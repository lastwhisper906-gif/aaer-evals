# FTNT 8-K — 0001262039-21-000011 filed 2021-04-29

## item codes, every 8-K on or before 2021-05-03

- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2021-05-03

- none on or before 2021-05-03

## item 2.02 — earnings release, exhibit 99.1

[0001262039-21-000011:8k_2_02:1]
EX-99.1
2
ftntq1-2021ex991.htm
PRESS RELEASE

[0001262039-21-000011:8k_2_02:2]
Document

[0001262039-21-000011:8k_2_02:3]
Press Release

[0001262039-21-000011:8k_2_02:4]
Fortinet Reports First Quarter 2021 Financial Results

[0001262039-21-000011:8k_2_02:5]
First Quarter 2021 Highlights

[0001262039-21-000011:8k_2_02:6]
•Total revenue of $710.3 million, up 23% year over year

[0001262039-21-000011:8k_2_02:7]
•Product revenue of $240.7 million, up 25% year over year

[0001262039-21-000011:8k_2_02:8]
•Service revenue of $469.6 million, up 22% year over year

[0001262039-21-000011:8k_2_02:9]
•Billings of $850.6 million, up 27% year over year1

[0001262039-21-000011:8k_2_02:10]
•Deferred revenue of $2.75 billion, up 25% year over year

[0001262039-21-000011:8k_2_02:11]
•GAAP operating margin of 17.1%, down 310 basis points year over year

[0001262039-21-000011:8k_2_02:12]
•Non-GAAP operating margin of 24.5%, up 210 basis points year over year1

[0001262039-21-000011:8k_2_02:13]
•GAAP diluted net income per share of $0.64

[0001262039-21-000011:8k_2_02:14]
•Non-GAAP diluted net income per share of $0.811

[0001262039-21-000011:8k_2_02:15]
•Cash flow from operations of $315.9 million

[0001262039-21-000011:8k_2_02:16]
•Free cash flow of $263.8 million1

[0001262039-21-000011:8k_2_02:17]
SUNNYVALE, Calif. - April 29, 2021 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the first quarter ended March 31, 2021.

[0001262039-21-000011:8k_2_02:18]
“We delivered strong revenue and billings growth in the first quarter while investing to increase market share across our existing businesses and drive growth in newer product areas such as 5G, SASE, and SD-WAN,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “Fortinet’s platform of on-premise and cloud security products is resonating with new and existing customers, confirmed by our highest quarterly product revenue growth in five years. With good visibility and strong business momentum, we are pleased to raise our full year guidance.”

[0001262039-21-000011:8k_2_02:19]
Financial Highlights for the First Quarter of 2021

[0001262039-21-000011:8k_2_02:20]
•Revenue: Total revenue was $710.3 million for the first quarter of 2021, an increase of 23.0% compared to $577.7 million for the same quarter of 2020.

[0001262039-21-000011:8k_2_02:21]
•Product Revenue: Product revenue was $240.7 million for the first quarter of 2021, an increase of 25.2% compared to $192.3 million for the same quarter of 2020.

[0001262039-21-000011:8k_2_02:22]
•Service Revenue: Service revenue was $469.6 million for the first quarter of 2021, an increase of 21.8% compared to $385.4 million for the same quarter of 2020.

[0001262039-21-000011:8k_2_02:23]
•Billings1: Total billings were $850.6 million for the first quarter of 2021, an increase of 27.4% compared to $667.8 million for the same quarter of 2020.

[0001262039-21-000011:8k_2_02:24]
•Deferred Revenue: Total deferred revenue was $2.75 billion as of March 31, 2021, an increase of 24.8% compared to $2.20 billion as of March 31, 2020.

[0001262039-21-000011:8k_2_02:25]
•GAAP Operating Income and Margin: GAAP operating income was $121.6 million for the first quarter of 2021, representing a GAAP operating margin of 17.1%. GAAP operating income was $116.7 million for the same quarter of 2020, representing a GAAP operating margin of 20.2%.

[0001262039-21-000011:8k_2_02:26]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $173.9 million for the first quarter of 2021, representing a non-GAAP operating margin of 24.5%. Non-GAAP operating income was $129.2 million for the same quarter of 2020, representing a non-GAAP operating margin of 22.4%.

[0001262039-21-000011:8k_2_02:27]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $107.2 million for the first quarter of 2021, compared to GAAP net income of $104.6 million for the same quarter of 2020. GAAP diluted net income per share was $0.64 for the first quarter of 2021, based on 166.4 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.60 for the same quarter of 2020, based on 174.2 million diluted weighted-average shares outstanding.

[0001262039-21-000011:8k_2_02:28]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $135.6 million for the first quarter of 2021, compared to non-GAAP net income of $105.1 million for the same quarter of 2020. Non-GAAP diluted net income per share was $0.81 for the first quarter of 2021, based on 166.4 million diluted weighted-average shares outstanding, compared to $0.60 for the same quarter of 2020, based on 174.2 million diluted weighted-average shares outstanding.

[0001262039-21-000011:8k_2_02:29]
•Cash Flow: In the first quarter of 2021, cash flow from operations was $315.9 million compared to $319.4 million in the same quarter of 2020.

[0001262039-21-000011:8k_2_02:30]
•Free Cash Flow1: Free cash flow was $263.8 million during the first quarter of 2021, compared to $241.8 million for the same quarter of 2020.

[0001262039-21-000011:8k_2_02:31]
Guidance

[0001262039-21-000011:8k_2_02:32]
For the second quarter of 2021, Fortinet currently expects:

[0001262039-21-000011:8k_2_02:33]
•Revenue in the range of $733 million to $747 million

[0001262039-21-000011:8k_2_02:34]
•Billings in the range of $860 million to $880 million

[0001262039-21-000011:8k_2_02:35]
•Non-GAAP gross margin in the range of 78.5% to 79.5%

[0001262039-21-000011:8k_2_02:36]
•Non-GAAP operating margin in the range of 24.5% to 25.5%

[0001262039-21-000011:8k_2_02:37]
•Diluted non-GAAP net income per share in the range of $0.83 to $0.88, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 168 million to 170 million.

[0001262039-21-000011:8k_2_02:38]
For the fiscal year 2021, Fortinet currently expects:

[0001262039-21-000011:8k_2_02:39]
•Revenue in the range of $3.080 billion to $3.130 billion

[0001262039-21-000011:8k_2_02:40]
•Service revenue in the range of $2.020 billion to $2.050 billion

[0001262039-21-000011:8k_2_02:41]
•Billings in the range of $3.685 billion to $3.745 billion

[0001262039-21-000011:8k_2_02:42]
•Non-GAAP gross margin in the range of 78.0% to 80.0%

[0001262039-21-000011:8k_2_02:43]
•Non-GAAP operating margin in the range of 25.0% to 27.0%

[0001262039-21-000011:8k_2_02:44]
•Diluted non-GAAP net income per share in the range of $3.65 to $3.80, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 170 million to 172 million.

[0001262039-21-000011:8k_2_02:45]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-21-000011:8k_2_02:46]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-21-000011:8k_2_02:47]
Conference Call Details

[0001262039-21-000011:8k_2_02:48]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 1998423. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through May 6 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #1998423.

[0001262039-21-000011:8k_2_02:49]
Second Quarter 2021 Virtual Conference Participation Schedule:

[0001262039-21-000011:8k_2_02:50]
•J.P. Morgan Virtual 49th Annual Global Technology, Media and Communications Conference

[0001262039-21-000011:8k_2_02:51]
May 25, 2021

[0001262039-21-000011:8k_2_02:52]
•Bernstein’s Virtual 37th Annual Strategic Decisions Conference

[0001262039-21-000011:8k_2_02:53]
June 2, 2021

[0001262039-21-000011:8k_2_02:54]
•Bank of America’s Virtual 2021 Global Technology Conference

[0001262039-21-000011:8k_2_02:55]
June 8, 2021

[0001262039-21-000011:8k_2_02:56]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-21-000011:8k_2_02:57]
About Fortinet (www.fortinet.com)

[0001262039-21-000011:8k_2_02:58]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. The Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a

[0001262039-21-000011:8k_2_02:59]
technology company and a learning organization, the Fortinet Network Security Institute has one of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-21-000011:8k_2_02:60]
#          #          #

[0001262039-21-000011:8k_2_02:61]
Copyright © 2021 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPenTest, FortiPhish, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiSASE, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-21-000011:8k_2_02:62]
FTNT-F

[0001262039-21-000011:8k_2_02:63]
Forward-Looking Statements

[0001262039-21-000011:8k_2_02:64]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, guidance and expectations around future financial results, including guidance and expectations for the second quarter and full year 2021, statements regarding the momentum in our business and future growth expectations and objectives and statements regarding growth in market demand. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by the COVID-19 pandemic; negative impacts from the COVID-19 pandemic on sales, billings, revenue, demand and buying patterns, component supply and ability to manufacture products to meet demand in a timely fashion, and costs such as possible increased costs for shipping and components; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and

[0001262039-21-000011:8k_2_02:65]
COVID-19 Impact

[0001262039-21-000011:8k_2_02:66]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending June 30, 2021, our annual results for 2021, and beyond. To highlight the uncertainty remaining for the three month period ending June 30, 2021, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-21-000011:8k_2_02:67]
Non-GAAP Financial Measures

[0001262039-21-000011:8k_2_02:68]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-21-000011:8k_2_02:69]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-21-000011:8k_2_02:70]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-21-000011:8k_2_02:71]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-21-000011:8k_2_02:72]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-21-000011:8k_2_02:73]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-21-000011:8k_2_02:74]
FORTINET, INC.

[0001262039-21-000011:8k_2_02:75]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-21-000011:8k_2_02:76]
(Unaudited, in millions)

[0001262039-21-000011:8k_2_02:77]
|  | March 31,2021 |  | December 31,2020 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,860.2 |  |  | $ | 1,061.8 |  |
| Short-term investments | 1,076.7 |  |  | 775.5 |  |
| Accounts receivable—net | 637.3 |  |  | 720.0 |  |
| Inventory | 149.6 |  |  | 139.8 |  |
| Prepaid expenses and other current assets | 57.4 |  |  | 43.3 |  |
| Total current assets | 3,781.2 |  |  | 2,740.4 |  |
| LONG-TERM INVESTMENTS | 151.1 |  |  | 118.3 |  |
| PROPERTY AND EQUIPMENT—NET | 494.2 |  |  | 448.0 |  |
| DEFERRED CONTRACT COSTS | 320.2 |  |  | 304.8 |  |
| DEFERRED TAX ASSETS | 260.6 |  |  | 245.2 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 131.5 |  |  | 124.6 |  |
| OTHER ASSETS | 143.4 |  |  | 63.2 |  |
| TOTAL ASSETS | $ | 5,282.2 |  |  | $ | 4,044.5 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 129.5 |  |  | $ | 141.6 |  |
| Accrued liabilities | 143.2 |  |  | 149.2 |  |
| Accrued payroll and compensation | 141.9 |  |  | 145.9 |  |
| Deferred revenue | 1,465.1 |  |  | 1,392.8 |  |
| Total current liabilities | 1,879.7 |  |  | 1,829.5 |  |
| DEFERRED REVENUE | 1,280.5 |  |  | 1,212.5 |  |
| INCOME TAX LIABILITIES | 97.7 |  |  | 90.3 |  |
| LONG-TERM DEBT | 987.0 |  |  | — |  |
| OTHER LIABILITIES | 56.5 |  |  | 56.2 |  |
| Total liabilities | 4,301.4 |  |  | 3,188.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,225.2 |  |  | 1,207.2 |  |
| Accumulated other comprehensive income | 0.3 |  |  | 0.7 |  |
| Accumulated deficit | (244.9) |  |  | (352.1) |  |
| Total stockholders’ equity | 980.8 |  |  | 856.0 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 5,282.2 |  |  | $ | 4,044.5 |  |

[0001262039-21-000011:8k_2_02:78]
FORTINET, INC.

[0001262039-21-000011:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-21-000011:8k_2_02:80]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000011:8k_2_02:81]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | 710.3 |  |  | 577.7 |  |  |  |  |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 91.3 |  |  | 76.3 |  |  |  |  |  |
| Service | 65.3 |  |  | 52.4 |  |  |  |  |  |
| Total cost of revenue | 156.6 |  |  | 128.7 |  |  |  |  |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 149.4 |  |  | 116.0 |  |  |  |  |  |
| Service | 404.3 |  |  | 333.0 |  |  |  |  |  |
| Total gross profit | 553.7 |  |  | 449.0 |  |  |  |  |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 97.2 |  |  | 80.3 |  |  |  |  |  |
| Sales and marketing | 304.0 |  |  | 260.0 |  |  |  |  |  |
| General and administrative | 32.0 |  |  | 28.8 |  |  |  |  |  |
| Gain on intellectual property matter | (1.1) |  |  | (36.8) |  |  |  |  |  |
| Total operating expenses | 432.1 |  |  | 332.3 |  |  |  |  |  |
| OPERATING INCOME | 121.6 |  |  | 116.7 |  |  |  |  |  |
| INTEREST INCOME (EXPENSE) —NET | (0.2) |  |  | 9.2 |  |  |  |  |  |
| OTHER EXPENSE—NET | (2.0) |  |  | (8.0) |  |  |  |  |  |
| INCOME BEFORE INCOME TAXES | 119.4 |  |  | 117.9 |  |  |  |  |  |
| PROVISION FOR INCOME TAXES | 12.2 |  |  | 13.3 |  |  |  |  |  |
| NET INCOME | $ | 107.2 |  |  | $ | 104.6 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.66 |  |  | $ | 0.61 |  |  |  |  |  |
| Diluted | $ | 0.64 |  |  | $ | 0.60 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 163.0 |  |  | 170.6 |  |  |  |  |  |
| Diluted | 166.4 |  |  | 174.2 |  |  |  |  |  |

[0001262039-21-000011:8k_2_02:82]
FORTINET, INC.

[0001262039-21-000011:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-21-000011:8k_2_02:84]
(Unaudited, in millions)

[0001262039-21-000011:8k_2_02:85]
|  | Three Months Ended |
|  | March 31,2021 |  | March 31,2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 107.2 |  |  | $ | 104.6 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 49.5 |  |  | 44.8 |  |
| Amortization of deferred contract costs | 39.7 |  |  | 31.3 |  |
| Depreciation and amortization | 17.3 |  |  | 17.6 |  |
| Amortization of investment premium (discounts) | 1.2 |  |  | (0.6) |  |
| Other | 0.4 |  |  | 4.3 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 82.5 |  |  | 69.6 |  |
| Inventory | (14.7) |  |  | 6.7 |  |
| Prepaid expenses and other current assets | (13.4) |  |  | (12.9) |  |
| Deferred contract costs | (55.2) |  |  | (43.0) |  |
| Deferred tax assets | (15.2) |  |  | 7.3 |  |
| Other assets | (4.8) |  |  | 0.9 |  |
| Accounts payable | (12.4) |  |  | (9.0) |  |
| Accrued liabilities | (2.8) |  |  | 1.8 |  |
| Accrued payroll and compensation | (3.9) |  |  | 1.8 |  |
| Other liabilities | 0.2 |  |  | 4.1 |  |
| Deferred revenue | 140.3 |  |  | 90.1 |  |
| Net cash provided by operating activities | 315.9 |  |  | 319.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (647.1) |  |  | (368.3) |  |
| Sales of investments | 18.6 |  |  | 126.8 |  |
| Maturities of investments | 292.4 |  |  | 277.2 |  |
| Purchases of property and equipment | (52.1) |  |  | (27.6) |  |
| Purchase of investment in privately held company | (75.0) |  |  | — |  |
| Payments made in connection with business combination, net of cash acquired | (10.3) |  |  | (3.1) |  |
| Other | — |  |  | (0.4) |  |
| Net cash provided by (used in) investing activities | (473.5) |  |  | 4.6 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from long-term debt, net of discount and underwriting fees | 989.4 |  |  | — |  |
| Payments for debt issuance costs | (1.9) |  |  |  |
| Repurchase and retirement of common stock | — |  |  | (889.9) |  |
| Proceeds from issuance of common stock | 9.9 |  |  | 7.4 |  |
| Taxes paid related to net share settlement of equity awards | (41.4) |  |  | (37.8) |  |
| Other | — |  |  | (0.1) |  |
| Net cash provided by (used in) financing activities | 956.0 |  |  | (920.4) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 798.4 |  |  | (596.4) |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,061.8 |  |  | 1,222.5 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,860.2 |  |  | $ | 626.1 |  |

[0001262039-21-000011:8k_2_02:86]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-21-000011:8k_2_02:87]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000011:8k_2_02:88]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-21-000011:8k_2_02:89]
|  | Three Months Ended |
|  | March 31,2021 |  | March 31,2020 |
| Net cash provided by operating activities | $ | 315.9 |  |  | $ | 319.4 |  |
| Less: Purchases of property and equipment | (52.1) |  |  | (27.6) |  |
| Less: Proceeds from intellectual property matter | — |  |  | (50.0) |  |
| Free cash flow | $ | 263.8 |  |  | $ | 241.8 |  |
| Net cash provided by (used in) investing activities | $ | (473.5) |  |  | $ | 4.6 |  |
| Net cash provided by (used in) financing activities | $ | 956.0 |  |  | $ | (920.4) |  |

[0001262039-21-000011:8k_2_02:90]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-21-000011:8k_2_02:91]
|  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 121.6 |  |  | $ | 52.3 |  | (a) | $ | 173.9 |  |  | $ | 116.7 |  |  | $ | 12.5 |  | (b) | $ | 129.2 |  |
| Operating margin | 17.1 | % |  |  |  | 24.5 | % |  | 20.2 | % |  |  |  | 22.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 50.0 |  |  |  |  |  |  | 45.3 |  |  |  |
| Amortization of acquired intangible assets |  |  | 3.4 |  |  |  |  |  |  | 4.0 |  |  |  |
| Gain on intellectual property matter |  |  | (1.1) |  |  |  |  |  |  | (36.8) |  |  |  |
| Loss on investments in privately-held companies |  |  | — |  |  |  |  |  |  | 4.3 |  | (c) |  |
| Tax adjustment |  |  | (23.9) |  | (d) |  |  |  |  | (16.3) |  | (d) |  |
| Net income | $ | 107.2 |  |  | $ | 28.4 |  |  | $ | 135.6 |  |  | $ | 104.6 |  |  | $ | 0.5 |  |  | $ | 105.1 |  |
| Diluted net income per share | $ | 0.64 |  |  |  |  | $ | 0.81 |  |  | $ | 0.60 |  |  |  |  | $ | 0.60 |  |
| Shares used in diluted net income per share calculations | 166.4 |  |  |  |  | 166.4 |  |  | 174.2 |  |  |  |  | 174.2 |  |

[0001262039-21-000011:8k_2_02:92]
(a) To exclude $50.0 million of stock-based compensation and $3.4 million of amortization of acquired intangible assets, offset by a $1.1 million gain on intellectual property matter, in the three months ended March 31, 2021.

[0001262039-21-000011:8k_2_02:93]
(b) To exclude $45.3 million of stock-based compensation and $4.0 million of amortization of acquired intangible assets, offset by a $36.8 million gain on intellectual property matter, in the three months ended March 31, 2020.

[0001262039-21-000011:8k_2_02:94]
(c) To exclude a $4.3 million impairment charge on an investment in a privately held company in the three months ended March 31, 2020.

[0001262039-21-000011:8k_2_02:95]
(d) Non-GAAP financial information is adjusted to an effective tax rate of 21% and 22% in the three months ended March 31, 2021 and 2020, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-21-000011:8k_2_02:96]
Reconciliation of total revenue to total billings

[0001262039-21-000011:8k_2_02:97]
|  | Three Months Ended |
|  | March 31,2021 |  | March 31,2020 |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |
| Add: Change in deferred revenue | 140.3 |  |  | 90.1 |  |
| Less: Deferred revenue balance acquired in business acquisition | — |  |  | — |  |
| Total billings | $ | 850.6 |  |  | $ | 667.8 |  |

[0001262039-21-000011:8k_2_02:98]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
