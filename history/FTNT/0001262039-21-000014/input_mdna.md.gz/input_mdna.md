# FTNT MD&A — 0001262039-21-000014


## mdna

[0001262039-21-000014:mdna:1]
[same as prior period, unchanged from 0001262039-20-000067:mdna:1]

[0001262039-21-000014:mdna:2]
•the duration and impact of the COVID-19 pandemic and the implementation of “return to office” plans;

[0001262039-21-000014:mdna:3]
[same as prior period, unchanged from 0001262039-20-000067:mdna:3]

[0001262039-21-000014:mdna:4]
[same as prior period, unchanged from 0001262039-20-000067:mdna:4]

[0001262039-21-000014:mdna:5]
[same as prior period, unchanged from 0001262039-20-000067:mdna:5]

[0001262039-21-000014:mdna:6]
[same as prior period, unchanged from 0001262039-20-000067:mdna:6]

[0001262039-21-000014:mdna:7]
[same as prior period, unchanged from 0001262039-20-000067:mdna:7]

[0001262039-21-000014:mdna:8]
[same as prior period, unchanged from 0001262039-20-000067:mdna:8]

[0001262039-21-000014:mdna:9]
•the effects of government regulation, tariffs and other policies;

[0001262039-21-000014:mdna:10]
•the effects of the global chip shortage and other factors affecting our manufacturing capacity and inventory management;

[0001262039-21-000014:mdna:11]
•drivers of long-term growth and operating leverage, such as sales productivity, functionality and value in our subscription service offerings;

[0001262039-21-000014:mdna:12]
[same as prior period, unchanged from 0001262039-20-000067:mdna:11]

[0001262039-21-000014:mdna:13]
[same as prior period, unchanged from 0001262039-20-000067:mdna:12]

[0001262039-21-000014:mdna:14]
[same as prior period, unchanged from 0001262039-20-000067:mdna:13]

[0001262039-21-000014:mdna:15]
[same as prior period, unchanged from 0001262039-20-000067:mdna:14]

[0001262039-21-000014:mdna:16]
•risks and expectations related to acquisitions and equity interests in private companies, including integration issues related to product plans and products, including the acquired technology;

[0001262039-21-000014:mdna:17]
•expectations that our operating expense will increase in absolute dollars during 2021;

[0001262039-21-000014:mdna:18]
[same as prior period, unchanged from 0001262039-20-000067:mdna:19]

[0001262039-21-000014:mdna:19]
•estimates of a range of 2021 spending on our headquarters expansion project and of the anticipated completion timeline for the project;

[0001262039-21-000014:mdna:20]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”) and the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”);

[0001262039-21-000014:mdna:21]
23

[0001262039-21-000014:mdna:22]
[same as prior period, unchanged from 0001262039-20-000067:mdna:23]

[0001262039-21-000014:mdna:23]
[same as prior period, unchanged from 0001262039-20-000067:mdna:24]

[0001262039-21-000014:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-21-000014:mdna:25]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs, including our debt servicing requirements, for at least the next 12 months;

[0001262039-21-000014:mdna:26]
[same as prior period, unchanged from 0001262039-20-000067:mdna:27]

[0001262039-21-000014:mdna:27]
[same as prior period, unchanged from 0001262039-20-000067:mdna:28]

[0001262039-21-000014:mdna:28]
[same as prior period, unchanged from 0001262039-20-000067:mdna:29]

[0001262039-21-000014:mdna:29]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response. The Fortinet Security Fabric platform leverages a common operating system or integration to this operating system across our product offerings and helps organizations secure their environments and reduce their security and network complexities. The Fortinet Security Fabric platform has an open architecture designed to connect Fortinet solutions and third-party solutions into a single ecosystem, enabling integration and automation.

[0001262039-21-000014:mdna:30]
Our product offerings consist of our FortiGate network security products and our non-FortiGate products. Our FortiGate hardware and software licenses are sold with a set of security services in addition to networking features. Our security services are enabled by FortiGuard Labs, which provides threat research and artificial intelligence capabilities from a cloud network to deliver protection services to each FortiGate appliance and virtual machine and each non-FortiGate product that is registered by the end-customer.

[0001262039-21-000014:mdna:31]
Our FortiOS operating system, associated security and networking functions, and products that run or are integrated with FortiOS are combined to form the Fortinet Security Fabric platform. This approach to security ties discrete security solutions together into an integrated whole that provides centralized management and visibility, automation and intelligence sharing to simplify network and security operations and rapid response to threats.

[0001262039-21-000014:mdna:32]
[same as prior period, unchanged from 0001262039-20-000067:mdna:33]

[0001262039-21-000014:mdna:33]
[same as prior period, unchanged from 0001262039-20-000067:mdna:34]

[0001262039-21-000014:mdna:34]
[same as prior period, unchanged from 0001262039-20-000067:mdna:35]

[0001262039-21-000014:mdna:35]
•Security-Driven Networking—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide area network (“SD-WAN”), Intrusion Prevention system (“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Units (“SPUs”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance.

[0001262039-21-000014:mdna:36]
•Infrastructure Security—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include Zero Trust Access solutions that provide teleworker and remote security such as FortiAuthenticator, FortiClient and FortiToken, as well as Secure Access (Wi-Fi and switch). Fortinet also extends, protects, and enables customer cloud on-ramp needs through FortiSASE, our Secure Access Service Edge (SASE) solution that is a cloud-delivered service that combines network and security functions with WAN capabilities.

[0001262039-21-000014:mdna:37]
•Adaptive Cloud Security—We help customers connect securely to and across their individual, hybrid and multi-cloud environments by offering security through our virtual firewall and other software products and through integrated capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform in and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also includes securing applications, including email and web. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud, IBM Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-21-000014:mdna:38]
•Endpoint Protection, Internet of Things (“IoT”) and Operational Technology (“OT”) Security—We protect end-customers from advanced threats that target their devices and the data that reside on them through our advanced endpoint solutions that provide core endpoint protection, advanced threat protection, incident monitoring, and response. Additionally, the proliferation of IoT and OT devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices.

[0001262039-21-000014:mdna:39]
•AI-Driven Security Operations—We develop and provide Artificial Intelligence (“AI”) driven security operations solutions, including FortiGuard and other security subscription services, endpoint detection and response, and our security orchestration, automation and response (“SOAR”) capabilities and solutions, that can be applied across the entire Fortinet Security Fabric platform. These solutions deliver intelligence and insights.

[0001262039-21-000014:mdna:40]
[same as prior period, unchanged from 0001262039-20-000067:mdna:41]

[0001262039-21-000014:mdna:41]
[same as prior period, unchanged from 0001262039-20-000067:mdna:42]

[0001262039-21-000014:mdna:42]
As discussed in Note 2 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an understatement of revenue during the three months ended March 31, 2020.

[0001262039-21-000014:mdna:43]
The correction of this error resulted in an increase to service revenue, gross profit and operating income of $0.8 million for the three months ended March 31, 2020. Net income increased by $0.6 million for the three months ended March 31, 2020.

[0001262039-21-000014:mdna:44]
25

[0001262039-21-000014:mdna:45]
We evaluated the effect of this correction on the previous results of operations and determined that it did not materially impact any trends previously disclosed. This correction did not impact net cash provided by operating activities, billings or free cash flows.

[0001262039-21-000014:mdna:46]
[same as prior period, unchanged from 0001262039-20-000067:mdna:47]

[0001262039-21-000014:mdna:47]
•Total revenue was $710.3 million during the three months ended March 31, 2021, an increase of 23%, compared to $577.7 million in the same period last year. Product revenue was $240.7 million during the three months ended March 31, 2021, an increase of 25%, compared to $192.3 million in the same period last year. Service revenue was $469.6 million during the three months ended March 31, 2021, an increase of 22%, compared to $385.4 million in the same period last year.

[0001262039-21-000014:mdna:48]
•Total gross profit was $553.7 million during the three months ended March 31, 2021, an increase of 23%, compared to $449.0 million in the same period last year.

[0001262039-21-000014:mdna:49]
•We generated operating income of $121.6 million during the three months ended March 31, 2021, an increase of 4%, compared to $116.7 million in the same period last year. Operating income during the three months ended March 31, 2021 and 2020 included gains on an intellectual property (“IP”) matter of $1.1 million and $36.8 million, respectively.

[0001262039-21-000014:mdna:50]
•Cash, cash equivalents and investments were $3.09 billion as of March 31, 2021.

[0001262039-21-000014:mdna:51]
•In March 2021, we issued $1.0 billion of Senior Notes. Long-term debt, net of unamortized discount and debt issuance costs, was $987.0 million as of March 31, 2021. There was no such debt outstanding at December  31, 2020.

[0001262039-21-000014:mdna:52]
•Deferred revenue was $2.75 billion as of March 31, 2021, an increase of $140.3 million, or 5%, from December 31, 2020. Short-term deferred revenue was $1.47 billion as of March 31, 2021, an increase of $72.3 million, or 5%, from December 31, 2020.

[0001262039-21-000014:mdna:53]
•We generated cash flows from operating activities of $315.9 million during the three months ended March 31, 2021, a decrease of $3.5 million, or 1%, compared to the same period last year. The decrease was mainly due to the $50.0 million proceeds from an IP matter in the first quarter of 2020.

[0001262039-21-000014:mdna:54]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended March 31, 2021, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 41%, 39% and 20% of our total revenue, respectively, and increased by 20%, 25% and 26% compared to the same period last year, respectively.

[0001262039-21-000014:mdna:55]
Product revenue grew 25% during the three months ended March 31, 2021 compared to the same period last year. We experienced revenue growth across many of our products primarily due to an increase in product revenue from our security fabric platform products, including our SD-WAN solutions, and software licenses. Service revenue growth of 22% during the three months ended March 31, 2021, compared to the same period last year, was driven by the strength of our FortiGate technical support and other service revenue and FortiGuard and other security subscription revenue, which grew 23% and 21%, respectively, compared to the same period last year.

[0001262039-21-000014:mdna:56]
Our billings were diversified on a geographic basis. During the three months ended March 31, 2021, approximately 50% of our billings in the aggregate were from over 80 countries that individually contributed less than 3% of our billings.

[0001262039-21-000014:mdna:57]
During the three months ended March 31, 2021 and 2020, we recognized gains of $1.1 million and $36.8 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter in the first quarter of 2020 and 2021, operating expenses as a percentage of revenue decreased by 2.9 percentage points during the three months ended March 31, 2021 compared to the same period last year. Headcount increased to 8,615 employees and contractors as of March 31, 2021, a 5% increase compared to 8,238 as of December 31, 2020 and a 16% increase compared to 7,448 as of March 31, 2020.

[0001262039-21-000014:mdna:58]
[same as prior period, unchanged from 0001262039-20-000067:mdna:60]

[0001262039-21-000014:mdna:59]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic. In response to the pandemic, we have taken a number of actions to protect our employees, including restricting travel and directing most of our employees to work from home. Where onsite work is permitted, we have implemented measures such

[0001262039-21-000014:mdna:60]
26

[0001262039-21-000014:mdna:61]
as staggered work shifts, social distancing, the use of face coverings, health safety awareness training and frequent disinfection of shared spaces. In March 2020, we implemented our readiness plans, which include steps to maintain critical internet infrastructure with many employees working remotely.

[0001262039-21-000014:mdna:62]
We are also continuing to provide free online information technology security training for the public, aimed at helping high school and college students and professionals augment their security skill sets to open career opportunities and to help narrow the security skills gap. As of March 31, 2021, there have been over 950,000 registrations for our free online trainings since we launched the program. We will continue to provide free online trainings throughout 2021.

[0001262039-21-000014:mdna:63]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three months ended March 31, 2021. Conversely, some aspects of our business do not appear to have been significantly affected. During the three months ended March 31, 2021, we have observed the following:

[0001262039-21-000014:mdna:64]
•In most countries, our employees’ ability to travel was reduced. In-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. As a result, expenses related to travel and marketing events decreased significantly. To the extent that it becomes safe for our employees to travel and for us to hold or attend marketing events, these expenses may increase in the future, although we cannot predict if or when such expenses will increase or return to pre-pandemic levels.

[0001262039-21-000014:mdna:65]
•The countries and geographic regions in which we experienced the fastest billings growth in the first quarter of 2021, as compared to the first quarter of 2020, were countries and geographic regions in which the COVID-19 pandemic is generally considered to have had a comparatively shorter or less severe impact on the local population and economy during the quarter.

[0001262039-21-000014:mdna:66]
•We have noted that, for some of our customers, sales cycles appear to have lengthened, though it is unclear whether this trend will persist.

[0001262039-21-000014:mdna:67]
•Our average service contract duration increased by approximately two months in the first quarter of 2021 as compared to the first quarter of 2020.

[0001262039-21-000014:mdna:68]
•In order to mitigate supply chain risk and in anticipation of future demand, we have increased our on-hand stock of certain products.

[0001262039-21-000014:mdna:69]
•The yield on investment-grade debt has decreased, and while the risk of credit losses on our investments and cash equivalents has not changed significantly, as the debt securities in our portfolio have matured, they have been replaced by securities with lower effective interest rates. This has contributed to a decrease in our interest income during the three months ended March 31, 2021, compared to the same period last year.

[0001262039-21-000014:mdna:70]
•In accordance with the CARES Act, we have deferred the deposit and payment of our employer’s share of Social Security taxes. This did not materially affect net cash provided by operating activities during the period.

[0001262039-21-000014:mdna:71]
•In addition, we have noted that, in certain countries, the COVID-19 infection rates have eased which might trigger the transition back to an in-person working model. We expect our “return to office” plan to be country specific and in line with local employee health and safety protocols and other regulations.

[0001262039-21-000014:mdna:72]
Through the filing of this Quarterly Report on Form 10-Q, there have been no material changes to the trends described above. Going forward, however, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods. For further discussion, see Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001262039-21-000014:mdna:73]
[same as prior period, unchanged from 0001262039-20-000067:mdna:73]

[0001262039-21-000014:mdna:74]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers. At times, we also sell directly to large service providers and major systems integrators who may sell to our end-customers or use our products and services to provided hosted solutions to other enterprises. Our end-customers are located in over 80 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including telecommunications, government, financial services, retail, technology, education, manufacturing and healthcare. An end-customer deployment may involve as few as one or as many as thousands of appliances and other Fortinet Security Fabric platform products, depending on the end-customer’s size and security requirements.

[0001262039-21-000014:mdna:75]
We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in third-party clouds or in their private cloud.

[0001262039-21-000014:mdna:76]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though, as noted in the COVID-19 Update above, we have offered extended payment terms to certain distributor customers.

[0001262039-21-000014:mdna:77]
[same as prior period, unchanged from 0001262039-20-000067:mdna:77]

[0001262039-21-000014:mdna:78]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-21-000014:mdna:79]
|  | Three Months Ended Or As Of |
|  | March 31, 2021 |  | March 31, 2020 |
|  | (in millions) |
| Revenue | $ | 710.3 |  |  | $ | 577.7 |  |
| Deferred revenue | $ | 2,745.6 |  |  | $ | 2,199.2 |  |
| Billings (non-GAAP) | $ | 850.6 |  |  | $ | 667.8 |  |
| Net cash provided by operating activities | $ | 315.9 |  |  | $ | 319.4 |  |
| Free cash flow (non-GAAP) | $ | 263.8 |  |  | $ | 241.8 |  |

[0001262039-21-000014:mdna:80]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.75 billion as of March 31, 2021, an increase of $140.3 million, or 5%, from December 31, 2020.

[0001262039-21-000014:mdna:81]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $850.6

[0001262039-21-000014:mdna:82]
million for the three months ended March 31, 2021, an increase of 27% compared to $667.8 million in the same period last year.

[0001262039-21-000014:mdna:83]
[same as prior period, unchanged from 0001262039-20-000067:mdna:83]

[0001262039-21-000014:mdna:84]
|  | Three Months Ended |
|  | March 31, 2021 |  | March 31, 2020 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 710.3 |  |  | $ | 577.7 |  |
| Add: Change in deferred revenue | 140.3 |  |  | 90.1 |  |
| Total billings (non-GAAP) | $ | 850.6 |  |  | $ | 667.8 |  |

[0001262039-21-000014:mdna:85]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-21-000014:mdna:86]
|  | Three Months Ended |
|  | March 31, 2021 |  | March 31, 2020 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 315.9 |  |  | $ | 319.4 |  |
| Less: Purchases of property and equipment | (52.1) |  |  | (27.6) |  |
| Less: Proceeds from IP matter | — |  |  | (50.0) |  |
| Free cash flow (non-GAAP) | $ | 263.8 |  |  | $ | 241.8 |  |
| Net cash provided by (used in) investing activities | $ | (473.5) |  |  | $ | 4.6 |  |
| Net cash provided by (used in) financing activities | $ | 956.0 |  |  | $ | (920.4) |  |

[0001262039-21-000014:mdna:87]
[same as prior period, unchanged from 0001262039-20-000067:mdna:89]

[0001262039-21-000014:mdna:88]
[same as prior period, unchanged from 0001262039-20-000067:mdna:90]

[0001262039-21-000014:mdna:89]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2021, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 19, 2021 (the “Form 10-K”).

[0001262039-21-000014:mdna:90]
[same as prior period, unchanged from 0001262039-20-000067:mdna:92]

[0001262039-21-000014:mdna:91]
[same as prior period, unchanged from 0001262039-20-000067:mdna:93]

[0001262039-21-000014:mdna:92]
[same as prior period, unchanged from 0001262039-20-000067:mdna:94]

[0001262039-21-000014:mdna:93]
Three Months Ended March 31, 2021 and March 31, 2020

[0001262039-21-000014:mdna:94]
[same as prior period, unchanged from 0001262039-20-000067:mdna:96]

[0001262039-21-000014:mdna:95]
|  | Three Months Ended |  |  |  |  |
| March 31,2021 |  | March 31,2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 240.7 |  |  | 34 | % |  | $ | 192.3 |  |  | 33 | % |  | $ | 48.4 |  |  | 25 | % |
| Service | 469.6 |  |  | 66 |  |  | 385.4 |  |  | 67 |  |  | 84.2 |  |  | 22 |  |
| Total revenue | $ | 710.3 |  |  | 100 | % |  | $ | 577.7 |  |  | 100 | % |  | $ | 132.6 |  |  | 23 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 290.9 |  |  | 41 | % |  | $ | 242.6 |  |  | 42 | % |  | $ | 48.3 |  |  | 20 | % |
| EMEA | 275.7 |  |  | 39 |  |  | 221.0 |  |  | 38 |  |  | 54.7 |  |  | 25 |  |
| APAC | 143.7 |  |  | 20 |  |  | 114.1 |  |  | 20 |  |  | 29.6 |  |  | 26 |  |
| Total revenue | $ | 710.3 |  |  | 100 | % |  | $ | 577.7 |  |  | 100 | % |  | $ | 132.6 |  |  | 23 | % |

[0001262039-21-000014:mdna:96]
Total revenue increased by $132.6 million, or 23%, during the three months ended March 31, 2021 compared to the same period last year. We continued to experience largely organic revenue growth (i.e. revenue growth excluding attribution from acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC contributing the largest growth on a percentage basis.

[0001262039-21-000014:mdna:97]
Product revenue increased by $48.4 million, or 25%, during the three months ended March 31, 2021 compared to the same period last year. We experienced revenue growth across many of our products primarily due to an increase in product revenue from our security fabric platform products, including our SD-WAN solutions, and software licenses.

[0001262039-21-000014:mdna:98]
Service revenue increased by $84.2 million, or 22%, during the three months ended March 31, 2021 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $43.9 million, or 21%, and by $40.3 million, or 23%, respectively, during the three months ended March 31, 2021 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000014:mdna:99]
Of the service revenue recognized during the three months ended March 31, 2021, 89% was included in the deferred revenue balance as of December 31, 2020.

[0001262039-21-000014:mdna:100]
30

[0001262039-21-000014:mdna:101]
[same as prior period, unchanged from 0001262039-20-000067:mdna:102]

[0001262039-21-000014:mdna:102]
|  | Three Months Ended |  |  |  |  |
| March 31,2021 |  | March 31,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 91.3 |  |  | $ | 76.3 |  |  | $ | 15.0 |  |  | 20 | % |
| Service | 65.3 |  |  | 52.4 |  |  | 12.9 |  |  | 25 |  |
| Total cost of revenue | $ | 156.6 |  |  | $ | 128.7 |  |  | $ | 27.9 |  |  | 22 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 62.1 | % |  | 60.3 | % |  |  |  |  |
| Service | 86.1 |  |  | 86.4 |  |  |  |  |  |
| Total gross margin | 78.0 | % |  | 77.7 | % |  |  |  |  |

[0001262039-21-000014:mdna:103]
Total gross margin increased by 0.3 percentage points during the three months ended March 31, 2021 compared to the same period last year, driven by improvements to product gross margins.

[0001262039-21-000014:mdna:104]
Product gross margin increased by 1.8 percentage points during the three months ended March 31, 2021 compared to the same period last year. Product gross margin benefited from lower hardware cost as a percentage of product revenue. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000014:mdna:105]
Service gross margin decreased by 0.3 percentage points during the three months ended March 31, 2021 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs and data center costs.

[0001262039-21-000014:mdna:106]
[same as prior period, unchanged from 0001262039-20-000067:mdna:107]

[0001262039-21-000014:mdna:107]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2021 |  | March 31,2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 97.2 |  |  | 14% |  | $ | 80.3 |  |  | 14 | % |  | $ | 16.9 |  |  | 21 | % |
| Sales and marketing | 304.0 |  |  | 43 |  | 260.0 |  |  | 45 |  |  | 44.0 |  |  | 17 |  |
| General and administrative | 32.0 |  |  | 5 |  | 28.8 |  |  | 5 |  |  | 3.2 |  |  | 11 |  |
| Gain on IP matter | (1.1) |  |  | — |  | (36.8) |  |  | (6) |  |  | 35.7 |  |  | (97) |  |
| Total operating expenses | $ | 432.1 |  |  | 61% |  | $ | 332.3 |  |  | 58 | % |  | $ | 99.8 |  |  | 30 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-21-000014:mdna:108]
[same as prior period, unchanged from 0001262039-20-000067:mdna:111]

[0001262039-21-000014:mdna:109]
Research and development expense increased by $16.9 million, or 21%, during the three months ended March 31, 2021 compared to the same period last year, primarily due to an increase of $14.2 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development costs, such as third-party testing and prototypes, increase $3.0 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000014:mdna:110]
[same as prior period, unchanged from 0001262039-20-000067:mdna:113]

[0001262039-21-000014:mdna:111]
Sales and marketing expense increased by $44.0 million, or 17%, during the three months ended March 31, 2021 compared to the same period last year, primarily due to an increase of $48.5 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000014:mdna:112]
[same as prior period, unchanged from 0001262039-20-000067:mdna:115]

[0001262039-21-000014:mdna:113]
General and administrative expense increased by $3.2 million, or 11%, during the three months ended March 31, 2021 compared to the same period last year, primarily due to an increase in personnel-related costs of $2.5 million. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000014:mdna:114]
Gain on IP matter in the first quarter of 2020.

[0001262039-21-000014:mdna:115]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended March 31, 2021, we recorded $1.1 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. During the three months ended March 31, 2020, we recorded $36.0 million upfront and an additional $0.8 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 13 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter in the first quarter of 2020.

[0001262039-21-000014:mdna:116]
[same as prior period, unchanged from 0001262039-20-000067:mdna:119]

[0001262039-21-000014:mdna:117]
We generated operating income of $121.6 million during the three months ended March 31, 2021, an increase of $4.9 million, or 4%, compared to $116.7 million in the same period last year. Operating income as a percentage of revenue decreased to 17% during the three months ended March 31, 2021 compared to 20% in the same period last year. During the first quarter of 2020, we recorded a one-time upfront gain related to an IP matter, which increased our operating margin by 6.2 percentage point. Excluding the impact of this gain, our operating margin increased 3.2 percentage point primarily due to 2.2 percentage point and 0.5 percentage point decrease in sales and marketing expense and general and administrative expense as percentage of revenue, as well as 0.3 percentage point improvement in gross margin.

[0001262039-21-000014:mdna:118]
Interest income (expense)—net and other expense—net

[0001262039-21-000014:mdna:119]
|  | Three Months Ended |  |  |  |  |
| March 31,2021 |  | March 31,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income (expense)—net | $ | (0.2) |  |  | $ | 9.2 |  |  | $ | (9.4) |  |  | (102) | % |
| Other expense—net | $ | (2.0) |  |  | $ | (8.0) |  |  | $ | 6.0 |  |  | (75) | % |

[0001262039-21-000014:mdna:120]
The change in interest income (expense)—net during the three months ended March 31, 2021 compared to the same period last year was primarily due to the decrease in interest income of $8.1 million, as a result of lower interest rates. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. In addition, interest expense increased $1.3 million, due to the senior notes issued in the first quarter of 2021. We expect interest expense to increase during the remainder of 2021 as a result of the debt issued in March 2021. The change in other expense—net during the three months ended March 31, 2021 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company in the first quarter of 2020. In addition, foreign currency exchange losses decreased by $1.5 million compared to the same period last year.

[0001262039-21-000014:mdna:121]
[same as prior period, unchanged from 0001262039-20-000067:mdna:126]

[0001262039-21-000014:mdna:122]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2021 |  | March 31,2020 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 12.2 |  |  | $ | 13.3 |  |  | $ | (1.1) |  |  | (8) | % |
| Effective tax rate (%) | 10 | % |  | 11 | % |  |  |  |  |

[0001262039-21-000014:mdna:123]
Our effective tax rate was 10% for the three months ended March 31, 2021 compared to an effective tax rate of 11% for the same period last year. The provision for income taxes for the three months ended March 31, 2021 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $35.7 million. This tax provision for income taxes was favorably affected by a tax benefit of $7.3 million from the foreign-derived intangible income deduction and excess tax benefits from stock-based compensation expense of $16.2 million.

[0001262039-21-000014:mdna:124]
[same as prior period, unchanged from 0001262039-20-000067:mdna:165]

[0001262039-21-000014:mdna:125]
|  | As of |
|  | March 31,2021 |  | December 31,2020 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,860.2 |  |  | $ | 1,061.8 |  |
| Investments | 1,227.8 |  |  | 893.8 |  |
| Total cash, cash equivalents and investments | $ | 3,088.0 |  |  | $ | 1,955.6 |  |
| Working capital | $ | 1,901.5 |  |  | $ | 910.9 |  |
|  | Three Months Ended |
|  | March 31,2021 |  | March 31,2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 315.9 |  |  | $ | 319.4 |  |
| Net cash provided by (used in) investing activities | (473.5) |  |  | 4.6 |  |
| Net cash provided by (used in) financing activities | 956.0 |  |  | (920.4) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 798.4 |  |  | $ | (596.4) |  |

[0001262039-21-000014:mdna:126]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuance of common stock under Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”), investment grade debt issuance and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-21-000014:mdna:127]
[same as prior period, unchanged from 0001262039-20-000067:mdna:168]

[0001262039-21-000014:mdna:128]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-21-000014:mdna:129]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2021. As of March 31, 2021, $1.01 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-21-000014:mdna:130]
[same as prior period, unchanged from 0001262039-20-000067:mdna:86]

[0001262039-21-000014:mdna:131]
In March 2021, we issued $1.0 billion aggregate principal amount of senior notes, consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031, in an underwritten registered public offering.

[0001262039-21-000014:mdna:132]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not intend to retire these Notes early. Refer to Note 12. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes. As of March 31, 2021, the long-term debt, net of unamortized discount and debt issuance costs, was $987.0 million.

[0001262039-21-000014:mdna:133]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue in 2021 and until project completion. We estimate 2021 spending on the second building of our headquarters campus project to be between $50.0 million and $60.0 million, which was moved from 2020 due to a delay to the project schedule as a result of the COVID-19 pandemic. We estimate construction to be completed in the first half of 2021.

[0001262039-21-000014:mdna:134]
As of March 31, 2021, our cash, cash equivalents and investments of $3.09 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-21-000014:mdna:135]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $115.5 million as of March 31, 2021 and $119.8 million as of December 31, 2020.

[0001262039-21-000014:mdna:136]
[same as prior period, unchanged from 0001262039-20-000067:mdna:176]

[0001262039-21-000014:mdna:137]
[same as prior period, unchanged from 0001262039-20-000067:mdna:177]

[0001262039-21-000014:mdna:138]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs and accounts receivable.

[0001262039-21-000014:mdna:139]
Our operating activities during the three months ended March 31, 2021 provided cash flows of $315.9 million as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $140.3 million, or 5%, during the three months ended March 31, 2021.

[0001262039-21-000014:mdna:140]
[same as prior period, unchanged from 0001262039-20-000067:mdna:180]

[0001262039-21-000014:mdna:141]
[same as prior period, unchanged from 0001262039-20-000067:mdna:181]

[0001262039-21-000014:mdna:142]
During the three months ended March 31, 2021, cash used in investing activities was $473.5 million, driven by $336.1 million spent for purchases of investments, net of maturities and sales of investments, $75.0 million used for purchases of investment in a privately held company, $52.1 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction,  and $10.3 million used for the acquisition of ShieldX Networks, Inc. (“ShieldX”), net of cash acquisition.

[0001262039-21-000014:mdna:143]
[same as prior period, unchanged from 0001262039-20-000067:mdna:98]

[0001262039-21-000014:mdna:144]
[same as prior period, unchanged from 0001262039-20-000067:mdna:183]

[0001262039-21-000014:mdna:145]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock,  taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the Amended Plan and the issuance of long-term notes, net of discount and underwriting.

[0001262039-21-000014:mdna:146]
During the three months ended March 31, 2021, cash provided by financing activities was $956.0 million, primarily driven by $989.4 million in cash proceeds from long-term investment grade debt, net of discount and underwriting fees, partially offset by $31.5 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-21-000014:mdna:147]
[same as prior period, unchanged from 0001262039-20-000067:mdna:186]

[0001262039-21-000014:mdna:148]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2021 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 14 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-21-000014:mdna:149]
[same as prior period, unchanged from 0001262039-20-000067:mdna:190]

[0001262039-21-000014:mdna:150]
As of March 31, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
