# FTNT notes — 0001262039-21-000014


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-21-000014:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

[0001262039-21-000014:notes:2]
[same as prior period, unchanged from 0001262039-20-000067:notes:2]

[0001262039-21-000014:notes:3]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2021.

[0001262039-21-000014:notes:4]
Recently Adopted Accounting Standards

[0001262039-21-000014:notes:5]
[same as prior period, unchanged from 0001262039-20-000067:notes:12]

[0001262039-21-000014:notes:6]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001262039-21-000014:notes:7]
IMMATERIAL CORRECTION OF PRIOR PERIOD FINANCIAL STATEMENTS
Subsequent to the issuance of our condensed consolidated financial statements for the period ended March 31, 2020, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts. Rather than commencing recognition upon end user registration, we should have commenced recognition when control had passed to the distributor, which we have determined is our customer. We assessed the effect of this correction, individually and in the aggregate, on prior periods’ financial statements in accordance with the SEC’s Staff Accounting Bulletin Nos. 99 and 108 and, based on an analysis of quantitative and qualitative factors, determined that the correction was not individually material to any of our prior interim or annual consolidated financial statements.

[0001262039-21-000014:notes:8]
All financial information contained in the accompanying notes to these condensed consolidated financial statements has been revised to reflect the correction of this error.

[0001262039-21-000014:notes:9]
The corrections to our condensed consolidated statement of income for the three months ended March 31, 2020 were as follows (in millions, except per share amounts):

[0001262039-21-000014:notes:10]
|  | Three Months Ended March 31, 2020 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |
| Service | $ | 384.6 |  |  | $ | 0.8 |  |  | $ | 385.4 |  |
| Total revenue | 576.9 |  |  | 0.8 |  |  | 577.7 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Service | 332.2 |  |  | 0.8 |  |  | 333.0 |  |
| Total gross profit | 448.2 |  |  | 0.8 |  |  | 449.0 |  |
| OPERATING INCOME | 115.9 |  |  | 0.8 |  |  | 116.7 |  |
| INCOME BEFORE INCOME TAXES | 117.1 |  |  | 0.8 |  |  | 117.9 |  |
| PROVISION FOR INCOME TAXES | 13.1 |  |  | 0.2 |  |  | 13.3 |  |
| NET INCOME | $ | 104.0 |  |  | $ | 0.6 |  |  | $ | 104.6 |  |
| Net income per share (Note 10): |  |  |  |  |  |
| Basic | $ | 0.61 |  |  | $ | — |  |  | $ | 0.61 |  |
| Diluted | $ | 0.60 |  |  | $ | — |  |  | $ | 0.60 |  |

[0001262039-21-000014:notes:11]
The corrections to our condensed consolidated statement of cash flows for the three months ended March 31, 2020 were as follows (in millions):

[0001262039-21-000014:notes:12]
|  | Three Months Ended March 31, 2020 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income | $ | 104.0 |  |  | $ | 0.6 |  |  | $ | 104.6 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Deferred tax assets | 7.1 |  |  | 0.2 |  |  | 7.3 |  |
| Deferred revenue | 90.9 |  |  | (0.8) |  |  | 90.1 |  |

[0001262039-21-000014:notes:13]
For the period in which we corrected net income, we made corresponding corrections to net income and comprehensive income in our condensed consolidated statement of comprehensive income and to net income, retained earnings (accumulated deficit) and total stockholders’ equity in our condensed consolidated statements of stockholders’ equity.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-21-000014:notes:14]
REVENUE RECOGNITIONWe sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.
Disaggregation of Revenue

[0001262039-21-000014:notes:15]
[same as prior period, unchanged from 0001262039-20-000067:notes:26]

[0001262039-21-000014:notes:16]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 255.3 |  |  | 211.4 |  |  |  |  |  |
| Technical support and other | 214.3 |  |  | 174.0 |  |  |  |  |  |
| Total service revenue | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |

[0001262039-21-000014:notes:17]
[same as prior period, unchanged from 0001262039-20-000067:notes:28]

[0001262039-21-000014:notes:18]
During the three months ended March 31, 2021 and March 31, 2020, we recognized $417.9 million and $343.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

[0001262039-21-000014:notes:19]
[same as prior period, unchanged from 0001262039-20-000067:notes:30]

[0001262039-21-000014:notes:20]
As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.75 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.47 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-21-000014:notes:21]
Accounts receivable

[0001262039-21-000014:notes:22]
Trade accounts receivable are recorded at the invoiced amount. Our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income.

[0001262039-21-000014:notes:23]
The allowance for credit losses was $3.1 million and $2.5 million as of March 31, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2021 and 2020.

[0001262039-21-000014:notes:24]
Deferred Contract Costs
Amortization of deferred contract costs during the three months ended March 31, 2021 and 2020 were $39.7 million and $31.3 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-21-000014:notes:25]
[same as prior period, unchanged from 0001262039-20-000067:notes:38]

[0001262039-21-000014:notes:26]
|  | March 31, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 482.1 |  |  | $ | 0.5 |  |  | $ | (0.2) |  |  | $ | 482.4 |  |
| Commercial paper | 426.4 |  |  | 0.1 |  |  | — |  |  | 426.5 |  |
| Certificates of deposit and term deposits (1) | 162.7 |  |  | — |  |  | — |  |  | 162.7 |  |
| U.S. government securities | 156.2 |  |  | — |  |  | — |  |  | 156.2 |  |
| Total available-for-sale securities | $ | 1,227.4 |  |  | $ | 0.6 |  |  | $ | (0.2) |  |  | $ | 1,227.8 |  |

[0001262039-21-000014:notes:27]
|  | December 31, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 410.5 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 411.5 |  |
| Commercial paper | 185.4 |  |  | — |  |  | — |  |  | 185.4 |  |
| Certificates of deposit and term deposits (1) | 112.0 |  |  | — |  |  | — |  |  | 112.0 |  |
| U.S. government securities | 184.9 |  |  | — |  |  | — |  |  | 184.9 |  |
| Total available-for-sale securities | $ | 892.8 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 893.8 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-21-000014:notes:28]
[same as prior period, unchanged from 0001262039-20-000067:notes:41]

[0001262039-21-000014:notes:29]
|  | March 31, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 272.2 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 272.2 |  |  | $ | (0.2) |  |
| Commercial paper | 164.1 |  |  | — |  |  | — |  |  | — |  |  | 164.1 |  |  | — |  |
| Certificates of deposit and term deposits | 29.5 |  |  | — |  |  | 5.5 |  |  | — |  |  | 35.0 |  |  | — |  |
| Total available-for-sale securities | $ | 465.8 |  |  | $ | (0.2) |  |  | $ | 5.5 |  |  | $ | — |  |  | $ | 471.3 |  |  | $ | (0.2) |  |

[0001262039-21-000014:notes:30]
|  | December 31, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 111.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 111.3 |  |  | $ | — |  |
| Commercial paper | 61.5 |  |  | — |  |  | — |  |  | — |  |  | 61.5 |  |  | — |  |
| U.S. government securities | 38.1 |  |  | — |  |  | — |  |  | — |  |  | 38.1 |  |  | — |  |
| Certificates of deposit and term deposits | 29.5 |  |  | — |  |  | — |  |  | — |  |  | 29.5 |  |  | — |  |
| Total available-for-sale securities | $ | 240.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 240.4 |  |  | $ | — |  |

[0001262039-21-000014:notes:31]
[same as prior period, unchanged from 0001262039-20-000067:notes:44]

[0001262039-21-000014:notes:32]
|  | March 31,2021 |  | December 31,2020 |
| Due within one year | $ | 1,076.7 |  |  | $ | 775.5 |  |
| Due within one to three years | 151.1 |  |  | 118.3 |  |
| Total | $ | 1,227.8 |  |  | $ | 893.8 |  |

[0001262039-21-000014:notes:33]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest receivable of $2.6 million as of March 31, 2021 was excluded from the fair value of our available-for-sale securities and was recorded in prepaid expenses and other current assets in our condensed consolidated balance sheet.

[0001262039-21-000014:notes:34]
Realized gains and losses on available-for-sale securities were insignificant in the periods presented.

[0001262039-21-000014:notes:35]
[same as prior period, unchanged from 0001262039-20-000067:notes:49]

[0001262039-21-000014:notes:36]
[same as prior period, unchanged from 0001262039-20-000067:notes:50]

[0001262039-21-000014:notes:37]
[same as prior period, unchanged from 0001262039-20-000067:notes:51]

[0001262039-21-000014:notes:38]
[same as prior period, unchanged from 0001262039-20-000067:notes:52]

[0001262039-21-000014:notes:39]
[same as prior period, unchanged from 0001262039-20-000067:notes:53]

[0001262039-21-000014:notes:40]
[same as prior period, unchanged from 0001262039-20-000067:notes:54]

[0001262039-21-000014:notes:41]
[same as prior period, unchanged from 0001262039-20-000067:notes:55]

[0001262039-21-000014:notes:42]
[same as prior period, unchanged from 0001262039-20-000067:notes:56]

[0001262039-21-000014:notes:43]
[same as prior period, unchanged from 0001262039-20-000067:notes:57]

[0001262039-21-000014:notes:44]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-21-000014:notes:45]
|  | March 31, 2021 |  | December 31, 2020 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 489.6 |  |  |  |  | $ | 489.6 |  |  | $ | — |  |  | $ | 413.7 |  |  | $ | — |  |  | $ | 413.7 |  |  | $ | — |  |
| Commercial paper | 463.2 |  |  | — |  |  | 463.2 |  |  | — |  |  | 197.2 |  |  | — |  |  | 197.2 |  |  | — |  |
| U.S. government securities | 156.2 |  |  | 156.2 |  |  | — |  |  | — |  |  | 184.9 |  |  | 184.9 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 169.2 |  |  | — |  |  | 169.2 |  |  | — |  |  | 112.0 |  |  | — |  |  | 112.0 |  |  | — |  |
| Money market funds | 282.8 |  |  | 282.8 |  |  | — |  |  | — |  |  | 152.7 |  |  | 152.7 |  |  | — |  |  | — |  |
| Total | $ | 1,561.0 |  |  | $ | 439.0 |  |  | $ | 1,122.0 |  |  | $ | — |  |  | $ | 1,060.5 |  |  | $ | 337.6 |  |  | $ | 722.9 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 333.2 |  |  |  |  |  |  |  |  | $ | 166.7 |  |  |  |  |  |  |  |
| Short-term investments | 1,076.7 |  |  |  |  |  |  |  |  | 775.5 |  |  |  |  |  |  |  |
| Long-term investments | 151.1 |  |  |  |  |  |  |  |  | 118.3 |  |  |  |  |  |  |  |
| Total | $ | 1,561.0 |  |  |  |  |  |  |  |  | $ | 1,060.5 |  |  |  |  |  |  |  |

[0001262039-21-000014:notes:46]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2021 and year ended December 31, 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-21-000014:notes:47]
[same as prior period, unchanged from 0001262039-20-000067:notes:61]

[0001262039-21-000014:notes:48]
|  | March 31,2021 |  | December 31,2020 |
| Raw materials | $ | 15.2 |  |  | $ | 13.8 |  |
| Finished goods | 134.4 |  |  | 126.0 |  |
| Inventory | $ | 149.6 |  |  | $ | 139.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-21-000014:notes:49]
[same as prior period, unchanged from 0001262039-20-000067:notes:63]

[0001262039-21-000014:notes:50]
|  | March 31,2021 |  | December 31,2020 |
| Land | $ | 106.8 |  |  | $ | 93.3 |  |
| Building and building improvements | 153.8 |  |  | 150.6 |  |
| Computer equipment and software | 146.4 |  |  | 137.2 |  |
| Leasehold improvements | 33.6 |  |  | 31.9 |  |
| Evaluation units | 18.7 |  |  | 19.8 |  |
| Furniture and fixtures | 22.1 |  |  | 21.3 |  |
| Construction-in-progress | 193.4 |  |  | 166.4 |  |
| Total property and equipment | 674.8 |  |  | 620.5 |  |
| Less: accumulated depreciation | (180.6) |  |  | (172.5) |  |
| Property and equipment—net | $ | 494.2 |  |  | $ | 448.0 |  |

[0001262039-21-000014:notes:51]
Construction-in-progress consists primarily of costs incurred in connection with the construction of a second building at our headquarters campus.
Depreciation expense was $14.0 million and $13.6 million during the three months ended March 31, 2021 and 2020, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-21-000014:notes:52]
INVESTMENTS IN PRIVATELY HELD COMPANIES
Linksys Holdings, Inc.

[0001262039-21-000014:notes:53]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys Holdings, Inc. (“Linksys”), which provides router connectivity solutions, for a 32.6% ownership interest in the outstanding capital stock of Linksys.

[0001262039-21-000014:notes:54]
We concluded that our investment is an in-substance common-stock investment, and, though we do not hold a controlling financial interest in Linksys, we have the ability to exercise significant influence over the operating and financial policies of Linksys. Therefore, we will account for this investment using the equity method of accounting.

[0001262039-21-000014:notes:55]
As of March 31, 2021, the investment was included in other assets on our condensed consolidated balance sheet. Our share of the earnings of Linksys subsequent to the acquisition date was not material for the quarter ended March 31, 2021. Transaction costs related to this investment were not material.

[0001262039-21-000014:notes:56]
Our other investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million as of March 31, 2021 and December 31, 2020.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-21-000014:notes:57]
BUSINESS COMBINATIONShieldX Networks, Inc.On March 10, 2021, we closed an acquisition of certain assets and liabilities of ShieldX Networks Inc. (“ShieldX”) for $10.8 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $6.2 million was allocated to goodwill, $4.1 million was allocated to developed technology intangible asset and $0.5 million was allocated to other net assets acquired. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business and potential cost savings and synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-21-000014:notes:58]
[same as prior period, unchanged from 0001262039-20-000067:notes:73]

[0001262039-21-000014:notes:59]
[same as prior period, unchanged from 0001262039-20-000067:notes:74]

[0001262039-21-000014:notes:60]
|  | Amount |
| Balance—December 31, 2020 | $ | 93.0 |  |
| Addition due to business combination | 6.2 |  |
| Balance—March 31, 2021 | $ | 99.2 |  |

[0001262039-21-000014:notes:61]
There were no impairments to goodwill during the three months ended March 31, 2021 or during prior periods.

[0001262039-21-000014:notes:62]
[same as prior period, unchanged from 0001262039-20-000067:notes:77]

[0001262039-21-000014:notes:63]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-21-000014:notes:64]
|  | March 31, 2021 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 63.4 |  |  | $ | 34.8 |  |  | $ | 28.6 |  |
| Customer relationships | 4.0 |  | 24.8 |  |  | 21.1 |  |  | 3.7 |  |
| Total other intangible assets—net |  |  | $ | 88.2 |  |  | $ | 55.9 |  |  | $ | 32.3 |  |

[0001262039-21-000014:notes:65]
|  | December 31, 2020 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 59.3 |  |  | $ | 32.3 |  |  | $ | 27.0 |  |
| Customer relationships | 4.0 |  | 24.8 |  |  | 20.2 |  |  | 4.6 |  |
| Total other intangible assets—net |  |  | $ | 84.1 |  |  | $ | 52.5 |  |  | $ | 31.6 |  |

[0001262039-21-000014:notes:66]
Amortization expense was $3.4 million and $4.0 million during the three months ended March 31, 2021 and 2020, respectively.

[0001262039-21-000014:notes:67]
[same as prior period, unchanged from 0001262039-20-000067:notes:82]

[0001262039-21-000014:notes:68]
|  | Amount |
| Years: |  |
| 2021 (the remainder of 2021) | $ | 10.5 |  |
| 2022 | 10.7 |  |
| 2023 | 7.6 |  |
| 2024 | 3.2 |  |
| 2025 | 0.3 |  |
| Total | $ | 32.3 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-21-000014:notes:69]
[same as prior period, unchanged from 0001262039-20-000067:notes:84]

[0001262039-21-000014:notes:70]
[same as prior period, unchanged from 0001262039-20-000067:notes:85]

[0001262039-21-000014:notes:71]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 107.2 |  |  | $ | 104.6 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.0 |  |  | 170.6 |  |  |  |  |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.0 |  |  | 170.6 |  |  |  |  |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.0 |  |  | 2.4 |  |  |  |  |  |
| Stock options | 1.4 |  |  | 1.2 |  |  |  |  |  |
| Weighted-average shares used to compute diluted net income per share | 166.4 |  |  | 174.2 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.66 |  |  | $ | 0.61 |  |  |  |  |  |
| Diluted | $ | 0.64 |  |  | $ | 0.60 |  |  |  |  |  |

[0001262039-21-000014:notes:72]
[same as prior period, unchanged from 0001262039-20-000067:notes:87]

[0001262039-21-000014:notes:73]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| RSUs | 0.4 |  |  | 0.6 |  |  |  |  |  |
| Stock options | 0.3 |  |  | 0.3 |  |  |  |  |  |
| Total | 0.7 |  |  | 0.9 |  |  |  |  |  |


## us-gaap:LesseeFinanceLeasesTextBlock

[0001262039-21-000014:notes:74]
LEASES 
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility.

[0001262039-21-000014:notes:75]
During the year ended December 31, 2019, we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our condensed consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-21-000014:notes:76]
The components of lease expense were as follows (in millions):

[0001262039-21-000014:notes:77]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Operating lease expense | $ | 5.9 |  |  | $ | 4.3 |  |  |  |  |  |
| Variable lease expense (1) | 0.8 |  |  | 0.6 |  |  |  |  |  |
| Short-term lease expense | 0.8 |  |  | 0.9 |  |  |  |  |  |
| Total lease expense | $ | 7.5 |  |  | $ | 5.8 |  |  |  |  |  |

[0001262039-21-000014:notes:78]
(1) Variable lease expense for the three months ended March 31, 2021 and 2020 predominantly included common area maintenance charges and parking expense.

[0001262039-21-000014:notes:79]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-21-000014:notes:80]
|  | Classification | March 31,2021 |  | December 31,2020 |
| Operating lease ROU assets - non-current | Other assets | $ | 53.9 |  |  | $ | 49.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 20.6 |  |  | $ | 19.1 |  |
| Operating lease liabilities - non-current | Other liabilities | 35.8 |  |  | 34.0 |  |
| Total operating lease liabilities |  | $ | 56.4 |  |  | $ | 53.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.4 |  | 3.5 |
| Weighted average discount rate - operating leases |  | 2.8 | % |  | 3.2 | % |

[0001262039-21-000014:notes:81]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-21-000014:notes:82]
|  | Three Months Ended |
|  | March 31,2021 |  | March 31,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 6.1 |  |  | $ | 4.6 |  |

[0001262039-21-000014:notes:83]
Maturities of operating lease liabilities as of March 31, 2021 were as follows (in millions):

[0001262039-21-000014:notes:84]
| Year Ending December 31, | Amount |
| 2021 (the remainder of 2021) | $ | 16.5 |  |
| 2022 | 17.8 |  |
| 2023 | 12.0 |  |
| 2024 | 7.5 |  |
| 2025 | 3.9 |  |
| Thereafter | 1.4 |  |
| Total lease payments | 59.1 |  |
| Less imputed interest | (2.7) |  |
| Total | $ | 56.4 |  |

[0001262039-21-000014:notes:85]
As of March 31, 2021, we had additional minimum lease payments of $2.7 million relating to operating leases for colocation space that had been signed but had not yet commenced. These leases will commence during 2021 and will have lease 
terms of three years.


## us-gaap:DebtDisclosureTextBlock

[0001262039-21-000014:notes:86]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-21-000014:notes:87]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-21-000014:notes:88]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (13.0) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.0 |  |

[0001262039-21-000014:notes:89]
As of March 31, 2021 we accrued interest payable of $1.2 million, and there are no financial covenants with which we must comply. During the quarter ended March 31, 2021 we recorded $1.3 million of total interest expense in relation to these Senior Notes.

[0001262039-21-000014:notes:90]
The total estimated fair value of the outstanding Senior Notes was approximately $975.6 million, including accrued and unpaid interest, as of March 31, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-21-000014:notes:91]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-21-000014:notes:92]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.
During the three months ended March 31, 2021 and 2020, we recorded $1.1 million and $36.8 million gain on IP matter in our condensed consolidated statements of income, respectively. We recorded $8.7 million in accrued liabilities and other liabilities in our condensed consolidated balance sheet as of March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-21-000014:notes:93]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2021 (in millions):

[0001262039-21-000014:notes:94]
|  | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 298.8 |  |  | $ | 298.7 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-21-000014:notes:95]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2021, we had $298.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-21-000014:notes:96]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2021, we had $65.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-21-000014:notes:97]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of March 31, 2021 and December 31, 2020.

[0001262039-21-000014:notes:98]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-21-000014:notes:99]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-21-000014:notes:100]
[same as prior period, unchanged from 0001262039-20-000067:notes:111]

[0001262039-21-000014:notes:101]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. As of March 31, 2021, there were a total of 11.4 million shares of common stock available for grant under the Amended Plan.

[0001262039-21-000014:notes:102]
[same as prior period, unchanged from 0001262039-20-000067:notes:114]

[0001262039-21-000014:notes:103]
[same as prior period, unchanged from 0001262039-20-000067:notes:115]

[0001262039-21-000014:notes:104]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2020 | 4.7 |  |  | $ | 90.46 |  |
| Granted | 0.8 |  |  | 172.74 |  |
| Forfeited | (0.1) |  |  | 100.57 |  |
| Vested | (0.8) |  |  | 79.95 |  |
| Balance—March 31, 2021 | 4.6 |  |  | $ | 107.37 |  |

[0001262039-21-000014:notes:105]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of March 31, 2021, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $450.7 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-21-000014:notes:106]
[same as prior period, unchanged from 0001262039-20-000067:notes:118]

[0001262039-21-000014:notes:107]
[same as prior period, unchanged from 0001262039-20-000067:notes:119]

[0001262039-21-000014:notes:108]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Shares withheld for taxes | 0.3 |  |  | 0.3 |  |  |  |  |  |
| Amount withheld for taxes | $ | 41.4 |  |  | $ | 37.8 |  |  |  |  |  |

[0001262039-21-000014:notes:109]
[same as prior period, unchanged from 0001262039-20-000067:notes:121]

[0001262039-21-000014:notes:110]
[same as prior period, unchanged from 0001262039-20-000067:notes:122]

[0001262039-21-000014:notes:111]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Expected term in years | 4.4 |  | 4.4 |  |  |  |  |
| Volatility | 39.5 | % |  | 33.5 | % |  |  |  |  |
| Risk-free interest rate | 0.5 | % |  | 1.3 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-21-000014:notes:112]
[same as prior period, unchanged from 0001262039-20-000067:notes:124]

[0001262039-21-000014:notes:113]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2020 | 2.7 |  |  | $ | 67.53 |  |  | 4.2 |  | 220.4 |  |
| Granted | 0.5 |  |  | 171.93 |  |  |  |  |  |
| Forfeited | — |  |  | 109.16 |  |  |  |  |  |
| Exercised | (0.2) |  |  | 50.36 |  |  |  |  |  |
| Balance—March 31, 2021 | 3.0 |  |  | $ | 85.66 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2021 | 3.0 |  |  | $ | 85.66 |  |  | 4.5 |  | $ | 297.1 |  |
| Options exercisable—March 31, 2021 | 1.5 |  |  | $ | 51.63 |  |  | 3.3 |  | $ | 205.8 |  |

[0001262039-21-000014:notes:114]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2021 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of March 31, 2021, total compensation expense related to unvested stock options granted to employees but not yet recognized was $54.6 million, with a weighted-average remaining vesting period of 3.2 years.

[0001262039-21-000014:notes:115]
[same as prior period, unchanged from 0001262039-20-000067:notes:127]

[0001262039-21-000014:notes:116]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Weighted-average fair value per share granted | $ | 56.49 |  |  | $ | 33.82 |  |  |  |  |  |
| Intrinsic value of options exercised | $ | 22.3 |  |  | $ | 13.1 |  |  |  |  |  |
| Fair value of options vested | $ | 7.0 |  |  | $ | 6.0 |  |  |  |  |  |

[0001262039-21-000014:notes:117]
[same as prior period, unchanged from 0001262039-20-000067:notes:129]

[0001262039-21-000014:notes:118]
[same as prior period, unchanged from 0001262039-20-000067:notes:130]

[0001262039-21-000014:notes:119]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  |  |  |  |
| Cost of service revenue | 3.5 |  |  | 3.0 |  |  |  |  |  |
| Research and development | 13.0 |  |  | 10.9 |  |  |  |  |  |
| Sales and marketing | 26.8 |  |  | 25.7 |  |  |  |  |  |
| General and administrative | 6.3 |  |  | 5.3 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 50.0 |  |  | $ | 45.3 |  |  |  |  |  |

[0001262039-21-000014:notes:120]
[same as prior period, unchanged from 0001262039-20-000067:notes:132]

[0001262039-21-000014:notes:121]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| RSUs | $ | 45.8 |  |  | $ | 42.2 |  |  |  |  |  |
| Stock options | 4.2 |  |  | 3.1 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 50.0 |  |  | $ | 45.3 |  |  |  |  |  |

[0001262039-21-000014:notes:122]
[same as prior period, unchanged from 0001262039-20-000067:notes:134]

[0001262039-21-000014:notes:123]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 11.0 |  |  | $ | 10.0 |  |  |  |  |  |

[0001262039-21-000014:notes:124]
[same as prior period, unchanged from 0001262039-20-000067:notes:136]

[0001262039-21-000014:notes:125]
[same as prior period, unchanged from 0001262039-20-000067:notes:137]

[0001262039-21-000014:notes:126]
There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2021. As of March 31, 2021, $1.01 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-21-000014:notes:127]
INCOME TAXES 
Our effective tax rate was 10% for the three months ended March 31, 2021, compared to an effective tax rate of 11% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes, the tax benefit from foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended March 31, 2021 and 2020 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $35.7 million and $33.3 million, respectively. The tax rate for the three months ended March 31, 2021 was impacted by a tax benefit of $7.3 million from the FDII deduction and by excess tax benefits from stock-based compensation expense of $16.2 million. The tax rate for the three months ended March 31, 2020 was impacted by a tax benefit of $4.8 million from the FDII deduction and excess tax benefits from stock-based compensation expense of $15.2 million.

[0001262039-21-000014:notes:128]
As of March 31, 2021 and December 31, 2020, unrecognized tax benefits were $81.6 million and $77.3 million, respectively. If recognized, $74.6 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of March 31, 2021 and December 31, 2020, accrued interest and penalties were $16.0 million and $14.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $4.4 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-21-000014:notes:129]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.
The Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law on March 27, 2020. The CARES Act provides numerous tax provisions and other stimulus measures, including temporary changes regarding the prior and future utilization of net operating losses, temporary changes to the prior and future limitations on interest deductions, temporary suspension of certain payment requirements for the employer portion of Social Security taxes, technical corrections from prior tax legislation for tax depreciation of certain qualified improvement property and the creation of certain refundable employee retention credits. There is no material tax impact on our condensed consolidated financial statements.On July 9, 2020, the United States Department of the Treasury (the “U.S. Treasury”) and the Internal Revenue Service (the “IRS”) released final Section 250 regulations, providing guidance on the foreign-derived intangible income deduction and the global intangible low-taxed income. Generally, the final regulations are applicable for taxable years beginning on or after January 1, 2021. However, taxpayers may apply the final regulations for taxable years beginning on or after January 1, 2018. We have elected to apply the final regulations to the year ending December 31, 2020 and included the tax impact from the final regulations on our foreign-derived intangible income deduction calculation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-21-000014:notes:130]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2021 and 2020 were $2.7 million and $2.2 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-21-000014:notes:131]
[same as prior period, unchanged from 0001262039-20-000067:notes:148]

[0001262039-21-000014:notes:132]
[same as prior period, unchanged from 0001262039-20-000067:notes:149]

[0001262039-21-000014:notes:133]
|  | Three Months Ended |  |  |
| Revenue | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 212.5 |  |  | $ | 181.9 |  |  |  |  |  |
| Other Americas | 78.4 |  |  | 60.7 |  |  |  |  |  |
| Total Americas | 290.9 |  |  | 242.6 |  |  |  |  |  |
| Europe, Middle East and Africa (“EMEA”) | 275.7 |  |  | 221.0 |  |  |  |  |  |
| Asia Pacific (“APAC”) | 143.7 |  |  | 114.1 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |

[0001262039-21-000014:notes:134]
| Property and Equipment—net | March 31,2021 |  | December 31,2020 |
| Americas: |  |  |  |
| United States | $ | 342.7 |  |  | $ | 296.3 |  |
| Canada | 120.2 |  |  | 121.3 |  |
| Latin America | 2.1 |  |  | 2.0 |  |
| Total Americas | 465.0 |  |  | 419.6 |  |
| EMEA | 22.3 |  |  | 20.6 |  |
| APAC | 6.9 |  |  | 7.8 |  |
| Total property and equipment—net | $ | 494.2 |  |  | $ | 448.0 |  |

[0001262039-21-000014:notes:135]
[same as prior period, unchanged from 0001262039-20-000067:notes:152]

[0001262039-21-000014:notes:136]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Exclusive Networks Group (“Exclusive”) | 32 | % |  | 31 | % |  |  |  |  |
| Ingram Micro, Inc. (“Ingram Micro”) | 11 | % |  | 10 | % |  |  |  |  |

[0001262039-21-000014:notes:137]
[same as prior period, unchanged from 0001262039-20-000067:notes:154]

[0001262039-21-000014:notes:138]
|  | March 31,2021 |  | December 31,2020 |
| Exclusive | 31 | % |  | 34 | % |
| Ingram Micro | 16 | % |  | 11 | % |
