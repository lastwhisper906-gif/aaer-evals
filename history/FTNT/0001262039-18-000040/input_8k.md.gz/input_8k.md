# FTNT 8-K — 0001262039-18-000037 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-07

- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2018-11-07

- none on or before 2018-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-18-000037:8k_2_02:1]
EX-99.1
2
ftntq3-2018ex991.htm
PRESS RELEASE

[0001262039-18-000037:8k_2_02:2]
Exhibit

[0001262039-18-000037:8k_2_02:3]
.

[0001262039-18-000037:8k_2_02:4]
Press Release

[0001262039-18-000037:8k_2_02:5]
Fortinet Reports Third Quarter 2018 Financial Results

[0001262039-18-000037:8k_2_02:6]
Security Fabric Platform Drives Strong Year-Over-Year Growth in Third Quarter 2018 Billings, Revenue and Operating Margin

[0001262039-18-000037:8k_2_02:7]
Third Quarter 2018 Financial Highlights

[0001262039-18-000037:8k_2_02:8]
| • | Revenue of $453.9 million, up 21% year over year |

[0001262039-18-000037:8k_2_02:9]
| • | Product revenue of $164.5 million, up 20% year over year |

[0001262039-18-000037:8k_2_02:10]
| • | Billings of $527.5 million, up 22% year over year1 |

[0001262039-18-000037:8k_2_02:11]
| • | Deferred revenue of $1.54 billion, up 27% year over year |

[0001262039-18-000037:8k_2_02:12]
| • | GAAP operating margin of 14% |

[0001262039-18-000037:8k_2_02:13]
| • | Non-GAAP operating margin of 24%1 |

[0001262039-18-000037:8k_2_02:14]
| • | Cash flow from operations of $176.7 million |

[0001262039-18-000037:8k_2_02:15]
| • | Free cash flow of $158.5 million1 |

[0001262039-18-000037:8k_2_02:16]
SUNNYVALE, Calif. - November 1, 2018 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the third quarter ended September 30, 2018.

[0001262039-18-000037:8k_2_02:17]
“We delivered strong third quarter financial results. Our market share gains are being driven by the competitive advantages associated with our highly differentiated Security Fabric platform,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “Organically built from the ground up, our Security Fabric platform provides a broad set of security capabilities with exceptional integration and automation, for both on-premise and cloud deployment. Fortinet is well positioned to empower our customers with the latest evolution in network security and we are excited about the sizable opportunities that lie ahead."

[0001262039-18-000037:8k_2_02:18]
Recent Highlights

[0001262039-18-000037:8k_2_02:19]
| • | Gartner Magic Quadrants: Fortinet has recently been recognized in three Gartner Magic Quadrants; as a Leader in the Magic Quadrant for Enterprise Network Firewalls for the second time, as a Leader in the Magic Quadrant for Unified Threat Management (SMB Multifunction Firewalls) for the ninth time, and is positioned furthest for completeness of vision in the Challengers quadrant of the first Magic Quadrant for WAN Edge Infrastructure.* Fortinet has appeared in seven Gartner Magic Quadrants* over the last twelve months. |

[0001262039-18-000037:8k_2_02:20]
| • | Gartner Peer Insights Customers’ Choice: Fortinet has also been recognized as a 2018 Gartner Peer Insights Customers’ Choice for Enterprise Network Firewalls and a 2018 Gartner Peer Insights Customers’ Choice for Unified Threat Management.** |

[0001262039-18-000037:8k_2_02:21]
| • | NSS Labs SD-WAN Recommendation: Fortinet was the only vendor with security capabilities to receive an SD-WAN "Recommended" rating in the first NSS Labs Software-Defined Wide Area Networking test report. |

[0001262039-18-000037:8k_2_02:22]
| • | NSS Labs Additional Recommendations: The FortiGate Next-Generation Firewall received a fifth consecutive “Recommended” rating in the NSS Labs NGFW report, delivering high SSL performance suited for encrypted cloud access. Fortinet is the only vendor to have received NSS Labs Recommended ratings in both the SD-WAN and Next-Generation Firewall group tests. Fortinet’s commitment to third party testing and validation has resulted in Fortinet solutions earning NSS Labs Recommended ratings across nine different group tests. |

[0001262039-18-000037:8k_2_02:23]
| • | ZoneFox Acquisition: In October, Fortinet acquired ZoneFox, further enhancing Fortinet's Security Fabric platform and strengthening its existing endpoint and SIEM security business. By adding ZoneFox’s cloud-based threat-hunting technology, Fortinet is well positioned to provide its customers with an integrated approach to defend against insider threats, eliminate blind spots and protect today’s expanding attack surface with automation and machine learning. |

[0001262039-18-000037:8k_2_02:24]
Financial Highlights

[0001262039-18-000037:8k_2_02:25]
| • | Revenue: Total revenue was $453.9 million for the third quarter of 2018, an increase of 21% compared to $374.2 million in the same quarter of 2017. |

[0001262039-18-000037:8k_2_02:26]
| • | Product Revenue: Product revenue was $164.5 million for the third quarter of 2018, an increase of 20% compared to $137.1 million in the same quarter of 2017. |

[0001262039-18-000037:8k_2_02:27]
| • | Service Revenue: Service revenue was $289.4 million for the third quarter of 2018, an increase of 22% compared to $237.1 million in the same quarter of 2017. |

[0001262039-18-000037:8k_2_02:28]
| • | Billings1: Total billings were $527.5 million for the third quarter of 2018, an increase of 22% compared to $431.7 million in the same quarter of 2017. |

[0001262039-18-000037:8k_2_02:29]
| • | Deferred Revenue: Total deferred revenue was $1.54 billion as of September 30, 2018, an increase of 27% compared to $1.22 billion as of September 30, 2017. |

[0001262039-18-000037:8k_2_02:30]
| • | GAAP Operating Income and Margin: GAAP operating income was $62.8 million for the third quarter of 2018, representing a GAAP operating margin of 14%. GAAP operating income was $33.7 million for the same quarter of 2017, representing a GAAP operating margin of 9%. |

[0001262039-18-000037:8k_2_02:31]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $108.5 million for the third quarter of 2018, representing a non-GAAP operating margin of 24%. Non-GAAP operating income was $70.0 million for the third quarter of 2017, representing a non-GAAP operating margin of 19%. |

[0001262039-18-000037:8k_2_02:32]
| • | GAAP Effective Tax Rate: GAAP effective tax rate was 17% in the third quarter of 2018, compared to an effective tax rate of 30% for the same quarter in 2017. |

[0001262039-18-000037:8k_2_02:33]
| • | Non-GAAP Effective Tax Rate: Non-GAAP effective tax rate was 24% in the third quarter of 2018, compared to 32% for the same quarter in 2017. |

[0001262039-18-000037:8k_2_02:34]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $58.7 million for the third quarter of 2018, compared to GAAP net income of $26.7 million for the same quarter of 2017. GAAP diluted net income per share was $0.33 for the third quarter of 2018, based on 175.7 million diluted weighted-average shares outstanding, compared to $0.15 for the same quarter of 2017, based on 179.0 million diluted weighted-average shares outstanding. |

[0001262039-18-000037:8k_2_02:35]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $86.7 million for the third quarter of 2018, compared to non-GAAP net income of $50.6 million for the same quarter of 2017. Non-GAAP diluted net income per share was $0.49 for the third quarter of 2018, based on 175.7 million diluted weighted-average shares outstanding, compared to $0.28 for the same quarter of 2017, based on 179.0 million diluted weighted-average shares outstanding. |

[0001262039-18-000037:8k_2_02:36]
| • | Cash Flow From Operations and Free Cash Flow1: In the third quarter of 2018, cash flow from operations was $176.7 million, compared to $162.3 million in the same quarter of 2017. Free cash flow1 was $158.5 million during the third quarter of 2018, compared to $140.6 million in the same quarter of 2017. |

[0001262039-18-000037:8k_2_02:37]
Guidance

[0001262039-18-000037:8k_2_02:38]
For the fourth quarter of 2018, Fortinet currently expects:

[0001262039-18-000037:8k_2_02:39]
| • | Revenue in the range of $490.0 million to $500.0 million |

[0001262039-18-000037:8k_2_02:40]
| • | Billings in the range of $620.0 million to $635.0 million |

[0001262039-18-000037:8k_2_02:41]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000037:8k_2_02:42]
| • | Non-GAAP operating margin in the range of 24.0% to 24.5%, including a benefit associated with the adoption of ASC 606 of approximately 250 basis points |

[0001262039-18-000037:8k_2_02:43]
| • | Diluted non-GAAP earnings per share in the range of $0.50 to $0.52, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 178 million to 179 million |

[0001262039-18-000037:8k_2_02:44]
For the fiscal year of 2018, Fortinet currently expects:

[0001262039-18-000037:8k_2_02:45]
| • | Revenue in the range of $1.785 billion to $1.795 billion |

[0001262039-18-000037:8k_2_02:46]
| • | Billings in the range of $2.125 billion to $2.140 billion |

[0001262039-18-000037:8k_2_02:47]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000037:8k_2_02:48]
| • | Non-GAAP operating margin in the range of 21.5% to 22.0%, including a benefit associated with the adoption of ASC 606 of approximately 300 basis points |

[0001262039-18-000037:8k_2_02:49]
| • | Diluted non-GAAP earnings per share in the range of $1.72 to $1.76, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 174 million to 176 million |

[0001262039-18-000037:8k_2_02:50]
The above guidance for the fourth quarter and full year of 2018 includes the transition impact of ASC 606 adoption, which was effective January 1, 2018. Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-18-000037:8k_2_02:51]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-18-000037:8k_2_02:52]
Conference Call Details

[0001262039-18-000037:8k_2_02:53]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 4694837. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through November 8, 2018, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 4694837.

[0001262039-18-000037:8k_2_02:54]
Fourth Quarter 2018 Investor Conference Participation Schedule:

[0001262039-18-000037:8k_2_02:55]
| • | UBS Global Technology Conference |

[0001262039-18-000037:8k_2_02:56]
November 12, 2018 - San Francisco, CA

[0001262039-18-000037:8k_2_02:57]
| • | Nasdaq 39th Investor Conference |

[0001262039-18-000037:8k_2_02:58]
December 4, 2018 - London, UK

[0001262039-18-000037:8k_2_02:59]
| • | Barclays' Global Technology, Media, and Telecommunications Conference |

[0001262039-18-000037:8k_2_02:60]
December 6, 2018 - San Francisco, CA

[0001262039-18-000037:8k_2_02:61]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-18-000037:8k_2_02:62]
*Sources: Magic Quadrant for Enterprise Network Firewalls, Adam Hils | Jeremy D'Hoinne | Rajpreet Kaur, 4 October 2018, Magic Quadrant for Endpoint Protection Platforms, Ian McShane | Avivah Litan | Eric Ouellet | Prateek Bhajanka, 24 January 2018, Magic Quadrant for Security Information and Event Management, Kelly Kavanagh | Toby Bussa, 4 December 2017, Magic Quadrant for Unified Threat Management (SMB Multifunction Firewalls), Rajpreet Kaur | Claudio Neiva, 20 September 2018, Magic Quadrant for Web Application Firewalls, Jeremy D'Hoinne | Adam Hils | Ayal Tirosh | Claudio Neiva, 29 August 2018, and Magic Quadrant for Wired & Wireless LAN Access Infrastructure, Bill Menezes | Christian Canales | Tim Zimmerman | Mike Toussaint, 11 July 2018, Magic Quadrant for WAN Edge infrastructure, Joe Skorupa | Andrew Lerner | Christian Canales | Mike Toussaint, 18 October 2018.

[0001262039-18-000037:8k_2_02:63]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-18-000037:8k_2_02:64]
**Gartner Peer Insights Customers’ Choice constitute the subjective opinions of individual end-user reviews, ratings, and data applied against a documented methodology; they neither represent the views of, nor constitute an endorsement by, Gartner or its affiliates.

[0001262039-18-000037:8k_2_02:65]
About Fortinet (www.fortinet.com)

[0001262039-18-000037:8k_2_02:66]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-18-000037:8k_2_02:67]
#          #          #

[0001262039-18-000037:8k_2_02:68]
Copyright © 2018 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiCare, FortiManager, FortiAnalyzer, FortiOS, FortiADC, FortiAP, FortiAppMonitor, FortiASIC, FortiAuthenticator, FortiBridge, FortiCache, FortiCamera, FortiCASB, FortiClient, FortiCloud, FortiConnect, FortiController, FortiConverter, FortiDB, FortiDDoS, FortiExplorer, FortiExtender, FortiFone, FortiCarrier, FortiHypervisor, FortiIsolator, FortiMail, FortiMonitor, FortiNAC, FortiPlanner, FortiPortal, FortiPresence , FortiProxy, FortiRecorder, FortiSandbox, FortiSIEM, FortiSwitch, FortiTester, FortiToken, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-18-000037:8k_2_02:69]
FTNT-F

[0001262039-18-000037:8k_2_02:70]
Forward-looking Statements

[0001262039-18-000037:8k_2_02:71]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the opportunities ahead, Fortinet’s position to empower customers and our position for future growth, our position to provide our customers the best network security, our ability to continue to grow our market position and address our market opportunity, our position to provide customers with an integrated approach to defend customers and the expected benefits of the ZoneFox acquisition,

[0001262039-18-000037:8k_2_02:72]
and all guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic

[0001262039-18-000037:8k_2_02:73]
risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its product and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith;

[0001262039-18-000037:8k_2_02:74]
Non-GAAP Financial Measures

[0001262039-18-000037:8k_2_02:75]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-18-000037:8k_2_02:76]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-18-000037:8k_2_02:77]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-18-000037:8k_2_02:78]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-18-000037:8k_2_02:79]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-18-000037:8k_2_02:80]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on sale of investments in privately held companies as well as impairment, and a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-18-000037:8k_2_02:81]
FORTINET, INC.

[0001262039-18-000037:8k_2_02:82]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-18-000037:8k_2_02:83]
(Unaudited, in millions)

[0001262039-18-000037:8k_2_02:84]
|  | September 30, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,169.3 |  |  | $ | 811.0 |  |
| Short-term investments | 464.9 |  |  | 440.3 |  |
| Accounts receivable—net | 324.4 |  |  | 348.2 |  |
| Inventory | 80.8 |  |  | 77.3 |  |
| Prepaid expenses and other current assets | 38.7 |  |  | 40.0 |  |
| Total current assets | 2,078.1 |  |  | 1,716.8 |  |
| LONG-TERM INVESTMENTS | 38.6 |  |  | 98.0 |  |
| PROPERTY AND EQUIPMENT—NET | 265.4 |  |  | 245.4 |  |
| DEFERRED CONTRACT COSTS | 169.6 |  |  | — |  |
| DEFERRED TAX ASSETS | 147.8 |  |  | 146.9 |  |
| OTHER INTANGIBLE ASSETS—NET | 18.1 |  |  | 16.3 |  |
| GOODWILL | 25.7 |  |  | 14.6 |  |
| OTHER ASSETS | 20.2 |  |  | 19.9 |  |
| TOTAL ASSETS | $ | 2,763.5 |  |  | $ | 2,257.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 66.6 |  |  | $ | 70.0 |  |
| Accrued liabilities | 60.7 |  |  | 50.0 |  |
| Accrued payroll and compensation | 85.4 |  |  | 92.0 |  |
| Income taxes payable | 23.0 |  |  | 21.4 |  |
| Deferred revenue | 876.2 |  |  | 793.8 |  |
| Total current liabilities | 1,111.9 |  |  | 1,027.2 |  |
| DEFERRED REVENUE | 668.2 |  |  | 542.5 |  |
| INCOME TAX LIABILITIES | 80.7 |  |  | 90.2 |  |
| OTHER LIABILITIES | 11.1 |  |  | 8.6 |  |
| Total liabilities | 1,871.9 |  |  | 1,668.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,048.4 |  |  | 909.6 |  |
| Accumulated other comprehensive loss | (1.0 | ) |  | (0.8 | ) |
| Accumulated deficit | (156.0 | ) |  | (319.6 | ) |
| Total stockholders’ equity | 891.6 |  |  | 589.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,763.5 |  |  | $ | 2,257.9 |  |

[0001262039-18-000037:8k_2_02:85]
FORTINET, INC.

[0001262039-18-000037:8k_2_02:86]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-18-000037:8k_2_02:87]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000037:8k_2_02:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | 453.9 |  |  | 374.2 |  |  | 1,294.2 |  |  | 1,078.3 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 72.0 |  |  | 58.1 |  |  | 204.1 |  |  | 174.2 |  |
| Service 1 | 39.6 |  |  | 35.5 |  |  | 117.8 |  |  | 105.7 |  |
| Total cost of revenue | 111.6 |  |  | 93.6 |  |  | 321.9 |  |  | 279.9 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 92.5 |  |  | 79.0 |  |  | 269.5 |  |  | 240.9 |  |
| Service | 249.8 |  |  | 201.6 |  |  | 702.8 |  |  | 557.5 |  |
| Total gross profit | 342.3 |  |  | 280.6 |  |  | 972.3 |  |  | 798.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 58.7 |  |  | 53.5 |  |  | 179.0 |  |  | 155.9 |  |
| Sales and marketing 1 | 198.3 |  |  | 172.4 |  |  | 576.4 |  |  | 509.1 |  |
| General and administrative 1 | 22.5 |  |  | 21.0 |  |  | 71.0 |  |  | 65.5 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Total operating expenses | 279.5 |  |  | 246.9 |  |  | 826.4 |  |  | 730.8 |  |
| OPERATING INCOME | 62.8 |  |  | 33.7 |  |  | 145.9 |  |  | 67.6 |  |
| INTEREST INCOME—NET | 6.9 |  |  | 3.9 |  |  | 17.2 |  |  | 9.5 |  |
| OTHER INCOME (EXPENSE)—NET | 0.9 |  |  | 0.4 |  |  | (4.3 | ) |  | 1.9 |  |
| INCOME BEFORE INCOME TAXES | 70.6 |  |  | 38.0 |  |  | 158.8 |  |  | 79.0 |  |
| PROVISION FOR INCOME TAXES | 11.9 |  |  | 11.3 |  |  | 9.2 |  |  | 18.6 |  |
| NET INCOME | $ | 58.7 |  |  | $ | 26.7 |  |  | $ | 149.6 |  |  | $ | 60.4 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.15 |  |  | $ | 0.89 |  |  | $ | 0.34 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 0.86 |  |  | $ | 0.34 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 169.8 |  |  | 175.5 |  |  | 168.7 |  |  | 175.3 |  |
| Diluted | 175.7 |  |  | 179.0 |  |  | 173.7 |  |  | 179.0 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |  | $ | 1.0 |  |
| Cost of service revenue | 2.8 |  |  | 2.4 |  |  | 8.0 |  |  | 7.2 |  |
| Research and development | 9.3 |  |  | 8.0 |  |  | 26.9 |  |  | 24.1 |  |
| Sales and marketing | 26.0 |  |  | 19.6 |  |  | 70.5 |  |  | 58.4 |  |
| General and administrative | 4.8 |  |  | 4.0 |  |  | 13.8 |  |  | 12.0 |  |
|  | $ | 43.2 |  |  | $ | 34.3 |  |  | $ | 120.3 |  |  | $ | 102.7 |  |

[0001262039-18-000037:8k_2_02:89]
FORTINET, INC.

[0001262039-18-000037:8k_2_02:90]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-18-000037:8k_2_02:91]
(Unaudited, in millions)

[0001262039-18-000037:8k_2_02:92]
|  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 149.6 |  |  | $ | 60.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 120.3 |  |  | 102.7 |  |
| Amortization of deferred contract costs | 66.3 |  |  | — |  |
| Depreciation and amortization | 41.0 |  |  | 41.2 |  |
| Other | (1.7 | ) |  | 3.2 |  |
| Amortization of investment premiums | — |  |  | 2.1 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 38.0 |  |  | 51.4 |  |
| Inventory | (19.0 | ) |  | 17.7 |  |
| Prepaid expenses and other current assets | 1.8 |  |  | (9.6 | ) |
| Deferred contract costs | (98.8 | ) |  | — |  |
| Deferred tax assets | (19.1 | ) |  | (22.1 | ) |
| Other assets | (3.3 | ) |  | (0.4 | ) |
| Accounts payable | (4.9 | ) |  | (16.5 | ) |
| Accrued liabilities | (2.0 | ) |  | 8.0 |  |
| Accrued payroll and compensation | (8.6 | ) |  | (3.5 | ) |
| Other liabilities | (2.8 | ) |  | (3.8 | ) |
| Deferred revenue | 209.9 |  |  | 184.4 |  |
| Income taxes payable | (8.0 | ) |  | 21.7 |  |
| Net cash provided by operating activities | 458.7 |  |  | 436.9 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (405.2 | ) |  | (359.6 | ) |
| Sales of investments | 39.6 |  |  | 10.0 |  |
| Maturities of investments | 405.6 |  |  | 329.1 |  |
| Purchases of property and equipment | (41.4 | ) |  | (121.6 | ) |
| Payments made in connection with business combination, net of cash acquired | (6.0 | ) |  | — |  |
| Net cash used in investing activities | (7.4 | ) |  | (142.1 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (117.1 | ) |  | (124.0 | ) |
| Proceeds from issuance of common stock | 81.6 |  |  | 61.9 |  |
| Taxes paid related to net share settlement of equity awards | (48.0 | ) |  | (35.9 | ) |
| Payments of debt assumed in connection with business combination | (9.5 | ) |  | — |  |
| Net cash used in financing activities | (93.0 | ) |  | (98.0 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 358.3 |  |  | 196.8 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 811.0 |  |  | 709.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,169.3 |  |  | $ | 905.8 |  |

[0001262039-18-000037:8k_2_02:93]
New Revenue Recognition Standard (ASC 606) Adoption Financial Impact1

[0001262039-18-000037:8k_2_02:94]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000037:8k_2_02:95]
|  | Three Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 164.5 |  |  | $ | 162.3 |  |  | $ | 2.2 |  |
| Service | 289.4 |  |  | 289.6 |  |  | (0.2 | ) |
| Total revenue | 453.9 |  |  | 451.9 |  |  | 2.0 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 72.0 |  |  | 72.3 |  |  | (0.3 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.5 |  |  | 90.0 |  |  | 2.5 |  |
| Service | 249.8 |  |  | 250.0 |  |  | (0.2 | ) |
| Total gross profit | 342.3 |  |  | 340.0 |  |  | 2.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 198.3 |  |  | 207.3 |  |  | (9.0 | ) |
| OPERATING INCOME | 62.8 |  |  | 51.5 |  |  | 11.3 |  |
| INCOME BEFORE INCOME TAXES | 70.6 |  |  | 59.3 |  |  | 11.3 |  |
| PROVISION FOR INCOME TAXES | 11.9 |  |  | 9.8 |  |  | 2.1 |  |
| NET INCOME | $ | 58.7 |  |  | $ | 49.5 |  |  | $ | 9.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.05 |  |

[0001262039-18-000037:8k_2_02:96]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 473.6 |  |  | $ | 461.5 |  |  | $ | 12.1 |  |
| Service | 820.6 |  |  | 819.1 |  |  | 1.5 |  |
| Total revenue | 1,294.2 |  |  | 1,280.6 |  |  | 13.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 204.1 |  |  | 203.1 |  |  | 1.0 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 269.5 |  |  | 258.4 |  |  | 11.1 |  |
| Service | 702.8 |  |  | 701.3 |  |  | 1.5 |  |
| Total gross profit | 972.3 |  |  | 959.7 |  |  | 12.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 576.4 |  |  | 608.9 |  |  | (32.5 | ) |
| OPERATING INCOME | 145.9 |  |  | 100.8 |  |  | 45.1 |  |
| INCOME BEFORE INCOME TAXES | 158.8 |  |  | 113.7 |  |  | 45.1 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 9.2 |  |  | (0.7 | ) |  | 9.9 |  |
| NET INCOME | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.68 |  |  | $ | 0.21 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.66 |  |  | $ | 0.20 |  |
| 1 The tables above do not represent the full condensed consolidated statement of operations as they only present the accounts impacted by the adoption of ASC 606. |

[0001262039-18-000037:8k_2_02:97]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-18-000037:8k_2_02:98]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000037:8k_2_02:99]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-18-000037:8k_2_02:100]
|  | Three Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
| Net cash provided by operating activities | $ | 176.7 |  |  | $ | 162.3 |  |
| Less: Purchases of property and equipment | (18.2 | ) |  | (21.7 | ) |
| Free cash flow | $ | 158.5 |  |  | $ | 140.6 |  |
| Net cash provided by (used in) investing activities | $ | 11.1 |  |  | $ | (28.9 | ) |
| Net cash provided by (used in) financing activities | $ | 9.4 |  |  | $ | (80.8 | ) |

[0001262039-18-000037:8k_2_02:101]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-18-000037:8k_2_02:102]
|  | Three Months Ended September 30, 2018 |  | Three Months Ended September 30, 2017 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 62.8 |  |  | $ | 45.7 |  | (a) | $ | 108.5 |  |  | $ | 33.7 |  |  | $ | 36.3 |  | (b) | $ | 70.0 |  |
| Operating margin | 14 | % |  |  |  | 24 | % |  | 9 | % |  |  |  | 19 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 43.2 |  |  |  |  |  |  | 34.3 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.5 |  |  |  |  |  |  | 2.0 |  |  |  |
| Operating income |  |  | 45.7 |  |  |  |  |  |  | 36.3 |  |  |  |
| Gain on sale of investment in privately-held company |  |  | (2.2 | ) | (c) |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (15.5 | ) | (d) |  |  |  |  | (12.4 | ) | (d) |  |
| Net income | $ | 58.7 |  |  | $ | 28.0 |  |  | $ | 86.7 |  |  | $ | 26.7 |  |  | $ | 23.9 |  |  | $ | 50.6 |  |
| Diluted net income per share | $ | 0.33 |  |  |  |  | $ | 0.49 |  |  | $ | 0.15 |  |  |  |  | $ | 0.28 |  |
| Shares used in diluted net income per share calculations | 175.7 |  |  |  |  | 175.7 |  |  | 179.0 |  |  |  |  | 179.0 |  |

[0001262039-18-000037:8k_2_02:103]
(a) To exclude $43.2 million of stock-based compensation and $2.5 million of amortization of acquired intangible assets in the three months ended September 30, 2018.

[0001262039-18-000037:8k_2_02:104]
(b) To exclude $34.3 million of stock-based compensation and $2.0 million of amortization of acquired intangible assets in the three months ended September 30, 2017.

[0001262039-18-000037:8k_2_02:105]
(c) To exclude $2.2 million of gain on sale of investment in privately-held company.

[0001262039-18-000037:8k_2_02:106]
(d)  Non-GAAP financial information is adjusted to achieve an overall effective tax rate of 24% and 32% in 2018 and 2017, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-18-000037:8k_2_02:107]
Reconciliation of total revenue to total billings

[0001262039-18-000037:8k_2_02:108]
|  | Three Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |
| Add: Change in deferred revenue | 73.6 |  |  | 57.5 |  |
| Total billings | $ | 527.5 |  |  | $ | 431.7 |  |

[0001262039-18-000037:8k_2_02:109]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
