# FTNT MD&A — 0001262039-18-000040


## mdna

[0001262039-18-000040:mdna:1]
[same as prior period, unchanged from 0001262039-18-000029:mdna:1]

[0001262039-18-000040:mdna:2]
[same as prior period, unchanged from 0001262039-18-000029:mdna:2]

[0001262039-18-000040:mdna:3]
[same as prior period, unchanged from 0001262039-18-000029:mdna:3]

[0001262039-18-000040:mdna:4]
[same as prior period, unchanged from 0001262039-18-000029:mdna:4]

[0001262039-18-000040:mdna:5]
[same as prior period, unchanged from 0001262039-18-000029:mdna:5]

[0001262039-18-000040:mdna:6]
[same as prior period, unchanged from 0001262039-18-000029:mdna:6]

[0001262039-18-000040:mdna:7]
[same as prior period, unchanged from 0001262039-18-000029:mdna:7]

[0001262039-18-000040:mdna:8]
[same as prior period, unchanged from 0001262039-18-000029:mdna:8]

[0001262039-18-000040:mdna:9]
[same as prior period, unchanged from 0001262039-18-000029:mdna:9]

[0001262039-18-000040:mdna:10]
[same as prior period, unchanged from 0001262039-18-000029:mdna:10]

[0001262039-18-000040:mdna:11]
[same as prior period, unchanged from 0001262039-18-000029:mdna:11]

[0001262039-18-000040:mdna:12]
[same as prior period, unchanged from 0001262039-18-000029:mdna:12]

[0001262039-18-000040:mdna:13]
[same as prior period, unchanged from 0001262039-18-000029:mdna:13]

[0001262039-18-000040:mdna:14]
[same as prior period, unchanged from 0001262039-18-000029:mdna:14]

[0001262039-18-000040:mdna:15]
| • | the impact of the 2017 Tax Act; |

[0001262039-18-000040:mdna:16]
[same as prior period, unchanged from 0001262039-18-000029:mdna:16]

[0001262039-18-000040:mdna:17]
[same as prior period, unchanged from 0001262039-18-000029:mdna:17]

[0001262039-18-000040:mdna:18]
| • | our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-18-000040:mdna:19]
[same as prior period, unchanged from 0001262039-18-000029:mdna:19]

[0001262039-18-000040:mdna:20]
[same as prior period, unchanged from 0001262039-18-000029:mdna:20]

[0001262039-18-000040:mdna:21]
[same as prior period, unchanged from 0001262039-18-000029:mdna:21]

[0001262039-18-000040:mdna:22]
Fortinet is a global leader in cybersecurity solutions to a wide variety of businesses, such as enterprises, communication service providers and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated Security Fabric Platform with automated protection, detection and response. We have four focus areas for our business.

[0001262039-18-000040:mdna:23]
| • | Network Security - We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, SSL data leak prevention, VPN, switch and wireless controller, and WAN acceleration, among others. Our network security appliances include our FortiOS operating system, which provides the foundation for FortiGate security functions and FortiSPU, which is designed to enhance the security processing capabilities. Our customers may also purchase FortiGuard subscription services to access threat intelligence updates. We provide standard technical support across all our products through our FortiCare support services. |

[0001262039-18-000040:mdna:24]
| • | Fortinet Security Fabric - The Fortinet Security Fabric, which is one of the fastest growing areas of our business, provides enterprise organizations with unified security across the entire digital attack surface, including network core, endpoints, applications, data centers, access and private and public cloud. Together with our network of 47 Fabric Partners, it enables disparate security devices to work together as an integrated and collaborative whole. |

[0001262039-18-000040:mdna:25]
| • | Cloud Security - We help customers secure their cloud environments in part by offering security through our virtual firewall and other software products in public cloud environments. Our FortiCASB extends the core capabilities of our Security Fabric Platform to provide businesses the same level of cybersecurity and threat intelligence in cloud environments as they receive on their physical networks. We experienced significant billings growth in on-demand cloud consumption and bring-your-own-license (“BYOL”), although not yet significant when compared to the rest of our business. The Fortinet cloud security is available across all major cloud providers, including Microsoft Azure, Amazon Web Services, Google Cloud, Oracle Cloud and IBM Cloud. We believe this area provides opportunity for growth. |

[0001262039-18-000040:mdna:26]
[same as prior period, unchanged from 0001262039-18-000029:mdna:27]

[0001262039-18-000040:mdna:27]
[same as prior period, unchanged from 0001262039-18-000029:mdna:28]

[0001262039-18-000040:mdna:28]
| • | We recorded total revenue of $453.9 million and $1.29 billion in the three and nine months ended September 30, 2018, an increase of 21% and 20%, respectively, compared to $374.2 million and $1.08 billion in the same periods last year. Product revenue was $164.5 million and $473.6 million in the three and nine months ended September 30, 2018, an increase of 20% and 14%, respectively, compared to $137.1 million and $415.1 million in the same periods last year. Service revenue was $289.4 million and $820.6 million, respectively, in the three and nine months ended September 30, 2018, an increase of 22% and 24%, respectively, compared to $237.1 million and $663.2 million in the same period last year. |

[0001262039-18-000040:mdna:29]
| • | We generated operating income of $62.8 million and $145.9 million in the three and nine months ended September 30, 2018, an increase of 86% and 116%, respectively, compared to $33.7 million and $67.6 million in the same periods last year. |

[0001262039-18-000040:mdna:30]
29

[0001262039-18-000040:mdna:31]
| • | Cash, cash equivalents and investments were $1.67 billion as of September 30, 2018, an increase of $323.5 million, or 24%, from December 31, 2017. |

[0001262039-18-000040:mdna:32]
| • | Deferred revenue was $1.54 billion as of September 30, 2018, an increase of $208.1 million, or 16%, from December 31, 2017. |

[0001262039-18-000040:mdna:33]
| • | We generated cash flows from operating activities of $458.7 million in the nine months ended September 30, 2018, an increase of $21.8 million, or 5%, compared to the same periods last year. |

[0001262039-18-000040:mdna:34]
| • | During the nine months ended September 30, 2018, we repurchased 2.5 million shares of common stock under the Repurchase Program for an aggregate purchase price of $117.1 million. |

[0001262039-18-000040:mdna:35]
During the three and nine months ended September 30, 2018, our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 20% and 14% in the three and nine months ended September 30, 2018, respectively. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, also grew significantly. Service revenue growth of 22% and 24% in the three and nine months ended September 30, 2018, respectively, was driven by the strength of our FortiCare technical support growing 26% and 30%, respectively, and FortiGuard and other security subscription revenue growing 20% for both periods.

[0001262039-18-000040:mdna:36]
The percentage of our FortiGate-related billings from entry-level products increased from 30% in the three months ended September 30, 2017 to 31% in the three months ended September 30, 2018. The percentage of our FortiGate-related billings from mid-range products increased from 29% in the three months ended September 30, 2017 to 33% in the three months ended September 30, 2018. The percentage of our FortiGate-related billings from high-end products decreased to 36% in the three months ended September 30, 2018 from 41% in the same period last year. We continue to see our enterprise customers purchasing a fairly balanced mix of products across these product groups.

[0001262039-18-000040:mdna:37]
During the three and nine months ended September 30, 2018, operating expenses as a percentage of revenue decreased by four percentage points in both periods, compared to the same periods last year. While both research and development and general and administrative expenses as a percentage of revenue, the decrease was primarily driven by a reduction in sales and marketing expenses as a percentage of revenue, as a result of the adoption of Topic 606 for deferred contract costs, which reduced our commissions expense in absolute dollars and as a percentage of total revenue. Our sales and marketing expenses included a benefit of $9.0 million and $32.5 million in the three and nine months ended September 30, 2018, respectively, from the adoption of Topic 606 related to deferred contract costs. Under Topic 606, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of Topic 606, we expensed the commission related to these service contracts upfront. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been comparable in the three and nine months ended September 30, 2018 compared to the same periods last year. Refer to Note 1 and Note 2 in our notes to the condensed consolidated financial statement for more information. Headcount increased by 3% to 5,639 employees and contractors as of September 30, 2018, up from 5,462 as of June 30, 2018.

[0001262039-18-000040:mdna:38]
[same as prior period, unchanged from 0001262039-18-000029:mdna:39]

[0001262039-18-000040:mdna:39]
Our sales strategy is based on a distribution model whereby we primarily sell our hardware, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across all major cloud providers, and have recognized on demand revenue and BYOL revenue from Amazon Web Services, Microsoft Azure, Oracle Cloud, and Google Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us and deploys the software in a cloud provider’s environment. While the revenue from such sales are relatively insignificant, they have increased significantly in recent periods on a percentage basis.

[0001262039-18-000040:mdna:40]
Typically, our customers purchase our hardware products and software licenses as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis.

[0001262039-18-000040:mdna:41]
[same as prior period, unchanged from 0001262039-18-000029:mdna:31]

[0001262039-18-000040:mdna:42]
Our Security Processing Unit (“SPU”) hardware architecture is an important part of our approach to network security. The SPU includes three lines of proprietary ASICs, content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, our ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-18-000040:mdna:43]
[same as prior period, unchanged from 0001262039-18-000029:mdna:43]

[0001262039-18-000040:mdna:44]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss our cash, cash equivalents and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table (in millions):

[0001262039-18-000040:mdna:45]
|  | Three Months Ended Or As Of |
|  | September 30, 2018 |  | September 30, 2017 |
| Revenue | $ | 453.9 |  |  | $ | 374.2 |  |
| Deferred revenue | $ | 1,544.4 |  |  | $ | 1,219.0 |  |
| Billings (non-GAAP) | $ | 527.5 |  |  | $ | 431.7 |  |
| Net cash provided by operating activities | $ | 176.7 |  |  | $ | 162.3 |  |
| Free cash flow (non-GAAP) | $ | 158.5 |  |  | $ | 140.6 |  |

[0001262039-18-000040:mdna:46]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $1.54 billion as of September 30, 2018, an increase of $208.1 million, or 16%, from December 31, 2017.

[0001262039-18-000040:mdna:47]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $527.5 million for the three months ended September 30, 2018, an increase of 22% compared to $431.7 million in the same period last year.

[0001262039-18-000040:mdna:48]
[same as prior period, unchanged from 0001262039-18-000029:mdna:48]

[0001262039-18-000040:mdna:49]
|  | Three Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
| Billings: |  |  |  |
| Revenue | $ | 453.9 |  |  | $ | 374.2 |  |
| Add: Change in deferred revenue | 73.6 |  |  | 57.5 |  |
| Total billings (non-GAAP) | $ | 527.5 |  |  | $ | 431.7 |  |

[0001262039-18-000040:mdna:50]
[same as prior period, unchanged from 0001262039-18-000029:mdna:50]

[0001262039-18-000040:mdna:51]
|  | Three Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 176.7 |  |  | $ | 162.3 |  |
| Less: Purchases of property and equipment | (18.2 | ) |  | (21.7 | ) |
| Free cash flow (non-GAAP) | $ | 158.5 |  |  | $ | 140.6 |  |
| Net cash provided by (used in) investing activities | $ | 11.1 |  |  | $ | (28.9 | ) |
| Net cash used in financing activities | $ | 9.4 |  |  | $ | (80.8 | ) |

[0001262039-18-000040:mdna:52]
[same as prior period, unchanged from 0001262039-18-000029:mdna:52]

[0001262039-18-000040:mdna:53]
[same as prior period, unchanged from 0001262039-18-000029:mdna:53]

[0001262039-18-000040:mdna:54]
We adopted Topic 606 on January 1, 2018 using the modified retrospective method. Refer to Note 2 in the notes to our condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for a discussion of the impact. Other than the adoption of Topic 606, there were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2018, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-18-000040:mdna:55]
[same as prior period, unchanged from 0001262039-18-000029:mdna:55]

[0001262039-18-000040:mdna:56]
[same as prior period, unchanged from 0001262039-18-000029:mdna:56]

[0001262039-18-000040:mdna:57]
[same as prior period, unchanged from 0001262039-18-000029:mdna:57]

[0001262039-18-000040:mdna:58]
Three Months Ended September 30, 2018 and September 30, 2017

[0001262039-18-000040:mdna:59]
[same as prior period, unchanged from 0001262039-18-000029:mdna:59]

[0001262039-18-000040:mdna:60]
|  | Three Months Ended |  |  |  |  |
| September 30, 2018 (1) |  | September 30, 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 164.5 |  |  | 36 | % |  | $ | 137.1 |  |  | 37 | % |  | $ | 27.4 |  |  | 20 | % |
| Service | 289.4 |  |  | 64 |  |  | 237.1 |  |  | 63 |  |  | 52.3 |  |  | 22 |  |
| Total revenue | $ | 453.9 |  |  | 100 | % |  | $ | 374.2 |  |  | 100 | % |  | $ | 79.7 |  |  | 21 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 194.0 |  |  | 43 | % |  | $ | 161.2 |  |  | 43 | % |  | $ | 32.8 |  |  | 20 | % |
| EMEA | 165.4 |  |  | 36 |  |  | 138.3 |  |  | 37 |  |  | 27.1 |  |  | 20 |  |
| APAC | 94.5 |  |  | 21 |  |  | 74.7 |  |  | 20 |  |  | 19.8 |  |  | 27 |  |
| Total revenue | $ | 453.9 |  |  | 100 | % |  | $ | 374.2 |  |  | 100 | % |  | $ | 79.7 |  |  | 21 | % |

[0001262039-18-000040:mdna:61]
(1) Revenue during the three months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000040:mdna:62]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Revenue: |  |  |  |  |  |
| Product | $ | 164.5 |  |  | $ | 162.3 |  |  | $ | 2.2 |  |
| Service | 289.4 |  |  | 289.6 |  |  | (0.2 | ) |
| Total revenue | $ | 453.9 |  |  | $ | 451.9 |  |  | $ | 2.0 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 194.0 |  |  | $ | 192.7 |  |  | $ | 1.3 |  |
| EMEA | 165.4 |  |  | 164.7 |  |  | 0.7 |  |
| APAC | 94.5 |  |  | 94.5 |  |  | — |  |
| Total revenue | $ | 453.9 |  |  | $ | 451.9 |  |  | $ | 2.0 |  |

[0001262039-18-000040:mdna:63]
Total revenue increased by $79.7 million, or 21%, during the three months ended September 30, 2018 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all regions grew both on an absolute dollars and on a percentage basis.

[0001262039-18-000040:mdna:64]
Product revenue increased by $27.4 million, or 20%, during the three months ended September 30, 2018 compared to the same period last year. Product revenue during the three months ended September 30, 2018 included a $2.2 million benefit from the adoption of Topic 606, which primarily relates to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements can now be recognized upfront instead of ratably over the contracted service term. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products also increased significantly. Fortinet Security Fabric was the fastest growing products compared to the remainder of our business. Service revenue increased by $52.3 million, or 22%, during the three months ended September 30, 2018 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-18-000040:mdna:65]
[same as prior period, unchanged from 0001262039-18-000029:mdna:65]

[0001262039-18-000040:mdna:66]
|  | Three Months Ended |  |  |  |  |
| September 30, 2018 (1) |  | September 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 72.0 |  |  | $ | 58.1 |  |  | $ | 13.9 |  |  | 24 | % |
| Service | 39.6 |  |  | 35.5 |  |  | 4.1 |  |  | 12 |  |
| Total cost of revenue | $ | 111.6 |  |  | $ | 93.6 |  |  | $ | 18.0 |  |  | 19 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.2 | % |  | 57.6 | % |  | (1.4 | )% |  |  |
| Service | 86.3 |  |  | 85.0 |  |  | 1.3 |  |  |  |
| Total gross margin | 75.4 | % |  | 75.0 | % |  | 0.4 | % |  |  |

[0001262039-18-000040:mdna:67]
(1) Cost of revenue and gross margin during the three months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000040:mdna:68]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 72.0 |  |  | $ | 72.3 |  |  | $ | (0.3 | ) |
| Service | 39.6 |  |  | 39.6 |  |  | — |  |
| Total cost of revenue | $ | 111.6 |  |  | $ | 111.9 |  |  | $ | (0.3 | ) |
| Gross margin (%): |  |  |  |  |  |
| Product | 56.2 | % |  | 55.5 | % |  | 0.7 | % |
| Service | 86.3 |  |  | 86.3 |  |  | — |  |
| Total gross margin | 75.4 | % |  | 75.2 | % |  | 0.2 | % |

[0001262039-18-000040:mdna:69]
Total gross margin increased by 0.4 percentage points during the three months ended September 30, 2018 compared to the same period last year, driven by revenue mix shift to higher margin service revenue. Service gross margin increased by 1.3 percentage points during the three months ended September 30, 2018 compared to the same period last year, as our FortiCare technical support and FortiGuard and other security subscription revenue grew 26% and 20%, respectively, during the three months ended September 30, 2018 compared to the same period last year, which outpaced the increase in the related personnel costs and headcount growth, resulting in a higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 1.4 percentage points during the three months ended September 30, 2018 compared to the same period last year as we continued to transition to our new product introductions. The decrease was partially offset by increased revenue in higher margin software licenses. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-18-000040:mdna:70]
[same as prior period, unchanged from 0001262039-18-000029:mdna:64]

[0001262039-18-000040:mdna:71]
[same as prior period, unchanged from 0001262039-18-000029:mdna:70]

[0001262039-18-000040:mdna:72]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2018 (1) |  | September 30, 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 58.7 |  |  | 13% |  | $ | 53.5 |  |  | 14 | % |  | $ | 5.2 |  |  | 10 | % |
| Sales and marketing | 198.3 |  |  | 44 |  | 172.4 |  |  | 46 |  |  | 25.9 |  |  | 15 |  |
| General and administrative | 22.5 |  |  | 5 |  | 21.0 |  |  | 6 |  |  | 1.5 |  |  | 7 |  |
| Total operating expenses | $ | 279.5 |  |  | 62% |  | $ | 246.9 |  |  | 66 | % |  | $ | 32.6 |  |  | 13 | % |

[0001262039-18-000040:mdna:73]
(1) Operating expenses during the three months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000040:mdna:74]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 58.7 |  |  | $ | 58.7 |  |  | $ | — |  |
| Sales and marketing expenses | 198.3 |  |  | 207.3 |  |  | (9.0 | ) |
| General and administrative | 22.5 |  |  | 22.5 |  |  | — |  |
| Total operating expenses | $ | 279.5 |  |  | $ | 288.5 |  |  | $ | (9.0 | ) |

[0001262039-18-000040:mdna:75]
[same as prior period, unchanged from 0001262039-18-000029:mdna:74]

[0001262039-18-000040:mdna:76]
Research and development expense increased by $5.2 million, or 10%, during the three months ended September 30, 2018 compared to the same period last year, primarily due to an increase of $6.9 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. The increase in expense was offset by a decrease of $2.1 million in product development expenses, such as third-party testing, prototypes and supplies. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000040:mdna:77]
[same as prior period, unchanged from 0001262039-18-000029:mdna:76]

[0001262039-18-000040:mdna:78]
Sales and marketing expense increased by $25.9 million, or 15%, during the three months ended September 30, 2018 compared to the same period last year, primarily due to an increase of $20.3 million in personnel-related costs, including higher stock-based compensation expense of $6.4 million, as sales and marketing headcount increased in order to drive market share gains globally. The increase in personnel costs was net of a benefit of $9.0 million from the adoption of the new accounting standard related to deferred contract costs. Under this new standard, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commission related to these service contracts. Our sales and marketing expense would have increased by $34.9 million, or 20%, under the prior accounting standard. Refer to Note 2 in our notes to the condensed consolidated financial statement for more information. Marketing-related expense increased by $1.8 million. In addition, depreciation expense and other occupancy-related expense increased by $1.5 million and travel and entertainment expenses increased by $1.3 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 46% of total revenue, which is comparable to the same period last year. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000040:mdna:79]
[same as prior period, unchanged from 0001262039-18-000029:mdna:79]

[0001262039-18-000040:mdna:80]
General and administrative expense increased by $1.5 million, or 7%, during the three months ended September 30, 2018 compared to the same period last year. Personnel costs increased by $1.8 million as we continued to increase headcount in order to support our expanding business. The increase in expense was partially offset by a combined decrease in depreciation and other operating costs of $0.4 million. We expect general and administrative expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000040:mdna:81]
[same as prior period, unchanged from 0001262039-18-000029:mdna:81]

[0001262039-18-000040:mdna:82]
We generated operating income of $62.8 million during the three months ended September 30, 2018, an increase of $29.1 million, or 86%, compared to $33.7 million in the same period last year. The improvement in operating income included benefit from the adoption of the new accounting standard. Operating income as a percentage of total revenue increased to 14% in the three months ended September 30, 2018 from 9% in the same period last year. The increase in operating margin is primarily due to a decrease in sales and marketing expenses to 44% as a percentage of total revenue in the three months ended September 30, 2018 from 46% in the same period last year. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 46% of total revenue. The adoption of this new standard resulted in an improvement of 2.4 percentage points in our operating margin. In addition, the decrease in research and development and general and administrative expenses as a percentage of total revenue, as well as improvement in gross margin, contributed to the improvement in operating margin.

[0001262039-18-000040:mdna:83]
[same as prior period, unchanged from 0001262039-18-000029:mdna:83]

[0001262039-18-000040:mdna:84]
|  | Three Months Ended |  |  |  |  |
| September 30, 2018 |  | September 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 6.9 |  |  | $ | 3.9 |  |  | $ | 3.0 |  |  | 77 | % |
| Other income—net | 0.9 |  |  | 0.4 |  |  | 0.5 |  |  | 125 |  |

[0001262039-18-000040:mdna:85]
Interest income increased during the three months ended September 30, 2018 compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income —net during the three months ended September 30, 2018 compared to the same period last year was primarily due to a $2.2 million gain on sale of an investment in a privately held company, offset by foreign currency exchange losses.

[0001262039-18-000040:mdna:86]
.

[0001262039-18-000040:mdna:87]
Provision for income taxes

[0001262039-18-000040:mdna:88]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2018 (1) |  | September 30, 2017 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 11.9 |  |  | $ | 11.3 |  |  | $ | 0.6 |  |  | 5 | % |
| Effective tax rate (%) | 17 | % |  | 30 | % |  | (13 | )% |  | — |  |

[0001262039-18-000040:mdna:89]
(1) Provision for income taxes during the three months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000040:mdna:90]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Increase (Decrease) |
| Provision for income taxes | $ | 11.9 |  |  | $ | 9.8 |  |  | $ | 2.1 |  |
| Effective tax rate (%) | 17 | % |  | 17 | % |  | — | % |

[0001262039-18-000040:mdna:91]
[same as prior period, unchanged from 0001262039-18-000029:mdna:78]

[0001262039-18-000040:mdna:92]
Our effective tax rate was 17% for the three months ended September 30, 2018 compared to an effective tax rate of 30% for the same period last year, with the primary difference being the change in the federal tax rate to 21% in 2018 from 35% in the prior year. The effective tax rate for the periods presented are comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes of $17.7 million, which were offset by a tax provision benefit of $5.8 million for stock-based compensation. The tax rate for the three months ended September 30, 2017 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $12.7 million which were offset by a tax provision benefit of $1.8 million for stock-based compensation.

[0001262039-18-000040:mdna:93]
[same as prior period, unchanged from 0001262039-18-000029:mdna:92]

[0001262039-18-000040:mdna:94]
[same as prior period, unchanged from 0001262039-18-000029:mdna:93]

[0001262039-18-000040:mdna:95]
The 2017 Tax Act creates a new requirement that global intangible low-taxed income (“GILTI”) earned by controlled foreign corporations (“CFCs”) be included currently in the gross income of the CFCs’ U.S. shareholder. Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the 2017 Tax Act and the application of ASC 740. Under GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. Our selection of an accounting policy for 2018 with respect to the GILTI tax rules was to treat GILTI tax as a current-period expense under the period cost method.

[0001262039-18-000040:mdna:96]
The IRS issued Notice 2018-26 on April 2, 2018, which included allowing a deduction for foreign taxes during 2017 to be allocated to earning and profits calculated as of November 2, 2017. This deduction resulted in a decrease of our transition tax by $3.2 million. We also released unrecognized tax benefits in the first quarter of 2018, which had previously reduced our transition tax. This increased our transition tax by $2.7 million. The net tax provision benefit due to changes in the transition tax calculation was $0.5 million in the first quarter of 2018. We did not make any changes to the transition tax in the third quarter of 2018.

[0001262039-18-000040:mdna:97]
It is our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of September 30, 2018 and December 31, 2017, accrued interest and penalties were $12.2 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $8.0 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000040:mdna:98]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. On August 7, 2018, the Ninth Circuit withdrew the opinions filed July 24, 2018 to allow time for the reconstituted panel to confer on the appeal. In Altera, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. The U.S. Tax Court had invalidated those regulations, in part because the Treasury Department failed to adequately consider significant taxpayer comments when adopting them. We will evaluate the tax impact when the new opinion is released from the Ninth Circuit.

[0001262039-18-000040:mdna:99]
[same as prior period, unchanged from 0001262039-18-000029:mdna:90]

[0001262039-18-000040:mdna:100]
Nine Months Ended September 30, 2018 and September 30, 2017

[0001262039-18-000040:mdna:101]
[same as prior period, unchanged from 0001262039-18-000029:mdna:100]

[0001262039-18-000040:mdna:102]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2018 (1) |  | September 30, 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 473.6 |  |  | 37 | % |  | $ | 415.1 |  |  | 38 | % |  | $ | 58.5 |  |  | 14 | % |
| Service | 820.6 |  |  | 63 |  |  | 663.2 |  |  | 62 |  |  | 157.4 |  |  | 24 |  |
| Total revenue | $ | 1,294.2 |  |  | 100 | % |  | $ | 1,078.3 |  |  | 100 | % |  | $ | 215.9 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 559.1 |  |  | 43 | % |  | $ | 468.3 |  |  | 43 | % |  | $ | 90.8 |  |  | 19 | % |
| EMEA | 474.3 |  |  | 37 |  |  | 394.2 |  |  | 37 |  |  | 80.1 |  |  | 20 |  |
| APAC | 260.8 |  |  | 20 |  |  | 215.8 |  |  | 20 |  |  | 45.0 |  |  | 21 |  |
| Total revenue | $ | 1,294.2 |  |  | 100 | % |  | $ | 1,078.3 |  |  | 100 | % |  | $ | 215.9 |  |  | 20 | % |

[0001262039-18-000040:mdna:103]
(1) Revenue during the nine months ended September 30, 2018 under Topic 606 (As Reported) and Topic 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000040:mdna:104]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Revenue: |  |  |  |  |  |
| Product | $ | 473.6 |  |  | $ | 461.5 |  |  | $ | 12.1 |  |
| Service | 820.6 |  |  | 819.1 |  |  | 1.5 |  |
| Total revenue | $ | 1,294.2 |  |  | $ | 1,280.6 |  |  | $ | 13.6 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 559.1 |  |  | $ | 547.0 |  |  | $ | 12.1 |  |
| EMEA | 474.3 |  |  | 471.8 |  |  | 2.5 |  |
| APAC | 260.8 |  |  | 261.8 |  |  | (1.0 | ) |
| Total revenue | $ | 1,294.2 |  |  | $ | 1,280.6 |  |  | $ | 13.6 |  |

[0001262039-18-000040:mdna:105]
Total revenue increased by $215.9 million, or 20%, during the nine months ended September 30, 2018 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all regions grew both on an absolute dollars and on a percentage basis. Product revenue increased by $58.5 million, or 14%, during the nine months ended September 30, 2018 compared to the same period last year. Product revenue in the nine months ended September 30, 2018 included a $12.1 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements can now be recognized upfront instead of ratably over the contracted service term. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products also increased significantly. Fortinet Security Fabric and cloud products were the fastest growing products compared to the remainder of our business. Service revenue increased by $157.4 million, or 24%, during the nine months ended September 30, 2018 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-18-000040:mdna:106]
[same as prior period, unchanged from 0001262039-18-000029:mdna:98]

[0001262039-18-000040:mdna:107]
[same as prior period, unchanged from 0001262039-18-000029:mdna:106]

[0001262039-18-000040:mdna:108]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2018 (1) |  | September 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 204.1 |  |  | $ | 174.2 |  |  | $ | 29.9 |  |  | 17 | % |
| Service | 117.8 |  |  | 105.7 |  |  | 12.1 |  |  | 11 |  |
| Total cost of revenue | $ | 321.9 |  |  | $ | 279.9 |  |  | $ | 42.0 |  |  | 15 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.9 | % |  | 58.0 | % |  | (1.1 | )% |  |  |
| Service | 85.6 |  |  | 84.1 |  |  | 1.5 |  |  |  |
| Total gross margin | 75.1 | % |  | 74.0 | % |  | 1.1 | % |  |  |

[0001262039-18-000040:mdna:109]
(1) Cost of revenue and gross margin during the nine months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000040:mdna:110]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 204.1 |  |  | $ | 203.1 |  |  | $ | 1.0 |  |
| Service | 117.8 |  |  | 117.8 |  |  | — |  |
| Total cost of revenue | $ | 321.9 |  |  | $ | 320.9 |  |  | $ | 1.0 |  |
| Gross margin (%): |  |  |  |  |  |
| Product | 56.9 | % |  | 56.0 | % |  | 0.9 | % |
| Service | 85.6 |  |  | 85.6 |  |  | — |  |
| Total gross margin | 75.1 | % |  | 74.9 | % |  | 0.2 | % |

[0001262039-18-000040:mdna:111]
Total gross margin increased by 1.1 percentage points during the nine months ended September 30, 2018 compared to the same period last year, driven by higher margin on higher service revenue. Service gross margin increased by 1.5 percentage points during the nine months ended September 30, 2018 compared to the same period last year, due to the strength of our FortiCare technical support and FortiGuard and other security subscription revenue growing 30% and 20%, respectively, during the nine months ended September 30, 2018 compared to the same period last year, which outpaced the increase in the related personnel costs and headcount growth, resulting in a higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 1.1 percentage points during the nine months ended September 30, 2018 compared to the same period last year, as we continued to transition to our new product introductions. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-18-000040:mdna:112]
[same as prior period, unchanged from 0001262039-18-000029:mdna:111]

[0001262039-18-000040:mdna:113]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2018 (1) |  | September 30, 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 179.0 |  |  | 14% |  | $ | 155.9 |  |  | 14 | % |  | $ | 23.1 |  |  | 15 | % |
| Sales and marketing | 576.4 |  |  | 45 |  | 509.1 |  |  | 47 |  |  | 67.3 |  |  | 13 |  |
| General and administrative | 71.0 |  |  | 5 |  | 65.5 |  |  | 6 |  |  | 5.5 |  |  | 8 |  |
| Restructuring charges | — |  |  | — |  | 0.3 |  |  | — |  |  | (0.3 | ) |  | (100 | ) |
| Total operating expenses | $ | 826.4 |  |  | 64% |  | $ | 730.8 |  |  | 68 | % |  | $ | 95.6 |  |  | 13 | % |

[0001262039-18-000040:mdna:114]
(1) Operating expenses during the nine months ended September 30, 2018 under Topic 606 (As Reported) and Topic 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000040:mdna:115]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 179.0 |  |  | $ | 179.0 |  |  | $ | — |  |
| Sales and marketing expenses | 576.4 |  |  | 608.9 |  |  | (32.5 | ) |
| General and administrative | 71.0 |  |  | 71.0 |  |  | — |  |
| Total operating expenses | $ | 826.4 |  |  | $ | 858.9 |  |  | $ | (32.5 | ) |

[0001262039-18-000040:mdna:116]
[same as prior period, unchanged from 0001262039-18-000029:mdna:115]

[0001262039-18-000040:mdna:117]
Research and development expense increased by $23.1 million, or 15%, during the nine months ended September 30, 2018 compared to the same period last year, primarily due to an increase of $20.9 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products.

[0001262039-18-000040:mdna:118]
[same as prior period, unchanged from 0001262039-18-000029:mdna:118]

[0001262039-18-000040:mdna:119]
Sales and marketing expense increased by $67.3 million, or 13%, during the nine months ended September 30, 2018 compared to the same period last year, primarily due to an increase of $50.6 million in personnel-related costs, including higher stock-based compensation expense of $12.1 million, as sales and marketing headcount increased in order to drive market share gains globally. These increases in personnel costs included a benefit of $32.5 million from the adoption of the new accounting standard related to deferred contract costs. Under this new standard, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commission related to these service contracts. Our sales and marketing expense would have increased by $99.8 million, or 20%, under the prior accounting standard. Refer to Note 2 in our notes to the condensed consolidated financial statement for more information. Travel and entertainment expense increased by $5.6 million. In addition, marketing-related expense increased by $4.9 million and depreciation and other occupancy-related costs increased by $4.8 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 48% of total revenue.

[0001262039-18-000040:mdna:120]
[same as prior period, unchanged from 0001262039-18-000029:mdna:120]

[0001262039-18-000040:mdna:121]
General and administrative expense increased by $5.5 million, or 8%, during the nine months ended September 30, 2018 compared to the same period last year. Personnel costs increased by $8.0 million as we continued to increase headcount in order to support our expanding business. In addition, expense related to software licenses and ERP costs increased by $2.4 million, supplies expense increase of $0.8 million and professional fees increased by $0.4 million. The increase in expense was partially offset by a decrease in depreciation and other occupancy-related costs of $5.0 million and a decrease in litigation settlement costs of $1.4 million.

[0001262039-18-000040:mdna:122]
[same as prior period, unchanged from 0001262039-18-000029:mdna:122]

[0001262039-18-000040:mdna:123]
We generated operating income of $145.9 million during the nine months ended September 30, 2018, an increase of $78.3 million, or 116%, compared to $67.6 million in the same period last year. The improvement in operating income generated was primarily due to the benefit from the adoption of the new accounting standard, along with revenue growth outpacing total operating expense growth. Operating income as a percentage of total revenue increased to 11% in the nine months ended September 30, 2018 from 6% in the same period of last year. The increase in operating margin is primarily due to a decrease in sales and marketing expenses to 45% as a percentage of total revenue in the nine months ended September 30, 2018 from 47% in the same period last year. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 48% of total revenue. The adoption of this new standard resulted in an improvement of 3.4 percentage points in our operating margin.

[0001262039-18-000040:mdna:124]
[same as prior period, unchanged from 0001262039-18-000029:mdna:124]

[0001262039-18-000040:mdna:125]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2018 |  | September 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 17.2 |  |  | $ | 9.5 |  |  | $ | 7.7 |  |  | 81 | % |
| Other income (expense)—net | (4.3 | ) |  | 1.9 |  |  | (6.2 | ) |  | (326 | ) |

[0001262039-18-000040:mdna:126]
Interest income increased during the nine months ended September 30, 2018 compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments and market interest rates. The change in other income (expense)—net during the nine months ended September 30, 2018 compared to the same period last year was primarily due to higher foreign currency exchange losses, offset by $2.2 million gain on sale of an investment in a privately held company.

[0001262039-18-000040:mdna:127]
Provision for income taxes

[0001262039-18-000040:mdna:128]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2018 (1) |  | September 30, 2017 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 9.2 |  |  | $ | 18.6 |  |  | $ | (9.4 | ) |  | (51 | )% |
| Effective tax rate (%) | 6 | % |  | 24 | % |  | (18 | )% |  | — |  |

[0001262039-18-000040:mdna:129]
(1) Provision for income taxes during the nine months ended September 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000040:mdna:130]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Increase (Decrease) |
| Provision for (benefit from) income taxes | $ | 9.2 |  |  | $ | (0.7 | ) |  | $ | 9.9 |  |
| Effective tax rate (%) | 6 | % |  | (1 | )% |  | 7 | % |

[0001262039-18-000040:mdna:131]
Our effective tax rate was 6% for the nine months ended September 30, 2018 compared to an effective tax rate of 24% for the same period last year, with the primary difference being the change in the federal corporate income tax rate to 21% in 2018 from 35% in the prior year and release of reserve for uncertain tax positions, including interest due to a statute of limitation expiring and the IRS audit finalization. The effective tax rate for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $43.4 million, which were offset by a tax benefit of $16.2 million for stock-based compensation. The tax rate for the nine month ended September 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million. The tax rate for the nine months ended September 30, 2017 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $30.0 million which were offset by a tax provision benefit of $11.4 million for stock-based compensation.

[0001262039-18-000040:mdna:132]
[same as prior period, unchanged from 0001262039-18-000029:mdna:132]

[0001262039-18-000040:mdna:133]
|  | As of |
|  | September 30, 2018 |  | December 31, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,169.3 |  |  | $ | 811.0 |  |
| Investments | 503.5 |  |  | 538.3 |  |
| Total cash, cash equivalents and investments | $ | 1,672.8 |  |  | $ | 1,349.3 |  |
| Working capital | $ | 966.2 |  |  | $ | 689.6 |  |
|  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 458.7 |  |  | $ | 436.9 |  |
| Net cash used in investing activities | (7.4 | ) |  | (142.1 | ) |
| Net cash used in financing activities | (93.0 | ) |  | (98.0 | ) |
| Net increase in cash and cash equivalents | $ | 358.3 |  |  | $ | 196.8 |  |

[0001262039-18-000040:mdna:134]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under the ESPP, and payment of taxes in connection with the net settlement of equity awards. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the proceeds from exercise of stock options and purchases under the ESPP. Additional increases in deferred revenue may depend on a number of factors including our billing growth rate, service contract renewal rates and length of initial and renewals service contracts. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units granted versus stock options and also to vary based on our share price. As of September 30, 2018, $825.8 million remained available for future share repurchase under the Repurchase Program.

[0001262039-18-000040:mdna:135]
Construction on the new headquarters building is expected to start in the fourth quarter of 2018 and related spend will continue in 2019 and until project completion. We estimate 2018 spending for this project to be approximately $10.0 million to $20.0 million. We estimate 2019 spending on the project to be between $60.0 million to $80.0 million dollars.

[0001262039-18-000040:mdna:136]
As of September 30, 2018, our cash, cash equivalents and investments of $1.67 billion were invested primarily in corporate debt securities, certificates of deposit and term deposits, money market funds, commercial paper and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-18-000040:mdna:137]
As of September 30, 2018, $870.4 million of our cash and investments were held by our international subsidiaries. Under the 2017 Tax Act signed into law in December 2017, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which were previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. Most of our off-shore cash is located in Singapore. Corporate law in Singapore only allows dividends to be paid to the extent we have retained earnings in Singapore. In Singapore, our retained earnings are lower than our current cash balance. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-18-000040:mdna:138]
42

[0001262039-18-000040:mdna:139]
[same as prior period, unchanged from 0001262039-18-000029:mdna:139]

[0001262039-18-000040:mdna:140]
[same as prior period, unchanged from 0001262039-18-000029:mdna:140]

[0001262039-18-000040:mdna:141]
Our operating activities during the nine months ended September 30, 2018 provided $458.7 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew 27% as of September 30, 2018 compared to the same period last year to $1.54 billion.

[0001262039-18-000040:mdna:142]
Our operating activities during the nine months ended September 30, 2017 provided $436.9 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. The increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers was reflected in the increase in our deferred revenue.

[0001262039-18-000040:mdna:143]
[same as prior period, unchanged from 0001262039-18-000029:mdna:143]

[0001262039-18-000040:mdna:144]
[same as prior period, unchanged from 0001262039-18-000029:mdna:144]

[0001262039-18-000040:mdna:145]
During the nine months ended September 30, 2018, cash used for investing activities was primarily due to the $41.4 million we spent on capital expenditures and $6.0 million used for the acquisition of Bradford, net of cash acquired. This was partially offset by an increase in cash of $40.0 million due to maturities and sales of our investments, net of purchases.

[0001262039-18-000040:mdna:146]
During the nine months ended September 30, 2017, cash used in investing activities was primarily due to the $121.6 million we spent on capital expenditures, including the purchase of $84.8 million in real estate in Burnaby, Canada in April 2017. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $20.5 million.

[0001262039-18-000040:mdna:147]
[same as prior period, unchanged from 0001262039-18-000029:mdna:147]

[0001262039-18-000040:mdna:148]
[same as prior period, unchanged from 0001262039-18-000029:mdna:148]

[0001262039-18-000040:mdna:149]
During the nine months ended September 30, 2018, cash used for financing activities was $93.0 million, primarily due to $117.1 million used to repurchase our common stock and $9.5 million of payments of the debt assumed in business combination. This was partially offset by $33.6 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000040:mdna:150]
During the nine months ended September 30, 2017, cash used in financing activities was $98.0 million, primarily due to $124.0 million used to repurchase our common stock. This was partially offset by $26.0 million proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000040:mdna:151]
[same as prior period, unchanged from 0001262039-18-000029:mdna:152]

[0001262039-18-000040:mdna:152]
There were no material changes outside the ordinary course of business during the nine months ended September 30, 2018 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 10 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-18-000040:mdna:153]
[same as prior period, unchanged from 0001262039-18-000029:mdna:137]

[0001262039-18-000040:mdna:154]
[same as prior period, unchanged from 0001262039-18-000029:mdna:154]

[0001262039-18-000040:mdna:155]
As of September 30, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
