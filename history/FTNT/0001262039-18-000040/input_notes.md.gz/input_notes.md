# FTNT notes — 0001262039-18-000040


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-18-000040:notes:1]
[same as prior period, unchanged from 0001262039-18-000029:notes:1]

[0001262039-18-000040:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Income tax benefit associated with stock-based compensation | $ | 6.8 |  |  | $ | 6.7 |  |  | $ | 19.0 |  |  | $ | 21.1 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-18-000040:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

[0001262039-18-000040:notes:4]
[same as prior period, unchanged from 0001262039-18-000029:notes:4]

[0001262039-18-000040:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-18-000040:notes:6]
[same as prior period, unchanged from 0001262039-18-000029:notes:6]

[0001262039-18-000040:notes:7]
|  | September 30, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 296.6 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 295.4 |  |
| Certificates of deposit and term deposits (1) | 106.1 |  |  | — |  |  | — |  |  | 106.1 |  |
| Commercial paper | 72.5 |  |  | — |  |  | (0.1 | ) |  | 72.4 |  |
| U.S. government and agency securities | 29.7 |  |  | — |  |  | (0.1 | ) |  | 29.6 |  |
| Total available-for-sale securities | $ | 504.9 |  |  | $ | — |  |  | $ | (1.4 | ) |  | $ | 503.5 |  |
|  | December 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 391.0 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 389.8 |  |
| Commercial paper | 74.2 |  |  | — |  |  | — |  |  | 74.2 |  |
| Certificates of deposit and term deposits (1) | 45.9 |  |  | — |  |  | — |  |  | 45.9 |  |
| U.S. government and agency securities | 28.5 |  |  | — |  |  | (0.1 | ) |  | 28.4 |  |
| Total available-for-sale securities | $ | 539.6 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 538.3 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-18-000040:notes:8]
[same as prior period, unchanged from 0001262039-18-000029:notes:8]

[0001262039-18-000040:notes:9]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.4 |  |  | 4.4 |  |
| Volatility | 30.5 | % |  | 33.1 | % |  | 31.6 | % |  | 36.1 | % |
| Risk-free interest rate | 2.7 | % |  | 1.8 | % |  | 2.7 | % |  | 1.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-18-000040:notes:10]
[same as prior period, unchanged from 0001262039-18-000029:notes:10]

[0001262039-18-000040:notes:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| RSUs | $ | 38.2 |  |  | $ | 29.9 |  |  | $ | 106.1 |  |  | $ | 89.8 |  |
| Stock options | 2.4 |  |  | 1.8 |  |  | 6.7 |  |  | 5.6 |  |
| ESPP | 2.6 |  |  | 2.6 |  |  | 7.5 |  |  | 7.3 |  |
| Total stock-based compensation expense | $ | 43.2 |  |  | $ | 34.3 |  |  | $ | 120.3 |  |  | $ | 102.7 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-18-000040:notes:12]
[same as prior period, unchanged from 0001262039-18-000029:notes:12]

[0001262039-18-000040:notes:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Shares withheld for taxes | 0.2 |  |  | 0.3 |  |  | 0.9 |  |  | 1.0 |  |
| Amount withheld for taxes | $ | 15.5 |  |  | $ | 10.0 |  |  | $ | 48.0 |  |  | $ | 35.9 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-18-000040:notes:14]
[same as prior period, unchanged from 0001262039-18-000029:notes:14]

[0001262039-18-000040:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Weighted-average fair value per share granted | $ | 22.75 |  |  | $ | 11.09 |  |  | $ | 15.67 |  |  | $ | 12.17 |  |
| Intrinsic value of options exercised | 14.1 |  |  | 3.4 |  |  | 53.6 |  |  | 30.3 |  |
| Fair value of options vested | 1.4 |  |  | 1.6 |  |  | 5.7 |  |  | 6.7 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-18-000040:notes:16]
[same as prior period, unchanged from 0001262039-18-000029:notes:16]

[0001262039-18-000040:notes:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Weighted-average fair value per share granted | $ | 18.28 |  |  | $ | 8.31 |  |  | $ | 14.14 |  |  | $ | 8.73 |  |
| Shares issued under the ESPP | 0.4 |  |  | 0.5 |  |  | 1.1 |  |  | 1.1 |  |
| Weighted-average price per share issued | $ | 41.89 |  |  | $ | 31.49 |  |  | $ | 35.32 |  |  | $ | 29.52 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-18-000040:notes:18]
[same as prior period, unchanged from 0001262039-18-000029:notes:18]

[0001262039-18-000040:notes:19]
[same as prior period, unchanged from 0001262039-18-000029:notes:19]

[0001262039-18-000040:notes:20]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services. We believe that this acquisition will extend the Fortinet Security Fabric to include network access control and provide for the security assessment and response related to devices accessing the network, including Internet of Things devices.

[0001262039-18-000040:notes:21]
Under the business combination method of accounting, the total purchase price was allocated to Bradford’s net tangible and intangible assets based upon their estimated fair values as of June 4, 2018. The purchase price allocation was preliminary and was based on management's best estimates and assumptions as of the reporting date. During the three months ended September 30, 2018, we subsequently decreased the intangible assets by $0.8 million with a corresponding change to goodwill of $0.6 million and deferred tax asset of $0.2 million. The preliminary purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes, and $8.0 million was allocated to identifiable intangible assets offset by $12.3 million of net liabilities assumed.

[0001262039-18-000040:notes:22]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of September 30, 2018, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the target.

[0001262039-18-000040:notes:23]
[same as prior period, unchanged from 0001262039-18-000029:notes:23]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-18-000040:notes:24]
COMMITMENTS AND CONTINGENCIES

[0001262039-18-000040:notes:25]
The following table summarizes our future principal contractual obligations as of September 30, 2018 (in millions):

[0001262039-18-000040:notes:26]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 52.0 |  |  | $ | 4.1 |  |  | $ | 15.3 |  |  | $ | 11.6 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |
| Inventory purchase commitments | 174.0 |  |  | 111.1 |  |  | 58.7 |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 226.0 |  |  | $ | 115.2 |  |  | $ | 74.0 |  |  | $ | 15.8 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |

[0001262039-18-000040:notes:27]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.4 million and $4.1 million during the three months ended September 30, 2018 and September 30, 2017, respectively. Rent expense was $13.1 million and $12.5 million during the nine months ended September 30, 2018 and September 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-18-000040:notes:28]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2018, we had $174.0 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-18-000040:notes:29]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2018, we had $11.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-18-000040:notes:30]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and there can be no assurances and the outcome of these matters is currently not determinable. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-18-000040:notes:31]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter. We are currently in settlement discussions with the United States Attorney’s Office.

[0001262039-18-000040:notes:32]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-18-000040:notes:33]
[same as prior period, unchanged from 0001262039-18-000029:notes:33]

[0001262039-18-000040:notes:34]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2018 and September 30, 2017 were $1.4 million and $1.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2018 and September 30, 2017 were $4.4 million and $3.8 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-18-000040:notes:35]
[same as prior period, unchanged from 0001262039-18-000029:notes:35]

[0001262039-18-000040:notes:36]
[same as prior period, unchanged from 0001262039-18-000029:notes:36]

[0001262039-18-000040:notes:37]
|  | Unrealized Losses on Investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Balance—December 31, 2017 | $ | (1.3 | ) |  | $ | 0.5 |  |  | $ | (0.8 | ) |
| Other comprehensive loss before reclassifications | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive loss | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Balance—September 30, 2018 | $ | (1.4 | ) |  | $ | 0.4 |  |  | $ | (1.0 | ) |

[0001262039-18-000040:notes:38]
[same as prior period, unchanged from 0001262039-18-000029:notes:38]


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-18-000040:notes:39]
[same as prior period, unchanged from 0001262039-18-000029:notes:39]

[0001262039-18-000040:notes:40]
Our investments in the equity securities of privately held companies totaled $9.1 million as of September 30, 2018 and $12.1 million as of December 31, 2017. These investments, which were previously accounted for at cost, are now accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. During the three months ended September 30, 2018, we sold equity securities of a privately held company for $5.2 million and recognized a gain of $2.2 million as other income in our condensed consolidated statements of operations. As of September 30, 2018, no other events have occurred that would adversely affect the carrying value of our remaining investments.

[0001262039-18-000040:notes:41]
As of September 30, 2018, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001262039-18-000040:notes:42]
[same as prior period, unchanged from 0001262039-18-000029:notes:42]

[0001262039-18-000040:notes:43]
[same as prior period, unchanged from 0001262039-18-000029:notes:43]

[0001262039-18-000040:notes:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 (1) |  | September 30, 2018 |  | September 30, 2017 (1) |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 157.0 |  |  | 130.8 |  |  | 440.7 |  |  | 366.3 |  |
| Technical support | 121.4 |  |  | 96.1 |  |  | 347.4 |  |  | 267.3 |  |
| Professional services and training | 11.0 |  |  | 10.2 |  |  | 32.5 |  |  | 29.6 |  |
| Total service revenue | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-18-000040:notes:45]
[same as prior period, unchanged from 0001262039-18-000029:notes:45]

[0001262039-18-000040:notes:46]
[same as prior period, unchanged from 0001262039-18-000029:notes:46]

[0001262039-18-000040:notes:47]
We have stock-based compensation plans pursuant to which we have granted RSUs and stock options. We also have an ESPP for eligible employees. As of September 30, 2018, there were a total of 54.5 million shares of common stock available for grant under our stock-based compensation plans.

[0001262039-18-000040:notes:48]
[same as prior period, unchanged from 0001262039-18-000029:notes:48]

[0001262039-18-000040:notes:49]
[same as prior period, unchanged from 0001262039-18-000029:notes:49]

[0001262039-18-000040:notes:50]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2017 | 8.5 |  |  | $ | 34.79 |  |
| Granted | 3.7 |  |  | 54.82 |  |
| Forfeited | (0.7 | ) |  | 38.24 |  |
| Vested | (3.1 | ) |  | 34.32 |  |
| Balance—September 30, 2018 | 8.4 |  |  | $ | 44.48 |  |

[0001262039-18-000040:notes:51]
As of September 30, 2018, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $331.7 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.8 years.

[0001262039-18-000040:notes:52]
[same as prior period, unchanged from 0001262039-18-000029:notes:52]

[0001262039-18-000040:notes:53]
[same as prior period, unchanged from 0001262039-18-000029:notes:53]

[0001262039-18-000040:notes:54]
[same as prior period, unchanged from 0001262039-18-000029:notes:54]

[0001262039-18-000040:notes:55]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2017 | 4.3 |  |  | $ | 27.50 |  |  |  |  |  |  |
| Granted | 0.8 |  |  | 51.29 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 31.90 |  |  |  |  |  |
| Exercised | (1.8 | ) |  | 24.74 |  |  |  |  |  |
| Balance—September 30, 2018 | 3.2 |  |  | $ | 34.69 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2018 | 3.2 |  |  | $ | 34.69 |  |  | 4.13 |  | $ | 183.4 |  |
| Options exercisable—September 30, 2018 | 1.6 |  |  | $ | 28.42 |  |  | 2.75 |  | $ | 104.9 |  |

[0001262039-18-000040:notes:56]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2018, for all in-the-money stock options. As of September 30, 2018, total compensation expense related to unvested stock options granted to employees but not yet recognized was $18.1 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.7 years.

[0001262039-18-000040:notes:57]
[same as prior period, unchanged from 0001262039-18-000029:notes:57]

[0001262039-18-000040:notes:58]
[same as prior period, unchanged from 0001262039-18-000029:notes:58]

[0001262039-18-000040:notes:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 30.5 | % |  | 26.2 | % |  | 28.9 | % |  | 29.5 | % |
| Risk-free interest rate | 2.2 | % |  | 1.2 | % |  | 2.0 | % |  | 0.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-18-000040:notes:60]
[same as prior period, unchanged from 0001262039-18-000029:notes:61]

[0001262039-18-000040:notes:61]
[same as prior period, unchanged from 0001262039-18-000029:notes:62]

[0001262039-18-000040:notes:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Cost of product revenue | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 1.1 |  |  | $ | 1.0 |  |
| Cost of service revenue | 2.8 |  |  | 2.4 |  |  | 8.0 |  |  | 7.2 |  |
| Research and development | 9.3 |  |  | 8.0 |  |  | 26.9 |  |  | 24.1 |  |
| Sales and marketing | 26.0 |  |  | 19.6 |  |  | 70.5 |  |  | 58.4 |  |
| General and administrative | 4.8 |  |  | 4.0 |  |  | 13.8 |  |  | 12.0 |  |
| Total stock-based compensation expense | $ | 43.2 |  |  | $ | 34.3 |  |  | $ | 120.3 |  |  | $ | 102.7 |  |

[0001262039-18-000040:notes:63]
[same as prior period, unchanged from 0001262039-18-000029:notes:64]

[0001262039-18-000040:notes:64]
In January 2016, our board of directors approved a Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-18-000040:notes:65]
During the three months ended September 30, 2018, we did not repurchase shares under the Repurchase Program. During the nine months ended September 30, 2018, we repurchased 2,540,547 shares of common stock under the Repurchase Program in open market transactions at an average price of $46.08 per share, for an aggregate purchase price of $117.1 million. As of September 30, 2018, $825.8 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-18-000040:notes:66]
[same as prior period, unchanged from 0001262039-18-000029:notes:67]

[0001262039-18-000040:notes:67]
[same as prior period, unchanged from 0001262039-18-000029:notes:68]

[0001262039-18-000040:notes:68]
[same as prior period, unchanged from 0001262039-18-000029:notes:69]

[0001262039-18-000040:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 58.7 |  |  | $ | 26.7 |  |  | $ | 149.6 |  |  | $ | 60.4 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 169.8 |  |  | 175.5 |  |  | 168.7 |  |  | 175.3 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 169.8 |  |  | 175.5 |  |  | 168.7 |  |  | 175.3 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 4.2 |  |  | 2.1 |  |  | 3.5 |  |  | 2.2 |  |
| Stock options | 1.6 |  |  | 1.3 |  |  | 1.4 |  |  | 1.4 |  |
| ESPP | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 175.7 |  |  | 179.0 |  |  | 173.7 |  |  | 179.0 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.15 |  |  | $ | 0.89 |  |  | $ | 0.34 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 0.86 |  |  | $ | 0.34 |  |

[0001262039-18-000040:notes:70]
[same as prior period, unchanged from 0001262039-18-000029:notes:71]

[0001262039-18-000040:notes:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| RSUs | 0.3 |  |  | 1.0 |  |  | 0.6 |  |  | 1.6 |  |
| Stock options | — |  |  | 1.1 |  |  | 0.4 |  |  | 1.1 |  |
| ESPP | 0.2 |  |  | 0.4 |  |  | 0.1 |  |  | 0.2 |  |
| Total | 0.5 |  |  | 2.5 |  |  | 1.1 |  |  | 2.9 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-18-000040:notes:72]
[same as prior period, unchanged from 0001262039-18-000029:notes:73]

[0001262039-18-000040:notes:73]
[same as prior period, unchanged from 0001262039-18-000029:notes:74]

[0001262039-18-000040:notes:74]
|  | September 30, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 163.1 |  |  | $ | (0.3 | ) |  | $ | 94.5 |  |  | $ | (0.9 | ) |  | $ | 257.6 |  |  | $ | (1.2 | ) |
| Commercial paper | 90.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 90.5 |  |  | (0.1 | ) |
| Certificates of deposit and term deposits | 35.9 |  |  | — |  |  | — |  |  | — |  |  | 35.9 |  |  | — |  |
| U.S. government and agency securities | 26.2 |  |  | — |  |  | 3.5 |  |  | (0.1 | ) |  | 29.7 |  |  | (0.1 | ) |
| Total available-for-sale securities | $ | 315.7 |  |  | $ | (0.4 | ) |  | $ | 98.0 |  |  | $ | (1.0 | ) |  | $ | 413.7 |  |  | $ | (1.4 | ) |

[0001262039-18-000040:notes:75]
[same as prior period, unchanged from 0001262039-18-000029:notes:76]

[0001262039-18-000040:notes:76]
[same as prior period, unchanged from 0001262039-18-000029:notes:77]

[0001262039-18-000040:notes:77]
|  | September 30, 2018 |  | December 31, 2017 |
| Due within one year | $ | 464.9 |  |  | $ | 440.3 |  |
| Due within one to three years | 38.6 |  |  | 98.0 |  |
| Total | $ | 503.5 |  |  | $ | 538.3 |  |

[0001262039-18-000040:notes:78]
[same as prior period, unchanged from 0001262039-18-000029:notes:79]

[0001262039-18-000040:notes:79]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of September 30, 2018.

[0001262039-18-000040:notes:80]
[same as prior period, unchanged from 0001262039-18-000029:notes:81]

[0001262039-18-000040:notes:81]
[same as prior period, unchanged from 0001262039-18-000029:notes:82]

[0001262039-18-000040:notes:82]
[same as prior period, unchanged from 0001262039-18-000029:notes:83]

[0001262039-18-000040:notes:83]
[same as prior period, unchanged from 0001262039-18-000029:notes:84]

[0001262039-18-000040:notes:84]
[same as prior period, unchanged from 0001262039-18-000029:notes:85]

[0001262039-18-000040:notes:85]
[same as prior period, unchanged from 0001262039-18-000029:notes:86]

[0001262039-18-000040:notes:86]
[same as prior period, unchanged from 0001262039-18-000029:notes:87]

[0001262039-18-000040:notes:87]
[same as prior period, unchanged from 0001262039-18-000029:notes:88]

[0001262039-18-000040:notes:88]
[same as prior period, unchanged from 0001262039-18-000029:notes:89]

[0001262039-18-000040:notes:89]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of September 30, 2018 and December 31, 2017 (in millions):

[0001262039-18-000040:notes:90]
|  | September 30, 2018 |  | December 31, 2017 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 295.4 |  |  | $ | — |  |  | $ | 295.4 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |
| Certificates of deposit and term deposits | 228.3 |  |  | — |  |  | 228.3 |  |  | — |  |  | 132.1 |  |  | — |  |  | 132.1 |  |  | — |  |
| Money market funds | 139.0 |  |  | 139.0 |  |  | — |  |  | — |  |  | 195.6 |  |  | 195.6 |  |  | — |  |  | — |  |
| Commercial paper | 121.0 |  |  | — |  |  | 121.0 |  |  | — |  |  | 128.9 |  |  | — |  |  | 128.9 |  |  | — |  |
| U.S. government and agency securities | 29.6 |  |  | 26.1 |  |  | 3.5 |  |  | — |  |  | 28.4 |  |  | 24.9 |  |  | 3.5 |  |  | — |  |
| Total | $ | 813.3 |  |  | $ | 165.1 |  |  | $ | 648.2 |  |  | $ | — |  |  | $ | 896.1 |  |  | $ | 220.5 |  |  | $ | 675.6 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 309.8 |  |  |  |  |  |  |  |  | $ | 357.8 |  |  |  |  |  |  |  |
| Short-term investments | 464.9 |  |  |  |  |  |  |  |  | 440.3 |  |  |  |  |  |  |  |
| Long-term investments | 38.6 |  |  |  |  |  |  |  |  | 98.0 |  |  |  |  |  |  |  |
| Total | $ | 813.3 |  |  |  |  |  |  |  |  | $ | 896.1 |  |  |  |  |  |  |  |

[0001262039-18-000040:notes:91]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2018 and year ended December 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-18-000040:notes:92]
[same as prior period, unchanged from 0001262039-18-000029:notes:93]

[0001262039-18-000040:notes:93]
[same as prior period, unchanged from 0001262039-18-000029:notes:94]

[0001262039-18-000040:notes:94]
[same as prior period, unchanged from 0001262039-18-000029:notes:95]

[0001262039-18-000040:notes:95]
|  | Amount |
| Balance—December 31, 2017 | $ | 14.6 |  |
| Addition due to business combination | 11.1 |  |
| Balance—September 30, 2018 | $ | 25.7 |  |

[0001262039-18-000040:notes:96]
There were no impairments to goodwill during the three and nine months ended September 30, 2018.

[0001262039-18-000040:notes:97]
[same as prior period, unchanged from 0001262039-18-000029:notes:98]

[0001262039-18-000040:notes:98]
The following tables present other intangible assets—net as of September 30, 2018 and December 31, 2017 (in millions, except years):

[0001262039-18-000040:notes:99]
|  | September 30, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 31.4 |  |  | $ | 18.1 |  |  | $ | 13.3 |  |
| Customer relationships | 4.5 |  | 16.7 |  |  | 11.9 |  |  | 4.8 |  |
| Total other intangible assets—net |  |  | $ | 48.1 |  |  | $ | 30.0 |  |  | $ | 18.1 |  |

[0001262039-18-000040:notes:100]
[same as prior period, unchanged from 0001262039-18-000029:notes:101]

[0001262039-18-000040:notes:101]
The in-process research and development intangible asset of $1.6 million was completed in the three months ended March 31, 2018. Upon completion, the cost was transferred to developed technology and is amortized over the estimated useful life of four years.

[0001262039-18-000040:notes:102]
Amortization expense was $2.5 million and $2.0 million during the three months ended September 30, 2018 and September 30, 2017, respectively. Amortization expense was $6.1 million and $6.5 million during the nine months ended September 30, 2018 and September 30, 2017, respectively.

[0001262039-18-000040:notes:103]
[same as prior period, unchanged from 0001262039-18-000029:notes:104]

[0001262039-18-000040:notes:104]
|  | Amount |
| Years: |  |
| 2018 | $ | 2.5 |  |
| 2019 | 8.2 |  |
| 2020 | 4.6 |  |
| 2021 and thereafter | 2.8 |  |
| Total | $ | 18.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-18-000040:notes:105]
[same as prior period, unchanged from 0001262039-18-000029:notes:106]

[0001262039-18-000040:notes:106]
Our effective tax rate was 17% for the three months ended September 30, 2018, compared to an effective tax rate of 30% for the same period last year. Our effective tax rate was 6% for the nine months ended September 30, 2018, compared to an effective tax rate of 24% for the same period last year, with the primary difference being the change in the federal corporate income tax rate to 21% in 2018 from 35% in the prior year, the release of reserve for uncertain tax positions including interest due to a statute of limitation expiring and the completion of the Internal Revenue Service (“IRS”) audit.  The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign taxes, excess tax benefits from stock-based compensation and release of a reserve for uncertain tax positions. The tax rates for the three months ended September 30, 2018 and September 30, 2017 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $17.7 million and $12.7 million, respectively, which were offset by a tax provision benefit of $5.8 million and $1.8 million, respectively, for stock-based compensation. The tax rate for the nine months ended September 30, 2018 and September 30, 2017 were impacted by withholding taxes and foreign taxes of $43.4 million and $30.0 million, respectively, which were offset by a tax benefit of $16.2 million and $11.4 million, respectively, for stock-based compensation. The tax rate for the nine months ended September 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-18-000040:notes:107]
As of September 30, 2018 and December 31, 2017, unrecognized tax benefits were $64.1 million and $72.5 million, respectively. The amount of $62.8 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of September 30, 2018 and December 31, 2017, accrued interest and penalties were $12.2 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $8.0 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000040:notes:108]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2008. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We have closed the Internal Revenue Service audit for tax years 2012, 2013 and 2014. In March 2018, we received a refund of $6.8 million for a carry-back claim approved in this audit. In October 2018, the French tax authorities notified us that they had closed the audit for tax years from 2007 to 2015 with no tax adjustment. This audit was examining the intercompany relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In April 2018, the tax authorities in Israel initiated a tax audit for tax years from 2008 to 2014. In July 2018, the tax authorities in Italy initiated a tax audit for tax year 2015.

[0001262039-18-000040:notes:109]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. On August 7, 2018, the Ninth Circuit withdrew the opinions filed on July 24, 2018 to allow time for the reconstituted panel to confer on the appeal. In Altera, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. The U.S. Tax Court had invalidated those regulations, in part because the Treasury Department failed to adequately consider significant taxpayer comments when adopting them. We will evaluate the tax impact when the new opinion is released by the Ninth Circuit.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-18-000040:notes:110]
[same as prior period, unchanged from 0001262039-18-000029:notes:111]

[0001262039-18-000040:notes:111]
[same as prior period, unchanged from 0001262039-18-000029:notes:112]

[0001262039-18-000040:notes:112]
|  | September 30, 2018 |  | December 31, 2017 |
| Raw materials | $ | 12.5 |  |  | $ | 13.0 |  |
| Finished goods | 68.3 |  |  | 64.3 |  |
| Inventory | $ | 80.8 |  |  | $ | 77.3 |  |

[0001262039-18-000040:notes:113]
Inventory includes materials at contract manufacturers of $2.9 million and $2.6 million as of September 30, 2018 and December 31, 2017, respectively. Inventory also includes finished goods held by distributors where revenue is recognized on a sell-through basis of $0.1 million as of December 31, 2017.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-18-000040:notes:114]
| Property and Equipment—net | September 30, 2018 |  | December 31, 2017 |
| Americas: |  |  |  |
| United States | $ | 127.8 |  |  | $ | 115.6 |  |
| Canada | 111.1 |  |  | 103.8 |  |
| LATAM | 0.4 |  |  | 0.3 |  |
| Total Americas | 239.3 |  |  | 219.7 |  |
| EMEA: |  |  |  |
| France | 13.3 |  |  | 11.9 |  |
| Other EMEA | 3.5 |  |  | 5.8 |  |
| Total EMEA | 16.8 |  |  | 17.7 |  |
| APAC | 9.3 |  |  | 8.0 |  |
| Total property and equipment—net | $ | 265.4 |  |  | $ | 245.4 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-18-000040:notes:115]
Recently Adopted Accounting Standards

[0001262039-18-000040:notes:116]
Financial Instruments – Recognition and Measurement

[0001262039-18-000040:notes:117]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, with further clarifications made recently with the issuance of ASU 2018-03, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

[0001262039-18-000040:notes:118]
Revenue Recognition

[0001262039-18-000040:notes:119]
In May 2014, the FASB issued Topic 606, which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted Topic 606 as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

[0001262039-18-000040:notes:120]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our condensed consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

[0001262039-18-000040:notes:121]
The cumulative effects of the changes made to our January 1, 2018 condensed consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

[0001262039-18-000040:notes:122]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | $ | 77.3 |  |  | $ | (0.1 | ) |  | $ | 77.2 |  |
| Deferred tax assets | $ | 146.9 |  |  | $ | (18.0 | ) |  | $ | 128.9 |  |
| Deferred contract costs | $ | — |  |  | $ | 137.1 |  |  | $ | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 50.0 |  |  | $ | 13.6 |  |  | $ | 63.6 |  |
| Deferred revenue, current | $ | 793.8 |  |  | $ | 0.3 |  |  | $ | 794.1 |  |
| Deferred revenue, non-current | $ | 542.5 |  |  | $ | (4.4 | ) |  | $ | 538.1 |  |
| Other liabilities, non-current | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

[0001262039-18-000040:notes:123]
Recent Accounting Standards Not Yet Effective

[0001262039-18-000040:notes:124]
Leases

[0001262039-18-000040:notes:125]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of Accounting Standards Codification (“ASC”) 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

[0001262039-18-000040:notes:126]
Stock Compensation

[0001262039-18-000040:notes:127]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of ASC Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of ASU 2018-07 on our consolidated financial statements.

[0001262039-18-000040:notes:128]
Cloud Computing

[0001262039-18-000040:notes:129]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Subtopic 350-40 to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our consolidated financial statements.

[0001262039-18-000040:notes:130]
Fair Value Measurements

[0001262039-18-000040:notes:131]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820—Fair Value Measurement as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements.

[0001262039-18-000040:notes:132]
Comprehensive Income

[0001262039-18-000040:notes:133]
In February 2018, the FASB issued ASU 2018-02—Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017 (the “2017 Tax Act”), from accumulated other comprehensive income to retained earnings. ASU 2018-02 also requires certain new disclosures regardless of the election. ASU 2018-02 is effective for us beginning January 1, 2019, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-02 on our consolidated financial statements.

[0001262039-18-000040:notes:134]
Financial Instruments

[0001262039-18-000040:notes:135]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. ASU 2016-13 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2016-13 on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-18-000040:notes:136]
[same as prior period, unchanged from 0001262039-18-000029:notes:129]

[0001262039-18-000040:notes:137]
[same as prior period, unchanged from 0001262039-18-000029:notes:130]

[0001262039-18-000040:notes:138]
|  | September 30, 2018 |  | December 31, 2017 |
| Building and building improvements | $ | 138.6 |  |  | $ | 133.2 |  |
| Computer equipment and software | 95.0 |  |  | 79.9 |  |
| Land | 75.7 |  |  | 65.6 |  |
| Leasehold improvements | 21.9 |  |  | 20.8 |  |
| Evaluation units | 20.2 |  |  | 20.1 |  |
| Furniture and fixtures | 16.7 |  |  | 14.7 |  |
| Construction-in-progress | 11.5 |  |  | 6.3 |  |
| Total property and equipment | 379.6 |  |  | 340.6 |  |
| Less: accumulated depreciation | (114.2 | ) |  | (95.2 | ) |
| Property and equipment—net | $ | 265.4 |  |  | $ | 245.4 |  |

[0001262039-18-000040:notes:139]
Depreciation expense was $11.8 million and $11.7 million during the three months ended September 30, 2018 and September 30, 2017, respectively. Depreciation expense was $34.9 million and $34.7 million during the nine months ended September 30, 2018 and September 30, 2017, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-18-000040:notes:140]
[same as prior period, unchanged from 0001262039-18-000029:notes:133]

[0001262039-18-000040:notes:141]
[same as prior period, unchanged from 0001262039-18-000029:notes:134]

[0001262039-18-000040:notes:142]
[same as prior period, unchanged from 0001262039-18-000029:notes:135]

[0001262039-18-000040:notes:143]
[same as prior period, unchanged from 0001262039-18-000029:notes:136]

[0001262039-18-000040:notes:144]
[same as prior period, unchanged from 0001262039-18-000029:notes:137]

[0001262039-18-000040:notes:145]
[same as prior period, unchanged from 0001262039-18-000029:notes:138]

[0001262039-18-000040:notes:146]
[same as prior period, unchanged from 0001262039-18-000029:notes:139]

[0001262039-18-000040:notes:147]
[same as prior period, unchanged from 0001262039-18-000029:notes:140]

[0001262039-18-000040:notes:148]
[same as prior period, unchanged from 0001262039-18-000029:notes:141]

[0001262039-18-000040:notes:149]
[same as prior period, unchanged from 0001262039-18-000029:notes:142]

[0001262039-18-000040:notes:150]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

[0001262039-18-000040:notes:151]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to the customer. Previously, term licenses were recognized over the license period.

[0001262039-18-000040:notes:152]
[same as prior period, unchanged from 0001262039-18-000029:notes:145]

[0001262039-18-000040:notes:153]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-18-000040:notes:154]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

[0001262039-18-000040:notes:155]
[same as prior period, unchanged from 0001262039-18-000029:notes:148]

[0001262039-18-000040:notes:156]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $13.7 million as of September 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

[0001262039-18-000040:notes:157]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-18-000040:notes:158]
During the three and nine months ended September 30, 2018, we recognized $173.0 million and $615.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

[0001262039-18-000040:notes:159]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and nine months ended September 30, 2018 and 2017.

[0001262039-18-000040:notes:160]
[same as prior period, unchanged from 0001262039-18-000029:notes:153]

[0001262039-18-000040:notes:161]
As of September 30, 2018, we had $1.54 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

[0001262039-18-000040:notes:162]
[same as prior period, unchanged from 0001262039-18-000029:notes:155]

[0001262039-18-000040:notes:163]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of September 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

[0001262039-18-000040:notes:164]
[same as prior period, unchanged from 0001262039-18-000029:notes:157]

[0001262039-18-000040:notes:165]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of September 30, 2018 and January 1, 2018.

[0001262039-18-000040:notes:166]
[same as prior period, unchanged from 0001262039-18-000029:notes:159]

[0001262039-18-000040:notes:167]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products and software licenses are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and nine months ended September 30, 2018 was $23.2 million and $66.3 million, respectively. No impairment loss was recognized during the three and nine months ended September 30, 2018.

[0001262039-18-000040:notes:168]
[same as prior period, unchanged from 0001262039-18-000029:notes:161]

[0001262039-18-000040:notes:169]
[same as prior period, unchanged from 0001262039-18-000029:notes:162]

[0001262039-18-000040:notes:170]
[same as prior period, unchanged from 0001262039-18-000029:notes:163]

[0001262039-18-000040:notes:171]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and nine months ended September 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

[0001262039-18-000040:notes:172]
[same as prior period, unchanged from 0001262039-18-000029:notes:165]

[0001262039-18-000040:notes:173]
|  | As of September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 324.4 |  |  | $ | 310.7 |  |  | $ | 13.7 |  |
| Inventory | $ | 80.8 |  |  | $ | 81.9 |  |  | $ | (1.1 | ) |
| Deferred contract costs | $ | 169.6 |  |  | $ | — |  |  | $ | 169.6 |  |
| Deferred tax assets | $ | 147.8 |  |  | $ | 175.6 |  |  | $ | (27.8 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 60.7 |  |  | $ | 45.5 |  |  | $ | 15.2 |  |
| Deferred revenue, current | $ | 876.2 |  |  | $ | 896.6 |  |  | $ | (20.4 | ) |
| Deferred revenue, non-current | $ | 668.2 |  |  | $ | 667.0 |  |  | $ | 1.2 |  |
| Other liabilities, non-current | $ | 11.1 |  |  | $ | 5.2 |  |  | $ | 5.9 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (156.0 | ) |  | $ | (308.5 | ) |  | $ | 152.5 |  |

[0001262039-18-000040:notes:174]
[same as prior period, unchanged from 0001262039-18-000029:notes:167]

[0001262039-18-000040:notes:175]
|  | Three Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 164.5 |  |  | $ | 162.3 |  |  | $ | 2.2 |  |
| Service | 289.4 |  |  | 289.6 |  |  | (0.2 | ) |
| Total revenue | 453.9 |  |  | 451.9 |  |  | 2.0 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 72.0 |  |  | 72.3 |  |  | (0.3 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.5 |  |  | 90.0 |  |  | 2.5 |  |
| Service | 249.8 |  |  | 250.0 |  |  | (0.2 | ) |
| Total gross profit | 342.3 |  |  | 340.0 |  |  | 2.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 198.3 |  |  | 207.3 |  |  | (9.0 | ) |
| OPERATING INCOME | 62.8 |  |  | 51.5 |  |  | 11.3 |  |
| INCOME BEFORE INCOME TAXES | 70.6 |  |  | 59.3 |  |  | 11.3 |  |
| PROVISION FOR INCOME TAXES | 11.9 |  |  | 9.8 |  |  | 2.1 |  |
| NET INCOME | $ | 58.7 |  |  | $ | 49.5 |  |  | $ | 9.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.05 |  |

[0001262039-18-000040:notes:176]
(1) Product revenue during the three months ended September 30, 2018 included a $2.2 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

[0001262039-18-000040:notes:177]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 473.6 |  |  | $ | 461.5 |  |  | $ | 12.1 |  |
| Service | 820.6 |  |  | 819.1 |  |  | 1.5 |  |
| Total revenue | 1,294.2 |  |  | 1,280.6 |  |  | 13.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 204.1 |  |  | 203.1 |  |  | 1.0 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 269.5 |  |  | 258.4 |  |  | 11.1 |  |
| Service | 702.8 |  |  | 701.3 |  |  | 1.5 |  |
| Total gross profit | 972.3 |  |  | 959.7 |  |  | 12.6 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 576.4 |  |  | 608.9 |  |  | (32.5 | ) |
| OPERATING INCOME | 145.9 |  |  | 100.8 |  |  | 45.1 |  |
| INCOME BEFORE INCOME TAXES | 158.8 |  |  | 113.7 |  |  | 45.1 |  |
| BENEFIT FROM INCOME TAXES | 9.2 |  |  | (0.7 | ) |  | 9.9 |  |
| NET INCOME | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.68 |  |  | $ | 0.21 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.66 |  |  | $ | 0.20 |  |

[0001262039-18-000040:notes:178]
(1) Product revenue during the nine months ended September 30, 2018 included a $12.1 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

[0001262039-18-000040:notes:179]
[same as prior period, unchanged from 0001262039-18-000029:notes:170]

[0001262039-18-000040:notes:180]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 66.3 |  |  | — |  |  | 66.3 |  |
| Other | (1.7 | ) |  | (1.6 | ) |  | (0.1 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (19.0 | ) |  | (20.0 | ) |  | 1.0 |  |
| Deferred contract costs | (98.8 | ) |  | — |  |  | (98.8 | ) |
| Deferred tax assets | (19.1 | ) |  | (29.0 | ) |  | 9.9 |  |
| Accrued liabilities | (2.0 | ) |  | (3.5 | ) |  | 1.5 |  |
| Deferred revenue | 209.9 |  |  | 224.9 |  |  | (15.0 | ) |
| Net cash provided by operating activities | $ | 458.7 |  |  | $ | 458.7 |  |  | $ | — |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-18-000040:notes:181]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 146.8 |  |  | $ | 123.7 |  |  | $ | 425.3 |  |  | $ | 367.1 |  |
| Latin America (“LATAM”) | 31.2 |  |  | 24.4 |  |  | 86.4 |  |  | 64.6 |  |
| Canada | 16.0 |  |  | 13.1 |  |  | 47.4 |  |  | 36.6 |  |
| Total Americas | 194.0 |  |  | 161.2 |  |  | 559.1 |  |  | 468.3 |  |
| Europe, Middle East and Africa (“EMEA”) | 165.4 |  |  | 138.3 |  |  | 474.3 |  |  | 394.2 |  |
| Asia Pacific (“APAC”) | 94.5 |  |  | 74.7 |  |  | 260.8 |  |  | 215.8 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001262039-18-000040:notes:182]
[same as prior period, unchanged from 0001262039-18-000029:notes:174]

[0001262039-18-000040:notes:183]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 (1) |  | September 30, 2017 |  | September 30, 2018 (1) |  | September 30, 2017 |
| Exclusive Networks Group | 29 | % |  | 29 | % |  | 29 | % |  | 23 | % |
| Ingram Micro | 11 | % |  | 11 | % |  | 10 | % |  | 10 | % |
| (1) Due to the acquisition by Exclusive Networks Group of the U.S. division of Fine Tec Computers (“Fine Tec U.S.”) in July 2017, Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive Networks Group. |

[0001262039-18-000040:notes:184]
[same as prior period, unchanged from 0001262039-18-000029:notes:176]

[0001262039-18-000040:notes:185]
|  | September 30, 2018 |  | December 31, 2017 |
| Exclusive Networks Group | 33 | % |  | 35 | % |
| Ingram Micro | 10 | % |  | * |  |
| * Represents less than 10% |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-18-000040:notes:186]
[same as prior period, unchanged from 0001262039-18-000029:notes:178]

[0001262039-18-000040:notes:187]
[same as prior period, unchanged from 0001262039-18-000029:notes:179]

[0001262039-18-000040:notes:188]
Revenue by geographic region is based on the billing address of our distributors and direct customer. The following tables set forth revenue and property and equipment—net by geographic region (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-18-000040:notes:189]
[same as prior period, unchanged from 0001262039-18-000029:notes:181]


## us-gaap:SubsequentEventsTextBlock

[0001262039-18-000040:notes:190]
SUBSEQUENT EVENT

[0001262039-18-000040:notes:191]
On October 23, 2018, we acquired ZoneFox Limited (“ZoneFox”), a privately held cloud-based insider threat detection and response company headquartered in Edinburgh, Scotland. The integration of ZoneFox’s machine learning-based threat-hunting technology will provide endpoint detection and response capabilities and will extend FortiSIEM product with additional user entity behavior analytics features, both on-premises and in the cloud. We acquired ZoneFox for approximately $18 million in initial consideration, subject to certain adjustments.

[0001262039-18-000040:notes:192]
We are currently in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
