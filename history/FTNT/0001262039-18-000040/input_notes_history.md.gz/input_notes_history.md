# FTNT note change history — 0001262039-18-000029 → 0001262039-18-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-07):
[0001262039-18-000040:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2018 (in millions):
  (was, 2018-08-07, similarity 0.9488):
[0001262039-18-000029:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2018 (in millions):

- changed (2018-11-07):
[0001262039-18-000040:note_history:2]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 52.0 |  |  | $ | 4.1 |  |  | $ | 15.3 |  |  | $ | 11.6 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |
| Inventory purchase commitments | 174.0 |  |  | 111.1 |  |  | 58.7 |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 226.0 |  |  | $ | 115.2 |  |  | $ | 74.0 |  |  | $ | 15.8 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |
  (was, 2018-08-07, similarity 0.9544):
[0001262039-18-000029:note_history:2]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 53.2 |  |  | $ | 8.9 |  |  | $ | 14.5 |  |  | $ | 11.2 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |
| Inventory purchase commitments | 104.9 |  |  | 100.7 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 158.1 |  |  | $ | 109.6 |  |  | $ | 14.5 |  |  | $ | 15.4 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |

- changed (2018-11-07):
[0001262039-18-000040:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.4 million and $4.1 million during the three months ended September 30, 2018 and September 30, 2017, respectively. Rent expense was $13.1 million and $12.5 million during the nine months ended September 30, 2018 and September 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2018-08-07, similarity 0.8996):
[0001262039-18-000029:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.9 million during the three months ended June 30, 2018 and June 30, 2017, respectively. Rent expense was $8.7 million and $8.4 million during the six months ended June 30, 2018 and June 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2018-11-07):
[0001262039-18-000040:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2018, we had $174.0 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2018-08-07, similarity 0.9904):
[0001262039-18-000029:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2018, we had $104.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2018-11-07):
[0001262039-18-000040:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2018, we had $11.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2018-08-07, similarity 0.9835):
[0001262039-18-000029:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2018, we had $9.5 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-07):
[0001262039-18-000040:note_history:6]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.
  (was, 2018-08-07, similarity 0.8113):
[0001262039-18-000029:note_history:6]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

- changed (2018-11-07):
[0001262039-18-000040:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.
  (was, 2018-08-07, similarity 0.9485):
[0001262039-18-000029:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.

- added (2018-11-07):
[0001262039-18-000040:note_history:8]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, with further clarifications made recently with the issuance of ASU 2018-03, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

- changed (2018-11-07):
[0001262039-18-000040:note_history:9]
In May 2014, the FASB issued Topic 606, which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted Topic 606 as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.
  (was, 2018-08-07, similarity 0.8949):
[0001262039-18-000029:note_history:9]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted ASU 2014-09 and its related amendments (collectively known as Topic 606) as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

- changed (2018-11-07):
[0001262039-18-000040:note_history:10]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our condensed consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.
  (was, 2018-08-07, similarity 0.997):
[0001262039-18-000029:note_history:10]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

- changed (2018-11-07):
[0001262039-18-000040:note_history:11]
The cumulative effects of the changes made to our January 1, 2018 condensed consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):
  (was, 2018-08-07, similarity 0.9671):
[0001262039-18-000029:note_history:11]
The cumulative effects of the changes made to our January 1, 2018 consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

- added (2018-11-07):
[0001262039-18-000040:note_history:12]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of Accounting Standards Codification (“ASC”) 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

- changed (2018-11-07):
[0001262039-18-000040:note_history:13]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of ASC Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of ASU 2018-07 on our consolidated financial statements.
  (was, 2018-08-07, similarity 0.9652):
[0001262039-18-000029:note_history:13]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of Accounting Standards Codification Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of this new standards on our consolidated financial statements.

- added (2018-11-07):
[0001262039-18-000040:note_history:14]
Cloud Computing

- added (2018-11-07):
[0001262039-18-000040:note_history:15]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Subtopic 350-40 to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our consolidated financial statements.

- added (2018-11-07):
[0001262039-18-000040:note_history:16]
Fair Value Measurements

- added (2018-11-07):
[0001262039-18-000040:note_history:17]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820—Fair Value Measurement as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements.

- added (2018-11-07):
[0001262039-18-000040:note_history:18]
Comprehensive Income

- added (2018-11-07):
[0001262039-18-000040:note_history:19]
In February 2018, the FASB issued ASU 2018-02—Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017 (the “2017 Tax Act”), from accumulated other comprehensive income to retained earnings. ASU 2018-02 also requires certain new disclosures regardless of the election. ASU 2018-02 is effective for us beginning January 1, 2019, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-02 on our consolidated financial statements.

- added (2018-11-07):
[0001262039-18-000040:note_history:20]
Financial Instruments

- added (2018-11-07):
[0001262039-18-000040:note_history:21]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. ASU 2016-13 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2016-13 on our consolidated financial statements.

- removed (2018-11-07):
[0001262039-18-000029:note_history:22]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

- removed (2018-11-07):
[0001262039-18-000029:note_history:23]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of ASC 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-11-07):
[0001262039-18-000040:note_history:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 (1) |  | September 30, 2018 |  | September 30, 2017 (1) |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 157.0 |  |  | 130.8 |  |  | 440.7 |  |  | 366.3 |  |
| Technical support | 121.4 |  |  | 96.1 |  |  | 347.4 |  |  | 267.3 |  |
| Professional services and training | 11.0 |  |  | 10.2 |  |  | 32.5 |  |  | 29.6 |  |
| Total service revenue | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- removed (2018-11-07):
[0001262039-18-000029:note_history:25]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 (1) |  | June 30, 2018 |  | June 30, 2017(1) |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 147.1 |  |  | 122.0 |  |  | 283.8 |  |  | 235.5 |  |
| Technical support | 116.4 |  |  | 90.1 |  |  | 226.0 |  |  | 171.2 |  |
| Professional services and training | 11.5 |  |  | 8.7 |  |  | 21.4 |  |  | 19.4 |  |
| Total service revenue | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-07):
[0001262039-18-000040:note_history:26]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.
  (was, 2018-08-07, similarity 0.9856):
[0001262039-18-000029:note_history:26]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a substantial majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- changed (2018-11-07):
[0001262039-18-000040:note_history:27]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to the customer. Previously, term licenses were recognized over the license period.
  (was, 2018-08-07, similarity 0.9179):
[0001262039-18-000029:note_history:27]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously, time-based software licenses were recognized over the license term.

- changed (2018-11-07):
[0001262039-18-000040:note_history:28]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.
  (was, 2018-08-07, similarity 0.9957):
[0001262039-18-000029:note_history:28]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- changed (2018-11-07):
[0001262039-18-000040:note_history:29]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.
  (was, 2018-08-07, similarity 0.9984):
[0001262039-18-000029:note_history:29]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

- changed (2018-11-07):
[0001262039-18-000040:note_history:30]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $13.7 million as of September 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.
  (was, 2018-08-07, similarity 0.9939):
[0001262039-18-000029:note_history:30]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.5 million as of June 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- changed (2018-11-07):
[0001262039-18-000040:note_history:31]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.
  (was, 2018-08-07, similarity 0.6025):
[0001262039-18-000029:note_history:31]
We generally invoice at the time of our sale for the total price of the products and security and technical support and other services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. We record deferred revenue when cash payments are received or due in advance of our performance.

- changed (2018-11-07):
[0001262039-18-000040:note_history:32]
During the three and nine months ended September 30, 2018, we recognized $173.0 million and $615.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.
  (was, 2018-08-07, similarity 0.9565):
[0001262039-18-000029:note_history:32]
During the three and six months ended June 30, 2018, we recognized $203.3 million and $442.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

- changed (2018-11-07):
[0001262039-18-000040:note_history:33]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and nine months ended September 30, 2018 and 2017.
  (was, 2018-08-07, similarity 0.9691):
[0001262039-18-000029:note_history:33]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and six months ended June 30, 2018 and 2017.

- added (2018-11-07):
[0001262039-18-000040:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 (1) |  | September 30, 2018 |  | September 30, 2017 (1) |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 157.0 |  |  | 130.8 |  |  | 440.7 |  |  | 366.3 |  |
| Technical support | 121.4 |  |  | 96.1 |  |  | 347.4 |  |  | 267.3 |  |
| Professional services and training | 11.0 |  |  | 10.2 |  |  | 32.5 |  |  | 29.6 |  |
| Total service revenue | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- changed (2018-11-07):
[0001262039-18-000040:note_history:35]
As of September 30, 2018, we had $1.54 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.
  (was, 2018-08-07, similarity 0.9831):
[0001262039-18-000029:note_history:35]
As of June 30, 2018, we had $1.47 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- changed (2018-11-07):
[0001262039-18-000040:note_history:36]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of September 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.
  (was, 2018-08-07, similarity 0.9881):
[0001262039-18-000029:note_history:36]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of June 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

- changed (2018-11-07):
[0001262039-18-000040:note_history:37]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of September 30, 2018 and January 1, 2018.
  (was, 2018-08-07, similarity 0.9287):
[0001262039-18-000029:note_history:37]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of June 30, 2018 and January 1, 2018.

- changed (2018-11-07):
[0001262039-18-000040:note_history:38]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products and software licenses are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and nine months ended September 30, 2018 was $23.2 million and $66.3 million, respectively. No impairment loss was recognized during the three and nine months ended September 30, 2018.
  (was, 2018-08-07, similarity 0.9471):
[0001262039-18-000029:note_history:38]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and six months ended June 30, 2018 was $22.4 million and $43.2 million, respectively. No impairment loss was recognized during the three months ended June 30, 2018.

- changed (2018-11-07):
[0001262039-18-000040:note_history:39]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and nine months ended September 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.
  (was, 2018-08-07, similarity 0.9288):
[0001262039-18-000029:note_history:39]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and six months ended June 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

- added (2018-11-07):
[0001262039-18-000040:note_history:40]
|  | As of September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 324.4 |  |  | $ | 310.7 |  |  | $ | 13.7 |  |
| Inventory | $ | 80.8 |  |  | $ | 81.9 |  |  | $ | (1.1 | ) |
| Deferred contract costs | $ | 169.6 |  |  | $ | — |  |  | $ | 169.6 |  |
| Deferred tax assets | $ | 147.8 |  |  | $ | 175.6 |  |  | $ | (27.8 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 60.7 |  |  | $ | 45.5 |  |  | $ | 15.2 |  |
| Deferred revenue, current | $ | 876.2 |  |  | $ | 896.6 |  |  | $ | (20.4 | ) |
| Deferred revenue, non-current | $ | 668.2 |  |  | $ | 667.0 |  |  | $ | 1.2 |  |
| Other liabilities, non-current | $ | 11.1 |  |  | $ | 5.2 |  |  | $ | 5.9 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (156.0 | ) |  | $ | (308.5 | ) |  | $ | 152.5 |  |

- added (2018-11-07):
[0001262039-18-000040:note_history:41]
|  | Three Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 164.5 |  |  | $ | 162.3 |  |  | $ | 2.2 |  |
| Service | 289.4 |  |  | 289.6 |  |  | (0.2 | ) |
| Total revenue | 453.9 |  |  | 451.9 |  |  | 2.0 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 72.0 |  |  | 72.3 |  |  | (0.3 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.5 |  |  | 90.0 |  |  | 2.5 |  |
| Service | 249.8 |  |  | 250.0 |  |  | (0.2 | ) |
| Total gross profit | 342.3 |  |  | 340.0 |  |  | 2.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 198.3 |  |  | 207.3 |  |  | (9.0 | ) |
| OPERATING INCOME | 62.8 |  |  | 51.5 |  |  | 11.3 |  |
| INCOME BEFORE INCOME TAXES | 70.6 |  |  | 59.3 |  |  | 11.3 |  |
| PROVISION FOR INCOME TAXES | 11.9 |  |  | 9.8 |  |  | 2.1 |  |
| NET INCOME | $ | 58.7 |  |  | $ | 49.5 |  |  | $ | 9.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.05 |  |

- added (2018-11-07):
[0001262039-18-000040:note_history:42]
(1) Product revenue during the three months ended September 30, 2018 included a $2.2 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

- added (2018-11-07):
[0001262039-18-000040:note_history:43]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 473.6 |  |  | $ | 461.5 |  |  | $ | 12.1 |  |
| Service | 820.6 |  |  | 819.1 |  |  | 1.5 |  |
| Total revenue | 1,294.2 |  |  | 1,280.6 |  |  | 13.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 204.1 |  |  | 203.1 |  |  | 1.0 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 269.5 |  |  | 258.4 |  |  | 11.1 |  |
| Service | 702.8 |  |  | 701.3 |  |  | 1.5 |  |
| Total gross profit | 972.3 |  |  | 959.7 |  |  | 12.6 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 576.4 |  |  | 608.9 |  |  | (32.5 | ) |
| OPERATING INCOME | 145.9 |  |  | 100.8 |  |  | 45.1 |  |
| INCOME BEFORE INCOME TAXES | 158.8 |  |  | 113.7 |  |  | 45.1 |  |
| BENEFIT FROM INCOME TAXES | 9.2 |  |  | (0.7 | ) |  | 9.9 |  |
| NET INCOME | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.68 |  |  | $ | 0.21 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.66 |  |  | $ | 0.20 |  |

- added (2018-11-07):
[0001262039-18-000040:note_history:44]
(1) Product revenue during the nine months ended September 30, 2018 included a $12.1 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

- changed (2018-11-07):
[0001262039-18-000040:note_history:45]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 66.3 |  |  | — |  |  | 66.3 |  |
| Other | (1.7 | ) |  | (1.6 | ) |  | (0.1 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (19.0 | ) |  | (20.0 | ) |  | 1.0 |  |
| Deferred contract costs | (98.8 | ) |  | — |  |  | (98.8 | ) |
| Deferred tax assets | (19.1 | ) |  | (29.0 | ) |  | 9.9 |  |
| Accrued liabilities | (2.0 | ) |  | (3.5 | ) |  | 1.5 |  |
| Deferred revenue | 209.9 |  |  | 224.9 |  |  | (15.0 | ) |
| Net cash provided by operating activities | $ | 458.7 |  |  | $ | 458.7 |  |  | $ | — |  |
  (was, 2018-08-07, similarity 0.7002):
[0001262039-18-000029:note_history:45]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 43.2 |  |  | — |  |  | 43.2 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (10.8 | ) |  | (12.2 | ) |  | 1.4 |  |
| Deferred contract costs | (66.7 | ) |  | — |  |  | (66.7 | ) |
| Deferred tax assets | (13.3 | ) |  | (21.1 | ) |  | 7.8 |  |
| Accrued liabilities | (4.7 | ) |  | (5.4 | ) |  | 0.7 |  |
| Deferred revenue | 136.3 |  |  | 148.7 |  |  | (12.4 | ) |
| Net cash provided by operating activities | $ | 282.0 |  |  | $ | 282.0 |  |  | $ | — |  |

- removed (2018-11-07):
[0001262039-18-000029:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 (1) |  | June 30, 2018 |  | June 30, 2017(1) |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 147.1 |  |  | 122.0 |  |  | 283.8 |  |  | 235.5 |  |
| Technical support | 116.4 |  |  | 90.1 |  |  | 226.0 |  |  | 171.2 |  |
| Professional services and training | 11.5 |  |  | 8.7 |  |  | 21.4 |  |  | 19.4 |  |
| Total service revenue | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- removed (2018-11-07):
[0001262039-18-000029:note_history:47]
|  | As of June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 333.6 |  |  | $ | 321.1 |  |  | $ | 12.5 |  |
| Inventory | $ | 78.2 |  |  | $ | 79.6 |  |  | $ | (1.4 | ) |
| Deferred contract costs | $ | 160.6 |  |  | $ | — |  |  | $ | 160.6 |  |
| Deferred tax assets | $ | 141.9 |  |  | $ | 167.8 |  |  | $ | (25.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 59.0 |  |  | $ | 44.7 |  |  | $ | 14.3 |  |
| Deferred revenue, current | $ | 849.5 |  |  | $ | 865.9 |  |  | $ | (16.4 | ) |
| Deferred revenue, non-current | $ | 621.3 |  |  | $ | 622.5 |  |  | $ | (1.2 | ) |
| Other liabilities, non-current | $ | 12.2 |  |  | $ | 6.4 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (214.7 | ) |  | $ | (358.0 | ) |  | $ | 143.3 |  |

- removed (2018-11-07):
[0001262039-18-000029:note_history:48]
|  | Three Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 162.1 |  |  | $ | 4.2 |  |
| Service | 275.0 |  |  | 274.0 |  |  | 1.0 |  |
| Total revenue | 441.3 |  |  | 436.1 |  |  | 5.2 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 73.9 |  |  | 74.1 |  |  | (0.2 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.4 |  |  | 88.0 |  |  | 4.4 |  |
| Service | 235.8 |  |  | 234.8 |  |  | 1.0 |  |
| Total gross profit | 328.2 |  |  | 322.8 |  |  | 5.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 192.8 |  |  | 204.6 |  |  | (11.8 | ) |
| OPERATING INCOME | 50.7 |  |  | 33.5 |  |  | 17.2 |  |
| INCOME BEFORE INCOME TAXES | 51.5 |  |  | 34.3 |  |  | 17.2 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.2 |  |  | (1.8 | ) |  | 4.0 |  |
| NET INCOME | $ | 49.3 |  |  | $ | 36.1 |  |  | $ | 13.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |

- removed (2018-11-07):
[0001262039-18-000029:note_history:49]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 309.1 |  |  | $ | 299.2 |  |  | $ | 9.9 |  |
| Service | 531.2 |  |  | 529.5 |  |  | 1.7 |  |
| Total revenue | 840.3 |  |  | 828.7 |  |  | 11.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 132.1 |  |  | 130.8 |  |  | 1.3 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 177.0 |  |  | 168.4 |  |  | 8.6 |  |
| Service | 453.0 |  |  | 451.3 |  |  | 1.7 |  |
| Total gross profit | 630.0 |  |  | 619.7 |  |  | 10.3 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 378.1 |  |  | 401.6 |  |  | (23.5 | ) |
| OPERATING INCOME | 83.1 |  |  | 49.3 |  |  | 33.8 |  |
| INCOME BEFORE INCOME TAXES | 88.2 |  |  | 54.4 |  |  | 33.8 |  |
| BENEFIT FROM INCOME TAXES | (2.7 | ) |  | (10.5 | ) |  | 7.8 |  |
| NET INCOME | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.54 |  |  | $ | 0.39 |  |  | $ | 0.15 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.38 |  |  | $ | 0.15 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-07):
[0001262039-18-000040:note_history:50]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.
  (was, 2018-08-07, similarity 0.9856):
[0001262039-18-000029:note_history:50]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a substantial majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- changed (2018-11-07):
[0001262039-18-000040:note_history:51]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to the customer. Previously, term licenses were recognized over the license period.
  (was, 2018-08-07, similarity 0.9179):
[0001262039-18-000029:note_history:51]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously, time-based software licenses were recognized over the license term.

- changed (2018-11-07):
[0001262039-18-000040:note_history:52]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.
  (was, 2018-08-07, similarity 0.9957):
[0001262039-18-000029:note_history:52]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- changed (2018-11-07):
[0001262039-18-000040:note_history:53]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.
  (was, 2018-08-07, similarity 0.9984):
[0001262039-18-000029:note_history:53]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

- changed (2018-11-07):
[0001262039-18-000040:note_history:54]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $13.7 million as of September 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.
  (was, 2018-08-07, similarity 0.9939):
[0001262039-18-000029:note_history:54]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.5 million as of June 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- changed (2018-11-07):
[0001262039-18-000040:note_history:55]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.
  (was, 2018-08-07, similarity 0.6025):
[0001262039-18-000029:note_history:55]
We generally invoice at the time of our sale for the total price of the products and security and technical support and other services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. We record deferred revenue when cash payments are received or due in advance of our performance.

- changed (2018-11-07):
[0001262039-18-000040:note_history:56]
During the three and nine months ended September 30, 2018, we recognized $173.0 million and $615.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.
  (was, 2018-08-07, similarity 0.9565):
[0001262039-18-000029:note_history:56]
During the three and six months ended June 30, 2018, we recognized $203.3 million and $442.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

- changed (2018-11-07):
[0001262039-18-000040:note_history:57]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and nine months ended September 30, 2018 and 2017.
  (was, 2018-08-07, similarity 0.9691):
[0001262039-18-000029:note_history:57]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and six months ended June 30, 2018 and 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-11-07):
[0001262039-18-000040:note_history:58]
On October 23, 2018, we acquired ZoneFox Limited (“ZoneFox”), a privately held cloud-based insider threat detection and response company headquartered in Edinburgh, Scotland. The integration of ZoneFox’s machine learning-based threat-hunting technology will provide endpoint detection and response capabilities and will extend FortiSIEM product with additional user entity behavior analytics features, both on-premises and in the cloud. We acquired ZoneFox for approximately $18 million in initial consideration, subject to certain adjustments.

- added (2018-11-07):
[0001262039-18-000040:note_history:59]
We are currently in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.

- removed (2018-11-07):
[0001262039-18-000029:note_history:60]
Share Repurchase

- removed (2018-11-07):
[0001262039-18-000029:note_history:61]
In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019.
