# FTNT notes — 0001262039-19-000014


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-19-000014:notes:1]
[same as prior period, unchanged from 0001262039-18-000040:notes:189]

[0001262039-19-000014:notes:2]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

[0001262039-19-000014:notes:3]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates.

[0001262039-19-000014:notes:4]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

[0001262039-19-000014:notes:5]
Recently Adopted Accounting Standards

[0001262039-19-000014:notes:6]
Leases

[0001262039-19-000014:notes:7]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to not reassess whether arrangements contain leases, not reassess lease classification and not reassess initial direct costs.

[0001262039-19-000014:notes:8]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less and does not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-19-000014:notes:9]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred

[0001262039-19-000014:notes:10]
rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.

[0001262039-19-000014:notes:11]
The ROU assets and the short-term and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our condensed consolidated balance sheets, respectively. Our accounting for finance leases (formerly referred to as capital leases prior to the adoption of Topic 842) remains substantially unchanged. Finance leases are not material to our condensed consolidated financial statements.

[0001262039-19-000014:notes:12]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease.

[0001262039-19-000014:notes:13]
Comprehensive Income

[0001262039-19-000014:notes:14]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.

[0001262039-19-000014:notes:15]
Stock Compensation

[0001262039-19-000014:notes:16]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019, ASU 2018-07 did not have a material impact to our condensed consolidated financial statements.

[0001262039-19-000014:notes:17]
Recent Accounting Standards Not Yet Effective

[0001262039-19-000014:notes:18]
Cloud Computing

[0001262039-19-000014:notes:19]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 to our condensed consolidated financial statements.

[0001262039-19-000014:notes:20]
Fair Value Measurements

[0001262039-19-000014:notes:21]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

[0001262039-19-000014:notes:22]
Financial Instruments

[0001262039-19-000014:notes:23]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). Topic 326 requires a financial asset (or a group of financial assets) to be measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. Topic 326 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of Topic 326 on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-19-000014:notes:24]
[same as prior period, unchanged from 0001262039-18-000040:notes:140]

[0001262039-19-000014:notes:25]
Our revenue consists of product and service revenue. Product revenue primarily consists of sales from our FortiGate products. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

[0001262039-19-000014:notes:26]
Disaggregation of Revenue

[0001262039-19-000014:notes:27]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-19-000014:notes:28]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service: |  |  |  |
| Security subscription | 169.6 |  |  | 136.6 |  |
| Technical support and other | 140.3 |  |  | 119.6 |  |
| Total service revenue | 309.9 |  |  | 256.2 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |

[0001262039-19-000014:notes:29]
[same as prior period, unchanged from 0001262039-18-000040:notes:160]

[0001262039-19-000014:notes:30]
As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.77 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

[0001262039-19-000014:notes:31]
[same as prior period, unchanged from 0001262039-18-000040:notes:162]

[0001262039-19-000014:notes:32]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of March 31, 2019 and December 31, 2018, respectively.

[0001262039-19-000014:notes:33]
[same as prior period, unchanged from 0001262039-18-000040:notes:166]

[0001262039-19-000014:notes:34]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2019 and March 31, 2018 were $25.1 million and $20.8 million, respectively. No impairment loss was recognized during the three months ended March 31, 2019 or March 31, 2018.

[0001262039-19-000014:notes:35]
Deferred Revenue

[0001262039-19-000014:notes:36]
During the three months ended March 31, 2019 and March 31, 2018, we recognized $288.6 million and $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31,2017, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-19-000014:notes:37]
[same as prior period, unchanged from 0001262039-18-000040:notes:72]

[0001262039-19-000014:notes:38]
The following tables summarize our investments (in millions):

[0001262039-19-000014:notes:39]
|  | March 31, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 348.1 |  |  | $ | 0.3 |  |  | $ | (0.6 | ) |  | $ | 347.8 |  |
| Commercial paper | 150.6 |  |  | — |  |  | — |  |  | 150.6 |  |
| Certificates of deposit and term deposits (1) | 70.8 |  |  | — |  |  | — |  |  | 70.8 |  |
| U.S. government and agency securities | 65.9 |  |  | — |  |  | — |  |  | 65.9 |  |
| Total available-for-sale securities | $ | 635.4 |  |  | $ | 0.3 |  |  | $ | (0.6 | ) |  | $ | 635.1 |  |
|  | December 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 299.5 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 298.3 |  |
| Commercial paper | 102.5 |  |  | — |  |  | — |  |  | 102.5 |  |
| Certificates of deposit and term deposits (1) | 145.8 |  |  | — |  |  | — |  |  | 145.8 |  |
| U.S. government and agency securities | 57.7 |  |  | — |  |  | (0.1 | ) |  | 57.6 |  |
| Total available-for-sale securities | $ | 605.5 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 604.2 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-19-000014:notes:40]
[same as prior period, unchanged from 0001262039-18-000040:notes:73]

[0001262039-19-000014:notes:41]
|  | March 31, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 86.1 |  |  | $ | (0.1 | ) |  | $ | 77.5 |  |  | $ | (0.5 | ) |  | $ | 163.6 |  |  | $ | (0.6 | ) |
| Commercial paper | 84.6 |  |  | — |  |  | — |  |  | — |  |  | 84.6 |  |  | — |  |
| Certificates of deposit and term deposits | 5.0 |  |  | — |  |  | — |  |  | — |  |  | 5.0 |  |  | — |  |
| U.S. government and agency securities | 21.2 |  |  | — |  |  | 3.5 |  |  | — |  |  | 24.7 |  |  | — |  |
| Total available-for-sale securities | $ | 196.9 |  |  | $ | (0.1 | ) |  | $ | 81.0 |  |  | $ | (0.5 | ) |  | $ | 277.9 |  |  | $ | (0.6 | ) |

[0001262039-19-000014:notes:42]
|  | December 31, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 150.1 |  |  | $ | (0.2 | ) |  | $ | 93.5 |  |  | $ | (1.0 | ) |  | $ | 243.6 |  |  | $ | (1.2 | ) |
| Commercial paper | 75.6 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 75.6 |  |  | (0.1 | ) |
| Certificates of deposit and term deposits | 51.7 |  |  | — |  |  | — |  |  | — |  |  | 51.7 |  |  | — |  |
| U.S. government and agency securities | 39.0 |  |  | — |  |  | 3.5 |  |  | — |  |  | 42.5 |  |  | — |  |
| Total available-for-sale securities | $ | 316.4 |  |  | $ | (0.3 | ) |  | $ | 97.0 |  |  | $ | (1.0 | ) |  | $ | 413.4 |  |  | $ | (1.3 | ) |

[0001262039-19-000014:notes:43]
[same as prior period, unchanged from 0001262039-18-000040:notes:76]

[0001262039-19-000014:notes:44]
|  | March 31, 2019 |  | December 31, 2018 |
| Due within one year | $ | 584.9 |  |  | $ | 537.2 |  |
| Due within one to three years | 50.2 |  |  | 67.0 |  |
| Total | $ | 635.1 |  |  | $ | 604.2 |  |

[0001262039-19-000014:notes:45]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized gains and losses on available-for-sale securities were insignificant in the periods presented and are included in other expense—net in our condensed consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-19-000014:notes:46]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2019.

[0001262039-19-000014:notes:47]
[same as prior period, unchanged from 0001262039-18-000040:notes:80]

[0001262039-19-000014:notes:48]
[same as prior period, unchanged from 0001262039-18-000040:notes:81]

[0001262039-19-000014:notes:49]
[same as prior period, unchanged from 0001262039-18-000040:notes:82]

[0001262039-19-000014:notes:50]
[same as prior period, unchanged from 0001262039-18-000040:notes:83]

[0001262039-19-000014:notes:51]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-19-000014:notes:52]
[same as prior period, unchanged from 0001262039-18-000040:notes:85]

[0001262039-19-000014:notes:53]
[same as prior period, unchanged from 0001262039-18-000040:notes:86]

[0001262039-19-000014:notes:54]
[same as prior period, unchanged from 0001262039-18-000040:notes:87]

[0001262039-19-000014:notes:55]
[same as prior period, unchanged from 0001262039-18-000040:notes:88]

[0001262039-19-000014:notes:56]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of March 31, 2019 and December 31, 2018 (in millions):

[0001262039-19-000014:notes:57]
|  | March 31, 2019 |  | December 31, 2018 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 349.9 |  |  | $ | — |  |  | $ | 349.9 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |
| Commercial paper | 201.0 |  |  | — |  |  | 201.0 |  |  | — |  |  | 184.7 |  |  | — |  |  | 184.7 |  |  | — |  |
| Certificates of deposit and term deposits | 70.8 |  |  | — |  |  | 70.8 |  |  | — |  |  | 217.4 |  |  | — |  |  | 217.4 |  |  | — |  |
| U.S. government and agency securities | 65.9 |  |  | 53.5 |  |  | 12.4 |  |  | — |  |  | 57.6 |  |  | 45.3 |  |  | 12.3 |  |  | — |  |
| Money market funds | 14.0 |  |  | 14.0 |  |  | — |  |  | — |  |  | 58.6 |  |  | 58.6 |  |  | — |  |  | — |  |
| Total | $ | 701.6 |  |  | $ | 67.5 |  |  | $ | 634.1 |  |  | $ | — |  |  | $ | 817.6 |  |  | $ | 103.9 |  |  | $ | 713.7 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 66.5 |  |  |  |  |  |  |  |  | $ | 213.4 |  |  |  |  |  |  |  |
| Short-term investments | 584.9 |  |  |  |  |  |  |  |  | 537.2 |  |  |  |  |  |  |  |
| Long-term investments | 50.2 |  |  |  |  |  |  |  |  | 67.0 |  |  |  |  |  |  |  |
| Total | $ | 701.6 |  |  |  |  |  |  |  |  | $ | 817.6 |  |  |  |  |  |  |  |

[0001262039-19-000014:notes:58]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2019 and year ended December 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-19-000014:notes:59]
[same as prior period, unchanged from 0001262039-18-000040:notes:110]

[0001262039-19-000014:notes:60]
[same as prior period, unchanged from 0001262039-18-000040:notes:111]

[0001262039-19-000014:notes:61]
|  | March 31, 2019 |  | December 31, 2018 |
| Raw materials | $ | 10.7 |  |  | $ | 13.3 |  |
| Finished goods | 77.7 |  |  | 76.7 |  |
| Inventory | $ | 88.4 |  |  | $ | 90.0 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-19-000014:notes:62]
[same as prior period, unchanged from 0001262039-18-000040:notes:136]

[0001262039-19-000014:notes:63]
[same as prior period, unchanged from 0001262039-18-000040:notes:137]

[0001262039-19-000014:notes:64]
|  | March 31, 2019 |  | December 31, 2018 |
| Land | $ | 75.7 |  |  | $ | 75.7 |  |
| Building and building improvements | 144.5 |  |  | 144.2 |  |
| Computer equipment and software | 98.7 |  |  | 95.9 |  |
| Leasehold improvements | 19.0 |  |  | 17.9 |  |
| Evaluation units | 20.1 |  |  | 20.5 |  |
| Furniture and fixtures | 16.2 |  |  | 15.7 |  |
| Construction-in-progress | 16.8 |  |  | 12.3 |  |
| Total property and equipment | 391.0 |  |  | 382.2 |  |
| Less: accumulated depreciation | (119.0 | ) |  | (110.8 | ) |
| Property and equipment—net | $ | 272.0 |  |  | $ | 271.4 |  |

[0001262039-19-000014:notes:65]
Depreciation expense was $12.7 million and $11.4 million during the three months ended March 31, 2019 and March 31, 2018, respectively.


## invest:InvestmentTextBlock

[0001262039-19-000014:notes:66]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-19-000014:notes:67]
Our investments in the equity securities of privately held companies totaled $9.1 million as of March 31, 2019 and December 31, 2018. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. As of March 31, 2019, no events have occurred that would affect the carrying value of these investments.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-19-000014:notes:68]
BUSINESS COMBINATIONS

[0001262039-19-000014:notes:69]
ZoneFox Holdings Limited

[0001262039-19-000014:notes:70]
On October 22, 2018, we acquired all outstanding shares of ZoneFox Holdings Limited (“ZoneFox”), a privately held cloud-based company providing insider threat detection and response. ZoneFox is headquartered in Edinburgh, Scotland. We expect the ZoneFox acquisition will allow us to provide additional user and entity behavior analytics features.

[0001262039-19-000014:notes:71]
Under the business combination method of accounting in accordance with ASC Topic 805, Business Combinations (“ASC 805”), the total purchase price was allocated to ZoneFox’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The purchase price for ZoneFox was $16.1 million, of which $12.5 million was allocated to goodwill that was non-deductible for tax purposes, and $6.8 million was allocated to identifiable intangible assets the majority of which was developed technology offset by $3.2 million of net liabilities assumed. Acquisition-related costs related to the ZoneFox acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000014:notes:72]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of March 31, 2019, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the performance conditions.

[0001262039-19-000014:notes:73]
[same as prior period, unchanged from 0001262039-18-000040:notes:19]

[0001262039-19-000014:notes:74]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services. We believe that this acquisition will extend the Fortinet Security Fabric to include network access control that helps with a security assessment related to devices accessing the network, including Internet of Things devices.

[0001262039-19-000014:notes:75]
Under the business combination method of accounting in accordance with ASC 805, the total purchase price was allocated to Bradford’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management's best estimates and assumptions to assign fair value as of the acquisition date. The purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes, and $8.0 million was allocated to identifiable intangible assets the majority of which was developed technology offset by $12.3 million of net liabilities assumed. Acquisition-related costs related to the Bradford acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000014:notes:76]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of March 31, 2019, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the performance conditions.

[0001262039-19-000014:notes:77]
Pro forma information has not been presented for these acquisitions as the impact to our condensed consolidated financial statements was not material.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-19-000014:notes:78]
[same as prior period, unchanged from 0001262039-18-000040:notes:92]

[0001262039-19-000014:notes:79]
[same as prior period, unchanged from 0001262039-18-000040:notes:93]

[0001262039-19-000014:notes:80]
As of March 31, 2019 and December 31, 2018, we had goodwill of $38.2 million. There were no impairments to goodwill during the three months ended March 31, 2019 or during prior periods.

[0001262039-19-000014:notes:81]
[same as prior period, unchanged from 0001262039-18-000040:notes:97]

[0001262039-19-000014:notes:82]
The following tables present other intangible assets—net as of March 31, 2019 and December 31, 2018 (in millions, except years):

[0001262039-19-000014:notes:83]
|  | March 31, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 34.4 |  |  | $ | 19.1 |  |  | $ | 15.3 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 13.7 |  |  | 3.8 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 32.8 |  |  | $ | 19.1 |  |

[0001262039-19-000014:notes:84]
|  | December 31, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 34.4 |  |  | $ | 17.0 |  |  | $ | 17.4 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 12.8 |  |  | 4.7 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 29.8 |  |  | $ | 22.1 |  |

[0001262039-19-000014:notes:85]
Amortization expense was $3.0 million and $1.8 million during the three months ended March 31, 2019 and March 31, 2018, respectively.

[0001262039-19-000014:notes:86]
[same as prior period, unchanged from 0001262039-18-000040:notes:103]

[0001262039-19-000014:notes:87]
|  | Amount |
| Years: |  |
| 2019 (the remainder of 2019) | $ | 7.3 |  |
| 2020 | 6.2 |  |
| 2021 | 3.5 |  |
| 2022 | 2.1 |  |
| Total | $ | 19.1 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-19-000014:notes:88]
[same as prior period, unchanged from 0001262039-18-000040:notes:66]

[0001262039-19-000014:notes:89]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and our Employee Stock Purchase Plan (the “ESPP”), which was terminated in February 2019 at the completion of the prior offering period. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-19-000014:notes:90]
[same as prior period, unchanged from 0001262039-18-000040:notes:68]

[0001262039-19-000014:notes:91]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Numerator: |  |  |  |
| Net income | $ | 58.8 |  |  | $ | 41.6 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 170.2 |  |  | 167.7 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 170.2 |  |  | 167.7 |  |
| Effect of potentially dilutive securities: |  |  |  |
| RSUs | 3.3 |  |  | 2.7 |  |
| Stock options | 1.3 |  |  | 1.3 |  |
| ESPP | — |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 174.8 |  |  | 171.8 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.25 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.24 |  |

[0001262039-19-000014:notes:92]
[same as prior period, unchanged from 0001262039-18-000040:notes:70]

[0001262039-19-000014:notes:93]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| RSUs | 0.7 |  |  | 1.1 |  |
| Stock options | 0.3 |  |  | 0.5 |  |
| ESPP | — |  |  | 0.2 |  |
| Total | 1.0 |  |  | 1.8 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-19-000014:notes:94]
LEASES

[0001262039-19-000014:notes:95]
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms of less than one year to approximately eight years, some of which include one or more options to renew, with renewal terms of up to five years. We do not include any of our renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement. Our finance leases are not material to our financial statements.

[0001262039-19-000014:notes:96]
The components of lease expense were as follows (in millions):

[0001262039-19-000014:notes:97]
|  | Three Months Ended |
|  | March 31, 2019 |
| Operating lease expense | $ | 3.6 |  |
| Variable lease expense (1) | 0.6 |  |
| Short-term lease expense | 0.7 |  |
| Total lease expense | $ | 4.9 |  |

[0001262039-19-000014:notes:98]
(1) Variable lease expense for the three months ended March 31, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-19-000014:notes:99]
Rent expense was $4.1 million during the three months ended March 31, 2018. Rent expense was recognized in accordance with ASC 840, Leases, using the straight-line method over the term of a lease.

[0001262039-19-000014:notes:100]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-19-000014:notes:101]
|  |  | Three Months Ended |
|  | Classification | March 31, 2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 39.2 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 11.9 |  |
| Operating lease liabilities - non-current | Other liabilities | 27.5 |  |
| Total operating lease liabilities |  | $ | 39.4 |  |
| Weighted average remaining lease term in years - operating leases |  | 4.1 |  |
| Weighted average discount rate - operating leases |  | 3.1 | % |

[0001262039-19-000014:notes:102]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-19-000014:notes:103]
|  | Three Months Ended |
|  | March 31, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows used for operating leases | $ | 4.6 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |
| Operating leases | $ | 3.5 |  |

[0001262039-19-000014:notes:104]
Maturities of operating lease liabilities as of March 31, 2019 were as follows (in millions):

[0001262039-19-000014:notes:105]
| Year ending December 31, | Amount |
| 2019 (the remainder of 2019) | $ | 9.7 |  |
| 2020 | 11.6 |  |
| 2021 | 8.2 |  |
| 2022 | 5.0 |  |
| 2023 | 3.7 |  |
| Thereafter | 3.8 |  |
| Total lease payments | $ | 42.0 |  |
| Less imputed interest | (2.6 | ) |
| Total | $ | 39.4 |  |

[0001262039-19-000014:notes:106]
As of March 31, 2019, we had additional minimum lease payments of $1.5 million relating to operating office space lease which was signed but had not yet commenced and therefore excluded from the table above. This lease will commence during 2019 with a lease term of approximately 5 years.

[0001262039-19-000014:notes:107]
The following table summarizes our future principal contractual obligations for operating lease commitments as of December 31, 2018 (in millions):

[0001262039-19-000014:notes:108]
| Year ending December 31, | Amount |
| 2019 | $ | 17.1 |  |
| 2020 | 12.2 |  |
| 2021 | 8.5 |  |
| 2022 | 5.0 |  |
| 2023 | 3.6 |  |
| Thereafter | 3.7 |  |
| Total | $ | 50.1 |  |

[0001262039-19-000014:notes:109]
Total future principal contractual obligations for operating lease commitments as of December 31, 2018 exceeded our undiscounted lease liability as of Topic 842 adoption date, primarily because the lease liability did not include short-term lease payments, which were excluded due to the adoption of the short-term lease exemption, and minimum lease payments relating to an operating office space lease that was signed but had not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-19-000014:notes:110]
COMMITMENTS AND CONTINGENCIES

[0001262039-19-000014:notes:111]
The following table summarizes our future principal contractual obligations as of March 31, 2019 (in millions):

[0001262039-19-000014:notes:112]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 202.2 |  |  | $ | 191.4 |  |  | $ | 10.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-19-000014:notes:113]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2019, we had $202.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-19-000014:notes:114]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2019, we had $15.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-19-000014:notes:115]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-19-000014:notes:116]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information on events from over two years ago related to our compliance with the Trade Agreements Act. We cooperated with the inquiry, and settled this matter with the United States Attorney’s Office.

[0001262039-19-000014:notes:117]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-19-000014:notes:118]
[same as prior period, unchanged from 0001262039-18-000040:notes:45]

[0001262039-19-000014:notes:119]
[same as prior period, unchanged from 0001262039-18-000040:notes:46]

[0001262039-19-000014:notes:120]
We have stock-based compensation plans pursuant to which we have granted RSUs and stock options. We also previously had an ESPP for eligible employees, which was terminated in February 2019. As of March 31, 2019, there were a total of 59.5 million shares of common stock available for grant under our stock-based compensation plans.

[0001262039-19-000014:notes:121]
[same as prior period, unchanged from 0001262039-18-000040:notes:48]

[0001262039-19-000014:notes:122]
[same as prior period, unchanged from 0001262039-18-000040:notes:49]

[0001262039-19-000014:notes:123]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2018 | 7.8 |  |  | $ | 46.07 |  |
| Granted | 1.6 |  |  | 84.75 |  |
| Forfeited | (0.1 | ) |  | 50.42 |  |
| Vested | (1.3 | ) |  | 41.95 |  |
| Balance—March 31, 2019 | 8.0 |  |  | $ | 54.40 |  |

[0001262039-19-000014:notes:124]
As of March 31, 2019, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $394.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.0 years.

[0001262039-19-000014:notes:125]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding tax requirement. Total payment of the employees’ tax obligations to the tax authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-19-000014:notes:126]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-19-000014:notes:127]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Shares withheld for taxes | 0.4 |  |  | 0.4 |  |
| Amount withheld for taxes | $ | 32.0 |  |  | $ | 19.2 |  |

[0001262039-19-000014:notes:128]
[same as prior period, unchanged from 0001262039-18-000040:notes:53]

[0001262039-19-000014:notes:129]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-19-000014:notes:130]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Expected term in years | 4.4 |  |  | 4.4 |  |
| Volatility | 34.2 | % |  | 31.7 | % |
| Risk-free interest rate | 2.5 | % |  | 2.6 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-19-000014:notes:131]
[same as prior period, unchanged from 0001262039-18-000040:notes:54]

[0001262039-19-000014:notes:132]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  |  |  |  |  |
| Granted | 0.6 |  |  | 84.49 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Exercised | (0.5 | ) |  | 28.67 |  |  |  |  |  |
| Balance—March 31, 2019 | 3.1 |  |  | $ | 46.56 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2019 | 3.1 |  |  | $ | 46.56 |  |  | 4.87 |  | $ | 116.0 |  |
| Options exercisable—March 31, 2019 | 1.4 |  |  | $ | 32.02 |  |  | 3.65 |  | $ | 71.3 |  |

[0001262039-19-000014:notes:133]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2019 for all in-the-money stock options. As of March 31, 2019, total compensation expense related to unvested stock options granted to employees but not yet recognized was $31.2 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.2 years.

[0001262039-19-000014:notes:134]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-19-000014:notes:135]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Weighted-average fair value per share granted | $ | 27.12 |  |  | $ | 15.02 |  |
| Intrinsic value of options exercised | 27.2 |  |  | 23.7 |  |
| Fair value of options vested | 4.2 |  |  | 2.8 |  |

[0001262039-19-000014:notes:136]
[same as prior period, unchanged from 0001262039-18-000040:notes:60]

[0001262039-19-000014:notes:137]
[same as prior period, unchanged from 0001262039-18-000040:notes:61]

[0001262039-19-000014:notes:138]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |
| Cost of service revenue | 2.8 |  |  | 2.5 |  |
| Research and development | 9.4 |  |  | 8.4 |  |
| Sales and marketing | 25.4 |  |  | 20.9 |  |
| General and administrative | 5.0 |  |  | 4.3 |  |
| Total stock-based compensation expense | $ | 43.0 |  |  | $ | 36.5 |  |

[0001262039-19-000014:notes:139]
The following table summarizes stock-based compensation expense by award type (in millions):

[0001262039-19-000014:notes:140]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| RSUs | $ | 39.2 |  |  | $ | 32.0 |  |
| Stock options | 2.5 |  |  | 2.0 |  |
| ESPP | 1.3 |  |  | 2.5 |  |
| Total stock-based compensation expense | $ | 43.0 |  |  | $ | 36.5 |  |

[0001262039-19-000014:notes:141]
Total income tax benefit associated with stock-based compensation that is recognized in the condensed consolidated statements of income is as follows (in millions):

[0001262039-19-000014:notes:142]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 10.0 |  |  | $ | 6.0 |  |

[0001262039-19-000014:notes:143]
[same as prior period, unchanged from 0001262039-18-000040:notes:63]

[0001262039-19-000014:notes:144]
Under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), the repurchase of up to $1.5 billion of our outstanding common stock is authorized through December 31, 2019. Share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-19-000014:notes:145]
During the three months ended March 31, 2019, we repurchased 0.8 million shares of common stock under the Repurchase Program in open market transactions at an average price of $72.19 per share, for an aggregate purchase price of $56.2 million. As of March 31, 2019, $677.5 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-19-000014:notes:146]
[same as prior period, unchanged from 0001262039-18-000040:notes:105]

[0001262039-19-000014:notes:147]
Our effective tax rate was 2% for the three months ended March 31, 2019, compared to an effective tax rate benefit of 13% for the same period last year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended March 31, 2019 and March 31, 2018 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $17.5 million and $8.5 million, respectively, which were offset by a tax benefit from stock-based compensation of $16.0 million and $5.6 million, respectively. The tax rate for the three months ended by March 31, 2018 was further impacted by a tax benefit of $7.8 million for the release of reserves on uncertain tax positions including interest due to the close of the Internal Revenue Service (“IRS”) audit.

[0001262039-19-000014:notes:148]
As of March 31, 2019 and December 31, 2018, unrecognized tax benefits were $65.9 million and $63.5 million, respectively. If recognized, an amount of $61.0 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of March 31, 2019 and December 31, 2018, accrued interest and penalties were $12.9 million and $11.6 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $10.0 million in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-19-000014:notes:149]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-19-000014:notes:150]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. On August 7, 2018, the Ninth Circuit withdrew the opinions filed on July 24, 2018 to allow time for the reconstituted panel to confer on the appeal. In Altera, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. The U.S. Tax Court had invalidated those regulations, in part because the Treasury Department failed to adequately consider significant taxpayer comments when adopting them. We continue to treat our stock-based compensation expense in accordance with the opinion of the Altera ruling. We also continue to monitor developments in this case and any impact it could have on our tax provision.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-19-000014:notes:151]
[same as prior period, unchanged from 0001262039-18-000040:notes:33]

[0001262039-19-000014:notes:152]
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2019 and March 31, 2018 were $1.7 million and $1.5 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-19-000014:notes:153]
[same as prior period, unchanged from 0001262039-18-000040:notes:186]

[0001262039-19-000014:notes:154]
[same as prior period, unchanged from 0001262039-18-000040:notes:187]

[0001262039-19-000014:notes:155]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-19-000014:notes:156]
|  | Three Months Ended |
| Revenue | March 31, 2019 |  | March 31, 2018 |
| Americas: |  |  |  |
| United States | $ | 150.3 |  |  | $ | 133.9 |  |
| Other Americas (1) | 50.2 |  |  | 41.9 |  |
| Total Americas | 200.5 |  |  | 175.8 |  |
| Europe, Middle East and Africa (“EMEA”) | 177.2 |  |  | 144.5 |  |
| Asia Pacific (“APAC”) | 94.9 |  |  | 78.7 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |
| (1) In 2019, Canada and Latin America revenue were combined and presented as Other Americas. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000014:notes:157]
| Property and Equipment—net | March 31, 2019 |  | December 31, 2018 |
| Americas: |  |  |  |
| United States | $ | 136.0 |  |  | $ | 132.1 |  |
| Canada | 111.8 |  |  | 113.5 |  |
| Latin America | 0.3 |  |  | 0.4 |  |
| Total Americas | 248.1 |  |  | 246.0 |  |
| EMEA (1) | 15.0 |  |  | 16.2 |  |
| APAC | 8.9 |  |  | 9.2 |  |
| Total property and equipment—net | $ | 272.0 |  |  | $ | 271.4 |  |
| (1) In 2019, France and Other EMEA property and equipment were combined and presented as EMEA. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000014:notes:158]
The following customers, each of which is a distributor, accounted for 10% or more of our revenue:

[0001262039-19-000014:notes:159]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Exclusive Networks Group | 30 | % |  | 29 | % |
| Ingram Micro | 11 | % |  | * |  |
| * Represents less than 10% |

[0001262039-19-000014:notes:160]
The following customers, each of which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-19-000014:notes:161]
|  | March 31, 2019 |  | December 31, 2018 |
| Exclusive Networks Group | 34 | % |  | 38 | % |
| Ingram Micro | 10 | % |  | * |  |
| * Represents less than 10% |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-19-000014:notes:162]
[same as prior period, unchanged from 0001262039-18-000040:notes:35]

[0001262039-19-000014:notes:163]
[same as prior period, unchanged from 0001262039-18-000040:notes:36]

[0001262039-19-000014:notes:164]
|  | Unrealized Losses on Investments |  | Tax benefit (provision) related to unrealized gains or losses on investments |  | Total |
| Balance—December 31, 2018 | $ | (1.3 | ) |  | $ | 0.5 |  |  | $ | (0.8 | ) |
| Other comprehensive income before reclassifications | 1.0 |  |  | (0.3 | ) |  | 0.7 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | (0.1 | ) |  | (0.1 | ) |
| Net current-period other comprehensive income | 1.0 |  |  | (0.4 | ) |  | 0.6 |  |
| Balance—March 31, 2019 | $ | (0.3 | ) |  | $ | 0.1 |  |  | $ | (0.2 | ) |

[0001262039-19-000014:notes:165]
We adopted ASU 2018-02 on January 1, 2019, and elected to reclassify the income tax effects of the 2017 Tax Act to retained earnings at the beginning of the period. Other amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in other expense—net and in provision for (benefit from) income taxes, respectively.
