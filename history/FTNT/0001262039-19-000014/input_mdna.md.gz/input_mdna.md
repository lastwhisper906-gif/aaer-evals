# FTNT MD&A — 0001262039-19-000014


## mdna

[0001262039-19-000014:mdna:1]
[same as prior period, unchanged from 0001262039-18-000040:mdna:1]

[0001262039-19-000014:mdna:2]
[same as prior period, unchanged from 0001262039-18-000040:mdna:2]

[0001262039-19-000014:mdna:3]
[same as prior period, unchanged from 0001262039-18-000040:mdna:3]

[0001262039-19-000014:mdna:4]
[same as prior period, unchanged from 0001262039-18-000040:mdna:4]

[0001262039-19-000014:mdna:5]
| • | the impact of macro-economic and geopolitical factors on our sales; |

[0001262039-19-000014:mdna:6]
[same as prior period, unchanged from 0001262039-18-000040:mdna:6]

[0001262039-19-000014:mdna:7]
[same as prior period, unchanged from 0001262039-18-000040:mdna:7]

[0001262039-19-000014:mdna:8]
| • | the effects of government regulation, tariffs and other related policies; |

[0001262039-19-000014:mdna:9]
[same as prior period, unchanged from 0001262039-18-000040:mdna:8]

[0001262039-19-000014:mdna:10]
[same as prior period, unchanged from 0001262039-18-000040:mdna:9]

[0001262039-19-000014:mdna:11]
[same as prior period, unchanged from 0001262039-18-000040:mdna:10]

[0001262039-19-000014:mdna:12]
[same as prior period, unchanged from 0001262039-18-000040:mdna:11]

[0001262039-19-000014:mdna:13]
| • | risks and expectations related to acquisitions or sales of assets, including integration issues related to product plans and products, including the acquired technology; |

[0001262039-19-000014:mdna:14]
[same as prior period, unchanged from 0001262039-18-000040:mdna:12]

[0001262039-19-000014:mdna:15]
[same as prior period, unchanged from 0001262039-18-000040:mdna:13]

[0001262039-19-000014:mdna:16]
| • | expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”); |

[0001262039-19-000014:mdna:17]
[same as prior period, unchanged from 0001262039-18-000040:mdna:16]

[0001262039-19-000014:mdna:18]
[same as prior period, unchanged from 0001262039-18-000040:mdna:17]

[0001262039-19-000014:mdna:19]
| • | statements regarding expected outcomes and liabilities in litigation; |

[0001262039-19-000014:mdna:20]
[same as prior period, unchanged from 0001262039-18-000040:mdna:18]

[0001262039-19-000014:mdna:21]
[same as prior period, unchanged from 0001262039-18-000040:mdna:19]

[0001262039-19-000014:mdna:22]
| • | adoption and impact of new accounting standards, including those related to accounting for leases. |

[0001262039-19-000014:mdna:23]
[same as prior period, unchanged from 0001262039-18-000040:mdna:21]

[0001262039-19-000014:mdna:24]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Security Fabric platform, which features automated protection, detection and responses.

[0001262039-19-000014:mdna:25]
The focus areas of our business consist of:

[0001262039-19-000014:mdna:26]
| • | Network Security—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, software-defined wide-area network, secure sockets layer data leak prevention, virtual private network, switch and wireless controller and wide area network edge. Our network security appliances include our FortiOS operating system, which provides the foundation for FortiGate security functions, and FortiASIC integrated circuit, which is designed to accelerate the processing of security and networking functions. Our customers may also purchase FortiGuard subscription services to receive threat intelligence updates. We provide standard technical support across all of our products through our FortiCare support services. We also offer services to end-customers including Technical Account Managers, Resident Engineers and professional service consultants for implementations, as well as training services to our end-customers and channel partners. |

[0001262039-19-000014:mdna:27]
| • | Fortinet Security Fabric—The Fortinet Security Fabric platform is an architectural approach that protects the entire digital attack surface, including network core, endpoints, applications, data centers and private and public cloud. Together with our network of Fabric-Ready Partners, the Fortinet Security Fabric platform enables disparate security devices to work together as an integrated, automated and collaborative solution. |

[0001262039-19-000014:mdna:28]
| • | Cloud Security—We help customers connect securely to and across their cloud environments by offering security through our virtual firewall and other software products in public and private cloud environments. Our Cloud Security solutions, including our Client Access Security Broker Solution, FortiCASB, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in cloud environments that they receive on their physical networks. Fortinet cloud security offerings are available across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and IBM Cloud. |

[0001262039-19-000014:mdna:29]
| • | Internet of Things and Operational Technology—The proliferation of Internet of Things (“IoT”) and the digitization of Operational Technology (“OT”) devices has generated new opportunities for us to grow our business. With both IOT and OT, network-connected devices are generating data that moves between devices, across locations and in private and public cloud environments; these networks and devices require cybersecurity to ensure their safety and privacy. |

[0001262039-19-000014:mdna:30]
[same as prior period, unchanged from 0001262039-18-000040:mdna:27]

[0001262039-19-000014:mdna:31]
| • | We recorded total revenue of $472.6 million during the three months ended March 31, 2019, an increase of 18% compared to $399.0 million in the same period last year. Product revenue was $162.7 million during the three months ended March 31, 2019, an increase of 14% compared to $142.8 million in the same period last year. Service revenue was $309.9 million during the three months ended March 31, 2019, an increase of 21% compared to $256.2 million in the same period last year. |

[0001262039-19-000014:mdna:32]
| • | We generated operating income of $50.6 million during the three months ended March 31, 2019, an increase of 56% compared to $32.4 million in the same period last year. |

[0001262039-19-000014:mdna:33]
25

[0001262039-19-000014:mdna:34]
| • | Cash, cash equivalents and investments were $1.85 billion as of March 31, 2019, an increase of $135.4 million, or 8%, from December 31, 2018. |

[0001262039-19-000014:mdna:35]
| • | Deferred revenue was $1.77 billion as of March 31, 2019, an increase of $79.0 million, or 5%, from December 31, 2018. |

[0001262039-19-000014:mdna:36]
| • | We generated cash flows from operating activities of $201.3 million during the three months ended March 31, 2019, an increase of $61.6 million, or 44%, compared to the same period last year. |

[0001262039-19-000014:mdna:37]
| • | During the three months ended March 31, 2019, we repurchased 0.8 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”) for an aggregate purchase price of $56.2 million. |

[0001262039-19-000014:mdna:38]
During the three months ended March 31, 2019, our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 14% during the three months ended March 31, 2019 compared to the same period last year. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, also grew compared to the same period last year. Service revenue growth of 21% during the three months ended March 31, 2019 compared to the same period last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 24% compared to the same period last year, and FortiCare technical support and other service revenue, which grew 17% compared to the same period last year.

[0001262039-19-000014:mdna:39]
The percentage of our FortiGate-related billings from entry-level products decreased from 36% during the three months ended March 31, 2018 to 34% during the three months ended March 31, 2019. The percentage of our FortiGate-related billings from mid-range products increased from 31% during the three months ended March 31, 2018 to 34% during the three months ended March 31, 2019. The percentage of our FortiGate-related billings from high-end products decreased from 33% during the three months ended March 31, 2018 to 32% during the three months ended March 31, 2019.

[0001262039-19-000014:mdna:40]
During the three months ended March 31, 2019, operating expenses as a percentage of revenue decreased by three percentage points compared to the same period last year. Headcount increased by 3% to 6,015 employees and contractors as of March 31, 2019, up from 5,845 as of December 31, 2018.

[0001262039-19-000014:mdna:41]
[same as prior period, unchanged from 0001262039-18-000040:mdna:38]

[0001262039-19-000014:mdna:42]
Our sales strategy is based on a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and service providers, who in turn sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across major cloud providers, and have recognized on-demand revenue from Amazon Web Services, Microsoft Azure and IBM Cloud from customers who deploy our products at a cloud services provider in a bring-your-own-license (“BYOL”) such as from Amazon Web Services, Microsoft Azure, Google Cloud and Oracle Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud. While the revenue from such sales is still relatively insignificant, it has increased compared to the same period last year on a percentage basis.

[0001262039-19-000014:mdna:43]
Typically, our customers purchase our hardware products and software licenses, as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is typically payable within 30 to 45 days. We also invoice certain services on a monthly basis.

[0001262039-19-000014:mdna:44]
Our Security Processing Unit (“SPU”) hardware architecture is an important part of our approach to network security. The SPU includes three lines of proprietary Application-Specific Integrated Circuits (“ASICs”): the Content Processor, the Network Processor and the System-on-a-Chip. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-19-000014:mdna:45]
[same as prior period, unchanged from 0001262039-18-000040:mdna:43]

[0001262039-19-000014:mdna:46]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating

[0001262039-19-000014:mdna:47]
activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-19-000014:mdna:48]
|  | Three Months Ended Or As Of |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (in millions) |
| Revenue | $ | 472.6 |  |  | $ | 399.0 |  |
| Deferred revenue | $ | 1,765.8 |  |  | $ | 1,396.4 |  |
| Billings (non-GAAP) | $ | 551.6 |  |  | $ | 463.2 |  |
| Net cash provided by operating activities | $ | 201.3 |  |  | $ | 139.7 |  |
| Free cash flow (non-GAAP) | $ | 191.1 |  |  | $ | 128.1 |  |

[0001262039-19-000014:mdna:49]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $1.77 billion as of March 31, 2019, an increase of $79.0 million, or 5%, from December 31, 2018.

[0001262039-19-000014:mdna:50]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $551.6 million for the three months ended March 31, 2019, an increase of 19% compared to $463.2 million in the same period last year.

[0001262039-19-000014:mdna:51]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-19-000014:mdna:52]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 472.6 |  |  | $ | 399.0 |  |
| Add: Change in deferred revenue | 79.0 |  |  | 60.1 |  |
| Add: Deferred revenue adjustment due to adoption of the new revenue recognition standard | — |  |  | 4.1 |  |
| Total billings (non-GAAP) | $ | 551.6 |  |  | $ | 463.2 |  |

[0001262039-19-000014:mdna:53]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting

[0001262039-19-000014:mdna:54]
27

[0001262039-19-000014:mdna:55]
cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-19-000014:mdna:56]
A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-19-000014:mdna:57]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 201.3 |  |  | $ | 139.7 |  |
| Less: Purchases of property and equipment | (10.2 | ) |  | (11.6 | ) |
| Free cash flow (non-GAAP) | $ | 191.1 |  |  | $ | 128.1 |  |
| Net cash used in investing activities | $ | (39.0 | ) |  | $ | (25.5 | ) |
| Net cash used in financing activities | $ | (57.8 | ) |  | $ | (89.6 | ) |

[0001262039-19-000014:mdna:58]
[same as prior period, unchanged from 0001262039-18-000040:mdna:52]

[0001262039-19-000014:mdna:59]
[same as prior period, unchanged from 0001262039-18-000040:mdna:53]

[0001262039-19-000014:mdna:60]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2019, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 27, 2019 (the “Form 10-K”).

[0001262039-19-000014:mdna:61]
[same as prior period, unchanged from 0001262039-18-000040:mdna:55]

[0001262039-19-000014:mdna:62]
See Note 1 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information regarding recent accounting pronouncements.

[0001262039-19-000014:mdna:63]
[same as prior period, unchanged from 0001262039-18-000040:mdna:57]

[0001262039-19-000014:mdna:64]
Three Months Ended March 31, 2019 and March 31, 2018

[0001262039-19-000014:mdna:65]
[same as prior period, unchanged from 0001262039-18-000040:mdna:59]

[0001262039-19-000014:mdna:66]
|  | Three Months Ended |  |  |  |  |
| March 31, 2019 |  | March 31, 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 162.7 |  |  | 34 | % |  | $ | 142.8 |  |  | 36 | % |  | $ | 19.9 |  |  | 14 | % |
| Service | 309.9 |  |  | 66 |  |  | 256.2 |  |  | 64 |  |  | 53.7 |  |  | 21 |  |
| Total revenue | $ | 472.6 |  |  | 100 | % |  | $ | 399.0 |  |  | 100 | % |  | $ | 73.6 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 200.5 |  |  | 42 | % |  | $ | 175.8 |  |  | 44 | % |  | $ | 24.7 |  |  | 14 | % |
| Europe, Middle East and Africa (“EMEA”) | 177.2 |  |  | 38 |  |  | 144.5 |  |  | 36 |  |  | 32.7 |  |  | 23 |  |
| Asia Pacific (“APAC”) | 94.9 |  |  | 20 |  |  | 78.7 |  |  | 20 |  |  | 16.2 |  |  | 21 |  |
| Total revenue | $ | 472.6 |  |  | 100 | % |  | $ | 399.0 |  |  | 100 | % |  | $ | 73.6 |  |  | 18 | % |

[0001262039-19-000014:mdna:67]
Total revenue increased by $73.6 million, or 18%, during the three months ended March 31, 2019 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all regions grew, with EMEA and APAC contributing the largest portion of our revenue growth on a percentage basis.

[0001262039-19-000014:mdna:68]
Product revenue increased by $19.9 million, or 14%, during the three months ended March 31, 2019 compared to the same period last year. We experienced revenue growth across several of our hardware and software products, including FortiGate appliances, for which unit shipments increased year-over-year. Service revenue increased by $53.7 million, or 21%, during the three months ended March 31, 2019 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support and other contracts sold to a larger customer base, as well as the renewals of similar contracts sold in the quarter and earlier periods.

[0001262039-19-000014:mdna:69]
[same as prior period, unchanged from 0001262039-18-000040:mdna:65]

[0001262039-19-000014:mdna:70]
|  | Three Months Ended |  |  |  |  |
| March 31, 2019 |  | March 31, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 70.2 |  |  | $ | 58.2 |  |  | $ | 12.0 |  |  | 21 | % |
| Service | 42.8 |  |  | 39.0 |  |  | 3.8 |  |  | 10 |  |
| Total cost of revenue | $ | 113.0 |  |  | $ | 97.2 |  |  | $ | 15.8 |  |  | 16 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.9 | % |  | 59.2 | % |  |  |  |  |
| Service | 86.2 |  |  | 84.8 |  |  |  |  |  |
| Total gross margin | 76.1 | % |  | 75.6 | % |  |  |  |  |

[0001262039-19-000014:mdna:71]
Total gross margin increased by 0.5 percentage points during the three months ended March 31, 2019 compared to the same period last year, driven by higher service revenue, which has a higher margin than product revenue. Service gross margin increased by 1.4 percentage points during the three months ended March 31, 2019 compared to the same period last year, as our

[0001262039-19-000014:mdna:72]
FortiGuard security subscription and FortiCare technical support and other service revenue grew 24% and 17%, respectively, during the three months ended March 31, 2019 compared to the same period last year, which outpaced the increase in the related personnel costs and headcount growth, resulting in a higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 2.3 percentage points during the three months ended March 31, 2019 compared to the same period last year. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-19-000014:mdna:73]
[same as prior period, unchanged from 0001262039-18-000040:mdna:71]

[0001262039-19-000014:mdna:74]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2019 |  | March 31, 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 68.6 |  |  | 14% |  | $ | 59.1 |  |  | 15 | % |  | $ | 9.5 |  |  | 16 | % |
| Sales and marketing | 215.9 |  |  | 46 |  | 185.3 |  |  | 46 |  |  | 30.6 |  |  | 17 |  |
| General and administrative | 24.5 |  |  | 5 |  | 25.0 |  |  | 6 |  |  | (0.5 | ) |  | (2 | ) |
| Total operating expenses | $ | 309.0 |  |  | 65% |  | $ | 269.4 |  |  | 68 | % |  | $ | 39.6 |  |  | 15 | % |

[0001262039-19-000014:mdna:75]
[same as prior period, unchanged from 0001262039-18-000040:mdna:75]

[0001262039-19-000014:mdna:76]
Research and development expense increased by $9.5 million, or 16%, during the three months ended March 31, 2019 compared to the same period last year, primarily due to an increase of $7.1 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000014:mdna:77]
[same as prior period, unchanged from 0001262039-18-000040:mdna:77]

[0001262039-19-000014:mdna:78]
Sales and marketing expense increased by $30.6 million, or 17%, during the three months ended March 31, 2019 compared to the same period last year, primarily due to an increase of $22.1 million in personnel-related costs, including higher stock-based compensation expense of $4.5 million, as sales and marketing headcount increased in order to drive market share gains globally. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000014:mdna:79]
[same as prior period, unchanged from 0001262039-18-000040:mdna:79]

[0001262039-19-000014:mdna:80]
General and administrative expense decreased by $0.5 million, or 2%, during the three months ended March 31, 2019 compared to the same period last year, primarily due to a decrease of $2.6 million in professional services cost. The decrease in expense was offset by an increase of $1.0 million in legal expenses and an increase of $0.8 million in personnel-related costs as we continued to increase headcount in order to support our expanding business. We expect general and administrative expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000014:mdna:81]
Interest income and other expense—net

[0001262039-19-000014:mdna:82]
|  | Three Months Ended |  |  |  |  |
| March 31, 2019 |  | March 31, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 10.2 |  |  | $ | 4.5 |  |  | $ | 5.7 |  |  | 127 | % |
| Other expense—net | (0.5 | ) |  | (0.2 | ) |  | (0.3 | ) |  | 150 |  |

[0001262039-19-000014:mdna:83]
Interest income increased during the three months ended March 31, 2019 compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net during the three months ended March 31, 2019 compared to the same period last year was primarily due to higher foreign currency exchange losses.

[0001262039-19-000014:mdna:84]
Provision for (benefit from) income taxes

[0001262039-19-000014:mdna:85]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2019 |  | March 31, 2018 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 1.5 |  |  | $ | (4.9 | ) |  | $ | 6.4 |  |  | (131 | )% |
| Effective tax rate (%) | 2 | % |  | (13 | )% |  |  |  |  |  |  |

[0001262039-19-000014:mdna:86]
Our effective tax rate was 2% for the three months ended March 31, 2019 compared to an effective tax rate benefit of 13% for the same period last year. The effective tax rate for the three months ended March 31, 2019 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $17.5 million, which were offset by a tax benefit of $16.0 million for stock-based compensation expense. The tax rate for the three months ended March 31, 2018 was comprised of the U.S. federal and state taxes, withholding taxes and foreign taxes of $8.5 million, which were offset by a tax benefit of $5.6 million for stock-based compensation expense and release of reserves of $7.8 million on uncertain tax positions including interest due to the close of the Internal Revenue Service (“IRS”) audit.

[0001262039-19-000014:mdna:87]
[same as prior period, unchanged from 0001262039-18-000040:mdna:132]

[0001262039-19-000014:mdna:88]
|  | As of |
|  | March 31, 2019 |  | December 31, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,216.9 |  |  | $ | 1,112.4 |  |
| Investments | 635.1 |  |  | 604.2 |  |
| Total cash, cash equivalents and investments | $ | 1,852.0 |  |  | $ | 1,716.6 |  |
| Working capital | $ | 1,059.0 |  |  | $ | 964.5 |  |
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 201.3 |  |  | $ | 139.7 |  |
| Net cash used in investing activities | (39.0 | ) |  | (25.5 | ) |
| Net cash used in financing activities | (57.8 | ) |  | (89.6 | ) |
| Net increase in cash and cash equivalents | $ | 104.5 |  |  | $ | 24.6 |  |

[0001262039-19-000014:mdna:89]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our equity incentive plans and payment of taxes in connection with the net settlement of equity awards. In recent years, we have received significant capital resources from billings, the exercise of stock options and ESPP purchases. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. We expect there to be no future proceeds from purchases under our ESPP, which was terminated in February 2019. As of March 31, 2019, $677.5 million remained available for future share repurchase under the Repurchase Program.

[0001262039-19-000014:mdna:90]
31

[0001262039-19-000014:mdna:91]
Construction of our new headquarters building started in the fourth quarter of 2018 and related spending will continue in 2019 and until project completion. We estimate 2019 spending on the project to be between $60.0 million to $80.0 million dollars.

[0001262039-19-000014:mdna:92]
As of March 31, 2019, our cash, cash equivalents and investments of $1.85 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-19-000014:mdna:93]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $151.8 million as of March 31, 2019 and $956.6 million as of December 31, 2018. The decrease in cash, cash equivalents and investments held by our international subsidiaries was due to our international tax restructure.

[0001262039-19-000014:mdna:94]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products and our investments in purchasing or leasing real estate. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-19-000014:mdna:95]
[same as prior period, unchanged from 0001262039-18-000040:mdna:139]

[0001262039-19-000014:mdna:96]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities, including deferred revenue. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums, net of accretion of purchase discounts.

[0001262039-19-000014:mdna:97]
Our operating activities during the three months ended March 31, 2019 provided $201.3 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew 26% as of March 31, 2019 compared to the same period last year to $1.77 billion.

[0001262039-19-000014:mdna:98]
Our operating activities during the three months ended March 31, 2018 provided $139.7 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable. Our total deferred revenue balance grew 27% during the three months ended March 31, 2018 compared to the same period last year.

[0001262039-19-000014:mdna:99]
[same as prior period, unchanged from 0001262039-18-000040:mdna:143]

[0001262039-19-000014:mdna:100]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believed that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with a future business combination.

[0001262039-19-000014:mdna:101]
During the three months ended March 31, 2019, cash used in investing activities was primarily due to $28.8 million spent for purchases of investments, net of maturities and sales of investments and $10.2 million spent on capital expenditures.

[0001262039-19-000014:mdna:102]
During the three months ended March 31, 2018, cash used in investing activities was primarily due to $13.9 million spent for purchases of investments, net of maturities and sales of investments, and $11.6 million spent on capital expenditures.

[0001262039-19-000014:mdna:103]
[same as prior period, unchanged from 0001262039-18-000040:mdna:147]

[0001262039-19-000014:mdna:104]
The changes in cash flows from financing activities primarily relate to cash payments for the repurchase and retirement of common stock, proceeds from the issuance of common stock under our equity incentive plans and taxes paid related to net share settlement of equity awards.

[0001262039-19-000014:mdna:105]
During the three months ended March 31, 2019, cash used in financing activities was $57.8 million, primarily due to $60.4 million used to repurchase our common stock. This was partially offset by $2.6 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000014:mdna:106]
During the three months ended March 31, 2018, cash used in financing activities was $89.6 million, primarily due to $115.5 million used to repurchase our common stock. This was partially offset by $25.9 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000014:mdna:107]
[same as prior period, unchanged from 0001262039-18-000040:mdna:151]

[0001262039-19-000014:mdna:108]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2019 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-19-000014:mdna:109]
[same as prior period, unchanged from 0001262039-18-000040:mdna:154]

[0001262039-19-000014:mdna:110]
As of March 31, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
