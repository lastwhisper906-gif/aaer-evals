# FTNT 8-K — 0001262039-19-000010 filed 2019-05-02

## item codes, every 8-K on or before 2019-05-08

- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2019-05-08

- none on or before 2019-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-19-000010:8k_2_02:1]
EX-99.1
2
ftntq1-2019ex991.htm
PRESS RELEASE

[0001262039-19-000010:8k_2_02:2]
Exhibit

[0001262039-19-000010:8k_2_02:3]
Press Release

[0001262039-19-000010:8k_2_02:4]
Fortinet Reports First Quarter 2019 Financial Results

[0001262039-19-000010:8k_2_02:5]
First Quarter 2019 Highlights

[0001262039-19-000010:8k_2_02:6]
| • | Revenue of $472.6 million, up 18% year over year |

[0001262039-19-000010:8k_2_02:7]
| • | Billings of $551.6 million, up 19% year over year1 |

[0001262039-19-000010:8k_2_02:8]
| • | Deferred revenue of $1.77 billion, up 26% year over year |

[0001262039-19-000010:8k_2_02:9]
| • | GAAP operating margin of 11% |

[0001262039-19-000010:8k_2_02:10]
| • | Non-GAAP operating margin of 20%1 |

[0001262039-19-000010:8k_2_02:11]
| • | GAAP diluted net income per share of $0.34 |

[0001262039-19-000010:8k_2_02:12]
| • | Non-GAAP diluted net income per share of $0.461 |

[0001262039-19-000010:8k_2_02:13]
| • | Cash flow from operations of $201.3 million |

[0001262039-19-000010:8k_2_02:14]
| • | Free cash flow of $191.1 million1 |

[0001262039-19-000010:8k_2_02:15]
SUNNYVALE, Calif. - May 2, 2019 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the first quarter ended March 31, 2019.

[0001262039-19-000010:8k_2_02:16]
“We had an excellent start to the year demonstrating the strong demand for our product and services,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “We expect 2019 to be another year of better-than-industry growth, driven by the momentum in our business and strong customer demand for our broad, integrated and automated Security Fabric platform.”

[0001262039-19-000010:8k_2_02:17]
Financial Highlights for the First Quarter of 2019

[0001262039-19-000010:8k_2_02:18]
| • | Revenue: Total revenue was $472.6 million for the first quarter of 2019, an increase of 18% compared to $399.0 million for the same quarter of 2018. |

[0001262039-19-000010:8k_2_02:19]
| • | Product revenue was $162.7 million for the first quarter of 2019, an increase of 14% compared to $142.8 million for the same quarter of 2018. |

[0001262039-19-000010:8k_2_02:20]
| • | Service revenue was $309.9 million for the first quarter of 2019, an increase of 21% compared to $256.2 million for the same quarter of 2018. |

[0001262039-19-000010:8k_2_02:21]
| • | Billings1: Total billings were $551.6 million for the first quarter of 2019, an increase of 19% compared to $463.2 million for the same quarter of 2018. |

[0001262039-19-000010:8k_2_02:22]
| • | Deferred Revenue: Total deferred revenue was $1.77 billion as of March 31, 2019, an increase of 26% compared to $1.40 billion as of March 31, 2018. |

[0001262039-19-000010:8k_2_02:23]
| • | GAAP Operating Income and Margin: GAAP operating income was $50.6 million for the first quarter of 2019, representing a GAAP operating margin of 11%. GAAP operating income was $32.4 million for the same quarter of 2018, representing a GAAP operating margin of 8%. |

[0001262039-19-000010:8k_2_02:24]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $96.6 million for the first quarter of 2019, representing a non-GAAP operating margin of 20%. Non-GAAP operating income was $70.7 million for the first quarter of 2018, representing a non-GAAP operating margin of 18%. |

[0001262039-19-000010:8k_2_02:25]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $58.8 million for the first quarter of 2019, compared to GAAP net income of $41.6 million for the same quarter of 2018. GAAP diluted net income per share was $0.34 for the first quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.24 for the same quarter of 2018, based on 171.8 million diluted weighted-average shares outstanding. |

[0001262039-19-000010:8k_2_02:26]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $80.8 million for the first quarter of 2019, compared to non-GAAP net income of $57.0 million for the same quarter of 2018. Non-GAAP diluted net income per share was $0.46 for the first quarter of 2019, based on 174.8 million diluted weighted-average shares outstanding, compared to $0.33 for the same quarter of 2018, based on 171.8 million diluted weighted-average shares outstanding. |

[0001262039-19-000010:8k_2_02:27]
| • | Cash Flow and Free Cash Flow1: In the first quarter of 2019, cash flow from operations was $201.3 million compared to $139.7 million in the same quarter of 2018. Free cash flow was $191.1 million during the first quarter of 2019, compared to $128.1 million for the same quarter of 2018. |

[0001262039-19-000010:8k_2_02:28]
Guidance

[0001262039-19-000010:8k_2_02:29]
For the second quarter of 2019, Fortinet currently expects:

[0001262039-19-000010:8k_2_02:30]
| • | Revenue in the range of $505 million to $515 million |

[0001262039-19-000010:8k_2_02:31]
| • | Billings in the range of $585 million to $605 million |

[0001262039-19-000010:8k_2_02:32]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000010:8k_2_02:33]
| • | Non-GAAP operating margin in the range of 22.0% to 22.5% |

[0001262039-19-000010:8k_2_02:34]
| • | Diluted non-GAAP net income per share in the range of $0.49 to $0.51, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 177 million to 179 million |

[0001262039-19-000010:8k_2_02:35]
For the fiscal year 2019, Fortinet currently expects:

[0001262039-19-000010:8k_2_02:36]
| • | Revenue in the range of $2.07 billion to $2.10 billion |

[0001262039-19-000010:8k_2_02:37]
| • | Service revenue in the range of $1.34 billion to $1.36 billion |

[0001262039-19-000010:8k_2_02:38]
| • | Billings in the range of $2.47 billion to $2.52 billion |

[0001262039-19-000010:8k_2_02:39]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000010:8k_2_02:40]
| • | Non-GAAP operating margin in the range of 22.5% to 23.5% |

[0001262039-19-000010:8k_2_02:41]
| • | Diluted non-GAAP net income per share in the range of $2.10 to $2.15, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 178 million to 180 million |

[0001262039-19-000010:8k_2_02:42]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-19-000010:8k_2_02:43]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-19-000010:8k_2_02:44]
Conference Call Details

[0001262039-19-000010:8k_2_02:45]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 9894018. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through May 9, 2019, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #9894018.

[0001262039-19-000010:8k_2_02:46]
Second Quarter 2019 Investor Conference Participation Schedule:

[0001262039-19-000010:8k_2_02:47]
| • | Jefferies 2019 Software Conference - Interactions! (Meetings Only) |

[0001262039-19-000010:8k_2_02:48]
May 8-9, 2019 - Beverly Hills, CA

[0001262039-19-000010:8k_2_02:49]
| • | 47th Annual J.P. Morgan Global Technology, Media and Communications Conference |

[0001262039-19-000010:8k_2_02:50]
May 14, 2019 - Boston, MA

[0001262039-19-000010:8k_2_02:51]
| • | Baird 2019 Global Consumer, Technology & Services Conference (Meetings Only) |

[0001262039-19-000010:8k_2_02:52]
June 4, 2019 - New York, NY

[0001262039-19-000010:8k_2_02:53]
| • | William Blair 39th Annual Growth Stock Conference |

[0001262039-19-000010:8k_2_02:54]
June 5, 2019 - Chicago, IL

[0001262039-19-000010:8k_2_02:55]
| • | Bank of America Merrill Lynch 2019 Global Technology Conference |

[0001262039-19-000010:8k_2_02:56]
June 6, 2019 - San Francisco, CA

[0001262039-19-000010:8k_2_02:57]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-19-000010:8k_2_02:58]
About Fortinet (www.fortinet.com)

[0001262039-19-000010:8k_2_02:59]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical

[0001262039-19-000010:8k_2_02:60]
security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-19-000010:8k_2_02:61]
#          #          #

[0001262039-19-000010:8k_2_02:62]
Copyright © 2019 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, ABACAS, APSecure, FortiADC, FortiAI, FortiAntenna, FortiAP, FortiAppMonitor, FortiAuthenticator, FortiBIOS, FortiBridge, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiDB, FortiDDoS, FortiDeceptor, FortiExplorer, FortiExtender, FortiFone, FortiHypervisor, FortiInsight, FortiIsolator, FortiLog, FortiMeter, FortiMonitor, FortiNAC, FortiPartner, FortiPlanner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiRescue, FortiSIEM, FortiSMS, FortiSwitch, FortiTester, FortiToken, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-19-000010:8k_2_02:63]
FTNT-F

[0001262039-19-000010:8k_2_02:64]
Forward-looking Statements

[0001262039-19-000010:8k_2_02:65]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, our expectations of growth in 2019, statements regarding the momentum in our business and all guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith;

[0001262039-19-000010:8k_2_02:66]
sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments; competition and pricing pressure; tariffs and other trade barriers; any political and government disruption around the world, including the impact of any future shutdowns of the U.S. government; and the other risk factors set forth from time to

[0001262039-19-000010:8k_2_02:67]
Non-GAAP Financial Measures

[0001262039-19-000010:8k_2_02:68]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-19-000010:8k_2_02:69]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-19-000010:8k_2_02:70]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-19-000010:8k_2_02:71]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities

[0001262039-19-000010:8k_2_02:72]
is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and

[0001262039-19-000010:8k_2_02:73]
Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-19-000010:8k_2_02:74]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-19-000010:8k_2_02:75]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on sale of investments in privately held companies as well as impairment, and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-19-000010:8k_2_02:76]
FORTINET, INC.

[0001262039-19-000010:8k_2_02:77]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-19-000010:8k_2_02:78]
(Unaudited, in millions)

[0001262039-19-000010:8k_2_02:79]
|  | March 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,216.9 |  |  | $ | 1,112.4 |  |
| Short-term investments | 584.9 |  |  | 537.2 |  |
| Accounts receivable—net | 381.0 |  |  | 444.5 |  |
| Inventory | 88.4 |  |  | 90.0 |  |
| Prepaid expenses and other current assets | 42.1 |  |  | 36.8 |  |
| Total current assets | 2,313.3 |  |  | 2,220.9 |  |
| LONG-TERM INVESTMENTS | 50.2 |  |  | 67.0 |  |
| PROPERTY AND EQUIPMENT—NET | 272.0 |  |  | 271.4 |  |
| DEFERRED CONTRACT COSTS | 190.5 |  |  | 182.6 |  |
| DEFERRED TAX ASSETS | 262.7 |  |  | 255.0 |  |
| GOODWILL | 38.2 |  |  | 38.2 |  |
| OTHER INTANGIBLE ASSETS—NET | 19.1 |  |  | 22.1 |  |
| OTHER ASSETS | 59.7 |  |  | 20.8 |  |
| TOTAL ASSETS | $ | 3,205.7 |  |  | $ | 3,078.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 69.2 |  |  | $ | 86.4 |  |
| Accrued liabilities | 88.7 |  |  | 77.5 |  |
| Accrued payroll and compensation | 81.0 |  |  | 98.4 |  |
| Income taxes payable | 24.3 |  |  | 28.2 |  |
| Deferred revenue | 991.1 |  |  | 965.9 |  |
| Total current liabilities | 1,254.3 |  |  | 1,256.4 |  |
| DEFERRED REVENUE | 774.7 |  |  | 720.9 |  |
| INCOME TAX LIABILITIES | 80.7 |  |  | 77.5 |  |
| OTHER LIABILITIES | 37.9 |  |  | 13.0 |  |
| Total liabilities | 2,147.6 |  |  | 2,067.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,108.1 |  |  | 1,068.3 |  |
| Accumulated other comprehensive loss | (0.2 | ) |  | (0.8 | ) |
| Accumulated deficit | (50.0 | ) |  | (57.5 | ) |
| Total stockholders’ equity | 1,058.1 |  |  | 1,010.2 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,205.7 |  |  | $ | 3,078.0 |  |

[0001262039-19-000010:8k_2_02:80]
FORTINET, INC.

[0001262039-19-000010:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-19-000010:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000010:8k_2_02:83]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| REVENUE: |  |  |  |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service | 309.9 |  |  | 256.2 |  |
| Total revenue | 472.6 |  |  | 399.0 |  |
| COST OF REVENUE: |  |  |  |
| Product | 70.2 |  |  | 58.2 |  |
| Service | 42.8 |  |  | 39.0 |  |
| Total cost of revenue | 113.0 |  |  | 97.2 |  |
| GROSS PROFIT: |  |  |  |
| Product | 92.5 |  |  | 84.6 |  |
| Service | 267.1 |  |  | 217.2 |  |
| Total gross profit | 359.6 |  |  | 301.8 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development | 68.6 |  |  | 59.1 |  |
| Sales and marketing | 215.9 |  |  | 185.3 |  |
| General and administrative | 24.5 |  |  | 25.0 |  |
| Total operating expenses | 309.0 |  |  | 269.4 |  |
| OPERATING INCOME | 50.6 |  |  | 32.4 |  |
| INTEREST INCOME | 10.2 |  |  | 4.5 |  |
| OTHER EXPENSE—NET | (0.5 | ) |  | (0.2 | ) |
| INCOME BEFORE INCOME TAXES | 60.3 |  |  | 36.7 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 1.5 |  |  | (4.9 | ) |
| NET INCOME | $ | 58.8 |  |  | $ | 41.6 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.25 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.24 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 170.2 |  |  | 167.7 |  |
| Diluted | 174.8 |  |  | 171.8 |  |

[0001262039-19-000010:8k_2_02:84]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-19-000010:8k_2_02:85]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000010:8k_2_02:86]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-19-000010:8k_2_02:87]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Net cash provided by operating activities | $ | 201.3 |  |  | $ | 139.7 |  |
| Less: Purchases of property and equipment | (10.2 | ) |  | (11.6 | ) |
| Free cash flow | $ | 191.1 |  |  | $ | 128.1 |  |
| Net cash used in investing activities | $ | (39.0 | ) |  | $ | (25.5 | ) |
| Net cash used in financing activities | $ | (57.8 | ) |  | $ | (89.6 | ) |

[0001262039-19-000010:8k_2_02:88]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-19-000010:8k_2_02:89]
|  | Three Months Ended March 31, 2019 |  | Three Months Ended March 31, 2018 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 50.6 |  |  | $ | 46.0 |  | (a) | $ | 96.6 |  |  | $ | 32.4 |  |  | $ | 38.3 |  | (b) | $ | 70.7 |  |
| Operating margin | 11 | % |  |  |  | 20 | % |  | 8 | % |  |  |  | 18 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 43.0 |  |  |  |  |  |  | 36.5 |  |  |  |
| Amortization of acquired intangible assets |  |  | 3.0 |  |  |  |  |  |  | 1.8 |  |  |  |
| Tax adjustment |  |  | (24.0 | ) | (c) |  |  |  |  | (22.9 | ) | (c) |  |
| Net income | $ | 58.8 |  |  | $ | 22.0 |  |  | $ | 80.8 |  |  | $ | 41.6 |  |  | $ | 15.4 |  |  | $ | 57.0 |  |
| Diluted net income per share | $ | 0.34 |  |  |  |  | $ | 0.46 |  |  | $ | 0.24 |  |  |  |  | $ | 0.33 |  |
| Shares used in diluted net income per share calculations | 174.8 |  |  |  |  | 174.8 |  |  | 171.8 |  |  |  |  | 171.8 |  |

[0001262039-19-000010:8k_2_02:90]
(a) To exclude $43.0 million of stock-based compensation and $3.0 million of amortization of acquired intangible assets in the three months ended March 31, 2019.

[0001262039-19-000010:8k_2_02:91]
(b) To exclude $36.5 million of stock-based compensation and $1.8 million of amortization of acquired intangible assets in the three months ended March 31, 2018.

[0001262039-19-000010:8k_2_02:92]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 24% in 2019 and 2018, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-19-000010:8k_2_02:93]
Reconciliation of total revenue to total billings

[0001262039-19-000010:8k_2_02:94]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |
| Add: Change in deferred revenue | 79.0 |  |  | 60.1 |  |
| Add: Deferred revenue adjustment due to adoption of the new revenue recognition standard | — |  |  | 4.1 |  |
| Total billings | $ | 551.6 |  |  | $ | 463.2 |  |

[0001262039-19-000010:8k_2_02:95]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
