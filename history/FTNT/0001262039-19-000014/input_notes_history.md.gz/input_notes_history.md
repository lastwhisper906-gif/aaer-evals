# FTNT note change history — 0001262039-18-000040 → 0001262039-19-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0001262039-19-000014:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2019 (in millions):
  (was, 2018-11-07, similarity 0.9537):
[0001262039-18-000040:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2018 (in millions):

- added (2019-05-08):
[0001262039-19-000014:note_history:2]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 202.2 |  |  | $ | 191.4 |  |  | $ | 10.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

- changed (2019-05-08):
[0001262039-19-000014:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2019, we had $202.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2018-11-07, similarity 0.9897):
[0001262039-18-000040:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2018, we had $174.0 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2019-05-08):
[0001262039-19-000014:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2019, we had $15.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2018-11-07, similarity 0.9823):
[0001262039-18-000040:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2018, we had $11.6 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2019-05-08):
[0001262039-19-000014:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2018-11-07, similarity 0.6996):
[0001262039-18-000040:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and there can be no assurances and the outcome of these matters is currently not determinable. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- added (2019-05-08):
[0001262039-19-000014:note_history:6]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information on events from over two years ago related to our compliance with the Trade Agreements Act. We cooperated with the inquiry, and settled this matter with the United States Attorney’s Office.

- removed (2019-05-08):
[0001262039-18-000040:note_history:7]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 52.0 |  |  | $ | 4.1 |  |  | $ | 15.3 |  |  | $ | 11.6 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |
| Inventory purchase commitments | 174.0 |  |  | 111.1 |  |  | 58.7 |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 226.0 |  |  | $ | 115.2 |  |  | $ | 74.0 |  |  | $ | 15.8 |  |  | $ | 8.0 |  |  | $ | 5.0 |  |  | $ | 8.0 |  |

- removed (2019-05-08):
[0001262039-18-000040:note_history:8]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.4 million and $4.1 million during the three months ended September 30, 2018 and September 30, 2017, respectively. Rent expense was $13.1 million and $12.5 million during the nine months ended September 30, 2018 and September 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- removed (2019-05-08):
[0001262039-18-000040:note_history:9]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter. We are currently in settlement discussions with the United States Attorney’s Office.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-08):
[0001262039-19-000014:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.
  (was, 2018-11-07, similarity 0.9752):
[0001262039-18-000040:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

- changed (2019-05-08):
[0001262039-19-000014:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.
  (was, 2018-11-07, similarity 0.8058):
[0001262039-18-000040:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.

- added (2019-05-08):
[0001262039-19-000014:note_history:12]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to not reassess whether arrangements contain leases, not reassess lease classification and not reassess initial direct costs.

- added (2019-05-08):
[0001262039-19-000014:note_history:13]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less and does not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

- added (2019-05-08):
[0001262039-19-000014:note_history:14]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred

- added (2019-05-08):
[0001262039-19-000014:note_history:15]
rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.

- added (2019-05-08):
[0001262039-19-000014:note_history:16]
The ROU assets and the short-term and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our condensed consolidated balance sheets, respectively. Our accounting for finance leases (formerly referred to as capital leases prior to the adoption of Topic 842) remains substantially unchanged. Finance leases are not material to our condensed consolidated financial statements.

- added (2019-05-08):
[0001262039-19-000014:note_history:17]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease.

- changed (2019-05-08):
[0001262039-19-000014:note_history:18]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.
  (was, 2018-11-07, similarity 0.7215):
[0001262039-18-000040:note_history:18]
In February 2018, the FASB issued ASU 2018-02—Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017 (the “2017 Tax Act”), from accumulated other comprehensive income to retained earnings. ASU 2018-02 also requires certain new disclosures regardless of the election. ASU 2018-02 is effective for us beginning January 1, 2019, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-02 on our consolidated financial statements.

- added (2019-05-08):
[0001262039-19-000014:note_history:19]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019, ASU 2018-07 did not have a material impact to our condensed consolidated financial statements.

- added (2019-05-08):
[0001262039-19-000014:note_history:20]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 to our condensed consolidated financial statements.

- added (2019-05-08):
[0001262039-19-000014:note_history:21]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

- added (2019-05-08):
[0001262039-19-000014:note_history:22]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). Topic 326 requires a financial asset (or a group of financial assets) to be measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. Topic 326 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of Topic 326 on our condensed consolidated financial statements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:23]
Financial Instruments – Recognition and Measurement

- removed (2019-05-08):
[0001262039-18-000040:note_history:24]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, with further clarifications made recently with the issuance of ASU 2018-03, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

- removed (2019-05-08):
[0001262039-18-000040:note_history:25]
Revenue Recognition

- removed (2019-05-08):
[0001262039-18-000040:note_history:26]
In May 2014, the FASB issued Topic 606, which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted Topic 606 as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

- removed (2019-05-08):
[0001262039-18-000040:note_history:27]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our condensed consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

- removed (2019-05-08):
[0001262039-18-000040:note_history:28]
The cumulative effects of the changes made to our January 1, 2018 condensed consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

- removed (2019-05-08):
[0001262039-18-000040:note_history:29]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | $ | 77.3 |  |  | $ | (0.1 | ) |  | $ | 77.2 |  |
| Deferred tax assets | $ | 146.9 |  |  | $ | (18.0 | ) |  | $ | 128.9 |  |
| Deferred contract costs | $ | — |  |  | $ | 137.1 |  |  | $ | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 50.0 |  |  | $ | 13.6 |  |  | $ | 63.6 |  |
| Deferred revenue, current | $ | 793.8 |  |  | $ | 0.3 |  |  | $ | 794.1 |  |
| Deferred revenue, non-current | $ | 542.5 |  |  | $ | (4.4 | ) |  | $ | 538.1 |  |
| Other liabilities, non-current | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

- removed (2019-05-08):
[0001262039-18-000040:note_history:30]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of Accounting Standards Codification (“ASC”) 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:31]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of ASC Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of ASU 2018-07 on our consolidated financial statements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:32]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Subtopic 350-40 to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our consolidated financial statements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:33]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820—Fair Value Measurement as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:34]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. ASU 2016-13 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2016-13 on our consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-08):
[0001262039-19-000014:note_history:35]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service: |  |  |  |
| Security subscription | 169.6 |  |  | 136.6 |  |
| Technical support and other | 140.3 |  |  | 119.6 |  |
| Total service revenue | 309.9 |  |  | 256.2 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |

- removed (2019-05-08):
[0001262039-18-000040:note_history:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 (1) |  | September 30, 2018 |  | September 30, 2017 (1) |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 157.0 |  |  | 130.8 |  |  | 440.7 |  |  | 366.3 |  |
| Technical support | 121.4 |  |  | 96.1 |  |  | 347.4 |  |  | 267.3 |  |
| Professional services and training | 11.0 |  |  | 10.2 |  |  | 32.5 |  |  | 29.6 |  |
| Total service revenue | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-08):
[0001262039-19-000014:note_history:37]
Our revenue consists of product and service revenue. Product revenue primarily consists of sales from our FortiGate products. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

- added (2019-05-08):
[0001262039-19-000014:note_history:38]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service: |  |  |  |
| Security subscription | 169.6 |  |  | 136.6 |  |
| Technical support and other | 140.3 |  |  | 119.6 |  |
| Total service revenue | 309.9 |  |  | 256.2 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |

- added (2019-05-08):
[0001262039-19-000014:note_history:39]
As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.77 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- changed (2019-05-08):
[0001262039-19-000014:note_history:40]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of March 31, 2019 and December 31, 2018, respectively.
  (was, 2018-11-07, similarity 0.7458):
[0001262039-18-000040:note_history:40]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of September 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

- added (2019-05-08):
[0001262039-19-000014:note_history:41]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2019 and March 31, 2018 were $25.1 million and $20.8 million, respectively. No impairment loss was recognized during the three months ended March 31, 2019 or March 31, 2018.

- added (2019-05-08):
[0001262039-19-000014:note_history:42]
Deferred Revenue

- changed (2019-05-08):
[0001262039-19-000014:note_history:43]
During the three months ended March 31, 2019 and March 31, 2018, we recognized $288.6 million and $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31,2017, respectively.
  (was, 2018-11-07, similarity 0.8021):
[0001262039-18-000040:note_history:43]
During the three and nine months ended September 30, 2018, we recognized $173.0 million and $615.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

- removed (2019-05-08):
[0001262039-18-000040:note_history:44]
Revenue recognition

- removed (2019-05-08):
[0001262039-18-000040:note_history:45]
On January 1, 2018 we adopted Topic 606 using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under Topic 605. The details of significant changes and quantitative impact of the changes are discussed below.

- removed (2019-05-08):
[0001262039-18-000040:note_history:46]
We derive the majority of our revenue from sales of our products, FortiGuard security subscription and FortiCare technical support services, and other services. Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

- removed (2019-05-08):
[0001262039-18-000040:note_history:47]
Under Topic 606, we determine revenue recognition through the following steps:

- removed (2019-05-08):
[0001262039-18-000040:note_history:48]
•identification of the contract, or contracts, with the customer,

- removed (2019-05-08):
[0001262039-18-000040:note_history:49]
| • | identification of the performance obligations in the contract, including evaluation of performance obligations as to being distinct goods or services in a contract, |

- removed (2019-05-08):
[0001262039-18-000040:note_history:50]
•determination of the transaction price,

- removed (2019-05-08):
[0001262039-18-000040:note_history:51]
•allocation of the transaction price to the performance obligations in the contract, and

- removed (2019-05-08):
[0001262039-18-000040:note_history:52]
•recognition of revenue when, or as, we satisfy a performance obligation.

- removed (2019-05-08):
[0001262039-18-000040:note_history:53]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- removed (2019-05-08):
[0001262039-18-000040:note_history:54]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to the customer. Previously, term licenses were recognized over the license period.

- removed (2019-05-08):
[0001262039-18-000040:note_history:55]
We generally provide a 1-year warranty on hardware products and a 90-day warranty on software that provides assurance that our hardware or software products conform to published specifications. Such assurance-type warranties are not deemed to be separate performance obligations from the hardware or software product and costs associated with providing the warranties are accrued in accordance with ASC 460-10.

- removed (2019-05-08):
[0001262039-18-000040:note_history:56]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- removed (2019-05-08):
[0001262039-18-000040:note_history:57]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

- removed (2019-05-08):
[0001262039-18-000040:note_history:58]
Under Topic 605, revenue from contracts that contain our products and services are allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:59]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $13.7 million as of September 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- removed (2019-05-08):
[0001262039-18-000040:note_history:60]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

- removed (2019-05-08):
[0001262039-18-000040:note_history:61]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and nine months ended September 30, 2018 and 2017.

- removed (2019-05-08):
[0001262039-18-000040:note_history:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 (1) |  | September 30, 2018 |  | September 30, 2017 (1) |
| Product | $ | 164.5 |  |  | $ | 137.1 |  |  | $ | 473.6 |  |  | $ | 415.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 157.0 |  |  | 130.8 |  |  | 440.7 |  |  | 366.3 |  |
| Technical support | 121.4 |  |  | 96.1 |  |  | 347.4 |  |  | 267.3 |  |
| Professional services and training | 11.0 |  |  | 10.2 |  |  | 32.5 |  |  | 29.6 |  |
| Total service revenue | 289.4 |  |  | 237.1 |  |  | 820.6 |  |  | 663.2 |  |
| Total revenue | $ | 453.9 |  |  | $ | 374.2 |  |  | $ | 1,294.2 |  |  | $ | 1,078.3 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- removed (2019-05-08):
[0001262039-18-000040:note_history:63]
As of September 30, 2018, we had $1.54 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- removed (2019-05-08):
[0001262039-18-000040:note_history:64]
Contract Assets

- removed (2019-05-08):
[0001262039-18-000040:note_history:65]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of September 30, 2018 and January 1, 2018.

- removed (2019-05-08):
[0001262039-18-000040:note_history:66]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products and software licenses are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and nine months ended September 30, 2018 was $23.2 million and $66.3 million, respectively. No impairment loss was recognized during the three and nine months ended September 30, 2018.

- removed (2019-05-08):
[0001262039-18-000040:note_history:67]
Practical Expedient

- removed (2019-05-08):
[0001262039-18-000040:note_history:68]
We elected to use the contract modification practical expedient. This practical expedient allows for all contract modifications before January 1, 2018 to be aggregated and evaluated at adoption date.

- removed (2019-05-08):
[0001262039-18-000040:note_history:69]
Impact on Condensed Consolidated Financial Statements

- removed (2019-05-08):
[0001262039-18-000040:note_history:70]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and nine months ended September 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

- removed (2019-05-08):
[0001262039-18-000040:note_history:71]
Condensed Consolidated Balance Sheet

- removed (2019-05-08):
[0001262039-18-000040:note_history:72]
|  | As of September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 324.4 |  |  | $ | 310.7 |  |  | $ | 13.7 |  |
| Inventory | $ | 80.8 |  |  | $ | 81.9 |  |  | $ | (1.1 | ) |
| Deferred contract costs | $ | 169.6 |  |  | $ | — |  |  | $ | 169.6 |  |
| Deferred tax assets | $ | 147.8 |  |  | $ | 175.6 |  |  | $ | (27.8 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 60.7 |  |  | $ | 45.5 |  |  | $ | 15.2 |  |
| Deferred revenue, current | $ | 876.2 |  |  | $ | 896.6 |  |  | $ | (20.4 | ) |
| Deferred revenue, non-current | $ | 668.2 |  |  | $ | 667.0 |  |  | $ | 1.2 |  |
| Other liabilities, non-current | $ | 11.1 |  |  | $ | 5.2 |  |  | $ | 5.9 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (156.0 | ) |  | $ | (308.5 | ) |  | $ | 152.5 |  |

- removed (2019-05-08):
[0001262039-18-000040:note_history:73]
Condensed Consolidated Statement of Operations

- removed (2019-05-08):
[0001262039-18-000040:note_history:74]
|  | Three Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 164.5 |  |  | $ | 162.3 |  |  | $ | 2.2 |  |
| Service | 289.4 |  |  | 289.6 |  |  | (0.2 | ) |
| Total revenue | 453.9 |  |  | 451.9 |  |  | 2.0 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 72.0 |  |  | 72.3 |  |  | (0.3 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.5 |  |  | 90.0 |  |  | 2.5 |  |
| Service | 249.8 |  |  | 250.0 |  |  | (0.2 | ) |
| Total gross profit | 342.3 |  |  | 340.0 |  |  | 2.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 198.3 |  |  | 207.3 |  |  | (9.0 | ) |
| OPERATING INCOME | 62.8 |  |  | 51.5 |  |  | 11.3 |  |
| INCOME BEFORE INCOME TAXES | 70.6 |  |  | 59.3 |  |  | 11.3 |  |
| PROVISION FOR INCOME TAXES | 11.9 |  |  | 9.8 |  |  | 2.1 |  |
| NET INCOME | $ | 58.7 |  |  | $ | 49.5 |  |  | $ | 9.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.05 |  |

- removed (2019-05-08):
[0001262039-18-000040:note_history:75]
(1) Product revenue during the three months ended September 30, 2018 included a $2.2 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

- removed (2019-05-08):
[0001262039-18-000040:note_history:76]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 473.6 |  |  | $ | 461.5 |  |  | $ | 12.1 |  |
| Service | 820.6 |  |  | 819.1 |  |  | 1.5 |  |
| Total revenue | 1,294.2 |  |  | 1,280.6 |  |  | 13.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 204.1 |  |  | 203.1 |  |  | 1.0 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 269.5 |  |  | 258.4 |  |  | 11.1 |  |
| Service | 702.8 |  |  | 701.3 |  |  | 1.5 |  |
| Total gross profit | 972.3 |  |  | 959.7 |  |  | 12.6 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 576.4 |  |  | 608.9 |  |  | (32.5 | ) |
| OPERATING INCOME | 145.9 |  |  | 100.8 |  |  | 45.1 |  |
| INCOME BEFORE INCOME TAXES | 158.8 |  |  | 113.7 |  |  | 45.1 |  |
| BENEFIT FROM INCOME TAXES | 9.2 |  |  | (0.7 | ) |  | 9.9 |  |
| NET INCOME | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.68 |  |  | $ | 0.21 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.66 |  |  | $ | 0.20 |  |

- removed (2019-05-08):
[0001262039-18-000040:note_history:77]
(1) Product revenue during the nine months ended September 30, 2018 included a $12.1 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term.

- removed (2019-05-08):
[0001262039-18-000040:note_history:78]
Condensed Consolidated Statement of Cash Flows

- removed (2019-05-08):
[0001262039-18-000040:note_history:79]
|  | Nine Months Ended September 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 149.6 |  |  | $ | 114.4 |  |  | $ | 35.2 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 66.3 |  |  | — |  |  | 66.3 |  |
| Other | (1.7 | ) |  | (1.6 | ) |  | (0.1 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (19.0 | ) |  | (20.0 | ) |  | 1.0 |  |
| Deferred contract costs | (98.8 | ) |  | — |  |  | (98.8 | ) |
| Deferred tax assets | (19.1 | ) |  | (29.0 | ) |  | 9.9 |  |
| Accrued liabilities | (2.0 | ) |  | (3.5 | ) |  | 1.5 |  |
| Deferred revenue | 209.9 |  |  | 224.9 |  |  | (15.0 | ) |
| Net cash provided by operating activities | $ | 458.7 |  |  | $ | 458.7 |  |  | $ | — |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-08):
[0001262039-18-000040:note_history:80]
Revenue recognition

- removed (2019-05-08):
[0001262039-18-000040:note_history:81]
On January 1, 2018 we adopted Topic 606 using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under Topic 605. The details of significant changes and quantitative impact of the changes are discussed below.

- removed (2019-05-08):
[0001262039-18-000040:note_history:82]
We derive the majority of our revenue from sales of our products, FortiGuard security subscription and FortiCare technical support services, and other services. Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

- removed (2019-05-08):
[0001262039-18-000040:note_history:83]
Under Topic 606, we determine revenue recognition through the following steps:

- removed (2019-05-08):
[0001262039-18-000040:note_history:84]
•identification of the contract, or contracts, with the customer,

- removed (2019-05-08):
[0001262039-18-000040:note_history:85]
| • | identification of the performance obligations in the contract, including evaluation of performance obligations as to being distinct goods or services in a contract, |

- removed (2019-05-08):
[0001262039-18-000040:note_history:86]
•determination of the transaction price,

- removed (2019-05-08):
[0001262039-18-000040:note_history:87]
•allocation of the transaction price to the performance obligations in the contract, and

- removed (2019-05-08):
[0001262039-18-000040:note_history:88]
•recognition of revenue when, or as, we satisfy a performance obligation.

- removed (2019-05-08):
[0001262039-18-000040:note_history:89]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- removed (2019-05-08):
[0001262039-18-000040:note_history:90]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to the customer. Previously, term licenses were recognized over the license period.

- removed (2019-05-08):
[0001262039-18-000040:note_history:91]
We generally provide a 1-year warranty on hardware products and a 90-day warranty on software that provides assurance that our hardware or software products conform to published specifications. Such assurance-type warranties are not deemed to be separate performance obligations from the hardware or software product and costs associated with providing the warranties are accrued in accordance with ASC 460-10.

- removed (2019-05-08):
[0001262039-18-000040:note_history:92]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- removed (2019-05-08):
[0001262039-18-000040:note_history:93]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

- removed (2019-05-08):
[0001262039-18-000040:note_history:94]
Under Topic 605, revenue from contracts that contain our products and services are allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- removed (2019-05-08):
[0001262039-18-000040:note_history:95]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $13.7 million as of September 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- removed (2019-05-08):
[0001262039-18-000040:note_history:96]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

- removed (2019-05-08):
[0001262039-18-000040:note_history:97]
During the three and nine months ended September 30, 2018, we recognized $173.0 million and $615.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

- removed (2019-05-08):
[0001262039-18-000040:note_history:98]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and nine months ended September 30, 2018 and 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-05-08):
[0001262039-18-000040:note_history:99]
SUBSEQUENT EVENT

- removed (2019-05-08):
[0001262039-18-000040:note_history:100]
On October 23, 2018, we acquired ZoneFox Limited (“ZoneFox”), a privately held cloud-based insider threat detection and response company headquartered in Edinburgh, Scotland. The integration of ZoneFox’s machine learning-based threat-hunting technology will provide endpoint detection and response capabilities and will extend FortiSIEM product with additional user entity behavior analytics features, both on-premises and in the cloud. We acquired ZoneFox for approximately $18 million in initial consideration, subject to certain adjustments.

- removed (2019-05-08):
[0001262039-18-000040:note_history:101]
We are currently in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
