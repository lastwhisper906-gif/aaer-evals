# FTNT MD&A — 0001262039-25-000017


## mdna

[0001262039-25-000017:mdna:1]
[same as prior period, unchanged from 0001262039-24-000043:mdna:1]

[0001262039-25-000017:mdna:2]
[same as prior period, unchanged from 0001262039-24-000043:mdna:2]

[0001262039-25-000017:mdna:3]
[same as prior period, unchanged from 0001262039-24-000043:mdna:3]

[0001262039-25-000017:mdna:4]
[same as prior period, unchanged from 0001262039-24-000043:mdna:4]

[0001262039-25-000017:mdna:5]
[same as prior period, unchanged from 0001262039-24-000043:mdna:5]

[0001262039-25-000017:mdna:6]
[same as prior period, unchanged from 0001262039-24-000043:mdna:6]

[0001262039-25-000017:mdna:7]
•macroeconomic, geopolitical factors and other disruption on our manufacturing or sales, including tariffs or other trade disruptions, public health issues, wars, natural disasters and economic growth;

[0001262039-25-000017:mdna:8]
•government regulation and other policies;

[0001262039-25-000017:mdna:9]
[same as prior period, unchanged from 0001262039-24-000043:mdna:9]

[0001262039-25-000017:mdna:10]
[same as prior period, unchanged from 0001262039-24-000043:mdna:10]

[0001262039-25-000017:mdna:11]
•our ability to successfully anticipate market changes, including those related to cloud-based and AI solutions and to sell, support and meet service level agreements related to cloud-based solutions;

[0001262039-25-000017:mdna:12]
[same as prior period, unchanged from 0001262039-24-000043:mdna:12]

[0001262039-25-000017:mdna:13]
[same as prior period, unchanged from 0001262039-24-000043:mdna:13]

[0001262039-25-000017:mdna:14]
[same as prior period, unchanged from 0001262039-24-000043:mdna:14]

[0001262039-25-000017:mdna:15]
[same as prior period, unchanged from 0001262039-24-000043:mdna:15]

[0001262039-25-000017:mdna:16]
[same as prior period, unchanged from 0001262039-24-000043:mdna:16]

[0001262039-25-000017:mdna:17]
[same as prior period, unchanged from 0001262039-24-000043:mdna:17]

[0001262039-25-000017:mdna:18]
•trends in revenue, cost of revenue and gross margin, including expectations regarding product revenue, service revenue and inventory related charges;

[0001262039-25-000017:mdna:19]
[same as prior period, unchanged from 0001262039-24-000043:mdna:19]

[0001262039-25-000017:mdna:20]
•expected impact of plans and strategy for the acceleration of our data center footprint and our PoPs deployment;

[0001262039-25-000017:mdna:21]
•expectations that our operating expense will increase year over year in absolute dollars during the remainder of 2025;

[0001262039-25-000017:mdna:22]
[same as prior period, unchanged from 0001262039-24-000043:mdna:22]

[0001262039-25-000017:mdna:23]
[same as prior period, unchanged from 0001262039-24-000043:mdna:23]

[0001262039-25-000017:mdna:24]
[same as prior period, unchanged from 0001262039-24-000043:mdna:24]

[0001262039-25-000017:mdna:25]
•estimates of a range of 2025 spending on capital expenditures;

[0001262039-25-000017:mdna:26]
•expansions, development, improvements, operating, subleasing and other real property holdings activities;

[0001262039-25-000017:mdna:27]
•expected outcomes and liabilities in litigation;

[0001262039-25-000017:mdna:28]
[same as prior period, unchanged from 0001262039-24-000043:mdna:27]

[0001262039-25-000017:mdna:29]
[same as prior period, unchanged from 0001262039-24-000043:mdna:28]

[0001262039-25-000017:mdna:30]
[same as prior period, unchanged from 0001262039-24-000043:mdna:29]

[0001262039-25-000017:mdna:31]
[same as prior period, unchanged from 0001262039-24-000043:mdna:30]

[0001262039-25-000017:mdna:32]
Fortinet is a leader in cybersecurity, driving the convergence of networking and security. Our mission is to secure people, devices and data everywhere. Our integrated platform, the Fortinet Security Fabric, spans secure networking, unified SASE and AI-driven security operations (“SecOps”). As of March 31, 2025, our end-customers were located in over 100 countries and included enterprises across a wide variety of market verticals, including financial services, retail, healthcare and operational technology (“OT”) market verticals, communication and security service providers, and government organizations. As of March 31, 2025, we had approximately 80% of the Fortune 100 companies and approximately 72% of the Global 2000 companies as customers. As a global company headquartered in Sunnyvale, California, our research and development is centered in the United States and Canada with a global footprint of support and centers of excellence around the world. As of March 31, 2025, we held 1,045 U.S. patents and 1,381 global patents, including 271 AI-related patents. We have been recognized in over 140 enterprise analyst reports demonstrating both our vision and execution across security and networking products.

[0001262039-25-000017:mdna:33]
Our competitive differentiation lies in our core technologies, which together provide performance, security, flexibility and integration across diverse environments.

[0001262039-25-000017:mdna:34]
•FortiOS—FortiOS enables the convergence of security and networking to enforce consistent security policies across form factors and edges. As the foundation of the Fortinet Security Fabric, FortiOS empowers organizations to unify

[0001262039-25-000017:mdna:35]
management and analytics for comprehensive network visibility and control at scale. To further validate our strategy, FortiOS has been recognized across five Gartner Magic Quadrants, including Firewall, Software-Defined Wide-Area Network (“SD-WAN”), Security Service Edge (“SSE”), SASE Platforms and Wired and Wireless Local Area Network (“LAN”).

[0001262039-25-000017:mdna:36]
•FortiASIC—Our Application-Specific Integrated Circuit (“ASIC”)-based SPUs increase the speed, scale, efficiency and value of our solutions while improving user experience, reducing footprint and power requirements. From branch and campus to data center solutions, SPU-powered Fortinet appliances deliver superior Security Compute Ratings versus industry alternatives.

[0001262039-25-000017:mdna:37]
•FortiCloud—Our organically built global cloud infrastructure provides customers with global reach, flexible connectivity, and cost savings. FortiCloud is our private cloud software as a service (“SaaS”) platform, powered by FortiStack, and leveraging software and hardware to optimize and secure all layers.

[0001262039-25-000017:mdna:38]
•FortiAI—FortiAI includes FortiAI-Protect, which defends against emerging AI-driven threats and ensures secure AI usage; FortiAI-Assist, our generative AI product with agentic AI, automates Security Operations Center (“SOC”) and Network Operations Center (“NOC”) operations; and FortiAI-SecureAI, which safeguards AI infrastructure and prevents data leakage into large language models. FortiAI helps security teams make faster, educated decisions while integrating into products like FortiAnalyzer, FortiManager, FortiSIEM, and FortiSOAR to streamline threat investigation, response, and automation.

[0001262039-25-000017:mdna:39]
•FortiEndpoint—FortiEndpoint converges secure connectivity, endpoint protection and advanced capabilities like endpoint detection and response and extended detection and response (“XDR”), into a single agent. It simplifies management and enhances visibility while reducing costs and complexity. The solution gives IT teams the visibility and control they need, while security teams benefit from automated threat detection and response. This minimizes the need for manual intervention and provides faster remediation of threats across all environments.

[0001262039-25-000017:mdna:40]
•OT Security—The Fortinet Security Fabric enables security for converged IT/OT ecosystems. It also provides an OT Security Platform with features and products to extend Security Fabric capabilities to OT networks in many areas, including factories, plants, remote locations and ships. To help alleviate security risks across the organization, we have continued to enhance our OT Security Platform offerings. These innovations range from edge products to NOC and SOC tools and services to provide effective and efficient networking and cybersecurity performance and operation.

[0001262039-25-000017:mdna:41]
These competitive differentiators provide networking and security professionals with a comprehensive cyber security platform comprised of over 50 products across three solution pillars:

[0001262039-25-000017:mdna:42]
•Secure Networking—Our Secure Networking solutions focus on the convergence of networking and security via FortiOS, our networking and security operating system that is the foundation of our Fortinet Security Fabric platform and supports over 30 functions that can be delivered via a physical, virtual, cloud or SaaS solutions. When delivered through our network firewall appliances, functionality is accelerated through our proprietary ASIC technology. These proprietary ASICs, allow our systems to scale, run multiple applications at higher performance, lower power consumption and perform more processor-intensive operations, such as inspecting encrypted traffic, including streaming video. Our network firewall offerings consist of a FortiGate data center, hyperscale and distributed firewalls, as well as encrypted applications (secure sockets layer inspection, virtual private network and Internet Protocol Security connectivity). Our ability to converge networking and security also enables the ethernet to become an extension of our customers’ security infrastructure through FortiSwitch and FortiLink. Our wireless LAN solution leverages secure networking to provide secure wireless access for the enterprise LAN edge. FortiExtender secures 5G/LTE and remote ethernet extenders to connect and secure any branch environment. Our Secure Connectivity solution includes FortiSwitch secure ethernet switches, FortiAP wireless local area network access points and FortiExtender 5G connectivity gateways.

[0001262039-25-000017:mdna:43]
•Unified Secure Access Service Edge (SASE)—As applications move to the cloud and hybrid workforce is now the norm, enabling secure access for users with zero trust framework becomes important. The Fortinet Unified SASE solution includes a single-vendor SASE solution that includes firewall, SD-WAN, secure web gateway, cloud access services broker, DLP and zero trust network access to deliver flexible secure access for all users. We are one of the few vendors to deliver consistent convergence and AI-powered security across Secure SD-WAN and SSE to enable a single-vendor SASE framework with a cloud-centric architecture powered by FortiOS. Our global and scalable cloud network includes over 150 PoPs to deliver the seamless secure access experience. Given this, we believe we are well positioned to support customers expanding from SD-WAN to a single-vendor SASE platform. Additionally, we offer a full suite of comprehensive, integrated cloud security solutions that enable customers to secure their applications from code to cloud. Our solutions include application security that includes our web application firewalls, cloud network security with virtualized firewalls and cloud-native firewalls, cloud-native application protection and code security. We deliver a holistic approach to cloud security, offering a single unified platform, consolidating protection across

[0001262039-25-000017:mdna:44]
multiple disparate tools, including coding, deploying, and running applications across hybrid and multi-clouds. Additionally, we also offer flexible consumption licensing programs that enable organizations to dynamically optimize their cloud security needs and investments as well as readily meet their cloud minimum spend commitment obligations with Cloud Service Providers.

[0001262039-25-000017:mdna:45]
•AI-Driven Security Operations (SecOps)—Our AI-Driven SecOps portfolio provides a comprehensive suite of cybersecurity solutions that identify, protect, detect, respond and recover from threats, all integrated within the Fortinet Security Fabric. At the core is FortiAnalyzer, which serves as the central SOC platform with its unified data lake that provides built-in SIEM, SOAR, XDR and threat intelligence, enabling centralized visibility, analytics and automation with complete control. FortiSIEM delivers robust security information and event management for more advanced SOC requirements, while FortiSOAR enables automated orchestration and playbook-driven response. This solution set also includes FortiEDR, FortiXDR, FortiNDR, FortiSandbox, FortiDeceptor, FortiDLP and FortiRecon, helping organizations achieve defense in depth, ensuring attackers face multiple layers of detection and mitigation across endpoints, networks, and applications. To bolster their security posture, organizations contending with staff shortages can tap into FortiGuard services, including SOC-as-a-Service, Managed detection and response, Security Posture Assessment and Incident Response. Finally, FortiAI generative AI assistance streamlines operations, helping security teams stay ahead of an ever-evolving threat landscape.

[0001262039-25-000017:mdna:46]
FortiGuard Labs is our cybersecurity threat intelligence and research organization comprised of experienced threat hunters, researchers, analysts, engineers and data scientists who develop and utilize ML and AI technologies to provide timely protection updates and actionable threat intelligence for the benefit of our customers. Using millions of global network sensors, FortiGuard Labs monitors the worldwide attack surface and employs AI to mine that data for new threats.

[0001262039-25-000017:mdna:47]
FortiGuard and Other Security Services are a suite of AI-powered security capabilities that are natively integrated as part of the Fortinet Security Fabric to deliver coordinated detection and enforcement across the entire attack surface. The portfolio consists of FortiGuard application security services, content security services, device security services, NOC/SOC security services and web security services.

[0001262039-25-000017:mdna:48]
FortiCare Technical Support Service is a per-device technical support service, which provides customers access to experts to ensure efficient and effective operations and maintenance of their Fortinet capabilities. Global technical support is offered 24x7 with flexible add-ons, including enhanced service-level agreements and priority hardware replacement through in-country and local depots. Organizations have the flexibility to procure different levels of service for different devices based on their availability needs. We offer three per-device support options tailored to the needs of our enterprise customers: FortiCare Elite, FortiCare Premium and FortiCare Essential. The FortiCare Elite service aims to provide a 15-minute response time for key product families.

[0001262039-25-000017:mdna:49]
In addition to FortiCare device level services, Advanced Support service options are available per account. These services are available for regional account support in three options: Core, Pro and Pro Plus, and can be available or provided on a global basis at the Pro and Pro Plus levels. Advanced Support brings support directly to each account, helping account holders to make their operations more effective and to plan and manage their solution lifecycle.

[0001262039-25-000017:mdna:50]
Additionally, we are committed to addressing the cybersecurity skills shortage through training and certification programs for customers, partners and employees. The Fortinet Training Institute’s ecosystem of public and private partnerships around the world extend to industry, academia, government and nonprofits to ensure we are reaching and increasing access of our cybersecurity certifications and training to all populations. The Fortinet Training Institute has issued over two million certifications to date.

[0001262039-25-000017:mdna:51]
[same as prior period, unchanged from 0001262039-24-000043:mdna:39]

[0001262039-25-000017:mdna:52]
•Total revenue was $1.54 billion during the three months ended March 31, 2025, an increase of 14%, compared to $1.35 billion in the same period last year. Product revenue was $459.1 million during the three months ended March 31, 2025, an increase of 12%, compared to $408.9 million in the same period last year. Service revenue was $1.08 billion during the three months ended March 31, 2025, an increase of 14%, compared to $944.4 million in the same period last year.

[0001262039-25-000017:mdna:53]
•Total gross profit was $1.25 billion during the three months ended March 31, 2025, an increase of 19%, compared to $1.05 billion in the same period last year.

[0001262039-25-000017:mdna:54]
•Total gross margin was 81.0% during the three months ended March 31, 2025, an increase of 3.5 percentage points, compared to 77.5% in the same period last year.

[0001262039-25-000017:mdna:55]
•Operating income was $453.8 million and during the three months ended March 31, 2025, an increase of 41%, compared to $321.2 million in the same period last year.

[0001262039-25-000017:mdna:56]
•Operating margin was 29.5% during the three months ended March 31, 2025, an increase of 5.8 percentage points, compared to 23.7% in the same period last year.

[0001262039-25-000017:mdna:57]
•Cash, cash equivalents, short-term and long-term investments were $4.82 billion as of March 31, 2025.

[0001262039-25-000017:mdna:58]
•Deferred revenue was $6.42 billion, including short-term deferred revenue of $3.34 billion, as of March 31, 2025.

[0001262039-25-000017:mdna:59]
•Cash flows from operating activities were $863.3 million, which includes $14.0 million of proceeds from a legal victory around an IP matter, during the three months ended March 31, 2025, an increase of $32.9 million, or 4%, compared to the same period last year.

[0001262039-25-000017:mdna:60]
Revenue continues to be diversified globally, which remains a key strength of our business. During the three months ended March 31, 2025, the Americas region, the Europe, Middle East and Africa region and the Asia Pacific region contributed 41%, 41% and 18% of our total revenue, respectively, and increased 13%, 16%, and 10% compared to the same period last year, respectively.

[0001262039-25-000017:mdna:61]
Product revenue increased 12% during the three months ended March 31, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licenses, including secure networking hardware products and term licenses. We expect our product revenue to continue to grow for the remainder of 2025.

[0001262039-25-000017:mdna:62]
Service revenue growth during the three months ended March 31, 2025 was 14%, as compared to the same period last year, was primarily driven by the strength of our security subscription revenue, which grew 16%. The increase was primarily due to the recognition of service revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and strength in unified SASE and SecOps. We expect our service revenue to continue to grow for the remainder of 2025, with growth opportunities that include unified SASE and SecOps offerings as well as the year over year increase in current deferred revenue. While service revenue is expected to grow for the remainder of 2025, we anticipate that the growth rates will continue to decrease for the remainder of 2025 due to slowing short-term deferred revenue growth over the past several quarters.

[0001262039-25-000017:mdna:63]
Our billings were diversified on a geographic basis. During the three months ended March 31, 2025, eight countries represented approximately 50% of our billings and the remaining approximately 50% in the aggregate were from over 100 countries that each individually contributed less than 3% of our billings.

[0001262039-25-000017:mdna:64]
Total gross margin increased 3.5 percentage points during the three months ended March 31, 2025 compared to the same period last year, primarily driven by increased product gross margin as inventory related reserves expense normalized in comparison to elevated levels we saw in the first half of 2024. Our overall gross margin for the full year of 2025 will be impacted by service and product revenue mix and their respective gross margins. We expect our product gross margin to slightly increase for the full year 2025 compared to 2024 as we continue to benefit from lower impact of inventory reserves expense. We expect our service gross margin to decrease for the full year of 2025 compared to 2024, as we expand our data center footprint and colocation and cloud hosting capacity to support the growth in our unified SASE and SecOps offerings. We currently do not expect the U.S. tariffs to have a meaningful impact on our gross margin. If tariffs increase in the future, we expect any resulting impact on our gross margin to mostly be on our hardware sales to U.S. customers.

[0001262039-25-000017:mdna:65]
Operating expenses as a percentage of revenue decreased 2.3 percentage points, during the three months ended March 31, 2025 compared to the same period last year, mainly because our revenue growth outpaced our personnel costs growth. Headcount increased to 14,556 employees as of March 31, 2025, an 8% increase compared to 13,522 as of March 31, 2024.

[0001262039-25-000017:mdna:66]
Operating margin increased 5.8 percentage points during the three months ended March 31, 2025, as a result of improvement in gross margin and decrease in operating expenses as a percentage of revenue. We expect our operating margin to decrease for the full year of 2025 compared to 2024 as we grow our sales and marketing and research and development workforce organically and through acquisitions, increase our product development investments, and expand our data center footprint and our colocation and cloud hosting capacity to support business growth.

[0001262039-25-000017:mdna:67]
[same as prior period, unchanged from 0001262039-24-000043:mdna:57]

[0001262039-25-000017:mdna:68]
Our overall performance depends in part on worldwide economic and geopolitical conditions, such as trade policies and tariffs, GDP growth or contraction (both domestically and internationally), geopolitical instability and uncertainty, the war

[0001262039-25-000017:mdna:69]
in Ukraine or tensions between China and Taiwan, and their impact on customer behavior. Worsening economic conditions, including tariffs, inflation, changing interest rates and other trade disruptions, slower growth, any recession, fluctuations in foreign exchange rates and other changes in economic conditions, may result in decreased sales productivity, lower growth and adversely affect our results of operations and financial performance. We have seen, and could continue to see, certain impacts on our business, results of operations, financial condition, cash flows, liquidity and capital and financial resources such as longer sales cycles, delayed purchases and increased commitments with certain suppliers and increased inventory and inventory purchase commitment reserves. For example, earlier this year the United States announced tariffs on imported goods from most countries, some of which have been temporarily suspended or adjusted from time to time. U.S. tariffs, and any new or additional retaliatory tariffs that could be imposed by other countries in response to such U.S. tariffs could have a material adverse impact on global trade, supply chains worldwide, and other worldwide economic and geopolitical conditions, which could increase our product costs for the remainder of 2025 and beyond, and also affect customer sentiment in deciding whether to purchase our products. We continue to monitor the impact of tariffs on our business.

[0001262039-25-000017:mdna:70]
[same as prior period, unchanged from 0001262039-24-000043:mdna:59]

[0001262039-25-000017:mdna:71]
[same as prior period, unchanged from 0001262039-24-000043:mdna:60]

[0001262039-25-000017:mdna:72]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to certain service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers or use our products and services to provide hosted solutions to other enterprises. At times, we also sell directly to enterprise customers, service providers, systems integrators and large enterprises. We also sell our software licenses and cloud delivered services via different cloud service provider platforms, both directly and through our channel partners. Our end-customers are located in over 100 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including financial services, government, healthcare, manufacturing, retail, technology and telecommunications. An end-customer deployment may involve as few as one or as many as thousands of secure networking, unified SASE and security operations technology products or users, depending on the end-customer’s size and security requirements.

[0001262039-25-000017:mdna:73]
Our customers purchase our hardware products, software licenses, SaaS subscriptions and cloud-delivered solutions, including our FortiGuard security subscriptions and FortiCare technical support services. Depending on the solution, these may be sold in a bundle or standalone as part of a solution sale. We generally invoice at the time of our sale for the total price of the products and services. Standard payment terms are generally no more than 60 days, though we may offer extended payment terms to certain distributors or large enterprises.

[0001262039-25-000017:mdna:74]
We offer our products hosted in our own data centers, PoPs, and through colocations and major cloud service providers, including Amazon Web Services, Microsoft Azure and Google Cloud.

[0001262039-25-000017:mdna:75]
[same as prior period, unchanged from 0001262039-24-000043:mdna:64]

[0001262039-25-000017:mdna:76]
We monitor several key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-25-000017:mdna:77]
|  | Three Months Ended Or As Of |
|  | March 31, 2025 |  | March 31, 2024 |
|  | (in millions) |
| Revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |
| Deferred revenue | $ | 6,418.4 |  |  | $ | 5,789.9 |  |
| Billings (non-GAAP) | $ | 1,597.2 |  |  | $ | 1,407.2 |  |
| Net cash provided by operating activities | $ | 863.3 |  |  | $ | 830.4 |  |
| Free cash flow (non-GAAP) | $ | 782.8 |  |  | $ | 608.5 |  |

[0001262039-25-000017:mdna:78]
30

[0001262039-25-000017:mdna:79]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscriptions and FortiCare technical support service contracts, which is recognized as revenue ratably over the service term. We monitor our deferred revenue balance, short-term and total deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $6.42 billion as of March 31, 2025, an increase of $57.5 million, or 1%, from December 31, 2024. Short-term deferred revenue was $3.34 billion as of March 31, 2025, an increase of $63.2 million, or 2%, from December 31, 2024.

[0001262039-25-000017:mdna:80]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.60 billion for the three months ended March 31, 2025, an increase of 14% compared to $1.41 billion in the same period last year.

[0001262039-25-000017:mdna:81]
Our backlog may fluctuate over quarters. A reduction to backlog increases our aggregate billings and revenue during the quarter when delivered. If we experience supply chain shortages and cannot fulfill orders or if customers cancel or delay delivery of orders, our backlog may be affected, which will negatively impact our aggregate backlog to billings conversion and revenue in such quarter.

[0001262039-25-000017:mdna:82]
[same as prior period, unchanged from 0001262039-24-000043:mdna:71]

[0001262039-25-000017:mdna:83]
|  | Three Months Ended |
|  | March 31, 2025 |  | March 31, 2024 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |
| Add: Change in deferred revenue | 57.5 |  |  | 54.9 |  |
| Less: Deferred revenue balance acquired in business combinations | — |  |  | (1.0) |  |
| Total billings (non-GAAP) | $ | 1,597.2 |  |  | $ | 1,407.2 |  |

[0001262039-25-000017:mdna:84]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from IP matters. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from IP matters, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from IP matters, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our proceeds from IP matters, our capital expenditures and other investing and financing activities on the condensed consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-25-000017:mdna:85]
[same as prior period, unchanged from 0001262039-24-000043:mdna:54]

[0001262039-25-000017:mdna:86]
|  | Three Months Ended |
|  | March 31, 2025 |  | March 31, 2024 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 863.3 |  |  | $ | 830.4 |  |
| Less: Purchases of property and equipment | (66.5) |  |  | (221.9) |  |
| Less: Proceeds from IP matter | (14.0) |  |  | — |  |
| Free cash flow (non-GAAP) | $ | 782.8 |  |  | $ | 608.5 |  |
| Net cash used in investing activities | $ | (110.8) |  |  | $ | (270.3) |  |
| Net cash used in financing activities | $ | (32.7) |  |  | $ | (30.3) |  |

[0001262039-25-000017:mdna:87]
[same as prior period, unchanged from 0001262039-24-000043:mdna:76]

[0001262039-25-000017:mdna:88]
[same as prior period, unchanged from 0001262039-24-000043:mdna:77]

[0001262039-25-000017:mdna:89]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2025, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 21, 2025 (the “Form 10-K”).

[0001262039-25-000017:mdna:90]
[same as prior period, unchanged from 0001262039-24-000043:mdna:79]

[0001262039-25-000017:mdna:91]
[same as prior period, unchanged from 0001262039-24-000043:mdna:81]

[0001262039-25-000017:mdna:92]
Three Months Ended March 31, 2025 and 2024

[0001262039-25-000017:mdna:93]
[same as prior period, unchanged from 0001262039-24-000043:mdna:83]

[0001262039-25-000017:mdna:94]
|  | Three Months Ended |  |  |  |  |
| March 31,2025 |  | March 31,2024 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 459.1 |  |  | 30 | % |  | $ | 408.9 |  |  | 30 | % |  | $ | 50.2 |  |  | 12 | % |
| Service | 1,080.6 |  |  | 70 |  |  | 944.4 |  |  | 70 |  |  | 136.2 |  |  | 14 |  |
| Total revenue | $ | 1,539.7 |  |  | 100 | % |  | $ | 1,353.3 |  |  | 100 | % |  | $ | 186.4 |  |  | 14 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 629.8 |  |  | 41 | % |  | $ | 557.0 |  |  | 41 | % |  | $ | 72.8 |  |  | 13 | % |
| EMEA | 628.4 |  |  | 41 |  |  | 539.4 |  |  | 40 |  |  | 89.0 |  |  | 16 |  |
| APAC | 281.5 |  |  | 18 |  |  | 256.9 |  |  | 19 |  |  | 24.6 |  |  | 10 |  |
| Total revenue | $ | 1,539.7 |  |  | 100 | % |  | $ | 1,353.3 |  |  | 100 | % |  | $ | 186.4 |  |  | 14 | % |

[0001262039-25-000017:mdna:95]
Total revenue increased $186.4 million, or 14%, during the three months ended March 31, 2025 compared to the same period last year. We continued to experience diversification of revenue geographically, and across customer and industry verticals. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-25-000017:mdna:96]
Product revenue increased $50.2 million, or 12%, during the three months ended March 31, 2025 compared to the same period last year. We experienced product revenue growth across our hardware products and software licenses, including secure networking hardware products and term licenses.

[0001262039-25-000017:mdna:97]
Service revenue increased $136.2 million, or 14%, during the three months ended March 31, 2025 compared to the same period last year. Security subscription revenue increased $86.2 million, or 16%, and technical support and other services revenue increased $50.0 million, or 12%, during the three months ended March 31, 2025 compared to the same period last year. The increase was primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud-based environments and growth in SaaS solutions, including unified SASE and SecOps.

[0001262039-25-000017:mdna:98]
Of the service revenue recognized during the three months ended March 31, 2025, 90% was included in the deferred revenue balance as of December 31, 2024. Of the service revenue recognized during the three months ended March 31, 2024, 90% was included in the deferred revenue balance as of December 31, 2023. We expect service revenue growth rates to continue to decrease for the remainder of 2025 due to slowing short-term deferred revenue growth over the past several quarters.

[0001262039-25-000017:mdna:99]
[same as prior period, unchanged from 0001262039-24-000043:mdna:89]

[0001262039-25-000017:mdna:100]
|  | Three Months Ended |  |  |  |  |
| March 31,2025 |  | March 31,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 149.9 |  |  | $ | 182.8 |  |  | $ | (32.9) |  |  | (18) | % |
| Service | 143.2 |  |  | 121.9 |  |  | 21.3 |  |  | 17 |  |
| Total cost of revenue | $ | 293.1 |  |  | $ | 304.7 |  |  | $ | (11.6) |  |  | (4) | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 67.3 | % |  | 55.3 | % |  |  |  |  |
| Service | 86.7 |  |  | 87.1 |  |  |  |  |  |
| Total gross margin | 81.0 | % |  | 77.5 | % |  |  |  |  |

[0001262039-25-000017:mdna:101]
Total gross margin increased 3.5 percentage points during the three months ended March 31, 2025 compared to the same period last year, primarily driven by increased product gross margin.

[0001262039-25-000017:mdna:102]
Product gross margin increased 12.0 percentage points during the three months ended March 31, 2025 compared to the same period last year, as inventory related reserves expense normalized from the elevated levels we saw in the first half of 2024. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs, and costs of materials used in production.

[0001262039-25-000017:mdna:103]
Service gross margin decreased 0.4 percentage points during the three months ended March 31, 2025 compared to the same period last year, primarily due to an increase in cloud service costs, partially offset by service revenue growth outpacing labor and replacement costs increase. Cost of service revenue was comprised primarily of personnel-related costs, replacement cost, cloud services costs from data centers, colocation provider and cloud providers, infrastructure, software and delivery costs, and facility-related costs.

[0001262039-25-000017:mdna:104]
[same as prior period, unchanged from 0001262039-24-000043:mdna:95]

[0001262039-25-000017:mdna:105]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2025 |  | March 31,2024 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 198.6 |  |  | 13 | % |  | $ | 173.0 |  |  | 13 | % |  | $ | 25.6 |  |  | 15 | % |
| Sales and marketing | 542.7 |  |  | 35 |  |  | 501.1 |  |  | 37 |  |  | 41.6 |  |  | 8 |  |
| General and administrative | 57.8 |  |  | 4 |  |  | 54.4 |  |  | 4 |  |  | 3.4 |  |  | 6 |  |
| Gain on intellectual property matters | (6.3) |  |  | — |  |  | (1.1) |  |  | — |  |  | (5.2) |  |  | 473 |  |
| Total operating expenses | $ | 792.8 |  |  | 51 | % |  | $ | 727.4 |  |  | 54 | % |  | $ | 65.4 |  |  | 9 | % |

[0001262039-25-000017:mdna:106]
[same as prior period, unchanged from 0001262039-24-000043:mdna:97]

[0001262039-25-000017:mdna:107]
Research and development expense increased $25.6 million, or 15%, during the three months ended March 31, 2025 compared to the same period last year, primarily due to an increase of $20.7 million in personnel-related costs as a result of increased headcount and compensation rates to support the development of new products and continued enhancements to our existing products and the impact of the recent acquisitions. In addition, non-personnel-related product development costs increased $7.2 million. We currently intend to continue investing in our research and development organization, and expect research and development expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000017:mdna:108]
[same as prior period, unchanged from 0001262039-24-000043:mdna:99]

[0001262039-25-000017:mdna:109]
Sales and marketing expense increased $41.6 million, or 8%, during the three months ended March 31, 2025 compared to the same period last year, primarily due to an increase of $28.4 million in personnel-related costs. In addition, marketing program and related expenses increased $5.6 million and amortization expense of certain intangible assets increased $4.2 million, partially offset by the favorable impact of foreign currency fluctuations. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect our sales and marketing expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000017:mdna:110]
[same as prior period, unchanged from 0001262039-24-000043:mdna:101]

[0001262039-25-000017:mdna:111]
General and administrative expense increased $3.4 million, or 6%, during the three months ended March 31, 2025 compared to the same period last year, primarily due to an increase of $3.1 million in personnel-related costs. We currently expect general and administrative expense to increase in absolute dollars year over year during the remainder of 2025.

[0001262039-25-000017:mdna:112]
[same as prior period, unchanged from 0001262039-24-000043:mdna:103]

[0001262039-25-000017:mdna:113]
We generated operating income of $453.8 million during the three months ended March 31, 2025, an increase of $132.6 million, or 41%, compared to $321.2 million in the same period last year. Operating margin was 29.5% during the three months ended March 31, 2025, compared to 23.7% in the same period last year. The 5.8 percentage points increase in operating margin was primarily due to 3.5 percentage points increase in gross margin and 1.8 percentage points decrease in sales and marketing expense and a gain on intellectual property matters.

[0001262039-25-000017:mdna:114]
Interest income, interest expense and other income (expense)—net

[0001262039-25-000017:mdna:115]
|  | Three Months Ended |  |  |  |  |
| March 31,2025 |  | March 31,2024 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 44.3 |  |  | $ | 32.2 |  |  | $ | 12.1 |  |  | 38 | % |
| Interest expense | $ | (4.9) |  |  | $ | (5.1) |  |  | $ | 0.2 |  |  | (4) | % |
| Other income (expense)—net | $ | 26.1 |  |  | $ | (2.9) |  |  | $ | 29.0 |  |  | (1,000) | % |

[0001262039-25-000017:mdna:116]
Interest income increased $12.1 million during the three months ended March 31, 2025 compared to the same period last year, primarily as a result of higher investment balances. Interest income varies depending on our average investment balances during the period, types and mix of investments, and interest rates. Interest expense remained comparatively flat during the three months ended March 31, 2025 compared to the same period last year. The $29.0 million change in other income (expense)—net during the three months ended March 31, 2025 compared to the same period last year, was primarily due to a gain on bargain purchase of $39.9 million related to our acquisition of Linksys and a $4.5 million increase in foreign currency exchange gains, partially offset by an increase of $15.1 million loss on marketable equity securities.

[0001262039-25-000017:mdna:117]
[same as prior period, unchanged from 0001262039-24-000043:mdna:143]

[0001262039-25-000017:mdna:118]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2025 |  | March 31,2024 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 96.5 |  |  | $ | 39.5 |  |  | $ | 57.0 |  |  | 144 | % |
| Effective tax rate (%) | 19 | % |  | 11 | % |  |  |  |  |

[0001262039-25-000017:mdna:119]
Our effective tax rate was 19% for the three months ended March 31, 2025 compared to an effective tax rate of 11% for the same period last year. The provision for income taxes for the three months ended March 31, 2025 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes totaling $128.5 million, which included a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys, a tax benefit of $25.8 million from the foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense of $36.8 million.

[0001262039-25-000017:mdna:120]
The provision for income taxes for the three months ended March 31, 2024 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes totaling $81.7 million, which were favorably affected by a tax benefit of $24.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $18.2 million.

[0001262039-25-000017:mdna:121]
Gain (loss) from equity method investments

[0001262039-25-000017:mdna:122]
|  | Three Months Ended |  | Change |  | % Change |
| March 31,2025 |  | March 31,2024 |  |
| (in millions, except percentages) |
| Gain (loss) from equity method investments | $ | 10.6 |  |  | $ | (6.6) |  |  | $ | 17.2 |  |  | (261) | % |

[0001262039-25-000017:mdna:123]
The $17.2 million change in gain (loss) from equity method investments during the three months ended March 31, 2025 compared to the same period last year was primarily driven by $10.8 million gain related to our acquisition of Linksys in the three months ended March 31, 2025 and $6.4 million loss due to our proportionate share of Linksys’ financial results including our share of the amortization of the basis differences in the three months ended March 31, 2024. Refer to Note 6. Business Combinations in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on our acquisition of Linksys.

[0001262039-25-000017:mdna:124]
[same as prior period, unchanged from 0001262039-24-000043:mdna:91]

[0001262039-25-000017:mdna:125]
[same as prior period, unchanged from 0001262039-24-000043:mdna:151]

[0001262039-25-000017:mdna:126]
|  | As of |
|  | March 31,2025 |  | December 31,2024 |
|  | (in millions) |
| Cash and cash equivalents | $ | 3,596.6 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,183.9 |  |  | 1,190.6 |  |
| Long-term investments | 35.2 |  |  | — |  |
| Total cash, cash equivalents and investments | $ | 4,815.7 |  |  | $ | 4,066.5 |  |
| Working capital | $ | 1,714.8 |  |  | $ | 1,910.8 |  |
|  | Three Months Ended |
|  | March 31,2025 |  | March 31,2024 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 863.3 |  |  | $ | 830.4 |  |
| Net cash used in investing activities | (110.8) |  |  | (270.3) |  |
| Net cash used in financing activities | (32.7) |  |  | (30.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | 0.9 |  |  | (1.4) |  |
| Net increase in cash and cash equivalents | $ | 720.7 |  |  | $ | 528.4 |  |

[0001262039-25-000017:mdna:127]
Liquidity and capital resources are primarily impacted by our operating activities, as well as real estate purchases, other capital expenditures and business acquisitions, payment of taxes in connection with the net settlement of equity awards and proceeds from the issuance of common stock and investment grade debt and repurchases of our common stock.

[0001262039-25-000017:mdna:128]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for and availability of our products and services, competition, pricing actions, market or industry changes, macroeconomic events such as rising inflation and changing interest rates, economic strength, supply chain capacity and disruptions, tariffs and other trade restrictions, international conflicts, including the war in Ukraine or tensions between China and Taiwan, an increase in installment billing, and our ability to execute. We expect proceeds from the exercise of stock options in future years to continue to be impacted by the increased mix of restricted stock units and performance stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-25-000017:mdna:129]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2025. As of March 31, 2025, approximately $2.03 billion remained available for future share repurchases. Refer to Note 11. Equity Plans and Share Repurchase Program and Note 15. Subsequent Events in Part I, Item 1 of this Quarterly Report on Form 10-Q for information regarding our repurchases of 4.6 million shares of our common stock for an aggregate purchase price of $401.1 million under the Repurchase Program, subsequent to March 31, 2025 through the filing of this Quarterly Report on Form 10-Q.

[0001262039-25-000017:mdna:130]
We expect to continue to increase our data centers, PoPs, office and warehouse capacity to support growth and the expansion of existing services or introduction of new services. As we purchase new properties, we will work to incorporate these properties into the environmental goals we have established. We estimate capital expenditures to be between approximately $380.0 million and $430.0 million in 2025.

[0001262039-25-000017:mdna:131]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not currently intend to retire our Senior Notes early. Refer to Note 9. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Senior Notes. As of March 31, 2025, the current portion of long-term debt and long-term debt, net of unamortized discount and debt issuance costs, were $994.9 million.

[0001262039-25-000017:mdna:132]
We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that

[0001262039-25-000017:mdna:133]
allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000017:mdna:134]
These inventory purchase commitments as of March 31, 2025 totaled $689.0 million, an increase of $97.9 million compared to $591.1 million as of December 31, 2024 due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitments position. We record a liability for inventory purchase commitments in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of March 31, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $47.5 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets.

[0001262039-25-000017:mdna:135]
[same as prior period, unchanged from 0001262039-24-000043:mdna:163]

[0001262039-25-000017:mdna:136]
We also have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2025, we had $94.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000017:mdna:137]
There have been no significant changes to our leases as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001262039-25-000017:mdna:138]
As of March 31, 2025, our cash, cash equivalents and short-term and long-term investments of $4.82 billion were invested primarily in deposit accounts, commercial paper, corporate debt securities, U.S. government and agency securities, certificates of deposit and term deposits, money market funds and marketable equity securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity, and generates return without significantly increasing risk. We believe that we have sufficient liquidity to meet our operating requirements for at least the next twelve months and thereafter for the foreseeable future, including our foreseeable future supply obligations, debt repayment, capital expenditures and share repurchases.

[0001262039-25-000017:mdna:139]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $228.8 million as of March 31, 2025 and $207.8 million as of December 31, 2024.

[0001262039-25-000017:mdna:140]
We believe that our existing cash and cash equivalents and cash flow from operations will be sufficient for at least the next 12 months to meet our requirements and plans for cash, including meeting our working capital requirements and capital expenditure requirements. In the long term, our ability to support our requirements and plans for cash, including our working capital and capital expenditure requirements will depend on many factors, including our growth rate; the timing and amount of our share repurchases and debt retirement; the expansion of sales and marketing activities, pricing actions, the introduction of new and enhanced products and services offerings; the continuing market acceptance of our products; the timing and extent of spending to support development efforts; our investments in purchasing, developing or leasing real estate; cash paid for taxes and macroeconomic impacts such as rising inflation and changing interest rates; the war in Ukraine and tensions between China and Taiwan. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-25-000017:mdna:141]
As of March 31, 2025, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-25-000017:mdna:142]
[same as prior period, unchanged from 0001262039-24-000043:mdna:171]

[0001262039-25-000017:mdna:143]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of amortization of deferred contract costs, stock-based compensation and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in accounts receivable—net, deferred contract costs, accrued liabilities, deferred revenue, inventory, deferred tax assets and accounts payable.

[0001262039-25-000017:mdna:144]
[same as prior period, unchanged from 0001262039-24-000043:mdna:114]

[0001262039-25-000017:mdna:145]
Our operating activities during the three months ended March 31, 2025 provided cash flows of $863.3 million as a result of the continued growth of our business, improved profitability and our ability to successfully manage our working capital. Changes in operating assets and liabilities were primarily driven by a decrease of $303.9 million in accounts receivable—net during three months ended March 31, 2025. Due to seasonality, our billings are highest in the fourth quarter, as such, our collections are highest in the first quarter of the year. In addition, changes in operating assets and liabilities were driven by an increase of $91.3 million in deferred contract costs, an increase of $63.7 million in accrued liabilities, an increase of $57.0 million in our deferred revenue, an increase of $34.1 million in inventory, an increase of $30.0 million in deferred tax assets and an increase of $24.6 million in accounts payable.

[0001262039-25-000017:mdna:146]
[same as prior period, unchanged from 0001262039-24-000043:mdna:174]

[0001262039-25-000017:mdna:147]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, investments in various companies and business acquisitions. Historically, we have elected to own a facility if we believe that purchasing or developing buildings rather than leasing is more closely aligned with our long-term strategy. We expect to make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-25-000017:mdna:148]
During the three months ended March 31, 2025, cash used in investing activities was $110.8 million, primarily driven by $66.5 million used for the purchases of property and equipment, $33.3 million spent for purchases of investments, net of maturities and sales of investments and $11.2 million used for the acquisition of Linksys, net of cash.

[0001262039-25-000017:mdna:149]
[same as prior period, unchanged from 0001262039-24-000043:mdna:177]

[0001262039-25-000017:mdna:150]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the Amended Plan.

[0001262039-25-000017:mdna:151]
During the three months ended March 31, 2025, cash used in financing activities was $32.7 million, driven by $32.7 million used to pay tax withholding, net of proceeds from the issuance of common stock.
