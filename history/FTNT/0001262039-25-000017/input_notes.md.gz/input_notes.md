# FTNT notes — 0001262039-25-000017


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-25-000017:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

[0001262039-25-000017:notes:2]
Amounts previously reported as marketable equity securities are included in short-term investments in prior periods to conform with current period presentation in our condensed consolidated balance sheets. Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

[0001262039-25-000017:notes:3]
[same as prior period, unchanged from 0001262039-24-000043:notes:2]

[0001262039-25-000017:notes:4]
[same as prior period, unchanged from 0001262039-24-000043:notes:3]

[0001262039-25-000017:notes:5]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

[0001262039-25-000017:notes:6]
[same as prior period, unchanged from 0001262039-24-000043:notes:5]

[0001262039-25-000017:notes:7]
[same as prior period, unchanged from 0001262039-24-000043:notes:8]

[0001262039-25-000017:notes:8]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-25-000017:notes:9]
Income Statement

[0001262039-25-000017:notes:10]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal year 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-25-000017:notes:11]
[same as prior period, unchanged from 0001262039-24-000043:notes:10]

[0001262039-25-000017:notes:12]
[same as prior period, unchanged from 0001262039-24-000043:notes:11]

[0001262039-25-000017:notes:13]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 623.1 |  |  | 536.9 |  |  |  |  |  |
| Technical support and other | 457.5 |  |  | 407.5 |  |  |  |  |  |
| Total service revenue | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |

[0001262039-25-000017:notes:14]
[same as prior period, unchanged from 0001262039-24-000043:notes:13]

[0001262039-25-000017:notes:15]
During the three months ended March 31, 2025 and 2024, we recognized $972.5 million and $851.1 million in revenue that was included in the deferred revenue balance as of December 31, 2024 and 2023, respectively.

[0001262039-25-000017:notes:16]
[same as prior period, unchanged from 0001262039-24-000043:notes:15]

[0001262039-25-000017:notes:17]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.49 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.38 billion as revenue over the next 12 months, $2.55 billion in years two and three, and the remainder thereafter.

[0001262039-25-000017:notes:18]
[same as prior period, unchanged from 0001262039-24-000043:notes:20]

[0001262039-25-000017:notes:19]
Amortization of deferred contract costs during the three months ended March 31, 2025 and 2024 were $78.0 million and $72.0 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-25-000017:notes:20]
FINANCIAL INSTRUMENTS AND FAIR VALUE
Short-Term and Long-Term Investments

[0001262039-25-000017:notes:21]
Our short-term and long-term investments comprised of available-for-sale investments and marketable equity securities. The following tables summarize our short-term and long-term investments (in millions):

[0001262039-25-000017:notes:22]
|  | March 31, 2025 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 486.5 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 486.7 |  |
| Commercial paper | 432.8 |  |  | 0.1 |  |  | (0.1) |  |  | 432.8 |  |
| Corporate debt securities | 158.2 |  |  | — |  |  | (0.1) |  |  | 158.1 |  |
| Certificates of deposit and term deposits | 73.9 |  |  | — |  |  | — |  |  | 73.9 |  |
| Total available-for-sale investments | 1,151.4 |  |  | 0.3 |  |  | (0.2) |  |  | 1,151.5 |  |
| Marketable equity securities |  |  |  |  |  |  | 67.6 |  |
| Total short-term and long-term investments | $ | 1,151.4 |  |  | $ | 0.3 |  |  | $ | (0.2) |  |  | $ | 1,219.1 |  |

[0001262039-25-000017:notes:23]
|  | December 31, 2024 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 469.1 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 469.5 |  |
| Commercial paper | 428.7 |  |  | 0.2 |  |  | (0.2) |  |  | 428.7 |  |
| Corporate debt securities | 166.4 |  |  | 0.1 |  |  | (0.1) |  |  | 166.4 |  |
| Certificates of deposit and term deposits | 61.8 |  |  | — |  |  | — |  |  | 61.8 |  |
| Total available-for-sale investments | 1,126.0 |  |  | 0.7 |  |  | (0.3) |  |  | 1,126.4 |  |
| Marketable equity securities |  |  |  |  |  |  | 64.2 |  |
| Total short-term and long-term investments | $ | 1,126.0 |  |  | $ | 0.7 |  |  | $ | (0.3) |  |  | $ | 1,190.6 |  |

[0001262039-25-000017:notes:24]
[same as prior period, unchanged from 0001262039-24-000043:notes:26]

[0001262039-25-000017:notes:25]
|  | March 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 119.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 119.7 |  |  | $ | — |  |
| Commercial paper | 260.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 260.5 |  |  | (0.1) |  |
| Corporate debt securities | 83.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 83.8 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 9.5 |  |  | — |  |  | — |  |  | — |  |  | 9.5 |  |  | — |  |
| Total available-for-sale investments | $ | 473.5 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 473.5 |  |  | $ | (0.2) |  |

[0001262039-25-000017:notes:26]
|  | December 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| Commercial paper | 149.4 |  |  | (0.2) |  |  | — |  |  | — |  |  | 149.4 |  |  | (0.2) |  |
| Corporate debt securities | 63.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 63.5 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 10.9 |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | — |  |
| Total available-for-sale investments | $ | 251.6 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 251.6 |  |  | $ | (0.3) |  |

[0001262039-25-000017:notes:27]
The contractual maturities of our available-for-sale investments were (in millions):

[0001262039-25-000017:notes:28]
|  | March 31,2025 |  | December 31,2024 |
| Due within one year | $ | 1,116.3 |  |  | $ | 1,126.4 |  |
| Due within one to three years | 35.2 |  |  | — |  |
| Total | $ | 1,151.5 |  |  | $ | 1,126.4 |  |

[0001262039-25-000017:notes:29]
Available-for-sale investments are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. We do not intend to sell any of the securities in an unrealized loss position and it is not more likely than not that we would be required to sell these securities before recovery of their amortized cost basis, which may be at maturity.

[0001262039-25-000017:notes:30]
[same as prior period, unchanged from 0001262039-24-000043:notes:32]

[0001262039-25-000017:notes:31]
Our marketable equity securities were $67.6 million and $64.2 million as of March 31, 2025 and December 31, 2024. The changes in fair value of our marketable equity securities are recorded in other income (expense)—net on the condensed

[0001262039-25-000017:notes:32]
consolidated statements of income. We recognized a $14.7 million loss and $0.3 million gain during the three months ended March 31, 2025 and 2024, respectively.

[0001262039-25-000017:notes:33]
[same as prior period, unchanged from 0001262039-24-000043:notes:43]

[0001262039-25-000017:notes:34]
[same as prior period, unchanged from 0001262039-24-000043:notes:44]

[0001262039-25-000017:notes:35]
|  | March 31, 2025 |  | December 31, 2024 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 260.3 |  |  | $ | 260.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 296.1 |  |  | $ | 296.1 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper | 86.5 |  |  | — |  |  | 86.5 |  |  | — |  |  | 59.7 |  |  | — |  |  | 59.7 |  |  | — |  |
| Total cash equivalents | 346.8 |  |  | 260.3 |  |  | 86.5 |  |  | — |  |  | 355.8 |  |  | 296.1 |  |  | 59.7 |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 451.5 |  |  | 446.5 |  |  | 5.0 |  |  | — |  |  | 469.5 |  |  | 464.5 |  |  | 5.0 |  |  | — |  |
| Commercial paper | 432.8 |  |  | — |  |  | 432.8 |  |  | — |  |  | 428.7 |  |  | — |  |  | 428.7 |  |  | — |  |
| Corporate debt securities | 158.1 |  |  | — |  |  | 158.1 |  |  | — |  |  | 166.4 |  |  | — |  |  | 166.4 |  |  | — |  |
| Certificates of deposit and term deposits | 73.9 |  |  | — |  |  | 73.9 |  |  | — |  |  | 61.8 |  |  | — |  |  | 61.8 |  |  | — |  |
| Marketable equity securities | 67.6 |  |  | 67.6 |  |  | — |  |  | — |  |  | 64.2 |  |  | 64.2 |  |  | — |  |  | — |  |
| Total short-term investments | 1,183.9 |  |  | 514.1 |  |  | 669.8 |  |  | — |  |  | 1,190.6 |  |  | 528.7 |  |  | 661.9 |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 35.2 |  |  | 35.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,565.9 |  |  | $ | 809.6 |  |  | $ | 756.3 |  |  | $ | — |  |  | $ | 1,546.4 |  |  | $ | 824.8 |  |  | $ | 721.6 |  |  | $ | — |  |

[0001262039-25-000017:notes:36]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2025 and year ended December 31, 2024.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-25-000017:notes:37]
[same as prior period, unchanged from 0001262039-24-000043:notes:47]

[0001262039-25-000017:notes:38]
|  | March 31,2025 |  | December 31,2024 |
| Raw materials | $ | 80.7 |  |  | $ | 90.9 |  |
| Work in process | 5.3 |  |  | 4.1 |  |
| Finished goods | 276.7 |  |  | 220.5 |  |
| Inventory | $ | 362.7 |  |  | $ | 315.5 |  |

[0001262039-25-000017:notes:39]
The excess and obsolete inventory reserve was $147.8 million and $144.8 million as of March 31, 2025 and December 31, 2024, respectively. Inventory write-downs related to excess and obsolete inventory were not material during the three months ended March 31, 2025. Inventory write-downs were $18.1 million during the three months ended March 31, 2024. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-25-000017:notes:40]
[same as prior period, unchanged from 0001262039-24-000043:notes:50]

[0001262039-25-000017:notes:41]
|  | March 31,2025 |  | December 31,2024 |
| Land | $ | 517.6 |  |  | $ | 500.6 |  |
| Buildings and improvements | 842.9 |  |  | 801.4 |  |
| Computer equipment and software | 295.5 |  |  | 279.1 |  |
| Leasehold improvements | 63.5 |  |  | 64.3 |  |
| Evaluation units | 31.9 |  |  | 31.8 |  |
| Furniture and fixtures | 36.8 |  |  | 36.4 |  |
| Construction-in-progress | 48.6 |  |  | 52.0 |  |
| Total property and equipment | 1,836.8 |  |  | 1,765.6 |  |
| Less: accumulated depreciation | (433.0) |  |  | (416.1) |  |
| Property and equipment—net | $ | 1,403.8 |  |  | $ | 1,349.5 |  |

[0001262039-25-000017:notes:42]
During the first quarter in 2025, we purchased certain real estate property in Frankfurt, Germany totaling $54.5 million, to be used predominantly for data center operations and as office space. The purchase was accounted for under the asset acquisition method. The costs of the assets allocated to land and building and improvements were $16.8 million and $37.7 million, respectively, based on their relative fair values.
Depreciation expense was $24.0 million and $25.6 million during the three months ended March 31, 2025 and 2024, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-25-000017:notes:43]
BUSINESS COMBINATIONS
Linksys Holdings, Inc.

[0001262039-25-000017:notes:44]
In 2021, we invested $160.0 million in cash for shares of the Series A Preferred Stock of Linksys for a 50.8% ownership interest in the outstanding equity of Linksys. On January 31, 2025 (“Linksys Acquisition Date”), we acquired all of the remaining outstanding Series A Preferred Stock of Linksys for $20.8 million in cash and now own 100% of the outstanding equity of Linksys. Our pre-existing equity method investment in Linksys of 50.8% ownership interest was remeasured to the fair value of $21.5 million at the Linksys Acquisition Date, which resulted in a $10.8 million gain recorded in gain (loss) from equity method investments on the condensed consolidated statements of income. Therefore, the aggregate purchase consideration for Linksys’ equity equaling the fair value of the previously owned stock and the purchase price for the remaining stock acquired was $42.3 million.

[0001262039-25-000017:notes:45]
This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the aggregate purchase price, $17.5 million was allocated to identifiable intangible assets acquired, and $64.7 million was allocated to other net assets acquired which predominantly included deferred tax asset of $45.8 million, inventory of $21.4 million, and cash of $8.8 million, offset by $11.3 million of net other assets and liabilities assumed. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $39.9 million within other income (expense)—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. In addition, we had previously recorded a deferred tax asset of $30.6 million for an outside basis difference in our investment in Linksys when it was accounted for under the equity method. As a result of the acquisition of the remaining shares, we now account for our investment in Linksys under the consolidation method, and therefore we have derecognized this deferred tax asset. The charge is included in the provision for income taxes on the condensed consolidated statements of income. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000017:notes:46]
Perception Point Ltd.

[0001262039-25-000017:notes:47]
On December 5, 2024, we acquired certain assets and liabilities of Perception Point Ltd., a business specializing in advanced collaboration and email security paid in cash. This acquisition was accounted for as a business combination using the

[0001262039-25-000017:notes:48]
acquisition method of accounting. Of the $33.7 million purchase price, $24.5 million was allocated to goodwill, $9.5 million was allocated to developed technology intangible asset, $6.5 million was allocated to customer relationships intangible asset, and $6.8 million was allocated to other net liabilities assumed, which predominantly include deferred revenue. Goodwill recorded in connection with this acquisition is primarily attributable to the assembled workforce acquired and the anticipated operational synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expense.

[0001262039-25-000017:notes:49]
[same as prior period, unchanged from 0001262039-24-000043:notes:69]

[0001262039-25-000017:notes:50]
On August 5, 2024 (“Next DLP Acquisition Date”), we acquired Next DLP Holdings Limited (“Next DLP”), a privately held insider risk and data loss prevention (“DLP”) company, for approximately $105.0 million in cash. We acquired Next DLP in an effort to improve our position in the standalone enterprise DLP market and strengthen our leadership in integrated DLP markets within endpoint and unified Secure Access Service Edge (“SASE”).

[0001262039-25-000017:notes:51]
[same as prior period, unchanged from 0001262039-24-000043:notes:71]

[0001262039-25-000017:notes:52]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the Next DLP Acquisition Date. The allocation of the purchase price has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-25-000017:notes:53]
Lacework Inc.

[0001262039-25-000017:notes:54]
On August 1, 2024 (“Lacework Acquisition Date”), we acquired Lacework Inc. (“Lacework”), a privately held data-driven cloud security company, for $152.3 million in cash. We acquired Lacework with a goal of offering its Cloud-Native Application Protection Platform solution separately as well as integrated with our existing portfolio, forming a comprehensive, artificial intelligence (“AI”)-driven cloud security platform available from a single vendor, which will help customers identify, prioritize, and remediate risks and threats in complex cloud-native infrastructure from code to cloud.

[0001262039-25-000017:notes:55]
This acquisition was accounted for as a business combination using the acquisition method of accounting. The total preliminary purchase price was allocated to Lacework’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. Of the total preliminary purchase price, $244.4 million was allocated to deferred tax assets, $61.3 million allocation to identifiable intangible assets, and $6.2 million cash, offset by net other assets and liabilities assumed of $53.3 million, which predominantly included deferred revenue and other current liabilities. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $106.3 million within other income (expense)—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets. The deferred tax assets were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.

[0001262039-25-000017:notes:56]
Of the total identified intangible assets acquired $39.5 million was developed technology, $10.0 million was backlog, $7.5 million was customer relationships and $4.3 million was trade name.

[0001262039-25-000017:notes:57]
Our estimates and assumptions are subject to change within the measurement period, which is up to 12 months after the Lacework Acquisition Date. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary area of the purchase price that is not yet finalized is related to income taxes.

[0001262039-25-000017:notes:58]
Additional acquisition-related information

[0001262039-25-000017:notes:59]
The operating results of the acquired companies are included in our condensed consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. The operating results of the acquired companies were not material in the years of acquisition. Pro forma information has not been presented, as the impact of these acquisitions, individually and in the aggregate, in each period were not material to our condensed consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-25-000017:notes:60]
[same as prior period, unchanged from 0001262039-24-000043:notes:77]

[0001262039-25-000017:notes:61]
[same as prior period, unchanged from 0001262039-24-000043:notes:78]

[0001262039-25-000017:notes:62]
|  | Amount |
| Balance—December 31, 2024 | $ | 235.4 |  |
| Foreign currency translation adjustments | 0.8 |  |
| Balance—March 31, 2025 | $ | 236.2 |  |

[0001262039-25-000017:notes:63]
There were no impairments to goodwill during the three months ended March 31, 2025 or during prior periods.

[0001262039-25-000017:notes:64]
[same as prior period, unchanged from 0001262039-24-000043:notes:81]

[0001262039-25-000017:notes:65]
[same as prior period, unchanged from 0001262039-24-000043:notes:82]

[0001262039-25-000017:notes:66]
|  | March 31, 2025 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 149.3 |  |  | $ | 79.8 |  |  | $ | 69.5 |  |
| Customer relationships | 5.4 |  | 62.7 |  |  | 27.8 |  |  | 34.9 |  |
| Trade name | 7.0 |  | 11.5 |  |  | 2.3 |  |  | 9.2 |  |
| Backlog | 2.5 |  | 13.7 |  |  | 6.1 |  |  | 7.6 |  |
| Total other intangible assets—net |  |  | $ | 237.2 |  |  | $ | 116.0 |  |  | $ | 121.2 |  |

[0001262039-25-000017:notes:67]
|  | December 31, 2024 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.4 |  | $ | 141.9 |  |  | $ | 73.7 |  |  | $ | 68.2 |  |
| Customer relationships | 5.5 |  | 53.9 |  |  | 23.0 |  |  | 30.9 |  |
| Trade name | 7.5 |  | 8.8 |  |  | 1.8 |  |  | 7.0 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 4.6 |  |  | 8.9 |  |
| Total other intangible assets—net |  |  | $ | 218.1 |  |  | $ | 103.1 |  |  | $ | 115.0 |  |

[0001262039-25-000017:notes:68]
Amortization expense was $11.8 million and $3.0 million during the three months ended March 31, 2025 and 2024, respectively.

[0001262039-25-000017:notes:69]
[same as prior period, unchanged from 0001262039-24-000043:notes:86]

[0001262039-25-000017:notes:70]
|  | Amount |
| Years: |  |
| 2025 (the remainder of 2025) | $ | 33.1 |  |
| 2026 | 31.0 |  |
| 2027 | 24.9 |  |
| 2028 | 18.5 |  |
| 2029 | 9.5 |  |
| Thereafter | 4.2 |  |
| Total | $ | 121.2 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-25-000017:notes:71]
[same as prior period, unchanged from 0001262039-24-000043:notes:88]

[0001262039-25-000017:notes:72]
[same as prior period, unchanged from 0001262039-24-000043:notes:89]

[0001262039-25-000017:notes:73]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 433.4 |  |  | $ | 299.3 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 768.3 |  |  | 762.4 |  |  |  |  |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 768.3 |  |  | 762.4 |  |  |  |  |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 3.3 |  |  | 2.7 |  |  |  |  |  |
| Stock options | 4.6 |  |  | 5.1 |  |  |  |  |  |
| PSUs | 0.6 |  |  | 0.3 |  |  |  |  |  |
| Weighted-average shares used to compute diluted net income per share | 776.8 |  |  | 770.5 |  |  |  |  |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.56 |  |  | $ | 0.39 |  |  |  |  |  |
| Diluted | $ | 0.56 |  |  | $ | 0.39 |  |  |  |  |  |

[0001262039-25-000017:notes:74]
[same as prior period, unchanged from 0001262039-24-000043:notes:91]

[0001262039-25-000017:notes:75]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| RSUs | 0.8 |  |  | — |  |  |  |  |  |
| Stock options | 0.4 |  |  | 3.1 |  |  |  |  |  |
| Total | 1.2 |  |  | 3.1 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-25-000017:notes:76]
DEBT
2026 and 2031 Senior Notes

[0001262039-25-000017:notes:77]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of March 31, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-25-000017:notes:78]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-25-000017:notes:79]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 498.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.2 |  |  | $ | 994.3 |  |

[0001262039-25-000017:notes:80]
As of March 31, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the three months ended March 31, 2025 and 2024, as the costs that qualified for capitalization were not material.

[0001262039-25-000017:notes:81]
The total estimated fair value of the outstanding Senior Notes was approximately $919.6 million, including accrued and unpaid interest, as of March 31, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-25-000017:notes:82]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2025 (in millions):

[0001262039-25-000017:notes:83]
|  | Total |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 689.0 |  |  | $ | 686.1 |  |  | $ | 2.9 |  |

[0001262039-25-000017:notes:84]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-25-000017:notes:85]
As of March 31, 2025, we had $689.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $47.5 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $4.5 million benefit and a $31.6 million cost during the three months ended March 31, 2025 and 2024, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.

[0001262039-25-000017:notes:86]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2025, we had $94.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-25-000017:notes:87]
As of March 31, 2025, we had $81.6 million in contractual commitments related to payments for operating leases.

[0001262039-25-000017:notes:88]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2025, and December 31, 2024.

[0001262039-25-000017:notes:89]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of March 31, 2025 or December 31, 2024 related to this litigation.

[0001262039-25-000017:notes:90]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the

[0001262039-25-000017:notes:91]
indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-25-000017:notes:92]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-25-000017:notes:93]
[same as prior period, unchanged from 0001262039-24-000043:notes:110]

[0001262039-25-000017:notes:94]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of March 31, 2025, there were a total of 48.8 million shares of common stock available for grant under the Amended Plan.

[0001262039-25-000017:notes:95]
[same as prior period, unchanged from 0001262039-24-000043:notes:112]

[0001262039-25-000017:notes:96]
[same as prior period, unchanged from 0001262039-24-000043:notes:113]

[0001262039-25-000017:notes:97]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2024 | 8.4 |  |  | $ | 64.70 |  |
| Granted | 2.0 |  |  | 110.02 |  |
| Forfeited | (0.3) |  |  | 70.79 |  |
| Vested | (1.4) |  |  | 58.23 |  |
| Balance—March 31, 2025 | 8.7 |  |  | $ | 75.85 |  |

[0001262039-25-000017:notes:98]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of March 31, 2025, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $605.6 million, with a weighted-average remaining vesting period of 3.0 years.

[0001262039-25-000017:notes:99]
[same as prior period, unchanged from 0001262039-24-000043:notes:127]

[0001262039-25-000017:notes:100]
We grant market/performance-based PSUs under the Amended Plan to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the performance period, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total

[0001262039-25-000017:notes:101]
stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-25-000017:notes:102]
[same as prior period, unchanged from 0001262039-24-000043:notes:129]

[0001262039-25-000017:notes:103]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Expected term in years | 2.7 |  | 2.7 |  |  |  |  |
| Volatility | 41.5 | % |  | 45.5 | % |  |  |  |  |
| Risk-free interest rate | 4.2 | % |  | 4.5 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-25-000017:notes:104]
We granted approximately 0.1 million and 0.3 million shares of PSU awards with a weighted-average grant date fair value of $168.93 and $98.19 per share to certain of our executives during the three months ended March 31, 2025 and 2024, respectively. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. Approximately 0.2 million and 0.1 million shares of PSU awards vested during the three months ended March 31, 2025 and 2024, respectively. None of these PSU awards were forfeited during the three months ended March 31, 2025 and 2024, respectively.

[0001262039-25-000017:notes:105]
As of March 31, 2025, total compensation expense related to unvested PSUs that were granted to certain of our executives, but not yet recognized, was $40.0 million. This expense is expected to be amortized on a graded vesting method over a weighted-average vesting period of 2.4 years.

[0001262039-25-000017:notes:106]
RSUs and PSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs and PSUs, we net-settle the RSUs and PSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the condensed consolidated statements of cash flows.

[0001262039-25-000017:notes:107]
[same as prior period, unchanged from 0001262039-24-000043:notes:117]

[0001262039-25-000017:notes:108]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Shares withheld for taxes | 0.5 |  |  | 0.6 |  |  |  |  |  |
| Amount withheld for taxes | $ | 53.8 |  |  | $ | 42.9 |  |  |  |  |  |

[0001262039-25-000017:notes:109]
[same as prior period, unchanged from 0001262039-24-000043:notes:119]

[0001262039-25-000017:notes:110]
[same as prior period, unchanged from 0001262039-24-000043:notes:120]

[0001262039-25-000017:notes:111]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Expected term in years | 4.5 |  | 4.5 |  |  |  |  |
| Volatility | 41.6 | % |  | 42.9 | % |  |  |  |  |
| Risk-free interest rate | 4.2 | % |  | 4.3 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-25-000017:notes:112]
[same as prior period, unchanged from 0001262039-24-000043:notes:122]

[0001262039-25-000017:notes:113]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2024 | 8.7 |  |  | $ | 37.81 |  |  | 3.1 |  | $ | 493.8 |  |
| Granted | 0.5 |  |  | 110.02 |  |  |  |  |  |
| Forfeited | — |  |  | 65.88 |  |  |  |  |  |
| Exercised | (1.1) |  |  | 17.56 |  |  |  |  |  |
| Balance—March 31, 2025 | 8.1 |  |  | $ | 45.46 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2025 | 8.1 |  |  | $ | 45.46 |  |  | 3.4 |  | $ | 418.1 |  |
| Options exercisable—March 31, 2025 | 6.0 |  |  | $ | 34.98 |  |  | 2.6 |  | $ | 368.2 |  |

[0001262039-25-000017:notes:114]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of the balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of March 31, 2025, total compensation expense related to unvested stock options granted to employees but not yet recognized was $61.3 million, with a weighted-average remaining vesting period of 2.8 years.

[0001262039-25-000017:notes:115]
[same as prior period, unchanged from 0001262039-24-000043:notes:125]

[0001262039-25-000017:notes:116]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Weighted-average fair value per share granted | $ | 44.34 |  |  | $ | 26.92 |  |  |  |  |  |
| Intrinsic value of options exercised | $ | 102.3 |  |  | $ | 51.8 |  |  |  |  |  |
| Fair value of options vested | $ | 9.5 |  |  | $ | 12.1 |  |  |  |  |  |

[0001262039-25-000017:notes:117]
[same as prior period, unchanged from 0001262039-24-000043:notes:133]

[0001262039-25-000017:notes:118]
[same as prior period, unchanged from 0001262039-24-000043:notes:134]

[0001262039-25-000017:notes:119]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.5 |  |  |  |  |  |
| Cost of service revenue | 6.5 |  |  | 6.2 |  |  |  |  |  |
| Research and development | 23.0 |  |  | 19.8 |  |  |  |  |  |
| Sales and marketing | 26.5 |  |  | 26.7 |  |  |  |  |  |
| General and administrative | 10.4 |  |  | 9.8 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 66.9 |  |  | $ | 63.0 |  |  |  |  |  |

[0001262039-25-000017:notes:120]
[same as prior period, unchanged from 0001262039-24-000043:notes:136]

[0001262039-25-000017:notes:121]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| RSUs | $ | 56.3 |  |  | $ | 52.0 |  |  |  |  |  |
| Stock options | 6.6 |  |  | 7.3 |  |  |  |  |  |
| PSUs | 4.0 |  |  | 3.7 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 66.9 |  |  | $ | 63.0 |  |  |  |  |  |

[0001262039-25-000017:notes:122]
[same as prior period, unchanged from 0001262039-24-000043:notes:138]

[0001262039-25-000017:notes:123]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 14.7 |  |  | $ | 13.9 |  |  |  |  |  |

[0001262039-25-000017:notes:124]
[same as prior period, unchanged from 0001262039-24-000043:notes:140]

[0001262039-25-000017:notes:125]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.
There were no shares repurchased under the Repurchase Program during the three months ended March 31, 2025. As of March 31, 2025, approximately $2.03 billion remained available for future share repurchases under the Repurchase Program. Refer to Note 15. Subsequent Events for information regarding our repurchases of 4.6 million shares of our common stock for an aggregate purchase price of $401.1 million, under the Repurchase Program, subsequent to March 31, 2025 through the filing of this Quarterly Report on Form 10-Q.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-25-000017:notes:126]
INCOME TAXES
Our effective tax rate was 19% for the three months ended March 31, 2025, compared to an effective tax rate of 11% for the same period last year. The tax rates for the three months ended March 31, 2025 and 2024 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $128.5 million and $81.7 million, respectively. The tax rate for the three months ended March 31, 2025 included a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys, a tax benefit of $25.8 million from the foreign-derived intangible income (“FDII”) deduction, and excess tax benefits from stock-based compensation expense of $36.8 million. The tax rate for the three months ended March 31, 2024 was impacted by a tax benefit of $24.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $18.2 million.

[0001262039-25-000017:notes:127]
As of March 31, 2025 and December 31, 2024, unrecognized tax benefits were $79.0 million and $75.9 million, respectively. If recognized, $64.0 million of the unrecognized tax benefits as of March 31, 2025 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of March 31, 2025 and December 31, 2024, accrued interest and penalties were $9.8 million and $8.8 million, respectively.

[0001262039-25-000017:notes:128]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2020 and by U.S. state and foreign tax authorities in our significant jurisdictions for tax years prior to 2016. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-25-000017:notes:129]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the Internal Revenue Service (“IRS”) released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. The OECD continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the three months ended March 31, 2025. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-25-000017:notes:130]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make pre-tax contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2025 and 2024 were $5.6 million and $6.3 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-25-000017:notes:131]
[same as prior period, unchanged from 0001262039-24-000043:notes:151]

[0001262039-25-000017:notes:132]
The following table reflects certain financial data for our reportable segment (in millions):

[0001262039-25-000017:notes:133]
|  | Three Months Ended |
| March 31, 2025 |  | March 31, 2024 |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |
| Less: |  |  |  |
| Cost of product revenue | 149.9 |  |  | 182.8 |  |
| Cost of service revenue | 143.2 |  |  | 121.9 |  |
| Research and development expense | 198.6 |  |  | 173.0 |  |
| Other sales and marketing expense (1) | 439.7 |  |  | 412.6 |  |
| Commission expense | 103.0 |  |  | 88.5 |  |
| General and administrative expense | 57.8 |  |  | 54.4 |  |
| Other segment items (2) | 82.4 |  |  | 18.7 |  |
| Provision for income taxes | 96.5 |  |  | 39.5 |  |
| Net income | $ | 433.4 |  |  | $ | 299.3 |  |

[0001262039-25-000017:notes:134]
(1) Excludes commission expense.

[0001262039-25-000017:notes:135]
(2) The following table presents other segment items (in millions):

[0001262039-25-000017:notes:136]
|  | Three Months Ended |
| March 31, 2025 |  | March 31, 2024 |
| Gain on intellectual property matters | $ | 6.3 |  |  | $ | 1.1 |  |
| Interest income | 44.3 |  |  | 32.2 |  |
| Interest expense | (4.9) |  |  | (5.1) |  |
| Other income (expense)—net | 26.1 |  |  | (2.9) |  |
| Gain (loss) from equity method investments | 10.6 |  |  | (6.6) |  |
| Total other segment items | $ | 82.4 |  |  | $ | 18.7 |  |

[0001262039-25-000017:notes:137]
The following table presents other segment information (in millions):

[0001262039-25-000017:notes:138]
|  | Three Months Ended |
| March 31, 2025 |  | March 31, 2024 |
| Significant non-cash items: |  |  |  |
| Stock‐based compensation expense | $ | 66.9 |  |  | $ | 63.0 |  |
| Depreciation and amortization expense | 35.8 |  |  | 28.6 |  |
| Total assets | $ | 10,407.0 |  |  | $ | 7,662.1 |  |
| Purchases of property and equipment | $ | 66.5 |  |  | $ | 221.9 |  |

[0001262039-25-000017:notes:139]
[same as prior period, unchanged from 0001262039-24-000043:notes:152]

[0001262039-25-000017:notes:140]
|  | Three Months Ended |  |  |
| Revenue | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 455.4 |  |  | $ | 407.1 |  |  |  |  |  |
| Other Americas | 174.4 |  |  | 149.9 |  |  |  |  |  |
| Total Americas | 629.8 |  |  | 557.0 |  |  |  |  |  |
| Europe, Middle East and Africa (“EMEA”) | 628.4 |  |  | 539.4 |  |  |  |  |  |
| Asia Pacific (“APAC”) | 281.5 |  |  | 256.9 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |

[0001262039-25-000017:notes:141]
| Property and Equipment—net | March 31,2025 |  | December 31,2024 |
| Americas: |  |  |  |
| United States | $ | 993.5 |  |  | $ | 993.5 |  |
| Canada | 215.8 |  |  | 216.8 |  |
| Latin America | 2.4 |  |  | 4.4 |  |
| Total Americas | 1,211.7 |  |  | 1,214.7 |  |
| EMEA | 129.3 |  |  | 73.3 |  |
| APAC | 62.8 |  |  | 61.5 |  |
| Total property and equipment—net | $ | 1,403.8 |  |  | $ | 1,349.5 |  |

[0001262039-25-000017:notes:142]
[same as prior period, unchanged from 0001262039-24-000043:notes:155]

[0001262039-25-000017:notes:143]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Distributor A | 28 | % |  | 31 | % |  |  |  |  |
| Distributor B | 14 | % |  | 15 | % |  |  |  |  |
| Distributor C | 12 | % |  | 13 | % |  |  |  |  |

[0001262039-25-000017:notes:144]
[same as prior period, unchanged from 0001262039-24-000043:notes:157]

[0001262039-25-000017:notes:145]
|  | March 31,2025 |  | December 31,2024 |
| Distributor A | 28 | % |  | 31 | % |
| Distributor B | 11 | % |  | 14 | % |
| Distributor C | 13 | % |  | 10 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-25-000017:notes:146]
SUBSEQUENT EVENTS
Share Repurchase Program

[0001262039-25-000017:notes:147]
Subsequent to March 31, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 4.6 million shares of our common stock at an average price of $87.89 per share, for an aggregate purchase price of $401.1 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.63 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.

[0001262039-25-000017:notes:148]
Real Property Purchases

[0001262039-25-000017:notes:149]
In April 2025, we purchased real property in Burnaby, Canada, totaling approximately 245,000 square feet, to be used for office space, for $99.9 million in cash.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-25-000017:notes:150]
On March 7, 2025, Margrit Christiane Ohlgart, our Chief Accounting Officer, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Ohlgart Plan”) during an open trading window in accordance with our insider trading policy. The Ohlgart Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Ohlgart Plan provides for the potential sale by Mrs. Ohlgart of net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon vesting and settlement of RSUs and PSUs, in each case, at the market price, all between June 6, 2025 and September 5, 2026.

[0001262039-25-000017:notes:151]
On March 3, 2025, John Whittle, our Chief Operating Officer, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Whittle Plan”) during an open trading window in accordance with our insider trading policy. The Whittle Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Whittle Plan provides for the potential sale by Mr. Whittle of up to 146,015 shares of our common stock, issued upon the exercise of vested stock options for shares of our common stock, at the market price, between June 2, 2025 and July 31, 2026.
