# FTNT 8-K — 0001262039-25-000014 filed 2025-05-07

## item codes, every 8-K on or before 2025-05-08

- 2025-05-07 0001262039-25-000014 — 2.02, 9.01
- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2025-05-08

- none on or before 2025-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-25-000014:8k_2_02:1]
EX-99.1
2
ftntq1-2025ex991.htm
PRESS RELEASE

[0001262039-25-000014:8k_2_02:2]
Document

[0001262039-25-000014:8k_2_02:3]
Press Release

[0001262039-25-000014:8k_2_02:4]
Fortinet Reports First Quarter 2025 Financial Results

[0001262039-25-000014:8k_2_02:5]
Highlights

[0001262039-25-000014:8k_2_02:6]
•Total revenue of $1.54 billion, up 14% year over year

[0001262039-25-000014:8k_2_02:7]
•Product revenue of $459 million, up 12% year over year

[0001262039-25-000014:8k_2_02:8]
•Billings of $1.60 billion, up 14% year over year1

[0001262039-25-000014:8k_2_02:9]
•Unified SASE ARR2 up 26% and Security Operations ARR2 up 30%, year over year

[0001262039-25-000014:8k_2_02:10]
•Record first quarter GAAP operating margin of 29%

[0001262039-25-000014:8k_2_02:11]
•Record first quarter Non-GAAP operating margin of 34%1

[0001262039-25-000014:8k_2_02:12]
•Record Cash flow from operations of $863 million

[0001262039-25-000014:8k_2_02:13]
•Record Free cash flow of $783 million1

[0001262039-25-000014:8k_2_02:14]
SUNNYVALE, Calif. - May 7, 2025 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the first quarter ended March 31, 2025.

[0001262039-25-000014:8k_2_02:15]
“We are pleased to report another strong quarter as non-GAAP operating margin increased 570 basis points year over year to a first quarter record of 34%, while billings grew 14% year over year,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “We continue to accelerate our growth strategy by investing in the rapidly expanding Unified SASE and Security Operations markets, while strengthening our leadership in Secure Networking. Leveraging our deep expertise in networking and security convergence, a strong track record of AI-driven innovation, and seamless product development and integration through our FortiOS operating system, we have established ourselves as the leader in organic innovation and will continue setting the industry standard in cybersecurity.”

[0001262039-25-000014:8k_2_02:16]
Financial Highlights for the First Quarter of 2025

[0001262039-25-000014:8k_2_02:17]
•Revenue: Total revenue was $1.54 billion for the first quarter of 2025, an increase of 13.8% compared to $1.35 billion for the same quarter of 2024.

[0001262039-25-000014:8k_2_02:18]
•Product Revenue: Product revenue was $459.1 million for the first quarter of 2025, an increase of 12.3% compared to $408.9 million for the same quarter of 2024.

[0001262039-25-000014:8k_2_02:19]
•Service Revenue: Service revenue was $1.08 billion for the first quarter of 2025, an increase of 14.4% compared to $944.4 million for the same quarter of 2024.

[0001262039-25-000014:8k_2_02:20]
•Billings1: Total billings were $1.60 billion for the first quarter of 2025, an increase of 13.5% compared to $1.41 billion for the same quarter of 2024.

[0001262039-25-000014:8k_2_02:21]
•Remaining performance obligations: Remaining performance obligations were $6.49 billion as of March 31, 2025, an increase of 11.7% compared to $5.81 billion as of March 31, 2024. We expect to recognize approximately $3.38 billion as revenue over the next 12 months, an increase of 15.4% compared to $2.93 billion as of March 31, 2024.

[0001262039-25-000014:8k_2_02:22]
•Unified SASE ARR2: Unified SASE ARR was $1.15 billion as of March 31, 2025, an increase of 25.7% compared to $914.7 million as of March 31, 2024.

[0001262039-25-000014:8k_2_02:23]
•Security Operations ARR2: Security Operations ARR was $434.5 million as of March 31, 2025, an increase of 30.3% compared to $333.5 million as of March 31, 2024.

[0001262039-25-000014:8k_2_02:24]
•GAAP Operating Income and Margin: GAAP operating income was $453.8 million for the first quarter of 2025, representing a GAAP operating margin of 29.5%. GAAP operating income was $321.2 million for the same quarter of 2024, representing a GAAP operating margin of 23.7%.

[0001262039-25-000014:8k_2_02:25]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $526.2 million for the first quarter of 2025, representing a non-GAAP operating margin of 34.2%. Non-GAAP operating income was $386.1 million for the same quarter of 2024, representing a non-GAAP operating margin of 28.5%.

[0001262039-25-000014:8k_2_02:26]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $433.4 million for the first quarter of 2025, compared to GAAP net income of $299.3 million for the same quarter of 2024. GAAP diluted net income per share was $0.56 for the first quarter of 2025, based on 776.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.39 for the same quarter of 2024, based on 770.5 million diluted weighted-average shares outstanding.

[0001262039-25-000014:8k_2_02:27]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $452.3 million for the first quarter of 2025, compared to non-GAAP net income of $333.9 million for the same quarter of 2024. Non-GAAP diluted net income per share was $0.58 for the first quarter of 2025, based on 776.8 million diluted weighted-average shares outstanding, compared to $0.43 for the same quarter of 2024, based on 770.5 million diluted weighted-average shares outstanding.

[0001262039-25-000014:8k_2_02:28]
•Cash Flow: Cash flow from operations was $863.3 million for the first quarter of 2025, compared to $830.4 million for the same quarter of 2024. Cash flow from operations for the first quarter of 2025 includes $14.0 million proceeds from an intellectual property matter.

[0001262039-25-000014:8k_2_02:29]
•Free Cash Flow1: Free cash flow was $782.8 million for the first quarter of 2025, compared to $608.5 million for the same quarter of 2024.

[0001262039-25-000014:8k_2_02:30]
Guidance

[0001262039-25-000014:8k_2_02:31]
For the second quarter of 2025, Fortinet currently expects:

[0001262039-25-000014:8k_2_02:32]
•Revenue in the range of $1.590 billion to $1.650 billion

[0001262039-25-000014:8k_2_02:33]
•Billings in the range of $1.685 billion to $1.765 billion

[0001262039-25-000014:8k_2_02:34]
•Non-GAAP gross margin in the range of 80.0% to 81.0%

[0001262039-25-000014:8k_2_02:35]
•Non-GAAP operating margin in the range of 31.5% to 32.5%

[0001262039-25-000014:8k_2_02:36]
•Diluted non-GAAP net income per share in the range of $0.58 to $0.60, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 773 million to 777 million.

[0001262039-25-000014:8k_2_02:37]
For the fiscal year 2025, Fortinet currently expects:

[0001262039-25-000014:8k_2_02:38]
•Revenue in the range of $6.650 billion to $6.850 billion

[0001262039-25-000014:8k_2_02:39]
•Service revenue in the range of $4.575 billion to $4.725 billion

[0001262039-25-000014:8k_2_02:40]
•Billings in the range of $7.200 billion to $7.400 billion

[0001262039-25-000014:8k_2_02:41]
•Non-GAAP gross margin in the range of 79.0% to 81.0%

[0001262039-25-000014:8k_2_02:42]
•Non-GAAP operating margin in the range of 31.5% to 33.5%

[0001262039-25-000014:8k_2_02:43]
•Diluted non-GAAP net income per share in the range of $2.43 to $2.49, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 769 million to 779 million.

[0001262039-25-000014:8k_2_02:44]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, gain on intellectual property matters, gain on bargain purchase related to acquisition, gain from an equity method investment and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-25-000014:8k_2_02:45]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures”.

[0001262039-25-000014:8k_2_02:46]
2 Annual Recurring Revenue or ARR is defined as the annualized value of renewable / recurring customer agreements as of the measurement date, assuming any contract that expires during the next 12 months is renewed at its existing value.

[0001262039-25-000014:8k_2_02:47]
Conference Call Details

[0001262039-25-000014:8k_2_02:48]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-25-000014:8k_2_02:49]
Second Quarter 2025 Conference Participation Schedule:

[0001262039-25-000014:8k_2_02:50]
•J.P. Morgan Global Technology, Media and Communications Conference

[0001262039-25-000014:8k_2_02:51]
May 13, 2025

[0001262039-25-000014:8k_2_02:52]
•Bank of America Global Technology Conference

[0001262039-25-000014:8k_2_02:53]
June 3, 2025

[0001262039-25-000014:8k_2_02:54]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-25-000014:8k_2_02:55]
About Fortinet (www.fortinet.com)

[0001262039-25-000014:8k_2_02:56]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-25-000014:8k_2_02:57]
#          #          #

[0001262039-25-000014:8k_2_02:58]
Copyright © 2025 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiBranchSASE, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiCNP, FortiConnect, FortiController, FortiConverter, FortiCSPM, FortiCWP, FortiDAST, FortiDATA, FortiDB, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHypervisor, FortiInsight, FortiIsolator, FortiLAN, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPenTest, FortiPhish, FortiPoint, FortiPoints, FortiPolicy, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiScanner, FortiSDNConnector, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSRA, FortiSwitch, FortiTelemetry, FortiTester, FortiTIP, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR, Lacework FortiCNAPP, Linksys, Intelligent Mesh, Velop, Max-Stream, Performance Perfected and SECURITY FABRIC. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-25-000014:8k_2_02:59]
FTNT-F

[0001262039-25-000014:8k_2_02:60]
Forward-Looking Statements

[0001262039-25-000014:8k_2_02:61]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the second quarter and full year 2025, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or

[0001262039-25-000014:8k_2_02:62]
Non-GAAP Financial Measures

[0001262039-25-000014:8k_2_02:63]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-25-000014:8k_2_02:64]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-25-000014:8k_2_02:65]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business and cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-25-000014:8k_2_02:66]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matters. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matters, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matters, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our proceeds from intellectual property matters, our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-25-000014:8k_2_02:67]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, amortization of acquired intangible assets, less gain on intellectual property matters and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-25-000014:8k_2_02:68]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain on bargain purchase related to acquisition, a gain from an equity method investment related to acquisition and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-25-000014:8k_2_02:69]
FORTINET, INC.

[0001262039-25-000014:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-25-000014:8k_2_02:71]
(Unaudited, in millions)

[0001262039-25-000014:8k_2_02:72]
|  | March 31,2025 |  | December 31,2024 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 3,596.6 |  |  | $ | 2,875.9 |  |
| Short-term investments | 1,183.9 |  |  | 1,190.6 |  |
| Accounts receivable—net | 1,174.0 |  |  | 1,463.4 |  |
| Inventory | 362.7 |  |  | 315.5 |  |
| Prepaid expenses and other current assets | 125.4 |  |  | 126.1 |  |
| Total current assets | 6,442.6 |  |  | 5,971.5 |  |
| LONG-TERM INVESTMENTS | 35.2 |  |  | — |  |
| PROPERTY AND EQUIPMENT—NET | 1,403.8 |  |  | 1,349.5 |  |
| DEFERRED CONTRACT COSTS | 636.2 |  |  | 622.9 |  |
| DEFERRED TAX ASSETS | 1,411.6 |  |  | 1,335.6 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 357.4 |  |  | 350.4 |  |
| OTHER ASSETS | 120.2 |  |  | 133.2 |  |
| TOTAL ASSETS | $ | 10,407.0 |  |  | $ | 9,763.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 224.5 |  |  | $ | 190.9 |  |
| Accrued liabilities | 415.0 |  |  | 337.9 |  |
| Accrued payroll and compensation | 250.2 |  |  | 255.7 |  |
| Current portion of long-term debt | 498.7 |  |  | — |  |
| Deferred revenue | 3,339.4 |  |  | 3,276.2 |  |
| Total current liabilities | 4,727.8 |  |  | 4,060.7 |  |
| DEFERRED REVENUE | 3,079.0 |  |  | 3,084.7 |  |
| LONG-TERM DEBT | 496.2 |  |  | 994.3 |  |
| OTHER LIABILITIES | 141.1 |  |  | 129.6 |  |
| Total liabilities | 8,444.1 |  |  | 8,269.3 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.8 |  |  | 0.8 |  |
| Additional paid-in capital | 1,668.7 |  |  | 1,636.2 |  |
| Accumulated other comprehensive loss | (22.9) |  |  | (26.1) |  |
| Retained earnings (accumulated deficit) | 316.3 |  |  | (117.1) |  |
| Total stockholders’ equity | 1,962.9 |  |  | 1,493.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 10,407.0 |  |  | $ | 9,763.1 |  |

[0001262039-25-000014:8k_2_02:73]
FORTINET, INC.

[0001262039-25-000014:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-25-000014:8k_2_02:75]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000014:8k_2_02:76]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | 1,539.7 |  |  | 1,353.3 |  |  |  |  |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 149.9 |  |  | 182.8 |  |  |  |  |  |
| Service | 143.2 |  |  | 121.9 |  |  |  |  |  |
| Total cost of revenue | 293.1 |  |  | 304.7 |  |  |  |  |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 309.2 |  |  | 226.1 |  |  |  |  |  |
| Service | 937.4 |  |  | 822.5 |  |  |  |  |  |
| Total gross profit | 1,246.6 |  |  | 1,048.6 |  |  |  |  |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 198.6 |  |  | 173.0 |  |  |  |  |  |
| Sales and marketing | 542.7 |  |  | 501.1 |  |  |  |  |  |
| General and administrative | 57.8 |  |  | 54.4 |  |  |  |  |  |
| Gain on intellectual property matters | (6.3) |  |  | (1.1) |  |  |  |  |  |
| Total operating expenses | 792.8 |  |  | 727.4 |  |  |  |  |  |
| OPERATING INCOME | 453.8 |  |  | 321.2 |  |  |  |  |  |
| INTEREST INCOME | 44.3 |  |  | 32.2 |  |  |  |  |  |
| INTEREST EXPENSE | (4.9) |  |  | (5.1) |  |  |  |  |  |
| OTHER INCOME (EXPENSE)—NET | 26.1 |  |  | (2.9) |  |  |  |  |  |
| INCOME BEFORE INCOME TAXES AND GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | 519.3 |  |  | 345.4 |  |  |  |  |  |
| PROVISION FOR INCOME TAXES | 96.5 |  |  | 39.5 |  |  |  |  |  |
| GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | 10.6 |  |  | (6.6) |  |  |  |  |  |
| NET INCOME | $ | 433.4 |  |  | $ | 299.3 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.56 |  |  | $ | 0.39 |  |  |  |  |  |
| Diluted | $ | 0.56 |  |  | $ | 0.39 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 768.3 |  |  | 762.4 |  |  |  |  |  |
| Diluted | 776.8 |  |  | 770.5 |  |  |  |  |  |

[0001262039-25-000014:8k_2_02:77]
FORTINET, INC.

[0001262039-25-000014:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-25-000014:8k_2_02:79]
(Unaudited, in millions)

[0001262039-25-000014:8k_2_02:80]
|  | Three Months Ended |
|  | March 31,2025 |  | March 31,2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 433.4 |  |  | $ | 299.3 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 66.1 |  |  | 62.3 |  |
| Amortization of deferred contract costs | 78.0 |  |  | 72.0 |  |
| Depreciation and amortization | 35.8 |  |  | 28.6 |  |
| Amortization of investment discounts | (10.3) |  |  | (12.2) |  |
| Other | (35.5) |  |  | 9.9 |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 303.9 |  |  | 405.6 |  |
| Inventory | (34.1) |  |  | 36.5 |  |
| Prepaid expenses and other current assets | 3.4 |  |  | (0.1) |  |
| Deferred contract costs | (91.3) |  |  | (66.5) |  |
| Deferred tax assets | (30.0) |  |  | (73.9) |  |
| Other assets | 1.5 |  |  | (6.2) |  |
| Accounts payable | 24.6 |  |  | (61.6) |  |
| Accrued liabilities | 63.7 |  |  | 105.0 |  |
| Accrued payroll and compensation | (8.2) |  |  | (27.4) |  |
| Deferred revenue | 57.0 |  |  | 54.8 |  |
| Other liabilities | 5.3 |  |  | 4.3 |  |
| Net cash provided by operating activities | 863.3 |  |  | 830.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (503.0) |  |  | (436.1) |  |
| Sales of investments | 2.8 |  |  | — |  |
| Maturities of investments | 466.9 |  |  | 393.4 |  |
| Purchases of property and equipment | (66.5) |  |  | (221.9) |  |
| Payments made in connection with business combinations, net of cash acquired | (11.2) |  |  | (5.7) |  |
| Other | 0.2 |  |  | — |  |
| Net cash used in investing activities | (110.8) |  |  | (270.3) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 20.2 |  |  | 13.4 |  |
| Taxes paid related to net share settlement of equity awards | (52.9) |  |  | (42.9) |  |
| Other | — |  |  | (0.8) |  |
| Net cash used in financing activities | (32.7) |  |  | (30.3) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | 0.9 |  |  | (1.4) |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 720.7 |  |  | 528.4 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 2,875.9 |  |  | 1,397.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 3,596.6 |  |  | $ | 1,926.3 |  |

[0001262039-25-000014:8k_2_02:81]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-25-000014:8k_2_02:82]
(Unaudited, in millions, except per share amounts)

[0001262039-25-000014:8k_2_02:83]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-25-000014:8k_2_02:84]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 453.8 |  |  | $ | 321.2 |  |  |  |  |  |
| GAAP operating margin | 29.5 | % |  | 23.7 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.9 |  |  | 63.0 |  |  |  |  |  |
| Amortization of acquired intangible assets | 11.8 |  |  | 3.0 |  |  |  |  |  |
| Gain on intellectual property matters | (6.3) |  |  | (1.1) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 526.2 |  |  | $ | 386.1 |  |  |  |  |  |
| Non‐GAAP operating margin | 34.2 | % |  | 28.5 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 433.4 |  |  | $ | 299.3 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 66.9 |  |  | 63.0 |  |  |  |  |  |
| Amortization of acquired intangible assets | 11.8 |  |  | 3.0 |  |  |  |  |  |
| Gain on intellectual property matters | (6.3) |  |  | (1.1) |  |  |  |  |  |
| Gain on bargain purchase (a) | (39.9) |  |  | — |  |  |  |  |  |
| Tax adjustment (b) | (2.8) |  |  | (30.3) |  |  |  |  |  |
| Gain from equity method investment (c) | (10.8) |  |  | — |  |  |  |  |  |
| Non-GAAP net income | $ | 452.3 |  |  | $ | 333.9 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 452.3 |  |  | $ | 333.9 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 776.8 |  |  | 770.5 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.58 |  |  | $ | 0.43 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.56 |  |  | $ | 0.39 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.02 |  |  | 0.04 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.58 |  |  | $ | 0.43 |  |  |  |  |  |

[0001262039-25-000014:8k_2_02:85]
(a) To exclude a $39.9 million gain on bargain purchase related to our acquisition of Linksys Holdings, Inc. (“Linksys”) in the three months ended March 31, 2025.

[0001262039-25-000014:8k_2_02:86]
(b) Non-GAAP financial information is adjusted to an effective tax rate of 18% and 17% in the three months ended March 31, 2025 and 2024, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-25-000014:8k_2_02:87]
(c) To exclude a $10.8 million gain from equity method investment in Linksys resulted from our acquisition of Linksys in the three months ended March 31, 2025.

[0001262039-25-000014:8k_2_02:88]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-25-000014:8k_2_02:89]
|  | Three Months Ended |
|  | March 31,2025 |  | March 31,2024 |
| Net cash provided by operating activities | $ | 863.3 |  |  | $ | 830.4 |  |
| Less: Purchases of property and equipment | (66.5) |  |  | (221.9) |  |
| Less: Proceeds from intellectual property matter | (14.0) |  |  | — |  |
| Free cash flow | $ | 782.8 |  |  | $ | 608.5 |  |
| Net cash used in investing activities | $ | (110.8) |  |  | $ | (270.3) |  |
| Net cash used in financing activities | $ | (32.7) |  |  | $ | (30.3) |  |

[0001262039-25-000014:8k_2_02:90]
Reconciliation of total revenue to total billings

[0001262039-25-000014:8k_2_02:91]
|  | Three Months Ended |
|  | March 31,2025 |  | March 31,2024 |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |
| Add: Change in deferred revenue | 57.5 |  |  | 54.9 |  |
| Less: Deferred revenue balance acquired in business acquisitions | — |  |  | (1.0) |  |
| Total billings | $ | 1,597.2 |  |  | $ | 1,407.2 |  |

[0001262039-25-000014:8k_2_02:92]
| Investor Contact: |  | Media Contact: |
| Aaron Ovadia |  | Michelle Zimmermann |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
