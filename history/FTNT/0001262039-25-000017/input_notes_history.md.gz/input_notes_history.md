# FTNT note change history — 0001262039-24-000043 → 0001262039-25-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2025 (in millions):
  (was, 2024-11-08, similarity 0.9609):
[0001262039-24-000043:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2024 (in millions):

- changed (2025-05-08):
[0001262039-25-000017:note_history:2]
As of March 31, 2025, we had $689.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $47.5 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments was $4.5 million benefit and a $31.6 million cost during the three months ended March 31, 2025 and 2024, respectively, and was recorded in cost of product revenue on the condensed consolidated statements of income.
  (was, 2024-11-08, similarity 0.7213):
[0001262039-24-000043:note_history:2]
As of September 30, 2024, we had $550.0 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2024 and December 31, 2023, the liability for these inventory purchase commitments was $76.3 million and $84.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The cost of product revenue related to such liabilities was a $27.4 million benefit and a $36.9 million cost during the three months ended September 30, 2024 and 2023, respectively. The cost of product revenue related to such accrued liability for inventory purchase commitments was $11.2 million and $59.3 million during the nine months ended September 30, 2024 and 2023, respectively.

- changed (2025-05-08):
[0001262039-25-000017:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2025, we had $94.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2024-11-08, similarity 0.9895):
[0001262039-24-000043:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of September 30, 2024, we had $116.5 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- changed (2025-05-08):
[0001262039-25-000017:note_history:4]
As of March 31, 2025, we had $81.6 million in contractual commitments related to payments for operating leases.
  (was, 2024-11-08, similarity 0.9519):
[0001262039-24-000043:note_history:4]
As of September 30, 2024, we had $83.1 million in contractual commitments related to payments for operating leases.

- changed (2025-05-08):
[0001262039-25-000017:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of March 31, 2025, and December 31, 2024.
  (was, 2024-11-08, similarity 0.996):
[0001262039-24-000043:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgement. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2024, and December 31, 2023.

- changed (2025-05-08):
[0001262039-25-000017:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of March 31, 2025 or December 31, 2024 related to this litigation.
  (was, 2024-11-08, similarity 0.6453):
[0001262039-24-000043:note_history:6]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. The time for Alorica to appeal the verdict has not yet expired. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, if Alorica appeals, any legal proceedings would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2024 or December 31, 2023 related to this litigation.

- added (2025-05-08):
[0001262039-25-000017:note_history:7]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.

- removed (2025-05-08):
[0001262039-24-000043:note_history:8]
Periodically we, like other security companies and companies in other industries, have experienced, and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the third quarter of 2024, we discovered that an individual gained unauthorized access to a limited number of files stored on Fortinet’s instance of a third-party cloud-based shared file drive, which included limited data related to a small number of Fortinet customers. We have completed our investigation of this incident and we do not currently believe that it had a material impact on our business or that of any of our customers. We are currently not aware of any significant claims arising from this matter.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:9]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.
  (was, 2024-11-08, similarity 0.9813):
[0001262039-24-000043:note_history:9]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2023, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2024. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2024 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2023 is derived from the audited consolidated financial statements for the year ended December 31, 2023.

- added (2025-05-08):
[0001262039-25-000017:note_history:10]
Amounts previously reported as marketable equity securities are included in short-term investments in prior periods to conform with current period presentation in our condensed consolidated balance sheets. Amounts previously reported as gain on bargain purchase are included in other income (expense)—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

- changed (2025-05-08):
[0001262039-25-000017:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.
  (was, 2024-11-08, similarity 0.9127):
[0001262039-24-000043:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2024, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 filed with the SEC.

- added (2025-05-08):
[0001262039-25-000017:note_history:12]
Income Statement

- added (2025-05-08):
[0001262039-25-000017:note_history:13]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal year 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

- removed (2025-05-08):
[0001262039-24-000043:note_history:14]
Segment Reporting

- removed (2025-05-08):
[0001262039-24-000043:note_history:15]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The amendments are effective for our annual reporting for fiscal year 2024, and for our interim period reporting starting in fiscal year 2025 retrospectively, with early adoption permitted. We are currently evaluating the ASU to determine its impact on our disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:16]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of March 31, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2024-11-08, similarity 0.8858):
[0001262039-24-000043:note_history:16]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of September 30, 2024 and December 31, 2023, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2025-05-08):
[0001262039-25-000017:note_history:17]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 498.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.2 |  |  | $ | 994.3 |  |
  (was, 2024-11-08, similarity 0.6696):
[0001262039-24-000043:note_history:17]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.8 |  |  | $ | 992.3 |  |

- changed (2025-05-08):
[0001262039-25-000017:note_history:18]
As of March 31, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the three months ended March 31, 2025 and 2024, as the costs that qualified for capitalization were not material.
  (was, 2024-11-08, similarity 0.7884):
[0001262039-24-000043:note_history:18]
As of September 30, 2024 and December 31, 2023, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2024 and 2023, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2024 and 2023, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2024 and 2023, as the costs that qualified for capitalization were not material.

- added (2025-05-08):
[0001262039-25-000017:note_history:19]
The total estimated fair value of the outstanding Senior Notes was approximately $919.6 million, including accrued and unpaid interest, as of March 31, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2025-05-08):
[0001262039-24-000043:note_history:20]
The total estimated fair value of the outstanding Senior Notes was approximately $912.8 million, including accrued and unpaid interest, as of September 30, 2024. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:21]
|  | March 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 119.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 119.7 |  |  | $ | — |  |
| Commercial paper | 260.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 260.5 |  |  | (0.1) |  |
| Corporate debt securities | 83.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 83.8 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 9.5 |  |  | — |  |  | — |  |  | — |  |  | 9.5 |  |  | — |  |
| Total available-for-sale investments | $ | 473.5 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 473.5 |  |  | $ | (0.2) |  |
  (was, 2024-11-08, similarity 0.7587):
[0001262039-24-000043:note_history:21]
|  | September 30, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 40.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 40.2 |  |  | $ | — |  |
| Commercial paper | 60.8 |  |  | — |  |  | — |  |  | — |  |  | 60.8 |  |  | — |  |
| Corporate debt securities | 15.8 |  |  | — |  |  | — |  |  | — |  |  | 15.8 |  |  | — |  |
| Total available-for-sale investments | $ | 116.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 116.8 |  |  | $ | — |  |

- added (2025-05-08):
[0001262039-25-000017:note_history:22]
|  | December 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| Commercial paper | 149.4 |  |  | (0.2) |  |  | — |  |  | — |  |  | 149.4 |  |  | (0.2) |  |
| Corporate debt securities | 63.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 63.5 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 10.9 |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | — |  |
| Total available-for-sale investments | $ | 251.6 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 251.6 |  |  | $ | (0.3) |  |

- removed (2025-05-08):
[0001262039-24-000043:note_history:23]
|  | December 31, 2023 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 47.1 |  |  | $ | — |  |  | $ | 11.7 |  |  | $ | (0.3) |  |  | $ | 58.8 |  |  | $ | (0.3) |  |
| Commercial paper | 200.8 |  |  | (0.1) |  |  | — |  |  | — |  |  | 200.8 |  |  | (0.1) |  |
| Corporate debt securities | 21.8 |  |  | — |  |  | 26.9 |  |  | (0.1) |  |  | 48.7 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 269.7 |  |  | $ | (0.1) |  |  | $ | 38.6 |  |  | $ | (0.4) |  |  | $ | 308.3 |  |  | $ | (0.5) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:24]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 5.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 498.7 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.2 |  |  | $ | 994.3 |  |
  (was, 2024-11-08, similarity 0.6696):
[0001262039-24-000043:note_history:24]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2024 |  | December 31,2023 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 6.2 |  |  | 7.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 993.8 |  |  | $ | 992.3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:25]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 623.1 |  |  | 536.9 |  |  |  |  |  |
| Technical support and other | 457.5 |  |  | 407.5 |  |  |  |  |  |
| Total service revenue | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |
  (was, 2024-11-08, similarity 0.6518):
[0001262039-24-000043:note_history:25]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 595.8 |  |  | 494.6 |  |  | 1,691.4 |  |  | 1,373.6 |  |
| Technical support and other | 438.4 |  |  | 374.1 |  |  | 1,269.6 |  |  | 1,076.9 |  |
| Total service revenue | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:26]
|  | Three Months Ended |  |  |
|  | March 31,2025 |  | March 31,2024 |  |  |  |  |
| Product | $ | 459.1 |  |  | $ | 408.9 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 623.1 |  |  | 536.9 |  |  |  |  |  |
| Technical support and other | 457.5 |  |  | 407.5 |  |  |  |  |  |
| Total service revenue | 1,080.6 |  |  | 944.4 |  |  |  |  |  |
| Total revenue | $ | 1,539.7 |  |  | $ | 1,353.3 |  |  |  |  |  |
  (was, 2024-11-08, similarity 0.6518):
[0001262039-24-000043:note_history:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2024 |  | September 30,2023 |  | September 30,2024 |  | September 30,2023 |
| Product | $ | 473.9 |  |  | $ | 465.9 |  |  | $ | 1,334.7 |  |  | $ | 1,439.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 595.8 |  |  | 494.6 |  |  | 1,691.4 |  |  | 1,373.6 |  |
| Technical support and other | 438.4 |  |  | 374.1 |  |  | 1,269.6 |  |  | 1,076.9 |  |
| Total service revenue | 1,034.2 |  |  | 868.7 |  |  | 2,961.0 |  |  | 2,450.5 |  |
| Total revenue | $ | 1,508.1 |  |  | $ | 1,334.6 |  |  | $ | 4,295.7 |  |  | $ | 3,889.7 |  |

- added (2025-05-08):
[0001262039-25-000017:note_history:27]
During the three months ended March 31, 2025 and 2024, we recognized $972.5 million and $851.1 million in revenue that was included in the deferred revenue balance as of December 31, 2024 and 2023, respectively.

- added (2025-05-08):
[0001262039-25-000017:note_history:28]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.49 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.38 billion as revenue over the next 12 months, $2.55 billion in years two and three, and the remainder thereafter.

- changed (2025-05-08):
[0001262039-25-000017:note_history:29]
Amortization of deferred contract costs during the three months ended March 31, 2025 and 2024 were $78.0 million and $72.0 million, respectively.
  (was, 2024-11-08, similarity 0.6284):
[0001262039-24-000043:note_history:29]
Amortization of deferred contract costs during the three months ended September 30, 2024 and 2023 were $73.6 million and $68.0 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2024 and 2023 were $218.3 million and $195.9 million, respectively.

- removed (2025-05-08):
[0001262039-24-000043:note_history:30]
During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively. During the three and nine months ended September 30, 2023, we recognized $514.3 million and $1.80 billion in revenue that was included in the deferred revenue balance as of December 31, 2022, respectively.

- removed (2025-05-08):
[0001262039-24-000043:note_history:31]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.08 billion, which was substantially comprised of deferred security subscription and technical support services revenue that will be recognized in future periods. We expect to recognize approximately $3.12 billion as revenue over the next 12 months and the remainder thereafter.

- removed (2025-05-08):
[0001262039-24-000043:note_history:32]
Accounts Receivable

- removed (2025-05-08):
[0001262039-24-000043:note_history:33]
Trade accounts receivable are recorded at the invoiced amount, net of an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis. Expected credit losses are recorded as general and administrative expenses on our condensed consolidated statements of income.

- removed (2025-05-08):
[0001262039-24-000043:note_history:34]
The allowance for credit losses was $4.7 million and $8.2 million as of September 30, 2024 and December 31, 2023, respectively. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2024 and 2023.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-05-08):
[0001262039-25-000017:note_history:35]
SUBSEQUENT EVENTS
Share Repurchase Program
  (was, 2024-11-08, similarity 0.7561):
[0001262039-24-000043:note_history:35]
SUBSEQUENT EVENTS
Real Property Purchase

- added (2025-05-08):
[0001262039-25-000017:note_history:36]
Subsequent to March 31, 2025 through the filing of this Quarterly Report on Form 10-Q, we repurchased 4.6 million shares of our common stock at an average price of $87.89 per share, for an aggregate purchase price of $401.1 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $1.63 billion remained available for future share repurchases through February 28, 2026 under the Repurchase Program.

- added (2025-05-08):
[0001262039-25-000017:note_history:37]
Real Property Purchases

- changed (2025-05-08):
[0001262039-25-000017:note_history:38]
In April 2025, we purchased real property in Burnaby, Canada, totaling approximately 245,000 square feet, to be used for office space, for $99.9 million in cash.
  (was, 2024-11-08, similarity 0.6352):
[0001262039-24-000043:note_history:38]
In November 2024, we purchased real property in Atlanta, Georgia, for $15.8 million in cash.

- removed (2025-05-08):
[0001262039-24-000043:note_history:39]
Share Repurchase Program

- removed (2025-05-08):
[0001262039-24-000043:note_history:40]
In October 2024, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2026, bringing the aggregate amount authorized to be repurchased to $8.25 billion of our outstanding common stock through February 28, 2026. As of November 8, 2024, approximately $2.03 billion remained available for future share repurchases.
