# FTNT MD&A — 0001262039-17-000034


## mdna

[0001262039-17-000034:mdna:1]
[same as prior period, unchanged from 0001262039-17-000027:mdna:1]

[0001262039-17-000034:mdna:2]
[same as prior period, unchanged from 0001262039-17-000027:mdna:2]

[0001262039-17-000034:mdna:3]
[same as prior period, unchanged from 0001262039-17-000027:mdna:3]

[0001262039-17-000034:mdna:4]
[same as prior period, unchanged from 0001262039-17-000027:mdna:4]

[0001262039-17-000034:mdna:5]
[same as prior period, unchanged from 0001262039-17-000027:mdna:5]

[0001262039-17-000034:mdna:6]
[same as prior period, unchanged from 0001262039-17-000027:mdna:6]

[0001262039-17-000034:mdna:7]
[same as prior period, unchanged from 0001262039-17-000027:mdna:7]

[0001262039-17-000034:mdna:8]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, increased functionality and value in our standalone and bundled subscription service offerings; |

[0001262039-17-000034:mdna:9]
| • | growing our sales to businesses, service providers and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-17-000034:mdna:10]
[same as prior period, unchanged from 0001262039-17-000027:mdna:10]

[0001262039-17-000034:mdna:11]
[same as prior period, unchanged from 0001262039-17-000027:mdna:11]

[0001262039-17-000034:mdna:12]
[same as prior period, unchanged from 0001262039-17-000027:mdna:12]

[0001262039-17-000034:mdna:13]
[same as prior period, unchanged from 0001262039-17-000027:mdna:13]

[0001262039-17-000034:mdna:14]
[same as prior period, unchanged from 0001262039-17-000027:mdna:14]

[0001262039-17-000034:mdna:15]
[same as prior period, unchanged from 0001262039-17-000027:mdna:15]

[0001262039-17-000034:mdna:16]
[same as prior period, unchanged from 0001262039-17-000027:mdna:16]

[0001262039-17-000034:mdna:17]
[same as prior period, unchanged from 0001262039-17-000027:mdna:19]

[0001262039-17-000034:mdna:18]
[same as prior period, unchanged from 0001262039-17-000027:mdna:20]

[0001262039-17-000034:mdna:19]
[same as prior period, unchanged from 0001262039-17-000027:mdna:21]

[0001262039-17-000034:mdna:20]
24

[0001262039-17-000034:mdna:21]
[same as prior period, unchanged from 0001262039-17-000027:mdna:23]

[0001262039-17-000034:mdna:22]
We provide high performance cybersecurity solutions to a wide variety of businesses, service providers and government organizations of all sizes across the globe, including a majority of the 2016 Fortune 100. Our cybersecurity solutions are designed to provide broad, rapid protection against dynamic and sophisticated security threats, while simplifying the information technology (“IT”) and security infrastructure of our end-customers.

[0001262039-17-000034:mdna:23]
The three key areas driving our business are the changing cyber threat landscape, expanding need for regulatory compliance and evolving network security infrastructure, including cloud environments and the internet of things (“IoT”). The cyber threat landscape continues to change at a rapid pace, with network attacks continually morphing into vehicles for malware, such as ransomware, and the challenge of having to comply with a variety of constantly changing regulatory requirements. Our end-customers’ infrastructures are rapidly evolving to leverage new technologies such as on-demand cloud, internet on demand and IoT, and changing web traffic patterns require end-customers to increase the bandwidth available across their network. This expanding threat landscape requires end-customers to increase the scope of their security offerings over an attack surface of technologies and devices with internet access. These three drivers mean end-customers are constantly evaluating the scope of their cybersecurity and upgrades or deployments of new cybersecurity solutions.

[0001262039-17-000034:mdna:24]
The Fortinet Security Fabric has been developed to provide unified security across the entire network, including network core, endpoints, applications, data centers, access and private and public cloud, and is designed to enable traditionally disparate security devices to work together as an integrated and collaborative whole. It delivers integrated scalability, access control, awareness, security, traffic segmentation, centralized management, visibility and orchestration. The breadth of the Fortinet Security Fabric helps businesses and government agencies actively defend the varied attack surface. The Fortinet Security Fabric is built around an open framework to ensure interoperability and synchronization of intelligence and response, and does so across the distributed network security infrastructure, including both from the cloud and for the cloud. At the core of the Fortinet Security Fabric are our FortiGate physical products and software licenses, which ship with a broad set of security services, including firewall, virtual private network, anti-malware, anti-spam, application control, intrusion prevention, access control, web filtering, traffic and device segmentation and advanced threat protection (“ATP”). Through these security services, our FortiGuard Labs team provides updates using threat research and a global cloud network of data collection and intelligence resources to deliver subscription-based security services to FortiGate appliances and software products. We certify the security effectiveness of our security updates through independent test organizations, such as NSS Labs. Our FortiOS operating system provides the foundation for all FortiGate security functions. The latest enhancements to the FortiOS 5.6 offer end-customers the ability to manage security capabilities across their cloud assets’ and software-defined wireless area networks.

[0001262039-17-000034:mdna:25]
Our customers select the form and deployment method that best meet their specific security requirements, such as a high-speed data center firewall at the network core, a next generation firewall at the edge, an internal segmentation firewall between network zones, a distributed enterprise firewall at branch sites or software- and hardware-based solutions designed for virtualized and cloud environments. Many smaller businesses also tend to deploy unified threat management devices. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses (“low-end products”), FortiGate-200 to -900 series for medium-sized businesses (“mid-range products”), to the FortiGate-1000 to -7000 series for large businesses and service providers (“high-end products”). Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering and anti-spam functionality. End-customers may also purchase FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management, analysis and reporting capabilities. FortiSIEM provides organizations with a solution for analyzing and managing network security, performance and compliance standards across our and other vendors’ products. Finally, end-customers may purchase FortiCare technical support services for our products and FortiCare professional services to assist in the design, implementation and maintenance of their networks.

[0001262039-17-000034:mdna:26]
25

[0001262039-17-000034:mdna:27]
We complement our core FortiGate product line with other products and software that offer additional protection from security threats to other critical areas of the business. These products include our FortiMail email security, FortiSandbox ATP, FortiWeb web application firewall and FortiDDoS security appliances, as well as our FortiClient endpoint security software, FortiSIEM software, FortiAP secure wireless access points and FortiSwitch secure switch connectivity products. Our technology also positions us to deliver security to the cloud and for the cloud. Sales of our cloud-related products and services across public, private and hybrid cloud environments continue to grow faster on a percentage basis than other parts of our business.

[0001262039-17-000034:mdna:28]
[same as prior period, unchanged from 0001262039-17-000027:mdna:30]

[0001262039-17-000034:mdna:29]
| • | We recorded total revenue of $374.2 million and $1.08 billion in the three and nine months ended September 30, 2017, an increase of 18% and 18%, respectively, compared to the same periods last year. Product revenue was $137.1 million and $415.1 million in the three and nine months ended September 30, 2017, an increase of 7% and 7%, respectively, compared to the same periods last year. Service revenue was $237.1 million and $663.2 million in the three and nine months ended September 30, 2017, an increase of 26% and 27%, respectively, compared to the same period last year. |

[0001262039-17-000034:mdna:30]
| • | We generated operating income of $33.7 million and $67.6 million in the three and nine months ended September 30, 2017, respectively, compared to operating income of $5.5 million and operating loss of $2.2 million in the three and nine months ended September 30, 2016, respectively. |

[0001262039-17-000034:mdna:31]
| • | Cash, cash equivalents and investments were $1.52 billion as of September 30, 2017, an increase of $213.1 million, or 16%, from December 31, 2016. |

[0001262039-17-000034:mdna:32]
| • | Deferred revenue was $1.22 billion as of September 30, 2017, an increase of $183.6 million, or 18%, from December 31, 2016. |

[0001262039-17-000034:mdna:33]
| • | We generated cash flows from operating activities of $436.9 million in the nine months ended September 30, 2017, an increase of $192.2 million, or 79%, compared to the same period last year. |

[0001262039-17-000034:mdna:34]
| • | We repurchased 2.4 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”) for an aggregate price of $90.8 million in the three months ended September 30, 2017. During the nine months ended September 30, 2017, we repurchased 3.3 million shares of common stock under the Repurchase Program in open market transactions at an average price of $37.67 per share, for an aggregate purchase price of $124.0 million. In October 2017, our board of directors authorized a $400.0 million increase to the Repurchase Program, bringing the total amount authorized to $1.0 billion through January 31, 2019. |

[0001262039-17-000034:mdna:35]
During the three and nine months ended September 30, 2017, our revenue growth was driven by the strength in sales of our FortiGate and non-FortiGate products and the sale of new, and the renewal and upgrade of existing, FortiCare and FortiGuard subscription service contracts. During the three and nine months ended September 30, 2017, our billings growth was driven by sales of FortiGate and non-FortiGate products, and current period renewals and upgrades of FortiCare and FortiGuard subscription service contracts. During the three months ended September 30, 2017, our high-end products, which accounted for 41% of total product billings, reflected a strong sales to large businesses and an increase in large deals. Our mid-range products accounted for 29% of product billings, and our entry-level products accounted for 30% of product billings. In addition, we continue to see a shift in our revenue mix to higher margin services, reflecting our success in driving higher-priced subscription bundles and services. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-17-000034:mdna:36]
During each of the three and nine months ended September 30, 2017, operating expenses as a percentage of revenue decreased by 5%, compared to the same periods last year. The decreases were primarily driven by a reduction in sales and marketing expenses as a percentage of revenue. Headcount increased by 6% to 4,903 employees and contractors as of September 30, 2017, up from 4,619 as of September 30, 2016.

[0001262039-17-000034:mdna:37]
[same as prior period, unchanged from 0001262039-17-000027:mdna:58]

[0001262039-17-000034:mdna:38]
[same as prior period, unchanged from 0001262039-17-000027:mdna:39]

[0001262039-17-000034:mdna:39]
[same as prior period, unchanged from 0001262039-17-000027:mdna:40]

[0001262039-17-000034:mdna:40]
Typically, FortiGuard and FortiCare subscription services are purchased along with our physical products and software licenses, most frequently as part of a bundle offering that includes hardware and services functionality. We generally invoice at the time of our sale for the total price of the products and security and technical support services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis.

[0001262039-17-000034:mdna:41]
We generally recognize product revenue up front, and recognize revenue for the sale of new and the renewal of existing FortiGuard and FortiCare subscription services contracts ratably. We recognize revenue for certain software licenses up front as product revenue and, to a lesser extent, recognize other software licenses over the term of the agreement as services revenue. We recognize the security and support revenue over the service period, which is typically one to three years, but can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which has contributed to our positive cash flow from operations.

[0001262039-17-000034:mdna:42]
[same as prior period, unchanged from 0001262039-17-000027:mdna:43]

[0001262039-17-000034:mdna:43]
[same as prior period, unchanged from 0001262039-17-000027:mdna:44]

[0001262039-17-000034:mdna:44]
[same as prior period, unchanged from 0001262039-17-000027:mdna:45]

[0001262039-17-000034:mdna:45]
|  | Three Months Ended Or As Of |
|  | September 30, 2017 |  | September 30, 2016 |
|  | (in thousands) |
| Revenue | $ | 374,217 |  |  | $ | 316,646 |  |
| Deferred revenue | $ | 1,218,957 |  |  | $ | 934,792 |  |
| Billings (non-GAAP) | $ | 431,703 |  |  | $ | 347,457 |  |
| Cash, cash equivalents and investments | $ | 1,523,630 |  |  | $ | 1,270,650 |  |
| Net cash provided by operating activities | $ | 162,343 |  |  | $ | 76,139 |  |
| Free cash flow (non-GAAP) | $ | 140,590 |  |  | $ | 70,219 |  |

[0001262039-17-000034:mdna:46]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and FortiCare subscription service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue to be recognized in future periods. Deferred revenue was $1.22 billion as of September 30, 2017, an increase of $183.6 million, or 18%, from December 31, 2016.

[0001262039-17-000034:mdna:47]
[same as prior period, unchanged from 0001262039-17-000027:mdna:67]

[0001262039-17-000034:mdna:48]
[same as prior period, unchanged from 0001262039-17-000027:mdna:48]

[0001262039-17-000034:mdna:49]
[same as prior period, unchanged from 0001262039-17-000027:mdna:49]

[0001262039-17-000034:mdna:50]
|  | Three Months Ended |
| September 30, 2017 |  | September 30, 2016 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 374,217 |  |  | $ | 316,646 |  |
| Add change in deferred revenue | 57,486 |  |  | 30,811 |  |
| Total billings (non-GAAP) | $ | 431,703 |  |  | $ | 347,457 |  |

[0001262039-17-000034:mdna:51]
[same as prior period, unchanged from 0001262039-17-000027:mdna:51]

[0001262039-17-000034:mdna:52]
|  | Three Months Ended |
| September 30, 2017 |  | September 30, 2016 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 162,343 |  |  | $ | 76,139 |  |
| Less purchases of property and equipment | (21,753 | ) |  | (5,920 | ) |
| Free cash flow (non-GAAP) | $ | 140,590 |  |  | $ | 70,219 |  |
| Net cash used in investing activities | $ | (28,914 | ) |  | $ | (6,798 | ) |
| Net cash used in financing activities | $ | (80,772 | ) |  | $ | (18,208 | ) |

[0001262039-17-000034:mdna:53]
28

[0001262039-17-000034:mdna:54]
[same as prior period, unchanged from 0001262039-17-000027:mdna:53]

[0001262039-17-000034:mdna:55]
[same as prior period, unchanged from 0001262039-17-000027:mdna:54]

[0001262039-17-000034:mdna:56]
There were no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2017, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on March 1, 2017 (the “Form 10-K”).

[0001262039-17-000034:mdna:57]
[same as prior period, unchanged from 0001262039-17-000027:mdna:56]

[0001262039-17-000034:mdna:58]
[same as prior period, unchanged from 0001262039-17-000027:mdna:57]

[0001262039-17-000034:mdna:59]
[same as prior period, unchanged from 0001262039-17-000027:mdna:59]

[0001262039-17-000034:mdna:60]
Three Months Ended September 30, 2017 and September 30, 2016

[0001262039-17-000034:mdna:61]
[same as prior period, unchanged from 0001262039-17-000027:mdna:61]

[0001262039-17-000034:mdna:62]
|  | Three Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 137,095 |  |  | 37 | % |  | $ | 127,972 |  |  | 40 | % |  | $ | 9,123 |  |  | 7 | % |
| Service | 237,122 |  |  | 63 |  |  | 188,674 |  |  | 60 |  |  | 48,448 |  |  | 26 |  |
| Total revenue | $ | 374,217 |  |  | 100 | % |  | $ | 316,646 |  |  | 100 | % |  | $ | 57,571 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 161,153 |  |  | 43 | % |  | $ | 133,874 |  |  | 42 | % |  | $ | 27,279 |  |  | 20 | % |
| Europe, Middle East and Africa | 138,335 |  |  | 37 |  |  | 116,967 |  |  | 37 |  |  | 21,368 |  |  | 18 |  |
| Asia Pacific | 74,729 |  |  | 20 |  |  | 65,805 |  |  | 21 |  |  | 8,924 |  |  | 14 |  |
| Total revenue | $ | 374,217 |  |  | 100 | % |  | $ | 316,646 |  |  | 100 | % |  | $ | 57,571 |  |  | 18 | % |

[0001262039-17-000034:mdna:63]
Total revenue increased by $57.6 million, or 18%, in the three months ended September 30, 2017 compared to the same period last year. On a geographic basis, we continued to experience global diversification. All three regions experienced revenue growth compared to the same period last year, with the Americas contributing the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $9.1 million, or 7%, in the three months ended September 30, 2017 compared to the same period last year. The increase in product revenue was primarily driven by the strength in sales of our FortiGate and non-FortiGate products. Service revenue increased by $48.4 million, or 26%, in the three months ended September 30, 2017 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard and FortiCare subscription services sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We continued to see the shift from product revenue to higher-margin, recurring service revenue, which reflected our success in driving sales of FortiGuard and FortiCare subscription services.

[0001262039-17-000034:mdna:64]
[same as prior period, unchanged from 0001262039-17-000027:mdna:64]

[0001262039-17-000034:mdna:65]
|  | Three Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 58,106 |  |  | $ | 50,267 |  |  | $ | 7,839 |  |  | 16 | % |
| Service | 35,543 |  |  | 34,532 |  |  | 1,011 |  |  | 3 |  |
| Total cost of revenue | $ | 93,649 |  |  | $ | 84,799 |  |  | $ | 8,850 |  |  | 10 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 57.6 | % |  | 60.7 | % |  | (3.1 | )% |  |  |
| Service | 85.0 |  |  | 81.7 |  |  | 3.3 |  |  |  |
| Total gross margin | 75.0 | % |  | 73.2 | % |  | 1.8 | % |  |  |

[0001262039-17-000034:mdna:66]
[same as prior period, unchanged from 0001262039-17-000027:mdna:95]

[0001262039-17-000034:mdna:67]
Total gross margin increased by 1.8 percentage points in the three months ended September 30, 2017 compared to the same period last year, driven by higher margin on service revenue. Service gross margin increased by 3.3 percentage points in the three months ended September 30, 2017 as compared to the same period last year. Product gross margin decreased by 3.1 percentage points in the three months ended September 30, 2017 compared to the same period last year. The shift in gross margin was a result of continued growth in the sales of higher-margin subscription bundles and longer duration of service contracts. Total cost of product revenue was comprised primarily of cost of products sold, inventory reserves and other charges. Total cost of service revenue was comprised primarily of personnel costs.

[0001262039-17-000034:mdna:68]
[same as prior period, unchanged from 0001262039-17-000027:mdna:69]

[0001262039-17-000034:mdna:69]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2017 |  | September 30, 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 53,486 |  |  | 14 | % |  | $ | 47,239 |  |  | 15 | % |  | $ | 6,247 |  |  | 13 | % |
| Sales and marketing | 172,361 |  |  | 46 |  |  | 154,831 |  |  | 49 |  |  | 17,530 |  |  | 11 |  |
| General and administrative | 21,025 |  |  | 6 |  |  | 22,006 |  |  | 7 |  |  | (981 | ) |  | (4 | ) |
| Restructuring charges | — |  |  | — |  |  | 2,283 |  |  | 1 |  |  | (2,283 | ) |  | (100 | ) |
| Total operating expenses | $ | 246,872 |  |  | 66 | % |  | $ | 226,359 |  |  | 71 | % |  | $ | 20,513 |  |  | 9 | % |

[0001262039-17-000034:mdna:70]
[same as prior period, unchanged from 0001262039-17-000027:mdna:71]

[0001262039-17-000034:mdna:71]
Research and development expense increased by $6.2 million, or 13%, in the three months ended September 30, 2017 compared to the same period last year, primarily due to an increase of $3.8 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, depreciation, facilities costs and product development expenses, such as third-party testing and prototypes, increased by $2.4 million. We intend to continue to invest in our research and development organization and expect research and development expense to increase in absolute dollars during the remainder of 2017.

[0001262039-17-000034:mdna:72]
[same as prior period, unchanged from 0001262039-17-000027:mdna:73]

[0001262039-17-000034:mdna:73]
Sales and marketing expense increased by $17.5 million, or 11%, in the three months ended September 30, 2017 compared to the same period last year, primarily due to an increase of $14.0 million in personnel costs, including an increase in stock-based compensation expense of $2.2 million. Marketing-related expenses increased by $2.9 million as we invested in marketing to drive broader market awareness, build lead generation programs and accelerate pipeline. In addition, depreciation expense and other occupancy-related expense increased by $0.8 million. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs. The decrease in personnel costs as a percentage of total revenue resulted from lower sales commissions, slower hiring and attrition. We intend to continue to invest in our sales resources and infrastructure and marketing, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2017.

[0001262039-17-000034:mdna:74]
[same as prior period, unchanged from 0001262039-17-000027:mdna:75]

[0001262039-17-000034:mdna:75]
General and administrative expense decreased by $1.0 million, or 4%, in the three months ended September 30, 2017 compared to the same period last year, primarily due to lower third-party costs of $4.1 million due to the substantial completion of our enterprise resource planning (“ERP”) system implementation in 2016. The decrease in expense was partially offset by an increase in personnel costs and costs to implement a new revenue recognition system increased by $3.7 million.  As a percentage of total revenue, general and administrative costs decreased to 6% in the three months ended September 30, 2017 from 7% in the three months ended September 30, 2016. We expect general and administrative expense to increase in absolute dollars during the remainder of 2017 as we continue to implement the new revenue recognition standard.

[0001262039-17-000034:mdna:76]
[same as prior period, unchanged from 0001262039-17-000027:mdna:77]

[0001262039-17-000034:mdna:77]
We generated operating income of $33.7 million in the three months ended September 30, 2017, an increase of $28.2 million, or 514%, compared to operating income of $5.5 million in the same period last year. The improvement in operating margin was primarily due to the improvement in gross margin, and the decline in sales and marketing and general and administrative expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 46% in the three months ended September 30, 2017 from 49% in the same period last year. In addition, as a percentage of total revenue, general and administrative expenses decreased to 6% in the three months ended September 30, 2017 from 7% in the same period last year.

[0001262039-17-000034:mdna:78]
[same as prior period, unchanged from 0001262039-17-000027:mdna:80]

[0001262039-17-000034:mdna:79]
|  | Three Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 3,866 |  |  | $ | 1,888 |  |  | $ | 1,978 |  |  | 105 | % |
| Other income (expense)—net | 344 |  |  | (787 | ) |  | 1,131 |  |  | (144 | ) |

[0001262039-17-000034:mdna:80]
Interest income increased by $2.0 million, or 105%, in the three months ended September 30, 2017 as compared to the same period last year primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Other income (expense)—net consisted primarily of foreign exchange and related hedging gains and losses. The increase in other income (expense)—net in the three months ended September 30, 2017 as compared to the same period last year was the result of foreign currency exchange gains in the three months ended September 30, 2017, compared to foreign currency exchange losses in the three months ended September 30, 2016.

[0001262039-17-000034:mdna:81]
[same as prior period, unchanged from 0001262039-17-000027:mdna:83]

[0001262039-17-000034:mdna:82]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2017 |  | September 30, 2016 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | 11,296 |  |  | $ | 298 |  |  | $ | 10,998 |  |  | * |
| Effective tax rate (%) | 30 | % |  | 5 | % |  | 25 | % |  | — |

[0001262039-17-000034:mdna:83]
[same as prior period, unchanged from 0001262039-17-000027:mdna:85]

[0001262039-17-000034:mdna:84]
Our effective tax rate was 30% in the three months ended September 30, 2017, compared to an effective tax rate of 5% in the same period last year. The effective tax rates in the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rates in the three months ended September 30, 2017 and 2016 were impacted by excess tax benefits of $1.8 million and $2.5 million, respectively, from stock-based compensation. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as the excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-17-000034:mdna:85]
Nine Months Ended September 30, 2017 and September 30, 2016

[0001262039-17-000034:mdna:86]
[same as prior period, unchanged from 0001262039-17-000027:mdna:88]

[0001262039-17-000034:mdna:87]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 415,053 |  |  | 38 | % |  | $ | 389,185 |  |  | 43 | % |  | $ | 25,868 |  |  | 7 | % |
| Service | 663,209 |  |  | 62 |  |  | 523,428 |  |  | 57 |  |  | 139,781 |  |  | 27 |  |
| Total revenue | $ | 1,078,262 |  |  | 100 | % |  | $ | 912,613 |  |  | 100 | % |  | $ | 165,649 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 468,230 |  |  | 43 | % |  | $ | 386,566 |  |  | 42 | % |  | $ | 81,664 |  |  | 21 | % |
| Europe, Middle East and Africa | 394,214 |  |  | 37 |  |  | 336,911 |  |  | 37 |  |  | 57,303 |  |  | 17 |  |
| Asia Pacific | 215,818 |  |  | 20 |  |  | 189,136 |  |  | 21 |  |  | 26,682 |  |  | 14 |  |
| Total revenue | $ | 1,078,262 |  |  | 100 | % |  | $ | 912,613 |  |  | 100 | % |  | $ | 165,649 |  |  | 18 | % |

[0001262039-17-000034:mdna:88]
Total revenue increased by $165.6 million, or 18%, in the nine months ended September 30, 2017 compared to the same period last year. All three regions experienced revenue growth compared to the same period last year, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis. Product revenue increased by $25.9 million, or 7%, in the nine months ended September 30, 2017 compared to the same period last year. The increase in product revenue was primarily driven by greater sales in our FortiGate and non-FortiGate products, as well as growth in other product lines.

[0001262039-17-000034:mdna:89]
Service revenue increased by $139.8 million, or 27%, in the nine months ended September 30, 2017 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard and FortiCare subscription services sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.We continued to see the shift from product revenue to higher-margin, recurring service revenue, which reflected our success in driving sales of subscriptions.

[0001262039-17-000034:mdna:90]
[same as prior period, unchanged from 0001262039-17-000027:mdna:92]

[0001262039-17-000034:mdna:91]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 174,190 |  |  | $ | 152,368 |  |  | $ | 21,822 |  |  | 14 | % |
| Service | 105,675 |  |  | 94,578 |  |  | 11,097 |  |  | 12 |  |
| Total cost of revenue | $ | 279,865 |  |  | $ | 246,946 |  |  | $ | 32,919 |  |  | 13 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 58.0 | % |  | 60.8 | % |  | (2.8 | )% |  |  |
| Service | 84.1 |  |  | 81.9 |  |  | 2.2 |  |  |  |
| Total gross margin | 74.0 | % |  | 72.9 | % |  | 1.1 | % |  |  |

[0001262039-17-000034:mdna:92]
Total gross margin increased by 1.1 percentage points in the nine months ended September 30, 2017 compared to the same period last year driven by higher margin on service revenue. Service gross margin increased by 2.2 percentage points in the nine months ended September 30, 2017 as compared to the same period last year. Product gross margin decreased by 2.8 percentage points in the nine months ended September 30, 2017 compared to the same period last year. The shift in gross margin was a result of continued growth in the sales of higher-margin subscription bundles and a longer average duration of service contracts. Total cost of product revenue was comprised primarily of cost of products sold, inventory reserves and other charges. Total cost of service revenue was comprised primarily of personnel costs.

[0001262039-17-000034:mdna:93]
[same as prior period, unchanged from 0001262039-17-000027:mdna:98]

[0001262039-17-000034:mdna:94]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2017 |  | September 30, 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 155,840 |  |  | 14 | % |  | $ | 137,495 |  |  | 15 | % |  | $ | 18,345 |  |  | 13 | % |
| Sales and marketing | 509,098 |  |  | 47 |  |  | 463,628 |  |  | 51 |  |  | 45,470 |  |  | 10 |  |
| General and administrative | 65,513 |  |  | 6 |  |  | 63,629 |  |  | 7 |  |  | 1,884 |  |  | 3 |  |
| Restructuring charges | 340 |  |  | — |  |  | 3,164 |  |  | — |  |  | (2,824 | ) |  | (89 | ) |
| Total operating expenses | $ | 730,791 |  |  | 68 | % |  | $ | 667,916 |  |  | 73 | % |  | $ | 62,875 |  |  | 9 | % |

[0001262039-17-000034:mdna:95]
[same as prior period, unchanged from 0001262039-17-000027:mdna:100]

[0001262039-17-000034:mdna:96]
Research and development expense increased by $18.3 million, or 13%, in the nine months ended September 30, 2017 compared to the same period last year primarily due to an increase of $12.5 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, product development costs, such as third-party testing and prototypes, increased by $3.5 million, and depreciation expense and other occupancy-related costs increased by $2.2 million.

[0001262039-17-000034:mdna:97]
[same as prior period, unchanged from 0001262039-17-000027:mdna:102]

[0001262039-17-000034:mdna:98]
Sales and marketing expense increased by $45.5 million, or 10%, in the nine months ended September 30, 2017 compared to the same period last year, primarily due to an increase of $37.9 million in personnel costs, including an increase in stock-based compensation expense of $8.2 million. Depreciation expense and other occupancy-related expense increased by $4.8 million. Amortization expense increased by $1.3 million related to intangible assets acquired from AccelOps. In addition, marketing-related expenses increased by $1.3 million as we invested in marketing to drive broader market awareness, build lead generation and accelerate pipeline. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs. The decrease in personnel costs as a percentage of total revenue resulted from lower sales commissions, slower hiring and attrition.

[0001262039-17-000034:mdna:99]
[same as prior period, unchanged from 0001262039-17-000027:mdna:104]

[0001262039-17-000034:mdna:100]
General and administrative expense increased by $1.9 million, or 3%, in the nine months ended September 30, 2017 compared to the same period last year, consisting primarily of an increase in other professional fees of $7.9 million that was mostly due to third-party costs related to implementing the new revenue recognition standard and an increase of $6.5 million in personnel costs as we continued to increase headcount. In addition, litigation settlement costs increased by $1.7 million. These increases were partially offset by lower third-party costs of $13.4 million primarily related to the substantial completion of our new ERP system implementation. As a percentage of total revenue, general and administrative costs decreased to 6% in the nine months ended September 30, 2017 from 7% in the same period last year.

[0001262039-17-000034:mdna:101]
[same as prior period, unchanged from 0001262039-17-000027:mdna:106]

[0001262039-17-000034:mdna:102]
We generated operating income of $67.6 million in the nine months ended September 30, 2017, an increase of $69.9 million, compared to operating loss of $2.2 million in the nine months ended September 30, 2016, respectively. The improvement in operating margin was primarily due to the increase in gross margin of 1.1 percentage points and the decline in sales and marketing and general and administrative expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 47% in the nine months ended September 30, 2017 from 51% in the same period last year. As a percentage of total revenue, general and administrative costs decreased to 6% in the nine months ended September 30, 2017 from 7% in the same period last year.

[0001262039-17-000034:mdna:103]
Interest income and other income (expense)—net

[0001262039-17-000034:mdna:104]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2017 |  | September 30, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 9,421 |  |  | $ | 5,339 |  |  | $ | 4,082 |  |  | 76 | % |
| Other income (expense)—net | 1,889 |  |  | (3,449 | ) |  | 5,338 |  |  | (155 | ) |

[0001262039-17-000034:mdna:105]
Interest income increased by $4.1 million, or 76%, in the nine months ended September 30, 2017 compared to the same period last year due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Other income (expense)—net consisted primarily of foreign exchange and related hedging gains and losses. The increase in other income (expense)—net in the nine months ended September 30, 2017 when compared to the same period last year was the result of foreign currency exchange gains in the nine months ended September 30, 2017, compared to foreign currency exchange losses in the nine months ended September 30, 2016.

[0001262039-17-000034:mdna:106]
[same as prior period, unchanged from 0001262039-17-000027:mdna:112]

[0001262039-17-000034:mdna:107]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2017 |  | September 30, 2016 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | 18,556 |  |  | $ | (7,380 | ) |  | $ | 25,936 |  |  | * |
| Effective tax rate (%) | 24 | % |  | 2,053 | % |  | * |  |  | * |

[0001262039-17-000034:mdna:108]
[same as prior period, unchanged from 0001262039-17-000027:mdna:114]

[0001262039-17-000034:mdna:109]
Our effective tax rate was 24% in the nine months ended September 30, 2017, compared with an effective tax rate of 2,053% in the same period last year. The effective tax rates in the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rate in the nine months ended September 30, 2017 and 2016 were impacted by excess tax benefits of $11.4 million and $8.7 million, respectively, from stock-based compensation.

[0001262039-17-000034:mdna:110]
35

[0001262039-17-000034:mdna:111]
[same as prior period, unchanged from 0001262039-17-000027:mdna:116]

[0001262039-17-000034:mdna:112]
|  | As of |
|  | September 30, 2017 |  | December 31, 2016 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 905,794 |  |  | $ | 709,003 |  |
| Investments | 617,836 |  |  | 601,505 |  |
| Total cash, cash equivalents and investments | $ | 1,523,630 |  |  | $ | 1,310,508 |  |
| Working capital | $ | 740,012 |  |  | $ | 709,276 |  |
|  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 436,863 |  |  | $ | 244,671 |  |
| Cash used in investing activities | (142,083 | ) |  | (76,215 | ) |
| Cash used in financing activities | (97,989 | ) |  | (64,220 | ) |
| Net increase in cash and cash equivalents | $ | 196,791 |  |  | $ | 104,236 |  |

[0001262039-17-000034:mdna:113]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our employee stock purchase plan (the “ESPP”), payment of taxes in connection with the net settlement of equity awards and business acquisitions. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the exercise of stock options. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units (“RSUs”) granted versus stock options and also to vary based on our share price. As of September 30, 2017, $365.2 million remained available for future share repurchase under the Repurchase Program. In October 2017, our board of directors approved a $400.0 million increase to the Repurchase Program, bringing the total amount authorized to be repurchased to $1.0 billion through January 31, 2019.

[0001262039-17-000034:mdna:114]
The total capital expenditures for real estate purchases in 2017 is currently expected to be approximately $110.0 million, including the $84.8 million we spent on the purchase of two buildings in Burnaby, Canada in April 2017. We currently expect to spend $120.0 million total in 2018 and 2019 to build out our headquarters in Sunnyvale, California. The specific timing of the 2018 and 2019 expenditures is yet to be determined.

[0001262039-17-000034:mdna:115]
As of September 30, 2017, our cash, cash equivalents and investments of $1.52 billion were invested primarily in corporate debt securities, commercial paper, term deposits, U.S. government and agency securities and municipal bonds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-17-000034:mdna:116]
As of September 30, 2017, $773.0 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes.

[0001262039-17-000034:mdna:117]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-17-000034:mdna:118]
[same as prior period, unchanged from 0001262039-17-000027:mdna:124]

[0001262039-17-000034:mdna:119]
[same as prior period, unchanged from 0001262039-17-000027:mdna:125]

[0001262039-17-000034:mdna:120]
Our operating activities during the nine months ended September 30, 2017 provided $436.9 million in cash as a result of our continued growth in the sales of FortiGuard and FortiCare subscription services, as well as product sales, and the ability to successfully manage our working capital. The increase in sales of our FortiGuard and FortiCare subscription services to new and existing customers was reflected in the increase in our deferred revenue. We continued to see the shift from product revenue to higher-margin, recurring service revenue.

[0001262039-17-000034:mdna:121]
Our operating activities during the nine months ended September 30, 2016 provided $244.7 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and FortiCare subscription services to new and existing customers, as reflected by an increase in our deferred revenue.

[0001262039-17-000034:mdna:122]
[same as prior period, unchanged from 0001262039-17-000027:mdna:128]

[0001262039-17-000034:mdna:123]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believe that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-17-000034:mdna:124]
During the nine months ended September 30, 2017, cash used in investing activities was primarily due to the $121.6 million we spent on capital expenditures, including the purchase of $84.8 million in real estate in Burnaby, Canada in April 2017. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $20.4 million.

[0001262039-17-000034:mdna:125]
During the nine months ended September 30, 2016, cash used for investing activities was primarily due to the $50.3 million we spent on capital expenditures, including our purchase of a warehouse in Union City, California for total cash of $18.5 million, and a $22.1 million payment for the acquisition of AccelOps. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $3.8 million.

[0001262039-17-000034:mdna:126]
[same as prior period, unchanged from 0001262039-17-000027:mdna:132]

[0001262039-17-000034:mdna:127]
The changes in cash flows from financing activities primarily relate to our repurchase of common stock and proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards.

[0001262039-17-000034:mdna:128]
During the nine months ended September 30, 2017, cash used in financing activities was $98.0 million, primarily due to $124.0 million used to repurchase our common stock. This was partially offset by $26.0 million proceeds from the issuance of common stock, net of tax withholding.

[0001262039-17-000034:mdna:129]
During the nine months ended September 30, 2016, cash used for financing activities was $64.2 million, primarily due to $75.0 million used to repurchase our common stock. This was partially offset by $12.4 million of proceeds from the issuance of common stock, net of taxes paid.

[0001262039-17-000034:mdna:130]
[same as prior period, unchanged from 0001262039-17-000027:mdna:136]

[0001262039-17-000034:mdna:131]
There were no material changes outside the ordinary course of business during the nine months ended September 30, 2017 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 9 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-17-000034:mdna:132]
37

[0001262039-17-000034:mdna:133]
[same as prior period, unchanged from 0001262039-17-000027:mdna:139]

[0001262039-17-000034:mdna:134]
As of September 30, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-17-000034:mdna:135]
38
