# FTNT notes — 0001262039-17-000034


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-17-000034:notes:1]
[same as prior period, unchanged from 0001262039-17-000027:notes:1]

[0001262039-17-000034:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Income tax benefit associated with stock-based compensation | $ | 6,722 |  |  | $ | 8,223 |  |  | $ | 21,111 |  |  | $ | 22,961 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-17-000034:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

[0001262039-17-000034:notes:4]
[same as prior period, unchanged from 0001262039-17-000027:notes:4]

[0001262039-17-000034:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-17-000034:notes:6]
[same as prior period, unchanged from 0001262039-17-000027:notes:6]

[0001262039-17-000034:notes:7]
|  | September 30, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 427,655 |  |  | $ | 91 |  |  | $ | (619 | ) |  | $ | 427,127 |  |
| Commercial paper | 97,757 |  |  | 1 |  |  | (23 | ) |  | 97,735 |  |
| U.S. government and agency securities | 53,243 |  |  | 2 |  |  | (118 | ) |  | 53,127 |  |
| Municipal bonds | 39,854 |  |  | 22 |  |  | (29 | ) |  | 39,847 |  |
| Total available-for-sale securities | $ | 618,509 |  |  | $ | 116 |  |  | $ | (789 | ) |  | $ | 617,836 |  |
|  | December 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 379,494 |  |  | $ | 43 |  |  | $ | (925 | ) |  | $ | 378,612 |  |
| Commercial paper | 95,110 |  |  | 23 |  |  | (25 | ) |  | 95,108 |  |
| U.S. government and agency securities | 64,604 |  |  | 16 |  |  | (79 | ) |  | 64,541 |  |
| Municipal bonds | 59,257 |  |  | 3 |  |  | (235 | ) |  | 59,025 |  |
| Certificates of deposit and term deposits (1) | 4,219 |  |  | — |  |  | — |  |  | 4,219 |  |
| Total available-for-sale securities | $ | 602,684 |  |  | $ | 85 |  |  | $ | (1,264 | ) |  | $ | 601,505 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-17-000034:notes:8]
[same as prior period, unchanged from 0001262039-17-000027:notes:8]

[0001262039-17-000034:notes:9]
|  | Three months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Expected term in years | 4.4 |  |  | 4.3 |  |  | 4.4 |  |  | 4.3 |  |
| Volatility | 33 | % |  | 38 | % |  | 36 | % |  | 42 | % |
| Risk-free interest rate | 1.8 | % |  | 1.1 | % |  | 1.9 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-17-000034:notes:10]
[same as prior period, unchanged from 0001262039-17-000027:notes:10]

[0001262039-17-000034:notes:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| RSUs | $ | 29,904 |  |  | $ | 27,342 |  |  | $ | 89,807 |  |  | $ | 79,244 |  |
| Stock options | 1,811 |  |  | 1,516 |  |  | 5,581 |  |  | 5,062 |  |
| ESPP | 2,592 |  |  | 2,235 |  |  | 7,341 |  |  | 6,036 |  |
| Total stock-based compensation expense | $ | 34,307 |  |  | $ | 31,093 |  |  | $ | 102,729 |  |  | $ | 90,342 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-17-000034:notes:12]
[same as prior period, unchanged from 0001262039-17-000027:notes:12]

[0001262039-17-000034:notes:13]
|  |  |  | Nine Months Ended |
|  |  |  |  |  | September 30, 2017 |  | September 30, 2016 |
| Shares withheld for taxes |  |  |  |  | 995 |  |  | 937 |  |
| Amount withheld for taxes |  |  |  |  | $ | 35,869 |  |  | $ | 29,886 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-17-000034:notes:14]
[same as prior period, unchanged from 0001262039-17-000027:notes:14]

[0001262039-17-000034:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Weighted-average fair value per share granted | $ | 11.09 |  |  | $ | 10.62 |  |  | $ | 12.17 |  |  | $ | 9.08 |  |
| Intrinsic value of options exercised | 3,432 |  |  | 9,340 |  |  | 30,333 |  |  | 35,593 |  |
| Fair value of options vested | 1,562 |  |  | 1,706 |  |  | 6,691 |  |  | 4,583 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-17-000034:notes:16]
[same as prior period, unchanged from 0001262039-17-000027:notes:16]

[0001262039-17-000034:notes:17]
|  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
| Weighted-average fair value per share granted | $ | 8.73 |  |  | $ | 7.68 |  |
| Shares issued under the ESPP | 1,135 |  |  | 1,151 |  |
| Weighted-average price per share issued | $ | 29.52 |  |  | $ | 21.01 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-17-000034:notes:18]
[same as prior period, unchanged from 0001262039-17-000027:notes:18]

[0001262039-17-000034:notes:19]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions, for total cash consideration of $22.1 million, net of cash received. This acquisition extended the Fortinet Security Fabric.

[0001262039-17-000034:notes:20]
The acquisition of AccelOps was accounted as a business combination in accordance with ASC Topic 805 “Business Combinations” issued by the FASB, and we used our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-17-000034:notes:21]
[same as prior period, unchanged from 0001262039-17-000027:notes:21]

[0001262039-17-000034:notes:22]
[same as prior period, unchanged from 0001262039-17-000027:notes:22]

[0001262039-17-000034:notes:23]
[same as prior period, unchanged from 0001262039-17-000027:notes:23]

[0001262039-17-000034:notes:24]
[same as prior period, unchanged from 0001262039-17-000027:notes:24]

[0001262039-17-000034:notes:25]
[same as prior period, unchanged from 0001262039-17-000027:notes:25]

[0001262039-17-000034:notes:26]
[same as prior period, unchanged from 0001262039-17-000027:notes:26]

[0001262039-17-000034:notes:27]
[same as prior period, unchanged from 0001262039-17-000027:notes:27]

[0001262039-17-000034:notes:28]
[same as prior period, unchanged from 0001262039-17-000027:notes:28]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-17-000034:notes:29]
COMMITMENTS AND CONTINGENCIES

[0001262039-17-000034:notes:30]
The following table summarizes our future principal contractual obligations as of September 30, 2017 (in thousands):

[0001262039-17-000034:notes:31]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 50,510 |  |  | $ | 3,953 |  |  | $ | 14,022 |  |  | $ | 10,732 |  |  | $ | 8,535 |  |  | $ | 4,557 |  |  | $ | 8,711 |  |
| Inventory purchase commitments | 93,664 |  |  | 89,417 |  |  | 4,247 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 67,253 |  |  | 40,854 |  |  | 19,651 |  |  | 4,311 |  |  | 2,132 |  |  | 302 |  |  | 3 |  |
| Total | $ | 211,427 |  |  | $ | 134,224 |  |  | $ | 37,920 |  |  | $ | 15,043 |  |  | $ | 10,667 |  |  | $ | 4,859 |  |  | $ | 8,714 |  |

[0001262039-17-000034:notes:32]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $6.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Rent expense was $12.5 million and $14.7 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-17-000034:notes:33]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2017, we had $93.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-17-000034:notes:34]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2017, we had $67.3 million in other contractual commitments that may not be cancelable.  Included in other contractual commitments is $8.8 million related to the purchase of certain real estate adjacent to our corporate headquarters.

[0001262039-17-000034:notes:35]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-17-000034:notes:36]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

[0001262039-17-000034:notes:37]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions, including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-17-000034:notes:38]
[same as prior period, unchanged from 0001262039-17-000027:notes:38]

[0001262039-17-000034:notes:39]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended September 30, 2017 and September 30, 2016 were $1.2 million and $1.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the nine months ended September 30, 2017 and September 30, 2016 were $3.8 million and $3.4 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-17-000034:notes:40]
[same as prior period, unchanged from 0001262039-17-000027:notes:40]

[0001262039-17-000034:notes:41]
[same as prior period, unchanged from 0001262039-17-000027:notes:41]

[0001262039-17-000034:notes:42]
|  | September 30, 2017 |
|  | Unrealized losses on investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |
| Other comprehensive income before reclassifications | 504 |  |  | (156 | ) |  | 348 |  |
| Amounts reclassified from accumulated other comprehensive loss | 2 |  |  | (1 | ) |  | 1 |  |
| Net current-period other comprehensive income | 506 |  |  | (157 | ) |  | 349 |  |
| Ending balance | $ | (673 | ) |  | $ | 257 |  |  | $ | (416 | ) |

[0001262039-17-000034:notes:43]
[same as prior period, unchanged from 0001262039-17-000027:notes:43]


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-17-000034:notes:44]
[same as prior period, unchanged from 0001262039-17-000027:notes:44]

[0001262039-17-000034:notes:45]
Our investments in the equity securities of privately held companies totaled $12.1 million and $10.3 million as of September 30, 2017 and December 31, 2016, respectively. These investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of September 30, 2017, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-17-000034:notes:46]
As of September 30, 2017, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-17-000034:notes:47]
[same as prior period, unchanged from 0001262039-17-000027:notes:47]

[0001262039-17-000034:notes:48]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), the Euro (“EUR”) and the British pound (“GBP”). To help protect against significant fluctuations in the value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to minimize the impact of balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have a maturity of one month. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other income (expense)—net in the consolidated statements of operations. As of September 30, 2017, the fair value of the forward exchange contracts was not material.

[0001262039-17-000034:notes:49]
[same as prior period, unchanged from 0001262039-17-000027:notes:49]

[0001262039-17-000034:notes:50]
There were no outstanding forward exchange contracts as of September 30, 2017. The notional amount of forward exchange contracts to hedge balance sheet accounts December 31, 2016 were (in thousands):

[0001262039-17-000034:notes:51]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of December 31, 2016 |  |  |  |
| CAD | Sell |  | $ | 2,615 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-17-000034:notes:52]
[same as prior period, unchanged from 0001262039-17-000027:notes:52]

[0001262039-17-000034:notes:53]
[same as prior period, unchanged from 0001262039-17-000027:notes:53]

[0001262039-17-000034:notes:54]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs. We also have an ESPP for all eligible employees. As of September 30, 2017, there were a total of 49,841,761 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-17-000034:notes:55]
[same as prior period, unchanged from 0001262039-17-000027:notes:55]

[0001262039-17-000034:notes:56]
[same as prior period, unchanged from 0001262039-17-000027:notes:56]

[0001262039-17-000034:notes:57]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2016 | 9,509 |  |  | $ | 31.01 |  |
| Granted | 3,630 |  |  | 37.29 |  |
| Forfeited | (928 | ) |  | 34.07 |  |
| Vested | (3,153 | ) |  | 29.02 |  |
| Balance—September 30, 2017 | 9,058 |  |  | $ | 34.01 |  |

[0001262039-17-000034:notes:58]
As of September 30, 2017, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $266.4 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.7 years.

[0001262039-17-000034:notes:59]
[same as prior period, unchanged from 0001262039-17-000027:notes:59]

[0001262039-17-000034:notes:60]
[same as prior period, unchanged from 0001262039-17-000027:notes:60]

[0001262039-17-000034:notes:61]
[same as prior period, unchanged from 0001262039-17-000027:notes:61]

[0001262039-17-000034:notes:62]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2016 | 6,187 |  |  | $ | 23.79 |  |  |  |  |  |  |
| Granted | 536 |  |  | 37.26 |  |  |  |  |  |
| Forfeited | (164 | ) |  | 30.84 |  |  |  |  |  |
| Exercised | (1,569 | ) |  | 18.04 |  |  |  |  |  |
| Balance—September 30, 2017 | 4,990 |  |  | $ | 26.82 |  |  |  |  |  |
| Options vested and expected to vest—September 30, 2017 | 4,990 |  |  | $ | 26.82 |  |  | 3.2 |  | $ | 48,315 |  |
| Options exercisable—September 30, 2017 | 3,418 |  |  | $ | 24.74 |  |  | 2.0 |  | $ | 39,413 |  |

[0001262039-17-000034:notes:63]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2017, for all in-the-money stock options. As of September 30, 2017, total compensation expense related to unvested stock options granted to employees but not yet recognized was $15.3 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.6 years.

[0001262039-17-000034:notes:64]
[same as prior period, unchanged from 0001262039-17-000027:notes:64]

[0001262039-17-000034:notes:65]
[same as prior period, unchanged from 0001262039-17-000027:notes:65]

[0001262039-17-000034:notes:66]
|  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 29 | % |  | 39 | % |
| Risk-free interest rate | 0.9 | % |  | 0.4 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-17-000034:notes:67]
[same as prior period, unchanged from 0001262039-17-000027:notes:67]

[0001262039-17-000034:notes:68]
[same as prior period, unchanged from 0001262039-17-000027:notes:68]

[0001262039-17-000034:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Cost of product revenue | $ | 314 |  |  | $ | 309 |  |  | $ | 1,039 |  |  | $ | 887 |  |
| Cost of service revenue | 2,371 |  |  | 2,238 |  |  | 7,154 |  |  | 6,495 |  |
| Research and development | 7,976 |  |  | 7,648 |  |  | 24,127 |  |  | 22,249 |  |
| Sales and marketing | 19,609 |  |  | 17,378 |  |  | 58,380 |  |  | 50,183 |  |
| General and administrative | 4,037 |  |  | 3,520 |  |  | 12,029 |  |  | 10,528 |  |
| Total stock-based compensation expense | $ | 34,307 |  |  | $ | 31,093 |  |  | $ | 102,729 |  |  | $ | 90,342 |  |

[0001262039-17-000034:notes:70]
Share Repurchase Program

[0001262039-17-000034:notes:71]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In October 2016 and July 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $300.0 million, respectively. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-17-000034:notes:72]
During the three months ended September 30, 2017, we repurchased 2.4 million shares of common stock under the Repurchase Program in open market transactions at an average price of $37.19 per share, for an aggregate purchase price of $90.8 million. During the nine months ended September 30, 2017, we repurchased 3.3 million shares of common stock under the Repurchase Program in open market transactions at an average price of $37.67 per share, for an aggregate purchase price of $124.0 million. As of September 30, 2017, $365.2 million remained available for future share repurchases under the Repurchase Program. See Note 17 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for information regarding the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-17-000034:notes:73]
NET INCOME PER SHARE

[0001262039-17-000034:notes:74]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and the employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-17-000034:notes:75]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-17-000034:notes:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 26,610 |  |  | $ | 6,291 |  |  | $ | 60,360 |  |  | $ | 7,021 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 175,519 |  |  | 173,335 |  |  | 175,253 |  |  | 172,212 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 175,519 |  |  | 173,335 |  |  | 175,253 |  |  | 172,212 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2,091 |  |  | 2,513 |  |  | 2,249 |  |  | 1,891 |  |
| Stock options | 1,327 |  |  | 2,009 |  |  | 1,446 |  |  | 1,867 |  |
| ESPP | 36 |  |  | 81 |  |  | 39 |  |  | 76 |  |
| Weighted-average shares used to compute diluted net income per share | 178,973 |  |  | 177,938 |  |  | 178,987 |  |  | 176,046 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | 0.34 |  |  | $ | 0.04 |  |
| Diluted | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | 0.34 |  |  | $ | 0.04 |  |

[0001262039-17-000034:notes:77]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-17-000034:notes:78]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| RSUs | 1,038 |  |  | 2,409 |  |  | 1,567 |  |  | 3,946 |  |
| Stock options | 1,081 |  |  | 836 |  |  | 1,108 |  |  | 1,067 |  |
| ESPP | 363 |  |  | 353 |  |  | 208 |  |  | 211 |  |
|  | 2,482 |  |  | 3,598 |  |  | 2,883 |  |  | 5,224 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-17-000034:notes:79]
[same as prior period, unchanged from 0001262039-17-000027:notes:79]

[0001262039-17-000034:notes:80]
[same as prior period, unchanged from 0001262039-17-000027:notes:80]

[0001262039-17-000034:notes:81]
|  | September 30, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 294,479 |  |  | $ | (482 | ) |  | $ | 35,645 |  |  | $ | (137 | ) |  | $ | 330,124 |  |  | $ | (619 | ) |
| U.S. government and agency securities | 43,187 |  |  | (66 | ) |  | 5,446 |  |  | (52 | ) |  | 48,633 |  |  | (118 | ) |
| Municipal bonds | 16,868 |  |  | (14 | ) |  | 3,180 |  |  | (15 | ) |  | 20,048 |  |  | (29 | ) |
| Commercial paper | 36,844 |  |  | (23 | ) |  | — |  |  | — |  |  | 36,844 |  |  | (23 | ) |
| Total available-for-sale securities | $ | 391,378 |  |  | $ | (585 | ) |  | $ | 44,271 |  |  | $ | (204 | ) |  | $ | 435,649 |  |  | $ | (789 | ) |

[0001262039-17-000034:notes:82]
[same as prior period, unchanged from 0001262039-17-000027:notes:82]

[0001262039-17-000034:notes:83]
[same as prior period, unchanged from 0001262039-17-000027:notes:83]

[0001262039-17-000034:notes:84]
|  | September 30, 2017 |  | December 31, 2016 |
| Due within one year | $ | 369,961 |  |  | $ | 376,522 |  |
| Due between one and three years | 247,875 |  |  | 224,983 |  |
| Total | $ | 617,836 |  |  | $ | 601,505 |  |

[0001262039-17-000034:notes:85]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other income (expense)—net in our condensed consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-17-000034:notes:86]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of September 30, 2017.

[0001262039-17-000034:notes:87]
[same as prior period, unchanged from 0001262039-17-000027:notes:87]

[0001262039-17-000034:notes:88]
[same as prior period, unchanged from 0001262039-17-000027:notes:88]

[0001262039-17-000034:notes:89]
[same as prior period, unchanged from 0001262039-17-000027:notes:89]

[0001262039-17-000034:notes:90]
[same as prior period, unchanged from 0001262039-17-000027:notes:90]

[0001262039-17-000034:notes:91]
[same as prior period, unchanged from 0001262039-17-000027:notes:91]

[0001262039-17-000034:notes:92]
[same as prior period, unchanged from 0001262039-17-000027:notes:92]

[0001262039-17-000034:notes:93]
[same as prior period, unchanged from 0001262039-17-000027:notes:93]

[0001262039-17-000034:notes:94]
[same as prior period, unchanged from 0001262039-17-000027:notes:94]

[0001262039-17-000034:notes:95]
[same as prior period, unchanged from 0001262039-17-000027:notes:95]

[0001262039-17-000034:notes:96]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of September 30, 2017 and December 31, 2016 (in thousands):

[0001262039-17-000034:notes:97]
|  | September 30, 2017 |  | December 31, 2016 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 427,127 |  |  | $ | — |  |  | $ | 427,127 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |
| Commercial paper | 111,726 |  |  | — |  |  | 111,726 |  |  | — |  |  | 105,097 |  |  | — |  |  | 105,097 |  |  | — |  |
| U.S. government and agency securities | 53,127 |  |  | 47,681 |  |  | 5,446 |  |  | — |  |  | 64,541 |  |  | 52,082 |  |  | 12,459 |  |  | — |  |
| Municipal bonds | 39,847 |  |  | — |  |  | 39,847 |  |  | — |  |  | 59,025 |  |  | — |  |  | 59,025 |  |  | — |  |
| Money market funds | 20,271 |  |  | 20,271 |  |  | — |  |  | — |  |  | 38,649 |  |  | 38,649 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits (1) | 55,424 |  |  | — |  |  | 55,424 |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Total | $ | 707,522 |  |  | $ | 67,952 |  |  | $ | 639,570 |  |  | $ | — |  |  | $ | 705,403 |  |  | $ | 90,731 |  |  | $ | 614,672 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 89,686 |  |  |  |  |  |  |  |  | $ | 103,898 |  |  |  |  |  |  |  |
| Short-term investments | 369,961 |  |  |  |  |  |  |  |  | 376,522 |  |  |  |  |  |  |  |
| Long-term investments | 247,875 |  |  |  |  |  |  |  |  | 224,983 |  |  |  |  |  |  |  |
| Total | $ | 707,522 |  |  |  |  |  |  |  |  | $ | 705,403 |  |  |  |  |  |  |  |

[0001262039-17-000034:notes:98]
[same as prior period, unchanged from 0001262039-17-000027:notes:98]

[0001262039-17-000034:notes:99]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-17-000034:notes:100]
[same as prior period, unchanged from 0001262039-17-000027:notes:100]

[0001262039-17-000034:notes:101]
[same as prior period, unchanged from 0001262039-17-000027:notes:101]

[0001262039-17-000034:notes:102]
As of September 30, 2017, we had goodwill of $14.6 million. There were no impairments to goodwill during the three and nine months ended September 30, 2017 or during prior periods.

[0001262039-17-000034:notes:103]
[same as prior period, unchanged from 0001262039-17-000027:notes:103]

[0001262039-17-000034:notes:104]
The following tables present other intangible assets—net as of September 30, 2017 and December 31, 2016 (in thousands, except years):

[0001262039-17-000034:notes:105]
|  | September 30, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 12,501 |  |  | $ | 11,483 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 9,292 |  |  | 5,208 |  |
|  |  |  | 38,484 |  |  | 21,793 |  |  | 16,691 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 21,793 |  |  | $ | 18,291 |  |

[0001262039-17-000034:notes:106]
[same as prior period, unchanged from 0001262039-17-000027:notes:106]

[0001262039-17-000034:notes:107]
The in-process research and development intangible asset of $1.6 million is expected to be completed in the fourth quarter of 2017. Upon completion, the cost will be transferred to developed technology and will be amortized over the remaining estimated useful life of the asset.

[0001262039-17-000034:notes:108]
Amortization expense was $2.0 million and $2.8 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Amortization expense was $6.5 million and $6.3 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in thousands):

[0001262039-17-000034:notes:109]
|  | Amount |
| Years: |  |
| 2017 (remainder) | $ | 2,037 |  |
| 2018 | 6,885 |  |
| 2019 | 5,406 |  |
| 2020 | 2,363 |  |
| Total | $ | 16,691 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-17-000034:notes:110]
[same as prior period, unchanged from 0001262039-17-000027:notes:109]

[0001262039-17-000034:notes:111]
Our effective tax rate was 30% for the three months ended September 30, 2017, compared to an effective tax rate of 5% for the same period last year. Our effective tax rate was 24% for the nine months ended September 30, 2017, compared to an effective tax rate of 2,053% for the same period last year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, excess tax benefits from stock-based compensation, withholding taxes and foreign income taxes. The tax rates for the three months ended September 30, 2017 and September 30, 2016 were impacted by excess tax benefits of $1.8 million and $2.5 million, respectively, from stock-based compensation. The tax rates for the nine months ended September 30, 2017 and September 30, 2016 were impacted by excess tax benefits of $11.4 million and $8.7 million, respectively, from stock-based compensation. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-17-000034:notes:112]
As of September 30, 2017 and December 31, 2016, unrecognized tax benefits were $82.1 million and $65.5 million, respectively. The total amount of $80.4 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate. It is our policy to classify accrued interest and penalties related to uncertain tax benefits in the provision for income taxes. As of September 30, 2017 and December 31, 2016, accrued interest and penalties were $12.9 million and $9.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $9.0 million in the next twelve months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-17-000034:notes:113]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for tax years 2012, 2013 and 2014. We have filed a waiver extending the statute of limitations to November 30, 2018 for U.S. federal income tax returns for tax years 2012, 2013 and 2014. In addition, the tax authorities in France are examining the inter-company relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In May 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-17-000034:notes:114]
[same as prior period, unchanged from 0001262039-17-000027:notes:115]

[0001262039-17-000034:notes:115]
[same as prior period, unchanged from 0001262039-17-000027:notes:116]

[0001262039-17-000034:notes:116]
|  | September 30, 2017 |  | December 31, 2016 |
| Raw materials | $ | 13,733 |  |  | $ | 18,924 |  |
| Finished goods | 59,862 |  |  | 87,963 |  |
| Inventory | $ | 73,595 |  |  | $ | 106,887 |  |

[0001262039-17-000034:notes:117]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.0 million as of September 30, 2017 and December 31, 2016.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-17-000034:notes:118]
| Property and Equipment—net | September 30, 2017 |  | December 31, 2016 |
| Americas: |  |  |  |
| U.S. | $ | 112,210 |  |  | $ | 96,414 |  |
| Canada | 101,103 |  |  | 12,881 |  |
| LATAM | 360 |  |  | 607 |  |
| Total Americas | 213,673 |  |  | 109,902 |  |
| EMEA: |  |  |  |
| France | 12,185 |  |  | 13,241 |  |
| Other EMEA | 5,903 |  |  | 6,391 |  |
| Total EMEA | 18,088 |  |  | 19,632 |  |
| APAC | 8,130 |  |  | 7,715 |  |
| Total property and equipment—net | $ | 239,891 |  |  | $ | 137,249 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-17-000034:notes:119]
Recently Adopted Accounting Standards

[0001262039-17-000034:notes:120]
Business Combinations – Definition of a Business

[0001262039-17-000034:notes:121]
In January 2017, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

[0001262039-17-000034:notes:122]
Recent Accounting Standards Not Yet Effective

[0001262039-17-000034:notes:123]
Share-Based Payment Accounting

[0001262039-17-000034:notes:124]
In May 2017, the FASB issued ASU 2017-09—Compensation—Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modification accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.

[0001262039-17-000034:notes:125]
Goodwill Impairment

[0001262039-17-000034:notes:126]
In January 2017, the FASB issued ASU 2017-04—Intangibles—Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We early adopted ASU 2017-04 on October 1, 2017. The adoption did not have a material impact on our consolidated financial statements.

[0001262039-17-000034:notes:127]
Income Taxes – Intra-Entity Asset Transfers

[0001262039-17-000034:notes:128]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of ASU 2016-16 on our consolidated financial statements.

[0001262039-17-000034:notes:129]
Financial Instruments – Credit Losses

[0001262039-17-000034:notes:130]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. Based on our current accounts receivable portfolio, we do not believe ASU 2016-13 will have a material impact on our consolidated financial statements.

[0001262039-17-000034:notes:131]
Leases

[0001262039-17-000034:notes:132]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the notes to consolidated financial statements include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

[0001262039-17-000034:notes:133]
Financial Instruments – Recognition and Measurement

[0001262039-17-000034:notes:134]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception will apply to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 is effective for our cost-method investments beginning on January 1, 2018 on a prospective basis. The adoption of ASU 2016-01 will result in the adjustment to the carrying amount when the cost-method investees complete a financing round subsequent to adoption date.

[0001262039-17-000034:notes:135]
Revenue Recognition

[0001262039-17-000034:notes:136]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 will be effective for us beginning January 1, 2018. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We will adopt the standard using the modified retrospective method and apply the standard to contracts that are not completed as of January 1, 2018, and recognize the cumulative effect of initially applying the standard as an adjustment to the opening balance of retained earnings.

[0001262039-17-000034:notes:137]
We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances and FortiGuard and FortiCare subscription services to be substantially unchanged on an ongoing basis. We believe that the acceleration of revenue and associated cost of sales to certain channel partners which are currently accounted for only once the product is sold through to the end-customer, and the allocation of revenue related to software due to the removal of the residual method will not have a significant impact on our financial statements.

[0001262039-17-000034:notes:138]
Under ASU 2014-09, we will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs related to service contracts. Under current U.S. GAAP, we expense all sales commissions when incurred. Our quantitative analysis of the impact of the change in accounting for sales commissions, including the various components of our current and future compensation plans and the key assumptions associated with the amortization term, is in progress. We believe that the amortization of incremental commission costs of obtaining customer contracts is likely to have a material impact on our financial statements.

[0001262039-17-000034:notes:139]
We expect to expand our financial statement disclosures, which may include more details on our disaggregation of revenue, performance obligations, contract balances and costs to obtain a contract, as well as any significant judgments. We are in the process of documenting process changes, implementing required changes in our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing, which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09, along with industry trends until the adoption date.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-17-000034:notes:140]
[same as prior period, unchanged from 0001262039-17-000027:notes:131]

[0001262039-17-000034:notes:141]
[same as prior period, unchanged from 0001262039-17-000027:notes:132]

[0001262039-17-000034:notes:142]
|  | September 30, 2017 |  | December 31, 2016 |
| Building and building improvements | $ | 131,054 |  |  | $ | 49,783 |  |
| Computer equipment and software | 76,872 |  |  | 65,323 |  |
| Land | 62,226 |  |  | 35,079 |  |
| Leasehold improvements | 20,690 |  |  | 18,699 |  |
| Evaluation units | 20,169 |  |  | 20,173 |  |
| Furniture and fixtures | 13,892 |  |  | 13,995 |  |
| Construction-in-progress | 2,971 |  |  | 4,669 |  |
| Total property and equipment | 327,874 |  |  | 207,721 |  |
| Less: accumulated depreciation | (87,983 | ) |  | (70,472 | ) |
| Property and equipment—net | $ | 239,891 |  |  | $ | 137,249 |  |

[0001262039-17-000034:notes:143]
[same as prior period, unchanged from 0001262039-17-000027:notes:134]

[0001262039-17-000034:notes:144]
Depreciation expense was $11.7 million and $10.2 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Depreciation expense was $34.7 million and $28.6 million during the nine months ended September 30, 2017 and September 30, 2016, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-17-000034:notes:145]
RELATED PARTY TRANSACTIONS

[0001262039-17-000034:notes:146]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Expenses for legal services provided by the law firm were $0.9 million and $0.3 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of September 30, 2017 and December 31, 2016, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-17-000034:notes:147]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 123,646 |  |  | $ | 108,142 |  |  | $ | 367,124 |  |  | $ | 309,041 |  |
| Latin America (“LATAM”) | 24,372 |  |  | 15,614 |  |  | 64,567 |  |  | 46,850 |  |
| Canada (1) | 13,135 |  |  | 10,118 |  |  | 36,539 |  |  | 30,675 |  |
| Total Americas | 161,153 |  |  | 133,874 |  |  | 468,230 |  |  | 386,566 |  |
| Europe, Middle East and Africa (“EMEA”) | 138,335 |  |  | 116,967 |  |  | 394,214 |  |  | 336,911 |  |
| Asia Pacific (“APAC”) | 74,729 |  |  | 65,805 |  |  | 215,818 |  |  | 189,136 |  |
| Total revenue | $ | 374,217 |  |  | $ | 316,646 |  |  | $ | 1,078,262 |  |  | $ | 912,613 |  |

[0001262039-17-000034:notes:148]
(1) Certain amounts in the prior periods in Canada were reclassified to the United States to conform with the 2017 presentation as a result of a change in the bill-to address of a customer.

[0001262039-17-000034:notes:149]
[same as prior period, unchanged from 0001262039-17-000027:notes:139]

[0001262039-17-000034:notes:150]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Exclusive Networks Group (2) | 29 | % |  | 19 | % |  | 23 | % |  | 19 | % |
| Ingram Micro | 11 | % |  | 10 | % |  | 10 | % |  | * |  |

[0001262039-17-000034:notes:151]
[same as prior period, unchanged from 0001262039-17-000027:notes:141]

[0001262039-17-000034:notes:152]
|  | September 30, 2017 (2) |  | December 31, 2016 |
| Exclusive Networks Group | 31 | % |  | 26 | % |
| Fine Tec Computers | * |  |  | 10 | % |

[0001262039-17-000034:notes:153]
* Represents less than 10%

[0001262039-17-000034:notes:154]
(2) Due to the acquisition by Exclusive Networks Group of the U.S. division of Fine Tec Computers (“Fine Tec U.S.”) in July 2017, Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive Networks Group’s. As of September 30, 2017, Fine Tec Canada's accounts receivable represent less than 10% of our net accounts receivable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-17-000034:notes:155]
[same as prior period, unchanged from 0001262039-17-000027:notes:143]

[0001262039-17-000034:notes:156]
[same as prior period, unchanged from 0001262039-17-000027:notes:144]

[0001262039-17-000034:notes:157]
[same as prior period, unchanged from 0001262039-17-000027:notes:145]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-17-000034:notes:158]
[same as prior period, unchanged from 0001262039-17-000027:notes:147]


## us-gaap:SubsequentEventsTextBlock

[0001262039-17-000034:notes:159]
SUBSEQUENT EVENT

[0001262039-17-000034:notes:160]
In October 2017, our board of directors approved a $400.0 million increase to authorized stock repurchases under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $1.0 billion.
