# FTNT 8-K — 0001262039-17-000031 filed 2017-10-26

## item codes, every 8-K on or before 2017-11-02

- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2017-11-02

- none on or before 2017-11-02

## item 2.02 — earnings release, exhibit 99.1

[0001262039-17-000031:8k_2_02:1]
EX-99.1
2
ftntq3-2017ex991.htm
EXHIBIT 99.1

[0001262039-17-000031:8k_2_02:2]
Exhibit

[0001262039-17-000031:8k_2_02:3]
Press Release

[0001262039-17-000031:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Kelly Blough |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 x 81612 |  | 408-391-9408 |
| kblough@fortinet.com |  | swheatley@fortinet.com |

[0001262039-17-000031:8k_2_02:5]
Fortinet Reports Third Quarter 2017 Financial Results

[0001262039-17-000031:8k_2_02:6]
Revenue and Billings Growth Continues to Surpass Market

[0001262039-17-000031:8k_2_02:7]
Operating Margins Expand

[0001262039-17-000031:8k_2_02:8]
Third Quarter 2017 Highlights

[0001262039-17-000031:8k_2_02:9]
•Revenue of $374.2 million, up 18% year over year

[0001262039-17-000031:8k_2_02:10]
•Billings of $431.7 million, up 24% year over year1

[0001262039-17-000031:8k_2_02:11]
•GAAP diluted net income per share of $0.15

[0001262039-17-000031:8k_2_02:12]
•Non-GAAP diluted net income per share of $0.281

[0001262039-17-000031:8k_2_02:13]
•GAAP operating margin of 9%

[0001262039-17-000031:8k_2_02:14]
•Non-GAAP operating margin of 19%1

[0001262039-17-000031:8k_2_02:15]
•Cash flow from operations of $162.3 million

[0001262039-17-000031:8k_2_02:16]
•Free cash flow of $140.6 million1

[0001262039-17-000031:8k_2_02:17]
•Cash, cash equivalents and investments of $1.52 billion

[0001262039-17-000031:8k_2_02:18]
•Deferred revenue of $1.22 billion, up 30% year over year

[0001262039-17-000031:8k_2_02:19]
•$90.8 million in share repurchases

[0001262039-17-000031:8k_2_02:20]
SUNNYVALE, Calif. — October 26, 2017—Fortinet® (NASDAQ: FTNT), a global leader in high-performance cyber security solutions, today announced financial results for the third quarter ended September 30, 2017.

[0001262039-17-000031:8k_2_02:21]
“Our large installed base of network security customers offers us a foundation from which to sell our Fortinet Security Fabric, which is the broadest and most integrated security architecture in

[0001262039-17-000031:8k_2_02:22]
the industry,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “We expect that the expanding cloud security market, and the future of securing critical infrastructure and IoT technologies, will enable Fortinet to continue to grow at multiples of the market over the coming years.”

[0001262039-17-000031:8k_2_02:23]
Financial Details

[0001262039-17-000031:8k_2_02:24]
| • | Revenue: Total revenue was $374.2 million for the third quarter of 2017, an increase of 18% compared to $316.6 million in the same quarter of 2016. |

[0001262039-17-000031:8k_2_02:25]
| • | Product revenue was $137.1 million, an increase of 7% compared to $128.0 million in the same quarter of 2016. Service revenue was $237.1 million, an increase of 26% compared to $188.7 million in the same quarter of 2016. |

[0001262039-17-000031:8k_2_02:26]
| • | Billings1: Total billings were $431.7 million for the third quarter of 2017, an increase of 24% compared to $347.5 million in the same quarter of 2016. |

[0001262039-17-000031:8k_2_02:27]
| • | Deferred Revenue: Total deferred revenue was $1.22 billion as of September 30, 2017, compared to $934.8 million as of September 30, 2016, and $1.16 billion as of June 30, 2017. Short-term deferred revenue was $734.3 million as of September 30, 2017, compared to $582.1 million as of September 30, 2016. Long-term deferred revenue was $484.6 million as of September 30, 2017, compared to $352.6 million as of September 30, 2016. |

[0001262039-17-000031:8k_2_02:28]
| • | Cash, Cash Flow and Free Cash Flow1: As of September 30, 2017, cash, cash equivalents and investments were $1.52 billion, compared to $1.46 billion as of June 30, 2017. In the third quarter of 2017, cash flow from operations was $162.3 million compared to $76.1 million in the same quarter of 2016. Free cash flow was $140.6 million during the third quarter of 2017 compared to $70.2 million in the same quarter of 2016, an increase of 100%. |

[0001262039-17-000031:8k_2_02:29]
| • | Share Repurchase: During the third quarter of 2017, Fortinet repurchased 2.4 million shares of its common stock for a total purchase price of $90.8 million. In addition, in October 2017, Fortinet’s Board of Directors approved an increase of $400.0 million in the current share repurchase authorization, bringing the total authorization to $1.0 billion. |

[0001262039-17-000031:8k_2_02:30]
| • | GAAP Operating Income and Margin: GAAP operating income was $33.7 million for the third quarter of 2017, representing a GAAP operating margin of 9%. GAAP operating income was $5.5 million for the same quarter of 2016, representing a GAAP operating margin of 2%. |

[0001262039-17-000031:8k_2_02:31]
| • | Non-GAAP Operating Income1 and Margin1: Non-GAAP operating income was $70.0 million for the third quarter of 2017, representing a non-GAAP operating margin of 19%. Non-GAAP operating income was $45.9 million for the same quarter of 2016, representing a non-GAAP operating margin of 15%. |

[0001262039-17-000031:8k_2_02:32]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $26.6 million for the third quarter of 2017, compared to GAAP net income of $6.3 million for the same quarter of 2016. GAAP diluted net income per share was $0.15 for the third quarter of 2017, compared to GAAP diluted net income per share of $0.04 for the same quarter of 2016. |

[0001262039-17-000031:8k_2_02:33]
| • | Non-GAAP Net Income1 and Diluted Net Income Per Share1: Non-GAAP net income was $50.5 million for the third quarter of 2017, compared to non-GAAP net income of $32.2 million for the same quarter of 2016. Non-GAAP diluted net income per share was $0.28 for the third quarter of 2017, compared to $0.18 for the same quarter of 2016. |

[0001262039-17-000031:8k_2_02:34]
Guidance

[0001262039-17-000031:8k_2_02:35]
Fortinet offered the following guidance for the fourth quarter of 2017:

[0001262039-17-000031:8k_2_02:36]
| • | Revenue in the range of $404.0 million to $412.0 million |

[0001262039-17-000031:8k_2_02:37]
| • | Billings in the range of $510.0 million to $525.0 million |

[0001262039-17-000031:8k_2_02:38]
| • | Non-GAAP gross margin of 75% to 76% |

[0001262039-17-000031:8k_2_02:39]
| • | Non-GAAP operating margin in the range of 18% to 19% |

[0001262039-17-000031:8k_2_02:40]
| • | Diluted non-GAAP earnings per share of $0.28 to $0.30 |

[0001262039-17-000031:8k_2_02:41]
Fortinet also offered the following update to its guidance for the full year 2017:

[0001262039-17-000031:8k_2_02:42]
| • | Revenue in the range of $1.482 billion to $1.490 billion |

[0001262039-17-000031:8k_2_02:43]
| • | Billings in the range of $1.772 billion to $1.787 billion |

[0001262039-17-000031:8k_2_02:44]
| • | Non-GAAP gross margin of 75% |

[0001262039-17-000031:8k_2_02:45]
| • | Non-GAAP operating margin of 17% |

[0001262039-17-000031:8k_2_02:46]
| • | Diluted non-GAAP earnings per share of $1.00 to $1.02 |

[0001262039-17-000031:8k_2_02:47]
Guidance for non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled non-GAAP metrics to GAAP metrics because certain items that impact these measures are uncertain, out of our control and/or cannot be reasonably predicted. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-17-000031:8k_2_02:48]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-17-000031:8k_2_02:49]
Conference Call Details

[0001262039-17-000031:8k_2_02:50]
Fortinet will host a conference call today, October 26, 2017, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID #90458376. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through November 2, 2017, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 90458376.

[0001262039-17-000031:8k_2_02:51]
Following Fortinet’s financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 90554546. This follow-up call will be webcast live and accessible at http://investor.fortinet.com. A replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through November 2, 2017 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 90554546.

[0001262039-17-000031:8k_2_02:52]
About Fortinet (www.fortinet.com)

[0001262039-17-000031:8k_2_02:53]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless

[0001262039-17-000031:8k_2_02:54]
protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-17-000031:8k_2_02:55]
#          #          #

[0001262039-17-000031:8k_2_02:56]
Copyright © 2017 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiSIEM, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-17-000031:8k_2_02:57]
FTNT-F

[0001262039-17-000031:8k_2_02:58]
Forward-looking Statements

[0001262039-17-000031:8k_2_02:59]
Non-GAAP Financial Measures

[0001262039-17-000031:8k_2_02:60]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-17-000031:8k_2_02:61]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-17-000031:8k_2_02:62]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-17-000031:8k_2_02:63]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. However, free cash flow is not intended to represent our residual cash flow available for discretionary expenditures, since we may have other non-discretionary expenditures that are not deducted from the measure. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-17-000031:8k_2_02:64]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-17-000031:8k_2_02:65]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-17-000031:8k_2_02:66]
FORTINET, INC.

[0001262039-17-000031:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-17-000031:8k_2_02:68]
(Unaudited, in thousands)

[0001262039-17-000031:8k_2_02:69]
|  | September 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 905,794 |  |  | $ | 709,003 |  |
| Short-term investments | 369,961 |  |  | 376,522 |  |
| Accounts receivable—net | 257,999 |  |  | 312,998 |  |
| Inventory | 73,595 |  |  | 106,887 |  |
| Prepaid expenses and other current assets | 43,302 |  |  | 33,306 |  |
| Total current assets | 1,650,651 |  |  | 1,538,716 |  |
| LONG-TERM INVESTMENTS | 247,875 |  |  | 224,983 |  |
| DEFERRED TAX ASSETS | 204,721 |  |  | 182,745 |  |
| PROPERTY AND EQUIPMENT—NET | 239,891 |  |  | 137,249 |  |
| OTHER INTANGIBLE ASSETS—NET | 18,291 |  |  | 24,828 |  |
| GOODWILL | 14,553 |  |  | 14,553 |  |
| OTHER ASSETS | 19,297 |  |  | 16,867 |  |
| TOTAL ASSETS | $ | 2,395,279 |  |  | $ | 2,139,941 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 44,543 |  |  | $ | 56,732 |  |
| Accrued liabilities | 40,439 |  |  | 35,640 |  |
| Accrued payroll and compensation | 75,482 |  |  | 78,138 |  |
| Income taxes payable | 15,862 |  |  | 13,588 |  |
| Deferred revenue | 734,313 |  |  | 645,342 |  |
| Total current liabilities | 910,639 |  |  | 829,440 |  |
| DEFERRED REVENUE | 484,644 |  |  | 390,007 |  |
| INCOME TAX LIABILITIES | 87,993 |  |  | 68,551 |  |
| OTHER LIABILITIES | 9,778 |  |  | 14,262 |  |
| Total liabilities | 1,493,054 |  |  | 1,302,260 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 175 |  |  | 173 |  |
| Additional paid-in capital | 912,053 |  |  | 800,653 |  |
| Accumulated other comprehensive loss | (416 | ) |  | (765 | ) |
| Retained earnings (deficit) | (9,587 | ) |  | 37,620 |  |
| Total stockholders’ equity | 902,225 |  |  | 837,681 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,395,279 |  |  | $ | 2,139,941 |  |

[0001262039-17-000031:8k_2_02:70]
FORTINET, INC.

[0001262039-17-000031:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-17-000031:8k_2_02:72]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000031:8k_2_02:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 137,095 |  |  | $ | 127,972 |  |  | $ | 415,053 |  |  | $ | 389,185 |  |
| Service | 237,122 |  |  | 188,674 |  |  | 663,209 |  |  | 523,428 |  |
| Total revenue | 374,217 |  |  | 316,646 |  |  | 1,078,262 |  |  | 912,613 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 58,106 |  |  | 50,267 |  |  | 174,190 |  |  | 152,368 |  |
| Service 1 | 35,543 |  |  | 34,532 |  |  | 105,675 |  |  | 94,578 |  |
| Total cost of revenue | 93,649 |  |  | 84,799 |  |  | 279,865 |  |  | 246,946 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 78,989 |  |  | 77,705 |  |  | 240,863 |  |  | 236,817 |  |
| Service | 201,579 |  |  | 154,142 |  |  | 557,534 |  |  | 428,850 |  |
| Total gross profit | 280,568 |  |  | 231,847 |  |  | 798,397 |  |  | 665,667 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 53,486 |  |  | 47,239 |  |  | 155,840 |  |  | 137,495 |  |
| Sales and marketing 1 | 172,361 |  |  | 154,831 |  |  | 509,098 |  |  | 463,628 |  |
| General and administrative 1 | 21,025 |  |  | 22,006 |  |  | 65,513 |  |  | 63,629 |  |
| Restructuring charges | — |  |  | 2,283 |  |  | 340 |  |  | 3,164 |  |
| Total operating expenses | 246,872 |  |  | 226,359 |  |  | 730,791 |  |  | 667,916 |  |
| OPERATING INCOME (LOSS) | 33,696 |  |  | 5,488 |  |  | 67,606 |  |  | (2,249 | ) |
| INTEREST INCOME | 3,866 |  |  | 1,888 |  |  | 9,421 |  |  | 5,339 |  |
| OTHER INCOME (EXPENSE)—NET | 344 |  |  | (787 | ) |  | 1,889 |  |  | (3,449 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | 37,906 |  |  | 6,589 |  |  | 78,916 |  |  | (359 | ) |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 11,296 |  |  | 298 |  |  | 18,556 |  |  | (7,380 | ) |
| NET INCOME | $ | 26,610 |  |  | $ | 6,291 |  |  | $ | 60,360 |  |  | $ | 7,021 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | 0.34 |  |  | $ | 0.04 |  |
| Diluted | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | 0.34 |  |  | $ | 0.04 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 175,519 |  |  | 173,335 |  |  | 175,253 |  |  | 172,212 |  |
| Diluted | 178,973 |  |  | 177,938 |  |  | 178,987 |  |  | 176,046 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 314 |  |  | $ | 309 |  |  | $ | 1,039 |  |  | $ | 887 |  |
| Cost of service revenue | 2,371 |  |  | 2,238 |  |  | 7,154 |  |  | 6,495 |  |
| Research and development | 7,976 |  |  | 7,648 |  |  | 24,127 |  |  | 22,249 |  |
| Sales and marketing | 19,609 |  |  | 17,378 |  |  | 58,380 |  |  | 50,183 |  |
| General and administrative | 4,037 |  |  | 3,520 |  |  | 12,029 |  |  | 10,528 |  |
|  | $ | 34,307 |  |  | $ | 31,093 |  |  | $ | 102,729 |  |  | $ | 90,342 |  |

[0001262039-17-000031:8k_2_02:74]
FORTINET, INC.

[0001262039-17-000031:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-17-000031:8k_2_02:76]
(Unaudited, in thousands)

[0001262039-17-000031:8k_2_02:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Net income | $ | 26,610 |  |  | $ | 6,291 |  |  | $ | 60,360 |  |  | $ | 7,021 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Change in unrealized gains (losses) on investments | 172 |  |  | (879 | ) |  | 506 |  |  | 1,670 |  |
| Tax provision (benefit) related to change in unrealized gains (losses) on investments | 65 |  |  | (308 | ) |  | 157 |  |  | 584 |  |
| Other comprehensive income (loss) | 107 |  |  | (571 | ) |  | 349 |  |  | 1,086 |  |
| Comprehensive income | $ | 26,717 |  |  | $ | 5,720 |  |  | $ | 60,709 |  |  | $ | 8,107 |  |

[0001262039-17-000031:8k_2_02:78]
FORTINET, INC.

[0001262039-17-000031:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-17-000031:8k_2_02:80]
(Unaudited, in thousands)

[0001262039-17-000031:8k_2_02:81]
|  | Nine Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 60,360 |  |  | $ | 7,021 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 41,208 |  |  | 34,896 |  |
| Amortization of investment premiums | 2,125 |  |  | 3,828 |  |
| Stock-based compensation | 102,729 |  |  | 90,342 |  |
| Other non-cash items—net | 3,179 |  |  | 4,846 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 51,447 |  |  | 12,788 |  |
| Inventory | 17,687 |  |  | (24,555 | ) |
| Deferred tax assets | (22,133 | ) |  | (35,005 | ) |
| Prepaid expenses and other current assets | (9,599 | ) |  | 4,301 |  |
| Other assets | (360 | ) |  | (2,595 | ) |
| Accounts payable | (16,537 | ) |  | (1,584 | ) |
| Accrued liabilities | 8,052 |  |  | 598 |  |
| Accrued payroll and compensation | (3,531 | ) |  | 3,253 |  |
| Other liabilities | (3,830 | ) |  | (3,119 | ) |
| Deferred revenue | 184,350 |  |  | 142,867 |  |
| Income taxes payable | 21,716 |  |  | 6,789 |  |
| Net cash provided by operating activities | 436,863 |  |  | 244,671 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (359,569 | ) |  | (370,573 | ) |
| Sales of investments | 9,995 |  |  | 21,805 |  |
| Maturities of investments | 329,132 |  |  | 344,959 |  |
| Purchases of property and equipment | (121,641 | ) |  | (50,319 | ) |
| Payments made in connection with business acquisition, net of cash acquired | — |  |  | (22,087 | ) |
| Net cash used in investing activities | (142,083 | ) |  | (76,215 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 61,836 |  |  | 42,292 |  |
| Taxes paid related to net share settlement of equity awards | (35,869 | ) |  | (29,886 | ) |
| Repurchase of common stock | (123,956 | ) |  | (75,000 | ) |
| Payments of debt assumed in connection with business acquisition | — |  |  | (1,626 | ) |
| Net cash used in financing activities | (97,989 | ) |  | (64,220 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 196,791 |  |  | 104,236 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 709,003 |  |  | 543,277 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 905,794 |  |  | $ | 647,513 |  |

[0001262039-17-000031:8k_2_02:82]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-17-000031:8k_2_02:83]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000031:8k_2_02:84]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-17-000031:8k_2_02:85]
|  | Three Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
| Net cash provided by operating activities | $ | 162,343 |  |  | $ | 76,139 |  |
| Less purchases of property and equipment | (21,753 | ) |  | (5,920 | ) |
| Free cash flow | $ | 140,590 |  |  | $ | 70,219 |  |
| Net cash used in investing activities | $ | (28,914 | ) |  | $ | (6,798 | ) |
| Net cash used in financing activities | $ | (80,772 | ) |  | $ | (18,208 | ) |

[0001262039-17-000031:8k_2_02:86]
Reconciliation of GAAP operating income to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-17-000031:8k_2_02:87]
|  | Three Months Ended September 30, 2017 |  | Three Months Ended September 30, 2016 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 33,696 |  |  | $ | 36,344 |  | (a) | $ | 70,040 |  |  | $ | 5,488 |  |  | $ | 40,447 |  | (b) | $ | 45,935 |  |
| Operating margin | 9 | % |  |  |  | 19 | % |  | 2 | % |  |  |  | 15 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 34,307 |  |  |  |  |  |  | 31,093 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,037 |  |  |  |  |  |  | 2,839 |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  |  |  | 2,283 |  |  |  |
| ERP-related expenses |  |  | — |  |  |  |  |  |  | 4,060 |  |  |  |
| Inventory fair value adjustment amortization |  |  | — |  |  |  |  |  |  | 172 |  |  |  |
| Tax adjustment |  |  | (12,464 | ) | (c) |  |  |  |  | (14,555 | ) | (c) |  |
| Net income | $ | 26,610 |  |  | $ | 23,880 |  |  | $ | 50,490 |  |  | $ | 6,291 |  |  | $ | 25,892 |  |  | $ | 32,183 |  |
| Diluted net income per share | $ | 0.15 |  |  |  |  | $ | 0.28 |  |  | $ | 0.04 |  |  |  |  | $ | 0.18 |  |
| Shares used in diluted net income per share calculations | 178,973 |  |  |  |  | 178,973 |  |  | 177,938 |  |  |  |  | 177,938 |  |

[0001262039-17-000031:8k_2_02:88]
(a) To exclude $34.3 million of stock-based compensation and $2.0 million of amortization of acquired intangible assets in the three months ended September 30, 2017.

[0001262039-17-000031:8k_2_02:89]
(b) To exclude $31.1 million of stock-based compensation, $2.8 million of amortization of acquired intangible assets, $2.3 million of restructuring charges, $4.1 million of ERP-related expenses, and $0.2 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition in the three months ended September 30, 2016.

[0001262039-17-000031:8k_2_02:90]
(c) Non-GAAP financial information is adjusted to achieve an overall 32% percent and 33% percent effective tax rate in 2017 and 2016, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-17-000031:8k_2_02:91]
Billings Reconciliation

[0001262039-17-000031:8k_2_02:92]
|  | Three Months Ended |
|  | September 30, 2017 |  | September 30, 2016 |
| Total revenue | $ | 374,217 |  |  | $ | 316,646 |  |
| Add change in deferred revenue | 57,486 |  |  | 30,811 |  |
| Total billings | $ | 431,703 |  |  | $ | 347,457 |  |
