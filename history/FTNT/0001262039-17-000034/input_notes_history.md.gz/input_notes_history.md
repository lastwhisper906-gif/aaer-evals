# FTNT note change history — 0001262039-17-000027 → 0001262039-17-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-02):
[0001262039-17-000034:note_history:1]
The following table summarizes our future principal contractual obligations as of September 30, 2017 (in thousands):
  (was, 2017-08-02, similarity 0.9493):
[0001262039-17-000027:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2017 (in thousands):

- changed (2017-11-02):
[0001262039-17-000034:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 50,510 |  |  | $ | 3,953 |  |  | $ | 14,022 |  |  | $ | 10,732 |  |  | $ | 8,535 |  |  | $ | 4,557 |  |  | $ | 8,711 |  |
| Inventory purchase commitments | 93,664 |  |  | 89,417 |  |  | 4,247 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 67,253 |  |  | 40,854 |  |  | 19,651 |  |  | 4,311 |  |  | 2,132 |  |  | 302 |  |  | 3 |  |
| Total | $ | 211,427 |  |  | $ | 134,224 |  |  | $ | 37,920 |  |  | $ | 15,043 |  |  | $ | 10,667 |  |  | $ | 4,859 |  |  | $ | 8,714 |  |
  (was, 2017-08-02, similarity 0.9979):
[0001262039-17-000027:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 46,907 |  |  | $ | 7,099 |  |  | $ | 11,296 |  |  | $ | 8,668 |  |  | $ | 7,283 |  |  | $ | 4,122 |  |  | $ | 8,439 |  |
| Inventory purchase commitments | 67,237 |  |  | 65,905 |  |  | 1,332 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 63,228 |  |  | 53,250 |  |  | 7,057 |  |  | 2,278 |  |  | 533 |  |  | 110 |  |  | — |  |
| Total | $ | 177,372 |  |  | $ | 126,254 |  |  | $ | 19,685 |  |  | $ | 10,946 |  |  | $ | 7,816 |  |  | $ | 4,232 |  |  | $ | 8,439 |  |

- changed (2017-11-02):
[0001262039-17-000034:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $6.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Rent expense was $12.5 million and $14.7 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2017-08-02, similarity 0.8996):
[0001262039-17-000027:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $3.9 million and $4.6 million during the three months ended June 30, 2017 and June 30, 2016, respectively. Rent expense was $8.4 million and $8.5 million during the six months ended June 30, 2017 and June 30, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2017-11-02):
[0001262039-17-000034:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2017, we had $93.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2017-08-02, similarity 0.9904):
[0001262039-17-000027:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2017, we had $67.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2017-11-02):
[0001262039-17-000034:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2017, we had $67.3 million in other contractual commitments that may not be cancelable.  Included in other contractual commitments is $8.8 million related to the purchase of certain real estate adjacent to our corporate headquarters.
  (was, 2017-08-02, similarity 0.6852):
[0001262039-17-000027:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2017, we had $63.2 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate adjacent to our corporate headquarters amounting to $12.1 million, which we capitalized as part of property and equipment.

- changed (2017-11-02):
[0001262039-17-000034:note_history:6]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions, including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.
  (was, 2017-08-02, similarity 0.6585):
[0001262039-17-000027:note_history:6]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-02):
[0001262039-17-000034:note_history:7]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.
  (was, 2017-08-02, similarity 0.8084):
[0001262039-17-000027:note_history:7]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

- changed (2017-11-02):
[0001262039-17-000034:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”
  (was, 2017-08-02, similarity 0.913):
[0001262039-17-000027:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2017, except for changes to our policies related to business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”

- added (2017-11-02):
[0001262039-17-000034:note_history:9]
Business Combinations – Definition of a Business

- added (2017-11-02):
[0001262039-17-000034:note_history:10]
Share-Based Payment Accounting

- changed (2017-11-02):
[0001262039-17-000034:note_history:11]
In May 2017, the FASB issued ASU 2017-09—Compensation—Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modification accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.
  (was, 2017-08-02, similarity 0.9955):
[0001262039-17-000027:note_history:11]
In May 2017, the FASB issued ASU 2017-09—Compensation - Stock Compensation to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modifications accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We do not believe ASU 2017-09 will have a material impact on our consolidated financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:12]
Goodwill Impairment

- changed (2017-11-02):
[0001262039-17-000034:note_history:13]
In January 2017, the FASB issued ASU 2017-04—Intangibles—Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We early adopted ASU 2017-04 on October 1, 2017. The adoption did not have a material impact on our consolidated financial statements.
  (was, 2017-08-02, similarity 0.9388):
[0001262039-17-000027:note_history:13]
In January 2017, the FASB issued ASU 2017-04—Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We intend to adopt ASU 2017-04 in the fourth quarter of 2017. We do not believe that ASU 2017-04 will have a material impact on our consolidated financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:14]
Income Taxes – Intra-Entity Asset Transfers

- changed (2017-11-02):
[0001262039-17-000034:note_history:15]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of ASU 2016-16 on our consolidated financial statements.
  (was, 2017-08-02, similarity 0.9878):
[0001262039-17-000027:note_history:15]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:16]
Financial Instruments – Credit Losses

- changed (2017-11-02):
[0001262039-17-000034:note_history:17]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. Based on our current accounts receivable portfolio, we do not believe ASU 2016-13 will have a material impact on our consolidated financial statements.
  (was, 2017-08-02, similarity 0.841):
[0001262039-17-000027:note_history:17]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of adopting ASU 2016-13 on our consolidated financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:18]
Leases

- changed (2017-11-02):
[0001262039-17-000034:note_history:19]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the notes to consolidated financial statements include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.
  (was, 2017-08-02, similarity 0.631):
[0001262039-17-000027:note_history:19]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. Previously, we had estimated the amount could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the footnotes to include more details on our leases, significant judgments and lease-related amounts recognized in the financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:20]
Financial Instruments – Recognition and Measurement

- added (2017-11-02):
[0001262039-17-000034:note_history:21]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception will apply to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 is effective for our cost-method investments beginning on January 1, 2018 on a prospective basis. The adoption of ASU 2016-01 will result in the adjustment to the carrying amount when the cost-method investees complete a financing round subsequent to adoption date.

- added (2017-11-02):
[0001262039-17-000034:note_history:22]
Revenue Recognition

- added (2017-11-02):
[0001262039-17-000034:note_history:23]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 will be effective for us beginning January 1, 2018. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We will adopt the standard using the modified retrospective method and apply the standard to contracts that are not completed as of January 1, 2018, and recognize the cumulative effect of initially applying the standard as an adjustment to the opening balance of retained earnings.

- added (2017-11-02):
[0001262039-17-000034:note_history:24]
We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances and FortiGuard and FortiCare subscription services to be substantially unchanged on an ongoing basis. We believe that the acceleration of revenue and associated cost of sales to certain channel partners which are currently accounted for only once the product is sold through to the end-customer, and the allocation of revenue related to software due to the removal of the residual method will not have a significant impact on our financial statements.

- added (2017-11-02):
[0001262039-17-000034:note_history:25]
We expect to expand our financial statement disclosures, which may include more details on our disaggregation of revenue, performance obligations, contract balances and costs to obtain a contract, as well as any significant judgments. We are in the process of documenting process changes, implementing required changes in our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing, which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09, along with industry trends until the adoption date.

- removed (2017-11-02):
[0001262039-17-000027:note_history:26]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for us beginning January 1, 2018.

- removed (2017-11-02):
[0001262039-17-000027:note_history:27]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. We have substantially completed our analysis of historical contracts and believe that the quantitative impact on revenue in our consolidated financial statements is not material. We expect the pattern of revenue recognition from the sales of our FortiGate and other appliances, FortiGuard security subscription services and FortiCare technical support services to be substantially unchanged on an ongoing basis. Further, we do not expect that the acceleration of revenue and associated cost of sales to certain channel partners, which are currently accounted for only once the product is sold through to the end-customer, to have a significant impact upon adoption. We expect to select the transition method for adoption in the third quarter of 2017.

- removed (2017-11-02):
[0001262039-17-000027:note_history:28]
We expect to expand our financial statement disclosures which may include more details on our disaggregation of revenue, performance obligations, contract balances, costs to obtain a contract, as well as any significant judgments. We are in the process of assessing the appropriate changes to our business processes, upgrading our systems and developing new controls to support recognition and disclosure under ASU 2014-09. Reviews are ongoing which may alter our conclusions and the anticipated financial impact. We will continue to assess the impact of ASU 2014-09 until the adoption date.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-11-02):
[0001262039-17-000034:note_history:29]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended September 30, 2017 and September 30, 2016, respectively. Expenses for legal services provided by the law firm were $0.9 million and $0.3 million during the nine months ended September 30, 2017 and September 30, 2016, respectively. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of September 30, 2017 and December 31, 2016, respectively.
  (was, 2017-08-02, similarity 0.7083):
[0001262039-17-000027:note_history:29]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.4 million and $0.1 million during the three months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the three months ended June 30, 2017 and 2016. Expenses for legal services provided by the law firm were $0.5 million and $0.4 million during the six months ended June 30, 2017 and June 30, 2016, respectively. No contingent fees were incurred in the six months ended June 30, 2017. Of the $0.4 million legal expenses incurred in the six months ended June 30, 2016, $0.2 million were incurred under contingent fee arrangements. Amounts due and payable to the law firm were $0.5 million and $0.1 million as of June 30, 2017 and December 31, 2016, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-11-02):
[0001262039-17-000034:note_history:30]
In October 2017, our board of directors approved a $400.0 million increase to authorized stock repurchases under the Repurchase Program, bringing the aggregate amount authorized to be repurchased to $1.0 billion.

- removed (2017-11-02):
[0001262039-17-000027:note_history:31]
In July 2017, our Board of Directors authorized a $300.0 million increase to the 2016 Repurchase Program, bringing the amount authorized to be repurchased to $600.0 million, and extended the 2016 Repurchase Program until January 31, 2019.
