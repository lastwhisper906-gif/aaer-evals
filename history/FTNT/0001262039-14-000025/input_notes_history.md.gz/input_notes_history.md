# FTNT note change history — 0001262039-13-000055 → 0001262039-14-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-05-07):
[0001262039-14-000025:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2014 (in thousands):

- added (2014-05-07):
[0001262039-14-000025:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 31,592 |  |  | $ | 6,543 |  |  | $ | 6,547 |  |  | $ | 5,385 |  |  | $ | 4,639 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |
| Less: Sublease rental income | 1,040 |  |  | 585 |  |  | 455 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 30,552 |  |  | 5,958 |  |  | 6,092 |  |  | 5,385 |  |  | 4,639 |  |  | 3,649 |  |  | 4,829 |  |
| Purchase commitments | 38,880 |  |  | 38,880 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contract commitments | 24,182 |  |  | 18,502 |  |  | 3,914 |  |  | 889 |  |  | 877 |  |  | — |  |  | — |  |
| Total | $ | 93,614 |  |  | $ | 63,340 |  |  | $ | 10,006 |  |  | $ | 6,274 |  |  | $ | 5,516 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |

- added (2014-05-07):
[0001262039-14-000025:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Future minimum payments under the non-cancelable operating leases totaled $31.6 million as of March 31, 2014. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.7 million and $2.3 million during the three months ended March 31, 2014 and March 31, 2013, respectively.

- changed (2014-05-07):
[0001262039-14-000025:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2014, we had $38.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2013-11-05, similarity 0.8513):
[0001262039-13-000055:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we issue non-cancelable purchase orders to some of our independent contract manufacturers. As of September 30, 2013, we had $46.6 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2014-05-07):
[0001262039-14-000025:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2014, we had $24.2 million in other purchase commitments.
  (was, 2013-11-05, similarity 0.9735):
[0001262039-13-000055:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2013, we had $10.2 million in other purchase commitments.

- changed (2014-05-07):
[0001262039-14-000025:note_history:6]
Warranties—Accrued warranty activities are summarized as follows (in thousands):
  (was, 2013-11-05, similarity 0.7974):
[0001262039-13-000055:note_history:6]
Accrued warranty activities are summarized as follows ($ amounts in 000’s):

- added (2014-05-07):
[0001262039-14-000025:note_history:7]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (756 | ) |  | (759 | ) |
| Provision for warranty for the period, including warranty liabilities assumed in connection with an acquisition | 837 |  |  | 674 |  |
| Changes in prior period estimates | (313 | ) |  | 60 |  |
| Accrued warranty balance—end of the period | $ | 2,805 |  |  | $ | 2,284 |  |

- changed (2014-05-07):
[0001262039-14-000025:note_history:8]
Litigation—We are involved in disputes, litigation, and other legal actions. We are defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2013-11-05, similarity 0.9566):
[0001262039-13-000055:note_history:8]
Litigation—We are involved in disputes, litigation, and other legal actions, including, but not limited to, the matters described below. We are  defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. Unless otherwise noted below, during the period presented, we have not: recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- changed (2014-05-07):
[0001262039-14-000025:note_history:9]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.
  (was, 2013-11-05, similarity 0.7258):
[0001262039-13-000055:note_history:9]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no claims under such indemnification provisions.

- removed (2014-05-07):
[0001262039-13-000055:note_history:10]
Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. Rent expense was $2.4 million and $2.1 million for the three months ended September 30, 2013 and September 30, 2012, respectively. Rent expense was $7.1 million and $6.5 million for the nine months ended September 30, 2013 and September 30, 2012, respectively. Rent expense is recognized using the straight-line method over the term of the lease. The aggregate future non-cancelable minimum rental payments on operating leases as of September 30, 2013 are as follows ($ amounts in 000’s):

- removed (2014-05-07):
[0001262039-13-000055:note_history:11]
|  | RentalPayment |
| Fiscal Years: |  |
| 2013 (remainder) | 2,675 |  |
| 2014 | 7,715 |  |
| 2015 | 5,342 |  |
| 2016 | 4,279 |  |
| 2017 | 3,738 |  |
| Thereafter | 7,779 |  |
| Total | 31,528 |  |

- removed (2014-05-07):
[0001262039-13-000055:note_history:12]
Warranties—We generally provide a 1-year warranty on hardware products and a 90-day warranty on software.

- removed (2014-05-07):
[0001262039-13-000055:note_history:13]
|  | For The Nine Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Accrued warranty balance—beginning of the period | 2,309 |  |  | 2,582 |  |
| Warranty costs incurred | (2,670 | ) |  | (1,843 | ) |
| Provision for warranty, including warranty assumed from Xtera | 3,134 |  |  | 1,604 |  |
| Changes in prior period estimates | 274 |  |  | (307 | ) |
| Accrued warranty balance—end of the period | 3,047 |  |  | 2,036 |  |

- removed (2014-05-07):
[0001262039-13-000055:note_history:14]
In July 2010, Network Protection Sciences, LLC (“NPS”), a non-practicing entity, filed a complaint in the United States District Court for the Eastern District of Texas alleging patent infringement by us and other defendants. In December 2011, the United States District Court for the Eastern District of Texas ordered the case to be transferred to the Northern District of California. In June 2012, the United States District Court for the Northern District of California dismissed the other defendants for misjoinder, and the case thereafter proceeded with Fortinet as the sole defendant. Between June and August 2013, we filed a number of pretrial motions with the Court.  As a result of those motions, the Court found that NPS had engaged in litigation misconduct. The Court also granted our motion to strike NPS’s expert report on the issue of damages. Shortly thereafter, in September 2013, NPS agreed to abandon the case and we did not make any payments related to this case. NPS and its principals furthermore agreed not to sue us on related patents. The litigation related to NPS is no longer material to us.

- removed (2014-05-07):
[0001262039-13-000055:note_history:15]
In June 2012, we received a letter from SRI International, (“SRI”) claiming that we infringed certain SRI patents.  Subsequently, we filed a complaint in the United States District Court for the Northern District of California seeking declaratory relief and a judgment that the SRI patents were invalid, unenforceable and not infringed by any of our products or services. The case is proceeding in the United States District Court for the Northern District of California. The case is currently in the early stages, and we have determined that, as of this time, there is not a reasonable possibility that a material loss has been incurred.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001262039-14-000025:note_history:16]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, except as otherwise noted, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.
  (was, 2013-11-05, similarity 0.6024):
[0001262039-13-000055:note_history:16]
The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) for interim financial information as well as the instructions to Form 10-Q and the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2012, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on February 27, 2013. In the opinion of management, all adjustments, which only includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2013 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2012 are derived from the audited consolidated financial statements for the year ended December 31, 2012.

- added (2014-05-07):
[0001262039-14-000025:note_history:17]
There have been no material changes to our significant accounting policies for the three months ended March 31, 2014. During the quarter we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements and furniture and fixtures.

- added (2014-05-07):
[0001262039-14-000025:note_history:18]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

- added (2014-05-07):
[0001262039-14-000025:note_history:19]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

- added (2014-05-07):
[0001262039-14-000025:note_history:20]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment, software and tooling | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

- added (2014-05-07):
[0001262039-14-000025:note_history:21]
Effective March 2014, we moved into our new corporate headquarters. The useful life of building improvements placed into service during the three months ended March 31, 2014, in association with our new corporate headquarters is estimated to be 20 years. The useful life of furniture and fixtures now ranges from 3 to 5 years as we placed new furniture and fixtures into service at the new corporate headquarters.

- added (2014-05-07):
[0001262039-14-000025:note_history:22]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the Condensed Consolidated Statements of Operations. The combined amounts are being presented as Services and other revenue in the Condensed Consolidated Statements of Operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material.

- removed (2014-05-07):
[0001262039-13-000055:note_history:23]
Basis of Presentation and Preparation

- removed (2014-05-07):
[0001262039-13-000055:note_history:24]
During the three and nine months ended September 30, 2013, we recorded a non-recurring out-of-period adjustment of  $3.0 million to correct the presentation on our condensed consolidated balance sheets relating to our repurchase of 1,409,264 shares during the fiscal year ended December 31, 2009. This reclassification adjustment resulted in a decrease to the outstanding treasury stock balance and a corresponding decrease to additional paid-in capital. We believe the impact of the adjustment is not material to the current or prior fiscal periods. The shares that we repurchased in 2009 were retired immediately after repurchase. There was no outstanding treasury stock balance at September 30, 2013.

- removed (2014-05-07):
[0001262039-13-000055:note_history:25]
There have been no material changes in our significant accounting policies as of and for the three and nine months ended September 30, 2013, as compared to the significant accounting policies described in the Form 10-K, except for the inclusion of policies related to goodwill and other indefinite-lived assets, long-term investments, and stock-based compensation expense pertaining to performance stock units (“PSUs”).

- removed (2014-05-07):
[0001262039-13-000055:note_history:26]
Goodwill and other indefinite-lived intangible assets

- removed (2014-05-07):
[0001262039-13-000055:note_history:27]
Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill and other indefinite-lived intangible assets such as in-process research and development acquired in a business combination are not amortized, but instead tested for impairment at least annually during the fourth quarter. We perform our annual goodwill impairment analysis at the reporting unit level. As of September 30, 2013, we had one reporting unit.

- removed (2014-05-07):
[0001262039-13-000055:note_history:28]
In reviewing goodwill for impairment we have the option to (i) assess qualitative factors to determine whether it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount or (ii) bypass the qualitative assessment and proceed directly to a quantitative assessment. If we opt to perform a qualitative assessment, the factors we may review include, but are not limited to (a) macroeconomic conditions; (b) industry and market considerations; (c) cost factors; (d) overall financial performance; (e) other relevant entity-specific events such as changes in management, strategy, customers, or litigation; (f) events affecting the reporting unit; or (g) or sustained decrease in share price. If we believe, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. A quantitative assessment utilizes a two-step process. In the first step, the fair value of the reporting unit is determined, and is compared against its carrying amount, including goodwill. We consider a combination of an income-based approach using projected discounted cash flows and a market-based approach using multiples of comparable companies to determine the fair value. The fair value of the reporting unit is estimated using significant judgment based on a combination of the income and the market approaches. Under the income approach, we estimate fair value of the reporting unit based on the present value of forecasted future cash flows that the reporting unit is expected to generate over its remaining life. Under the market approach, we estimate fair value of our reporting unit based on an analysis that compares the value of the reporting unit to values of other companies in similar lines of business. If the fair value of the reporting unit does not exceed its carrying value, then we perform the second step to measure the amount of impairment loss. The amount of impairment is determined by comparing the implied fair value of reporting unit goodwill to the carrying value of the goodwill. When the carrying value of the reporting unit's goodwill exceeds its implied fair value, we record an impairment loss equal to the difference.

- removed (2014-05-07):
[0001262039-13-000055:note_history:29]
Determining the fair value of the reporting unit requires us to make judgments and involves the use of significant estimates and assumptions. These estimates and assumptions include revenue growth rates and operating margins used to calculate projected future cash flows, operating trends, risk-adjusted discount rates, future economic and market conditions and determination of appropriate market comparables. We base our fair value estimates on assumptions we believe to be reasonable but that are unpredictable and inherently uncertain. Actual future results may differ from those estimates. We may also test goodwill and other intangible assets for impairment between annual tests in the presence of impairment indicators. Acquired in-process research and development assets are classified as indefinite-lived intangible assets until the successful completion or abandonment of the associated research and development efforts. Upon successful completion of the associated research and development efforts, the useful life of the asset is determined and the asset is amortized over its useful life. If the associated research and development efforts are abandoned, an impairment loss is recognized for the carrying value of the related asset.

- removed (2014-05-07):
[0001262039-13-000055:note_history:30]
Long-term investments

- removed (2014-05-07):
[0001262039-13-000055:note_history:31]
Investments in privately held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in Long-term investments in the consolidated balance sheets and are accounted for under the cost method. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts based on information provided by these privately held companies. If it is determined that an other-than-temporary decline exists in an equity security, we write down the investment to its fair value and record the related impairment as an investment loss in our consolidated statements of operations. As of September 30, 2013, we only have one investment of $2.0 million in a privately-held company accounted for under the cost method.

- removed (2014-05-07):
[0001262039-13-000055:note_history:32]
Stock-Based Compensation Expense - Performance Stock Units

- removed (2014-05-07):
[0001262039-13-000055:note_history:33]
PSUs are restricted stock units (“RSUs”) that contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period.  The fair value of a PSU is calculated using the Monte Carlo simulation model on the grant date and is based on the market price of our common stock on the grant date modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions.

- removed (2014-05-07):
[0001262039-13-000055:note_history:34]
Certain prior period amounts have been combined on the condensed consolidated balance sheets and statements of cash flows to conform to the current period presentation.

- removed (2014-05-07):
[0001262039-13-000055:note_history:35]
Recent Accounting Pronouncements

- removed (2014-05-07):
[0001262039-13-000055:note_history:36]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-02, Comprehensive Income (Topic 220)—Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (“ASU 2013-02”). ASU 2013-02 requires an entity to report the effect of significant reclassifications out of accumulated other comprehensive income on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. We adopted ASU 2013-02 on January 1, 2013, and presented the effects within Note 16, Accumulated Other Comprehensive Income.

- removed (2014-05-07):
[0001262039-13-000055:note_history:37]
In July 2013, the FASB issued ASU No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”). ASU 2013-11 provides guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, similar tax loss, or tax credit carryforward exists. This new standard requires the netting of unrecognized tax benefits (“UTBs”) against a deferred tax asset for a loss or other carryforward that would apply in settlement of the uncertain tax positions. UTBs will be netted against all available same-jurisdiction loss or other tax carryforwards that would be utilized, rather than only against carryforwards that are created by the UTBs. ASU 2013-11 will be effective for us beginning in the first quarter of fiscal 2014. Early adoption is permitted. Since ASU 2013-11 only impacts financial statement disclosure requirements for unrecognized tax benefits, we do not expect its adoption to have an impact on our financial position or results of operations.
