# FTNT 8-K — 0001262039-14-000021 filed 2014-04-23

## item codes, every 8-K on or before 2014-05-07

- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2014-05-07

- none on or before 2014-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-14-000021:8k_2_02:1]
EX-99.1
2
ftntq1-2014ex991.htm
PRESS RELEASE

[0001262039-14-000021:8k_2_02:2]
FTNT Q1-2014 EX 99.1

[0001262039-14-000021:8k_2_02:3]
Press Release

[0001262039-14-000021:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Rick Popko |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-486-7853 |
| mspolver@fortinet.com |  | rpopko@fortinet.com |

[0001262039-14-000021:8k_2_02:5]
Fortinet Reports Strong First Quarter 2014 Financial Results:  Billings Grow 26% and Revenues Grow 24% year-over-year

[0001262039-14-000021:8k_2_02:6]
•Billings of $187.6 million, up 26% year over year1

[0001262039-14-000021:8k_2_02:7]
•Revenues of $168.9 million, up 24% year over year

[0001262039-14-000021:8k_2_02:8]
•GAAP diluted net income per share of $0.05

[0001262039-14-000021:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.111

[0001262039-14-000021:8k_2_02:10]
•Cash flow from operations of $60.9 million

[0001262039-14-000021:8k_2_02:11]
| • | Free cash flow of $49.6 million1 |

[0001262039-14-000021:8k_2_02:12]
| • | Cash, cash equivalents and investments of $888.3 million2, with no debt |

[0001262039-14-000021:8k_2_02:13]
SUNNYVALE, Calif. - April 23, 2014 - Fortinet® (NASDAQ: FTNT), a global leader in high-performance network security, today announced financial results for the first quarter ended March 31, 2014.

[0001262039-14-000021:8k_2_02:14]
“The first quarter marked a strong start to the year, highlighted by billings, revenue, and operating profitability, each of which exceeded expectations,” said Ken Xie, founder, chairman, and chief executive officer.  “Fortinet’s business momentum is being driven by our focused execution and the strength, applicability, and breadth of our technology, as evidenced by the demand for recently-introduced products such as the FortiGate-3700D and 1500D high speed, low latency next-generation enterprise data center security appliances. Given the leverage we have seen from recent growth initiatives, we remain committed to investing for growth and delivering security innovation to further extend our market share and leadership position globally.”

[0001262039-14-000021:8k_2_02:15]
Financial Highlights for the First Quarter of 2014

[0001262039-14-000021:8k_2_02:16]
| • | Billings1: Total billings were $187.6 million for the first quarter of 2014, an increase of 26% compared to $148.5 million in the same quarter of 2013. |

[0001262039-14-000021:8k_2_02:17]
| • | Revenue3: Total revenue was $168.9 million for the first quarter of 2014, an increase of 24% compared to $135.8 million in the same quarter of 2013. Within total revenue, |

[0001262039-14-000021:8k_2_02:18]
product revenue was $76.8 million, an increase of 32% compared to the same quarter of 2013.  Services and other revenue was $92.2 million, an increase of 18% compared to the same quarter of 2013.

[0001262039-14-000021:8k_2_02:19]
| • | Deferred Revenue: Deferred revenue was $451.3 million as of March 31, 2014, an increase of 20% compared to deferred revenue of $376.4 million as of March 31, 2013, and an increase of $18.7 million from $432.6 million as of December 31, 2013. |

[0001262039-14-000021:8k_2_02:20]
| • | Cash and Cash Flow2: As of March 31, 2014, cash, cash equivalents and investments were $888.3 million, compared to $843.0 million as of December 31, 2013. In the first quarter of 2014, cash flow from operations was $60.9 million and free cash flow1 was $49.6 million. Cash flow from operations and free cash flow1 during the first quarter of 2014 included payment to Fortinet of $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement. |

[0001262039-14-000021:8k_2_02:21]
| • | GAAP Operating Income: GAAP operating income was $12.8 million for the first quarter of 2014, representing a GAAP operating margin of 8%. GAAP operating income was $15.4 million for the same quarter of 2013, representing a GAAP operating margin of 11%. |

[0001262039-14-000021:8k_2_02:22]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $8.4 million for the first quarter of 2014, based on a 39% effective tax rate for the quarter. This compares to GAAP net income of $12.2 million for the same quarter of 2013, based on a 28% effective tax rate for the quarter. GAAP diluted net income per share was $0.05 for the first quarter of 2014, based on 168.1 million weighted-average diluted shares outstanding, compared to $0.07 for the same quarter of 2013, based on 167.8 million weighted-average diluted shares outstanding. |

[0001262039-14-000021:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $26.3 million for the first quarter of 2014, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $25.0 million for the same quarter of 2013, representing a non-GAAP operating margin of 18%. |

[0001262039-14-000021:8k_2_02:24]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $18.2 million for the first quarter of 2014, based on a 33% effective tax rate for the quarter. Non-GAAP net income for the same quarter of 2013 was $17.8 million, based on a 33% effective tax rate. Non-GAAP diluted net income per share was $0.11 for the first quarter of 2014 based on 168.1 million weighted-average diluted shares outstanding, compared to $0.11 for the same quarter of 2013, based on 167.8 million weighted-average diluted shares outstanding. |

[0001262039-14-000021:8k_2_02:25]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-14-000021:8k_2_02:26]
2 During the first quarter of fiscal 2014, the Company repurchased $7.5 million of its common stock under its share repurchase program, all of which was paid in the first quarter of fiscal 2014 except for $0.7 million which was settled and paid in April 2014.

[0001262039-14-000021:8k_2_02:27]
3 Beginning in the first quarter of 2014, the Company has combined Ratable and other revenue with Services revenue to present the combined amounts as Services and other revenue in the Condensed Consolidated Statements of Operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation. The Company

[0001262039-14-000021:8k_2_02:28]
believes the Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material.

[0001262039-14-000021:8k_2_02:29]
Conference Call Details

[0001262039-14-000021:8k_2_02:30]
Fortinet will host a conference call today, April 23, 2014, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results.  To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 27164378. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through April 30, 2014, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 27164378.

[0001262039-14-000021:8k_2_02:31]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 27166356. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through April 30, 2014 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 27166356.

[0001262039-14-000021:8k_2_02:32]
About Fortinet

[0001262039-14-000021:8k_2_02:33]
Fortinet (NASDAQ: FTNT) is a worldwide provider of network security appliances and a market leader in unified threat management (UTM). Our products and subscription services provide broad, integrated and high-performance protection against dynamic security threats while simplifying the IT security infrastructure. Our customers include enterprises, service providers and government entities worldwide, including the majority of the 2013 Fortune Global 100. Fortinet's flagship FortiGate product delivers ASIC-accelerated performance and integrates multiple layers of security designed to help protect against application and network threats. Fortinet's broad product line goes beyond UTM to help secure the extended enterprise -- from endpoints, to the perimeter and the core, including databases and applications. Fortinet is headquartered in Sunnyvale, Calif., with offices around the world.

[0001262039-14-000021:8k_2_02:34]
#          #          #

[0001262039-14-000021:8k_2_02:35]
Copyright © 2014 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-14-000021:8k_2_02:36]
FTNT-F

[0001262039-14-000021:8k_2_02:37]
Forward-looking Statements

[0001262039-14-000021:8k_2_02:38]
Non-GAAP Financial Measures

[0001262039-14-000021:8k_2_02:39]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-14-000021:8k_2_02:40]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-14-000021:8k_2_02:41]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically represented a majority of the quarterly

[0001262039-14-000021:8k_2_02:42]
revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from other companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP.

[0001262039-14-000021:8k_2_02:43]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, and strengthening the balance sheet. Analysis of free cash flow facilitates management's comparisons of our operating results to competitors' operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash balance from operations for the period because it excludes cash used for capital expenditures. Management compensates for this limitation by providing information about our capital expenditures on the face of the cash flow statement and under the caption “Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-14-000021:8k_2_02:44]
Non-GAAP operating income and operating margin. Beginning in the first quarter of fiscal 2014, we define non-GAAP operating income as operating income plus stock-based compensation expense, acquisition related charges, including amortization, impairments and other purchase accounting adjustments, and when applicable, any other significant non-recurring items such as significant litigation settlements in a given quarter. Prior period amounts have been adjusted to conform to the current period presentation. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition related charges, including amortization, impairments and other purchase accounting adjustments, and when applicable, any other significant non-recurring items  so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes stock-based compensation expense and acquisition-related charges and any other significant non-recurring items. Stock-based compensation expense has been and will continue to be for the foreseeable future a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees' compensation and impacts their performance. Third, the components of the costs that we exclude in our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-14-000021:8k_2_02:45]
Non-GAAP net income and diluted net income per share. Beginning in the first quarter of fiscal 2014, we define non-GAAP net income as net income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring charges, such as significant litigation settlements, adjusted for the impact of the tax adjustment, if any, required to achieve the effective tax rate on a pro forma basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided

[0001262039-14-000021:8k_2_02:46]
by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required to achieve the effective tax rate on a pro forma basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. Our estimated tax rate on non-GAAP income is determined annually and may be adjusted during the year to take into account events or trends that we believe materially impact the estimated annual rate including, but not limited to, significant changes resulting from tax legislation, material changes in the geographic mix of revenues and expenses and other significant events.  The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-14-000021:8k_2_02:47]
Changes to non-GAAP financial measures.  Beginning in the first quarter of 2014, we will no longer adjust our GAAP results for insignificant non-recurring items. As a result, insignificant patent sale, license or settlement income amounts are no longer being excluded from our non-GAAP financial measures. All prior amounts reported in our earnings release have been adjusted to conform to the current period presentation. These changes do not restate or amend any previously published financial results.

[0001262039-14-000021:8k_2_02:48]
FORTINET, INC.

[0001262039-14-000021:8k_2_02:49]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-14-000021:8k_2_02:50]
(Unaudited, in thousands)

[0001262039-14-000021:8k_2_02:51]
|  | March 31, 2014 |  | December 31, 2013 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 172,968 |  |  | $ | 115,873 |  |
| Short-term investments | 388,083 |  |  | 375,497 |  |
| Accounts receivable—Net | 111,489 |  |  | 130,471 |  |
| Inventory | 43,294 |  |  | 48,672 |  |
| Deferred tax assets | 50,956 |  |  | 50,980 |  |
| Prepaid expenses and other current assets | 14,670 |  |  | 14,053 |  |
| Total current assets | 781,460 |  |  | 735,546 |  |
| PROPERTY AND EQUIPMENT—Net | 47,474 |  |  | 36,652 |  |
| DEFERRED TAX ASSETS—Non-current | 30,058 |  |  | 30,058 |  |
| LONG-TERM INVESTMENTS | 327,263 |  |  | 351,675 |  |
| GOODWILL | 2,824 |  |  | 2,872 |  |
| OTHER INTANGIBLE ASSETS—Net | 6,218 |  |  | 6,841 |  |
| OTHER ASSETS | 4,734 |  |  | 4,820 |  |
| TOTAL ASSETS | $ | 1,200,031 |  |  | $ | 1,168,464 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable | $ | 27,603 |  |  | $ | 35,599 |  |
| Accrued liabilities | 25,716 |  |  | 27,380 |  |
| Accrued payroll and compensation | 35,845 |  |  | 34,997 |  |
| Income taxes payable | — |  |  | 21,421 |  |
| Deferred revenue | 305,702 |  |  | 293,664 |  |
| Total current liabilities | 394,866 |  |  | 413,061 |  |
| DEFERRED REVENUE—Non-current | 145,601 |  |  | 138,964 |  |
| INCOME TAXES PAYABLE—Non-current | 32,860 |  |  | 30,208 |  |
| OTHER LIABILITIES | 16,610 |  |  | 471 |  |
| Total liabilities | 589,937 |  |  | 582,704 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |  |
| Common stock | 163 |  |  | 161 |  |
| Additional paid-in capital | 486,174 |  |  | 462,644 |  |
| Accumulated other comprehensive income | 77 |  |  | 1,092 |  |
| Retained earnings | 123,680 |  |  | 121,863 |  |
| Total stockholders' equity | 610,094 |  |  | 585,760 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS' EQUITY | $ | 1,200,031 |  |  | $ | 1,168,464 |  |

[0001262039-14-000021:8k_2_02:52]
FORTINET, INC.

[0001262039-14-000021:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-14-000021:8k_2_02:54]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000021:8k_2_02:55]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| REVENUE: |  |  |  |
| Product | $ | 76,765 |  |  | $ | 57,950 |  |
| Services and other | 92,184 |  |  | 77,870 |  |
| Total revenue | 168,949 |  |  | 135,820 |  |
| COST OF REVENUE: |  |  |  |
| Product 1 | 32,139 |  |  | 22,958 |  |
| Services and other1 | 18,604 |  |  | 16,170 |  |
| Total cost of revenue | 50,743 |  |  | 39,128 |  |
| GROSS PROFIT: |  |  |  |
| Product | 44,626 |  |  | 34,992 |  |
| Services and other | 73,580 |  |  | 61,700 |  |
| Total gross profit | 118,206 |  |  | 96,692 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development 1 | 29,055 |  |  | 23,334 |  |
| Sales and marketing 1 | 67,326 |  |  | 49,976 |  |
| General and administrative 1 | 9,010 |  |  | 7,991 |  |
| Total operating expenses | 105,391 |  |  | 81,301 |  |
| OPERATING INCOME | 12,815 |  |  | 15,391 |  |
| INTEREST INCOME | 1,333 |  |  | 1,369 |  |
| OTHER (EXPENSE) INCOME—Net | (389 | ) |  | 215 |  |
| INCOME BEFORE INCOME TAXES | 13,759 |  |  | 16,975 |  |
| PROVISION FOR INCOME TAXES | 5,366 |  |  | 4,726 |  |
| NET INCOME | $ | 8,393 |  |  | $ | 12,249 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.05 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.05 |  |  | $ | 0.07 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 162,391 |  |  | 161,282 |  |
| Diluted | 168,114 |  |  | 167,823 |  |
| 1 Includes stock-based compensation expense as follows: |  |  |  |
| Cost of product revenue | $ | 113 |  |  | $ | 90 |  |
| Cost of services and other revenue | 1,329 |  |  | 1,020 |  |
| Research and development | 3,882 |  |  | 2,766 |  |
| Sales and marketing | 5,746 |  |  | 4,118 |  |
| General and administrative | 1,860 |  |  | 1,305 |  |
|  | $ | 12,930 |  |  | $ | 9,299 |  |

[0001262039-14-000021:8k_2_02:56]
FORTINET, INC.

[0001262039-14-000021:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-14-000021:8k_2_02:58]
(Unaudited, in thousands)

[0001262039-14-000021:8k_2_02:59]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Net income | $ | 8,393 |  |  | $ | 12,249 |  |
| Other comprehensive loss, net of tax: |  |  |  |
| Foreign currency translation losses | (1,017 | ) |  | (952 | ) |
| Unrealized gains on investments | 2 |  |  | 42 |  |
| Tax provision related to items of other comprehensive income or loss | — |  |  | (15 | ) |
| Other comprehensive loss, net of tax | (1,015 | ) |  | (925 | ) |
| Comprehensive income | $ | 7,378 |  |  | $ | 11,324 |  |

[0001262039-14-000021:8k_2_02:60]
FORTINET, INC.

[0001262039-14-000021:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-14-000021:8k_2_02:62]
(Unaudited, in thousands)

[0001262039-14-000021:8k_2_02:63]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 8,393 |  |  | $ | 12,249 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 4,422 |  |  | 3,536 |  |
| Amortization of investment premiums | 2,513 |  |  | 3,051 |  |
| Stock-based compensation | 12,930 |  |  | 9,299 |  |
| Excess tax benefits from stock-based compensation | (579 | ) |  | (1,453 | ) |
| Other non-cash items, net | (67 | ) |  | (540 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 19,119 |  |  | 5,747 |  |
| Inventory | 3,326 |  |  | (4,520 | ) |
| Deferred tax assets | 24 |  |  | (8,970 | ) |
| Prepaid expenses and other current assets | (287 | ) |  | (217 | ) |
| Other assets | 45 |  |  | 417 |  |
| Accounts payable | (6,042 | ) |  | 4,957 |  |
| Accrued liabilities | (170 | ) |  | 2 |  |
| Other liabilities | 16,155 |  |  | (13 | ) |
| Accrued payroll and compensation | 1,071 |  |  | (2,416 | ) |
| Deferred revenue | 18,469 |  |  | 12,677 |  |
| Income taxes payable | (18,420 | ) |  | 4,305 |  |
| Net cash provided by operating activities | 60,902 |  |  | 38,111 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (120,590 | ) |  | (171,506 | ) |
| Sales of investments | 10,920 |  |  | 13,823 |  |
| Maturities of investments | 118,641 |  |  | 86,018 |  |
| Purchases of property and equipment | (11,318 | ) |  | (1,534 | ) |
| Payments made in connection with business acquisitions, net of cash acquired | (17 | ) |  | (5,979 | ) |
| Net cash used in investing activities | (2,364 | ) |  | (79,178 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 14,471 |  |  | 14,464 |  |
| Taxes paid related to net share settlement of equity awards | (3,633 | ) |  | — |  |
| Excess tax benefit from stock-based compensation | 579 |  |  | 1,453 |  |
| Repurchase and retirement of common stock | (12,305 | ) |  | — |  |
| Net cash (used in) provided by financing activities | (888 | ) |  | 15,917 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | (555 | ) |  | (441 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 57,095 |  |  | (25,591 | ) |
| CASH AND CASH EQUIVALENTS—Beginning of period | 115,873 |  |  | 122,975 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 172,968 |  |  | $ | 97,384 |  |

[0001262039-14-000021:8k_2_02:64]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-14-000021:8k_2_02:65]
(Unaudited, in thousands)

[0001262039-14-000021:8k_2_02:66]
Reconciliation of GAAP revenue to billings

[0001262039-14-000021:8k_2_02:67]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Total revenue | $ | 168,949 |  |  | $ | 135,820 |  |
| Add increase in deferred revenue | 18,675 |  |  | 13,229 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | (550 | ) |
| Total billings (Non-GAAP) | $ | 187,624 |  |  | $ | 148,499 |  |

[0001262039-14-000021:8k_2_02:68]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-14-000021:8k_2_02:69]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Net cash provided by operating activities | $ | 60,902 |  |  | $ | 38,111 |  |
| Less purchases of property and equipment | (11,318 | ) |  | (1,534 | ) |
| Free cash flow (Non-GAAP) | $ | 49,584 |  |  | $ | 36,577 |  |

[0001262039-14-000021:8k_2_02:70]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-14-000021:8k_2_02:71]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000021:8k_2_02:72]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-14-000021:8k_2_02:73]
|  | Three Months Ended March 31, 2014 |  | Three Months Ended March 31, 2013 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating Income | $ | 12,815 |  |  | $ | 13,441 |  | (a) | $ | 26,256 |  |  | $ | 15,391 |  |  | $ | 9,565 |  | (b) | $ | 24,956 |  |
| Operating Margin | 8 | % |  |  |  | 16 | % |  | 11 | % |  |  |  | 18 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 12,930 |  |  |  |  |  |  | 9,299 |  |  |  |
| Amortization expense of intangible assets |  |  | 511 |  | (c) |  |  |  |  | 266 |  | (c) |  |
| Tax adjustment |  |  | (3,610 | ) | (d) |  |  |  |  | (4,032 | ) | (d) |  |
| Net Income | $ | 8,393 |  |  | $ | 9,831 |  |  | $ | 18,224 |  |  | $ | 12,249 |  |  | $ | 5,533 |  |  | $ | 17,782 |  |
| Diluted net income per share | $ | 0.05 |  |  |  |  | $ | 0.11 |  |  | $ | 0.07 |  |  |  |  | $ | 0.11 |  |
| Shares used in per share calculations - diluted | 168,114 |  |  |  |  | 168,114 |  |  | 167,823 |  |  |  |  | 167,823 |  |

[0001262039-14-000021:8k_2_02:74]
(a) To exclude $12.9 million of stock-based compensation expense and $0.5 million of amortization expense of intangible assets in the three months ended March 31, 2014.

[0001262039-14-000021:8k_2_02:75]
(b) To exclude $9.3 million of stock-based compensation expense and $0.3 million of amortization expense of intangible assets in the three months ended March 31, 2013.

[0001262039-14-000021:8k_2_02:76]
(c) Beginning in the second quarter of fiscal 2013, amortization expense of intangible assets has been excluded from GAAP operating income and GAAP net income. Prior period amounts have been adjusted to conform to the current period presentation.

[0001262039-14-000021:8k_2_02:77]
(d)  Non-GAAP financial information is adjusted to achieve an overall 33 percent effective tax rate on a pro forma basis, which differs from the GAAP tax rate, in the three months ended March 31, 2014 and March 31, 2013.
