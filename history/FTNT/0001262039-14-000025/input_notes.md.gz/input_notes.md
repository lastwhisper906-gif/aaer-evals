# FTNT notes — 0001262039-14-000025


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-14-000025:notes:1]
[same as prior period, unchanged from 0001262039-13-000055:notes:1]

[0001262039-14-000025:notes:2]
[same as prior period, unchanged from 0001262039-13-000055:notes:9]

[0001262039-14-000025:notes:3]
On March 21, 2013, we acquired all of the outstanding equity securities of Coyote Point Systems, Inc. (“Coyote”), a provider of application delivery, load balancing and acceleration solutions, for $6.0 million in cash. The acquisition also included a contingent obligation for up to $5.5 million in future earn-out payments to former stockholders of Coyote, if specified future operational objectives, service conditions and financial results are met within two years of the acquisition date.  Of the maximum $5.5 million in contingent earn-out payments, up to $3.5 million will be payable after eighteen months from the acquisition date, and up to $2.0 million will be payable after two years from the acquisition date.  As the future earn-out payments are also contingent upon one of Coyote's former stockholder's employment during the earn-out period, the estimated fair value of these contingent obligations is being recorded as compensation expense ratably over the earn-out periods. This acquisition complemented our network security strategy and allowed us and our channel partners to accelerate and further deliver on our vision of providing broad security and networking functionality to customers.

[0001262039-14-000025:notes:4]
We accounted for this acquisition as a purchase of a business and, accordingly, the total purchase price was allocated to Coyote’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The fair value assigned to the intangible assets acquired was determined using the income approach which discounts expected cash flows to present value using our estimates and assumptions.

[0001262039-14-000025:notes:5]
The following table summarizes the fair value of assets acquired and liabilities assumed (in thousands):

[0001262039-14-000025:notes:6]
| Cash and cash equivalents | $ | 206 |  |
| Other current assets | 501 |  |
| Finite-lived intangible assets | 2,800 |  |
| Indefinite-lived intangible assets | 2,600 |  |
| Goodwill | 2,824 |  |
| Other assets | 88 |  |
| Total assets acquired | 9,019 |  |
| Current liabilities | 1,030 |  |
| Long-term liabilities | 2,004 |  |
| Total liabilities assumed | 3,034 |  |
| Total purchase price | $ | 5,985 |  |

[0001262039-14-000025:notes:7]
Of the total acquired identified intangible assets, we allocated $2.3 million to developed technology, $0.5 million to customer relationships, and $2.6 million to in-process research and development (“IPR&D”) as of the acquisition date. Identified finite-lived intangible assets consist of developed technology and customer relationships that are being amortized as cost of revenue and sales and marketing expense, respectively, ratably on a straight-line basis, each over an estimated useful life of six years. Identified indefinite-lived intangible assets consisted of acquired IPR&D relating to existing research and development projects at the time of acquisition. The goodwill of $2.8 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to acquire developed and in-process technology. None of the goodwill recognized as a result of the acquisition is deductible for income tax purposes. The financial results of this acquisition were considered immaterial for purposes of pro-forma financial disclosures. During the three months ended September 30, 2013, we completed the development of technology associated with the IPR&D projects, and started amortizing this developed technology as cost of revenue ratably on a straight-line basis over an estimated useful life of 6 years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-14-000025:notes:8]
COMMITMENTS AND CONTINGENCIES

[0001262039-14-000025:notes:9]
The following table summarizes our future principal contractual obligations as of March 31, 2014 (in thousands):

[0001262039-14-000025:notes:10]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 31,592 |  |  | $ | 6,543 |  |  | $ | 6,547 |  |  | $ | 5,385 |  |  | $ | 4,639 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |
| Less: Sublease rental income | 1,040 |  |  | 585 |  |  | 455 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 30,552 |  |  | 5,958 |  |  | 6,092 |  |  | 5,385 |  |  | 4,639 |  |  | 3,649 |  |  | 4,829 |  |
| Purchase commitments | 38,880 |  |  | 38,880 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contract commitments | 24,182 |  |  | 18,502 |  |  | 3,914 |  |  | 889 |  |  | 877 |  |  | — |  |  | — |  |
| Total | $ | 93,614 |  |  | $ | 63,340 |  |  | $ | 10,006 |  |  | $ | 6,274 |  |  | $ | 5,516 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |

[0001262039-14-000025:notes:11]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Future minimum payments under the non-cancelable operating leases totaled $31.6 million as of March 31, 2014. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.7 million and $2.3 million during the three months ended March 31, 2014 and March 31, 2013, respectively.

[0001262039-14-000025:notes:12]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2014, we had $38.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-14-000025:notes:13]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2014, we had $24.2 million in other purchase commitments.

[0001262039-14-000025:notes:14]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-14-000025:notes:15]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (756 | ) |  | (759 | ) |
| Provision for warranty for the period, including warranty liabilities assumed in connection with an acquisition | 837 |  |  | 674 |  |
| Changes in prior period estimates | (313 | ) |  | 60 |  |
| Accrued warranty balance—end of the period | $ | 2,805 |  |  | $ | 2,284 |  |

[0001262039-14-000025:notes:16]
Litigation—We are involved in disputes, litigation, and other legal actions. We are defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-14-000025:notes:17]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-14-000025:notes:18]
[same as prior period, unchanged from 0001262039-13-000055:notes:30]

[0001262039-14-000025:notes:19]
Our tax-deferred savings plan, under the 401(k) Plan, allows participating employees to defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions up to the maximum contribution limits under the Income Tax Act. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for the three months ended March 31, 2014 and March 31, 2013 were $0.6 million and $0.5 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-14-000025:notes:20]
[same as prior period, unchanged from 0001262039-13-000055:notes:32]

[0001262039-14-000025:notes:21]
The following table summarizes the changes in accumulated balances of other comprehensive income for the three months ended March 31, 2014 (in thousands):

[0001262039-14-000025:notes:22]
|  | March 31, 2014 |
|  | Foreign Currency Translation Gains And Losses |  | Unrealized Gains And Losses On Investments |  | Tax Benefit Or Provision Related To Items Of Other Comprehensive Income Or Loss |  | Total |
| Balance as of December 31, 2013 | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |
| Other comprehensive income before reclassifications | (1,019 | ) |  | 6 |  |  | — |  |  | (1,013 | ) |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net current-period other comprehensive income | (1,019 | ) |  | 4 |  |  | — |  |  | (1,015 | ) |
| Balance as of March 31, 2014 | $ | (686 | ) |  | $ | 1,172 |  |  | $ | (409 | ) |  | $ | 77 |  |

[0001262039-14-000025:notes:23]
The following table provides details about the reclassification out of accumulated other comprehensive income for the three months ended March 31, 2014 (in thousands):

[0001262039-14-000025:notes:24]
| March 31, 2014 |
| Details About Accumulated Other Comprehensive Income Components |  | Amount Reclassified From Accumulated Other Comprehensive Income |  | Affected Line Item In The Statement Where Net Income Is Presented |
| Unrealized gains on investments |  | $ | (2 | ) |  | Other (expense) income—net |
| Tax provision related to items of other comprehensive income or loss |  | — |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (2 | ) |  |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-14-000025:notes:25]
Deferred revenue consisted of the following (in thousands):

[0001262039-14-000025:notes:26]
|  | March 31, 2014 |  | December 31, 2013 |
| Product | $ | 3,527 |  |  | $ | 2,915 |  |
| Services and other | 447,776 |  |  | 429,713 |  |
| Total deferred revenue | $ | 451,303 |  |  | $ | 432,628 |  |
| Reported As: |  |  |  |
| Current | $ | 305,702 |  |  | $ | 293,664 |  |
| Non-current | 145,601 |  |  | 138,964 |  |
| Total deferred revenue | $ | 451,303 |  |  | $ | 432,628 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-14-000025:notes:27]
[same as prior period, unchanged from 0001262039-13-000055:notes:41]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-14-000025:notes:28]
[same as prior period, unchanged from 0001262039-13-000055:notes:42]

[0001262039-14-000025:notes:29]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other (expense) income—net in the consolidated statement of operations.

[0001262039-14-000025:notes:30]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR, GBP and JPY could adversely impact our operating expenses in the future.

[0001262039-14-000025:notes:31]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of March 31, 2014 and December 31, 2013 were (in thousands):

[0001262039-14-000025:notes:32]
|  | Buy/Sell |  | Notional |
| Currency—As of March 31, 2014 |  |  |  |
| CAD | Buy |  | $ | 23,058 |  |
| Currency—As of December 31, 2013 |  |  |  |
| CAD | Buy |  | $ | 21,867 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-14-000025:notes:33]
[same as prior period, unchanged from 0001262039-13-000055:notes:45]

[0001262039-14-000025:notes:34]
[same as prior period, unchanged from 0001262039-13-000055:notes:46]

[0001262039-14-000025:notes:35]
[same as prior period, unchanged from 0001262039-13-000055:notes:47]

[0001262039-14-000025:notes:36]
[same as prior period, unchanged from 0001262039-13-000055:notes:49]

[0001262039-14-000025:notes:37]
|  | Three Months Ended |
|  | March 31, 2014 |
| Expected term in years | 4.88 |  |
| Volatility | 44.5 | % |
| Risk-free interest rate | 1.7 | % |
| Dividend rate | — |  |

[0001262039-14-000025:notes:38]
There were no stock options granted during the three months ended March 31, 2013.

[0001262039-14-000025:notes:39]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-14-000025:notes:40]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2013 | 15,521 |  |  | $ | 13.18 |  |  |  |  |  |  |
| Granted | 187 |  |  | 21.46 |  |  |  |  |  |
| Forfeited | (148 | ) |  | 23.16 |  |  |  |  |  |
| Exercised | (1,015 | ) |  | 7.09 |  |  |  |  |  |
| Balance—March 31, 2014 | 14,545 |  |  | 13.61 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2014 | 14,509 |  |  | $ | 13.59 |  |  | 3.14 |  | $ | 135,393 |  |
| Options exercisable—March 31, 2014 | 11,567 |  |  | $ | 11.20 |  |  | 2.72 |  | $ | 132,401 |  |

[0001262039-14-000025:notes:41]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2014, for all in-the-money options. As of March 31, 2014, total compensation expense related to unvested stock options granted to employees but not yet recognized was $34.2 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 1.70 years.

[0001262039-14-000025:notes:42]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-14-000025:notes:43]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Weighted-average fair value per share granted | $ | 8.65 |  |  | $ | — |  |
| Intrinsic value of options exercised | $ | 15,321 |  |  | $ | 26,059 |  |
| Fair value of options vested | $ | 4,562 |  |  | $ | 11,004 |  |

[0001262039-14-000025:notes:44]
[same as prior period, unchanged from 0001262039-13-000055:notes:57]

[0001262039-14-000025:notes:45]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-14-000025:notes:46]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2013 | 4,199 |  |  | $ | 22.00 |  |
| Granted | 1,852 |  |  | 21.48 |  |
| Forfeited | (100 | ) |  | 21.74 |  |
| Vested | (516 | ) |  | 23.25 |  |
| Balance—March 31, 2014 | 5,435 |  |  | $ | 21.74 |  |
| RSUs expected to vest—March 31, 2014 | 5,120 |  |  | $ | 21.78 |  |

[0001262039-14-000025:notes:47]
As of March 31, 2014, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $116.1 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.25 years.

[0001262039-14-000025:notes:48]
The following summarizes the number and value of the shares withheld for employee taxes for the three months ended March 31, 2014 (in thousands):

[0001262039-14-000025:notes:49]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Shares withheld for taxes | 171 |  |  | — |  |
| Amount withheld for taxes | $ | 3,633 |  |  | $ | — |  |

[0001262039-14-000025:notes:50]
[same as prior period, unchanged from 0001262039-13-000055:notes:70]

[0001262039-14-000025:notes:51]
In determining the fair value of our ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-14-000025:notes:52]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Expected term in years | 0.49 |  |  | 0.50 |  |
| Volatility | 36.9 | % |  | 48 | % |
| Risk-free interest rate | 0.08 | % |  | 0.10 | % |
| Dividend rate | — |  |  | — |  |

[0001262039-14-000025:notes:53]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-14-000025:notes:54]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Weighted-average fair value per share granted | $ | 5.76 |  |  | $ | 6.83 |  |
| Shares issued under the ESPP | 424 |  |  | 329 |  |
| Weighted-average price per share issued | $ | 17.18 |  |  | $ | 19.91 |  |

[0001262039-14-000025:notes:55]
[same as prior period, unchanged from 0001262039-13-000055:notes:75]

[0001262039-14-000025:notes:56]
Stock-based compensation expense is included in costs and expenses as follows (in thousands):

[0001262039-14-000025:notes:57]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Cost of product revenue | $ | 113 |  |  | $ | 90 |  |
| Cost of services and other revenue | 1,329 |  |  | 1,020 |  |
| Research and development | 3,882 |  |  | 2,766 |  |
| Sales and marketing | 5,746 |  |  | 4,118 |  |
| General and administrative | 1,860 |  |  | 1,305 |  |
| Total stock-based compensation expense | $ | 12,930 |  |  | $ | 9,299 |  |

[0001262039-14-000025:notes:58]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-14-000025:notes:59]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Stock options | $ | 4,692 |  |  | $ | 5,486 |  |
| RSUs | 7,363 |  |  | 2,674 |  |
| ESPP | 875 |  |  | 1,139 |  |
| Total stock-based compensation expense | $ | 12,930 |  |  | $ | 9,299 |  |

[0001262039-14-000025:notes:60]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-14-000025:notes:61]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Income tax benefit associated with stock-based compensation | $ | 3,349 |  |  | $ | 3,587 |  |

[0001262039-14-000025:notes:62]
Share Repurchase Program

[0001262039-14-000025:notes:63]
On December 6, 2013, our Board of Directors authorized a Share Repurchase Program (“the Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.  During the three months ended March 31, 2014, we repurchased 0.3 million shares of common stock under the Program in open market transactions for an aggregate purchase price of $7.5 million. The share repurchases were financed by available cash balances and cash flow from operations. As of March 31, 2014, $153.5 million remains authorized for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-14-000025:notes:64]
[same as prior period, unchanged from 0001262039-13-000055:notes:82]

[0001262039-14-000025:notes:65]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, restricted stock units (“RSUs”), and employee stock purchase plan (“ESPP”). Potentially dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-14-000025:notes:66]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-14-000025:notes:67]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Numerator: |  |  |  |
| Net income | $ | 8,393 |  |  | $ | 12,249 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 162,391 |  |  | 161,282 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 162,391 |  |  | 161,282 |  |
| Effect of potentially dilutive securities: |  |  |  |
| Stock options | 5,196 |  |  | 6,457 |  |
| RSUs | 484 |  |  | 72 |  |
| ESPP | 43 |  |  | 12 |  |
| Weighted-average shares used to compute diluted net income per share | 168,114 |  |  | 167,823 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.05 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.05 |  |  | $ | 0.07 |  |

[0001262039-14-000025:notes:68]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-14-000025:notes:69]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Stock options | 5,079 |  |  | 6,751 |  |
| RSUs | 1,348 |  |  | 1,069 |  |
| ESPP | 358 |  |  | 331 |  |
|  | 6,785 |  |  | 8,151 |  |


## us-gaap:FairValueInputsLiabilitiesQuantitativeInformationTableTextBlock

[0001262039-14-000025:notes:70]
The following table presents quantitative information about the inputs and valuation methodologies used for our fair value measurements classified in Level 3 of the fair value hierarchy as of March 31, 2014 (in thousands except for percentage):

[0001262039-14-000025:notes:71]
|  | March 31, 2014 |
|  | FairValue |  | Valuation Technique |  | Significant Unobservable Input |  | Range |
| Contingent consideration | $707 |  | Probability Weighted Income Approach |  | Revenue |  | $7,000 - $7,639 |
|  |  |  |  |  | Probability of occurrence (%) |  | 20%-70% |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-14-000025:notes:72]
[same as prior period, unchanged from 0001262039-13-000055:notes:90]

[0001262039-14-000025:notes:73]
The following table summarizes our investments as of March 31, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000025:notes:74]
|  | March 31, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 583,341 |  |  | $ | 1,406 |  |  | $ | (280 | ) |  | $ | 584,467 |  |
| Commercial paper | 74,547 |  |  | 4 |  |  | (2 | ) |  | 74,549 |  |
| Municipal bonds | 38,207 |  |  | 50 |  |  | (9 | ) |  | 38,248 |  |
| Certificates of deposit and term deposits | 12,331 |  |  | 2 |  |  | — |  |  | 12,333 |  |
| U.S. government and agency securities | 5,748 |  |  | 3 |  |  | (2 | ) |  | 5,749 |  |
| Total available-for-sale securities | $ | 714,174 |  |  | $ | 1,465 |  |  | $ | (293 | ) |  | $ | 715,346 |  |

[0001262039-14-000025:notes:75]
|  | December 31, 2013 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 603,185 |  |  | $ | 1,506 |  |  | $ | (374 | ) |  | $ | 604,317 |  |
| Commercial paper | 69,356 |  |  | 7 |  |  | — |  |  | 69,363 |  |
| Municipal bonds | 38,815 |  |  | 48 |  |  | (20 | ) |  | 38,843 |  |
| Certificates of deposit and term deposits | 12,645 |  |  | 3 |  |  | — |  |  | 12,648 |  |
| U.S. government and agency securities | 2,000 |  |  | 1 |  |  | — |  |  | 2,001 |  |
| Total available-for-sale securities | $ | 726,001 |  |  | $ | 1,565 |  |  | $ | (394 | ) |  | $ | 727,172 |  |

[0001262039-14-000025:notes:76]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of March 31, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000025:notes:77]
|  | March 31, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 148,132 |  |  | $ | (257 | ) |  | $ | 13,176 |  |  | $ | (23 | ) |  | $ | 161,308 |  |  | $ | (280 | ) |
| Commercial paper | 12,094 |  |  | (2 | ) |  | — |  |  | — |  |  | 12,094 |  |  | (2 | ) |
| Municipal bonds | 4,776 |  |  | (5 | ) |  | 4,028 |  |  | (4 | ) |  | 8,804 |  |  | (9 | ) |
| U.S. government and agency securities | 2,748 |  |  | (2 | ) |  | — |  |  | — |  |  | 2,748 |  |  | (2 | ) |
| Total available-for-sale securities | $ | 167,750 |  |  | $ | (266 | ) |  | $ | 17,204 |  |  | $ | (27 | ) |  | $ | 184,954 |  |  | $ | (293 | ) |

[0001262039-14-000025:notes:78]
|  | December 31, 2013 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 182,795 |  |  | $ | (374 | ) |  | $ | 500 |  |  | $ | — |  |  | $ | 183,295 |  |  | $ | (374 | ) |
| Commercial paper | 7,897 |  |  | — |  |  | — |  |  | — |  |  | 7,897 |  |  | — |  |
| Municipal bonds | 14,736 |  |  | (20 | ) |  | — |  |  | — |  |  | 14,736 |  |  | (20 | ) |
| Total available-for-sale securities | $ | 205,428 |  |  | $ | (394 | ) |  | $ | 500 |  |  | $ | — |  |  | $ | 205,928 |  |  | $ | (394 | ) |

[0001262039-14-000025:notes:79]
The contractual maturities of our investments are as follows (in thousands):

[0001262039-14-000025:notes:80]
|  | March 31, 2014 |  | December 31, 2013 |
| Due within one year | $ | 388,083 |  |  | $ | 375,497 |  |
| Due within one to three years | 327,263 |  |  | 351,675 |  |
| Total | $ | 715,346 |  |  | $ | 727,172 |  |

[0001262039-14-000025:notes:81]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are included in Other (expense) income—net in our condensed consolidated statements of operations.

[0001262039-14-000025:notes:82]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor it is more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2014.

[0001262039-14-000025:notes:83]
Realized gains and losses from the sale of available-for-sale securities were not significant in any of the periods presented.

[0001262039-14-000025:notes:84]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of March 31, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000025:notes:85]
|  | March 31, 2014 |  |  |  | December 31, 2013 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 584,467 |  |  | $ | — |  |  | $ | 584,467 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |
| Commercial paper | 74,549 |  |  | — |  |  | 74,549 |  |  | — |  |  | 71,363 |  |  | — |  |  | 71,363 |  |  | — |  |
| Municipal bonds | 38,248 |  |  | — |  |  | 38,248 |  |  | — |  |  | 38,843 |  |  | — |  |  | 38,843 |  |  | — |  |
| Certificates of deposit and term deposits | 12,333 |  |  | — |  |  | 12,333 |  |  | — |  |  | 12,648 |  |  | — |  |  | 12,648 |  |  | — |  |
| Money market funds | 20,298 |  |  | 20,298 |  |  | — |  |  | — |  |  | 5,724 |  |  | 5,724 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 5,749 |  |  | — |  |  | 5,749 |  |  | — |  |  | 2,001 |  |  | — |  |  | 2,001 |  |  | — |  |
| Total | $ | 735,644 |  |  | $ | 20,298 |  |  | $ | 715,346 |  |  | $ | — |  |  | $ | 734,896 |  |  | $ | 5,724 |  |  | $ | 729,172 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | $ | 707 |  |  | $ | — |  |  | $ | — |  |  | $ | 707 |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Total | $ | 707 |  |  | $ | — |  |  | $ | — |  |  | $ | 707 |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 20,298 |  |  |  |  |  |  |  |  | $ | 7,724 |  |  |  |  |  |  |  |
| Short-term investments | 388,083 |  |  |  |  |  |  |  |  | 375,497 |  |  |  |  |  |  |  |
| Long-term investments | 327,263 |  |  |  |  |  |  |  |  | 351,675 |  |  |  |  |  |  |  |
| Total | $ | 735,644 |  |  |  |  |  |  |  |  | $ | 734,896 |  |  |  |  |  |  |  |

[0001262039-14-000025:notes:86]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-14-000025:notes:87]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-14-000025:notes:88]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2014.

[0001262039-14-000025:notes:89]
The fair value of contingent consideration arising from the acquisition of Coyote Point Systems (see Note 5), is classified within Level 3 of the fair value hierarchy since it is based on a probability-based approach that includes significant unobservable inputs. The significant unobservable inputs include projected revenues and the percentage probability of occurrence to value the payment. A significant increase (decrease) in the projected revenue in isolation could result in a significantly higher (lower) fair value measurement and significant increase (decrease) in the probability of occurrence between the outcomes in isolation could result in a significantly higher (lower) fair value measurement. The fair value of the contingent consideration is calculated on a quarterly basis by management based on a collaborative effort of our operations and finance and accounting groups. Potential valuation adjustments are made as additional information becomes available, including the progress toward achieving revenue targets as compared to initial projections, the impact of market competition, and changes in actual and projected product mix and average selling price. Any adjustments to the fair value of the contingent consideration are included in research and development expense in the condensed consolidated statements of operations.

[0001262039-14-000025:notes:90]
The change in the fair value of our contingent consideration liability is as follows (in thousands):

[0001262039-14-000025:notes:91]
| As of December 31, 2013 | $1,850 |
| Less adjustment to fair value of contingent consideration | (1,143) |
| As of March 31, 2014 | $707 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-14-000025:notes:92]
[same as prior period, unchanged from 0001262039-13-000055:notes:105]

[0001262039-14-000025:notes:93]
The effective tax rate was 39% for the three months ended March 31, 2014, compared to an effective tax rate of 28% for the three months ended March 31, 2013. The provision for income taxes for the periods presented is comprised of U.S. federal and state taxes, foreign income taxes, and withholding tax, as well as the inclusion of stock option benefits and cost allocations, which affected the transfer pricing calculations among the U.S. and some of our foreign subsidiaries.

[0001262039-14-000025:notes:94]
As of March 31, 2014 and December 31, 2013, unrecognized tax benefits were $33.8 million and $30.2 million, respectively. The total amount of $33.2 million in unrecognized tax benefits, would favorably impact the effective tax rate.

[0001262039-14-000025:notes:95]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of March 31, 2014, we had accrued approximately $1.2 million for estimated interest related to uncertain tax positions.

[0001262039-14-000025:notes:96]
The State of California had been conducting an audit of our state income tax returns for fiscal 2010 and fiscal 2011. The audit was settled during the three months ended March 31, 2014 with no significant impact to our tax position or reserves.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001262039-14-000025:notes:97]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-14-000025:notes:98]
We recorded $2.8 million of goodwill from the acquisition of Coyote. There were no impairments to goodwill during the three months ended March 31, 2014.

[0001262039-14-000025:notes:99]
The following tables present other intangible assets (in thousands):

[0001262039-14-000025:notes:100]
|  | March 31, 2014 |
|  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |
| Developed technology | $ | 8,887 |  |  | $ | 3,086 |  |  | $ | 5,801 |  |
| Customer relationships | 500 |  |  | 83 |  |  | 417 |  |
| Total other intangible assets—net | $ | 9,387 |  |  | $ | 3,169 |  |  | $ | 6,218 |  |

[0001262039-14-000025:notes:101]
|  | December 31, 2013 |
|  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |
| Developed technology | $ | 8,971 |  |  | $ | 2,568 |  |  | $ | 6,403 |  |
| Customer relationships | 500 |  |  | 62 |  |  | 438 |  |
| Total other intangible assets—net | $ | 9,471 |  |  | $ | 2,630 |  |  | $ | 6,841 |  |

[0001262039-14-000025:notes:102]
Amortization expense was $0.5 million and $0.3 million during the three months ended March 31, 2014 and March 31, 2013, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net (in thousands):

[0001262039-14-000025:notes:103]
|  | Amount |
| Years Ending December 31: |  |
| 2014 (remainder) | $ | 1,220 |  |
| 2015 | 1,567 |  |
| 2016 | 1,261 |  |
| 2017 | 900 |  |
| 2018 | 900 |  |
| Thereafter | 370 |  |
| Total | $ | 6,218 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001262039-14-000025:notes:104]
[same as prior period, unchanged from 0001262039-13-000055:notes:119]

[0001262039-14-000025:notes:105]
Inventory consisted of the following (in thousands):

[0001262039-14-000025:notes:106]
|  | March 31, 2014 |  | December 31, 2013 |
| Raw materials | $ | 5,089 |  |  | $ | 4,319 |  |
| Finished goods | 34,555 |  |  | 40,093 |  |
| Consigned inventory | 3,650 |  |  | 4,260 |  |
| Inventory | $ | 43,294 |  |  | $ | 48,672 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-14-000025:notes:107]
The following table sets forth property and equipment by geographic region (in thousands):

[0001262039-14-000025:notes:108]
| Property and Equipment—Net | March 31, 2014 |  | December 31, 2013 |
| Americas: |  |  |  |
| United States | $ | 40,146 |  |  | $ | 29,334 |  |
| Canada | 3,930 |  |  | 4,372 |  |
| Other Americas | 30 |  |  | 45 |  |
| Total Americas | 44,106 |  |  | 33,751 |  |
| EMEA | 1,647 |  |  | 1,273 |  |
| APAC | 1,721 |  |  | 1,628 |  |
| Total property and equipment—net | $ | 47,474 |  |  | $ | 36,652 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-14-000025:notes:109]
[same as prior period, unchanged from 0001262039-13-000055:notes:127]

[0001262039-14-000025:notes:110]
Property and equipment—net consisted of the following (in thousands):

[0001262039-14-000025:notes:111]
|  | March 31, 2014 |  | December 31, 2013 |
| Land | $ | 13,895 |  |  | $ | 13,895 |  |
| Building and building improvements | 19,121 |  |  | 610 |  |
| Evaluation units | 24,951 |  |  | 23,442 |  |
| Computer equipment, software and tooling | 25,151 |  |  | 23,556 |  |
| Furniture and fixtures | 3,185 |  |  | 1,697 |  |
| Construction-in-progress | 634 |  |  | 10,947 |  |
| Leasehold improvements | 4,520 |  |  | 4,303 |  |
| Total property and equipment | 91,457 |  |  | 78,450 |  |
| Less: accumulated depreciation | (43,983 | ) |  | (41,798 | ) |
| Property and equipment—net | $ | 47,474 |  |  | $ | 36,652 |  |

[0001262039-14-000025:notes:112]
Beginning in the first quarter of 2014, we reclassified certain fixed assets between categories in the table above to better reflect the nature of these fixed assets.  Prior period amounts have also been reclassified to conform to the current period presentation. We believe the impact of the reclassification is not material.

[0001262039-14-000025:notes:113]
Depreciation expense was $3.9 million and $3.2 million during the three months ended March 31, 2014 and March 31, 2013, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-14-000025:notes:114]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-14-000025:notes:115]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment, software and tooling | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-14-000025:notes:116]
Effective March 2014, we moved into our new corporate headquarters. The useful life of building improvements placed into service during the three months ended March 31, 2014, in association with our new corporate headquarters is estimated to be 20 years. The useful life of furniture and fixtures now ranges from 3 to 5 years as we placed new furniture and fixtures into service at the new corporate headquarters.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-14-000025:notes:117]
The following table sets forth revenue by geographic region (in thousands):

[0001262039-14-000025:notes:118]
|  | Three Months Ended |
| Revenue | March 31, 2014 |  | March 31, 2013 |
| Americas: |  |  |  |
| United States | $ | 44,793 |  |  | $ | 34,788 |  |
| Other Americas | 27,639 |  |  | 17,839 |  |
| Total Americas | 72,432 |  |  | 52,627 |  |
| Europe, Middle East, and Africa (“EMEA”) | 56,643 |  |  | 47,326 |  |
| Asia Pacific and Japan (“APAC”) | 39,874 |  |  | 35,867 |  |
| Total revenue | $ | 168,949 |  |  | $ | 135,820 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-14-000025:notes:119]
SEGMENT INFORMATION

[0001262039-14-000025:notes:120]
During the three months ended March 31, 2014, Exclusive Networks Group and Ingram Micro, accounted for 14% and 10% of total revenue, respectively. During the three months ended March 31, 2013, Exclusive Networks Group accounted for 12% of total revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-14-000025:notes:121]
[same as prior period, unchanged from 0001262039-13-000055:notes:136]

[0001262039-14-000025:notes:122]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, except as otherwise noted, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

[0001262039-14-000025:notes:123]
[same as prior period, unchanged from 0001262039-13-000055:notes:139]

[0001262039-14-000025:notes:124]
There have been no material changes to our significant accounting policies for the three months ended March 31, 2014. During the quarter we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements and furniture and fixtures.

[0001262039-14-000025:notes:125]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-14-000025:notes:126]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the Condensed Consolidated Statements of Operations. The combined amounts are being presented as Services and other revenue in the Condensed Consolidated Statements of Operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material.
