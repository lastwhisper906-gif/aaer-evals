# FTNT MD&A — 0001262039-14-000025


## mdna

[0001262039-14-000025:mdna:1]
ITEM 2.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-14-000025:mdna:2]
[same as prior period, unchanged from 0001262039-13-000055:mdna:2]

[0001262039-14-000025:mdna:3]
| • | expected impact of certain acquisitions, asset purchases and strategic investments; |

[0001262039-14-000025:mdna:4]
[same as prior period, unchanged from 0001262039-13-000055:mdna:4]

[0001262039-14-000025:mdna:5]
[same as prior period, unchanged from 0001262039-13-000055:mdna:5]

[0001262039-14-000025:mdna:6]
[same as prior period, unchanged from 0001262039-13-000055:mdna:6]

[0001262039-14-000025:mdna:7]
[same as prior period, unchanged from 0001262039-13-000055:mdna:7]

[0001262039-14-000025:mdna:8]
[same as prior period, unchanged from 0001262039-13-000055:mdna:8]

[0001262039-14-000025:mdna:9]
[same as prior period, unchanged from 0001262039-13-000055:mdna:9]

[0001262039-14-000025:mdna:10]
[same as prior period, unchanged from 0001262039-13-000055:mdna:10]

[0001262039-14-000025:mdna:11]
[same as prior period, unchanged from 0001262039-13-000055:mdna:11]

[0001262039-14-000025:mdna:12]
| • | continued investments in research and development to strengthen our technology leadership position and in sales and marketing and the impact of those investments; |

[0001262039-14-000025:mdna:13]
[same as prior period, unchanged from 0001262039-13-000055:mdna:13]

[0001262039-14-000025:mdna:14]
| • | the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-14-000025:mdna:15]
[same as prior period, unchanged from 0001262039-13-000055:mdna:15]

[0001262039-14-000025:mdna:16]
[same as prior period, unchanged from 0001262039-13-000055:mdna:16]

[0001262039-14-000025:mdna:17]
We provide high performance network security solutions, which enable broad, integrated and high performance protection against advanced security threats while simplifying the IT security infrastructure for enterprises, service providers and governmental entities worldwide. Since inception through March 31, 2014, we had shipped over 1,500,000 appliances via more than 20,000 channel partners to more than 190,000 end-customers worldwide, including a majority of the 2013 Fortune Global 100.

[0001262039-14-000025:mdna:18]
Our core product line, comprised of FortiGate physical and virtual appliances, ships with a set of broad security and networking capabilities, including firewall, virtual private network (VPN), application control, antivirus, intrusion prevention,

[0001262039-14-000025:mdna:19]
Web filtering, vulnerability management, anti-spam, wireless controller, wide area network (WAN) acceleration and native internet protocol version 6 (IPv6) support functionality. Customers select the functions or combination of functions that best meet their specific security requirements -- whether that be a high-speed data center firewall (DCFW) at the network core, a next-generation firewall (NGFW) at the edge, or a broad unified threat management (UTM) solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -800 series for mid-sized enterprises, to the FortiGate-1000 to -5000 series for large enterprises, telecommunications carriers, and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to intrusion prevention, application control, anti-malware, Web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management, analysis and reporting capabilities. We complement our core FortiGate product line with other appliances and software that offer additional protection from security threats to other critical areas of the enterprise, such as protection from advanced persistent threats (APTs), messaging, Web application firewalls, databases, protection against distributed denial of service attacks (DDoS) and endpoint security for employee computers and mobile devices. Sales of these complementary products and related services represent less than 10% of our total revenue.

[0001262039-14-000025:mdna:20]
[same as prior period, unchanged from 0001262039-13-000055:mdna:24]

[0001262039-14-000025:mdna:21]
| • | We recorded total revenue of $168.9 million during the three months ended March 31, 2014. This represents an increase of 24% during the three months ended March 31, 2014, compared to the same period last year. Product revenue was $76.8 million, an increase of 32% during the three months ended March 31, 2014, compared to the same period last year. Services and other revenue was $92.2 million during the three months ended March 31, 2014, an increase of 18%, compared to the same period last year. |

[0001262039-14-000025:mdna:22]
| • | Cash, cash equivalents and investments were $888.3 million as of March 31, 2014, an increase of $45.3 million from December 31, 2013. |

[0001262039-14-000025:mdna:23]
| • | Deferred revenue was $451.3 million as of March 31, 2014, an increase of $18.7 million from December 31, 2013. |

[0001262039-14-000025:mdna:24]
| • | We generated cash flows from operating activities of $60.9 million during the three months ended March 31, 2014, an increase of 60% compared to the same period last year. |

[0001262039-14-000025:mdna:25]
| • | We received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. during the three months ended March 31, 2014. |

[0001262039-14-000025:mdna:26]
| • | We repurchased 0.3 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $7.5 million during the three months ended March 31, 2014. |

[0001262039-14-000025:mdna:27]
During the three months ended March 31, 2014, revenue grew as a result of our focused execution and increased investment in sales and marketing, as well as continued commitment to product development, which strengthened our technology advantage. We also continued to gain traction with several recently introduced FortiGate products, including demand for certain of our high speed, low latency next-generation enterprise data center security product.

[0001262039-14-000025:mdna:28]
We continue to invest in research and development to strengthen our technology leadership position, sales and marketing to expand brand awareness, and our global sales team and distribution channels to expand our global reach and sales capacity and meet increasing customer expectations about the quality and functionality of our products. We continue to focus on selling to large customers, such as enterprise and service providers. As a result, we experienced increased deal volumes driven by traction in enterprise data center deployments and large enterprise deals, with particular strength in the  financial and telecommunication sectors.

[0001262039-14-000025:mdna:29]
Sales of FortiGate products have generally been balanced across entry-level (FortiGate-20 to -100 series), mid-range (FortiGate-200 to -800 series) and high-end (FortiGate-1000 to -5000 series) models with each product category representing approximately one-third of FortiGate sales, with some degree of variability from year to year and between quarters.

[0001262039-14-000025:mdna:30]
During the three months ended March 31, 2014, operating expenses increased by 30% compared to the same period last year. The increase was primarily driven by our accelerated pace of hiring to support our growth as we continued to invest in expanding our sales coverage, developing new products and scaling our customer support organization to meet the needs of our growing customer base. Headcount increased to 2,389 as of March 31, 2014 from 2,077 as of March 31, 2013.

[0001262039-14-000025:mdna:31]
24

[0001262039-14-000025:mdna:32]
Key Financial Metrics

[0001262039-14-000025:mdna:33]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “— Results of Operations,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-14-000025:mdna:34]
|  | Three Months Ended Or As Of |
|  | March 31, 2014 |  | March 31, 2013 |
|  | (in thousands) |
| Revenue | $ | 168,949 |  |  | $ | 135,820 |  |
| Deferred revenue | $ | 451,303 |  |  | $ | 376,414 |  |
| Increase in deferred revenue | $ | 18,675 |  |  | $ | 13,229 |  |
| Billings (non-GAAP) | $ | 187,624 |  |  | $ | 148,499 |  |
| Cash, cash equivalents and investments | $ | 888,314 |  |  | $ | 782,538 |  |
| Net cash provided by operating activities | $ | 60,902 |  |  | $ | 38,111 |  |
| Free cash flow (non-GAAP) | $ | 49,584 |  |  | $ | 36,577 |  |

[0001262039-14-000025:mdna:35]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from subscription and support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-14-000025:mdna:36]
Billings (Non-GAAP). We define billings as revenue recognized during a period plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combinations. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically, represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from other companies that report similar financial measures. We compensate for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000025:mdna:37]
|  | Three Months Ended |
| March 31, 2014 |  | March 31, 2013 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 168,949 |  |  | $ | 135,820 |  |
| Add increase in deferred revenue | 18,675 |  |  | 13,229 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | (550 | ) |
| Total billings (Non-GAAP) | $ | 187,624 |  |  | $ | 148,499 |  |

[0001262039-14-000025:mdna:38]
Free cash flow (Non-GAAP). Free cash flow is defined as net cash provided by operating activities less capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making acquisitions, and strengthening the balance sheet. Analysis of free cash flow facilitates comparisons of our operating results to competitors' operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash balance from operations for the period

[0001262039-14-000025:mdna:39]
25

[0001262039-14-000025:mdna:40]
because it excludes cash used for capital expenditures. We compensate for this limitation by providing information about our capital expenditures on the face of the cash flow statement and under “Liquidity and Capital Resources”.  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000025:mdna:41]
|  | Three Months Ended |
| March 31, 2014 |  | March 31, 2013 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 60,902 |  |  | $ | 38,111 |  |
| Less purchases of property and equipment | (11,318 | ) |  | (1,534 | ) |
| Free cash flow (Non-GAAP) | $ | 49,584 |  |  | $ | 36,577 |  |

[0001262039-14-000025:mdna:42]
[same as prior period, unchanged from 0001262039-13-000055:mdna:63]

[0001262039-14-000025:mdna:43]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, cash flow and related disclosure of contingent assets and liabilities. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, goodwill and other long-lived assets and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-14-000025:mdna:44]
There have been no material changes to our critical accounting policies for the three months ended March 31, 2014. During the quarter we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements and furniture and fixtures.

[0001262039-14-000025:mdna:45]
Stock-Based Compensation Expense—Beginning in the first quarter of fiscal 2014, we changed the methodology of calculating the expected term, which is one of the assumptions used in determining the fair value of our employee stock options under the Black Scholes option pricing model. The expected term represents the period that our stock-based awards are estimated to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-14-000025:mdna:46]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-14-000025:mdna:47]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment, software and tooling | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-14-000025:mdna:48]
Effective March 2014, we moved into our new corporate headquarters. The useful life of building improvements placed into service during the three months ended March 31, 2014, in association with our new corporate headquarters is estimated to be 20 years. The useful life of furniture and fixtures now ranges from 3 to 5 years as we placed new furniture and fixtures into service at the new corporate headquarters.

[0001262039-14-000025:mdna:49]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the Condensed Consolidated Statements of Operations. The combined amounts are being presented as Services and other revenue in the Condensed Consolidated Statements of Operations. The related Cost of revenue and Gross profit, including prior period amounts, have also

[0001262039-14-000025:mdna:50]
[same as prior period, unchanged from 0001262039-13-000055:mdna:19]

[0001262039-14-000025:mdna:51]
been combined to conform to the current period presentation. The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material.

[0001262039-14-000025:mdna:52]
[same as prior period, unchanged from 0001262039-13-000055:mdna:80]

[0001262039-14-000025:mdna:53]
[same as prior period, unchanged from 0001262039-13-000055:mdna:82]

[0001262039-14-000025:mdna:54]
|  | Three Months Ended |  |  |  |  |
| March 31, 2014 |  | March 31, 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands except percentage) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 76,765 |  |  | 45 | % |  | $ | 57,950 |  |  | 43 | % |  | $ | 18,815 |  |  | 32 | % |
| Services and other | 92,184 |  |  | 55 |  |  | 77,870 |  |  | 57 |  |  | 14,314 |  |  | 18 |  |
| Total revenue | $ | 168,949 |  |  | 100 | % |  | $ | 135,820 |  |  | 100 | % |  | $ | 33,129 |  |  | 24 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 72,432 |  |  | 43 | % |  | $ | 52,627 |  |  | 39 | % |  | $ | 19,805 |  |  | 38 | % |
| EMEA | 56,643 |  |  | 33 |  |  | 47,326 |  |  | 35 |  |  | 9,317 |  |  | 20 |  |
| APAC | 39,874 |  |  | 24 |  |  | 35,867 |  |  | 26 |  |  | 4,007 |  |  | 11 |  |
| Total revenue | $ | 168,949 |  |  | 100 | % |  | $ | 135,820 |  |  | 100 | % |  | $ | 33,129 |  |  | 24 | % |

[0001262039-14-000025:mdna:55]
Total revenue increased by $33.1 million, or 24%, in the three months ended March 31, 2014 compared to the same period last year. All three regions experienced revenue growth compared to the same period last year, with Americas contributing the largest portion of our revenue growth. Product revenue increased by $18.8 million, or 32% in the three months ended March 31, 2014, compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories for our entry-level products for smaller enterprises, our mid-range products for mid to large enterprises and branch deployments, and  our high-end products for large enterprise and service provider customers. We also experienced strong demand for some of our more recently introduced high-end appliances.

[0001262039-14-000025:mdna:56]
Services and other revenue increased by $14.3 million, or 18%, in the three months ended March 31, 2014 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of subscription and support contracts sold to a larger customer base. In addition, we grew our FortiGuard subscription offerings and FortiCare support, as well as increase in our professional services revenues from existing large enterprise customers.

[0001262039-14-000025:mdna:57]
[same as prior period, unchanged from 0001262039-13-000055:mdna:31]

[0001262039-14-000025:mdna:58]
[same as prior period, unchanged from 0001262039-13-000055:mdna:87]

[0001262039-14-000025:mdna:59]
|  | Three Months Ended |  |  |  |  |
| March 31, 2014 |  | March 31, 2013 |  | Change |  | % Change |
| (in thousands except percentage) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 32,139 |  |  | $ | 22,958 |  |  | $ | 9,181 |  |  | 40 | % |
| Services and other | 18,604 |  |  | 16,170 |  |  | 2,434 |  |  | 15 |  |
| Total cost of revenue | $ | 50,743 |  |  | $ | 39,128 |  |  | $ | 11,615 |  |  | 30 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 58.1 | % |  | 60.4 | % |  | (2.3 | )% |  |  |
| Services and other | 79.8 |  |  | 79.2 |  |  | 0.6 |  |  |  |
| Total gross margin | 70.0 | % |  | 71.2 | % |  | (1.2 | )% |  |  |

[0001262039-14-000025:mdna:60]
Total gross margin decreased by 1.2 percentage points in the three months ended March 31, 2014 compared to the same period last year, as product gross margin declined. Product gross margin decreased by 2.3 percentage points in the three months ended March 31, 2014 compared to the same period last year as we experienced the impact from higher costs related to personnel and occupancy-related costs of $0.6 million, warranty-related costs which increased by $0.4 million, and higher excess inventory write-offs of $1.0 million. Services and other gross margin increased by 0.6 percentage points during the three months ended March 31, 2014 as our continued investments in our technical support and global threat research organizations were relatively in line with our rate of growth of services and other revenue. Cost of services and other revenue increased by $2.4 million primarily due to a $1.8 million increase in cash-based personnel costs related to headcount increases and a $0.5 million increase in travel, depreciation and other expenses.

[0001262039-14-000025:mdna:61]
[same as prior period, unchanged from 0001262039-13-000055:mdna:90]

[0001262039-14-000025:mdna:62]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2014 |  | March 31, 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands except percentage) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 29,055 |  |  | 17 | % |  | $ | 23,334 |  |  | 17 | % |  | $ | 5,721 |  |  | 25 | % |
| Sales and marketing | 67,326 |  |  | 40 |  |  | 49,976 |  |  | 37 |  |  | 17,350 |  |  | 35 |  |
| General and administrative | 9,010 |  |  | 5 |  |  | 7,991 |  |  | 6 |  |  | 1,019 |  |  | 13 |  |
| Total operating expenses | $ | 105,391 |  |  | 62 | % |  | $ | 81,301 |  |  | 60 | % |  | $ | 24,090 |  |  | 30 | % |

[0001262039-14-000025:mdna:63]
Research and development

[0001262039-14-000025:mdna:64]
Research and development expense increased by $5.7 million, or 25%, in the three months ended March 31, 2014 compared to the same period last year primarily due to an increase of $3.1 million in cash-based personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, we incurred higher stock-based compensation expense of $1.1 million, higher product development expenses, such as third-party testing and prototypes, of $1.9 million and higher occupancy-related costs of $0.5 million. This increase in expense was partially offset by a $1.1 million reduction in estimated earn-out liabilities. We intend to continue to invest in our research and development organization but expect research and development expense as a percentage of total revenue to remain at comparable levels during the remainder of fiscal 2014.

[0001262039-14-000025:mdna:65]
Sales and marketing

[0001262039-14-000025:mdna:66]
Sales and marketing expense increased by $17.4 million, or 35%, in the three months ended March 31, 2014 compared to the same period last year, primarily due to an increase of $11.8 million in cash-based personnel costs as we continued to increase our sales headcount in order to drive continued market share gains. In addition, we incurred increases in stock-based

[0001262039-14-000025:mdna:67]
[same as prior period, unchanged from 0001262039-13-000055:mdna:38]

[0001262039-14-000025:mdna:68]
compensation expense of $1.6 million, and increases in travel, tradeshows and other marketing-related expenses of $2.7 million. As a percentage of revenue, sales and marketing expenses increased as we are accelerating the investment in our sales force and marketing campaigns to support future growth. We intend to continue to make investments in sales and marketing, which are critical to support sustainable growth and expect sales and marketing expense as a percentage of total revenue to remain at comparable levels or increase during the remainder of fiscal 2014.

[0001262039-14-000025:mdna:69]
General and administrative

[0001262039-14-000025:mdna:70]
General and administrative expense increased by $1.0 million, or 13%, in the three months ended March 31, 2014 compared to the same period last year. Cash-based personnel costs increased by $1.1 million and stock-based compensation expense increased by $0.6 million as we continued to increase our headcount in order to support our expanding business. The increase in expense was partially offset by decrease of $0.4 million in facilities and other related costs. We expect general and administrative expense as a percentage of total revenue to remain at comparable levels during the remainder of fiscal 2014.

[0001262039-14-000025:mdna:71]
Interest income and other (expense) income—net

[0001262039-14-000025:mdna:72]
|  | Three Months Ended |  |  |  |  |
| March 31, 2014 |  | March 31, 2013 |  | Change |  | % Change |
| (in thousands except percentage) |
| Interest income | $ | 1,333 |  |  | $ | 1,369 |  |  | $ | (36 | ) |  | (3 | )% |
| Other (expense) income—net | (389 | ) |  | 215 |  |  | (604 | ) |  | (281 | ) |

[0001262039-14-000025:mdna:73]
Interest income was relatively flat in the three months ended March 31, 2014 compared to the same period last year due to lower interest earned, despite higher invested balances of cash, cash equivalents and investments. The change in other (expense) income—net, for the three months ended March 31, 2014 when compared to the same period last year, was the result of higher foreign exchange losses.

[0001262039-14-000025:mdna:74]
[same as prior period, unchanged from 0001262039-13-000055:mdna:102]

[0001262039-14-000025:mdna:75]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2014 |  | March 31, 2013 |  |
| (in thousands except percentage) |
| Provision for income taxes | $ | 5,366 |  |  | $ | 4,726 |  |  | $ | 640 |  |  | 14 | % |
| Effective tax rate | 39 | % |  | 28 | % |  | 11 | % |  | — | % |

[0001262039-14-000025:mdna:76]
Our effective tax rate was 39% for the three months ended March 31, 2014, compared to 28% for the same period last year. The provision for income taxes for the three months ended March 31, 2014 was comprised primarily of U.S. federal and state taxes, foreign income taxes, and withholding tax, as well as the inclusion of stock option benefits and cost allocations, which affected the transfer pricing calculations among the U.S. and some of our foreign subsidiaries. The increase in the effective tax rate for the three months ended March 31, 2014 as compared to the same period last year was primarily due to limitations on utilizing foreign tax credits to offset tax liability, as well as the expiration of the U.S. federal research and development credit effective December 31, 2013.The U.S.  Congress has not extended the research and development tax credit.

[0001262039-14-000025:mdna:77]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of March 31, 2014, we had accrued approximately $1.2 million for estimated interest related to uncertain tax positions.

[0001262039-14-000025:mdna:78]
The State of California had been conducting an audit of our state income tax returns for fiscal 2010 and fiscal 2011. The audit was settled during the three months ended March 31, 2014 with no significant impact to our tax position or reserves.

[0001262039-14-000025:mdna:79]
[same as prior period, unchanged from 0001262039-13-000055:mdna:110]

[0001262039-14-000025:mdna:80]
[same as prior period, unchanged from 0001262039-13-000055:mdna:134]

[0001262039-14-000025:mdna:81]
|  | March 31, 2014 |  | December 31, 2013 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 172,968 |  |  | $ | 115,873 |  |
| Investments | 715,346 |  |  | 727,172 |  |
| Total cash, cash equivalents and investments | $ | 888,314 |  |  | $ | 843,045 |  |
| Working capital | $ | 386,594 |  |  | $ | 322,485 |  |
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
|  | (in thousands) |
| Net cash provided by operating activities | $ | 60,902 |  |  | $ | 38,111 |  |
| Net cash used in investing activities | (2,364 | ) |  | (79,178 | ) |
| Net cash (used in) provided by financing activities | (888 | ) |  | 15,917 |  |
| Effect of exchange rates on cash and cash equivalents | (555 | ) |  | (441 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 57,095 |  |  | $ | (25,591 | ) |

[0001262039-14-000025:mdna:82]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures and investments in strategic relationships that we have made or may make in the future. During the three months ended March 31, 2014, we received a cash payment of $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. We expect to spend up to $15.0 million related to the improvement of our new corporate headquarters and the implementation of our enterprise resource planning system during the remainder of fiscal 2014. Additionally, our liquidity may be impacted, if we were to repurchase additional shares of our common stock under our Share Repurchase Program. As of March 31, 2014, $153.5 million remains available for future share repurchases under this program, which will be financed through our available working capital.

[0001262039-14-000025:mdna:83]
As of March 31, 2014, our cash, cash equivalents, and investments of $888.3 million were held for working-capital purposes and were invested primarily in corporate debt securities, commercial paper,  municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return.

[0001262039-14-000025:mdna:84]
As of March 31, 2014, $136.7 million of our cash and investments was held by our international subsidiaries and is therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-14-000025:mdna:85]
[same as prior period, unchanged from 0001262039-13-000055:mdna:51]

[0001262039-14-000025:mdna:86]
[same as prior period, unchanged from 0001262039-13-000055:mdna:145]

[0001262039-14-000025:mdna:87]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets, excess tax benefit from stock-based compensation, and amortization of investment premiums.

[0001262039-14-000025:mdna:88]
Our operating activities during the three months ended March 31, 2014, provided $60.9 million in cash as a result of our growth in billings, profitability, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the three months ended March 31, 2014 consisted of net income of $8.4 million increased by non-cash adjustments of $19.2 million and changes in operating assets and liabilities of $33.3 million. During the three months ended March 31, 2014, we received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payment of income taxes during the period.

[0001262039-14-000025:mdna:89]
Our operating activities during the three months ended March 31, 2013, provided $38.1 million in cash. The primary sources of cash from operating activities during the three months ended March 31, 2013 consisted of net income of $12.2 million increased by non-cash adjustments of $13.9 million and changes in operating assets and liabilities of $12.0 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payment for inventory purchases.

[0001262039-14-000025:mdna:90]
[same as prior period, unchanged from 0001262039-13-000055:mdna:149]

[0001262039-14-000025:mdna:91]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities, and sales of investments, purchases of property and equipment, and payments made in connection with acquisitions.

[0001262039-14-000025:mdna:92]
During the three months ended March 31, 2014, cash used was primarily due to $11.3 million for our capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $9.0 million.

[0001262039-14-000025:mdna:93]
During the three months ended March 31, 2013, cash used was primarily due to $71.7 million net purchases of investments, $6.0 million for acquisitions, and $1.5 million for the purchases of property and equipment.

[0001262039-14-000025:mdna:94]
[same as prior period, unchanged from 0001262039-13-000055:mdna:152]

[0001262039-14-000025:mdna:95]
The changes in cash flows from financing activities primarily relate to proceeds from issuance of common stock, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-14-000025:mdna:96]
During the three months ended March 31, 2014, we used $12.3 million and $3.6 million of our cash to repurchase and retire our common stock and pay taxes related to withholding upon issuance of restricted stock units, respectively.  This cash outflow was partially offset by proceeds of $14.5 million from the issuance of common stock under our stock plans, as well as excess tax benefit from employee stock-based compensation of $0.6 million.

[0001262039-14-000025:mdna:97]
During the three months ended March 31, 2013, we had positive cash flow of $15.9 million as a result of proceeds of $14.4 million, from the issuance of common stock under our stock plans and an excess tax benefit from employee stock option exercises of $1.5 million.

[0001262039-14-000025:mdna:98]
[same as prior period, unchanged from 0001262039-13-000055:mdna:155]

[0001262039-14-000025:mdna:99]
There have been no material changes outside the ordinary course of business during the three months ended March 31, 2014, to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K.

[0001262039-14-000025:mdna:100]
[same as prior period, unchanged from 0001262039-13-000055:mdna:162]

[0001262039-14-000025:mdna:101]
As of March 31, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
