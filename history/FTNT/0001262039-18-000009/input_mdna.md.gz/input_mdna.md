# FTNT MD&A — 0001262039-18-000009


## mdna

[0001262039-18-000009:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-18-000009:mdna:2]
| • | continued growth and market share gains; |

[0001262039-18-000009:mdna:3]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-18-000009:mdna:4]
| • | expected impact of sales of certain products and services; |

[0001262039-18-000009:mdna:5]
| • | the impact of macro-economic and geopolitical factors on our international sales; |

[0001262039-18-000009:mdna:6]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-18-000009:mdna:7]
| • | the impact of our product innovation strategy; |

[0001262039-18-000009:mdna:8]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, functionality and value in our standalone and bundled subscription service offerings; |

[0001262039-18-000009:mdna:9]
| • | growing our sales to businesses, service providers and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-18-000009:mdna:10]
| • | trends in revenue, costs of revenue and gross margin; |

[0001262039-18-000009:mdna:11]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses as a percentage of total revenue; |

[0001262039-18-000009:mdna:12]
| • | continued investments in research and development; |

[0001262039-18-000009:mdna:13]
| • | managing our continued investments in sales and marketing, and the impact of those investments; |

[0001262039-18-000009:mdna:14]
| • | expectations regarding uncertain tax benefits and our effective tax rate; |

[0001262039-18-000009:mdna:15]
| • | the impact of the 2017 Tax Act; |

[0001262039-18-000009:mdna:16]
| • | expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows; |

[0001262039-18-000009:mdna:17]
| • | competition in our markets; |

[0001262039-18-000009:mdna:18]
| • | our intentions regarding repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-18-000009:mdna:19]
| • | other statements regarding our future operations, financial condition and prospects and business strategies; and |

[0001262039-18-000009:mdna:20]
| • | adoption and impact of new accounting standards, including those related to revenue recognition and accounting for leases. |

[0001262039-18-000009:mdna:21]
Business Overview

[0001262039-18-000009:mdna:22]
Fortinet is a global leader in broad, automated and integrated cybersecurity solutions. We provide high performance cybersecurity solutions to a wide variety of businesses, such as enterprises, data centers and distributed offices, including majority of the Fortune 100 companies. Our cybersecurity solutions are designed to provide broad, automated and integrated protection against dynamic and sophisticated security threats, while simplifying the IT and security infrastructure of our end-customers.

[0001262039-18-000009:mdna:23]
We have four current focus areas for our business. First, we derive a majority of product sales from our FortiGate network security appliances. We continue to develop and improve our offerings, which provide opportunities for market share gains. Second, the Fortinet Security Fabric has been developed to provide unified security across the entire digital attack surface, including network core, endpoints, applications, data centers, access and private and public cloud, and is designed to enable traditionally disparate security devices to work together as an integrated and collaborative whole. As a result of the increased success in selling the Security Fabric, billings for non-FortiGate products and services grew significantly in 2017. Third, cloud security provides opportunity for growth and was one of the fastest growing parts of our business in 2017. We help customers secure their cloud implementations by offering integration, visibility and automation across multi-cloud and hybrid deployments. Our FortiCASB extends the core capabilities of our security fabric architecture to provide businesses the same level of cybersecurity and threat intelligence in cloud environments as they do on their physical networks. The Fortinet cloud security is available across all major cloud providers, including Microsoft Azure, Amazon Web Services, Google Cloud, IBM Cloud and Oracle Cloud. Fourth, the emergence of the IoT has created an environment where data move freely between devices across locations, network environments, remote offices, mobile workers and public cloud environments, making it difficult to consistently track and secure.

[0001262039-18-000009:mdna:24]
Financial Highlights

[0001262039-18-000009:mdna:25]
| • | We recorded total revenue of $1.49 billion in 2017, an increase of 17% compared to $1.28 billion in 2016. Product revenue was $577.2 million in 2017, an increase of 5% compared to $548.1 million in 2016. Service revenue was $917.8 million in 2017, an increase of 26% compared to $727.3 million in 2016. |

[0001262039-18-000009:mdna:26]
| • | We generated operating income of $109.8 million in 2017, an increase of 156% compared to $42.9 million in 2016. |

[0001262039-18-000009:mdna:27]
| • | Cash, cash equivalents and investments were $1.35 billion as of December 31, 2017, an increase of $38.8 million, or 3%, from December 31, 2016. |

[0001262039-18-000009:mdna:28]
| • | Deferred revenue was $1.34 billion as of December 31, 2017, an increase of $301.0 million, or 29%, from December 31, 2016. |

[0001262039-18-000009:mdna:29]
| • | We generated cash flows from operating activities of $594.4 million in 2017, an increase of $248.7 million, or 72%, compared to 2016. |

[0001262039-18-000009:mdna:30]
| • | In 2017, we repurchased 11.2 million shares of common stock under the Repurchase Program for an aggregate purchase price of $446.3 million. In 2016, we repurchased 3.9 million shares of common stock for a total purchase price of $110.8 million. |

[0001262039-18-000009:mdna:31]
Our revenue growth was driven by the strength in sales of our FortiGate and non-FortiGate products and the sale of new, and the renewal and upgrade of existing, FortiCare technical support and FortiGuard security subscription service contracts. Revenue grew in 2017 as the investment made in sales and marketing enabled us to continue to gain enterprise customers.

[0001262039-18-000009:mdna:32]
42

[0001262039-18-000009:mdna:33]
We continue to see a shift in our revenue mix from product revenues to higher-margin, recurring service revenues, reflecting our success in driving higher-priced subscription bundles and services. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-18-000009:mdna:34]
The percentage of our FortiGate-related billings from high-end products increased from 38% in 2016 to 39% in 2017, and the percentage of our FortiGate-related billings from mid-range products increased from 28% in 2016 to 30% in 2017. The percentage of our FortiGate-related billings from entry-level products decreased to 31% in 2017 from 34% in 2016. The sale of non-FortiGate products also grew significantly in 2017. We also saw more deals that included multiple Fortinet products in physical, virtual and cloud environments.

[0001262039-18-000009:mdna:35]
In 2017, operating expenses as a percentage of revenue decreased by 3 percentage points compared to 2016. The decrease was primarily driven by a reduction in sales and marketing expenses as a percentage of revenue. Headcount increased by 9% to 5,066 employees and contractors as of December 31, 2017, up from 4,665 as of December 31, 2016.

[0001262039-18-000009:mdna:36]
Business Model

[0001262039-18-000009:mdna:37]
Our sales strategy is based on a distribution model whereby we primarily sell our products, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, IBM Cloud and Oracle Cloud. While the revenue from such sales are still relatively insignificant, they have increased significantly in recent periods on a percentage basis.

[0001262039-18-000009:mdna:38]
Typically, FortiGuard security subscription and FortiCare technical support services are purchased along with our hardware products and software licenses, most frequently as part of a bundle offering that includes hardware and services functionality. We generally invoice at the time of our sale for the total price of the products and security and technical support services, and the invoice is payable within 30 to 90 days. We also invoice certain licenses and services on a monthly basis.

[0001262039-18-000009:mdna:39]
We generally recognize product revenue up front, and recognize revenue for the sale of new and the renewal of existing FortiGuard security subscription and FortiCare technical support services contracts ratably over the term of the service contract. We recognize revenue for certain software licenses up front as product revenue and, to a lesser extent, recognize other software licenses over the term of the agreement as services revenue. We recognize the security and support revenue over the service period, which is typically one to three years, to a lesser extent, five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which has contributed to our positive cash flow from operations. We recognize commissions on both product and service sales at the time of sale.

[0001262039-18-000009:mdna:40]
Our approach to network security is defined by our SPU hardware architecture. The SPU includes three lines of proprietary ASICs, content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-18-000009:mdna:41]
Key Metrics

[0001262039-18-000009:mdna:42]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss our cash, cash equivalents and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-18-000009:mdna:43]
43

[0001262039-18-000009:mdna:44]
|  | Year Ended or As of December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands) |
| Revenue | $ | 1,494,930 |  |  | $ | 1,275,443 |  |  | $ | 1,009,268 |  |
| Deferred revenue | $ | 1,336,314 |  |  | $ | 1,035,349 |  |  | $ | 791,303 |  |
| Billings (non-GAAP) | $ | 1,795,895 |  |  | $ | 1,515,089 |  |  | $ | 1,232,014 |  |
| Cash, cash equivalents and investments | $ | 1,349,299 |  |  | $ | 1,310,508 |  |  | $ | 1,164,310 |  |
| Net cash provided by operating activities | $ | 594,405 |  |  | $ | 345,708 |  |  | $ | 282,547 |  |
| Free cash flow (non-GAAP) | $ | 459,093 |  |  | $ | 278,526 |  |  | $ | 245,189 |  |

[0001262039-18-000009:mdna:45]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue and free cash flow to be recognized in future periods. Deferred revenue was $1.34 billion as of December 31, 2017, an increase of $301.0 million, or 29%, from December 31, 2016.

[0001262039-18-000009:mdna:46]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.80 billion for 2017, an increase of 19% compared to $1.52 billion in 2016.

[0001262039-18-000009:mdna:47]
A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-18-000009:mdna:48]
|  | Year Ended December 31, |
| 2017 |  | 2016 |  | 2015 |
| (in thousands) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 1,494,930 |  |  | $ | 1,275,443 |  |  | $ | 1,009,268 |  |
| Add change in deferred revenue | 300,965 |  |  | 244,046 |  |  | 232,546 |  |
| Less deferred revenue balance acquired in business combination | — |  |  | (4,400 | ) |  | (9,800 | ) |
| Total billings (non-GAAP) | $ | 1,795,895 |  |  | $ | 1,515,089 |  |  | $ | 1,232,014 |  |

[0001262039-18-000009:mdna:49]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure. A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-18-000009:mdna:50]
44

[0001262039-18-000009:mdna:51]
|  | Year Ended December 31, |
| 2017 |  | 2016 |  | 2015 |
| (in thousands) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 594,405 |  |  | $ | 345,708 |  |  | $ | 282,547 |  |
| Less purchases of property and equipment | (135,312 | ) |  | (67,182 | ) |  | (37,358 | ) |
| Free cash flow (non-GAAP) | $ | 459,093 |  |  | $ | 278,526 |  |  | $ | 245,189 |  |
| Net cash used in investing activities | $ | (76,803 | ) |  | $ | (74,123 | ) |  | $ | (967 | ) |
| Net cash used in financing activities | $ | (415,601 | ) |  | $ | (105,859 | ) |  | $ | (21,557 | ) |

[0001262039-18-000009:mdna:52]
Components of Operating Results

[0001262039-18-000009:mdna:53]
Revenue

[0001262039-18-000009:mdna:54]
We generate the majority of our revenue from sales of our products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from sales of software licenses, cloud business relationships and providing professional services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured.

[0001262039-18-000009:mdna:55]
Our total revenue is comprised of the following:

[0001262039-18-000009:mdna:56]
| • | Product revenue. Product revenue is primarily generated from sales of our appliances. The majority of our product revenue has been generated by our FortiGate line of appliances, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of software. As a percentage of total revenue, we expect that our product revenue may vary from quarter-to-quarter based on certain factors, as discussed below under “—Quarterly Results of Operations,” and we expect the trend to continue in 2018. |

[0001262039-18-000009:mdna:57]
| • | Service revenue. Service revenue is generated primarily from FortiGuard security subscription services related to application control, antivirus, intrusion prevention, web filtering, anti-spam, ATP and vulnerability management updates, and from FortiCare technical support services for software updates, maintenance releases and patches, internet access to technical content, telephone and internet access to technical support personnel and hardware support. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years and, to a lesser extent, five years. We also generate a small portion of our revenue from professional services and training services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. We continue to see a shift from product revenue to higher-margin, recurring service revenue, which reflects our ongoing success in driving sales of mid-range and high-end service bundles, as well as increases in certain software and other time based service models. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings and the renewal of service contracts by our existing customers. |

[0001262039-18-000009:mdna:58]
Our total cost of revenue is comprised of the following:

[0001262039-18-000009:mdna:59]
| • | Cost of product revenue. A substantial majority of the cost of product revenue consists of third-party contract manufacturers' costs, as well as other costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs, and amortization and impairment of intangible assets, if applicable. Personnel costs include direct compensation and benefits. |

[0001262039-18-000009:mdna:60]
| • | Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes supplies and facility-related costs. |

[0001262039-18-000009:mdna:61]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between products, software licenses and services and any excess inventory write-offs. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to product gross margins. During 2017, service gross margin benefited from the shift to higher-margin service revenue. Product gross margin was negatively impacted as longer term deals and higher priced service bundles resulted in allocating a lower percentage of contract values to product and allocating a larger percentage of contact values to services. As a result, the service margin expansion was partially offset by a decline in product gross margin in 2017. We believe our overall gross margin will remain at a relatively comparable level in 2018.

[0001262039-18-000009:mdna:62]
Operating expenses. Our operating expenses consist of research and development, sales and marketing, general and administrative expenses, and restructuring charges. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, stock-based compensation, and sales commissions, as applicable. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce. We expect sales commission expense recognized at the time of sale to decrease as a percentage of revenue due to the adoption of ASU 2014-09—Revenue from Contracts with Customers.

[0001262039-18-000009:mdna:63]
| • | Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of capital equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our research and development teams are primarily located in Canada and the United States. |

[0001262039-18-000009:mdna:64]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include promotional lead generation and other marketing expenses, travel, depreciation of capital equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture additional market share in the high-return enterprise market, where customers tend to provide a higher lifetime value. |

[0001262039-18-000009:mdna:65]
| • | General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of capital equipment and software, facility-related expenses, expenses associated with the ERP system implementation and business acquisition costs. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-18-000009:mdna:66]
| • | Restructuring charges. Restructuring charges relate to alignment activities performed in connection with the Meru Networks, Inc. (“Meru”) and AccelOps, Inc. (“AccelOps”) acquisitions to reduce our cost structure and improve operational efficiencies, resulting in workforce reductions, contract terminations and other charges. |

[0001262039-18-000009:mdna:67]
Interest income. Interest income consists of income earned on our cash, cash equivalents and investments. We have historically invested our cash in corporate debt securities, money market funds, certificates of deposit, commercial paper, U.S. government and agency securities and municipal bonds.

[0001262039-18-000009:mdna:68]
Other income (expense)—net. Other income (expense)—net consists primarily of foreign exchange gains and losses related to foreign currency exchange remeasurement.

[0001262039-18-000009:mdna:69]
Provision for income taxes. We are subject to tax in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in the local country, which are generally lower than U.S. tax rates, and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., research and development tax credits, withholding taxes, nondeductible stock-based compensation expense and the tax impact of the 2017 Tax Act.

[0001262039-18-000009:mdna:70]
46

[0001262039-18-000009:mdna:71]
In December, 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act decreased the federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. As such, we provisionally recorded a $47.9 million expense on the remeasurement of deferred assets due to the reduction of the federal corporate income tax rate, and a $15.2 million expense for the one-time transition tax on the deemed repatriation related to the 2017 Tax Act.

[0001262039-18-000009:mdna:72]
Our effective tax rate approximates the federal corporate income tax rates plus the impact of state taxes, excess tax benefits related to stock-based compensation expense, research and development tax credits, foreign withholding tax, nondeductible stock-based compensation expense, foreign income subject to lower tax rates than income earned in the United States, deferred tax assets remeasurement and a one-time transition tax.

[0001262039-18-000009:mdna:73]
Critical Accounting Policies and Estimates

[0001262039-18-000009:mdna:74]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-18-000009:mdna:75]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-18-000009:mdna:76]
Revenue Recognition

[0001262039-18-000009:mdna:77]
We derive the majority of our revenue from sales of our hardware, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-18-000009:mdna:78]
Revenue is recognized when all of the following criteria have been met:

[0001262039-18-000009:mdna:79]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-18-000009:mdna:80]
| • | Delivery has occurred or services have been rendered. Product delivery occurs when we fulfill an order and title and risk of loss has been transferred. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and, to a lesser extent, five years, and is generally recognized upon delivery or completion of service. |

[0001262039-18-000009:mdna:81]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-18-000009:mdna:82]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-18-000009:mdna:83]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance. We recognize software license revenue upon electronic transfer of the license key to the customer. Historically, software license revenue has not been material.

[0001262039-18-000009:mdna:84]
47

[0001262039-18-000009:mdna:85]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering, and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel, and hardware support.

[0001262039-18-000009:mdna:86]
Service revenue consists of sales from our FortiGuard security subscription and FortiCare technical support services, professional and training services and other services that include SaaS and IaaS, both of which are hosted or cloud-based services. We recognize revenue from these arrangements as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS and IaaS revenues have not represented a significant percentage of our total revenue.

[0001262039-18-000009:mdna:87]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-18-000009:mdna:88]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element. Revenue is reported net of sales taxes.

[0001262039-18-000009:mdna:89]
For our hardware appliances, we use BESP as our selling price estimate. For our support and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-18-000009:mdna:90]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-18-000009:mdna:91]
ASU 2014-09

[0001262039-18-000009:mdna:92]
On January 1, 2018, we adopted Accounting Standards Update (“ASU”) 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under the legacy GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We elected to adopt ASU 2014-09 using the modified retrospective method and will apply the standard to contracts that are not completed as of January 1, 2018, and will recognize the cumulative effect of initially applying the standard as an adjustment to the opening balance of accumulated deficit.

[0001262039-18-000009:mdna:93]
We have completed our analysis of open revenue contracts as of January 1, 2018. Based on our assessment, the impact on revenue in our consolidated financial statements is not material. The impact on revenue primarily relates to the acceleration of revenue from U.S.-based channel partners that was previously deferred until the product was sold through and certain changes related to revenue recognized on software license sales. We expect the pattern of revenue recognition from direct sales of our FortiGate and other appliances and FortiGuard security subscription and FortiCare technical support services to be substantially unchanged on an ongoing basis.

[0001262039-18-000009:mdna:94]
Commission Expense

[0001262039-18-000009:mdna:95]
We recognize commission expense on both product sales and service contracts at the time of sale. Under ASC 2014-09, as of January 1, 2018, we will continue to expense commissions related to appliance sales when incurred, but will capitalize and recognize certain commissions on service contracts over the period of benefit. As part of the transition to the new accounting standard, we expect to capitalize at least $130.0 million of sales commissions that have been determined to be the remaining costs to obtain then existing service contracts. Capitalized sales commissions will be amortized on a straight-line basis over the period of benefit for new business or the contract term for renewals. See Note 1 to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for further discussion.

[0001262039-18-000009:mdna:96]
Stock-Based Compensation

[0001262039-18-000009:mdna:97]
Employee Stock Options. We estimate the fair value of employee stock options awarded to our employees using the Black-Scholes-Merton (“Black-Scholes”) pricing model. For all employee stock options, we recognize expense over the requisite service period using the straight-line method. Our option pricing model requires the input of subjective assumptions, including the expected stock price volatility, expected term, risk-free interest rates and expected dividend yield of our common stock. The assumptions used in our option pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-18-000009:mdna:98]
Employee Stock Purchase Plan. We estimate the fair value of the rights to acquire stock under our employee stock purchase plan (“ESPP”) using the Black-Scholes pricing model and we recognize expense over the requisite service period using the straight-line method. The pricing model requires the input of the fair value of our common stock and assumptions, including the expected term of the award, expected volatility of the price of our common stock, risk-free interest rates and expected dividend yield of our common stock. Our ESPP provides for consecutive six-month offering periods and we use our own historical volatility data in the valuation of ESPP shares. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-18-000009:mdna:99]
49

[0001262039-18-000009:mdna:100]
Valuation of Inventory

[0001262039-18-000009:mdna:101]
As of December 31, 2016, inventory was recorded at the lower of cost or market. On January 1, 2017, we adopted ASU 2015-11—Inventory: Simplifying the Measurement of Inventory. As such, as of December 31, 2017, inventory is recorded at the lower of cost or net realizable value. Adoption of ASU 2015-11 did not have an impact on our consolidated financial statements. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-18-000009:mdna:102]
Business Combinations

[0001262039-18-000009:mdna:103]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such charges are recorded in the period in which they are identified.

[0001262039-18-000009:mdna:104]
Restructuring

[0001262039-18-000009:mdna:105]
Our restructuring expenses consist of severance and other one-time benefits, contract terminations and other expenses. Liabilities for costs associated with a restructuring activity are measured at fair value. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for terminating a contract before the end of its term, which termination is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty, is recognized at fair value on the notification date. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Other costs primarily consist of asset write-offs, which are expensed when incurred.

[0001262039-18-000009:mdna:106]
Accounting for Income Taxes

[0001262039-18-000009:mdna:107]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-18-000009:mdna:108]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-18-000009:mdna:109]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time transition tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under U.S. GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. Due to the timing of the enactment and the complexity involved in applying the provisions of the 2017 Tax Act, we have recorded provisional estimates associated with the 2017 Tax Act. We consider both the recognition of the transition tax and the remeasurement of deferred income taxes incomplete. New guidance from regulators, interpretation of the law, and refinement of our estimates from ongoing analysis of data and tax positions may change the provisional amounts.

[0001262039-18-000009:mdna:110]
50

[0001262039-18-000009:mdna:111]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of operations become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-18-000009:mdna:112]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of operations for the period that the adjustment is determined to be required.

[0001262039-18-000009:mdna:113]
We make estimates and judgments about our future taxable income that are based on assumptions that are consistent with our plans and estimates. Should the actual amounts differ from our estimates, the amount of our tax expense and liabilities could be materially impacted.

[0001262039-18-000009:mdna:114]
Results of Operations

[0001262039-18-000009:mdna:115]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-18-000009:mdna:116]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands) |
| Consolidated Statement of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 577,171 |  |  | $ | 548,110 |  |  | $ | 476,782 |  |
| Service | 917,759 |  |  | 727,333 |  |  | 532,486 |  |
| Total revenue | 1,494,930 |  |  | 1,275,443 |  |  | 1,009,268 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 243,824 |  |  | 208,984 |  |  | 190,398 |  |
| Service | 141,460 |  |  | 128,853 |  |  | 96,379 |  |
| Total cost of revenue | 385,284 |  |  | 337,837 |  |  | 286,777 |  |
| Gross profit: |  |  |  |  |  |
| Product | 333,347 |  |  | 339,126 |  |  | 286,384 |  |
| Service | 776,299 |  |  | 598,480 |  |  | 436,107 |  |
| Total gross profit | 1,109,646 |  |  | 937,606 |  |  | 722,491 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 210,614 |  |  | 183,084 |  |  | 158,129 |  |
| Sales and marketing | 701,026 |  |  | 626,501 |  |  | 470,371 |  |
| General and administrative | 87,862 |  |  | 81,080 |  |  | 71,514 |  |
| Restructuring charges | 340 |  |  | 3,997 |  |  | 7,600 |  |
| Total operating expenses | 999,842 |  |  | 894,662 |  |  | 707,614 |  |
| Operating income | 109,804 |  |  | 42,944 |  |  | 14,877 |  |
| Interest income | 13,482 |  |  | 7,303 |  |  | 5,295 |  |
| Other income (expense)—net | 708 |  |  | (7,099 | ) |  | (3,167 | ) |
| Income before income taxes | 123,994 |  |  | 43,148 |  |  | 17,005 |  |
| Provision for income taxes | 92,595 |  |  | 10,961 |  |  | 9,018 |  |
| Net income | $ | 31,399 |  |  | $ | 32,187 |  |  | $ | 7,987 |  |

[0001262039-18-000009:mdna:117]
51

[0001262039-18-000009:mdna:118]
|  | Year Ended December 31, |
| 2017 |  | 2016 |  | 2015 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 39 | % |  | 43 | % |  | 47 | % |
| Service | 61 |  |  | 57 |  |  | 53 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 16 |  |  | 16 |  |  | 19 |  |
| Service | 9 |  |  | 10 |  |  | 10 |  |
| Total cost of revenue | 26 |  |  | 26 |  |  | 28 |  |
| Gross margin: |  |  |  |  |  |
| Product | 58 |  |  | 62 |  |  | 60 |  |
| Service | 85 |  |  | 82 |  |  | 82 |  |
| Total gross margin | 74 |  |  | 74 |  |  | 72 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 14 |  |  | 14 |  |  | 16 |  |
| Sales and marketing | 47 |  |  | 49 |  |  | 47 |  |
| General and administrative | 6 |  |  | 6 |  |  | 7 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 1 |  |
| Total operating expenses | 67 |  |  | 70 |  |  | 70 |  |
| Operating margin | 7 |  |  | 3 |  |  | 1 |  |
| Interest income | 1 |  |  | 1 |  |  | 1 |  |
| Other income (expense)—net | — |  |  | (1 | ) |  | — |  |
| Income before income taxes | 8 |  |  | 3 |  |  | 2 |  |
| Provision for income taxes | 6 |  |  | 1 |  |  | 1 |  |
| Net income | 2 | % |  | 3 | % |  | 1 | % |

[0001262039-18-000009:mdna:119]
2017 and 2016

[0001262039-18-000009:mdna:120]
Revenue

[0001262039-18-000009:mdna:121]
|  | Year Ended December 31, |  |  |  |  |
| 2017 |  | 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 577,171 |  |  | 39 | % |  | $ | 548,110 |  |  | 43 | % |  | $ | 29,061 |  |  | 5 | % |
| Service | 917,759 |  |  | 61 |  |  | 727,333 |  |  | 57 |  |  | 190,426 |  |  | 26 |  |
| Total revenue | $ | 1,494,930 |  |  | 100 | % |  | $ | 1,275,443 |  |  | 100 | % |  | $ | 219,487 |  |  | 17 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 642,331 |  |  | 43 | % |  | $ | 536,706 |  |  | 42 | % |  | $ | 105,625 |  |  | 20 | % |
| Europe, Middle East and Africa (“EMEA”) | 554,569 |  |  | 37 |  |  | 477,393 |  |  | 37 |  |  | 77,176 |  |  | 16 |  |
| Asia Pacific (“APAC”) | 298,030 |  |  | 20 |  |  | 261,344 |  |  | 21 |  |  | 36,686 |  |  | 14 |  |
| Total revenue | $ | 1,494,930 |  |  | 100 | % |  | $ | 1,275,443 |  |  | 100 | % |  | $ | 219,487 |  |  | 17 | % |

[0001262039-18-000009:mdna:122]
Total revenue increased by $219.5 million, or 17%, in 2017 compared to 2016. We continued to experience global diversification of revenue in 2017. Revenue from all our regions grew, with the Americas contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $29.1 million, or 5%, in 2017 compared to 2016. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories and in particular for our high-end and mid-range products for large enterprise customers. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, also grew significantly. Service revenue increased by $190.4 million, or 26%, in 2017 compared to 2016. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We continue to see a shift from product revenues to higher-margin, recurring service revenues, which reflect our ongoing success in driving sales of high-end and mid-range products and tend to include more security subscriptions and support services, as well as longer contract durations.

[0001262039-18-000009:mdna:123]
Cost of revenue and gross margin

[0001262039-18-000009:mdna:124]
|  | Year Ended December 31, |  |  |  |  |
| 2017 |  | 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 243,824 |  |  | $ | 208,984 |  |  | $ | 34,840 |  |  | 17 | % |
| Service | 141,460 |  |  | 128,853 |  |  | 12,607 |  |  | 10 |  |
| Total cost of revenue | $ | 385,284 |  |  | $ | 337,837 |  |  | $ | 47,447 |  |  | 14 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.8 | % |  | 61.9 | % |  | (4.1 | )% |  |  |
| Service | 84.6 |  |  | 82.3 |  |  | 2.3 |  |  |  |
| Total gross margin | 74.2 | % |  | 73.5 | % |  | 0.7 | % |  |  |

[0001262039-18-000009:mdna:125]
Total gross margin increased by 0.7 percentage points in 2017 compared to 2016, driven by higher margin on service revenue. Service gross margin increased by 2.3 percentage points during 2017 as compared to 2016. Product gross margin decreased by 4.1 percentage points in 2017 compared to 2016. During 2017, service gross margin benefited from the shift to higher-margin service revenue. Product gross margin was negatively impacted by longer term deals and higher priced service bundles, resulting in lower product revenue recognized in 2017 and higher deferred revenue for services that will be recognized in future periods, and as a result of product costs being recognized upon shipment. As a result, the service margin expansion was partially offset by a decline in product gross margin in 2017. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-18-000009:mdna:126]
Operating expenses

[0001262039-18-000009:mdna:127]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 210,614 |  |  | 14 | % |  | $ | 183,084 |  |  | 14 | % |  | $ | 27,530 |  |  | 15 | % |
| Sales and marketing | 701,026 |  |  | 47 |  |  | 626,501 |  |  | 49 |  |  | 74,525 |  |  | 12 |  |
| General and administrative | 87,862 |  |  | 6 |  |  | 81,080 |  |  | 6 |  |  | 6,782 |  |  | 8 |  |
| Restructuring charges | 340 |  |  | — |  |  | 3,997 |  |  | 0.3 |  |  | (3,657 | ) |  | (91 | ) |
| Total operating expenses | $ | 999,842 |  |  | 67 | % |  | $ | 894,662 |  |  | 70 | % |  | $ | 105,180 |  |  | 12 | % |

[0001262039-18-000009:mdna:128]
53

[0001262039-18-000009:mdna:129]
Research and development

[0001262039-18-000009:mdna:130]
Research and development expense increased by $27.5 million, or 15%, in 2017 compared to 2016, primarily due to an increase of $17.6 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, product development costs, such as third-party testing and prototypes, increased by $6.2 million and depreciation and other occupancy-related costs increased by $3.1 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2018.

[0001262039-18-000009:mdna:131]
Sales and marketing

[0001262039-18-000009:mdna:132]
Sales and marketing expense increased by $74.5 million, or 12%, in 2017 compared to 2016, primarily due to an increase of $55.1 million in personnel costs as we continued to increase our sales and marketing headcount in order to drive continued market share gains globally. Marketing-related expense increased by $11.9 million as we invested significantly in marketing programs to drive broader market awareness, build lead generation programs and accelerate pipeline. In addition, depreciation expense and other occupancy-related expense increased by $6.8 million. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars in 2018.

[0001262039-18-000009:mdna:133]
General and administrative

[0001262039-18-000009:mdna:134]
General and administrative expense increased by $6.8 million, or 8%, in 2017 compared to 2016. Personnel costs increased by $8.5 million as we continued to increase headcount in order to support our expanding business. Professional fees increased by $10.6 million, primarily due to the implementation of a new revenue recognition system and a litigation settlement expense of $1.8 million. The increase in expense was partially offset by a decrease in third-party costs of $13.4 million related to the substantial completion of our ERP system implementation in 2016. We expect general and administrative expense to increase in absolute dollars in 2018.

[0001262039-18-000009:mdna:135]
Restructuring

[0001262039-18-000009:mdna:136]
Restructuring expenses of $0.3 million and $4.0 million in 2017 and 2016, respectively, primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. See Note 9 to the consolidated financial statements for additional details, including the types of expenses incurred and cash payments made.

[0001262039-18-000009:mdna:137]
Operating margin

[0001262039-18-000009:mdna:138]
We generated operating income of $109.8 million in 2017, an increase of $66.9 million, or 156%, compared to $42.9 million in 2016. The improvement in operating margin was primarily due to the improvement in gross margin, and the decline in sales and marketing expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 47% in 2017 from 49% in 2016.

[0001262039-18-000009:mdna:139]
Interest income and other income (expense)—net

[0001262039-18-000009:mdna:140]
|  | Year Ended December 31, |  |  |  |  |
| 2017 |  | 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 13,482 |  |  | $ | 7,303 |  |  | $ | 6,179 |  |  | 85 | % |
| Other income (expense)—net | 708 |  |  | (7,099 | ) |  | 7,807 |  |  | (110 | ) |

[0001262039-18-000009:mdna:141]
Interest income increased in 2017 as compared to 2016, primarily due to higher interest rates on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net in 2017 as compared to 2016 was the result of a gain of approximately $1.0 million for foreign currency exchange gains in 2017 compared to a loss of $6.6 million in 2016, due primarily to changes in the value of Euro relative to the U.S. dollar.

[0001262039-18-000009:mdna:142]
Provision for income taxes

[0001262039-18-000009:mdna:143]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 92,595 |  |  | $ | 10,961 |  |  | $ | 81,634 |  |  | 745 | % |
| Effective tax rate (%) | 75 | % |  | 25 | % |  | 50 | % |  | — |  |

[0001262039-18-000009:mdna:144]
Our effective tax rate was 75% for 2017, compared to an effective tax rate of 25% for 2016. The provision for income taxes for 2017 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, an increase in tax reserves, remeasurement of deferred tax assets and a one-time transition tax.

[0001262039-18-000009:mdna:145]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate.

[0001262039-18-000009:mdna:146]
The SEC staff has issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the 2017 Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the 2017 Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the 2017 Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the 2017 Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the 2017 Tax Act.

[0001262039-18-000009:mdna:147]
The increase in the effective tax rate in 2017 was primarily due to the deferred tax assets remeasurement and a one-time transition tax due to the 2017 Tax Act. Excluding the tax impact from the 2017 Tax Act, the 2017 effective tax rate would have been 24%, which was relatively consistent with 2016. In 2016, due to the early adoption of ASU 2016-09, approximately $10.8 million of excess tax benefits were recognized in the income tax provision. In 2017, $13.5 million of excess tax benefits was included in the income tax provision.

[0001262039-18-000009:mdna:148]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2017, we had accrued $13.5 million for estimated interest related to uncertain tax provisions compared to an accrual of $9.5 million as of December 31, 2016.

[0001262039-18-000009:mdna:149]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $12.0 million in the next 12 months, primarily due to the lapse of the statute of limitations and audit settlement. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000009:mdna:150]
2016 and 2015

[0001262039-18-000009:mdna:151]
Revenue

[0001262039-18-000009:mdna:152]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 548,110 |  |  | 43 | % |  | $ | 476,782 |  |  | 47 | % |  | $ | 71,328 |  |  | 15 | % |
| Service | 727,333 |  |  | 57 |  |  | 532,486 |  |  | 53 |  |  | 194,847 |  |  | 37 |  |
| Total revenue | $ | 1,275,443 |  |  | 100 | % |  | $ | 1,009,268 |  |  | 100 | % |  | $ | 266,175 |  |  | 26 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 536,706 |  |  | 42 | % |  | $ | 435,282 |  |  | 43 | % |  | $ | 101,424 |  |  | 23 | % |
| EMEA | 477,393 |  |  | 37 |  |  | 366,018 |  |  | 36 |  |  | 111,375 |  |  | 30 |  |
| APAC | 261,344 |  |  | 21 |  |  | 207,968 |  |  | 21 |  |  | 53,376 |  |  | 26 |  |
| Total revenue | $ | 1,275,443 |  |  | 100 | % |  | $ | 1,009,268 |  |  | 100 | % |  | $ | 266,175 |  |  | 26 | % |

[0001262039-18-000009:mdna:153]
Total revenue increased by $266.2 million, or 26%, in 2016 compared to 2015. We continued to experience global diversification of revenue in 2016. Revenue from all our regions grew, with EMEA contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $71.3 million, or 15%, in 2016 compared to 2015. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories and in particular for our high-end and mid-range products for large enterprise customers. Sales of non-FortiGate products also grew significantly. Service revenue increased by $194.8 million, or 37%, in 2016 compared to 2015. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We started to see a shift from product revenues to higher-margin, recurring service revenues, which reflected our ongoing success in driving sales of service bundles.

[0001262039-18-000009:mdna:154]
Cost of revenue and gross margin

[0001262039-18-000009:mdna:155]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 208,984 |  |  | $ | 190,398 |  |  | $ | 18,586 |  |  | 10 | % |
| Service | 128,853 |  |  | 96,379 |  |  | 32,474 |  |  | 34 |  |
| Total cost of revenue | $ | 337,837 |  |  | $ | 286,777 |  |  | $ | 51,060 |  |  | 18 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.9 | % |  | 60.1 | % |  | 1.8 | % |  |  |
| Service | 82.3 |  |  | 81.9 |  |  | 0.4 |  |  |  |
| Total gross margin | 73.5 | % |  | 71.6 | % |  | 1.9 | % |  |  |

[0001262039-18-000009:mdna:156]
Total gross margin increased by 1.9 percentage points in 2016 compared to 2015, as both product and service gross margins increased. Product gross margin increased by 1.8 percentage points in 2016 compared to 2015. Product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions and by lower warranty related costs, and was partially offset by higher inventory reserves.

[0001262039-18-000009:mdna:157]
Service gross margin increased during 2016 as compared to 2015, as we scaled efficiencies resulting from an increased mix on higher-margin service revenue. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-18-000009:mdna:158]
Operating expenses

[0001262039-18-000009:mdna:159]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 183,084 |  |  | 14 | % |  | $ | 158,129 |  |  | 16 | % |  | $ | 24,955 |  |  | 16 | % |
| Sales and marketing | 626,501 |  |  | 49 |  |  | 470,371 |  |  | 47 |  |  | 156,130 |  |  | 33 |  |
| General and administrative | 81,080 |  |  | 6 |  |  | 71,514 |  |  | 7 |  |  | 9,566 |  |  | 13 |  |
| Restructuring charges | 3,997 |  |  | 0.3 |  |  | 7,600 |  |  | 1 |  |  | (3,603 | ) |  | (47 | ) |
| Total operating expenses | $ | 894,662 |  |  | 70 | % |  | $ | 707,614 |  |  | 70 | % |  | $ | 187,048 |  |  | 26 | % |

[0001262039-18-000009:mdna:160]
Research and development

[0001262039-18-000009:mdna:161]
Research and development expense increased by $25.0 million, or 16%, in 2016 compared to 2015, primarily due to an increase of $19.0 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $6.6 million.

[0001262039-18-000009:mdna:162]
Sales and marketing

[0001262039-18-000009:mdna:163]
Sales and marketing expense increased by $156.1 million, or 33%, in 2016 compared to 2015, primarily due to an increase of $122.3 million in personnel costs as we continued to increase our sales and marketing headcount in order to drive continued market share gains globally. In addition, depreciation expense and other occupancy-related expense increased by $14.0 million, and travel and entertainment expense increased by $8.1 million. Marketing-related expense increased by $7.6 million as we invested significantly in marketing programs, particularly in the large enterprise market, including costs related to trade shows and lead generation. As a percentage of total revenue, sales and marketing expense increased as we accelerated the investment in our sales force and marketing programs to drive future growth.

[0001262039-18-000009:mdna:164]
General and administrative

[0001262039-18-000009:mdna:165]
General and administrative expense increased by $9.6 million, or 13%, in 2016 compared to 2015. Personnel costs increased by $9.6 million as we continued to increase headcount in order to support our expanding business and ERP implementation. During 2016, we expensed $7.8 million of third-party costs relating to the implementation and maintenance of the ERP system implementation compared to $5.4 million in 2015. These increases were partially offset by lower professional fees of $6.7 million in 2016.

[0001262039-18-000009:mdna:166]
Restructuring

[0001262039-18-000009:mdna:167]
Restructuring expenses of $4.0 million in 2016 primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. Restructuring charges of $7.6 million during 2015 relate to restructuring activities in connection with the Meru acquisition. See Note 9 to the consolidated financial statements for additional details, including the types of expenses incurred and cash payments made.

[0001262039-18-000009:mdna:168]
Operating margin

[0001262039-18-000009:mdna:169]
We generated operating income of $42.9 million in 2016, an increase of $28.0 million, or 189%, compared to operating income of $14.9 million in 2015. The improvement in operating margin was primarily due to the improvement in gross margin, and the decline in general and administrative expenses as a percentage of total revenue. As a percentage of total revenue, general and administrative expenses decreased to 6% in 2016 from 7% in 2015.

[0001262039-18-000009:mdna:170]
57

[0001262039-18-000009:mdna:171]
Interest income and other income (expense)—net

[0001262039-18-000009:mdna:172]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| (in thousands, except percentages) |
| Interest income | $ | 7,303 |  |  | $ | 5,295 |  |  | $ | 2,008 |  |  | 38 | % |
| Other income (expense)—net | (7,099 | ) |  | (3,167 | ) |  | (3,932 | ) |  | 124 |  |

[0001262039-18-000009:mdna:173]
Interest income increased in 2016 as compared to 2015, primarily due to higher interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in other expense—net in 2016 as compared to 2015 was the result of higher foreign currency exchange losses.

[0001262039-18-000009:mdna:174]
Provision for income taxes

[0001262039-18-000009:mdna:175]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 10,961 |  |  | $ | 9,018 |  |  | $ | 1,943 |  |  | 22 | % |
| Effective tax rate (%) | 25 | % |  | 53 | % |  | (28 | )% |  | — |  |

[0001262039-18-000009:mdna:176]
Our effective tax rate was 25% for 2016, compared with an effective tax rate of 53% for 2015. The provision for income taxes for 2016 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, an increase in tax reserves, as well as transfer pricing allocations that impact jurisdictional income taxed at various tax rates. The decrease in the effective tax rate in 2016 was primarily due to the recognition of excess tax benefits for income tax provision from the adoption of ASU 2016-09. In 2016, due to the early adoption of ASU 2016-09, approximately $10.8 million of excess tax benefits were recognized in the income tax provision. In 2015, there were no excess tax benefits included in the income tax provision.

[0001262039-18-000009:mdna:177]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2016, we had accrued $9.5 million for estimated interest related to uncertain tax provisions compared to an accrual of $5.5 million as of December 31, 2015.

[0001262039-18-000009:mdna:178]
Quarterly Results of Operations

[0001262039-18-000009:mdna:179]
The following table sets forth our unaudited quarterly statements of operations data for the last eight quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-18-000009:mdna:180]
58

[0001262039-18-000009:mdna:181]
|  | Three Months Ended |
|  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 |
|  | (in thousands, except per share amounts) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 162,118 |  |  | $ | 137,095 |  |  | $ | 142,705 |  |  | $ | 135,253 |  |  | $ | 158,925 |  |  | $ | 127,972 |  |  | $ | 136,641 |  |  | $ | 124,572 |  |
| Service | 254,550 |  |  | 237,122 |  |  | 220,764 |  |  | 205,323 |  |  | 203,905 |  |  | 188,674 |  |  | 174,750 |  |  | 160,004 |  |
| Total revenue | 416,668 |  |  | 374,217 |  |  | 363,469 |  |  | 340,576 |  |  | 362,830 |  |  | 316,646 |  |  | 311,391 |  |  | 284,576 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 69,634 |  |  | 58,106 |  |  | 60,787 |  |  | 55,297 |  |  | 56,616 |  |  | 50,267 |  |  | 52,788 |  |  | 49,313 |  |
| Service (1)(2) | 35,785 |  |  | 35,543 |  |  | 34,865 |  |  | 35,267 |  |  | 34,275 |  |  | 34,532 |  |  | 31,715 |  |  | 28,331 |  |
| Total cost of revenue | 105,419 |  |  | 93,649 |  |  | 95,652 |  |  | 90,564 |  |  | 90,891 |  |  | 84,799 |  |  | 84,503 |  |  | 77,644 |  |
| Total gross profit | 311,249 |  |  | 280,568 |  |  | 267,817 |  |  | 250,012 |  |  | 271,939 |  |  | 231,847 |  |  | 226,888 |  |  | 206,932 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 54,774 |  |  | 53,486 |  |  | 51,159 |  |  | 51,195 |  |  | 45,589 |  |  | 47,239 |  |  | 45,502 |  |  | 44,754 |  |
| Sales and marketing (1)(2) | 191,928 |  |  | 172,361 |  |  | 166,337 |  |  | 170,400 |  |  | 162,873 |  |  | 154,831 |  |  | 162,694 |  |  | 146,103 |  |
| General and administrative (1) | 22,349 |  |  | 21,025 |  |  | 21,911 |  |  | 22,577 |  |  | 17,451 |  |  | 22,006 |  |  | 22,184 |  |  | 19,439 |  |
| Restructuring charges | — |  |  | — |  |  | (90 | ) |  | 430 |  |  | 833 |  |  | 2,283 |  |  | 553 |  |  | 328 |  |
| Total operating expenses | 269,051 |  |  | 246,872 |  |  | 239,317 |  |  | 244,602 |  |  | 226,746 |  |  | 226,359 |  |  | 230,933 |  |  | 210,624 |  |
| Operating income (loss) | 42,198 |  |  | 33,696 |  |  | 28,500 |  |  | 5,410 |  |  | 45,193 |  |  | 5,488 |  |  | (4,045 | ) |  | (3,692 | ) |
| Interest income | 4,061 |  |  | 3,866 |  |  | 3,163 |  |  | 2,392 |  |  | 1,964 |  |  | 1,888 |  |  | 1,705 |  |  | 1,746 |  |
| Other income (expense)—net | (1,181 | ) |  | 344 |  |  | 1,243 |  |  | 302 |  |  | (3,650 | ) |  | (787 | ) |  | (1,350 | ) |  | (1,312 | ) |
| Income (loss) before income taxes | 45,078 |  |  | 37,906 |  |  | 32,906 |  |  | 8,104 |  |  | 43,507 |  |  | 6,589 |  |  | (3,690 | ) |  | (3,258 | ) |
| Provision for (benefit from) income taxes | 74,039 |  |  | 11,296 |  |  | 9,873 |  |  | (2,613 | ) |  | 18,341 |  |  | 298 |  |  | (2,302 | ) |  | (5,376 | ) |
| Net income (loss) | $ | (28,961 | ) |  | $ | 26,610 |  |  | $ | 23,033 |  |  | $ | 10,717 |  |  | $ | 25,166 |  |  | $ | 6,291 |  |  | $ | (1,388 | ) |  | $ | 2,118 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.17 | ) |  | $ | 0.15 |  |  | $ | 0.13 |  |  | $ | 0.06 |  |  | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | (0.01 | ) |  | $ | 0.01 |  |
| Diluted | $ | (0.17 | ) |  | $ | 0.15 |  |  | $ | 0.13 |  |  | $ | 0.06 |  |  | $ | 0.14 |  |  | $ | 0.04 |  |  | $ | (0.01 | ) |  | $ | 0.01 |  |

[0001262039-18-000009:mdna:182]
_______________________________________________

[0001262039-18-000009:mdna:183]
| (1) | Includes stock-based compensation as follows: |

[0001262039-18-000009:mdna:184]
|  | Three Months Ended |
|  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 |
|  | (in thousands) |
| Cost of product revenue | $ | 341 |  |  | $ | 314 |  |  | $ | 383 |  |  | $ | 342 |  |  | $ | 313 |  |  | $ | 309 |  |  | $ | 298 |  |  | $ | 280 |  |
| Cost of service revenue | 2,349 |  |  | 2,371 |  |  | 2,473 |  |  | 2,310 |  |  | 2,276 |  |  | 2,238 |  |  | 2,123 |  |  | 2,134 |  |
| Research and development | 8,067 |  |  | 7,976 |  |  | 8,253 |  |  | 7,898 |  |  | 7,871 |  |  | 7,648 |  |  | 7,458 |  |  | 7,143 |  |
| Sales and marketing | 19,614 |  |  | 19,609 |  |  | 19,745 |  |  | 19,026 |  |  | 17,930 |  |  | 17,378 |  |  | 16,990 |  |  | 15,815 |  |
| General and administrative | 4,083 |  |  | 4,037 |  |  | 4,237 |  |  | 3,755 |  |  | 3,691 |  |  | 3,520 |  |  | 3,478 |  |  | 3,530 |  |
| Total stock-based compensation expense | $ | 34,454 |  |  | $ | 34,307 |  |  | $ | 35,091 |  |  | $ | 33,331 |  |  | $ | 32,081 |  |  | $ | 31,093 |  |  | $ | 30,347 |  |  | $ | 28,902 |  |

[0001262039-18-000009:mdna:185]
| (2) | Total amortization included in the product costs, service costs, and sales and marketing expense are as follows: |

[0001262039-18-000009:mdna:186]
59

[0001262039-18-000009:mdna:187]
|  | Three Months Ended |
|  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 |
|  | (in thousands) |
| Amortization of intangible assets | $ | 2,037 |  |  | $ | 2,037 |  |  | $ | 2,207 |  |  | $ | 2,292 |  |  | $ | 3,022 |  |  | $ | 2,839 |  |  | $ | 2,269 |  |  | $ | 1,178 |  |

[0001262039-18-000009:mdna:188]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-18-000009:mdna:189]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, which results in lower billings and product revenue. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-18-000009:mdna:190]
Consistent with the seasonality note above, our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first quarters of 2017 and 2016. Product revenue, on average throughout the year, increased in 2017 as compared to the same quarters in 2016, which we believe was due in part to the investments made in our sales and marketing organizations, to a robust security market and to continued product innovation. We continue to see a shift from product revenues to higher-margin, recurring service revenues, which reflect our ongoing success in driving sales of mid-range and high-end service bundles, richer service offerings and the average contract length.

[0001262039-18-000009:mdna:191]
Total gross margin has fluctuated on a quarterly basis primarily due to shifts in the mix of sales between products and services, and among products. Product gross margin varies based on the types of products sold and the average selling prices of our products. In 2017, product gross margin was impacted by the shift toward higher-margin subscription bundles and longer duration of service contracts. Service gross margin benefited from the shift to higher-margin service revenue.

[0001262039-18-000009:mdna:192]
60

[0001262039-18-000009:mdna:193]
Liquidity and Capital Resources

[0001262039-18-000009:mdna:194]
|  | As of December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 811,004 |  |  | $ | 709,003 |  |  | $ | 543,277 |  |
| Investments | 538,295 |  |  | 601,505 |  |  | 621,033 |  |
| Total cash, cash equivalents and investments | $ | 1,349,299 |  |  | $ | 1,310,508 |  |  | $ | 1,164,310 |  |
| Working capital | $ | 689,597 |  |  | $ | 709,276 |  |  | $ | 591,873 |  |
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 594,405 |  |  | $ | 345,708 |  |  | $ | 282,547 |  |
| Cash used in investing activities | (76,803 | ) |  | (74,123 | ) |  | (967 | ) |
| Cash used in financing activities | (415,601 | ) |  | (105,859 | ) |  | (21,557 | ) |
| Net increase in cash and cash equivalents | $ | 102,001 |  |  | $ | 165,726 |  |  | $ | 260,023 |  |

[0001262039-18-000009:mdna:195]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our ESPP, payment of taxes in connection with the net settlement of equity awards and business acquisitions. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the proceeds from exercise of stock options and purchases under our ESPP. Additional increases in deferred revenue may depend on a number of factors including our billing growth rate, service contract renewal rates and length of initial and renewals service contracts. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units granted versus stock options and also to vary based on our share price. As of December 31, 2017, $442.8 million remained available for future share repurchase under the Repurchase Program.

[0001262039-18-000009:mdna:196]
We currently expect to spend $90.0 million to $120.0 million for 2018 in capital expenditures, primarily related to expansion of our offices to support worldwide growth.

[0001262039-18-000009:mdna:197]
As of December 31, 2017, our cash, cash equivalents and investments of $1.35 billion were invested primarily in corporate debt securities, money market fund, certificate of deposits, commercial paper and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-18-000009:mdna:198]
As of December 31, 2017, $848.0 million of our cash and investments were held by our international subsidiaries. Under the 2017 Tax Act signed into law in December 2017, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to a repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-18-000009:mdna:199]
61

[0001262039-18-000009:mdna:200]
Operating Activities

[0001262039-18-000009:mdna:201]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities, including deferred revenue. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-18-000009:mdna:202]
Our operating activities during 2017 provided $594.4 million in cash as a result of our continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable. We continue to see a shift from product revenues to higher-margin, recurring service revenues and longer duration contracts. For example, our total revenue grew 17% in 2017 compared to 2016, while our total deferred revenue balance grew 29%.

[0001262039-18-000009:mdna:203]
Our operating activities during 2016 provided $345.7 million in cash as a result of our continued growth of our business and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable and payments for inventory purchases. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues. For example, our total revenue grew 26% in 2016 compared to 2015, while our total deferred revenue balance grew 31%.

[0001262039-18-000009:mdna:204]
Our operating activities during 2015 provided $282.5 million in cash as a result of our continued growth in billings and the ability to successfully manage our working capital. Additionally, in 2015, we received $9.0 million related to a mutual three-year covenant-not-to-sue agreement. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, partially offset by an increase in payments to vendors.

[0001262039-18-000009:mdna:205]
Investing Activities

[0001262039-18-000009:mdna:206]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, and payments made in connection with business acquisitions. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believe that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-18-000009:mdna:207]
During 2017, cash used for investing activities was primarily due to the $135.3 million we spent on capital expenditures, including our purchases of real estate properties in Canada and Sunnyvale, California for total cash of $107.2 million. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $58.5 million.

[0001262039-18-000009:mdna:208]
During 2016, cash used for investing activities was primarily due to $67.2 million we spent on capital expenditures, including our purchases of a warehouse in Union City, California, for total cash of $18.5 million, and a $22.1 million payment for the acquisition of AccelOps. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $15.1 million.

[0001262039-18-000009:mdna:209]
During 2015, cash used for investing activities was primarily due to $38.0 million used for the acquisition of Meru. In addition, we spent $37.4 million on capital expenditures, including our purchases of certain real properties in Sunnyvale, California and Sophia, France for total cash of $13.9 million. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $74.4 million.

[0001262039-18-000009:mdna:210]
Financing Activities

[0001262039-18-000009:mdna:211]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards and repurchase and retirement of common stock.

[0001262039-18-000009:mdna:212]
62

[0001262039-18-000009:mdna:213]
During 2017, cash used for financing activities was $415.6 million, primarily due to $446.3 million used to repurchase our common stock. This was partially offset by $30.7 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000009:mdna:214]
During 2016, cash used for financing activities was $105.9 million, primarily due to $110.8 million used to repurchase our common stock. This was partially offset by $6.6 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000009:mdna:215]
During 2015, cash used for financing activities was $21.6 million, primarily due to $60.0 million used to repurchase our common stock. This was partially offset by $38.4 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000009:mdna:216]
Contractual Obligations and Commitments

[0001262039-18-000009:mdna:217]
The following summarizes our contractual obligations as of December 31, 2017:

[0001262039-18-000009:mdna:218]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in thousands) |
| Operating lease commitments (1) | $ | 56,871 |  |  | $ | 16,020 |  |  | $ | 23,790 |  |  | $ | 10,503 |  |  | $ | 6,558 |  |
| Inventory purchase commitments (2) | 97,170 |  |  | 97,170 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 154,041 |  |  | $ | 113,190 |  |  | $ | 23,790 |  |  | $ | 10,503 |  |  | $ | 6,558 |  |

[0001262039-18-000009:mdna:219]
________________________

[0001262039-18-000009:mdna:220]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001262039-18-000009:mdna:221]
| (2) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-18-000009:mdna:222]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2017, we had $6.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-18-000009:mdna:223]
As of December 31, 2017, we had $90.2 million of long-term tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001262039-18-000009:mdna:224]
Off-Balance Sheet Arrangements

[0001262039-18-000009:mdna:225]
During 2017, 2016 and 2015, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-18-000009:mdna:226]
Recent Accounting Pronouncement

[0001262039-18-000009:mdna:227]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
