# FTNT notes — 0001262039-18-000009


## ftnt:CashandCashEquivalentsandAvailableforSaleInvestmentsPolicyTextBlock

[0001262039-18-000009:notes:1]
Cash, Cash Equivalents and Available-for-Sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds, commercial paper, term deposits and corporate debt.

[0001262039-18-000009:notes:2]
We classify our investments as available-for-sale at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-18-000009:notes:3]
Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001262039-18-000009:notes:4]
For debt securities in an unrealized loss position which is deemed to be other-than-temporary, the difference between the security’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive loss.


## ftnt:ComprehensiveIncomeLossPolicyTextBlock

[0001262039-18-000009:notes:5]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments and the related tax impact.


## ftnt:ConcentrationRiskPolicyTextBlock

[0001262039-18-000009:notes:6]
Concentration of Credit Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, commercial paper and fixed income securities with major financial institutions that our management believes are financially sound.

[0001262039-18-000009:notes:7]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses.


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-18-000009:notes:8]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-18-000009:notes:9]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Income tax benefit associated with stock-based compensation | $ | 30,943 |  |  | $ | 29,190 |  |  | $ | 25,189 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-18-000009:notes:10]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-18-000009:notes:11]
The following tables summarize our investments (in thousands):

[0001262039-18-000009:notes:12]
|  | December 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 391,000 |  |  | $ | 3 |  |  | $ | (1,178 | ) |  | $ | 389,825 |  |
| Commercial paper | 74,210 |  |  | 5 |  |  | (8 | ) |  | 74,207 |  |
| Certificates of deposit and term deposits (1) | 45,870 |  |  | 2 |  |  | (17 | ) |  | 45,855 |  |
| U.S. government and agency securities | 28,487 |  |  | — |  |  | (79 | ) |  | 28,408 |  |
| Total available-for-sale securities | $ | 539,567 |  |  | $ | 10 |  |  | $ | (1,282 | ) |  | $ | 538,295 |  |
|  | December 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 379,494 |  |  | $ | 43 |  |  | $ | (925 | ) |  | $ | 378,612 |  |
| Commercial paper | 95,110 |  |  | 23 |  |  | (25 | ) |  | 95,108 |  |
| U.S. government and agency securities | 64,604 |  |  | 16 |  |  | (79 | ) |  | 64,541 |  |
| Municipal bonds | 59,257 |  |  | 3 |  |  | (235 | ) |  | 59,025 |  |
| Certificates of deposit and term deposits (1) | 4,219 |  |  | — |  |  | — |  |  | 4,219 |  |
| Total available-for-sale securities | $ | 602,684 |  |  | $ | 85 |  |  | $ | (1,264 | ) |  | $ | 601,505 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-18-000009:notes:13]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-18-000009:notes:14]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Expected term in years | 4.4 |  |  | 4.3 |  |  | 4.3 |  |
| Volatility | 36 | % |  | 42 | % |  | 39 | % |
| Risk-free interest rate | 1.9 | % |  | 1.1 | % |  | 1.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleOfSharesReservedForFutureIssuanceTableTextBlock

[0001262039-18-000009:notes:15]
The following table presents the common stock reserved for future issuance (in thousands):

[0001262039-18-000009:notes:16]
|  | December 31, 2017 |
| Outstanding stock options and RSUs | 12,840 |  |
| Reserved for future equity award grants | 46,939 |  |
| Reserved for future ESPP issuances | 2,931 |  |
| Total common stock reserved for future issuances | 62,710 |  |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-18-000009:notes:17]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-18-000009:notes:18]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| RSUs | $ | 119,764 |  |  | $ | 107,124 |  |  | $ | 77,262 |  |
| Stock options | 7,341 |  |  | 6,596 |  |  | 11,425 |  |
| ESPP | 10,078 |  |  | 8,703 |  |  | 6,401 |  |
| Total stock-based compensation expense | $ | 137,183 |  |  | $ | 122,423 |  |  | $ | 95,088 |  |


## ftnt:ScheduleofEstimatedUsefulLivesofPropertyPlantandEquipmentTableTextBlock

[0001262039-18-000009:notes:19]
Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-18-000009:notes:20]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 30 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 5 years |
| Leasehold improvements | Shorter of useful life or lease term |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-18-000009:notes:21]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-18-000009:notes:22]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Shares withheld for taxes | 1,234 |  |  | 1,203 |  |  | 761 |  |
| Amount withheld for taxes | $ | 45,137 |  |  | $ | 38,266 |  |  | $ | 28,871 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-18-000009:notes:23]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-18-000009:notes:24]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Weighted-average fair value per share granted | $ | 12.15 |  |  | $ | 9.14 |  |  | $ | 13.20 |  |
| Intrinsic value of options exercised | 42,666 |  |  | 40,306 |  |  | 113,786 |  |
| Fair value of options vested | 8,102 |  |  | 5,444 |  |  | 10,943 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-18-000009:notes:25]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-18-000009:notes:26]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Weighted-average fair value per share granted | $ | 8.73 |  |  | $ | 7.68 |  |  | $ | 9.56 |  |
| Shares issued under the ESPP | 1,135 |  |  | 1,151 |  |  | 764 |  |
| Weighted-average price per share issued | $ | 29.52 |  |  | $ | 21.01 |  |  | $ | 24.30 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-18-000009:notes:27]
BUSINESS COMBINATIONS

[0001262039-18-000009:notes:28]
AccelOps, Inc.

[0001262039-18-000009:notes:29]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions, for total cash consideration of $22.1 million, net of cash received. This acquisition extended the Fortinet Security Fabric.

[0001262039-18-000009:notes:30]
The acquisition of AccelOps was accounted as a business combination in accordance with ASC Topic 805 “Business Combinations” issued by the FASB, and we used our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-18-000009:notes:31]
Total allocation of the purchase price was (in thousands):

[0001262039-18-000009:notes:32]
| Cash and cash equivalents | $ | 171 |  |
| Accounts receivable | 1,126 |  |
| Prepaid expenses and other assets | 430 |  |
| Property and equipment | 203 |  |
| Deferred tax assets | 3,435 |  |
| Finite-lived intangible assets | 14,900 |  |
| Indefinite-lived intangible assets in process research and development | 1,600 |  |
| Goodwill | 9,861 |  |
| Total assets acquired | 31,726 |  |
| Deferred revenue | 4,400 |  |
| Accounts payable and accrued liabilities | 3,348 |  |
| Other liabilities | 1,694 |  |
| Total liabilities assumed | 9,442 |  |
| Total purchase price allocation | $ | 22,284 |  |

[0001262039-18-000009:notes:33]
Finite-lived intangible assets consist of developed technology, customer relationships and other intangible assets. AccelOps’ technology provides a software solution to manage security, performance and compliance from a single platform. The acquired developed technologies include software patents, know-how, process and designs. The value of customer relationships is attributable to the generation of a consistent income source and the avoidance of costs associated with creating new customer relationships.

[0001262039-18-000009:notes:34]
The estimated useful life and fair values of the acquired finite-lived intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-18-000009:notes:35]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Developed technologies | 4 |  | $ | 12,400 |  |
| Customer relationships | 3 |  | 2,300 |  |
| Other | 2 |  | 200 |  |
| Total |  |  | $ | 14,900 |  |

[0001262039-18-000009:notes:36]
The developed technologies and other are amortized on a straight-line basis. The amortization expense of developed technologies and other intangibles are recorded in cost of revenue. The amortization expense of customer relationships is amortized on an accelerated basis and is recorded in sales and marketing expenses.

[0001262039-18-000009:notes:37]
Indefinite-lived intangible assets consist of in-process research and development, which will begin to be amortized upon completion of development.

[0001262039-18-000009:notes:38]
The goodwill of $9.9 million represents the amount of the purchase price in excess of the fair value of the net tangible liabilities assumed and intangible assets acquired, including AccelOps’ assembled workforce. The goodwill recorded as part of the AccelOps acquisition is not deductible for U.S. federal income tax purposes.

[0001262039-18-000009:notes:39]
Meru Networks, Inc.

[0001262039-18-000009:notes:40]
On July 8, 2015, we completed our acquisition of Meru Networks, Inc. (“Meru”), a provider of wi-fi networking products and services. In connection with the acquisition, we paid $41.8 million, comprised of cash consideration of $40.9 million, withholding tax liability of $0.4 million and the estimated fair value associated with RSUs of Meru of $0.5 million that were converted for 53,401 shares of our common stock.

[0001262039-18-000009:notes:41]
We accounted for this transaction as a business combination in accordance with ASC Topic 805. We expensed acquisition-related costs of $1.7 million in general and administrative expenses. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-18-000009:notes:42]
Total allocation of the purchase price was as follows (in thousands):

[0001262039-18-000009:notes:43]
| Cash and cash equivalents | $ | 3,268 |  |
| Accounts receivable | 8,191 |  |
| Inventory | 11,610 |  |
| Prepaid expenses and other assets | 2,409 |  |
| Property and equipment | 920 |  |
| Deferred tax assets | 18,585 |  |
| Finite-lived intangible assets | 19,600 |  |
| Goodwill | 1,868 |  |
| Total assets acquired | 66,451 |  |
| Deferred revenue | 9,800 |  |
| Accounts payable and accrued liabilities | 14,887 |  |
| Total liabilities assumed | 24,687 |  |
| Total purchase price allocation | $ | 41,764 |  |

[0001262039-18-000009:notes:44]
The goodwill of $1.9 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to Meru’s assembled workforce. The goodwill recorded as part of the Meru acquisition is not deductible for U.S. federal income tax purposes.

[0001262039-18-000009:notes:45]
Intangible assets consist primarily of customer relationships and developed technologies. Customer relationships represent Meru’s installed base and the ability to sell existing, in-process and future versions of our products and services to its existing customers. Developed technologies represent the virtualized wireless local area network solutions offering centralized coordination and control of various access points on the network. This includes patented and unpatented technology, know-how, processes, designs and computer software. The estimated useful life and fair values of the acquired identifiable intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-18-000009:notes:46]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Customer relationships | 5 |  | $ | 12,200 |  |
| Developed technologies | 4 |  | 7,200 |  |
| Trade name | 0.5 |  | 200 |  |
| Total |  |  | $ | 19,600 |  |

[0001262039-18-000009:notes:47]
Customer relationships and trade name are amortized and the amortization expense is recorded in sales and marketing expenses in the consolidated statement of operations. Developed technologies are amortized and the amortization expense is recorded in cost of product revenue in the consolidated statement of operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-18-000009:notes:48]
COMMITMENTS AND CONTINGENCIES

[0001262039-18-000009:notes:49]
The following table summarizes our future principal contractual obligations as of December 31, 2017 (in thousands):

[0001262039-18-000009:notes:50]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 56,871 |  |  | $ | 16,020 |  |  | $ | 13,193 |  |  | $ | 10,597 |  |  | $ | 6,346 |  |  | $ | 4,157 |  |  | $ | 6,558 |  |
| Inventory purchase commitments | 97,170 |  |  | 97,170 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 154,041 |  |  | $ | 113,190 |  |  | $ | 13,193 |  |  | $ | 10,597 |  |  | $ | 6,346 |  |  | $ | 4,157 |  |  | $ | 6,558 |  |

[0001262039-18-000009:notes:51]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $16.7 million, $18.9 million and $13.8 million for 2017, 2016 and 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-18-000009:notes:52]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2017, we had $97.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-18-000009:notes:53]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2017, we had $6.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-18-000009:notes:54]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-18-000009:notes:55]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.

[0001262039-18-000009:notes:56]
In December 2015, we received $9.0 million from a third-party for a release of claims. In addition, we agreed to a three-year covenant-not-to-sue. Of the $9.0 million consideration received, $2.0 million was used to offset contingent legal fees incurred in connection with the litigation and the remaining $7.0 million was deferred, with the short-term portion recorded as accrued liabilities and the long-term portion recorded as other liabilities in the consolidated balance sheet. The deferral is recognized ratably through 2018 as an offset to general and administrative expenses in the consolidated statement of operations.

[0001262039-18-000009:notes:57]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-18-000009:notes:58]
DEFINED CONTRIBUTION PLANS

[0001262039-18-000009:notes:59]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2017, 2016 and 2015 were $4.7 million, $4.4 million and $3.5 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-18-000009:notes:60]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-18-000009:notes:61]
The following table summarizes the changes in accumulated balances of other comprehensive loss for 2017 and 2016 (in thousands):

[0001262039-18-000009:notes:62]
|  | December 31, 2017 |
|  | Unrealized Losses on Investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |
| Other comprehensive loss before reclassifications | (938 | ) |  | 248 |  |  | (690 | ) |
| Amounts reclassified from accumulated other comprehensive loss | 845 |  |  | (237 | ) |  | 608 |  |
| Net current-period other comprehensive loss | (93 | ) |  | 11 |  |  | (82 | ) |
| Ending balance | $ | (1,272 | ) |  | $ | 425 |  |  | $ | (847 | ) |

[0001262039-18-000009:notes:63]
|  | December 31, 2016 |
|  | Unrealized Losses on Investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |
| Other comprehensive income before reclassifications | 255 |  |  | (89 | ) |  | 166 |  |
| Amounts reclassified from accumulated other comprehensive loss | 3 |  |  | (1 | ) |  | 2 |  |
| Net current-period other comprehensive income | 258 |  |  | (90 | ) |  | 168 |  |
| Ending balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |

[0001262039-18-000009:notes:64]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in Other income (expense)—net and in Provision for income taxes, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-18-000009:notes:65]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-18-000009:notes:66]
Our investments in the equity securities of privately held companies totaled $12.1 million and $10.3 million as of December 31, 2017 and 2016, respectively. These investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of December 31, 2017, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-18-000009:notes:67]
As of December 31, 2017, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The VIEs are not required to be consolidated in our consolidated financial statements.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001262039-18-000009:notes:68]
Restructuring— Our restructuring expenses consist of severance and other one-time benefits, contract terminations and other expenses. Liabilities for costs associated with a restructuring activity are measured at fair value. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for terminating a contract before the end of its term, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty, is recognized at fair value on the notification date. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Other costs primarily consist of asset write-offs, which are expensed when incurred.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-18-000009:notes:69]
STOCKHOLDERS’ EQUITY

[0001262039-18-000009:notes:70]
Stock-Based Compensation Plans

[0001262039-18-000009:notes:71]
Our stock-based compensation plans include the 2000 Stock Plan (the “2000 Plan”), the 2008 Stock Plan (the “2008 Plan”), the 2009 Equity Incentive Plan (the “2009 Plan”) and the ESPP, as well as an equity plan assumed through the Meru acquisition. Under these plans, we have granted (or, in the case of the acquired plan, we have assumed) stock options and RSUs.

[0001262039-18-000009:notes:72]
Stock Plans—Our board of directors adopted the 2000 Plan in 2000 and the 2008 Plan in 2008. The plans include both incentive and non-statutory stock options, which allowed us to grant options to purchase common stock to employees, directors, and contractors. During 2017, 2016 and 2015, we issued no stock options under these plans. As of December 31, 2015, no shares remain available for grant under these plans.

[0001262039-18-000009:notes:73]
2009 Equity Incentive Plan—In 2009, our board of directors approved the 2009 Plan, which includes awards of stock options, stock appreciation rights, restricted stock, RSUs and performance stock units. The maximum aggregate number of shares that may be issued under the 2009 Plan is 9.0 million shares, plus any shares subject to stock options or similar awards granted under the 2008 Plan and the 2000 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2008 Plan and the 2000 Plan that are forfeited to or repurchased by us, with the maximum number of shares to be added to the 2009 Plan pursuant to such terminations, forfeitures and repurchases not to exceed 21.0 million shares. The shares may be authorized but unissued or reacquired, common stock. The number of shares available for issuance under the 2009 Plan is increased on the first day of each year beginning with 2011, in an amount equal to the lesser of (i) 14.0 million shares (as adjusted in connection with the stock split effected in June 2011), (ii) 5% of the outstanding shares on the last day of the immediately preceding year or (iii) such number of shares determined by our board of directors. Under the 2009 Plan, we may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of seven years and options generally vest over four years.

[0001262039-18-000009:notes:74]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permits eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year.

[0001262039-18-000009:notes:75]
Meru 2010 Equity Incentive Plan—In connection with the Meru acquisition, we assumed and exchanged Meru’s outstanding RSUs with an estimated fair value of $2.0 million. Of the total estimated fair value, $0.5 million relating to earned equity awards was allocated to the purchase price and the remainder relating to future services is being recognized over the remaining service period. No new equity awards can be granted under the assumed plan. As of December 31, 2017, RSUs representing 584 shares of common stock were outstanding under the awards assumed through the acquisition of Meru.

[0001262039-18-000009:notes:76]
As of December 31, 2017, there were a total of 49,869,569 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-18-000009:notes:77]
Restricted Stock Units

[0001262039-18-000009:notes:78]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-18-000009:notes:79]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2014 | 6,291 |  |  | $ | 22.93 |  |
| Granted | 6,303 |  |  | 39.04 |  |
| Forfeited | (1,029 | ) |  | 31.78 |  |
| Vested | (2,308 | ) |  | 22.74 |  |
| Balance—December 31, 2015 | 9,257 |  |  | 32.97 |  |
| Granted | 5,551 |  |  | 27.96 |  |
| Forfeited | (1,673 | ) |  | 32.03 |  |
| Vested | (3,626 | ) |  | 30.45 |  |
| Balance—December 31, 2016 | 9,509 |  |  | 31.01 |  |
| Granted | 4,200 |  |  | 37.60 |  |
| Forfeited | (1,254 | ) |  | 34.12 |  |
| Vested | (3,939 | ) |  | 29.42 |  |
| Balance—December 31, 2017 | 8,516 |  |  | $ | 34.79 |  |

[0001262039-18-000009:notes:80]
As of December 31, 2017, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $249.2 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.57 years.

[0001262039-18-000009:notes:81]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding taxes. Total payment for the employees’ tax obligations to the taxing authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-18-000009:notes:82]
Employee Stock Options

[0001262039-18-000009:notes:83]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-18-000009:notes:84]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-18-000009:notes:85]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-18-000009:notes:86]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-18-000009:notes:87]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-18-000009:notes:88]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-18-000009:notes:89]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-18-000009:notes:90]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2014 | 10,702 |  |  | $ | 14.98 |  |  |  |  |  |
| Granted | 819 |  |  | 39.50 |  |  |  |  |  |
| Forfeited | (150 | ) |  | 28.67 |  |  |  |  |  |
| Exercised | (4,403 | ) |  | 11.10 |  |  |  |  |  |
| Balance—December 31, 2015 | 6,968 |  |  | 20.03 |  |  |  |  |  |
| Granted | 1,468 |  |  | 25.65 |  |  |  |  |  |
| Forfeited | (268 | ) |  | 34.82 |  |  |  |  |  |
| Exercised | (1,981 | ) |  | 10.45 |  |  |  |  |  |
| Balance—December 31, 2016 | 6,187 |  |  | 23.79 |  |  |  |  |  |  |
| Granted | 555 |  |  | 37.34 |  |  |  |  |  |
| Forfeited | (209 | ) |  | 31.75 |  |  |  |  |  |
| Exercised | (2,209 | ) |  | 19.19 |  |  |  |  |  |
| Balance—December 31, 2017 | 4,324 |  |  | $ | 27.50 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2017 | 4,324 |  |  | $ | 27.50 |  |  | 3.18 |  | $ | 70,853 |  |
| Options exercisable—December 31, 2017 | 2,908 |  |  | $ | 25.46 |  |  | 2.07 |  | $ | 53,569 |  |

[0001262039-18-000009:notes:91]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2017, for all in-the-money stock options. As of December 31, 2017, total compensation expense related to unvested stock options granted to employees but not yet recognized was $13.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.4 years.

[0001262039-18-000009:notes:92]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2017, as follows (in thousands, except exercise prices and contractual life):

[0001262039-18-000009:notes:93]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $19.94–19.94 |  | 29 |  |  | 2.85 |  | $ | 19.94 |  |  | 29 |  |  | $ | 19.94 |  |
| 20.13–24.92 |  | 2,164 |  |  | 2.79 |  | 22.43 |  |  | 1,596 |  |  | 21.94 |  |
| 26.49–26.70 |  | 912 |  |  | 1.18 |  | 26.70 |  |  | 906 |  |  | 26.70 |  |
| 31.39–33.31 |  | 461 |  |  | 4.80 |  | 32.71 |  |  | 239 |  |  | 32.79 |  |
| 36.70–48.83 |  | 758 |  |  | 5.72 |  | 40.13 |  |  | 138 |  |  | 46.56 |  |
|  |  | 4,324 |  |  |  |  |  |  | 2,908 |  |  |  |

[0001262039-18-000009:notes:94]
Employee Stock Purchase Plan

[0001262039-18-000009:notes:95]
In determining the fair value of the ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-18-000009:notes:96]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 29 | % |  | 39 | % |  | 30 | % |
| Risk-free interest rate | 0.9 | % |  | 0.4 | % |  | 0.2 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-18-000009:notes:97]
Shares Reserved for Future Issuances

[0001262039-18-000009:notes:98]
Stock-based Compensation Expense

[0001262039-18-000009:notes:99]
Stock-based compensation expense is included in costs and expenses as follows (in thousands):

[0001262039-18-000009:notes:100]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Cost of product revenue | $ | 1,380 |  |  | $ | 1,200 |  |  | $ | 973 |  |
| Cost of service revenue | 9,503 |  |  | 8,771 |  |  | 7,121 |  |
| Research and development | 32,194 |  |  | 30,120 |  |  | 24,555 |  |
| Sales and marketing | 77,994 |  |  | 68,113 |  |  | 49,436 |  |
| General and administrative | 16,112 |  |  | 14,219 |  |  | 13,003 |  |
| Total stock-based compensation expense | $ | 137,183 |  |  | $ | 122,423 |  |  | $ | 95,088 |  |

[0001262039-18-000009:notes:101]
Share Repurchase Program

[0001262039-18-000009:notes:102]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2017, we repurchased 11.2 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $446.3 million. As of December 31, 2017, $442.8 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-18-000009:notes:103]
NET INCOME PER SHARE

[0001262039-18-000009:notes:104]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of RSUs, stock options and the ESPP. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-18-000009:notes:105]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-18-000009:notes:106]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 31,399 |  |  | $ | 32,187 |  |  | $ | 7,987 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 174,315 |  |  | 172,621 |  |  | 170,385 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 174,315 |  |  | 172,621 |  |  | 170,385 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2,287 |  |  | 1,891 |  |  | 2,260 |  |
| Stock options | 1,426 |  |  | 1,757 |  |  | 3,427 |  |
| ESPP | 51 |  |  | 69 |  |  | 69 |  |
| Weighted-average shares used to compute diluted net income per share | 178,079 |  |  | 176,338 |  |  | 176,141 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.18 |  |  | $ | 0.19 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.18 |  |  | $ | 0.18 |  |  | $ | 0.05 |  |

[0001262039-18-000009:notes:107]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-18-000009:notes:108]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| RSUs | 1,418 |  |  | 3,319 |  |  | 1,393 |  |
| Stock options | 1,031 |  |  | 1,024 |  |  | 382 |  |
| ESPP | 156 |  |  | 159 |  |  | 94 |  |
|  | 2,605 |  |  | 4,502 |  |  | 1,869 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-18-000009:notes:109]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-18-000009:notes:110]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in thousands):

[0001262039-18-000009:notes:111]
|  | December 31, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317,412 |  |  | $ | (871 | ) |  | $ | 58,161 |  |  | $ | (308 | ) |  | $ | 375,573 |  |  | $ | (1,179 | ) |
| Certificates of deposit and term deposits | 37,229 |  |  | (16 | ) |  | — |  |  | — |  |  | 37,229 |  |  | (16 | ) |
| Commercial paper | 29,044 |  |  | (8 | ) |  | — |  |  | — |  |  | 29,044 |  |  | (8 | ) |
| U.S. government and agency securities | 16,967 |  |  | (21 | ) |  | 11,441 |  |  | (58 | ) |  | 28,408 |  |  | (79 | ) |
| Total available-for-sale securities | $ | 400,652 |  |  | $ | (916 | ) |  | $ | 69,602 |  |  | $ | (366 | ) |  | $ | 470,254 |  |  | $ | (1,282 | ) |

[0001262039-18-000009:notes:112]
|  | December 31, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 311,980 |  |  | $ | (910 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 325,521 |  |  | $ | (925 | ) |
| Municipal bonds | 52,200 |  |  | (235 | ) |  | — |  |  | — |  |  | 52,200 |  |  | (235 | ) |
| U.S. government and agency securities | 33,430 |  |  | (79 | ) |  | — |  |  | — |  |  | 33,430 |  |  | (79 | ) |
| Commercial paper | 17,394 |  |  | (25 | ) |  | — |  |  | — |  |  | 17,394 |  |  | (25 | ) |
| Total available-for-sale securities | $ | 415,004 |  |  | $ | (1,249 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 428,545 |  |  | $ | (1,264 | ) |

[0001262039-18-000009:notes:113]
The contractual maturities of our investments were as follows (in thousands):

[0001262039-18-000009:notes:114]
|  | December 31, 2017 |  | December 31, 2016 |
| Due within one year | $ | 440,273 |  |  | $ | 376,522 |  |
| Due within one to three years | 98,022 |  |  | 224,983 |  |
| Total | $ | 538,295 |  |  | $ | 601,505 |  |

[0001262039-18-000009:notes:115]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized losses on available-for-sale securities were $0.8 million in the periods presented and are included in Other income (expense)—net in our consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-18-000009:notes:116]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of December 31, 2017.

[0001262039-18-000009:notes:117]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-18-000009:notes:118]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-18-000009:notes:119]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-18-000009:notes:120]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-18-000009:notes:121]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-18-000009:notes:122]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-18-000009:notes:123]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-18-000009:notes:124]
Fair Value of Financial Instruments

[0001262039-18-000009:notes:125]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-18-000009:notes:126]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of December 31, 2017 and 2016 (in thousands):

[0001262039-18-000009:notes:127]
|  | December 31, 2017 |  |  |  | December 31, 2016 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 411,142 |  |  | $ | — |  |  | $ | 411,142 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |
| Money market funds | 195,592 |  |  | 195,592 |  |  | — |  |  | — |  |  | 38,649 |  |  | 38,649 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits (1) | 132,070 |  |  | — |  |  | 132,070 |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Commercial paper | 128,890 |  |  | — |  |  | 128,890 |  |  | — |  |  | 105,097 |  |  | — |  |  | 105,097 |  |  | — |  |
| U.S. government and agency securities | 28,408 |  |  | 24,952 |  |  | 3,456 |  |  | — |  |  | 64,541 |  |  | 52,082 |  |  | 12,459 |  |  | — |  |
| Municipal bonds | — |  |  | — |  |  | — |  |  | — |  |  | 59,025 |  |  | — |  |  | 59,025 |  |  | — |  |
| Total | $ | 896,102 |  |  | $ | 220,544 |  |  | $ | 675,558 |  |  | $ | — |  |  | $ | 705,403 |  |  | $ | 90,731 |  |  | $ | 614,672 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 357,807 |  |  |  |  |  |  |  |  | $ | 103,898 |  |  |  |  |  |  |  |
| Short-term investments | 440,273 |  |  |  |  |  |  |  |  | 376,522 |  |  |  |  |  |  |  |
| Long-term investments | 98,022 |  |  |  |  |  |  |  |  | 224,983 |  |  |  |  |  |  |  |
| Total | $ | 896,102 |  |  |  |  |  |  |  |  | $ | 705,403 |  |  |  |  |  |  |  |

[0001262039-18-000009:notes:128]
(1) Subsequent to the issuance of our consolidated financial statements as of and for the year ended December 31, 2016, we determined that $55.3 million in 30-day term deposits, included within cash and cash equivalents in the consolidated balance sheet as of December 31, 2016, should have also been included as Level 2 investments in the fair value hierarchy table for financial assets and financial liabilities measured at fair value on a recurring basis. Accordingly, we have corrected the above table as of December 31, 2016, the effect of which is immaterial to the financial statements as a whole.

[0001262039-18-000009:notes:129]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the year ended December 31, 2017 and December 31, 2016.

[0001262039-18-000009:notes:130]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001262039-18-000009:notes:131]
We measure certain assets, including goodwill, other intangible assets—net and investments in privately held companies at fair value on a nonrecurring basis when there are identifiable events or changes in circumstances that may have a significant adverse impact on the fair value of these assets.

[0001262039-18-000009:notes:132]
During the second quarter of 2015, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationship acquired from the Coyote Point Systems (“Coyote”) business acquisition. Based on this reassessment, we determined a decrease in the projected cash flow and that the remaining net book value of the developed technologies and customer relationships were impaired. As a result, we recorded an impairment charge of $1.6 million associated with these assets. The impairment charge is included within cost of product revenue and sales and marketing in the consolidated statements of operations.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-18-000009:notes:133]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-18-000009:notes:134]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-18-000009:notes:135]
Goodwill

[0001262039-18-000009:notes:136]
As of December 31, 2017, we had goodwill of $14.6 million. There were no impairments to goodwill during 2017 or during prior periods.

[0001262039-18-000009:notes:137]
Other Intangible Assets—net

[0001262039-18-000009:notes:138]
The following tables present other intangible assets—net as of December 31, 2017 and 2016 (in thousands, except years):

[0001262039-18-000009:notes:139]
|  | December 31, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 13,750 |  |  | $ | 10,234 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 10,079 |  |  | 4,421 |  |
|  |  |  | 38,484 |  |  | 23,829 |  |  | 14,655 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 23,829 |  |  | $ | 16,255 |  |

[0001262039-18-000009:notes:140]
|  | December 31, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 8,750 |  |  | $ | 15,234 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 6,506 |  |  | 7,994 |  |
|  |  |  | 38,484 |  |  | 15,256 |  |  | 23,228 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 15,256 |  |  | $ | 24,828 |  |

[0001262039-18-000009:notes:141]
The in-process research and development intangible asset of $1.6 million is expected to be completed in the first quarter of 2018. Upon completion, the cost will be transferred to developed technology and will be amortized over the remaining estimated useful life of the asset. Amortization expense was $8.6 million, $9.3 million, and $3.2 million in 2017, 2016 and 2015, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in thousands):

[0001262039-18-000009:notes:142]
|  | Amount |
| Years: |  |
| 2018 | $ | 6,885 |  |
| 2019 | 5,407 |  |
| 2020 | 2,363 |  |
| Total | $ | 14,655 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001262039-18-000009:notes:143]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-18-000009:notes:144]
INCOME TAXES

[0001262039-18-000009:notes:145]
Income before income taxes consisted of the following (in thousands):

[0001262039-18-000009:notes:146]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Domestic | $ | (40,709 | ) |  | $ | (49,707 | ) |  | $ | (37,437 | ) |
| Foreign | 164,703 |  |  | 92,855 |  |  | 54,442 |  |
| Total income before income taxes | $ | 123,994 |  |  | $ | 43,148 |  |  | $ | 17,005 |  |

[0001262039-18-000009:notes:147]
The provision for income taxes consisted of the following (in thousands):

[0001262039-18-000009:notes:148]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Current: |  |  |  |  |  |
| Federal | $ | 34,739 |  |  | $ | 7,904 |  |  | $ | 9,864 |  |
| State | 816 |  |  | 803 |  |  | (136 | ) |
| Foreign | 27,688 |  |  | 17,829 |  |  | 13,683 |  |
| Total current | $ | 63,243 |  |  | $ | 26,536 |  |  | $ | 23,411 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | 39,103 |  |  | $ | (10,037 | ) |  | $ | (9,383 | ) |
| State | (9,333 | ) |  | (4,861 | ) |  | (2,988 | ) |
| Foreign | (418 | ) |  | (677 | ) |  | (2,022 | ) |
| Total deferred | 29,352 |  |  | (15,575 | ) |  | (14,393 | ) |
| Provision for income taxes | $ | 92,595 |  |  | $ | 10,961 |  |  | $ | 9,018 |  |

[0001262039-18-000009:notes:149]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in thousands):

[0001262039-18-000009:notes:150]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Tax at federal statutory tax rate | $ | 43,398 |  |  | $ | 15,096 |  |  | $ | 5,951 |  |
| Foreign income taxed at different rates | (19,536 | ) |  | (13,681 | ) |  | (11,225 | ) |
| Foreign withholding taxes | 17,445 |  |  | 14,998 |  |  | 10,962 |  |
| Stock-based compensation expense | 9,502 |  |  | 10,010 |  |  | 6,369 |  |
| Foreign tax credit | (12,795 | ) |  | (34,992 | ) |  | (6,901 | ) |
| State taxes—net of federal benefit | (3,505 | ) |  | (4,252 | ) |  | (2,454 | ) |
| Research and development credit | (4,009 | ) |  | (2,713 | ) |  | (3,529 | ) |
| Dividend distribution | — |  |  | 27,295 |  |  | 9,647 |  |
| Impact of the 2017 Tax Act: |  |  |  |  |  |
| Deferred tax asset remeasurement due to reduction in the federal corporate income tax rate | 47,878 |  |  | — |  |  | — |  |
| One-time transition tax | 15,222 |  |  | — |  |  | — |  |
| Other | (1,005 | ) |  | (800 | ) |  | 198 |  |
| Total provision for income taxes | $ | 92,595 |  |  | $ | 10,961 |  |  | $ | 9,018 |  |

[0001262039-18-000009:notes:151]
Significant permanent differences arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock option grants to certain foreign employees, offset by the actual tax benefits in the current periods from disqualifying dispositions of shares held by our U.S. employees. For stock options exercised by our U.S. employees, we receive an income tax benefit calculated as the difference between the fair market value of the stock issued at the time of the exercise and the option price, tax effected. In 2017, the excess tax benefits of $13.5 million were recognized in income tax provision due to the adoption of ASU 2016-09. In 2016, the excess tax benefits of $10.8 million were recognized in income tax provision. For 2015, income tax payable was reduced by excess tax benefits from the exercise or vesting of stock-based awards of $1.3 million.

[0001262039-18-000009:notes:152]
In December 2017, the U.S. federal government enacted the Tax Cuts and Jobs Act (the “2017 Tax Act”). The 2017 Tax Act reduced the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate.

[0001262039-18-000009:notes:153]
The Securities and Exchange Commission (“SEC”) staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the 2017 Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the 2017 Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the 2017 Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the 2017 Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the 2017 Tax Act.

[0001262039-18-000009:notes:154]
Consistent with the guidance issued by the SEC, which provides for a measurement period of one year from the enactment date to finalize the accounting for effects of the 2017 Tax Act, we provisionally recorded a $47.9 million expense on the remeasurement of deferred tax assets due to the reduction of federal corporate income tax rate, and a $15.2 million expense for the one-time transition tax on deemed repatriation. We are able to make a reasonable estimate of the transition tax. However, we are continuing to gather additional information to more precisely compute the amount of the transition tax.

[0001262039-18-000009:notes:155]
The 2017 Tax Act creates a new requirement that global intangible low-taxed income (“GILTI”) earned by controlled foreign corporations (“CFCs”) must be included currently in the gross income of the CFCs’ U.S. shareholder. Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the 2017 Tax Act and the application of ASC 740. Under GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). Our selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be. We have not yet made any adjustments related to potential GILTI tax in our financial statements and have not made a policy decision regarding whether to record deferred taxes on GILTI.

[0001262039-18-000009:notes:156]
During 2016, we repatriated $55.0 million of foreign earnings and profits. A decision was made to bring this cash back to the United States as it carried a foreign tax credit of $22.3 million. Our 2015 income tax provision reflected a $1.2 million tax benefit due to a recent U.S. Tax Court opinion involving an independent third party filed on July 27, 2015. Based on the findings of the U.S. Tax Court, we recognized the tax benefit for excluding the share-based compensation from intercompany charges in prior periods. During 2015, we completed a corporate reorganization to convert our Canadian company to a branch of our U.S. company resulting on a $27.6 million deemed dividend distribution. The tax impact of the Canadian deemed dividend distribution of $9.6 million was partially offset by an additional tax benefit of $6.4 million due to the deferred tax benefit of the Canadian stock based compensation expense.

[0001262039-18-000009:notes:157]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in thousands):

[0001262039-18-000009:notes:158]
|  | December 31, 2017 |  | December 31, 2016 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 49,854 |  |  | $ | 62,705 |  |
| Deferred revenue | 37,432 |  |  | 41,877 |  |
| Nondeductible reserves and accruals | 22,966 |  |  | 27,029 |  |
| Net operating loss carryforward | 15,670 |  |  | 24,348 |  |
| Stock-based compensation expense | 12,265 |  |  | 20,943 |  |
| Depreciation and amortization | 8,753 |  |  | 5,776 |  |
| Other | (8 | ) |  | 67 |  |
| Total deferred tax assets | $ | 146,932 |  |  | $ | 182,745 |  |

[0001262039-18-000009:notes:159]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we would be able to realize the benefits of our deferred tax assets in the future.

[0001262039-18-000009:notes:160]
As of December 31, 2017, we had $42.4 million in federal net operating loss carryforwards to offset future income, which is limited by Section 382 of the Internal Revenue Code (“Section 382”) due to the acquisition of Meru and AccelOps. With the acquisition of Meru, we had $22.6 million in federal net operating loss carryforwards which is limited by Section 382 available from year 2020. With the acquisition of AccelOps, we had $19.9 million in federal net operating loss carryforwards which is limited by Section 382 available from year 2016. We had $25.6 million federal tax credits to offset future federal taxes. As of December 31, 2017, we had $36.7 million in California net operating loss carryforwards. With the acquisition of Meru and AccelOps, we also had $22.1 million and $14.6 million in California net operating loss carryforwards, respectively, which is subject to Section 382 limitation. We had state tax credit carryforwards of $21.7 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-18-000009:notes:161]
We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to a repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. For those investments from which we were not able to make a reasonable estimate, we have not recorded any deferred taxes. We will record the tax effects of any change in our prior assertion with respect to these investments, and disclose any unrecognized deferred tax liability for temporary differences related to our foreign investments, if practicable, in the period that we are first able to make a reasonable estimate, no later than December 2018.

[0001262039-18-000009:notes:162]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2021, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-18-000009:notes:163]
As of December 31, 2017, we had $72.5 million of unrecognized tax benefits, of which, if recognized, $70.8 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2017, 2016 and 2015, accrued interest and penalties were $13.5 million, $9.5 million and $5.5 million, respectively.

[0001262039-18-000009:notes:164]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in thousands):

[0001262039-18-000009:notes:165]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Unrecognized tax benefits, beginning of year | $ | 65,534 |  |  | $ | 59,672 |  |  | $ | 44,151 |  |
| Gross increases for tax positions related to the current year | 13,166 |  |  | 4,837 |  |  | 17,478 |  |
| Gross decreases for tax positions related to the current year | (10,747 | ) |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 7,049 |  |  | 1,762 |  |  | 8,319 |  |
| Gross decreases for tax positions related to prior year | (874 | ) |  | (737 | ) |  | (9,207 | ) |
| Gross decreases for tax positions related to expiration of statute of limitations | (1,584 | ) |  | — |  |  | (1,069 | ) |
| Unrecognized tax benefits, end of year | $ | 72,544 |  |  | $ | 65,534 |  |  | $ | 59,672 |  |

[0001262039-18-000009:notes:166]
As of December 31, 2017, 2016 and 2015, $90.2 million, $68.6 million and $60.6 million, respectively, of the amounts reflected above were recorded as Income tax liabilities—non-current in our consolidated balance sheet.

[0001262039-18-000009:notes:167]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $12.0 million in the next 12 months, primarily due to the lapse of the statute of limitations and audit settlement. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000009:notes:168]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We have closed the Internal Revenue Service audit for tax years 2012, 2013 and 2014 at the field level. This audit included a refund claim for $6.5 million, which was approved in the audit process. This refund claim was sent to the Joint Committee in Washington for the final review on January 18, 2018, and was approved on January 31, 2018 and will result in a benefit to the tax provision in 2018 by approximately $3.0 million. In addition, the tax authorities in France are examining the intercompany relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In May 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015.


## us-gaap:IncomeTaxPolicyTextBlock

[0001262039-18-000009:notes:169]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-18-000009:notes:170]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-18-000009:notes:171]
INVENTORY

[0001262039-18-000009:notes:172]
Inventory consisted of the following (in thousands):

[0001262039-18-000009:notes:173]
|  | December 31, 2017 |  | December 31, 2016 |
| Raw materials | $ | 13,042 |  |  | $ | 18,924 |  |
| Finished goods | 64,249 |  |  | 87,963 |  |
| Inventory | $ | 77,291 |  |  | $ | 106,887 |  |

[0001262039-18-000009:notes:174]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $0.1 million and $1.0 million as of December 31, 2017 and 2016, respectively. Inventory also includes materials at contract manufacturers of $2.6 million and $6.1 million as of December 31, 2017 and 2016, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001262039-18-000009:notes:175]
Inventory—As of December 31, 2016, inventory is recorded at the lower of cost or market. On January 1, 2017, we adopted Accounting Standards Update (“ASU”) 2015-11—Inventory: Simplifying the Measurement of Inventory. As such, as of December 31, 2017, inventory is recorded at the lower of cost or net realizable value. Adoption of ASU 2015-11 did not have an impact on our consolidated financial statements. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001262039-18-000009:notes:176]
Leases—We rent certain facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-18-000009:notes:177]
| Property and Equipment—net | December 31, 2017 |  | December 31, 2016 |
| Americas: |  |  |  |
| United States | $ | 115,606 |  |  | $ | 96,414 |  |
| Canada | 103,787 |  |  | 12,881 |  |
| LATAM | 342 |  |  | 607 |  |
| Total Americas | 219,735 |  |  | 109,902 |  |
| EMEA: |  |  |  |
| France | 11,846 |  |  | 13,241 |  |
| Other EMEA | 5,836 |  |  | 6,391 |  |
| Total EMEA | 17,682 |  |  | 19,632 |  |
| APAC | 7,978 |  |  | 7,715 |  |
| Total property and equipment—net | $ | 245,395 |  |  | $ | 137,249 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-18-000009:notes:178]
Recently Adopted Accounting Standards

[0001262039-18-000009:notes:179]
Measurement of Inventory

[0001262039-18-000009:notes:180]
In July 2015, the Financial Accounting Standards Board (the “FASB”) issued ASU 2015-11—Inventory: Simplifying the Measurement of Inventory, which requires entities to measure most inventory at the lower of cost and net realizable value, replacing the former methodology of measuring inventory at the lower of cost or market. We adopted ASU 2015-11 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2015-11 did not have an impact on our consolidated financial statements.

[0001262039-18-000009:notes:181]
Statement of Cash Flows - Restricted Cash

[0001262039-18-000009:notes:182]
In August 2016, the FASB issued ASU 2016-18—Statement of Cash Flows: Restricted Cash, which addresses the presentation of restricted cash in the statement of cash flows. Under ASU 2016-18, restricted cash or restricted cash equivalents should be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU 2016-18 is effective for us beginning on January 1, 2018 and will be applied on a retrospective basis. Early adoption is permitted. We elected to early adopt ASU 2016-18 on January 1, 2017. The adoption did not have a material impact on our consolidated financial statements.

[0001262039-18-000009:notes:183]
Business Combinations – Definition of a Business

[0001262039-18-000009:notes:184]
In January 2017, the FASB issued ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

[0001262039-18-000009:notes:185]
Goodwill Impairment

[0001262039-18-000009:notes:186]
In January 2017, the FASB issued ASU 2017-04—Intangibles—Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test, which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2017-04 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, ASU 2017-04 requires a prospective approach. We early adopted ASU 2017-04 on October 1, 2017, and the adoption did not impact our consolidated financial statements.

[0001262039-18-000009:notes:187]
Recent Accounting Standards Not Yet Effective

[0001262039-18-000009:notes:188]
Share-Based Payment Accounting

[0001262039-18-000009:notes:189]
In May 2017, the FASB issued ASU 2017-09—Compensation—Stock Compensation: Scope of Modification Accounting to clarify when to account for a change to the terms or conditions of a share-based payment award as a modification. Under ASU 2017-09, modification accounting is required only if the fair value, the vesting conditions or the classification of the award (as equity or liability) changes as a result of the change in terms or conditions. ASU 2017-09 is effective prospectively for us beginning on January 1, 2018. We adopted ASU 2017-09 on January 1, 2018. The adoption is not expected to have a material impact on our consolidated financial statements.

[0001262039-18-000009:notes:190]
Income Taxes – Intra-Entity Asset Transfers

[0001262039-18-000009:notes:191]
In October 2016, the FASB issued ASU 2016-16—Income Taxes—Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-16 is effective for us beginning on January 1, 2018. We adopted ASU 2016-16 on January 1, 2018. The adoption is not expected to have a material impact on our consolidated financial statements.

[0001262039-18-000009:notes:192]
Leases

[0001262039-18-000009:notes:193]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. ASU 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

[0001262039-18-000009:notes:194]
Financial Instruments – Recognition and Measurement

[0001262039-18-000009:notes:195]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception will apply to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 is effective for our cost-method investments beginning on January 1, 2018 on a prospective basis. We adopted ASU 2016-01 on January 1, 2018 and there was no material impact as of adoption date.

[0001262039-18-000009:notes:196]
Revenue Recognition

[0001262039-18-000009:notes:197]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under the legacy GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 is effective for us beginning on January 1, 2018. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We elected to adopt ASU 2014-09 using the modified retrospective method and will apply the standard to contracts that are not completed as of January 1, 2018, and will recognize the cumulative effect of initially applying the standard as an adjustment to the opening balance of accumulated deficit.

[0001262039-18-000009:notes:198]
We have completed our analysis of open revenue contracts as of January 1, 2018. Based on our assessment, the impact on revenue in our consolidated financial statements is not material. The impact on revenue primarily relates to the acceleration of revenue from U.S.-based channel partners, which were previously deferred until the product was sold through, and certain changes related to revenue recognized on software license sales. We expect the pattern of revenue recognition from direct sales of our FortiGate and other appliances and FortiGuard security subscription and FortiCare technical support services to be substantially unchanged on an ongoing basis. As of January 1, 2018, sales returns reserve will be presented as part of accrued liabilities as netting against accounts receivable is no longer allowed under ASU 2014-09.

[0001262039-18-000009:notes:199]
Under the legacy GAAP, we expensed all sales commissions when incurred. As of January 1, 2018, we will continue to expense commissions related to appliance sales when incurred, but will capitalize and recognize certain commissions on service contracts over the period of benefit. As part of the transition to the new accounting standard, we expect to capitalize at least $130.0 million of sales commissions as of January 1, 2018 that have been determined to be the remaining costs to obtain then-existing service contracts. Capitalized sales commissions will be amortized on a straight-line basis over the period of benefit for new business or the contract term for renewals.

[0001262039-18-000009:notes:200]
In the preparation for the adoption of ASU 2014-09, we have implemented internal controls and all necessary system functionality to enable the preparation of financial information and related disclosures in accordance with this standard.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-18-000009:notes:201]
PROPERTY AND EQUIPMENT—Net

[0001262039-18-000009:notes:202]
Property and equipment—net consisted of the following (in thousands):

[0001262039-18-000009:notes:203]
|  | December 31, 2017 |  | December 31, 2016 |
| Building and building improvements | $ | 133,212 |  |  | $ | 49,783 |  |
| Computer equipment and software | 79,911 |  |  | 65,323 |  |
| Land | 65,583 |  |  | 35,079 |  |
| Leasehold improvements | 20,777 |  |  | 18,699 |  |
| Evaluation units | 20,087 |  |  | 20,173 |  |
| Furniture and fixtures | 14,705 |  |  | 13,995 |  |
| Construction-in-progress | 6,275 |  |  | 4,669 |  |
| Total property and equipment | 340,550 |  |  | 207,721 |  |
| Less: accumulated depreciation | (95,155 | ) |  | (70,472 | ) |
| Property and equipment—net | $ | 245,395 |  |  | $ | 137,249 |  |

[0001262039-18-000009:notes:204]
Depreciation expense was $46.9 million, $39.2 million and $28.4 million in 2017, 2016 and 2015, respectively.

[0001262039-18-000009:notes:205]
In April 2017, we purchased certain real estate in Burnaby, Canada for $84.8 million. The purchase was accounted for under the asset acquisition method. The cost of the assets acquired was allocated to land and buildings based on their relative fair values. The amounts allocated to land and buildings were $12.7 million and $72.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-18-000009:notes:206]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-18-000009:notes:207]
RELATED PARTY TRANSACTIONS

[0001262039-18-000009:notes:208]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $1.1 million, $0.4 million and $7.2 million in 2017, 2016 and 2015, respectively. Of such amounts, $2.5 million was incurred under contingent fee arrangements in 2015. There were no expenses incurred under contingent fee arrangements in 2017 and 2016. Amounts due and payable to the law firm were $0.2 million and $0.1 million as of December 31, 2017 and December 31, 2016, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-18-000009:notes:209]
RESTRUCTURING CHARGES

[0001262039-18-000009:notes:210]
In 2016 and 2015, we implemented plans to restructure and further improve efficiencies in our operations due primarily to acquisitions of Meru and AccelOps. Restructuring charges related to these plans consisted primarily of employee severance and other one-time benefits paid in cash and are included in operating expense in the consolidated statements of operations. The restructuring reserve was included in accrued liabilities on the consolidated balance sheet as of December 31, 2017 and 2016. The restructuring activities were completed by the end of the third quarter of 2017.

[0001262039-18-000009:notes:211]
Activities related to the restructuring actions are summarized as follows (in thousands):

[0001262039-18-000009:notes:212]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Costs incurred | $ | 7,109 |  |  | $ | 491 |  |  | $ | 7,600 |  |
| Less cash payments | (3,104 | ) |  | (71 | ) |  | (3,175 | ) |
| Less non-cash items | (316 | ) |  | (191 | ) |  | (507 | ) |
| Balance as of December 31, 2015 | 3,689 |  |  | 229 |  |  | 3,918 |  |
| Costs incurred | 3,246 |  |  | 751 |  |  | 3,997 |  |
| Less cash payments | (5,933 | ) |  | (664 | ) |  | (6,597 | ) |
| Less non-cash items | (89 | ) |  | (78 | ) |  | (167 | ) |
| Balance as of December 31, 2016 | 913 |  |  | 238 |  |  | 1,151 |  |
| Costs incurred | 294 |  |  | 46 |  |  | 340 |  |
| Less cash payments | (1,207 | ) |  | (284 | ) |  | (1,491 | ) |
| Less non-cash items | — |  |  | — |  |  | — |  |
| Balance as of December 31, 2017 | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-18-000009:notes:213]
|  | Year Ended December 31, |
| Revenue | 2017 |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |  |
| United States | $ | 496,967 |  |  | $ | 426,406 |  |  | $ | 347,905 |  |
| Latin America (“LATAM”) | 92,081 |  |  | 66,026 |  |  | 54,124 |  |
| Canada (1) | 53,283 |  |  | 44,274 |  |  | 33,253 |  |
| Total Americas | 642,331 |  |  | 536,706 |  |  | 435,282 |  |
| Europe, Middle East and Africa (“EMEA”) | 554,569 |  |  | 477,393 |  |  | 366,018 |  |
| Asia Pacific (“APAC”) | 298,030 |  |  | 261,344 |  |  | 207,968 |  |
| Total revenue | $ | 1,494,930 |  |  | $ | 1,275,443 |  |  | $ | 1,009,268 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001262039-18-000009:notes:214]
Revenue Recognition—We derive the majority of our revenue from sales of our hardware, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-18-000009:notes:215]
Revenue is recognized when all of the following criteria have been met:

[0001262039-18-000009:notes:216]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-18-000009:notes:217]
| • | Delivery has occurred or services have been rendered. Product delivery occurs when we fulfill an order and title and risk of loss has been transferred. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and, to a lesser extent, five years, and is generally recognized upon delivery or completion of service. |

[0001262039-18-000009:notes:218]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-18-000009:notes:219]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-18-000009:notes:220]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is typically not fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-18-000009:notes:221]
We recognize software license revenue upon electronic transfer of the license key to the customer. To date, software license revenues have not represented a significant percentage of our total revenue.

[0001262039-18-000009:notes:222]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel and hardware support. We recognize revenue from these services ratably over the contractual service period. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement.

[0001262039-18-000009:notes:223]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-18-000009:notes:224]
Service revenue consists of sales from our FortiGuard security subscription and FortiCare technical support services, professional and training services and other services that include SaaS and IaaS (both of which are hosted or cloud-based services). We recognize revenue from these arrangements as the subscription service is delivered over the term which is typically one year or on a monthly usage basis. To date, SaaS and IaaS revenues have not represented a significant percentage of our total revenue.

[0001262039-18-000009:notes:225]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using VSOE of selling price, if it exists, or TPE of selling price. If neither VSOE nor TPE of selling price exists for a deliverable, we use our BESP for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element. Revenue is reported net of sales taxes.

[0001262039-18-000009:notes:226]
For our hardware products, we use BESP as our selling price. For our support, software licenses and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-18-000009:notes:227]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0001262039-18-000009:notes:228]
The estimated useful life and fair values of the acquired identifiable intangible assets were as follows (in thousands, except for estimated useful life):


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001262039-18-000009:notes:229]
There were no outstanding forward exchange contracts as of December 31, 2017. The notional amount of forward exchange contracts to hedge balance sheet accounts December 31, 2016 were (in thousands):

[0001262039-18-000009:notes:230]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of December 31, 2016 |  |  |  |
| CAD | Sell |  | $ | 2,615 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-18-000009:notes:231]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-18-000009:notes:232]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands) |
| Sales Returns Reserve and Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 11,235 |  |  | $ | 6,228 |  |  | $ | 6,204 |  |
| Charged to costs and expenses, net of deductions | 3,268 |  |  | 5,007 |  |  | 24 |  |
| Ending balance | $ | 14,503 |  |  | $ | 11,235 |  |  | $ | 6,228 |  |

[0001262039-18-000009:notes:233]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-18-000009:notes:234]
| 3. | Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K. |

[0001262039-18-000009:notes:235]
(b) Exhibits:

[0001262039-18-000009:notes:236]
The exhibit list in the Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-18-000009:notes:237]
(c) Financial Statement Schedules: See Item 15(a) above.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-18-000009:notes:238]
SEGMENT INFORMATION

[0001262039-18-000009:notes:239]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-18-000009:notes:240]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment—net by geographic region (in thousands):

[0001262039-18-000009:notes:241]
(1) Certain amounts in the prior periods in Canada were reclassified to the United States to conform with the 2017 presentation as a result of a change in the bill-to address of a customer.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001262039-18-000009:notes:242]
Shipping and Handling—Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-18-000009:notes:243]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-18-000009:notes:244]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a global leader in broad, automated and integrated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as enterprises, data centers and distributed offices, including a majority of the Fortune 100 companies. Fortinet’s cybersecurity solutions are designed to provide broad, automated and integrated protection against dynamic and sophisticated security threats, while simplifying the information technology and security infrastructure of our end-customers.

[0001262039-18-000009:notes:245]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the best estimate of selling price (“BESP”) for our products and services, stock-based compensation, inventory valuation, fair value of assets acquired and liabilities assumed in business combinations, measurement of liabilities for uncertain tax positions and deferred tax assets, assessment of recoverability of our goodwill and other long-lived assets, sales returns reserve, restructuring expenses and other loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-18-000009:notes:246]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses. As of December 31, 2017, one distributor, Exclusive Networks Group (“Exclusive”), accounted for 35% of total net accounts receivable. In July 2017, Exclusive acquired the U.S. division of Fine Tec Computers (“Fine Tec U.S.”). Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive’s from the date of acquisition. As of December 31, 2016, two distributors, Exclusive and Fine Tec Computers, accounted for 26% and 10% of total net accounts receivable, respectively.

[0001262039-18-000009:notes:247]
During 2015, 2016 and 2017, Exclusive accounted for 18%, 20% and 25% of total revenue, respectively.

[0001262039-18-000009:notes:248]
Financial Instruments and Fair Value—We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-18-000009:notes:249]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period. Foreign currency remeasurement gains (losses) of $1.0 million, $(6.6) million and $(3.2) million are included in other income (expense)—net for 2017, 2016 and 2015, respectively.

[0001262039-18-000009:notes:250]
Other Investments—Investments in privately held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets and are accounted for under the cost method. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts as well as current fundraising activities and valuations based on information provided by these privately held companies. If it is determined that an other-than-temporary decline exists in an equity security, we write down the investment to its fair value and record the related impairment as an investment loss in our consolidated statements of operations.

[0001262039-18-000009:notes:251]
Consolidation of Variable Interest Entities—We use a qualitative approach in assessing the consolidation requirement for variable interest entities (“VIEs”). This approach focuses on determining whether we have the power to direct the activities of the VIE that most significantly affect the VIE’s economic performance and whether we have the obligation to absorb losses, or the right to receive benefits, that could potentially be significant to the VIE. For all periods presented in the accompanying consolidated financial statements, we have determined that we are not the primary beneficiary of any VIEs.

[0001262039-18-000009:notes:252]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-18-000009:notes:253]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-18-000009:notes:254]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2017, we had one reporting unit.

[0001262039-18-000009:notes:255]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line and accelerated method over the estimated economic lives of the assets, which range from one to five years.

[0001262039-18-000009:notes:256]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-18-000009:notes:257]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our employee stock purchase plan (“ESPP”). Stock-based compensation expense is amortized on a straight-line basis over the service period.

[0001262039-18-000009:notes:258]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of operations. Our advertising expenses were not significant for any periods presented.

[0001262039-18-000009:notes:259]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-18-000009:notes:260]
Commission Expense—We recognize commission expense on both product sales and service contracts at the time of sale.

[0001262039-18-000009:notes:261]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of operations.

[0001262039-18-000009:notes:262]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-18-000009:notes:263]
Shipping and Handling—Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during 2017, 2016 and 2015.

[0001262039-18-000009:notes:264]
Accounts Receivable—Trade accounts receivable are recorded at the invoiced amount, net of sales returns reserve and allowances for doubtful accounts. The sales returns reserve is determined based on specific criteria including agreements to provide rebates and other factors known at the time, as well as estimates of the amount of goods shipped that will be returned. To determine the adequacy of the sales returns reserve, we analyze historical experience of actual rebates and returns as well as distributor inventory levels. The sales returns reserve was $13.6 million and $10.3 million as of December 31, 2017 and 2016, respectively. The allowance for doubtful accounts is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.9 million as of December 31, 2017 and 2016.

[0001262039-18-000009:notes:265]
Warranties—We generally provide a 1-year warranty on hardware products and a 90-day warranty on software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of sales or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2017 and 2016.

[0001262039-18-000009:notes:266]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), the Euro (“EUR”) and the British pound (“GBP”). To help protect against significant fluctuations in the value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to minimize the impact of balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have a maturity of one month. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other income (expense)—net in the consolidated statement of operations.

[0001262039-18-000009:notes:267]
Additionally, independent of our use of foreign currency risk management activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on the CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR and GBP, could adversely impact our operating expenses in the future.
