# FTNT 8-K — 0001262039-18-000004 filed 2018-02-05

## item codes, every 8-K on or before 2018-02-26

- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2018-02-26

- none on or before 2018-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001262039-18-000004:8k_2_02:1]
EX-99.1
2
ftntq4-2017ex991.htm
EXHIBIT 99.1

[0001262039-18-000004:8k_2_02:2]
Exhibit

[0001262039-18-000004:8k_2_02:3]
Press Release

[0001262039-18-000004:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |

[0001262039-18-000004:8k_2_02:5]
Fortinet Reports Fourth Quarter and Full Year 2017 Financial Results

[0001262039-18-000004:8k_2_02:6]
Fortinet Reports Full Year Revenue Up 17% and Billings Up 19% over 2016

[0001262039-18-000004:8k_2_02:7]
Fourth Quarter 2017 Highlights

[0001262039-18-000004:8k_2_02:8]
| • | Revenue of $416.7 million, up 15% year over year |

[0001262039-18-000004:8k_2_02:9]
| • | Billings of $534.0 million, up 15% year over year1 |

[0001262039-18-000004:8k_2_02:10]
| • | Deferred revenue of $1.34 billion, up 29% year over year |

[0001262039-18-000004:8k_2_02:11]
| • | GAAP diluted net loss per share of $0.17, including the impact of a one-time tax expense of $63.0 million, or $0.36 per share, related to new tax legislation |

[0001262039-18-000004:8k_2_02:12]
| • | Non-GAAP diluted net income per share of $0.321 |

[0001262039-18-000004:8k_2_02:13]
| • | Cash flow from operations of $157.5 million |

[0001262039-18-000004:8k_2_02:14]
| • | Free cash flow of $143.9 million1 |

[0001262039-18-000004:8k_2_02:15]
| • | Cash, cash equivalents and investments of $1.35 billion |

[0001262039-18-000004:8k_2_02:16]
| • | $322.4 million in share repurchases |

[0001262039-18-000004:8k_2_02:17]
Full Year 2017 Highlights

[0001262039-18-000004:8k_2_02:18]
| • | Revenue of $1.49 billion, up 17% year over prior year |

[0001262039-18-000004:8k_2_02:19]
| • | Billings of $1.80 billion, up 19% year over prior year1 |

[0001262039-18-000004:8k_2_02:20]
| • | GAAP diluted net income per share of $0.18, including the impact of a one-time tax expense of $63.0 million, or $0.35 per share, related to new tax legislation |

[0001262039-18-000004:8k_2_02:21]
| • | Non-GAAP diluted net income per share grew 42% year over year to $1.041 |

[0001262039-18-000004:8k_2_02:22]
| • | Cash flow from operations of $594.4 million |

[0001262039-18-000004:8k_2_02:23]
| • | Free cash flow grew 65% year over year to $459.1 million1 |

[0001262039-18-000004:8k_2_02:24]
| • | $446.3 million in share repurchases |

[0001262039-18-000004:8k_2_02:25]
SUNNYVALE, Calif. - February 5, 2018 - Fortinet® (NASDAQ: FTNT), a global leader in broad, automated and integrated cyber security solutions, today announced financial results for the fourth quarter and full year ended December 31, 2017.

[0001262039-18-000004:8k_2_02:26]
“We are pleased with our strong fourth quarter and full year results, which demonstrate our clear technology advantage and market leadership,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “Our ability to provide our customers with broad, integrated and automated security across the entire network infrastructure sets us apart from our competition. Led by the innovation of the Fortinet Security Fabric, Fortinet has strong market momentum and is well positioned for robust future growth.”

[0001262039-18-000004:8k_2_02:27]
Financial Highlights for the Fourth Quarter of 2017

[0001262039-18-000004:8k_2_02:28]
| • | Revenue: Total revenue was $416.7 million for the fourth quarter of 2017, an increase of 15% compared to $362.8 million in the same quarter of 2016. |

[0001262039-18-000004:8k_2_02:29]
| • | Product revenue was $162.1 million for the fourth quarter of 2017, an increase of 2% compared to $158.9 million in the same quarter of 2016. Service revenue was $254.6 million for the fourth quarter of 2017, an increase of 25% compared to $203.9 million in the same quarter of 2016. |

[0001262039-18-000004:8k_2_02:30]
| • | Billings1: Total billings were $534.0 million for the fourth quarter of 2017, an increase of 15% compared to $463.4 million in the same quarter of 2016. |

[0001262039-18-000004:8k_2_02:31]
| • | Deferred Revenue: Total deferred revenue was $1.34 billion as of December 31, 2017, an increase of 29% compared to $1.04 billion as of December 31, 2016. |

[0001262039-18-000004:8k_2_02:32]
| • | GAAP Operating Income and Margin: GAAP operating income was $42.2 million for the fourth quarter of 2017, representing a GAAP operating margin of 10%. GAAP operating income was $45.2 million for the same quarter of 2016, representing a GAAP operating margin of 12%. |

[0001262039-18-000004:8k_2_02:33]
| • | Non-GAAP Operating Income1 and Margin1: Non-GAAP operating income was $78.7 million for the fourth quarter of 2017, representing a non-GAAP operating margin of 19%. Non-GAAP operating income was $81.1 million for the fourth quarter of 2016, representing a non-GAAP operating margin of 22%. |

[0001262039-18-000004:8k_2_02:34]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net loss was $29.0 million for the fourth quarter of 2017, compared to GAAP net income of $25.2 million for the same quarter of 2016. GAAP diluted net loss per share was $0.17 for the fourth quarter of 2017, based on 171.5 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.14 for the same quarter of 2016, based on 176.7 million diluted weighted-average shares outstanding. |

[0001262039-18-000004:8k_2_02:35]
| • | Impact of New Tax Legislation: Net loss in the fourth quarter of 2017 was impacted by a one-time tax expense of $63.0 million, or $0.36 per share, resulting from the Tax Cuts and Jobs Act (the “Act”) signed into law in December 2017. |

[0001262039-18-000004:8k_2_02:36]
| • | Non-GAAP Net Income1 and Diluted Net Income Per Share1: Non-GAAP net income was $55.5 million for the fourth quarter of 2017, compared to non-GAAP net income of $53.2 million for the same quarter of 2016. Non-GAAP diluted net income per share was $0.32 for the fourth quarter of 2017, based on 175.4 million diluted weighted-average shares outstanding, compared to $0.30 for the same quarter of 2016, based on 176.7 million diluted weighted-average shares outstanding. Non-GAAP effective tax rate remained at 32% in 2017 and was not impacted by the Act. |

[0001262039-18-000004:8k_2_02:37]
| • | Cash, Cash Flow and Free Cash Flow1: As of December 31, 2017, cash, cash equivalents and investments were $1.35 billion, compared to $1.52 billion as of September 30, 2017. In the fourth quarter of 2017, cash flow from operations was $157.5 million compared to $101.0 million in the same quarter of 2016. Free cash flow1 was $143.9 million during the fourth quarter of 2017 compared to $84.2 million in the same quarter of 2016. |

[0001262039-18-000004:8k_2_02:38]
| • | Share Repurchase: During the fourth quarter of 2017, Fortinet repurchased 7.9 million shares of its common stock for a total purchase price of $322.4 million. During the fourth quarter of 2016, Fortinet repurchased 1.2 million shares of its common stock for a total purchase price of $35.8 million. |

[0001262039-18-000004:8k_2_02:39]
Financial Highlights for the Full Year 2017

[0001262039-18-000004:8k_2_02:40]
| • | Revenue: Total revenue was $1.49 billion for 2017, an increase of 17% compared to $1.28 billion in 2016. |

[0001262039-18-000004:8k_2_02:41]
| • | Product revenue was $577.2 million for 2017, an increase of 5% compared to $548.1 million in 2016. Service revenue was $917.8 million for 2017, an increase of 26% compared to $727.3 million in 2016. |

[0001262039-18-000004:8k_2_02:42]
| • | Billings1: Total billings were $1.80 billion for 2017, an increase of 19% compared to $1.52 billion in 2016. |

[0001262039-18-000004:8k_2_02:43]
| • | GAAP Operating Income and Margin: GAAP operating income was $109.8 million for 2017, representing a GAAP operating margin of 7%. GAAP operating income was $42.9 million for 2016, representing a GAAP operating margin of 3%. |

[0001262039-18-000004:8k_2_02:44]
| • | Non-GAAP Operating Income1 and Margin1: Non-GAAP operating income was $257.4 million for 2017, representing a non-GAAP operating margin of 17%. Non-GAAP operating income was $193.1 million for 2016, representing a non-GAAP operating margin of 15%. |

[0001262039-18-000004:8k_2_02:45]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $31.4 million for 2017, compared to GAAP net income of $32.2 million for 2016. GAAP diluted net income per share was $0.18 for 2017, based on 178.1 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.18 for 2016, based on 176.3 million diluted weighted-average shares outstanding. |

[0001262039-18-000004:8k_2_02:46]
| • | Impact of New Tax Legislation: Net income for 2017 was impacted by a one-time tax expense of $63.0 million, or $0.35 per share, resulting from the Act. The effective GAAP tax rate was 75% in 2017, up from the 25% rate in 2016, reflecting the impact of the Act. Excluding the impact of the Act, the effective income tax rate for 2017 was 24%. |

[0001262039-18-000004:8k_2_02:47]
| • | Non-GAAP Net Income1 and Diluted Net Income Per Share1: Non-GAAP net income was $184.7 million for 2017, compared to non-GAAP net income of $129.5 million for 2016. Non-GAAP diluted net income per share was $1.04 for 2017, based on 178.1 million diluted weighted-average shares outstanding, compared to $0.73, based on 176.3 million diluted weighted-average shares outstanding, for 2016. Non-GAAP effective tax rate remained at 32% in 2017 and was not impacted by the Act. |

[0001262039-18-000004:8k_2_02:48]
| • | Cash Flow and Free Cash Flow1: In 2017, cash flow from operations was $594.4 million compared to $345.7 million in 2016. Free cash flow1 was $459.1 million in 2017 compared to $278.5 million in 2016. In 2017, Fortinet used $107.2 million for real estate purchases for its Canada and Sunnyvale offices. |

[0001262039-18-000004:8k_2_02:49]
| • | Share Repurchase: During 2017, Fortinet repurchased 11.2 million shares of its common stock for a total purchase price of $446.3 million. During 2016, Fortinet repurchased 3.9 million shares of its common stock for a total purchase price of $110.8 million. |

[0001262039-18-000004:8k_2_02:50]
Guidance

[0001262039-18-000004:8k_2_02:51]
For the first quarter of 2018, Fortinet expects:

[0001262039-18-000004:8k_2_02:52]
| • | Revenue in the range of $387.0 million to $393.0 million |

[0001262039-18-000004:8k_2_02:53]
| • | Billings in the range of $449.0 million to $457.0 million |

[0001262039-18-000004:8k_2_02:54]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000004:8k_2_02:55]
| • | Non-GAAP operating margin in the range of 12% to 13% |

[0001262039-18-000004:8k_2_02:56]
| • | Diluted non-GAAP earnings per share in the range of $0.21 to $0.22, assuming a non-GAAP tax rate of 24% |

[0001262039-18-000004:8k_2_02:57]
For the fiscal year of 2018, Fortinet expects:

[0001262039-18-000004:8k_2_02:58]
| • | Revenue in the range of $1.695 billion to $1.715 billion |

[0001262039-18-000004:8k_2_02:59]
| • | Billings in the range of $2.030 billion to $2.050 billion |

[0001262039-18-000004:8k_2_02:60]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000004:8k_2_02:61]
| • | Non-GAAP operating margin in the range of 17.7% to 18% |

[0001262039-18-000004:8k_2_02:62]
| • | Diluted non-GAAP earnings per share in the range of $1.30 to $1.32, assuming a non-GAAP tax rate of 24% |

[0001262039-18-000004:8k_2_02:63]
The above guidance for the first quarter and full year of 2018 excludes the transition impact of ASC 606 adoption, which is effective January 1, 2018. Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-18-000004:8k_2_02:64]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-18-000004:8k_2_02:65]
Keith Jensen Named Interim Chief Financial Officer - Effective February 16, 2018

[0001262039-18-000004:8k_2_02:66]
Keith Jensen, a 35-year finance veteran and Fortinet’s chief accounting officer since May 2014, will succeed CFO Drew Del Matto as interim CFO effective February 16, 2018. Keith served as chief administrative officer and chief accounting officer (CAO) at DataDirect Networks and CAO at Sybase. Before Sybase, Keith was chief financial officer of Dorado Network Systems. “The past four years have been incredibly rewarding and I am honored to have worked with Ken, Michael and the rest of the Fortinet team. I will miss them all and I am excited that Keith is taking over the interim CFO role," said Drew Del Matto, who is leaving for another opportunity.  “Over the last four years, Drew has made a strong impact on the business and significantly contributed to the company’s growth and profitability. During that time Drew has developed a deep bench of seasoned leaders and has built a strong financial organization to support and grow the business. We wish Drew the very best in his next endeavor and we thank him for his significant contributions," said Ken Xie.

[0001262039-18-000004:8k_2_02:67]
Conference Call Details

[0001262039-18-000004:8k_2_02:68]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 1373759. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through February 12, 2018, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #1373759.

[0001262039-18-000004:8k_2_02:69]
Following Fortinet’s financial results conference call, Fortinet will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed product and financial questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID #6075549. This call will be webcast live and accessible at http://investor.fortinet.com, and will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through February 12, 2018, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #6075549.

[0001262039-18-000004:8k_2_02:70]
First Quarter 2018 Analyst Day and Investor Conference Participation Schedule:

[0001262039-18-000004:8k_2_02:71]
| • | Goldman Sachs Technology & Internet Conference 2018 |

[0001262039-18-000004:8k_2_02:72]
February 13, 2018 - San Francisco, CA

[0001262039-18-000004:8k_2_02:73]
| • | Fortinet Analyst Day |

[0001262039-18-000004:8k_2_02:74]
February 27, 2018 - Las Vegas, NV

[0001262039-18-000004:8k_2_02:75]
| • | Morgan Stanley Technology, Media & Telecom Conference |

[0001262039-18-000004:8k_2_02:76]
March 1, 2018 - San Francisco, CA

[0001262039-18-000004:8k_2_02:77]
Members of Fortinet’s management team are expected to present at these events and discuss the latest company strategies and initiatives. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-18-000004:8k_2_02:78]
About Fortinet (www.fortinet.com)

[0001262039-18-000004:8k_2_02:79]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless

[0001262039-18-000004:8k_2_02:80]
protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-18-000004:8k_2_02:81]
#          #          #

[0001262039-18-000004:8k_2_02:82]
Copyright © 2017 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-18-000004:8k_2_02:83]
FTNT-F

[0001262039-18-000004:8k_2_02:84]
Forward-looking Statements

[0001262039-18-000004:8k_2_02:85]
Non-GAAP Financial Measures

[0001262039-18-000004:8k_2_02:86]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful

[0001262039-18-000004:8k_2_02:87]
to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-18-000004:8k_2_02:88]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-18-000004:8k_2_02:89]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-18-000004:8k_2_02:90]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. However, free cash flow is not intended to represent our residual cash flow available for discretionary expenditures, since we may have other non-discretionary expenditures that are not deducted from the measure. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-18-000004:8k_2_02:91]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial

[0001262039-18-000004:8k_2_02:92]
measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-18-000004:8k_2_02:93]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-18-000004:8k_2_02:94]
FORTINET, INC.

[0001262039-18-000004:8k_2_02:95]
CONSOLIDATED BALANCE SHEETS

[0001262039-18-000004:8k_2_02:96]
(Unaudited, in thousands)

[0001262039-18-000004:8k_2_02:97]
|  | December 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 811,004 |  |  | $ | 709,003 |  |
| Short-term investments | 440,273 |  |  | 376,522 |  |
| Accounts receivable—net | 348,185 |  |  | 312,998 |  |
| Inventory | 77,291 |  |  | 106,887 |  |
| Prepaid expenses and other current assets | 40,067 |  |  | 33,306 |  |
| Total current assets | 1,716,820 |  |  | 1,538,716 |  |
| LONG-TERM INVESTMENTS | 98,022 |  |  | 224,983 |  |
| PROPERTY AND EQUIPMENT—NET | 245,395 |  |  | 137,249 |  |
| DEFERRED TAX ASSETS | 146,932 |  |  | 182,745 |  |
| OTHER INTANGIBLE ASSETS—NET | 16,255 |  |  | 24,828 |  |
| GOODWILL | 14,553 |  |  | 14,553 |  |
| OTHER ASSETS | 19,939 |  |  | 16,867 |  |
| TOTAL ASSETS | $ | 2,257,916 |  |  | $ | 2,139,941 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 70,009 |  |  | $ | 56,732 |  |
| Accrued liabilities | 50,015 |  |  | 35,640 |  |
| Accrued payroll and compensation | 91,944 |  |  | 78,138 |  |
| Income taxes payable | 21,435 |  |  | 13,588 |  |
| Deferred revenue | 793,820 |  |  | 645,342 |  |
| Total current liabilities | 1,027,223 |  |  | 829,440 |  |
| DEFERRED REVENUE | 542,494 |  |  | 390,007 |  |
| INCOME TAX LIABILITIES | 90,213 |  |  | 68,551 |  |
| OTHER LIABILITIES | 8,609 |  |  | 14,262 |  |
| Total liabilities | 1,668,539 |  |  | 1,302,260 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 168 |  |  | 173 |  |
| Additional paid-in capital | 909,636 |  |  | 800,653 |  |
| Accumulated other comprehensive loss | (847 | ) |  | (765 | ) |
| Retained earnings (deficit) | (319,580 | ) |  | 37,620 |  |
| Total stockholders’ equity | 589,377 |  |  | 837,681 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,257,916 |  |  | $ | 2,139,941 |  |

[0001262039-18-000004:8k_2_02:98]
FORTINET, INC.

[0001262039-18-000004:8k_2_02:99]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-18-000004:8k_2_02:100]
(Unaudited, in thousands, except per share amounts)

[0001262039-18-000004:8k_2_02:101]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 162,118 |  |  | $ | 158,925 |  |  | $ | 577,171 |  |  | $ | 548,110 |  |
| Service | 254,550 |  |  | 203,905 |  |  | 917,759 |  |  | 727,333 |  |
| Total revenue | 416,668 |  |  | 362,830 |  |  | 1,494,930 |  |  | 1,275,443 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 69,634 |  |  | 56,616 |  |  | 243,824 |  |  | 208,984 |  |
| Service 1 | 35,785 |  |  | 34,275 |  |  | 141,460 |  |  | 128,853 |  |
| Total cost of revenue | 105,419 |  |  | 90,891 |  |  | 385,284 |  |  | 337,837 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 92,484 |  |  | 102,309 |  |  | 333,347 |  |  | 339,126 |  |
| Service | 218,765 |  |  | 169,630 |  |  | 776,299 |  |  | 598,480 |  |
| Total gross profit | 311,249 |  |  | 271,939 |  |  | 1,109,646 |  |  | 937,606 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 54,774 |  |  | 45,589 |  |  | 210,614 |  |  | 183,084 |  |
| Sales and marketing 1 | 191,928 |  |  | 162,873 |  |  | 701,026 |  |  | 626,501 |  |
| General and administrative 1 | 22,349 |  |  | 17,451 |  |  | 87,862 |  |  | 81,080 |  |
| Restructuring charges | — |  |  | 833 |  |  | 340 |  |  | 3,997 |  |
| Total operating expenses | 269,051 |  |  | 226,746 |  |  | 999,842 |  |  | 894,662 |  |
| OPERATING INCOME | 42,198 |  |  | 45,193 |  |  | 109,804 |  |  | 42,944 |  |
| INTEREST INCOME | 4,061 |  |  | 1,964 |  |  | 13,482 |  |  | 7,303 |  |
| OTHER INCOME (EXPENSE)—NET | (1,181 | ) |  | (3,650 | ) |  | 708 |  |  | (7,099 | ) |
| INCOME BEFORE INCOME TAXES | 45,078 |  |  | 43,507 |  |  | 123,994 |  |  | 43,148 |  |
| PROVISION FOR INCOME TAXES | 74,039 |  |  | 18,341 |  |  | 92,595 |  |  | 10,961 |  |
| NET INCOME (LOSS) | $ | (28,961 | ) |  | $ | 25,166 |  |  | $ | 31,399 |  |  | $ | 32,187 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.17 | ) |  | $ | 0.15 |  |  | $ | 0.18 |  |  | $ | 0.19 |  |
| Diluted | $ | (0.17 | ) |  | $ | 0.14 |  |  | $ | 0.18 |  |  | $ | 0.18 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 171,530 |  |  | 173,315 |  |  | 174,315 |  |  | 172,621 |  |
| Diluted | 171,530 |  |  | 176,679 |  |  | 178,079 |  |  | 176,338 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 341 |  |  | $ | 313 |  |  | $ | 1,380 |  |  | $ | 1,200 |  |
| Cost of service revenue | 2,349 |  |  | 2,276 |  |  | 9,503 |  |  | 8,771 |  |
| Research and development | 8,067 |  |  | 7,871 |  |  | 32,194 |  |  | 30,120 |  |
| Sales and marketing | 19,614 |  |  | 17,930 |  |  | 77,994 |  |  | 68,113 |  |
| General and administrative | 4,083 |  |  | 3,691 |  |  | 16,112 |  |  | 14,219 |  |
|  | $ | 34,454 |  |  | $ | 32,081 |  |  | $ | 137,183 |  |  | $ | 122,423 |  |

[0001262039-18-000004:8k_2_02:102]
FORTINET, INC.

[0001262039-18-000004:8k_2_02:103]
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-18-000004:8k_2_02:104]
(Unaudited, in thousands)

[0001262039-18-000004:8k_2_02:105]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Net income (loss) | $ | (28,961 | ) |  | $ | 25,166 |  |  | $ | 31,399 |  |  | $ | 32,187 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Change in unrealized gains (losses) on investments | (599 | ) |  | (1,411 | ) |  | (93 | ) |  | 258 |  |
| Tax provision (benefit) related to change in unrealized gains (losses) on investments | (168 | ) |  | (493 | ) |  | (11 | ) |  | 90 |  |
| Other comprehensive income (loss) | (431 | ) |  | (918 | ) |  | (82 | ) |  | 168 |  |
| Comprehensive income (loss) | $ | (29,392 | ) |  | $ | 24,248 |  |  | $ | 31,317 |  |  | $ | 32,355 |  |

[0001262039-18-000004:8k_2_02:106]
FORTINET, INC.

[0001262039-18-000004:8k_2_02:107]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-18-000004:8k_2_02:108]
(Unaudited, in thousands)

[0001262039-18-000004:8k_2_02:109]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (28,961 | ) |  | $ | 25,166 |  |  | $ | 31,399 |  |  | $ | 32,187 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 14,268 |  |  | 13,624 |  |  | 55,476 |  |  | 48,520 |  |
| Amortization of investment premiums | 417 |  |  | 952 |  |  | 2,542 |  |  | 4,780 |  |
| Stock-based compensation | 34,454 |  |  | 32,081 |  |  | 137,183 |  |  | 122,423 |  |
| Other non-cash items—net | 601 |  |  | (2,202 | ) |  | 3,780 |  |  | 2,644 |  |
| Changes in operating assets and liabilities, net of assets acquired and liabilities assumed in business acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable—net | (89,902 | ) |  | (70,663 | ) |  | (38,455 | ) |  | (57,875 | ) |
| Inventory | (8,264 | ) |  | (18,468 | ) |  | 9,423 |  |  | (43,023 | ) |
| Prepaid expenses and other current assets | 2,873 |  |  | (1,685 | ) |  | (6,726 | ) |  | 2,616 |  |
| Deferred tax assets | 57,957 |  |  | 7,183 |  |  | 35,824 |  |  | (27,822 | ) |
| Other assets | (641 | ) |  | 243 |  |  | (1,001 | ) |  | (2,352 | ) |
| Accounts payable | 29,627 |  |  | 1,623 |  |  | 13,090 |  |  | 39 |  |
| Accrued liabilities | 6,393 |  |  | (3,808 | ) |  | 14,445 |  |  | (3,210 | ) |
| Accrued payroll and compensation | 16,098 |  |  | 12,443 |  |  | 12,567 |  |  | 15,696 |  |
| Other liabilities | (1,659 | ) |  | (1,894 | ) |  | (5,489 | ) |  | (5,013 | ) |
| Deferred revenue | 116,489 |  |  | 100,094 |  |  | 300,839 |  |  | 242,961 |  |
| Income taxes payable | 7,792 |  |  | 6,348 |  |  | 29,508 |  |  | 13,137 |  |
| Net cash provided by operating activities | 157,542 |  |  | 101,037 |  |  | 594,405 |  |  | 345,708 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |
| Purchases of investments | (309,602 | ) |  | (103,035 | ) |  | (669,171 | ) |  | (473,608 | ) |
| Sales of investments | 290,322 |  |  | 6,506 |  |  | 300,317 |  |  | 28,311 |  |
| Maturities of investments | 98,231 |  |  | 115,484 |  |  | 427,363 |  |  | 460,443 |  |
| Purchases of property and equipment | (13,671 | ) |  | (16,863 | ) |  | (135,312 | ) |  | (67,182 | ) |
| Payments made in connection with business acquisitions, net of cash acquired | — |  |  | — |  |  | — |  |  | (22,087 | ) |
| Net cash provided by (used in) investing activities | 65,280 |  |  | 2,092 |  |  | (76,803 | ) |  | (74,123 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |
| Repurchase and retirement of common stock | (322,377 | ) |  | (35,828 | ) |  | (446,333 | ) |  | (110,828 | ) |
| Proceeds from issuance of common stock | 14,033 |  |  | 2,569 |  |  | 75,869 |  |  | 44,861 |  |
| Taxes paid related to net share settlement of equity awards | (9,268 | ) |  | (8,380 | ) |  | (45,137 | ) |  | (38,266 | ) |
| Payments of debt assumed in business acquisition | — |  |  | — |  |  | — |  |  | (1,626 | ) |
| Net cash used in financing activities | (317,612 | ) |  | (41,639 | ) |  | (415,601 | ) |  | (105,859 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | (94,790 | ) |  | 61,490 |  |  | 102,001 |  |  | 165,726 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 905,794 |  |  | 647,513 |  |  | 709,003 |  |  | 543,277 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 811,004 |  |  | $ | 709,003 |  |  | $ | 811,004 |  |  | $ | 709,003 |  |

[0001262039-18-000004:8k_2_02:110]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-18-000004:8k_2_02:111]
(Unaudited, in thousands, except per share amounts)

[0001262039-18-000004:8k_2_02:112]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-18-000004:8k_2_02:113]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Net cash provided by operating activities | $ | 157,542 |  |  | $ | 101,037 |  |  | $ | 594,405 |  |  | $ | 345,708 |  |
| Less purchases of property and equipment | (13,671 | ) |  | (16,863 | ) |  | (135,312 | ) |  | (67,182 | ) |
| Free cash flow | $ | 143,871 |  |  | $ | 84,174 |  |  | $ | 459,093 |  |  | $ | 278,526 |  |
| Net cash provided by (used) in investing activities | $ | 65,280 |  |  | $ | 2,092 |  |  | $ | (76,803 | ) |  | $ | (74,123 | ) |
| Net cash used in financing activities | $ | (317,612 | ) |  | $ | (41,639 | ) |  | $ | (415,601 | ) |  | $ | (105,859 | ) |

[0001262039-18-000004:8k_2_02:114]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-18-000004:8k_2_02:115]
|  | Three Months Ended December 31, 2017 |  | Three Months Ended December 31, 2016 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 42,198 |  |  | $ | 36,490 |  | (a) | $ | 78,688 |  |  | $ | 45,193 |  |  | $ | 35,936 |  | (b) | $ | 81,129 |  |
| Operating margin | 10 | % |  |  |  | 19 | % |  | 12 | % |  |  |  | 22 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 34,454 |  |  |  |  |  |  | 32,081 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,036 |  |  |  |  |  |  | 3,022 |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  |  |  | 833 |  |  |  |
| Tax adjustment |  |  | 47,937 |  | (c) |  |  |  |  | (7,875 | ) | (c) |  |
| Net income (loss) | $ | (28,961 | ) |  | $ | 84,427 |  |  | $ | 55,466 |  |  | $ | 25,166 |  |  | $ | 28,061 |  |  | $ | 53,227 |  |
| Diluted net income (loss) per share | $ | (0.17 | ) |  |  |  | $ | 0.32 |  |  | $ | 0.14 |  |  |  |  | $ | 0.30 |  |
| Shares used in diluted net income (loss) per share calculations | 171,530 |  |  |  |  | 175,384 |  |  | 176,679 |  |  |  |  | 176,679 |  |

[0001262039-18-000004:8k_2_02:116]
(a) To exclude $34.5 million of stock-based compensation and $2.0 million of amortization of acquired intangible assets in the three months ended December 31, 2017.

[0001262039-18-000004:8k_2_02:117]
(b) To exclude $32.1 million of stock-based compensation, $3.0 million of amortization of acquired intangible assets and $0.8 million of restructuring charges in the three months ended December 31, 2016.

[0001262039-18-000004:8k_2_02:118]
(c)  Non-GAAP financial information is adjusted to achieve an overall 32% and 33% effective tax rate in 2017 and 2016, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-18-000004:8k_2_02:119]
|  | Year Ended December 31, 2017 |  | Year Ended December 31, 2016 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 109,804 |  |  | $ | 147,595 |  | (a) | $ | 257,399 |  |  | $ | 42,944 |  |  | $ | 150,186 |  | (b) | $ | 193,130 |  |
| Operating margin | 7 | % |  |  |  | 17 | % |  | 3 | % |  |  |  | 15 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 137,183 |  |  |  |  |  |  | 122,423 |  |  |  |
| Amortization of acquired intangible assets |  |  | 8,572 |  |  |  |  |  |  | 9,308 |  |  |  |
| Litigation settlement expenses |  |  | 1,500 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 340 |  |  |  |  |  |  | 3,997 |  |  |  |
| ERP-related expenses |  |  | — |  |  |  |  |  |  | 13,362 |  |  |  |
| Inventory fair value adjustment amortization |  |  | — |  |  |  |  |  |  | 842 |  |  |  |
| Acquisition-related charges |  |  | — |  |  |  |  |  |  | 254 |  |  |  |
| Tax adjustment |  |  | 5,687 |  | (c) |  |  |  |  | (52,839 | ) | (c) |  |
| Net income | $ | 31,399 |  |  | $ | 153,282 |  |  | $ | 184,681 |  |  | $ | 32,187 |  |  | $ | 97,347 |  |  | $ | 129,534 |  |
| Diluted net income per share | $ | 0.18 |  |  |  |  | $ | 1.04 |  |  | $ | 0.18 |  |  |  |  | $ | 0.73 |  |
| Shares used in diluted net income per share calculations | 178,079 |  |  |  |  | 178,079 |  |  | 176,338 |  |  |  |  | 176,338 |  |

[0001262039-18-000004:8k_2_02:120]
(a) To exclude $137.2 million of stock-based compensation, $8.6 million of amortization of acquired intangible assets, $1.5 million litigation settlement expenses and $0.3 million of restructuring charges in 2017.

[0001262039-18-000004:8k_2_02:121]
(b) To exclude $122.4 million of stock-based compensation, $9.3 million of amortization of acquired intangible assets, $4.0 million of restructuring charges, $13.4 million of ERP-related expenses, $0.8 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition and $0.3 million of acquisition-related charges in 2016.

[0001262039-18-000004:8k_2_02:122]
(c)  Non-GAAP financial information is adjusted to achieve an overall 32% and 33% effective tax rate in 2017 and 2016, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-18-000004:8k_2_02:123]
Reconciliation of diluted weighted-average shares outstanding used in the calculation of GAAP and non-GAAP earnings per share

[0001262039-18-000004:8k_2_02:124]
|  |  | Three Months Ended |  | Year Ended |
|  |  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Shares used in diluted net income (loss) per share calculations - GAAP |  | 171,530 |  |  | 176,679 |  |  | 178,079 |  |  | 176,338 |  |
| Adjustment for diluted weighted-average shares outstanding | (a) | 3,854 |  |  | — |  |  | — |  |  | — |  |
| Shares used in diluted net income per share calculations - Non-GAAP |  | 175,384 |  |  | 176,679 |  |  | 178,079 |  |  | 176,338 |  |

[0001262039-18-000004:8k_2_02:125]
(a) GAAP diluted weighted-average shares outstanding differs from non-GAAP diluted weighted-average shares outstanding in periods when we have a GAAP net loss and a non-GAAP net income. The adjustment for diluted weighted-average shares outstanding represents the dilutive effect of employee equity incentive plan awards and is calculated by applying the treasury stock method.

[0001262039-18-000004:8k_2_02:126]
Billings Reconciliation

[0001262039-18-000004:8k_2_02:127]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Total revenue | $ | 416,668 |  |  | $ | 362,830 |  |  | $ | 1,494,930 |  |  | $ | 1,275,443 |  |
| Add change in deferred revenue | 117,357 |  |  | 100,557 |  |  | 300,965 |  |  | 244,046 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | — |  |  | — |  |  | (4,400 | ) |
| Total billings | $ | 534,025 |  |  | $ | 463,387 |  |  | $ | 1,795,895 |  |  | $ | 1,515,089 |  |

## item 5.02 — body, verbatim

[0001262039-18-000004:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001262039-18-000004:8k_body:2]
On February 2, 2018, Andrew Del Matto informed Fortinet of his resignation from his position as Chief Financial Officer, effective February 16, 2018.

[0001262039-18-000004:8k_body:3]
On February 5, 2018, Fortinet’s board of directors appointed Keith Jensen as Interim Chief Financial Officer, effective February 16, 2018. Mr. Jensen has served as Fortinet’s Chief Accounting Officer since July 2015. Prior to that, Mr. Jensen served as Fortinet’s Vice President of Finance and Corporate Controller from May 2014 to July 2015. From November 2012 to May 2014, Mr. Jensen served in various positions at DataDirect Networks, Inc., a data storage provider, including as its Chief Accounting Officer and Chief Administrative Officer. From February 2006 to November 2012, Mr. Jensen served in various positions at Sybase, Inc. (which was acquired by SAP America, Inc. in July 2010), an enterprise software and services company, including as Sybase’s Chief Financial Officer and Chief Accounting Officer. Prior to Sybase, from October 1999 to January 2006, Mr. Jensen served as Chief Financial Officer of Dorado Network Systems Corporation, a provider of software solutions to financial service companies. Mr. Jensen also previously held several positions with Coopers & Lybrand, including audit manager. Mr. Jensen holds a B.S. in Business from California State University, Sacramento.

[0001262039-18-000004:8k_body:4]
Mr. Jensen currently has an annual base salary of $320,000 and a target bonus of 30% of his annual base salary. In connection with Mr. Jensen’s appointment as Interim Chief Financial Officer, Fortinet’s board of directors has approved an additional quarterly bonus of $40,000 for Mr. Jensen, to be paid for each quarter in which he serves as Interim Chief Financial Officer. Fortinet previously entered into a change of control severance agreement with Mr. Jensen, dated as of February 4, 2016, a copy of which will be filed with Fortinet’s next periodic report and is incorporated herein by reference, and previously entered into its standard form of indemnification agreement with Mr. Jensen, in substantially the same form filed as Exhibit 10.1 to Fortinet’s Registration Statement on Form S-1, as amended (File No. 333-161190), filed with the Securities and Exchange Commission on August 10, 2009, which form of agreement is incorporated herein by reference.

[0001262039-18-000004:8k_body:5]
There are no arrangements or understandings between Mr. Jensen and any other persons, pursuant to which he was appointed as Interim Chief Financial Officer, no family relationships among any of the Company’s directors or executive officers and Mr. Jensen and he has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.
