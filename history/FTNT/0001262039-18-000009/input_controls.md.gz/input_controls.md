# FTNT 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001262039-18-000009:item_9a:1]
ITEM 9A.     Controls and Procedures

[0001262039-18-000009:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001262039-18-000009:item_9a:3]
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) or 15d-15(e) under the Securities Exchange Act of 1934 (the “Exchange Act”) as of the end of the period covered by this Annual Report on Form 10-K. In designing and evaluating the disclosure controls and procedures, management recognized that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001262039-18-000009:item_9a:4]
Based on that evaluation, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective as of December 31, 2017 to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001262039-18-000009:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001262039-18-000009:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Management conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control—Integrated Framework (2013) set forth by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001262039-18-000009:item_9a:7]
Based on this evaluation, management concluded that our internal control over financial reporting was effective as of December 31, 2017. Management reviewed the results of its assessment with our Audit Committee. The effectiveness of our internal control over financial reporting as of December 31, 2017 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in its report, which appears in this Item under the heading “Report of Independent Registered Public Accounting Firm.”

[0001262039-18-000009:item_9a:8]
Changes in Internal Control over Financial Reporting

[0001262039-18-000009:item_9a:9]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) or 15d-15(f) under the Exchange Act) during the fourth quarter of 2017 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001262039-18-000009:item_9a:10]
102

[0001262039-18-000009:item_9a:11]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001262039-18-000009:item_9a:12]
To the Shareholders and Board of Directors of Fortinet, Inc.

[0001262039-18-000009:item_9a:13]
Opinion on Internal Control over Financial Reporting

[0001262039-18-000009:item_9a:14]
We have audited the internal control over financial reporting of Fortinet, Inc. and subsidiaries (the “Company”) as of December 31, 2017, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2017, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the COSO.

[0001262039-18-000009:item_9a:15]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements and financial statement schedule as of and for the year ended December 31, 2017, of the Company and our report dated February 26, 2018, expressed an unqualified opinion on those financial statements and financial statement schedule.

[0001262039-18-000009:item_9a:16]
Basis for Opinion

[0001262039-18-000009:item_9a:17]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001262039-18-000009:item_9a:18]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001262039-18-000009:item_9a:19]
A company’s internal control over financial reporting is a process designed by, or under the supervision of, the company’s principal executive and principal financial officers, or persons performing similar functions, and effected by the company’s board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0001262039-18-000009:item_9a:20]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001262039-18-000009:item_9a:21]
/s/ DELOITTE & TOUCHE LLP

[0001262039-18-000009:item_9a:22]
San Jose, California

[0001262039-18-000009:item_9a:23]
February 26, 2018

[0001262039-18-000009:item_9a:24]
103
