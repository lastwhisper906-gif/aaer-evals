# FTNT notes — 0001262039-21-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001262039-21-000008:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2021 Annual Meeting of Stockholders (“Proxy Statement”) are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such Proxy Statement will be filed with the United States Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-21-000008:notes:2]
THE COMPANY AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as large enterprises, communication service providers, government organizations and small to medium-sized enterprises. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated Security Fabric Platform with automated protection, detection and responses.

[0001262039-21-000008:notes:3]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.

[0001262039-21-000008:notes:4]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the standalone selling price for our products and services, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation, the fair value of assets acquired and liabilities assumed in business combinations, the measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, the assessment of recoverability of our goodwill and other long-lived assets, the determination of sales returns reserves and contingent liabilities. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ materially from those estimates.

[0001262039-21-000008:notes:5]
Concentration Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, commercial paper and fixed income debt securities with major financial institutions that our management believes are financially sound.

[0001262039-21-000008:notes:6]
Our accounts receivables are primarily derived from our distributor customers in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated potential credit losses. As of December 31, 2020 and 2019, Exclusive Networks Group (“Exclusive”) accounted for 34% and 36% of total net accounts receivable, respectively. As of December 31, 2020 and 2019, Ingram Micro Inc. (“Ingram Micro”) accounted for 11% and 10% of total net accounts receivable, respectively.

[0001262039-21-000008:notes:7]
During 2020, Exclusive and Ingram Micro accounted for 30% and 10% of total revenue, respectively. During 2019, Exclusive and Ingram Micro accounted for 31% and 11% of total revenue, respectively. During 2018, Exclusive and Ingram Micro accounted for 30% and 10% of total revenue, respectively.

[0001262039-21-000008:notes:8]
We rely on a small number of manufacturing partners, primarily in Taiwan, to manufacture our products, and some of the components of our products are available from limited or sole sources of supply. Each of our proprietary Application-Specific Integrated Circuits is built by contract manufacturers located in Japan.

[0001262039-21-000008:notes:9]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-21-000008:notes:10]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments and the related tax impact.

[0001262039-21-000008:notes:11]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency remeasurement losses of $5.5 million, $4.7 million and $8.2 million, which are related to changes in foreign currency rates, are included in other expense—net for 2020, 2019, and 2018, respectively.

[0001262039-21-000008:notes:12]
Cash, Cash Equivalents and Available-for-Sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds, commercial paper, term deposits and corporate debt.

[0001262039-21-000008:notes:13]
We hold investment grade securities consisting of money market funds, corporate debt securities, U.S. government securities, commercial paper, certificates of deposit and term deposits that our management believes are financially sound. We classify our investments as available-for-sale (“AFS”) at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months with a remaining maturity less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with remaining maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-21-000008:notes:14]
Our AFS investments in debt securities are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in consolidated statements of stockholders’ equity. AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. An investment is impaired if the fair value of the investment is less than its cost. If the fair value of an investment is less than its amortized cost basis at the balance sheet date and if we do not intend to sell the investment, we consider available evidence to assess whether it is more likely than not that we will be required to sell the investment before the recovery of its amortized cost basis. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our ability to hold the investment. Once an impairment is determined to be attributable to credit-related factors, allowance for credit losses (i.e., the credit loss component) on AFS debt securities is recognized as credit loss expense, a charge in other expense—net, on our consolidated statements of income, and any remaining unrealized losses (i.e., the non-credit loss component), net of taxes, are included in accumulated other comprehensive income (loss) on our consolidated statements of stockholders’ equity.

[0001262039-21-000008:notes:15]
Prior to 2020, we followed the guidance in Accounting Standards Codification (“ASC”) 320 Investments—Debt and Equity Securities in determining whether unrealized losses were other than temporary. In June 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (“Topic 326”). We adopted Topic 326 on January 1, 2020, and now consider whether unrealized losses have resulted from a credit loss or other factors. The unrealized losses on our AFS debt securities as of December 31, 2020 and December 31, 2019 were caused by fluctuations in market value and interest rates as a result of the market conditions. We concluded that an allowance for credit losses was unnecessary as of December 31, 2020 and that the impairments as of December 31, 2019 were not other than temporary because (i) the decline in market value was attributable to changes in market conditions and not credit quality, and (ii) we concluded that neither do we intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis. As a result, we had no credit losses recorded for the year ended December 31, 2020, and there was no impairment charge for any unrealized losses in 2019 and 2018.

[0001262039-21-000008:notes:16]
We determine realized gains or losses on sale of AFS debt securities using specific identification method to determine the cost basis of investments sold and record such gains or losses as other expense-net on the consolidated statements of income. We have elected to not record an allowance for credit losses for accrued interest for AFS investments in debt securities and will reverse the accrued interest against interest income in the period in which we determine the accrued interest to be uncollectible.

[0001262039-21-000008:notes:17]
Accounts receivable—Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

[0001262039-21-000008:notes:18]
We further consider collectibility trends for the allowance for credit losses based on our assessment of various factors, including credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from our customers. The COVID-19 pandemic and the recent economic downturn prompted us to perform additional credit reviews of our existing customers, including obtaining recent credit reports and reviewing their latest available statements of financial position. In addition, we have seen an increase in requests for extended payment terms. After performing our additional reviews, we increased the allowance for credit losses for certain accounts receivable. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. The allowance for credit losses was $2.5 million as of December 31, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the year ended December 31, 2020.

[0001262039-21-000008:notes:19]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.

[0001262039-21-000008:notes:20]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. We do not depreciate the allocated cost of land. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-21-000008:notes:21]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 30 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-21-000008:notes:22]
Other Investments—Other investments are investments in equity securities of privately held companies without readily determinable fair values and are included in other assets in the consolidated balance sheets. We elected to account for these equity investments using the measurement alternative, which is at cost, less any impairment, adjusted for changes in fair value resulting from observable price changes in orderly transactions for the identical or similar investments of the same issuer. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts as well as current fundraising activities and valuations based on information provided by these privately held companies. If it is determined that a decline or increase in value exists in an investment without readily determinable fair value, we adjust the carrying value of the investment to its fair value and record the related impairment or increase in value as an investment loss or gain. The change in carrying value, if any, is recognized in other income (expense)—net on our consolidated statements of income. In addition, as of December 31, 2020, we also held equity investments with readily determinable fair values accounted for at fair value through net income, which were immaterial as of December 31, 2020.

[0001262039-21-000008:notes:23]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. Our estimates and assumptions are subject to change

[0001262039-21-000008:notes:24]
and we often continue to gather additional information throughout the measurement period, which is up to 12 months after the acquisition date, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-21-000008:notes:25]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets. There was no material impairment in 2020, 2019 and 2018.

[0001262039-21-000008:notes:26]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-21-000008:notes:27]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2020, we had one reporting unit.

[0001262039-21-000008:notes:28]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from three to five years.

[0001262039-21-000008:notes:29]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-21-000008:notes:30]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-21-000008:notes:31]
Effective January 1, 2018, the 2017 Tax Cuts and Jobs Act (the “2017 Tax Act”) reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time transition tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Our selection of an accounting policy for 2018 with respect to the Global Intangible Low-Taxed Income (“GILTI”) tax rules was to treat GILTI tax as a current period expense under the period cost method. For 2019 and 2020, we were not subject to GILTI. We will continue to monitor and assess the impact of the 2017 Tax Act and ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act.

[0001262039-21-000008:notes:32]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-21-000008:notes:33]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-21-000008:notes:34]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our equity incentive plans. Stock-based compensation expense is amortized on a straight-line basis over the service period. We account for forfeitures of all stock-based payment awards when they occur.

[0001262039-21-000008:notes:35]
Leases—We rent certain facilities under operating lease agreements. On January 1, 2019, we adopted FASB Topic 842, Leases (“Topic 842”), which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the consolidated balance sheet. Under Topic 842, we determine if an arrangement is a lease at inception. The ROU assets and the short and long-term lease liabilities from our operating leases are included in other assets, accrued liabilities and other liabilities in our consolidated balance sheets, respectively. The corresponding assets, the short and long-term lease liabilities from our finance leases are included in property and equipment, accrued liabilities and other liabilities in our consolidated balance sheets, respectively.

[0001262039-21-000008:notes:36]
The ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-21-000008:notes:37]
Lease expense for lease payments for our operating leases is recognized on a straight-line basis over the term of the lease. We begin recognizing rent expense on the date that a lessor makes an underlying asset that is subject to the lease available for our use. For our finance leases, we recognize amortization expense from the amortization of the corresponding assets and interest expense on the related lease liabilities.

[0001262039-21-000008:notes:38]
Prior to 2019, leases were recognized under FASB Topic 840, Leases (“Topic 840”). Under Topic 840, related rent expense was recognized on a straight-line basis over the term of the lease. Rent holidays and scheduled rent increases were included in the determination of rent expense to be recorded over the lease term. Lease incentives were recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals were not assumed in the determination of the lease term unless they were deemed to be reasonably assured at the inception of the lease. We began recognizing rent expense on the date that we obtained the legal right to use and control the leased space.

[0001262039-21-000008:notes:39]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not significant for any periods presented.

[0001262039-21-000008:notes:40]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-21-000008:notes:41]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-21-000008:notes:42]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-21-000008:notes:43]
Deferred Contract Costs and Commission Expense—Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. We recognize sales commissions expenses related to product sales upfront while sales commissions expenses for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Commission costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statements of income. Amortization of deferred contract costs during 2020, 2019 and 2018 was $137.4 million, $107.9 million and $90.9 million, respectively. No impairment loss was recognized during 2020, 2019 and 2018.

[0001262039-21-000008:notes:44]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. Deferred revenue that will be recognized during the succeeding 12-month period is recorded as current deferred revenue and the remaining portion is recorded as non-current deferred revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-21-000008:notes:45]
Revenue Recognition—Our revenue consists of product and service revenue. Revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We determine revenue recognition through the following steps:

[0001262039-21-000008:notes:46]
•identification of a contract or contracts with a customer;

[0001262039-21-000008:notes:47]
•identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract;

[0001262039-21-000008:notes:48]
•determination of a transaction price;

[0001262039-21-000008:notes:49]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-21-000008:notes:50]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-21-000008:notes:51]
We derive a majority of product sales from our FortiGate hardware and virtual machine products which include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide-area network, intrusion prevention, SSL data leak prevention, virtual private network, switch and wireless controller and wide area network edge.

[0001262039-21-000008:notes:52]
We recognize product revenue upon shipment when control of the promised goods is transferred to the customer. Our term software licenses represent multiple performance obligations, which include software licenses and software support services where the term licenses are recognized upfront upon transfer of control, with the associated software support services recognized ratably over the contract term as services and software updates are provided.

[0001262039-21-000008:notes:53]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. We generally recognize revenue from these services ratably over the support period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted by us or provided through cloud-providers. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-21-000008:notes:54]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone

[0001262039-21-000008:notes:55]
selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract. Revenue is reported net of sales tax.

[0001262039-21-000008:notes:56]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration using the expected-value method based on the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for refund liabilities, which include sales returns reserve and customer rebates, was $43.0 million and $27.6 million as of December 31, 2020 and 2019, respectively, and is included in current liabilities in our consolidated balance sheet.

[0001262039-21-000008:notes:57]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services. Standard payment terms are generally no more than 60 days, but we have accepted more requests for non-standard payment terms since the first quarter of 2021. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-21-000008:notes:58]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not significant during 2020, 2019 and 2018.

[0001262039-21-000008:notes:59]
Warranties—We generally provide a one-year warranty on most hardware products and a 90-day warranty on software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2020 and 2019.

[0001262039-21-000008:notes:60]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. There are many uncertainties associated with any disputes, litigation and other legal actions, and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties, which are inherently difficult to estimate and could adversely affect our results of operations. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses, which may be material.

[0001262039-21-000008:notes:61]
Recently Adopted Accounting Standards

[0001262039-21-000008:notes:62]
Financial Instruments

[0001262039-21-000008:notes:63]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which provides guidance on how an entity should measure credit losses on financial instruments. The standard replaces the existing incurred loss model with an expected credit loss model for financial assets measured at amortized cost, including trade receivables, and requires that credit losses on available-for-sale debt securities be presented as an allowance rather than as a write-down. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We adopted Topic 326 on January 1, 2020 using the modified retrospective method. The adoption of this standard did not have a material impact on our consolidated financial statements. We continue to monitor the financial implications of the COVID-19 pandemic on expected credit losses.

[0001262039-21-000008:notes:64]
Cloud Computing

[0001262039-21-000008:notes:65]
In August 2018, the FASB issued ASU 2018-15—Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. We adopted ASU 2018-15 on January 1, 2020. The adoption of this standard did not have a material impact on our consolidated financial statements.

[0001262039-21-000008:notes:66]
Fair Value Measurements

[0001262039-21-000008:notes:67]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. We adopted ASU 2018-13 on January 1, 2020. The adoption of this standard did not have a material impact on our disclosures.

[0001262039-21-000008:notes:68]
Recent Accounting Standards Not Yet Effective

[0001262039-21-000008:notes:69]
Income Taxes

[0001262039-21-000008:notes:70]
In December 2019, the FASB issued ASU 2019-12—Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for us beginning on January 1, 2021. We do not expect that ASC 2019-12 will have a material impact on our consolidated financial statements.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001262039-21-000008:notes:71]
IMMATERIAL CORRECTION OF PRIOR PERIOD FINANCIAL STATEMENTS
Subsequent to the issuance of our consolidated financial statements for the period ended December 31, 2019, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts. Rather than commencing recognition upon end user registration, we should have commenced recognition when control had passed to the distributor, which we have determined is our customer. We assessed the effect of this correction, individually and in the aggregate, on prior periods’ financial statements in accordance with the SEC’s Staff Accounting Bulletin Nos. 99 and 108 and, based on an analysis of quantitative and qualitative factors, determined that the correction was not individually material to any of our prior interim or annual consolidated financial statements.

[0001262039-21-000008:notes:72]
All financial information contained in the accompanying notes to these consolidated financial statements has been revised to reflect the correction of this error.

[0001262039-21-000008:notes:73]
The corrections to our consolidated balance sheet as of December 31, 2019 were as follows (in millions):

[0001262039-21-000008:notes:74]
|  | December 31, 2019 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| ASSETS |  |  |  |  |  |
| DEFERRED TAX ASSETS | $ | 232.6 |  |  | $ | (6.3) |  |  | $ | 226.3 |  |
| TOTAL ASSETS | 3,885.5 |  |  | (6.3) |  |  | 3,879.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |
| Deferred revenue | 1,173.6 |  |  | (17.8) |  |  | 1,155.8 |  |
| Total current liabilities | 1,473.6 |  |  | (17.8) |  |  | 1,455.8 |  |
| DEFERRED REVENUE | 962.3 |  |  | (9.0) |  |  | 953.3 |  |
| Total liabilities | 2,563.6 |  |  | (26.8) |  |  | 2,536.8 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |
| Retained earnings | 140.3 |  |  | 20.5 |  |  | 160.8 |  |
| Total stockholders’ equity | 1,321.9 |  |  | 20.5 |  |  | 1,342.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,885.5 |  |  | $ | (6.3) |  |  | $ | 3,879.2 |  |

[0001262039-21-000008:notes:75]
The corrections to our consolidated statements of income for the year ended December 31, 2019 and December 31, 2018 were as follows (in millions, except per share amounts):

[0001262039-21-000008:notes:76]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |
|  | As Previously Reported |  | Corrections |  | As Corrected |  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |
| Service | $ | 1,367.7 |  |  | $ | 6.8 |  |  | $ | 1,374.5 |  |  | $ | 1,126.8 |  |  | $ | 3.4 |  |  | $ | 1,130.2 |  |
| Total revenue | 2,156.2 |  |  | 6.8 |  |  | 2,163.0 |  |  | 1,801.2 |  |  | 3.4 |  |  | 1,804.6 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |  |  |  |  |
| Service | 1,186.4 |  |  | 6.8 |  |  | 1,193.2 |  |  | 967.4 |  |  | 3.4 |  |  | 970.8 |  |
| Total gross profit | 1,650.3 |  |  | 6.8 |  |  | 1,657.1 |  |  | 1,350.8 |  |  | 3.4 |  |  | 1,354.2 |  |
| OPERATING INCOME | 344.2 |  |  | 6.8 |  |  | 351.0 |  |  | 231.0 |  |  | 3.4 |  |  | 234.4 |  |
| INCOME BEFORE INCOME TAXES | 379.2 |  |  | 6.8 |  |  | 386.0 |  |  | 250.9 |  |  | 3.4 |  |  | 254.3 |  |
| PROVISION FOR INCOME TAXES | 52.7 |  |  | 1.6 |  |  | 54.3 |  |  | (81.3) |  |  | 0.7 |  |  | (80.6) |  |
| NET INCOME | $ | 326.5 |  |  | $ | 5.2 |  |  | $ | 331.7 |  |  | $ | 332.2 |  |  | $ | 2.7 |  |  | $ | 334.9 |  |
| Net income per share (Note 10): |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.91 |  |  | $ | 0.03 |  |  | $ | 1.94 |  |  | $ | 1.96 |  |  | $ | 0.02 |  |  | $ | 1.98 |  |
| Diluted | $ | 1.87 |  |  | $ | 0.03 |  |  | $ | 1.90 |  |  | $ | 1.91 |  |  | $ | 0.01 |  |  | $ | 1.92 |  |

[0001262039-21-000008:notes:77]
The corrections to our consolidated statements of cash flows for the year ended December 31, 2019 and December 31, 2018 were as follows (in millions):

[0001262039-21-000008:notes:78]
|  | Year Ended December 31, |
|  | 2019 |  | 2018 |
|  | As Previously Reported |  | Corrections |  | As Corrected |  | As Previously Reported |  | Corrections |  | As Corrected |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 326.5 |  |  | $ | 5.2 |  |  | $ | 331.7 |  |  | $ | 332.2 |  |  | $ | 2.7 |  |  | $ | 334.9 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Deferred tax assets | $ | 17.8 |  |  | $ | 1.6 |  |  | $ | 19.4 |  |  | $ | (127.8) |  |  | $ | 0.7 |  |  | $ | (127.1) |  |
| Deferred revenue | $ | 446.7 |  |  | $ | (6.8) |  |  | $ | 439.9 |  |  | $ | 352.1 |  |  | $ | (3.4) |  |  | $ | 348.7 |  |

[0001262039-21-000008:notes:79]
For all periods in which we corrected net income, we made corresponding corrections to net income and comprehensive income in our consolidated statements of comprehensive income and to net income, retained earnings (accumulated deficit) and total stockholders’ equity in our consolidated statements of stockholders’ equity.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-21-000008:notes:80]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

[0001262039-21-000008:notes:81]
Disaggregation of Revenue

[0001262039-21-000008:notes:82]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-21-000008:notes:83]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Product | $ | 916.4 |  |  | $ | 788.5 |  |  | $ | 674.4 |  |
| Service: |  |  |  |  |  |
| Security subscription | 918.7 |  |  | 750.8 |  |  | 606.1 |  |
| Technical support and other | 759.3 |  |  | 623.7 |  |  | 524.1 |  |
| Total service revenue | 1,678.0 |  |  | 1,374.5 |  |  | 1,130.2 |  |
| Total revenue | $ | 2,594.4 |  |  | $ | 2,163.0 |  |  | $ | 1,804.6 |  |

[0001262039-21-000008:notes:84]
Deferred Revenue

[0001262039-21-000008:notes:85]
Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of period end. During 2020, we recognized $1.15 billion in revenue that was included in the deferred revenue balance as of December 31, 2019. During 2019, we recognized $935.0 million in revenue that was included in the deferred revenue balance as of December 31, 2018.

[0001262039-21-000008:notes:86]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-21-000008:notes:87]
As of December 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.61 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.39 billion as revenue over the next 12 months and the remainder thereafter.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-21-000008:notes:88]
FINANCIAL INSTRUMENTS AND FAIR VALUE
The following tables summarize our investments (in millions):

[0001262039-21-000008:notes:89]
|  | December 31, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 410.5 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 411.5 |  |
| Commercial paper | 185.4 |  |  | — |  |  | — |  |  | 185.4 |  |
| U.S. government securities | 184.9 |  |  | — |  |  | — |  |  | 184.9 |  |
| Certificates of deposit and term deposits (1) | 112.0 |  |  | — |  |  | — |  |  | 112.0 |  |
| Total available-for-sale securities | $ | 892.8 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 893.8 |  |
|  | December 31, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 576.1 |  |  | $ | 1.0 |  |  | $ | (0.1) |  |  | $ | 577.0 |  |
| Commercial paper | 148.7 |  |  | 0.1 |  |  | — |  |  | 148.8 |  |
| U.S. government securities | 195.0 |  |  | 0.2 |  |  | — |  |  | 195.2 |  |
| Certificates of deposit and term deposits (1) | 66.4 |  |  | — |  |  | — |  |  | 66.4 |  |
| Total available-for-sale securities | $ | 986.2 |  |  | $ | 1.3 |  |  | $ | (0.1) |  |  | $ | 987.4 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-21-000008:notes:90]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in millions):

[0001262039-21-000008:notes:91]
|  | December 31, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 111.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 111.3 |  |  | $ | — |  |
| Commercial paper | 61.5 |  |  | — |  |  | — |  |  | — |  |  | 61.5 |  |  | — |  |
| U.S. government securities | 38.1 |  |  | — |  |  | — |  |  | — |  |  | 38.1 |  |  | — |  |
| Certificates of deposit and term deposits | 29.5 |  |  | — |  |  | — |  |  | — |  |  | 29.5 |  |  | — |  |
| Total available-for-sale securities | $ | 240.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 240.4 |  |  | $ | — |  |

[0001262039-21-000008:notes:92]
|  | December 31, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 117.3 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 133.4 |  |  | $ | (0.1) |  |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| U.S. government securities | 47.1 |  |  | — |  |  | — |  |  | — |  |  | 47.1 |  |  | — |  |
| Certificates of deposit and term deposits | 13.0 |  |  | — |  |  | — |  |  | — |  |  | 13.0 |  |  | — |  |
| Total available-for-sale securities | $ | 203.4 |  |  | $ | (0.1) |  |  | $ | 16.1 |  |  | $ | — |  |  | $ | 219.5 |  |  | $ | (0.1) |  |

[0001262039-21-000008:notes:93]
The contractual maturities of our investments were as follows (in millions):

[0001262039-21-000008:notes:94]
|  | December 31,2020 |  | December 31,2019 |
| Due within one year | $ | 775.5 |  |  | $ | 843.1 |  |
| Due within one to three years | 118.3 |  |  | 144.3 |  |
| Total | $ | 893.8 |  |  | $ | 987.4 |  |

[0001262039-21-000008:notes:95]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest of $2.8 million as of December 31, 2020 was excluded from both the fair value and the amortized cost of our available-for-sale securities and was recorded in prepaid expenses and other current assets in our consolidated balance sheet.

[0001262039-21-000008:notes:96]
Realized gains and losses on available-for-sale securities were insignificant in the periods presented.

[0001262039-21-000008:notes:97]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-21-000008:notes:98]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-21-000008:notes:99]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-21-000008:notes:100]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-21-000008:notes:101]
We measure the fair value of money market funds and certain U.S. government securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-21-000008:notes:102]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-21-000008:notes:103]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-21-000008:notes:104]
Fair Value of Financial Instruments

[0001262039-21-000008:notes:105]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-21-000008:notes:106]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis (in millions):

[0001262039-21-000008:notes:107]
|  | December 31, 2020 |  | December 31, 2019 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 413.7 |  |  | $ | — |  |  | $ | 413.7 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |  | $ | 577.0 |  |  | $ | — |  |
| Commercial paper | 197.2 |  |  | — |  |  | 197.2 |  |  | — |  |  | 165.8 |  |  | — |  |  | 165.8 |  |  | — |  |
| U.S. government securities | 184.9 |  |  | 184.9 |  |  | — |  |  | — |  |  | 195.2 |  |  | 195.2 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 112.0 |  |  | — |  |  | 112.0 |  |  | — |  |  | 66.4 |  |  | — |  |  | 66.4 |  |  | — |  |
| Money market funds | 152.7 |  |  | 152.7 |  |  | — |  |  | — |  |  | 15.0 |  |  | 15.0 |  |  | — |  |  | — |  |
| Total | $ | 1,060.5 |  |  | $ | 337.6 |  |  | $ | 722.9 |  |  | $ | — |  |  | $ | 1,019.4 |  |  | $ | 210.2 |  |  | $ | 809.2 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 166.7 |  |  |  |  |  |  |  |  | $ | 32.0 |  |  |  |  |  |  |  |
| Short-term investments | 775.5 |  |  |  |  |  |  |  |  | 843.1 |  |  |  |  |  |  |  |
| Long-term investments | 118.3 |  |  |  |  |  |  |  |  | 144.3 |  |  |  |  |  |  |  |
| Total | $ | 1,060.5 |  |  |  |  |  |  |  |  | $ | 1,019.4 |  |  |  |  |  |  |  |

[0001262039-21-000008:notes:108]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the year ended December 31, 2020 and December 31, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-21-000008:notes:109]
INVENTORY
Inventory consisted of the following (in millions):

[0001262039-21-000008:notes:110]
|  | December 31,2020 |  | December 31,2019 |
| Raw materials | $ | 13.8 |  |  | $ | 9.7 |  |
| Finished goods | 126.0 |  |  | 108.2 |  |
| Inventory | $ | 139.8 |  |  | $ | 117.9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-21-000008:notes:111]
PROPERTY AND EQUIPMENT—Net
Property and equipment—net consisted of the following (in millions):

[0001262039-21-000008:notes:112]
|  | December 31,2020 |  | December 31,2019 |
| Land | $ | 93.3 |  |  | $ | 93.3 |  |
| Building and building improvements | 150.6 |  |  | 147.4 |  |
| Computer equipment and software | 137.2 |  |  | 116.7 |  |
| Leasehold improvements | 31.9 |  |  | 25.5 |  |
| Evaluation units | 19.8 |  |  | 19.9 |  |
| Furniture and fixtures | 21.3 |  |  | 17.3 |  |
| Construction-in-progress | 166.4 |  |  | 61.2 |  |
| Total property and equipment | 620.5 |  |  | 481.3 |  |
| Less: accumulated depreciation | (172.5) |  |  | (137.0) |  |
| Property and equipment—net | $ | 448.0 |  |  | $ | 344.3 |  |

[0001262039-21-000008:notes:113]
Construction-in-progress consists primarily of costs incurred in connection with the construction of a second building at our headquarters campus.

[0001262039-21-000008:notes:114]
Depreciation expense was $55.5 million, $50.7 million and $46.7 million in 2020, 2019 and 2018, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001262039-21-000008:notes:115]
INVESTMENTS IN PRIVATELY HELD COMPANIESOur investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million and $5.3 million as of December 31, 2020 and 2019, respectively. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. These investments are recorded as other assets in our consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. In the first quarter of 2020 and in the third quarter of 2019, we recognized non-cash impairment charges of $4.3 million and $3.8 million in other expense—net in our consolidated statements of income, respectively. Cumulative impairment adjustments to all equity securities without readily determinable fair values totaled $8.1 million since their respective acquisitions. During the third quarter of 2018, we sold equity securities of a privately held company for $5.2 million and recognized a gain of $2.2 million to other expense—net in our consolidated statements of income. As of December 31, 2020, no other events have occurred that would affect the carrying value of these investments.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-21-000008:notes:116]
BUSINESS COMBINATIONS
2020 Acquisitions

[0001262039-21-000008:notes:117]
Panopta Holdings LLC

[0001262039-21-000008:notes:118]
On December 9, 2020, we acquired all outstanding shares of Panopta Holdings LLC (“Panopta”), a privately held SaaS platform innovator that provides visibility, automated management and alerting, and remediation for enterprise networks and infrastructure.

[0001262039-21-000008:notes:119]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to Panopta’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The preliminary purchase price for Panopta was $31.9 million in cash, of which $24.8 million was allocated to goodwill and $9.0 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.9 million of net liabilities assumed, which predominantly included cash and accounts payable. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies, and $16.9 million of goodwill is expected to be deductible for tax purposes.

[0001262039-21-000008:notes:120]
The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary areas of the purchase price that are not yet finalized are related to income taxes and the valuation of acquired assets and assumed liabilities.

[0001262039-21-000008:notes:121]
OPAQ Networks, Inc.

[0001262039-21-000008:notes:122]
On July 20, 2020, we acquired all outstanding shares of OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge cloud provider.

[0001262039-21-000008:notes:123]
Under the acquisition method of accounting in accordance with ASC 805, the total preliminary purchase price was allocated to OPAQ’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date. The preliminary purchase price for OPAQ was $8.0 million in cash, of which $1.0 million was allocated to goodwill, $4.7 million was allocated to identifiable intangible assets, the majority of which was developed technology, and $2.3 million was allocated to other net assets acquired, which predominantly included cash, deferred tax assets, operating lease right-of-use assets and lease liabilities, accounts payable, accrued liabilities and assumed debt. The preliminary purchase price included a $1.3 million indemnity fund held in escrow for 12 months after the transaction closing date. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies, and goodwill is non-deductible for tax purposes.

[0001262039-21-000008:notes:124]
2019 Acquisitions

[0001262039-21-000008:notes:125]
CyberSponse, Inc.

[0001262039-21-000008:notes:126]
On December 12, 2019, we acquired all outstanding shares of CyberSponse, Inc. (“CyberSponse”), a provider of security orchestration, automation and response products and services. The purchase price for CyberSponse was $26.1 million, of which $18.6 million was allocated to goodwill that was non-deductible for tax purposes and $9.1 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $1.6 million of net liabilities assumed. We incurred a $4.1 million liability in connection with this business combination, the majority of which related to the settlement of CyberSponse’s equity awards in cash, which we included in accrued liabilities in our consolidated balance sheet as of December 31, 2019, and paid during the year ended December 31, 2020. The purchase price included $3.0 million of this liability and the remaining $1.1 million was recognized as compensation cost in the consolidated statements of income for the year ended December 31, 2019. The purchase price also included $3.8 million held in indemnity escrow, of which $2.8 million was held for 12 months and released to CyberSponse shareholders during the year ended December 31, 2020, and the remaining $1.0 million will be held for 36 months after the transaction closing date.

[0001262039-21-000008:notes:127]
enSilo Limited

[0001262039-21-000008:notes:128]
On October 28, 2019, we acquired all outstanding shares of enSilo Limited (“enSilo”), a provider of endpoint detection and response products and services. The purchase price for enSilo was $15.8 million, of which $10.4 million was allocated to goodwill, $10.8 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $5.4 million of net liabilities assumed. The purchase price included $2.0 million held in indemnity escrow for 12 months after the transaction closing date, of which $1.7 million was received by Fortinet and the remainder was released to enSilo shareholders during the year ended December 31, 2020.

[0001262039-21-000008:notes:129]
2018 Acquisitions

[0001262039-21-000008:notes:130]
ZoneFox Holdings Limited

[0001262039-21-000008:notes:131]
On October 22, 2018, we acquired all outstanding shares of ZoneFox Holdings Limited (“ZoneFox”), a privately held cloud-based company providing insider threat detection and response. The purchase price for ZoneFox was $16.1 million, of which $12.5 million was allocated to goodwill that was non-deductible for tax purposes and $6.8 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $3.2 million of net liabilities assumed. The acquisition included a $2.0 million cash earn-out that was subject in full to satisfaction of certain performance conditions. The performance conditions were not met and the cash earn-out was not paid.

[0001262039-21-000008:notes:132]
Bradford Networks, Inc.

[0001262039-21-000008:notes:133]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services. The purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes and $8.0 million was allocated to identifiable intangible assets, the majority of which was developed technology, offset by $12.3 million of net liabilities assumed. The acquisition included a $2.0 million cash earn-out that was subject in full to satisfaction of certain performance conditions. The performance conditions were not met and the cash earn-out was not paid.

[0001262039-21-000008:notes:134]
Additional Acquisition-Related Information

[0001262039-21-000008:notes:135]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. Pro forma information has not been presented as the impact of these acquisitions, individually and in the aggregate, in each year were not material to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-21-000008:notes:136]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net
Goodwill

[0001262039-21-000008:notes:137]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-21-000008:notes:138]
|  | Amount |
| Balance—December 31, 2019 | $ | 67.2 |  |
| Additions due to business combinations | 25.8 |  |
| Balance—December 31, 2020 | $ | 93.0 |  |

[0001262039-21-000008:notes:139]
There were no impairments to goodwill during 2020, 2019, and 2018, or any previous years.

[0001262039-21-000008:notes:140]
Other Intangible Assets—Net

[0001262039-21-000008:notes:141]
The following tables present other intangible assets—net (in millions, except years):

[0001262039-21-000008:notes:142]
|  | December 31, 2020 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 59.3 |  |  | $ | 32.3 |  |  | $ | 27.0 |  |
| Customer relationships | 4.0 |  | 24.8 |  |  | 20.2 |  |  | 4.6 |  |
| Total other intangible assets—net |  |  | $ | 84.1 |  |  | $ | 52.5 |  |  | $ | 31.6 |  |

[0001262039-21-000008:notes:143]
|  | December 31, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 50.2 |  |  | $ | 24.6 |  |  | $ | 25.6 |  |
| Customer relationships | 4.1 |  | 21.6 |  |  | 16.1 |  |  | 5.5 |  |
| Total other intangible assets—net |  |  | $ | 71.8 |  |  | $ | 40.7 |  |  | $ | 31.1 |  |

[0001262039-21-000008:notes:144]
Amortization expense of finite-lived intangible assets was $13.3 million, $10.9 million and $9.0 million in 2020, 2019, and 2018, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets (in millions):

[0001262039-21-000008:notes:145]
| Year Ending December 31, | Amount |
| 2021 | $ | 13.1 |  |
| 2022 | 9.7 |  |
| 2023 | 6.6 |  |
| 2024 | 2.2 |  |
| Total | $ | 31.6 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-21-000008:notes:146]
NET INCOME PER SHARE
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and our Employee Stock Purchase Plan (“ESPP”), which was terminated in February 2019 at the completion of the prior offering period. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-21-000008:notes:147]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-21-000008:notes:148]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 488.5 |  |  | $ | 331.7 |  |  | $ | 334.9 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 164.2 |  |  | 171.0 |  |  | 169.1 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 164.2 |  |  | 171.0 |  |  | 169.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 2.3 |  |  | 2.8 |  |  | 3.6 |  |
| Stock options | 1.2 |  |  | 1.2 |  |  | 1.4 |  |
| ESPP | — |  |  | — |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 167.7 |  |  | 175.0 |  |  | 174.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 2.98 |  |  | $ | 1.94 |  |  | $ | 1.98 |  |
| Diluted | $ | 2.91 |  |  | $ | 1.90 |  |  | $ | 1.92 |  |

[0001262039-21-000008:notes:149]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-21-000008:notes:150]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| RSUs | 0.3 |  |  | 0.3 |  |  | 0.5 |  |
| Stock options | 0.5 |  |  | 0.6 |  |  | 0.3 |  |
| ESPP | — |  |  | — |  |  | 0.1 |  |
| Total | 0.8 |  |  | 0.9 |  |  | 0.9 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-21-000008:notes:151]
LEASES
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility.

[0001262039-21-000008:notes:152]
During the year ended December 31, 2019, we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-21-000008:notes:153]
The components of lease expense were as follows (in millions):

[0001262039-21-000008:notes:154]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |
| Operating lease expense | $ | 18.5 |  |  | $ | 15.3 |  |
| Variable lease expense (1) | 2.3 |  |  | 2.6 |  |
| Short-term lease expense | 3.8 |  |  | 3.2 |  |
| Total lease expense | $ | 24.6 |  |  | $ | 21.1 |  |
| (1) Variable lease expense for the year ended December 31, 2020 and December 31, 2019 predominantly included common area maintenance charges and parking expense. |

[0001262039-21-000008:notes:155]
Rent expense was $17.1 million for 2018. Rent expense was recognized in accordance with Topic 840 using the straight-line method over the term of a lease.

[0001262039-21-000008:notes:156]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-21-000008:notes:157]
|  | Classification |  | December 31,2020 |  | December 31,2019 |
| Operating lease ROU assets – non-current | Other assets |  | $ | 49.3 |  |  | $ | 44.3 |  |
| Operating lease liabilities – current | Accrued liabilities |  | $ | 19.1 |  |  | $ | 15.5 |  |
| Operating lease liabilities – non-current | Other liabilities |  | 34.0 |  |  | 30.6 |  |
| Total operating lease liabilities |  |  | $ | 53.1 |  |  | $ | 46.1 |  |
| Weighted average remaining lease term in years – operating leases |  |  | 3.5 |  | 3.7 |
| Weighted average discount rate – operating leases |  |  | 3.2 | % |  | 2.8 | % |

[0001262039-21-000008:notes:158]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-21-000008:notes:159]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 18.9 |  |  | $ | 16.2 |  |

[0001262039-21-000008:notes:160]
Maturities of operating lease liabilities as of December 31, 2020 were as follows (in millions):

[0001262039-21-000008:notes:161]
| Year Ending December 31, | Amount |
| 2021 | $ | 20.3 |  |
| 2022 | 15.2 |  |
| 2023 | 9.6 |  |
| 2024 | 6.3 |  |
| 2025 | 3.3 |  |
| Thereafter | 1.4 |  |
| Total lease payments | $ | 56.1 |  |
| Less imputed interest | (3.0) |  |
| Total | $ | 53.1 |  |

[0001262039-21-000008:notes:162]
As of December 31, 2020, we had additional minimum lease payments of $4.7 million relating to the operating leases, primarily for colocation space, that had been signed but had not yet commenced. These leases will commence during 2021 and will have lease terms of approximately three to four years.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-21-000008:notes:163]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-21-000008:notes:164]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-21-000008:notes:165]
During the year ended December 31, 2020, we recorded a $40.2 million gain on IP matter in our consolidated statements of income. We recorded $9.8 million in accrued liabilities and other liabilities in our consolidated balance sheet as of December 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-21-000008:notes:166]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of December 31, 2020 (in millions):

[0001262039-21-000008:notes:167]
|  | Total |  | 2021 |  | Thereafter |
| Inventory purchase commitments | $ | 259.4 |  |  | $ | 259.4 |  |  | $ | — |  |

[0001262039-21-000008:notes:168]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2020 and 2019, we had $259.4 million and $231.9 million, respectively, of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-21-000008:notes:169]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2020 and 2019, we had $28.9 million and $12.8 million, respectively, in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-21-000008:notes:170]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of December 31, 2020 and 2019.

[0001262039-21-000008:notes:171]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-21-000008:notes:172]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-21-000008:notes:173]
STOCKHOLDERS’ EQUITY
Stock-Based Compensation Plans

[0001262039-21-000008:notes:174]
We have one primary stock incentive plan, the 2009 Equity Incentive Plan, under which we have granted RSUs and stock options. We also previously had an ESPP for eligible employees, which was terminated in February 2019.

[0001262039-21-000008:notes:175]
2009 Equity Incentive Plan—Our board of directors approved the 2009 Equity Incentive Plan in 2009. On June 21, 2019, our stockholders approved the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “2009 Plan”). Among other things, the 2009 Plan provided for a net decrease in the number of shares of common stock that were authorized and available for issuance pursuant to future awards granted on or following the effective date of the 2009 Plan. On June 28, 2019, we deregistered from various registration statements on Form S-8 an aggregate of 46.2 million shares of common stock that were originally registered for issuance under the 2009 Plan.

[0001262039-21-000008:notes:176]
The maximum aggregate number of shares that may be issued under the 2009 Plan is 47,873,531 shares; provided, however, that only 13,500,000 shares may be issued or transferred pursuant to new awards granted on or following the effective date of the 2009 Plan. We may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire no more than five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of no more than ten years and options generally vest over four years.

[0001262039-21-000008:notes:177]
As of December 31, 2020, there were a total of 12.3 million shares of common stock available for grant under the 2009 Plan.

[0001262039-21-000008:notes:178]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permitted eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year. Our board of directors voluntarily determined to terminate the ESPP, effective February 2019 at the completion of the prior offering period.

[0001262039-21-000008:notes:179]
Restricted Stock Units

[0001262039-21-000008:notes:180]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-21-000008:notes:181]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2017 | 8.5 |  |  | $ | 34.79 |  |
| Granted | 4.1 |  |  | 57.37 |  |
| Forfeited | (0.9) |  |  | 39.29 |  |
| Vested | (3.9) |  |  | 34.67 |  |
| Balance—December 31, 2018 | 7.8 |  |  | 46.07 |  |
| Granted | 2.7 |  |  | 87.09 |  |
| Forfeited | (0.7) |  |  | 55.13 |  |
| Vested | (3.7) |  |  | 43.31 |  |
| Balance—December 31, 2019 | 6.1 |  |  | 64.56 |  |
| Granted | 1.9 |  |  | 121.16 |  |
| Forfeited | (0.4) |  |  | 79.83 |  |
| Vested | (2.9) |  |  | 58.20 |  |
| Balance—December 31, 2020 | 4.7 |  |  | $ | 90.46 |  |

[0001262039-21-000008:notes:182]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of December 31, 2020, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $360.5 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-21-000008:notes:183]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy employee withholding tax requirements. The payment of the withheld taxes to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-21-000008:notes:184]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-21-000008:notes:185]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Shares withheld for taxes | 0.9 |  |  | 1.1 |  |  | 1.2 |  |
| Amount withheld for taxes | $ | 108.2 |  |  | $ | 96.0 |  |  | $ | 67.2 |  |

[0001262039-21-000008:notes:186]
Employee Stock Options

[0001262039-21-000008:notes:187]
In determining the fair value of our employee stock options, we use the Black-Scholes model, which employs the following assumptions.

[0001262039-21-000008:notes:188]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-21-000008:notes:189]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-21-000008:notes:190]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-21-000008:notes:191]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-21-000008:notes:192]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-21-000008:notes:193]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-21-000008:notes:194]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 34.8 | % |  | 34.3 | % |  | 31.8 | % |
| Risk-free interest rate | 1.1 | % |  | 2.4 | % |  | 2.7 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-21-000008:notes:195]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-21-000008:notes:196]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2017 | 4.3 |  |  | $ | 27.50 |  |  | 3.2 |  | $ | 70.9 |  |
| Granted | 0.8 |  |  | 52.09 |  |  |  |  |  |
| Forfeited | (0.2) |  |  | 32.24 |  |  |  |  |  |
| Exercised | (1.9) |  |  | 24.96 |  |  |  |  |  |
| Balance—December 31, 2018 | 3.0 |  |  | 35.53 |  |  | 4.0 |  | 105.6 |  |
| Granted | 0.7 |  |  | 85.02 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 62.93 |  |  |  |  |  |
| Exercised | (0.9) |  |  | 30.21 |  |  |  |  |  |
| Balance—December 31, 2019 | 2.7 |  |  | 50.37 |  |  | 4.5 |  | 150.3 |  |
| Granted | 0.6 |  |  | 118.80 |  |  |  |  |  |
| Forfeited | (0.1) |  |  | 91.52 |  |  |  |  |  |
| Exercised | (0.5) |  |  | 41.49 |  |  |  |  |  |
| Balance—December 31, 2020 | 2.7 |  |  | $ | 67.53 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2020 | 2.7 |  |  | $ | 67.53 |  |  | 4.2 |  | $ | 220.4 |  |
| Options exercisable—December 31, 2020 | 1.5 |  |  | $ | 44.58 |  |  | 3.2 |  | $ | 155.9 |  |

[0001262039-21-000008:notes:197]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2020 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of December 31, 2020, total compensation expense related to unvested stock options granted to employees but not yet recognized was $31.3 million, with a weighted-average remaining vesting period of 2.6 years.

[0001262039-21-000008:notes:198]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-21-000008:notes:199]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Weighted-average fair value per share granted | $ | 35.79 |  |  | $ | 27.19 |  |  | $ | 16.03 |  |
| Intrinsic value of options exercised | $ | 43.5 |  |  | $ | 54.6 |  |  | $ | 62.2 |  |
| Fair value of options vested | $ | 13.5 |  |  | $ | 10.1 |  |  | $ | 7.2 |  |

[0001262039-21-000008:notes:200]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2020, as follows (in millions, except exercise prices and contractual life):

[0001262039-21-000008:notes:201]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $20.76-$24.51 |  | 0.4 |  |  | 1.9 |  | $ | 23.65 |  |  | 0.4 |  |  | $ | 23.65 |  |
| $26.49-$39.49 |  | 0.4 |  |  | 2.8 |  | 35.98 |  |  | 0.4 |  |  | 35.90 |  |
| $48.83-$72.75 |  | 0.6 |  |  | 3.9 |  | 50.25 |  |  | 0.4 |  |  | 49.84 |  |
| $76.22-$145.62 |  | 1.3 |  |  | 5.7 |  | 101.91 |  |  | 0.3 |  |  | 85.51 |  |
|  |  | 2.7 |  |  |  |  |  |  | 1.5 |  |  |  |

[0001262039-21-000008:notes:202]
Employee Stock Purchase Plan

[0001262039-21-000008:notes:203]
There were no grants under the ESPP during the year ended December 31, 2020 and December 31, 2019. In determining the grant date fair value of the ESPP, we used the Black-Scholes option pricing model. The following table summarizes the assumptions used and the resulting grant-date fair values of our ESPP:

[0001262039-21-000008:notes:204]
|  |  | Year Ended December 31, |
|  |  | 2018 |
| Expected term in years |  |  | 0.5 |
| Volatility |  |  | 28.9 | % |
| Risk-free interest rate |  |  | 2.0 | % |
| Dividend rate |  |  | — | % |
| Weighted-average fair value per share granted |  |  | $ | 14.14 |  |

[0001262039-21-000008:notes:205]
Additional information related to the ESPP is provided below (in millions, except per share amounts):

[0001262039-21-000008:notes:206]
|  |  |  | Year Ended December 31, |
|  |  |  | 2019 |  | 2018 |
| Shares issued under the ESPP |  |  | 0.3 |  |  | 1.1 |  |
| Weighted-average price per share issued |  |  | $ | 64.79 |  |  | $ | 35.32 |  |

[0001262039-21-000008:notes:207]
Shares Reserved for Future Issuances

[0001262039-21-000008:notes:208]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-21-000008:notes:209]
|  | December 31,2020 |
| Reserved for future equity award grants | 12.3 |  |
| Outstanding stock options and RSUs | 7.4 |  |
| Total common stock reserved for future issuances | 19.7 |  |

[0001262039-21-000008:notes:210]
Stock-Based Compensation Expense

[0001262039-21-000008:notes:211]
Stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, is included in costs and expenses as follows (in millions):

[0001262039-21-000008:notes:212]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Cost of product revenue | $ | 1.6 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |
| Cost of service revenue | 12.9 |  |  | 11.3 |  |  | 10.8 |  |
| Research and development | 47.6 |  |  | 38.7 |  |  | 36.4 |  |
| Sales and marketing | 108.4 |  |  | 101.7 |  |  | 95.6 |  |
| General and administrative | 23.3 |  |  | 20.9 |  |  | 18.6 |  |
| Total stock-based compensation expense | $ | 193.8 |  |  | $ | 174.1 |  |  | $ | 162.9 |  |

[0001262039-21-000008:notes:213]
The following table summarizes stock-based compensation expense, including stock-based compensation expense related to awards classified as liabilities, by award type (in millions):

[0001262039-21-000008:notes:214]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| RSUs | $ | 179.7 |  |  | $ | 160.2 |  |  | $ | 143.9 |  |
| Stock options | 14.1 |  |  | 12.6 |  |  | 8.8 |  |
| ESPP | — |  |  | 1.3 |  |  | 10.2 |  |
| Total stock-based compensation expense | $ | 193.8 |  |  | $ | 174.1 |  |  | $ | 162.9 |  |

[0001262039-21-000008:notes:215]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is as follows (in millions):

[0001262039-21-000008:notes:216]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Income tax benefit associated with stock-based compensation | $ | 42.1 |  |  | $ | 38.3 |  |  | $ | 24.9 |  |

[0001262039-21-000008:notes:217]
Share Repurchase Program

[0001262039-21-000008:notes:218]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. From 2016 through 2019, our board of directors approved increases to our Repurchase Program by various amounts, bringing the aggregated amount authorized to $2.5 billion. In July 2020, our board of directors approved a $500.0 million increase and extended the term to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2020, we repurchased 11.7 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $1.08 billion. As of December 31, 2020, $1.01 billion remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-21-000008:notes:219]
INCOME TAXES 
Income before income taxes consisted of the following (in millions):

[0001262039-21-000008:notes:220]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Domestic | $ | 490.6 |  |  | $ | 371.7 |  |  | $ | 3.7 |  |
| Foreign | 51.1 |  |  | 14.3 |  |  | 250.6 |  |
| Total income before income taxes | $ | 541.7 |  |  | $ | 386.0 |  |  | $ | 254.3 |  |

[0001262039-21-000008:notes:221]
Due to the realignment of our tax structure, income before income taxes moved from foreign jurisdictions to domestic jurisdiction in the year ended December 31, 2019.

[0001262039-21-000008:notes:222]
The provision for (benefit from) income taxes consisted of the following (in millions):

[0001262039-21-000008:notes:223]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| Federal | $ | 38.6 |  |  | $ | 11.0 |  |  | $ | (12.6) |  |
| State | 8.1 |  |  | 0.1 |  |  | 2.0 |  |
| Foreign | 13.6 |  |  | 11.4 |  |  | 36.9 |  |
| Total current | $ | 60.3 |  |  | $ | 22.5 |  |  | $ | 26.3 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (8.1) |  |  | $ | 40.6 |  |  | $ | (124.8) |  |
| State | (0.8) |  |  | (6.0) |  |  | 14.4 |  |
| Foreign | 1.8 |  |  | (2.8) |  |  | 3.5 |  |
| Total deferred | (7.1) |  |  | 31.8 |  |  | (106.9) |  |
| Provision for (benefit from) income taxes | $ | 53.2 |  |  | $ | 54.3 |  |  | $ | (80.6) |  |

[0001262039-21-000008:notes:224]
The foreign tax provision included the tax impacts from U.S. GAAP to local tax return book to tax differences and return to provision adjustments that create a permanent addback including but not limited to stock compensation, meals and entertainment, and settlement of prior year tax audits with foreign jurisdiction adjustments.

[0001262039-21-000008:notes:225]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001262039-21-000008:notes:226]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Tax at federal statutory tax rate | $ | 113.8 |  |  | $ | 81.2 |  |  | $ | 53.4 |  |
| Foreign income taxed at different rates | 16.4 |  |  | 12.3 |  |  | (21.5) |  |
| Foreign withholding taxes | 18.8 |  |  | 16.0 |  |  | 20.1 |  |
| Stock-based compensation expense | (39.6) |  |  | (30.6) |  |  | (14.3) |  |
| Foreign tax credit | (30.1) |  |  | (30.4) |  |  | (15.8) |  |
| State taxes—net of federal benefit | 4.9 |  |  | (11.3) |  |  | 1.2 |  |
| Research and development credit | (7.5) |  |  | (6.8) |  |  | (5.0) |  |
| Valuation allowance | 11.9 |  |  | 22.0 |  |  | 14.9 |  |
| Dividend distribution | — |  |  | — |  |  | (3.8) |  |
| Impact of the 2017 Tax Act: |  |  |  |  |  |
| One-time transition tax | 2.6 |  |  | (2.1) |  |  | 32.6 |  |
| Global Intangible Low-Taxed Income | — |  |  | — |  |  | 20.5 |  |
| Foreign-Derived Intangible Income | (44.3) |  |  | — |  |  | — |  |
| Book-to-Tax Basis differences | — |  |  | — |  |  | (164.0) |  |
| Other | 6.3 |  |  | 4.0 |  |  | 1.1 |  |
| Total provision for (benefit from) income taxes | $ | 53.2 |  |  | $ | 54.3 |  |  | $ | (80.6) |  |

[0001262039-21-000008:notes:227]
We have realigned our tax structure in order to maximize the tax efficiency of our group structure and better align with our business operations as a result of the 2017 Tax Act. This realignment resulted in a book-to-tax basis difference for previously taxed off-shore deferred revenue as well as other book-to-tax difference. The basis differences resulted in a $164.0 million benefit to the 2018 tax provision.

[0001262039-21-000008:notes:228]
In 2018, we completed our analysis to determine the effect of the 2017 Tax Act within the measurement period under the SEC guidance, and reflected an additional $32.6 million increase related to the transition tax in the 2018 income tax expense. In 2019, we recorded a $2.1 million tax benefit related to the transition tax due to the adjustments on prior 2018 foreign tax amounts. The 2017 Tax Act also created a new requirement that GILTI earned by controlled foreign corporations (“CFCs”) must be included currently in the gross income of a CFC’s U.S. shareholder. In 2018, there was also a $20.5 million expense for the GILTI tax regime that was introduced by the 2017 Tax Act. In 2019 and 2020, we were not subject to GILTI. We will continue to monitor and assess the impact of the 2017 Tax Act and ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act.

[0001262039-21-000008:notes:229]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision on Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue and ruled in favor of the Commissioner, validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement. A rehearing of the case was requested, but the rehearing request was denied by the Ninth Circuit on November 12, 2019. A petition was filed with the U.S. Supreme Court on February 10, 2020. On June 22, 2020, the Supreme Court of the United States issued an order declining the petition in Altera. As a result, the Ninth Circuit’s decision requiring that stock-based compensation be included in cost sharing arrangements is the controlling law at present. However, as we are no longer part of a cost sharing arrangement, this does not impact our future income tax provisions. The Ninth Circuit’s decision, together with Supreme Court’s order, did not have a material impact on our consolidated financial statements.

[0001262039-21-000008:notes:230]
The Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law on March 27, 2020. The CARES Act provides numerous tax provisions and other stimulus measures, including temporary changes regarding the prior and future utilization of net operating losses, temporary changes to the prior and future limitations on interest deductions, temporary suspension of certain payment requirements for the employer portion of Social Security taxes, technical corrections from prior tax legislation for tax depreciation of certain qualified improvement property and the creation of certain refundable employee retention credits. We do not expect there to be a material tax impact on our consolidated financial statements at this time and will continue to assess the implications of the CARES Act and its continuing developments and interpretations.

[0001262039-21-000008:notes:231]
On July 9, 2020, the United States Department of the Treasury (the “U.S. Treasury”) and the Internal Revenue Service (the “IRS”) released final Section 250 regulations, providing guidance on the foreign-derived intangible income deduction and the global intangible low-taxed income. Generally, the final regulations are applicable for taxable years beginning on or after January 1, 2021. However, taxpayers may apply the final regulations for taxable years beginning on or after January 1, 2018. We have elected to apply the final regulations to the year ending December 31, 2020 and included the tax impact from the final regulations on our foreign-derived intangible income deduction calculation. In 2020, we recorded a $44.3 million tax benefit related to the foreign-derived intangible income deduction.

[0001262039-21-000008:notes:232]
On September 29, 2020, the U.S. Treasury and the IRS released final regulations related to foreign tax credits that were the subject of proposed regulations issued in December 2019 and proposed certain provisions in proposed regulations issued in December 2019. The final and proposed regulations provide administrative guidance for the foreign tax credit regime, which was updated in the 2017 Tax Act. Generally, the provisions that were included in the 2019 proposed regulations apply to taxable years ending on or after December 16, 2019, except as otherwise specified. The final regulations did not have a material impact on our consolidated financial statements.

[0001262039-21-000008:notes:233]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-21-000008:notes:234]
|  | December 31,2020 |  | December 31,2019 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 48.9 |  |  | $ | 73.2 |  |
| Deferred revenue | 216.4 |  |  | 145.7 |  |
| Reserves and accruals | 41.9 |  |  | 30.7 |  |
| Net operating loss carryforward | 23.4 |  |  | 57.9 |  |
| Stock-based compensation expense | 17.5 |  |  | 14.8 |  |
| Depreciation and amortization | 17.2 |  |  | 0.7 |  |
| Operating lease liabilities | 11.6 |  |  | 10.6 |  |
| Total deferred tax assets | 376.9 |  |  | 333.6 |  |
| Less: Valuation allowance | (54.9) |  |  | (43.0) |  |
| Deferred tax assets, net of valuation allowance | 322.0 |  |  | 290.6 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (74.0) |  |  | (59.9) |  |
| Operating lease ROU assets | (10.8) |  |  | (9.5) |  |
| Total deferred tax liabilities | (84.8) |  |  | (69.4) |  |
| Net deferred tax assets | $ | 237.2 |  |  | $ | 221.2 |  |

[0001262039-21-000008:notes:235]
As of December 31, 2020, we recorded a deferred tax asset of $245.2 million and a deferred tax liability of $8.0 million. In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we will be able to realize the benefits of our deferred tax assets in the future except for our California research and development (“R&D”) credits carryforward, certain impairment losses in business investments, certain foreign tax credits from foreign disregarded entities and certain tax attributes from business acquisitions. We anticipate having sufficient current year generated California R&D credits to cover the same year California tax liability for tax year 2019 and subsequent years. We also believe that it is more likely than not that the deferred tax assets for impairment losses, foreign tax credits from foreign disregarded entities and acquired foreign tax attributes will not be realized. As of December 31, 2020, we recorded a valuation allowance of $54.9 million against deferred tax assets for California R&D credits carryforwards (net of the unrecognized tax benefits), impairment losses, certain foreign tax credits and certain acquired tax attributes.

[0001262039-21-000008:notes:236]
As of December 31, 2020, our federal and California net operating loss carryforwards for income tax purpose were $83.5 million and $20.8 million, respectively. All the net operating loss carryforwards were from acquisitions which were limited by Section 382 of the Internal Revenue Code. If not utilized, the federal net operating loss carryforwards will begin to expire in 2022, and California net operating loss carryforwards will begin to expire in 2034.

[0001262039-21-000008:notes:237]
As of December 31, 2020, we had state tax credit carryforwards of $33.3 million. The state credits can be carried forward indefinitely.

[0001262039-21-000008:notes:238]
Under the 2017 Tax Act, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. For those investments from which we were not able to make a reasonable estimate, we have not recorded any deferred taxes.

[0001262039-21-000008:notes:239]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2020. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-21-000008:notes:240]
As of December 31, 2020, we had $77.3 million of unrecognized tax benefits, of which, if recognized, $70.5 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2020, 2019 and 2018, accrued interest and penalties were $14.5 million, $14.1 million and $11.6 million, respectively.

[0001262039-21-000008:notes:241]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in millions):

[0001262039-21-000008:notes:242]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Unrecognized tax benefits, beginning of year | $ | 67.5 |  |  | $ | 63.5 |  |  | $ | 72.5 |  |
| Gross increases for tax positions related to the current year | 13.1 |  |  | 11.4 |  |  | 8.6 |  |
| Gross decreases for tax positions related to the current year | — |  |  | — |  |  | — |  |
| Gross increases for tax positions related to the prior year | 6.1 |  |  | 3.0 |  |  | 6.0 |  |
| Gross decreases for tax positions related to prior year | (1.3) |  |  | (0.3) |  |  | (9.5) |  |
| Gross decreases for tax positions related to prior year audit settlements | (1.4) |  |  | (1.7) |  |  | (6.4) |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (6.7) |  |  | (8.4) |  |  | (7.7) |  |
| Unrecognized tax benefits, end of year | $ | 77.3 |  |  | $ | 67.5 |  |  | $ | 63.5 |  |

[0001262039-21-000008:notes:243]
As of December 31, 2020, 2019 and 2018, $90.3 million, $82.8 million and $77.5 million, respectively, of the amounts reflected above were recorded as income tax liabilities—non-current in our consolidated balance sheets.

[0001262039-21-000008:notes:244]
We recorded a net increase of gross unrecognized tax benefits of approximately $9.8 million during the year ended December 31, 2020. The net increase was primarily due to the increase in benefits related to the foreign taxes, offset by the reversal of gross unrecognized tax benefits in connection with the lapse of statutes of limitations and the settlement of tax audits in foreign jurisdictions.

[0001262039-21-000008:notes:245]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $4.2 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-21-000008:notes:246]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-21-000008:notes:247]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2020, 2019 and 2018 were $8.3 million, $6.6 million and $5.7 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-21-000008:notes:248]
SEGMENT INFORMATION
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-21-000008:notes:249]
Revenue by geographic region is based on the billing address of our customers. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-21-000008:notes:250]
|  | Year Ended December 31, |
| Revenue | 2020 |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |  |
| United States | $ | 813.3 |  |  | $ | 695.5 |  |  | $ | 578.3 |  |
| Other Americas | 263.9 |  |  | 224.7 |  |  | 186.1 |  |
| Total Americas | 1,077.2 |  |  | 920.2 |  |  | 764.4 |  |
| Europe, Middle East and Africa (“EMEA”) | 991.9 |  |  | 816.5 |  |  | 679.3 |  |
| Asia Pacific (“APAC”) | 525.3 |  |  | 426.3 |  |  | 360.9 |  |
| Total revenue | $ | 2,594.4 |  |  | $ | 2,163.0 |  |  | $ | 1,804.6 |  |

[0001262039-21-000008:notes:251]
| Property and Equipment—net | December 31,2020 |  | December 31,2019 |
| Americas: |  |  |  |
| United States | $ | 296.3 |  |  | $ | 197.4 |  |
| Canada | 121.3 |  |  | 120.5 |  |
| Latin America | 2.0 |  |  | 5.5 |  |
| Total Americas | 419.6 |  |  | 323.4 |  |
| EMEA | 20.6 |  |  | 15.2 |  |
| APAC | 7.8 |  |  | 5.7 |  |
| Total property and equipment—net | $ | 448.0 |  |  | $ | 344.3 |  |


## us-gaap:SubsequentEventsTextBlock

[0001262039-21-000008:notes:252]
SUBSEQUENT EVENT 
Building Purchase

[0001262039-21-000008:notes:253]
In February 2021, we purchased two properties in California totaling approximately 97,000 square feet for an aggregate cash payment of $15.5 million.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-21-000008:notes:254]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-21-000008:notes:255]
|  | Year Ended December 31, |
|  | 2020 (1) |  | 2019 (1) |  | 2018 (1) |
|  | (in millions) |
| Sales Returns Reserve and Allowance for Credit Losses/Doubtful Accounts |  |  |  |  |  |
| Beginning balance | $ | 1.2 |  |  | $ | 0.9 |  |  | $ | 14.5 |  |
| Charged to expenses, net of deductions | 1.3 |  |  | 0.3 |  |  | — |  |
| Reclassification due to adoption of Topic 606 (1) | — |  |  | — |  |  | (13.6) |  |
| Ending balance | $ | 2.5 |  |  | $ | 1.2 |  |  | $ | 0.9 |  |
| (1) Effective January 1, 2018, we reclassified our sales returns reserve in the amount of $13.6 million from accounts receivable to accrued liabilities, in connection with the adoption of Topic 606. The ending balances for the years ended December 31, 2020 and 2019 consist only of the allowance for credit losses or doubtful accounts. |

[0001262039-21-000008:notes:256]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-21-000008:notes:257]
3. Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K.

[0001262039-21-000008:notes:258]
(b) Exhibits:

[0001262039-21-000008:notes:259]
The exhibits listed on the Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-21-000008:notes:260]
(c) Financial Statement Schedules: See Item 15(a) above.
