# FTNT note change history — 0001262039-20-000053 → 0001262039-20-000067


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001262039-20-000067:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2020 (in millions):
  (was, 2020-08-06, similarity 0.9569):
[0001262039-20-000053:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2020 (in millions):

- changed (2020-11-06):
[0001262039-20-000067:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of September 30, 2020, we had $284.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2020-08-06, similarity 0.9904):
[0001262039-20-000053:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2020, we had $282.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2020-11-06):
[0001262039-20-000067:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2020, we had $23.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2020-08-06, similarity 0.9835):
[0001262039-20-000053:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2020, we had $27.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001262039-20-000067:note_history:4]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.
  (was, 2020-08-06, similarity 0.7213):
[0001262039-20-000053:note_history:4]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2019, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2020. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2020 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2019 is derived from the audited consolidated financial statements for the year ended December 31, 2019. For 2020, the amounts previously reported as Income taxes payable are included in Accrued liabilities. Prior periods have been reclassified to conform with current period presentation.

- changed (2020-11-06):
[0001262039-20-000067:note_history:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2020.
  (was, 2020-08-06, similarity 0.9389):
[0001262039-20-000053:note_history:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2020.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001262039-20-000067:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 235.4 |  |  | 192.8 |  |  | 669.4 |  |  | 545.5 |  |
| Technical support and other | 191.9 |  |  | 158.2 |  |  | 549.0 |  |  | 449.7 |  |
| Total service revenue | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |
  (was, 2020-08-06, similarity 0.8728):
[0001262039-20-000053:note_history:6]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 222.6 |  |  | 183.1 |  |  | 434.0 |  |  | 352.7 |  |
| Technical support and other | 181.0 |  |  | 148.7 |  |  | 354.2 |  |  | 289.0 |  |
| Total service revenue | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-11-06):
[0001262039-20-000067:note_history:7]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security appliances, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

- changed (2020-11-06):
[0001262039-20-000067:note_history:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2020 |  | September 30,2019 |  | September 30,2020 |  | September 30,2019 |
| Product | $ | 223.8 |  |  | $ | 197.1 |  |  | $ | 628.0 |  |  | $ | 549.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 235.4 |  |  | 192.8 |  |  | 669.4 |  |  | 545.5 |  |
| Technical support and other | 191.9 |  |  | 158.2 |  |  | 549.0 |  |  | 449.7 |  |
| Total service revenue | 427.3 |  |  | 351.0 |  |  | 1,218.4 |  |  | 995.2 |  |
| Total revenue | $ | 651.1 |  |  | $ | 548.1 |  |  | $ | 1,846.4 |  |  | $ | 1,544.9 |  |
  (was, 2020-08-06, similarity 0.8728):
[0001262039-20-000053:note_history:8]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | June 30,2020 |  | June 30,2019 |  | June 30,2020 |  | June 30,2019 |
| Product | $ | 211.9 |  |  | $ | 189.9 |  |  | $ | 404.2 |  |  | $ | 352.6 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 222.6 |  |  | 183.1 |  |  | 434.0 |  |  | 352.7 |  |
| Technical support and other | 181.0 |  |  | 148.7 |  |  | 354.2 |  |  | 289.0 |  |
| Total service revenue | 403.6 |  |  | 331.8 |  |  | 788.2 |  |  | 641.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 521.7 |  |  | $ | 1,192.4 |  |  | $ | 994.3 |  |

- changed (2020-11-06):
[0001262039-20-000067:note_history:9]
During the three months ended September 30, 2020 and September 30, 2019, we recognized $263.1 million and $211.8 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the nine months ended September 30, 2020 and September 30, 2019, we recognized $921.7 million and $754.5 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.
  (was, 2020-08-06, similarity 0.8568):
[0001262039-20-000053:note_history:9]
During the three months ended June 30, 2020 and June 30, 2019, we recognized $307.9 million and $252.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively. During the six months ended June 30, 2020 and June 30, 2019, we recognized $656.8 million and $540.6 million in service revenue that was included in the deferred revenue balance as of December 31, 2019 and December 31, 2018, respectively.

- changed (2020-11-06):
[0001262039-20-000067:note_history:10]
As of September 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.39 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.30 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2020-08-06, similarity 0.9812):
[0001262039-20-000053:note_history:10]
As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.32 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.28 billion as revenue over the next 12 months and the remainder thereafter.

- added (2020-11-06):
[0001262039-20-000067:note_history:11]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for expected credit losses. We measure expected credit losses of accounts receivable on a collective (pooled) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

- added (2020-11-06):
[0001262039-20-000067:note_history:12]
The allowance for credit losses was $2.2 million as of September 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the nine months ended September 30, 2020.

- changed (2020-11-06):
[0001262039-20-000067:note_history:13]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended September 30, 2020 and September 30, 2019 were $35.3 million and $27.5 million, respectively. Amortization of deferred contract costs during the nine months ended September 30, 2020 and September 30, 2019 were $99.8 million and $78.5 million, respectively.
  (was, 2020-08-06, similarity 0.8895):
[0001262039-20-000053:note_history:13]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2020 and June 30, 2019 were $33.2 million and $25.9 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2020 and June 30, 2019 were $64.5 million and $51.0 million, respectively.

- removed (2020-11-06):
[0001262039-20-000053:note_history:14]
REVENUE RECOGNITION
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our security subscription services, which mainly consist of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

- removed (2020-11-06):
[0001262039-20-000053:note_history:15]
Trade accounts receivable are recorded at the invoiced amount. On January 1, 2020, we adopted Topic 326, which provides guidance on how to measure credit losses on financial instruments, including accounts receivable. Prior to our adoption of Topic 326, our accounts receivable balance was reduced by an allowance for doubtful accounts that we determined based on our assessment of the collectability of customer accounts. Under Topic 326, our accounts receivable balance is reduced by an allowance for credit losses. We measure expected credit losses of accounts receivable on a collective (pool) basis, aggregating accounts receivable that are either current or no more than 60 days past due, and aggregating accounts receivable that are more than 60 days past due. We apply a credit-loss percentage to each of the pools that is based on our historical credit losses. We review whether each of our significant accounts receivable that is more than 60 days past due

- removed (2020-11-06):
[0001262039-20-000053:note_history:16]
continues to exhibit similar risk characteristics with the other accounts receivable in the pool. If we determine that it does not, we evaluate it for expected credit losses on an individual basis.

- removed (2020-11-06):
[0001262039-20-000053:note_history:17]
The allowance for credit losses was $2.2 million as of June 30, 2020, and the allowance for doubtful accounts was $1.2 million as of December 31, 2019. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-11-06):
[0001262039-20-000053:note_history:18]
SUBSEQUENT EVENTS
Share Repurchase

- removed (2020-11-06):
[0001262039-20-000053:note_history:19]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. As of August 6, 2020, $1.05 billion remained available for future share repurchases under the Repurchase Program.

- removed (2020-11-06):
[0001262039-20-000053:note_history:20]
Business Combination

- removed (2020-11-06):
[0001262039-20-000053:note_history:21]
On July 20, 2020, we acquired OPAQ Networks, Inc. (“OPAQ”), a privately held Secure Access Service Edge cloud provider. We acquired OPAQ for approximately $13.0 million in cash consideration, subject to certain adjustments.

- removed (2020-11-06):
[0001262039-20-000053:note_history:22]
We are currently in the process of evaluating the business combination accounting, including the consideration transferred and the initial purchase price allocation.
