# FTNT 8-K — 0001262039-21-000005 filed 2021-02-04

## item codes, every 8-K on or before 2021-02-19

- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2021-02-19

- none on or before 2021-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001262039-21-000005:8k_2_02:1]
EX-99.1
2
ftntq4-2020ex991.htm
EX-99.1

[0001262039-21-000005:8k_2_02:2]
Document

[0001262039-21-000005:8k_2_02:3]
Press Release

[0001262039-21-000005:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2020 Financial Results

[0001262039-21-000005:8k_2_02:5]
Fourth Quarter 2020 Highlights

[0001262039-21-000005:8k_2_02:6]
•Total revenue of $748.0 million, up 21% year over year

[0001262039-21-000005:8k_2_02:7]
•Product revenue of $288.4 million, up 21% year over year

[0001262039-21-000005:8k_2_02:8]
•Service revenue of $459.6 million, up 21% year over year

[0001262039-21-000005:8k_2_02:9]
•Billings of $960.9 million, up 20% year over year1

[0001262039-21-000005:8k_2_02:10]
•GAAP operating margin of 22.6%, up 280 basis points year over year

[0001262039-21-000005:8k_2_02:11]
•Non-GAAP operating margin of 29.4%, up 210 basis points year over year1

[0001262039-21-000005:8k_2_02:12]
•GAAP diluted net income per share of $0.89

[0001262039-21-000005:8k_2_02:13]
•Non-GAAP diluted net income per share of $1.061

[0001262039-21-000005:8k_2_02:14]
•Cash flow from operations of $296.5 million

[0001262039-21-000005:8k_2_02:15]
•Free cash flow of $264.2 million1

[0001262039-21-000005:8k_2_02:16]
Full Year 2020 Highlights

[0001262039-21-000005:8k_2_02:17]
•Total revenue of $2.59 billion, up 20% year over year

[0001262039-21-000005:8k_2_02:18]
•Product revenue of $916.4 million, up 16% year over year

[0001262039-21-000005:8k_2_02:19]
•Service revenue of $1.68 billion, up 22% year over year

[0001262039-21-000005:8k_2_02:20]
•Billings of $3.09 billion, up 19% year over year1

[0001262039-21-000005:8k_2_02:21]
•Deferred revenue of $2.61 billion, up 24% year over year

[0001262039-21-000005:8k_2_02:22]
•GAAP operating margin of 20.5%, up 430 basis points year over year

[0001262039-21-000005:8k_2_02:23]
•Non-GAAP operating margin of 26.9%, up 210 basis points year over year1

[0001262039-21-000005:8k_2_02:24]
•GAAP diluted net income per share of $2.91

[0001262039-21-000005:8k_2_02:25]
•Non-GAAP diluted net income per share of $3.351

[0001262039-21-000005:8k_2_02:26]
•Cash flow from operations of $1.08 billion

[0001262039-21-000005:8k_2_02:27]
•Free cash flow of $907.8 million1

[0001262039-21-000005:8k_2_02:28]
SUNNYVALE, Calif. - February 4, 2021 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the fourth quarter and full year ended December 31, 2020.

[0001262039-21-000005:8k_2_02:29]
"We reported our third consecutive year of product revenue growth of approximately 16%, services revenue growth of approximately 22% and total organic revenue growth of approximately 20%. These results were driven by a strong worldwide sales operation, an innovative culture that results in a diversified product set and the market’s growing demand for cybersecurity products both on-premise and in the cloud. Our solid 2020 revenue performance led to an all-time company high non-GAAP operating margin of 26.9%,” said Ken Xie, Founder, Chairman, and Chief Executive Officer. “Given the many growth opportunities that lie ahead for us, we plan to shift our focus more to growth for at least the next several quarters.”

[0001262039-21-000005:8k_2_02:30]
Financial Highlights for the Fourth Quarter of 20202

[0001262039-21-000005:8k_2_02:31]
•Revenue: Total revenue was $748.0 million for the fourth quarter of 2020, an increase of 21.0% compared to $618.1 million for the same quarter of 2019.

[0001262039-21-000005:8k_2_02:32]
•Product Revenue: Product revenue was $288.4 million for the fourth quarter of 2020, an increase of 20.8% compared to $238.8 million for the same quarter of 2019.

[0001262039-21-000005:8k_2_02:33]
•Service Revenue: Service revenue was $459.6 million for the fourth quarter of 2020, an increase of 21.2% compared to $379.3 million for the same quarter of 2019.

[0001262039-21-000005:8k_2_02:34]
•Billings1: Total billings were $960.9 million for the fourth quarter of 2020, an increase of 19.8% compared to $802.3 million for the same quarter of 2019.

[0001262039-21-000005:8k_2_02:35]
•GAAP Operating Income and Margin: GAAP operating income was $169.4 million for the fourth quarter of 2020, representing a GAAP operating margin of 22.6%. GAAP operating income was $122.1 million for the same quarter of 2019, representing a GAAP operating margin of 19.8%.

[0001262039-21-000005:8k_2_02:36]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $219.9 million for the fourth quarter of 2020, representing a non-GAAP operating margin of 29.4%. Non-GAAP operating income was $168.6 million for the fourth quarter of 2019, representing a non-GAAP operating margin of 27.3%.

[0001262039-21-000005:8k_2_02:37]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $146.7 million for the fourth quarter of 2020, compared to GAAP net income of $118.2 million for the same quarter of 2019. GAAP diluted net income per share was $0.89 for the fourth quarter of 2020, based on 165.5 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.67 for the same quarter of 2019, based on 175.2 million diluted weighted-average shares outstanding.

[0001262039-21-000005:8k_2_02:38]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $175.5 million for the fourth quarter of 2020, compared to non-GAAP net income of $135.1 million for the same quarter of 2019. Non-GAAP diluted net income per share was $1.06 for the fourth quarter of 2020, based on 165.5 million diluted weighted-average shares outstanding, compared to $0.77 for the same quarter of 2019, based on 175.2 million diluted weighted-average shares outstanding.

[0001262039-21-000005:8k_2_02:39]
•Cash Flow: In the fourth quarter of 2020, cash flow from operations was $296.5 million compared to $190.4 million in the same quarter of 2019.

[0001262039-21-000005:8k_2_02:40]
•Free Cash Flow1: Free cash flow was $264.2 million during the fourth quarter of 2020, compared to $143.2 million for the same quarter of 2019.

[0001262039-21-000005:8k_2_02:41]
Financial Highlights for the Full Year 20202

[0001262039-21-000005:8k_2_02:42]
•Revenue: Total revenue was $2.59 billion for 2020, an increase of 19.9% compared to $2.16 billion in 2019.

[0001262039-21-000005:8k_2_02:43]
•Product Revenue: Product revenue was $916.4 million for 2020, an increase of 16.2% compared to $788.5 million in 2019.

[0001262039-21-000005:8k_2_02:44]
•Service Revenue: Service revenue was $1.68 billion for 2020, an increase of 22.1% compared to $1.37 billion in 2019.

[0001262039-21-000005:8k_2_02:45]
•Billings1: Total billings were $3.09 billion for 2020, an increase of 18.7% compared to $2.60 billion in 2019.

[0001262039-21-000005:8k_2_02:46]
•Deferred Revenue: Total deferred revenue was $2.61 billion as of December 31, 2020, an increase of 23.5% compared to $2.11 billion as of December 31, 2019.

[0001262039-21-000005:8k_2_02:47]
•GAAP Operating Income and Margin: GAAP operating income was $531.8 million for  2020, representing a GAAP operating margin of 20.5%. GAAP operating income was $351.0 million for 2019, representing a GAAP operating margin of 16.2%.

[0001262039-21-000005:8k_2_02:48]
•Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $698.0 million for 2020, representing a non-GAAP operating margin of 26.9%. Non-GAAP operating income was $536.0 million for 2019, representing a non-GAAP operating margin of 24.8%.

[0001262039-21-000005:8k_2_02:49]
•GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $488.5 million for 2020, compared to GAAP net income of $331.7 million for 2019. GAAP diluted net income per share was $2.91 for 2020, based on 167.7 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $1.90 for 2019, based on 175.0 million diluted weighted-average shares outstanding.

[0001262039-21-000005:8k_2_02:50]
•Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $562.6 million for 2020, compared to non-GAAP net income of $436.7 million for 2019. Non-GAAP diluted net income per share was $3.35 for 2020, based on 167.7 million diluted weighted-average shares outstanding, compared to $2.50 for 2019, based on 175.0 million diluted weighted-average shares outstanding.

[0001262039-21-000005:8k_2_02:51]
•Cash Flow: In 2020, cash flow from operations was $1.08 billion compared to $808.0 million in 2019.

[0001262039-21-000005:8k_2_02:52]
•Free Cash Flow1: Free cash flow was $907.8 million during 2020, compared to $715.8 million in 2019.

[0001262039-21-000005:8k_2_02:53]
Guidance

[0001262039-21-000005:8k_2_02:54]
For the first quarter of 2021, Fortinet currently expects:

[0001262039-21-000005:8k_2_02:55]
•Revenue in the range of $670 million to $685 million

[0001262039-21-000005:8k_2_02:56]
•Billings in the range of $765 million to $780 million

[0001262039-21-000005:8k_2_02:57]
•Non-GAAP gross margin in the range of 78.5% to 79.5%

[0001262039-21-000005:8k_2_02:58]
•Non-GAAP operating margin in the range of 22.5% to 23.5%

[0001262039-21-000005:8k_2_02:59]
•Diluted non-GAAP net income per share in the range of $0.70 to $0.75, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 167 million to 169 million.

[0001262039-21-000005:8k_2_02:60]
For the fiscal year 2021, Fortinet currently expects:

[0001262039-21-000005:8k_2_02:61]
•Revenue in the range of $3.025 billion to $3.075 billion

[0001262039-21-000005:8k_2_02:62]
•Service revenue in the range of $2.015 billion to $2.045 billion

[0001262039-21-000005:8k_2_02:63]
•Billings in the range of $3.560 billion to $3.640 billion

[0001262039-21-000005:8k_2_02:64]
•Non-GAAP gross margin in the range of 78.0% to 80.0%

[0001262039-21-000005:8k_2_02:65]
•Non-GAAP operating margin in the range of 25.0% to 27.0%

[0001262039-21-000005:8k_2_02:66]
•Diluted non-GAAP net income per share in the range of $3.60 to $3.75, assuming a non-GAAP effective tax rate of 21%. This assumes a diluted share count of 170 million to 172 million.

[0001262039-21-000005:8k_2_02:67]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets and gain on intellectual property matter. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-21-000005:8k_2_02:68]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-21-000005:8k_2_02:69]
2 Fortinet identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an immaterial correction to revenue for prior year reported amounts for the six months ended June 30, 2020. All financial information contained herein has been revised to reflect the correction of this error.

[0001262039-21-000005:8k_2_02:70]
Conference Call Details

[0001262039-21-000005:8k_2_02:71]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 9656007. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through February 11, 2021, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #9656007.

[0001262039-21-000005:8k_2_02:72]
First Quarter 2021 Virtual Conference Participation Schedule:

[0001262039-21-000005:8k_2_02:73]
•Goldman Sachs Technology and Internet Conference 2021

[0001262039-21-000005:8k_2_02:74]
February 10, 2021

[0001262039-21-000005:8k_2_02:75]
•Morgan Stanley TMT Conference

[0001262039-21-000005:8k_2_02:76]
March 2, 2021

[0001262039-21-000005:8k_2_02:77]
•Fortinet Virtual Accelerate 2021 & Analyst/Investor Day

[0001262039-21-000005:8k_2_02:78]
March 9, 2021

[0001262039-21-000005:8k_2_02:79]
Management Keynotes:                     8:00 AM PT – 9:30 AM PT

[0001262039-21-000005:8k_2_02:80]
CFO presentation & Q&A session:    10:00 AM PT – 11:30 AM PT

[0001262039-21-000005:8k_2_02:81]
Registration Link:

[0001262039-21-000005:8k_2_02:82]
https://www.fortinetaccelerate.com/2021americas/register?reg_type_id=140747

[0001262039-21-000005:8k_2_02:83]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at https://investor.fortinet.com. The schedule is subject to change.

[0001262039-21-000005:8k_2_02:84]
About Fortinet (www.fortinet.com)

[0001262039-21-000005:8k_2_02:85]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with complete visibility and control across the expanding attack surface and the power to take on ever-increasing performance requirements today and into the future. The Fortinet Security Fabric platform can address the most critical security challenges and protect data across the entire digital infrastructure, whether in networked, application, multi-cloud or edge environments. Both a technology company and a learning organization, the Fortinet Network Security Institute has one of the largest and broadest cybersecurity training programs in the industry. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-21-000005:8k_2_02:86]
#          #          #

[0001262039-21-000005:8k_2_02:87]
Copyright © 2021 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAI, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiCWP, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiEDR, FortiExplorer, FortiExtender, FortiFirewall, FortiFone, FortiGSLB, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPenTest, FortiPhish, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiSASE, FortiScan, FortiSDNConnector, FortiSIEM, FortiSDWAN, FortiSMS, FortiSOAR, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVoice, FortiVoIP, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-21-000005:8k_2_02:88]
FTNT-F

[0001262039-21-000005:8k_2_02:89]
Forward-Looking Statements

[0001262039-21-000005:8k_2_02:90]
COVID-19 Impact

[0001262039-21-000005:8k_2_02:91]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources. Going forward, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods, including our results for the three months ending March 31, 2021 and beyond. To highlight the uncertainty remaining for the three month period ending March 31, 2021, it should be noted that, due to customer buying patterns and the efforts of our sales force and channel partners to meet or exceed quarterly quotas, we have historically received a substantial portion of each quarter’s sales orders and generated a substantial portion of each quarter’s billings and revenue during the last two weeks of the quarter. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods.

[0001262039-21-000005:8k_2_02:92]
Non-GAAP Financial Measures

[0001262039-21-000005:8k_2_02:93]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-21-000005:8k_2_02:94]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-21-000005:8k_2_02:95]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-21-000005:8k_2_02:96]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matter. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matter, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matter, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-21-000005:8k_2_02:97]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, impairment and amortization of acquired intangible assets, less gain on intellectual property matter and, when applicable, other significant non-recurring items in a given quarter, such as non-recurring gains or losses on litigation-related matters. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-21-000005:8k_2_02:98]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on investments in privately held companies and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same

[0001262039-21-000005:8k_2_02:99]
limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-21-000005:8k_2_02:100]
FORTINET, INC.

[0001262039-21-000005:8k_2_02:101]
CONDENSED CONSOLIDATED BALANCE SHEETS1

[0001262039-21-000005:8k_2_02:102]
(Unaudited, in millions)

[0001262039-21-000005:8k_2_02:103]
|  | December 31,2020 |  | December 31,2019 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,061.8 |  |  | $ | 1,222.5 |  |
| Short-term investments | 775.5 |  |  | 843.1 |  |
| Accounts receivable—net | 720.0 |  |  | 544.3 |  |
| Inventory | 139.8 |  |  | 117.9 |  |
| Prepaid expenses and other current assets | 43.3 |  |  | 41.2 |  |
| Total current assets | 2,740.4 |  |  | 2,769.0 |  |
| LONG-TERM INVESTMENTS | 118.3 |  |  | 144.3 |  |
| PROPERTY AND EQUIPMENT—NET | 448.0 |  |  | 344.3 |  |
| DEFERRED CONTRACT COSTS | 304.8 |  |  | 237.0 |  |
| DEFERRED TAX ASSETS | 245.2 |  |  | 226.3 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 124.6 |  |  | 98.3 |  |
| OTHER ASSETS | 63.2 |  |  | 60.0 |  |
| TOTAL ASSETS | $ | 4,044.5 |  |  | $ | 3,879.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 141.6 |  |  | $ | 96.4 |  |
| Accrued liabilities | 149.2 |  |  | 101.8 |  |
| Accrued payroll and compensation | 145.9 |  |  | 101.8 |  |
| Deferred revenue | 1,392.8 |  |  | 1,155.8 |  |
| Total current liabilities | 1,829.5 |  |  | 1,455.8 |  |
| DEFERRED REVENUE | 1,212.5 |  |  | 953.3 |  |
| INCOME TAX LIABILITIES | 90.3 |  |  | 82.8 |  |
| OTHER LIABILITIES | 56.2 |  |  | 44.9 |  |
| Total liabilities | 3,188.5 |  |  | 2,536.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,207.2 |  |  | 1,180.3 |  |
| Accumulated other comprehensive income | 0.7 |  |  | 1.1 |  |
| Retained earnings (accumulated deficit) | (352.1) |  |  | 160.8 |  |
| Total stockholders’ equity | 856.0 |  |  | 1,342.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 4,044.5 |  |  | $ | 3,879.2 |  |

[0001262039-21-000005:8k_2_02:104]
1 Fortinet identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an immaterial correction to revenue for prior year reported amounts for the six months ended June 30, 2020. All financial information contained herein has been revised to reflect the correction of this error.

[0001262039-21-000005:8k_2_02:105]
FORTINET, INC.

[0001262039-21-000005:8k_2_02:106]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME1

[0001262039-21-000005:8k_2_02:107]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000005:8k_2_02:108]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2020 |  | December 31,2019 |  | December 31,2020 |  | December 31,2019 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 288.4 |  |  | $ | 238.8 |  |  | $ | 916.4 |  |  | $ | 788.5 |  |
| Service | 459.6 |  |  | 379.3 |  |  | 1,678.0 |  |  | 1,374.5 |  |
| Total revenue | 748.0 |  |  | 618.1 |  |  | 2,594.4 |  |  | 2,163.0 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 107.4 |  |  | 92.7 |  |  | 352.4 |  |  | 324.6 |  |
| Service | 59.6 |  |  | 47.8 |  |  | 217.6 |  |  | 181.3 |  |
| Total cost of revenue | 167.0 |  |  | 140.5 |  |  | 570.0 |  |  | 505.9 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 181.0 |  |  | 146.1 |  |  | 564.0 |  |  | 463.9 |  |
| Service | 400.0 |  |  | 331.5 |  |  | 1,460.4 |  |  | 1,193.2 |  |
| Total gross profit | 581.0 |  |  | 477.6 |  |  | 2,024.4 |  |  | 1,657.1 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 89.0 |  |  | 71.2 |  |  | 341.4 |  |  | 277.1 |  |
| Sales and marketing | 291.4 |  |  | 257.1 |  |  | 1,071.9 |  |  | 926.9 |  |
| General and administrative | 32.4 |  |  | 27.2 |  |  | 119.5 |  |  | 102.1 |  |
| Gain on intellectual property matter | (1.2) |  |  | — |  |  | (40.2) |  |  | — |  |
| Total operating expenses | 411.6 |  |  | 355.5 |  |  | 1,492.6 |  |  | 1,306.1 |  |
| OPERATING INCOME | 169.4 |  |  | 122.1 |  |  | 531.8 |  |  | 351.0 |  |
| INTEREST INCOME—NET | 2.0 |  |  | 9.9 |  |  | 17.7 |  |  | 42.5 |  |
| OTHER INCOME (EXPENSE)—NET | 0.3 |  |  | (0.6) |  |  | (7.8) |  |  | (7.5) |  |
| INCOME BEFORE INCOME TAXES | 171.7 |  |  | 131.4 |  |  | 541.7 |  |  | 386.0 |  |
| PROVISION FOR INCOME TAXES | 25.0 |  |  | 13.2 |  |  | 53.2 |  |  | 54.3 |  |
| NET INCOME | $ | 146.7 |  |  | $ | 118.2 |  |  | $ | 488.5 |  |  | $ | 331.7 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.90 |  |  | $ | 0.69 |  |  | $ | 2.98 |  |  | $ | 1.94 |  |
| Diluted | $ | 0.89 |  |  | $ | 0.67 |  |  | $ | 2.91 |  |  | $ | 1.90 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 162.5 |  |  | 171.5 |  |  | 164.2 |  |  | 171.0 |  |
| Diluted | 165.5 |  |  | 175.2 |  |  | 167.7 |  |  | 175.0 |  |

[0001262039-21-000005:8k_2_02:109]
1 Fortinet identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an immaterial correction to revenue for prior year reported amounts for the six months ended June 30, 2020. All financial information contained herein has been revised to reflect the correction of this error.

[0001262039-21-000005:8k_2_02:110]
FORTINET, INC.

[0001262039-21-000005:8k_2_02:111]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS1

[0001262039-21-000005:8k_2_02:112]
(Unaudited, in millions)

[0001262039-21-000005:8k_2_02:113]
|  | Year Ended |
|  | December 31,2020 |  | December 31,2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 488.5 |  |  | $ | 331.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 191.7 |  |  | 174.1 |  |
| Amortization of deferred contract costs | 137.4 |  |  | 107.9 |  |
| Depreciation and amortization | 68.8 |  |  | 61.6 |  |
| Amortization of investment premium (discounts) | 1.3 |  |  | (6.0) |  |
| Other | 6.0 |  |  | 5.7 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | (176.4) |  |  | (96.7) |  |
| Inventory | (42.2) |  |  | (48.5) |  |
| Prepaid expenses and other current assets | (2.8) |  |  | (2.1) |  |
| Deferred contract costs | (205.1) |  |  | (162.3) |  |
| Deferred tax assets | (10.5) |  |  | 19.4 |  |
| Other assets | (4.6) |  |  | (1.3) |  |
| Accounts payable | 37.4 |  |  | 7.7 |  |
| Accrued liabilities | 45.8 |  |  | (20.2) |  |
| Accrued payroll and compensation | 43.1 |  |  | (2.7) |  |
| Other liabilities | 9.7 |  |  | (0.2) |  |
| Deferred revenue | 495.6 |  |  | 439.9 |  |
| Net cash provided by operating activities | 1,083.7 |  |  | 808.0 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (1,079.0) |  |  | (1,332.3) |  |
| Sales of investments | 152.2 |  |  | 31.3 |  |
| Maturities of investments | 1,018.8 |  |  | 925.5 |  |
| Purchases of property and equipment | (125.9) |  |  | (92.2) |  |
| Payments made in connection with business combination, net of cash acquired | (40.2) |  |  | (34.6) |  |
| Other | 1.3 |  |  | — |  |
| Net cash used in investing activities | (72.8) |  |  | (502.3) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (1,080.1) |  |  | (145.1) |  |
| Proceeds from issuance of common stock | 22.1 |  |  | 49.5 |  |
| Taxes paid related to net share settlement of equity awards | (108.2) |  |  | (96.0) |  |
| Payment of debt assumed in connection with business combination | (4.1) |  |  | (3.7) |  |
| Other | (1.3) |  |  | (0.3) |  |
| Net cash used in financing activities | (1,171.6) |  |  | (195.6) |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (160.7) |  |  | 110.1 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 1,222.5 |  |  | 1,112.4 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 1,061.8 |  |  | $ | 1,222.5 |  |

[0001262039-21-000005:8k_2_02:114]
1 Fortinet identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an immaterial correction to revenue for prior year reported amounts for the six months ended June 30, 2020. All financial information contained herein has been revised to reflect the correction of this error.

[0001262039-21-000005:8k_2_02:115]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-21-000005:8k_2_02:116]
(Unaudited, in millions, except per share amounts)

[0001262039-21-000005:8k_2_02:117]
Reconciliation of net cash provided by operating activities to free cash flow1

[0001262039-21-000005:8k_2_02:118]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2020 |  | December 31,2019 |  | December 31,2020 |  | December 31,2019 |
| Net cash provided by operating activities | $ | 296.5 |  |  | $ | 190.4 |  |  | $ | 1,083.7 |  |  | $ | 808.0 |  |
| Less: Purchases of property and equipment | (32.3) |  |  | (47.2) |  |  | (125.9) |  |  | (92.2) |  |
| Less: Proceeds from intellectual property matter | — |  |  | — |  |  | (50.0) |  |  | — |  |
| Free cash flow | $ | 264.2 |  |  | $ | 143.2 |  |  | $ | 907.8 |  |  | $ | 715.8 |  |
| Net cash used in investing activities | $ | (65.0) |  |  | $ | (99.6) |  |  | $ | (72.8) |  |  | $ | (502.3) |  |
| Net cash used in financing activities | $ | (52.0) |  |  | $ | (43.8) |  |  | $ | (1,171.6) |  |  | $ | (195.6) |  |

[0001262039-21-000005:8k_2_02:119]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share1

[0001262039-21-000005:8k_2_02:120]
|  | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 169.4 |  |  | $ | 50.5 |  | (a) | $ | 219.9 |  |  | $ | 122.1 |  |  | $ | 46.5 |  | (b) | $ | 168.6 |  |
| Operating margin | 22.6 | % |  |  |  | 29.4 | % |  | 19.8 | % |  |  |  | 27.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 48.9 |  |  |  |  |  |  | 43.7 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.8 |  |  |  |  |  |  | 2.8 |  |  |  |
| Gain on intellectual property matter |  |  | (1.2) |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (21.7) |  | (c) |  |  |  |  | (29.6) |  | (c) |  |
| Net income | $ | 146.7 |  |  | $ | 28.8 |  |  | $ | 175.5 |  |  | $ | 118.2 |  |  | $ | 16.9 |  |  | $ | 135.1 |  |
| Diluted net income per share | $ | 0.89 |  |  |  |  | $ | 1.06 |  |  | $ | 0.67 |  |  |  |  | $ | 0.77 |  |
| Shares used in diluted net income per share calculations | 165.5 |  |  |  |  | 165.5 |  |  | 175.2 |  |  |  |  | 175.2 |  |

[0001262039-21-000005:8k_2_02:121]
(a) To exclude $48.9 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets, offset by a $1.2 million gain on intellectual property matter, in the three months ended December 31, 2020.

[0001262039-21-000005:8k_2_02:122]
(b) To exclude $43.7 million of stock-based compensation and $2.8 million of amortization of acquired intangible assets in the three months ended December 31, 2019.

[0001262039-21-000005:8k_2_02:123]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 21% and 24% in 2020 and 2019, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-21-000005:8k_2_02:124]
|  | Year Ended December 31, 2020 |  | Year Ended December 31, 2019 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 531.8 |  |  | $ | 166.2 |  | (a) | $ | 698.0 |  |  | $ | 351.0 |  |  | $ | 185.0 |  | (b) | $ | 536.0 |  |
| Operating margin | 20.5 | % |  |  |  | 26.9 | % |  | 16.2 | % |  |  |  | 24.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 193.8 |  |  |  |  |  |  | 174.1 |  |  |  |
| Amortization of acquired intangible assets |  |  | 13.3 |  |  |  |  |  |  | 10.9 |  |  |  |
| Gain on intellectual property matter |  |  | (40.2) |  |  |  |  |  |  | — |  |  |  |
| Litigation-related matter |  |  | (0.7) |  |  |  |  |  |  | — |  |  |  |
| Loss on investments in privately-held companies |  |  | 4.3 |  | (c) |  |  |  |  | 3.8 |  | (d) |  |
| Tax adjustment |  |  | (96.4) |  | (e) |  |  |  |  | (83.8) |  | (e) |  |
| Net income | $ | 488.5 |  |  | $ | 74.1 |  |  | $ | 562.6 |  |  | $ | 331.7 |  |  | $ | 105.0 |  |  | $ | 436.7 |  |
| Diluted net income per share | $ | 2.91 |  |  |  |  | $ | 3.35 |  |  | $ | 1.90 |  |  |  |  | $ | 2.50 |  |
| Shares used in diluted net income per share calculations | 167.7 |  |  |  |  | 167.7 |  |  | 175.0 |  |  |  |  | 175.0 |  |

[0001262039-21-000005:8k_2_02:125]
(a) To exclude $193.8 million of stock-based compensation and $13.3 million of amortization of acquired intangible assets, offset by a $40.2 million gain on intellectual property matter and a $0.7 million adjustment for a litigation-related matter in 2020.

[0001262039-21-000005:8k_2_02:126]
(b) To exclude $174.1 million of stock-based compensation and $10.9 million of amortization of acquired intangible assets in 2019.

[0001262039-21-000005:8k_2_02:127]
(c) To exclude a $4.3 million impairment charge on an investment in a privately held company in 2020.

[0001262039-21-000005:8k_2_02:128]
(d) To exclude a $3.8 million impairment charge on an investment in a privately held company in 2019.

[0001262039-21-000005:8k_2_02:129]
(e) Non-GAAP financial information is adjusted to an overall effective tax rate of 21% and 24% in 2020 and 2019, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-21-000005:8k_2_02:130]
Reconciliation of total revenue to total billings1

[0001262039-21-000005:8k_2_02:131]
|  | Three Months Ended |  | Year Ended |
|  | December 31,2020 |  | December 31,2019 |  | December 31,2020 |  | December 31,2019 |
| Total revenue | $ | 748.0 |  |  | $ | 618.1 |  |  | $ | 2,594.4 |  |  | $ | 2,163.0 |  |
| Add: Change in deferred revenue | 213.3 |  |  | 186.6 |  |  | 496.2 |  |  | 442.3 |  |
| Less: Deferred revenue balance acquired in business acquisitions | (0.4) |  |  | (2.4) |  |  | (0.6) |  |  | (2.4) |  |
| Total billings | $ | 960.9 |  |  | $ | 802.3 |  |  | $ | 3,090.0 |  |  | $ | 2,602.9 |  |

[0001262039-21-000005:8k_2_02:132]
1 Fortinet identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an immaterial correction to revenue for prior year reported amounts for the six months ended June 30, 2020. All financial information contained herein has been revised to reflect the correction of this error.

[0001262039-21-000005:8k_2_02:133]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
