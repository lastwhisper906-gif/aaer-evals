# FTNT MD&A — 0001262039-21-000008


## mdna

[0001262039-21-000008:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-21-000008:mdna:2]
•the duration and impact of the COVID-19 pandemic;

[0001262039-21-000008:mdna:3]
•continued growth and market share gains;

[0001262039-21-000008:mdna:4]
•variability in sales in certain product categories from year to year and between quarters;

[0001262039-21-000008:mdna:5]
•expected impact of sales of certain products and services;

[0001262039-21-000008:mdna:6]
•the impact of macro-economic, geopolitical factors and other disruption on our manufacturing or sales, including the impact of the COVID-19 pandemic and other public health issues and natural disasters;

[0001262039-21-000008:mdna:7]
•the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts;

[0001262039-21-000008:mdna:8]
•the impact of our product innovation strategy;

[0001262039-21-000008:mdna:9]
•the effects of government regulation, tariffs and other related policies;

[0001262039-21-000008:mdna:10]
•drivers of long-term growth and operating leverage, such as sales productivity, functionality and value in our standalone and bundled subscription service offerings;

[0001262039-21-000008:mdna:11]
•growing our sales to businesses, service providers and government organizations, our ability to execute these sales and of the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization;

[0001262039-21-000008:mdna:12]
•our ability to hire properly qualified and effective sales, support and engineering employees;

[0001262039-21-000008:mdna:13]
•trends in revenue, cost of revenue and gross margin;

[0001262039-21-000008:mdna:14]
•trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses;

[0001262039-21-000008:mdna:15]
•risks and expectations related to acquisitions, including integration issues related to product plans and products, including the acquired technology;

[0001262039-21-000008:mdna:16]
•expectations that our operating expense will increase in absolute dollars during 2021;

[0001262039-21-000008:mdna:17]
•expectations that proceeds from the exercise of stock options in future years will be adversely impacted by the increased mix of restricted stock units versus stock options granted;

[0001262039-21-000008:mdna:18]
•estimates of a range of 2021 spending on our headquarters expansion project and of the anticipated completion timeline for the project;

[0001262039-21-000008:mdna:19]
•expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”) and the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”);

[0001262039-21-000008:mdna:20]
•expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows;

[0001262039-21-000008:mdna:21]
•competition in our markets;

[0001262039-21-000008:mdna:22]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-21-000008:mdna:23]
•our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months;

[0001262039-21-000008:mdna:24]
•other statements regarding our future operations, financial condition and prospects and business strategies; and

[0001262039-21-000008:mdna:25]
•adoption and impact of new accounting standards.

[0001262039-21-000008:mdna:26]
Business Overview

[0001262039-21-000008:mdna:27]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response.

[0001262039-21-000008:mdna:28]
The focus areas of our business consist of:

[0001262039-21-000008:mdna:29]
•Security-Driven Networking—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, next-generation firewall, secure web gateway, secure sockets layer (“SSL”) inspection, software-defined wide area network (“SD-WAN”), Intrusion Prevention system(“IPS”), sandboxing, data leak prevention, virtual private network (“VPN”), switch and wireless controller and wide area network (“WAN”) edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. We enhance the performance of our network security appliances from branch to data center by designing and implementing Security Processing Units (“SPUs”) technology within our appliances, enabling us to add security and network functionality with minimal impact to network throughput performance.

[0001262039-21-000008:mdna:30]
•Infrastructure Security—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. Other infrastructure solutions covered include teleworker and remote security solutions such as FortiAuthenticator, FortiClient and FortiToken, as well as Secure Access (Wi-Fi and switch).

[0001262039-21-000008:mdna:31]
•Dynamic Cloud Security—We help customers connect securely to and across their individual, hybrid and multi-cloud environments by offering security through our virtual firewall and other software products and through integrated capabilities with major cloud platforms. Our public and private cloud security solutions, including virtual appliances and hosted solutions, extend the core capabilities of the Fortinet Security Fabric platform in and across cloud environments, delivering security that follows their applications and data. Our Secure SD-WAN for Multi-Cloud solution automates deployment of an overlay network across different cloud networks and offers visibility, control and centralized management that integrates functionality across multiple cloud environments. Our Cloud Security portfolio also includes securing applications, including email and web. Fortinet cloud security offerings are available for deployment in major public and private cloud environments, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud, IBM Cloud and VMWare Cloud. We also offer managed IPS and web application firewall (“WAF”) rules delivered by FortiGuard Labs as an overlay service to native security offerings offered by Amazon Web Services.

[0001262039-21-000008:mdna:32]
•Endpoint Protection, Internet of Things (“IoT”) and Operational Technology (“OT”) Security—We protect end-customers from advanced threats that target their devices and the data that reside on them through our advanced endpoint solutions that provide core endpoint protection, advanced threat protection, incident monitoring, and response. Additionally, the proliferation of IoT and OT devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices.

[0001262039-21-000008:mdna:33]
•AI-Driven Security Operations—We develop and provide Artificial Intelligence (“AI”) driven security operations solutions, including FortiGuard and other security subscription services, endpoint detection and response, and our security orchestration, automation and response (“SOAR”) capabilities and solutions, that can be applied across the entire Fortinet Security Fabric platform. These solutions deliver intelligence and insights.

[0001262039-21-000008:mdna:34]
In addition to our security solutions, our customers may purchase FortiGuard and other security subscription services to receive threat intelligence updates and protection updates delivered by FortiGuard Labs, FortiCare technical support services and the support of TAMs, REs and professional service consultants for implementations or training services.

[0001262039-21-000008:mdna:35]
Correction of Prior Period Financial Data

[0001262039-21-000008:mdna:36]
As discussed further in Note 2 of the notes to consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an understatement of revenue during the years ended 2019 and 2018, respectively.

[0001262039-21-000008:mdna:37]
The correction of this error resulted in increases to service revenue, gross profit and operating income of $6.8 million and $3.4 million for the year ended 2019 and 2018, respectively. Net income increased by $5.2 million and $2.7 million for the year ended 2019 and 2018, respectively. This resulted in an increase to diluted net income per share of $0.03 and $0.01 for the year ended 2019 and 2018, respectively.

[0001262039-21-000008:mdna:38]
We evaluated the effect of this correction on the previous results of operations and determined that it did not materially impact any trends previously disclosed. This correction did not impact net cash provided by operating activities, billings or free cash flows.

[0001262039-21-000008:mdna:39]
Financial Highlights

[0001262039-21-000008:mdna:40]
•Total revenue was $2.59 billion in 2020, an increase of 20% compared to $2.16 billion in 2019. Product revenue was $916.4 million in 2020, an increase of 16% compared to $788.5 million in 2019. Service revenue was $1.68 billion in 2020, an increase of 22% compared to $1.37 billion in 2019.

[0001262039-21-000008:mdna:41]
•Total gross profit was $2.02 billion in 2020, an increase of 22% compared to $1.66 billion in 2019.

[0001262039-21-000008:mdna:42]
•We generated operating income of $531.8 million in 2020, an increase of 52% compared to $351.0 million in 2019. Operating income for 2020 included gains on an IP matter of $40.2 million.

[0001262039-21-000008:mdna:43]
•Cash, cash equivalents and investments were $1.96 billion as of December 31, 2020, a decrease of $254.3 million, or 12%, from December 31, 2019.

[0001262039-21-000008:mdna:44]
•In 2020, we repurchased 11.7 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.08 billion. In 2019, we repurchased 1.9 million shares of common stock for a total purchase price of $140.9 million.

[0001262039-21-000008:mdna:45]
•Deferred revenue was $2.61 billion as of December 31, 2020, an increase of $496.2 million, or 24%, from December 31, 2019. Short-term deferred revenue was $1.39 billion as of December 31, 2020, an increase of $237.0 million, or 21%, from December 31, 2019.

[0001262039-21-000008:mdna:46]
•We generated cash flows from operating activities of $1.08 billion in 2020, an increase of $275.7 million, or 34%, compared to 2019.

[0001262039-21-000008:mdna:47]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. In 2020, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 42%, 38% and 20% of our total revenue, respectively, and increased by 17%, 21% and 23% compared to 2019, respectively.

[0001262039-21-000008:mdna:48]
Product revenue grew 16% in 2020. We experienced revenue growth across several of our hardware and software products, including SD-WAN and teleworker and remote security solutions. Service revenue growth of 22% in 2020 was driven by the strength of our FortiGuard and other security subscription revenue and FortiGate technical support and other service revenue, which both grew 22% in 2020.

[0001262039-21-000008:mdna:49]
Our billings were diversified on a geographic basis. In 2020, approximately 50% of our billings in the aggregate were from over 80 countries that individually contributed less than 3% of our billings.

[0001262039-21-000008:mdna:50]
During the fourth quarter of 2020, we acquired Panopta Holdings LLC (“ Panopta”) to provide a platform for monitoring the health and performance of network and IT infrastructure. During the third quarter of 2020, we acquired OPAQ Networks, Inc. (“OPAQ”) to further enhance the Fortinet Security Fabric platform by providing enterprises with the zero trust network access SASE cloud solution. The impact of these acquisitions were not material to our consolidated financial statements.

[0001262039-21-000008:mdna:51]
In 2020, we recognized gains of $40.2 million on an IP matter in connection with a mutual covenant-no-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter, operating expenses as a percentage of revenue decreased by 1.3 percentage points compared to 2019. Headcount increased by 16% to 8,238 employees and contractors as of December 31, 2020, up from 7,082 as of December 31, 2019.

[0001262039-21-000008:mdna:52]
COVID-19 Update

[0001262039-21-000008:mdna:53]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic. In response to the pandemic, we have taken a number of actions to protect our employees, including restricting travel and directing most of our employees to work from home. Where onsite work is permitted, we have implemented measures such as staggered work shifts, social distancing, the use of face coverings, health safety awareness training and frequent disinfection of shared spaces. We have implemented our readiness plans, which include steps to maintain critical internet infrastructure with many employees working remotely.

[0001262039-21-000008:mdna:54]
We are also providing free online information technology security training for the public, aimed at helping high school and college students and professionals augment their security skill sets to open career opportunities and to help narrow the security skills gap. As of December 31, 2020, there have been over 800,000 registrations for our free online trainings since we launched the program. We will continue to provide free online trainings in 2021.

[0001262039-21-000008:mdna:55]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance remain uncertain, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the year ended December 31, 2020. Conversely, some aspects of our business do not appear to have been significantly affected. During the year ended December 31, 2020, we have observed the following:

[0001262039-21-000008:mdna:56]
•In most countries, our employees ability to travel was reduced. In-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. As a result, expenses related to travel and marketing events decreased significantly. To the extent that it becomes safe for our employees to travel and for us to hold or attend marketing events, these expenses may increase in the future, although we cannot predict if or when such expenses will increase or return to pre-pandemic levels.

[0001262039-21-000008:mdna:57]
•After performing additional credit review of our existing customers, including obtained credit reports and reviewing their latest available statements of financial position, we increased the allowance of credit losses for certain accounts receivable. The allowance for credit losses was $2.5 million as of December 31, 2020. Provisions, write-offs and recoveries were not material during the year ended December 31, 2020.

[0001262039-21-000008:mdna:58]
•We have offered payment terms in excess of our contractual agreements to certain distributor customers, which has resulted in an increase to the average collection period of our trade receivables. As of December 31, 2020, 97% of our outstanding trade accounts receivable was due to be collected during the first quarter of 2021.

[0001262039-21-000008:mdna:59]
•The countries and geographic regions in which we experienced the fastest billings growth in the fourth quarter of 2020, as compared to the fourth quarter of 2019, were countries and geographic regions in which the COVID-19 pandemic is generally considered to have had a comparatively shorter or less severe impact on the local population and economy during the quarter.

[0001262039-21-000008:mdna:60]
•We have noted that, for some of our customers, sales cycles appear to have lengthened, though it is unclear whether this trend will persist.

[0001262039-21-000008:mdna:61]
•Our average service contract duration increased by approximately two months in the fourth quarter of 2020 as compared to the fourth quarter of 2019.

[0001262039-21-000008:mdna:62]
•In order to mitigate supply chain risk and in anticipation of fourth-quarter demand, we have increased our on-hand stock of certain products.

[0001262039-21-000008:mdna:63]
•The yield on investment-grade debt has decreased, and while the risk of credit losses on our investments and cash equivalents has not changed significantly, as the debt securities in our portfolio have matured, they have been replaced by securities with lower effective interest rates. This has contributed to a decrease in our interest income during the year ended December 31, 2020, compared to the same periods last year.

[0001262039-21-000008:mdna:64]
•In accordance with the CARES Act, we have deferred the deposit and payment of our employer’s share of Social Security taxes. This did not materially affect net cash provided by operating activities during the period.

[0001262039-21-000008:mdna:65]
Through the filing of this Annual Report on Form 10-K, there have been no material changes to the trends described above. Going forward, however, the situation is uncertain, rapidly changing and hard to predict, and the COVID-19 pandemic may have a material negative impact on our future periods. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The duration and severity of the economic downturn from the pandemic may negatively impact our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources in a material way. As a result, the effects of the pandemic may not be fully reflected in our results of operations until future periods. For further discussion, see Part I, Item 1A of this Annual Report on Form 10-K.

[0001262039-21-000008:mdna:66]
Business Model

[0001262039-21-000008:mdna:67]
We typically sell our security solutions to distributors that sell to networking security focused resellers and to service providers and managed security service providers (“MSSPs”), who, in turn, sell to end-customers. At times, we also sell directly to large service providers and major systems integrators who may sell to our end-customers or use our products and services to provided hosted solutions to other enterprises. Our end-customers are located in over 80 countries and include small, medium and large enterprises and government organizations across a wide range of industries, including telecommunications, government, financial services, retail, technology, education, manufacturing and healthcare. An end-customer deployment may involve as few as one or as many as thousands of appliances and other Fortinet Security Fabric platform products, depending on the end-customer’s size and security requirements.

[0001262039-21-000008:mdna:68]
We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, Alibaba Cloud and IBM Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in third-party clouds or in their private cloud.

[0001262039-21-000008:mdna:69]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though, as noted in the COVID-19 Update above, we have recently offered extended payment terms to certain distributor customers.

[0001262039-21-000008:mdna:70]
Key Metrics

[0001262039-21-000008:mdna:71]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-21-000008:mdna:72]
|  | Year Ended or As of December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (in millions) |
| Revenue | $ | 2,594.4 |  |  | $ | 2,163.0 |  |  | $ | 1,804.6 |  |
| Deferred revenue | $ | 2,605.3 |  |  | $ | 2,109.1 |  |  | $ | 1,666.8 |  |
| Billings (non-GAAP) | $ | 3,090.0 |  |  | $ | 2,602.9 |  |  | $ | 2,153.3 |  |
| Net cash provided by operating activities | $ | 1,083.7 |  |  | $ | 808.0 |  |  | $ | 638.9 |  |
| Free cash flow (non-GAAP) | $ | 907.8 |  |  | $ | 715.8 |  |  | $ | 585.9 |  |

[0001262039-21-000008:mdna:73]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.61 billion as of December 31, 2020, an increase of $496.2 million, or 24%, from December 31, 2019.

[0001262039-21-000008:mdna:74]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of Financial Accounting Standards Board (“FASB”) Topic 606, Revenue from Contracts with Customers (“Topic 606”), less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $3.09 billion for 2020, an increase of 19% compared to $2.60 billion in 2019.

[0001262039-21-000008:mdna:75]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-21-000008:mdna:76]
|  | Year Ended December 31, |
| 2020 |  | 2019 |  | 2018 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 2,594.4 |  |  | $ | 2,163.0 |  |  | $ | 1,804.6 |  |
| Add: Change in deferred revenue | 496.2 |  |  | 442.3 |  |  | 347.1 |  |
| Add: Deferred revenue adjustment due to adoption of Topic 606 | — |  |  | — |  |  | 4.1 |  |
| Less: Deferred revenue balance acquired in business combinations | (0.6) |  |  | (2.4) |  |  | (2.5) |  |
| Total billings (non-GAAP) | $ | 3,090.0 |  |  | $ | 2,602.9 |  |  | $ | 2,153.3 |  |

[0001262039-21-000008:mdna:77]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant nonrecurring items. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-21-000008:mdna:78]
|  | Year Ended December 31, |
| 2020 |  | 2019 |  | 2018 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 1,083.7 |  |  | $ | 808.0 |  |  | $ | 638.9 |  |
| Less: Purchases of property and equipment | (125.9) |  |  | (92.2) |  |  | (53.0) |  |
| Less: Proceeds from intellectual property matter | (50.0) |  |  | — |  |  | — |  |
| Free cash flow (non-GAAP) | $ | 907.8 |  |  | $ | 715.8 |  |  | $ | 585.9 |  |
| Net cash used in investing activities | $ | (72.8) |  |  | $ | (502.3) |  |  | $ | (134.9) |  |
| Net cash used in financing activities | $ | (1,171.6) |  |  | $ | (195.6) |  |  | $ | (202.6) |  |

[0001262039-21-000008:mdna:79]
Components of Operating Results

[0001262039-21-000008:mdna:80]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud security solutions, professional services and training.

[0001262039-21-000008:mdna:81]
Our total revenue is comprised of the following:

[0001262039-21-000008:mdna:82]
•Product revenue. Product revenue is primarily generated from sales of our physical and virtual machine appliances. While the majority of our product revenue continues to be generated by our FortiGate product line, our Fabric appliance and software products are growing faster. As a percentage of total revenue, our product revenue has varied from quarter-to-quarter.

[0001262039-21-000008:mdna:83]
•Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and FortiCare technical support services. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years and, to a lesser extent, five years. We also generate a small portion of our revenue from professional services and training services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings, the attach rate of service contracts to new product sales, and the renewal of service contracts by our existing customers.

[0001262039-21-000008:mdna:84]
Our total cost of revenue is comprised of the following:

[0001262039-21-000008:mdna:85]
•Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers’ costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs and amortization of intangible assets. Personnel costs include direct compensation and benefits.

[0001262039-21-000008:mdna:86]
•Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes third-party repair and contract fulfillment, data center and cloud hosting, supplies and facility-related costs.

[0001262039-21-000008:mdna:87]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between hardware products, software licenses and services and any excess inventory write-offs. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to hardware product gross margins. During 2020, product gross margin benefited from gains in average selling price, as well as lower direct and indirect product costs as a percentage of product revenue. It also benefited from product mix, software revenue growth and a stable product transition environment. Service gross margin benefited from renewals and continued sales of services and subscriptions, growing faster than related expenses. Overall gross margin in 2021 will be impacted by service and product revenue mix.

[0001262039-21-000008:mdna:88]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, sales commission and stock-based compensation. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-21-000008:mdna:89]
•Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. As of December 31, 2020, approximately 90% of our research and development teams were located in Canada, the United States and India.

[0001262039-21-000008:mdna:90]
•Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include product marketing, public relations, field marketing and channel marketing programs (e.g. partner cooperative marketing arrangements), as well as travel, depreciation of property and equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share.

[0001262039-21-000008:mdna:91]
•General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, tax, information technology and other consulting costs.

[0001262039-21-000008:mdna:92]
•Gain on intellectual property matter. Gain on intellectual property matter consists of the amortization of the deferred component of an agreement with a competitor in the network security industry, whereby, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims.

[0001262039-21-000008:mdna:93]
Interest income—net. Interest income—net consists primarily of interest earned on our cash equivalents and investments. We have historically invested our cash in corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, and U.S. government and agency securities.

[0001262039-21-000008:mdna:94]
Other expense—net. Other expense—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, as well as the gain on the sale or the impairment charges of our investments in privately held companies.

[0001262039-21-000008:mdna:95]
Provision for (benefit from) income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in local countries and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., nondeductible stock-based compensation expense, federal research and development tax credit, state taxes, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the 2017 Tax Act, including the foreign-derived intangible income (“FDII”) deduction.

[0001262039-21-000008:mdna:96]
Critical Accounting Policies and Estimates

[0001262039-21-000008:mdna:97]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-21-000008:mdna:98]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-21-000008:mdna:99]
Revenue Recognition

[0001262039-21-000008:mdna:100]
Revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

[0001262039-21-000008:mdna:101]
We determine revenue recognition through the following steps:

[0001262039-21-000008:mdna:102]
•identification of a contract or contracts with a customer;

[0001262039-21-000008:mdna:103]
•identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract;

[0001262039-21-000008:mdna:104]
•determination of a transaction price;

[0001262039-21-000008:mdna:105]
•allocation of a transaction price to the performance obligations in a contract; and

[0001262039-21-000008:mdna:106]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-21-000008:mdna:107]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. Our hardware and software licenses have significant standalone functionalities and capabilities. Accordingly, the hardware and software licenses are distinct from the security subscription and technical support services, as a customer can benefit from the product without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We establish standalone selling price using the prices charged for a deliverable when sold separately. If not observable through past transactions, we determine standalone selling price by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract.

[0001262039-21-000008:mdna:108]
Deferred Contract Costs and Commission Expense

[0001262039-21-000008:mdna:109]
We defer contract costs that are recoverable and incremental to obtaining customer sales contracts. Contract costs, which primarily consist of sales commissions, are amortized on a systematic basis that is consistent with the transfer to the customer of the goods or services to which the asset relates. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit of five years. Significant estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-21-000008:mdna:110]
57

[0001262039-21-000008:mdna:111]
Valuation of Inventory

[0001262039-21-000008:mdna:112]
Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-21-000008:mdna:113]
Business Combinations

[0001262039-21-000008:mdna:114]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-21-000008:mdna:115]
Contingent Liabilities

[0001262039-21-000008:mdna:116]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-21-000008:mdna:117]
Accounting for Income Taxes

[0001262039-21-000008:mdna:118]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-21-000008:mdna:119]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-21-000008:mdna:120]
Effective January 1, 2018, the 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time transition tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Our selection of an accounting policy for 2018 with respect to the Global Intangible Low-Taxed Income (“GILTI”) tax rules was to treat GILTI tax as a current period expense under the period cost method. For 2019 and 2020, we were not subject to GILTI. We will continue to monitor and assess the impact of the 2017 Tax Act and ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act.

[0001262039-21-000008:mdna:121]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-21-000008:mdna:122]
58

[0001262039-21-000008:mdna:123]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-21-000008:mdna:124]
Results of Operations

[0001262039-21-000008:mdna:125]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-21-000008:mdna:126]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 916.4 |  |  | $ | 788.5 |  |  | $ | 674.4 |  |
| Service | 1,678.0 |  |  | 1,374.5 |  |  | 1,130.2 |  |
| Total revenue | 2,594.4 |  |  | 2,163.0 |  |  | 1,804.6 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 352.4 |  |  | 324.6 |  |  | 291.0 |  |
| Service | 217.6 |  |  | 181.3 |  |  | 159.4 |  |
| Total cost of revenue | 570.0 |  |  | 505.9 |  |  | 450.4 |  |
| Gross profit: |  |  |  |  |  |
| Product | 564.0 |  |  | 463.9 |  |  | 383.4 |  |
| Service | 1,460.4 |  |  | 1,193.2 |  |  | 970.8 |  |
| Total gross profit | 2,024.4 |  |  | 1,657.1 |  |  | 1,354.2 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 341.4 |  |  | 277.1 |  |  | 244.5 |  |
| Sales and marketing | 1,071.9 |  |  | 926.9 |  |  | 782.3 |  |
| General and administrative | 119.5 |  |  | 102.1 |  |  | 93.0 |  |
| Gain on intellectual property matter | (40.2) |  |  | — |  |  | — |  |
| Total operating expenses | 1,492.6 |  |  | 1,306.1 |  |  | 1,119.8 |  |
| Operating income | 531.8 |  |  | 351.0 |  |  | 234.4 |  |
| Interest income—net | 17.7 |  |  | 42.5 |  |  | 26.5 |  |
| Other expense—net | (7.8) |  |  | (7.5) |  |  | (6.6) |  |
| Income before income taxes | 541.7 |  |  | 386.0 |  |  | 254.3 |  |
| Provision for (benefit from) income taxes | 53.2 |  |  | 54.3 |  |  | (80.6) |  |
| Net income | $ | 488.5 |  |  | $ | 331.7 |  |  | $ | 334.9 |  |

[0001262039-21-000008:mdna:127]
59

[0001262039-21-000008:mdna:128]
|  | Year Ended December 31, |
| 2020 |  | 2019 |  | 2018 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 35 | % |  | 36 | % |  | 37 | % |
| Service | 65 |  |  | 64 |  |  | 63 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 14 |  |  | 15 |  |  | 16 |  |
| Service | 8 |  |  | 8 |  |  | 9 |  |
| Total cost of revenue | 22 |  |  | 23 |  |  | 25 |  |
| Gross margin: |  |  |  |  |  |
| Product | 62 |  |  | 59 |  |  | 57 |  |
| Service | 87 |  |  | 87 |  |  | 86 |  |
| Total gross margin | 78 |  |  | 77 |  |  | 75 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 13 |  |  | 13 |  |  | 14 |  |
| Sales and marketing | 41 |  |  | 43 |  |  | 43 |  |
| General and administrative | 5 |  |  | 5 |  |  | 5 |  |
| Gain on intellectual property matter | (2) |  |  | — |  |  | — |  |
| Total operating expenses | 58 |  |  | 60 |  |  | 62 |  |
| Operating margin | 20 |  |  | 16 |  |  | 13 |  |
| Interest income—net | 1 |  |  | 2 |  |  | 1 |  |
| Other expense—net | — |  |  | — |  |  | — |  |
| Income before income taxes | 21 |  |  | 18 |  |  | 14 |  |
| Provision for (benefit from) income taxes | 2 |  |  | 3 |  |  | (4) |  |
| Net income | 19 | % |  | 15 | % |  | 19 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-21-000008:mdna:129]
Discussion regarding our financial condition and results of operations for 2019 as compared to 2018 can be found in Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2019, filed with the SEC on February 26, 2020.

[0001262039-21-000008:mdna:130]
2020 and 2019

[0001262039-21-000008:mdna:131]
Revenue

[0001262039-21-000008:mdna:132]
|  | Year Ended December 31, |  |  |  |  |
| 2020 |  | 2019 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 916.4 |  |  | 35 | % |  | $ | 788.5 |  |  | 36 | % |  | $ | 127.9 |  |  | 16 | % |
| Service | 1,678.0 |  |  | 65 |  |  | 1,374.5 |  |  | 64 |  |  | 303.5 |  |  | 22 |  |
| Total revenue | $ | 2,594.4 |  |  | 100 | % |  | $ | 2,163.0 |  |  | 100 | % |  | $ | 431.4 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,077.2 |  |  | 42 | % |  | $ | 920.2 |  |  | 42 | % |  | $ | 157.0 |  |  | 17 | % |
| EMEA | 991.9 |  |  | 38 |  |  | 816.5 |  |  | 38 |  |  | 175.4 |  |  | 21 |  |
| APAC | 525.3 |  |  | 20 |  |  | 426.3 |  |  | 20 |  |  | 99.0 |  |  | 23 |  |
| Total revenue | $ | 2,594.4 |  |  | 100 | % |  | $ | 2,163.0 |  |  | 100 | % |  | $ | 431.4 |  |  | 20 | % |

[0001262039-21-000008:mdna:133]
60

[0001262039-21-000008:mdna:134]
Total revenue increased by $431.4 million, or 20%, in 2020 compared to 2019. We continued to experience diversification of revenue globally, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and APAC contributing the fastest growth on a percentage basis.

[0001262039-21-000008:mdna:135]
Product revenue increased by $127.9 million, or 16%, in 2020 compared to 2019. We experienced revenue growth across many of our products due to an increase in product revenue from our FortiGate SD-WAN solutions, software licenses and our security fabric platform products.

[0001262039-21-000008:mdna:136]
Service revenue increased by $303.5 million, or 22%, in 2020 compared to 2019. FortiGuard security subscription, FortiCare technical support and other revenues increased by $167.9 million and $135.6 million, respectively, or 22% in 2020 compared to 2019. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000008:mdna:137]
Of the service revenue recognized in 2020, 68% was included in the deferred revenue balance as of December 31, 2019. Of the service revenue recognized in 2019, 68% was included in the deferred revenue balance as of December 31, 2018.

[0001262039-21-000008:mdna:138]
Cost of revenue and gross margin

[0001262039-21-000008:mdna:139]
|  | Year Ended December 31, |  |  |  |  |
| 2020 |  | 2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 352.4 |  |  | $ | 324.6 |  |  | $ | 27.8 |  |  | 9 | % |
| Service | 217.6 |  |  | 181.3 |  |  | 36.3 |  |  | 20 |  |
| Total cost of revenue | $ | 570.0 |  |  | $ | 505.9 |  |  | $ | 64.1 |  |  | 13 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.5 | % |  | 58.8 | % |  |  |  |  |
| Service | 87.0 | % |  | 86.8 | % |  |  |  |  |
| Total gross margin | 78.0 | % |  | 76.6 | % |  |  |  |  |

[0001262039-21-000008:mdna:140]
Total gross margin increased by 1.4 percentage points in 2020 compared to 2019, driven primarily by improvements to product gross margins.

[0001262039-21-000008:mdna:141]
Product gross margin increased by 2.7 percentage points in 2020 compared to 2019. Product gross margin benefited from lower direct costs of hardware as a percentage of product revenue and increased software sales. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000008:mdna:142]
Service gross margin increased by 0.2 percentage points in 2020 compared to 2019, as our personnel costs grew slower than our service revenue and we experienced lower costs to replace and repair our products. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-21-000008:mdna:143]
Operating expenses

[0001262039-21-000008:mdna:144]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2020 |  | 2019 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 341.4 |  |  | 13 | % |  | $ | 277.1 |  |  | 13 | % |  | $ | 64.3 |  |  | 23 | % |
| Sales and marketing | 1,071.9 |  |  | 41 |  |  | 926.9 |  |  | 43 |  |  | 145.0 |  |  | 16 |  |
| General and administrative | 119.5 |  |  | 5 |  |  | 102.1 |  |  | 5 |  |  | 17.4 |  |  | 17 |  |
| Gain on intellectual property matter | (40.2) |  |  | (2) |  |  | — |  |  | — |  |  | (40.2) |  |  | * |
| Total operating expenses | $ | 1,492.6 |  |  | 58 | % |  | $ | 1,306.1 |  |  | 60 | % |  | $ | 186.5 |  |  | 14 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |
| * Not meaningful |  |  |  |  |  |  |  |  |  |  |  |

[0001262039-21-000008:mdna:145]
Research and development

[0001262039-21-000008:mdna:146]
Research and development expense increased by $64.3 million, or 23%, in 2020 compared to 2019, primarily due to an increase in personnel-related costs of $49.0 million as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development costs, such as third-party testing and prototypes, increased $12.3 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2021.

[0001262039-21-000008:mdna:147]
Sales and marketing

[0001262039-21-000008:mdna:148]
Sales and marketing expense increased by $145.0 million, or 16%, in 2020 compared to 2019, primarily due to an increase in personnel-related costs of $173.4 million as a result of increases to sales and marketing headcount in order to drive global market revenue increases. This increase was offset by savings related to decreased travel and fewer in-person marketing events as a result of the COVID-19 pandemic. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars in 2021.

[0001262039-21-000008:mdna:149]
General and administrative

[0001262039-21-000008:mdna:150]
General and administrative expense increased by $17.4 million, or 17%, in 2020 compared to 2019, primarily due to an increase in personnel-related costs of $9.3 million, an increase in legal-related costs of $2.5 million, an increase in professional services fee of $2.2 million and an increase in the provision for expected credit losses of $2.0 million. We currently expect general and administrative expense to increase in absolute dollars in 2021.

[0001262039-21-000008:mdna:151]
Gain on IP matter

[0001262039-21-000008:mdna:152]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. In 2020 we recorded a $40.2 million gain on intellectual property matter in our consolidated statements of income. See Note 12 of the notes to consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K for additional information regarding the gain on IP matter.

[0001262039-21-000008:mdna:153]
Operating income and margin

[0001262039-21-000008:mdna:154]
We generated operating income of $531.8 million in 2020, an increase of $180.8 million, or 52%, compared to $351.0 million in 2019. Operating income as a percentage of revenue increased to 20% in 2020 compared to 16% in 2019. The increase in operating margin is primarily due to the $40.2 million gain on IP matter, the 1.4 percentage point improvement in gross margin and the 1.6 percentage point decrease in sales and marketing expense as a percentage of revenue.

[0001262039-21-000008:mdna:155]
62

[0001262039-21-000008:mdna:156]
Interest income—net and other expense—net

[0001262039-21-000008:mdna:157]
|  | Year Ended December 31, |  |  |  |  |
| 2020 |  | 2019 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income—net | $ | 17.7 |  |  | $ | 42.5 |  |  | $ | (24.8) |  |  | (58) | % |
| Other expense—net | $ | (7.8) |  |  | $ | (7.5) |  |  | $ | (0.3) |  |  | 4 | % |

[0001262039-21-000008:mdna:158]
Interest income—net decreased in 2020 as compared to 2019, primarily due to lower interest rates and, to a lesser extent, lower invested balances of cash, cash equivalents and investments. Interest income—net varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net in 2020 as compared to 2019 was the result of a $4.3 million impairment charge on an investment in a privately held company during 2020 compared to a $3.8 million impairment charge on an investment in a privately held company in the same period last year.

[0001262039-21-000008:mdna:159]
Provision for (benefit from) income taxes

[0001262039-21-000008:mdna:160]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2020 |  | 2019 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 53.2 |  |  | $ | 54.3 |  |  | $ | (1.1) |  |  | (2) | % |
| Effective tax rate | 10 | % |  | 14 | % |  |  |  |  |

[0001262039-21-000008:mdna:161]
Our provision for income taxes for 2020 reflects an effective tax rate of 10%, compared to an effective tax rate of 14% for 2019. The provision for income taxes for 2020 was comprised primarily of a $146.8 million tax expense related to U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and unrecognized tax benefits. The provision was partially offset by a tax benefit of $44.3 million from the FDII deduction, excess tax benefits of $42.0 million from stock-based compensation expense and tax benefits of $7.5 million from federal research and development tax credits.

[0001262039-21-000008:mdna:162]
Our provision for income taxes for 2019 reflects an effective tax rate of 14%, compared to an effective tax rate benefit of 32% for 2018. The provision for income taxes for 2019 was comprised primarily of a $90.3 million tax expense related to U.S. federal and state taxes, other foreign income taxes and foreign withholding taxes and a $10.1 million tax expense for an unrecognized tax benefit related to the Ninth Circuit’s opinion in Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”). The provision was partially offset by excess tax benefits of $39.3 million from stock-based compensation expense and tax benefits of $6.8 million from federal research and development tax credits.

[0001262039-21-000008:mdna:163]
Unaudited Quarterly Results of Operations

[0001262039-21-000008:mdna:164]
The following table sets forth our unaudited quarterly statements of income for the last eight quarters. The quarterly results of operations for the four quarters of 2019 were adjusted for an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an understatement of revenue. See Note 2 of the notes to consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K for further detail. Additionally, the quarterly results of operations for the first two quarters of 2020 were also adjusted to reflect the correction of the immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an understatement of revenue.

[0001262039-21-000008:mdna:165]
The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-21-000008:mdna:166]
63

[0001262039-21-000008:mdna:167]
|  | Three Months Ended |
|  | Dec 31, 2020 |  | Sep 30, 2020 |  | Jun 30, 2020 |  | Mar 31, 2020 |
|  | As Reported |  | As Reported |  | As Previously Reported |  | As Corrected |  | As Previously Reported |  | As Corrected |
|  | (in millions, except per share amounts) |
| Consolidated Statements of Income Data: |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 288.4 |  |  | $ | 223.8 |  |  | $ | 211.9 |  |  | $ | 211.9 |  |  | $ | 192.3 |  |  | $ | 192.3 |  |
| Service | 459.6 |  |  | 427.3 |  |  | 403.6 |  | 405.7 |  |  | 384.6 |  | 385.4 |  |
| Total revenue | 748.0 |  |  | 651.1 |  |  | 615.5 |  |  | 617.6 |  |  | 576.9 |  |  | 577.7 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 107.4 |  |  | 84.3 |  |  | 84.4 |  | 84.4 |  |  | 76.3 |  | 76.3 |  |
| Service (1)(2) | 59.6 |  |  | 54.9 |  |  | 50.7 |  | 50.7 |  |  | 52.4 |  | 52.4 |  |
| Total cost of revenue | 167.0 |  |  | 139.2 |  |  | 135.1 |  |  | 135.1 |  |  | 128.7 |  |  | 128.7 |  |
| Total gross profit | 581.0 |  |  | 511.9 |  |  | 480.4 |  |  | 482.5 |  |  | 448.2 |  |  | 449.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 89.0 |  |  | 90.0 |  |  | 82.1 |  | 82.1 |  |  | 80.3 |  | 80.3 |  |
| Sales and marketing (1)(2) | 291.4 |  |  | 266.7 |  |  | 253.8 |  | 253.8 |  |  | 260.0 |  | 260.0 |  |
| General and administrative (1) | 32.4 |  |  | 29.4 |  |  | 28.9 |  | 28.9 |  |  | 28.8 |  | 28.8 |  |
| Gain on intellectual property matter | (1.2) |  |  | (1.1) |  |  | (1.1) |  |  | (1.1) |  |  | (36.8) |  |  | (36.8) |  |
| Total operating expenses | 411.6 |  |  | 385.0 |  |  | 363.7 |  |  | 363.7 |  |  | 332.3 |  |  | 332.3 |  |
| Operating income | 169.4 |  |  | 126.9 |  |  | 116.7 |  |  | 118.8 |  |  | 115.9 |  |  | 116.7 |  |
| Interest income—net | 2.0 |  |  | 2.5 |  |  | 4.0 |  | 4.0 |  |  | 9.2 |  | 9.2 |  |
| Other income (expense)—net | 0.3 |  |  | (1.0) |  |  | 0.9 |  | 0.9 |  |  | (8.0) |  |  | (8.0) |  |
| Income before income taxes | 171.7 |  |  | 128.4 |  |  | 121.6 |  |  | 123.7 |  |  | 117.1 |  |  | 117.9 |  |
| Provision for income taxes | 25.0 |  |  | 5.0 |  |  | 9.5 |  | 9.9 |  |  | 13.1 |  | 13.3 |  |
| Net income | $ | 146.7 |  |  | $ | 123.4 |  |  | $ | 112.1 |  |  | $ | 113.8 |  |  | $ | 104.0 |  |  | $ | 104.6 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.90 |  |  | $ | 0.76 |  |  | $ | 0.69 |  |  | $ | 0.70 |  |  | $ | 0.61 |  |  | $ | 0.61 |  |
| Diluted | $ | 0.89 |  |  | $ | 0.75 |  |  | $ | 0.68 |  |  | $ | 0.69 |  |  | $ | 0.60 |  |  | $ | 0.60 |  |

[0001262039-21-000008:mdna:168]
64

[0001262039-21-000008:mdna:169]
|  | Three Months Ended |
|  | Dec 31, 2019 |  | Sept 30, 2019 |  | Jun 30, 2019 |  | Mar 31, 2019 |
|  | As Previously Reported |  | As Corrected |  | As Previously Reported |  | As Corrected |  | As Previously Reported |  | As Corrected |  | As Previously Reported |  | As Corrected |
|  | (in millions, except per share amounts) |
| Consolidated Statements of Income Data: |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 238.8 |  |  | $ | 238.8 |  |  | $ | 197.1 |  |  | $ | 197.1 |  |  | $ | 189.9 |  |  | $ | 189.9 |  |  | $ | 162.7 |  |  | $ | 162.7 |  |
| Service | 375.6 |  |  | 379.3 |  |  | 350.4 |  |  | 351.0 |  |  | 331.8 |  | 333.9 |  |  | 309.9 |  |  | 310.3 |  |
| Total revenue | 614.4 |  |  | 618.1 |  |  | 547.5 |  |  | 548.1 |  |  | 521.7 |  |  | 523.8 |  |  | 472.6 |  |  | 473.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 92.7 |  |  | 92.7 |  |  | 79.0 |  |  | 79.0 |  |  | 82.7 |  | 82.7 |  |  | 70.2 |  |  | 70.2 |  |
| Service (1)(2) | 47.8 |  |  | 47.8 |  |  | 45.1 |  |  | 45.1 |  |  | 45.6 |  | 45.6 |  |  | 42.8 |  |  | 42.8 |  |
| Total cost of revenue | 140.5 |  |  | 140.5 |  |  | 124.1 |  |  | 124.1 |  |  | 128.3 |  |  | 128.3 |  |  | 113.0 |  |  | 113.0 |  |
| Total gross profit | 473.9 |  |  | 477.6 |  |  | 423.4 |  |  | 424.0 |  |  | 393.4 |  |  | 395.5 |  |  | 359.6 |  |  | 360.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 71.2 |  |  | 71.2 |  |  | 69.9 |  |  | 69.9 |  |  | 67.4 |  | 67.4 |  |  | 68.6 |  |  | 68.6 |  |
| Sales and marketing (1)(2) | 257.1 |  |  | 257.1 |  |  | 227.4 |  |  | 227.4 |  |  | 226.5 |  | 226.5 |  |  | 215.9 |  |  | 215.9 |  |
| General and administrative (1) | 27.2 |  |  | 27.2 |  |  | 26.1 |  |  | 26.1 |  |  | 24.3 |  | 24.3 |  |  | 24.5 |  |  | 24.5 |  |
| Total operating expenses | 355.5 |  |  | 355.5 |  |  | 323.4 |  |  | 323.4 |  |  | 318.2 |  |  | 318.2 |  |  | 309.0 |  |  | 309.0 |  |
| Operating income | 118.4 |  |  | 122.1 |  |  | 100.0 |  |  | 100.6 |  |  | 75.2 |  |  | 77.3 |  |  | 50.6 |  |  | 51.0 |  |
| Interest income—net | 9.9 |  |  | 9.9 |  |  | 11.4 |  |  | 11.4 |  |  | 11.0 |  | 11.0 |  |  | 10.2 |  |  | 10.2 |  |
| Other expense—net | (0.6) |  |  | (0.6) |  |  | (6.0) |  |  | (6.0) |  |  | (0.4) |  |  | (0.4) |  |  | (0.5) |  |  | (0.5) |  |
| Income before income taxes | 127.7 |  |  | 131.4 |  |  | 105.4 |  |  | 106.0 |  |  | 85.8 |  |  | 87.9 |  |  | 60.3 |  |  | 60.7 |  |
| Provision for income taxes | 12.5 |  |  | 13.2 |  |  | 25.6 |  |  | 25.8 |  |  | 13.1 |  | 13.7 |  |  | 1.5 |  |  | 1.6 |  |
| Net income | $ | 115.2 |  |  | $ | 118.2 |  |  | $ | 79.8 |  |  | $ | 80.2 |  |  | $ | 72.7 |  |  | $ | 74.2 |  |  | $ | 58.8 |  |  | $ | 59.1 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.67 |  |  | $ | 0.69 |  |  | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 0.43 |  |  | $ | 0.35 |  |  | $ | 0.35 |  |
| Diluted | $ | 0.66 |  |  | $ | 0.67 |  |  | $ | 0.46 |  |  | $ | 0.46 |  |  | $ | 0.42 |  |  | $ | 0.42 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |
| (1) Includes stock-based compensation as follows: |

[0001262039-21-000008:mdna:170]
|  | Three Months Ended |
|  | Dec 31,2020 |  | Sept 30,2020 |  | Jun 30,2020 |  | Mar 31,2020 |  | Dec 31,2019 |  | Sept 30,2019 |  | Jun 30,2019 |  | Mar 31,2019 |
|  | (in millions) |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| Cost of service revenue | 3.4 |  |  | 3.3 |  |  | 3.2 |  |  | 3.0 |  |  | 2.9 |  |  | 2.7 |  |  | 2.9 |  |  | 2.8 |  |
| Research and development | 12.0 |  |  | 12.7 |  |  | 12.0 |  |  | 10.9 |  |  | 10.0 |  |  | 9.3 |  |  | 10.0 |  |  | 9.4 |  |
| Sales and marketing | 27.1 |  |  | 27.7 |  |  | 27.9 |  |  | 25.7 |  |  | 25.1 |  |  | 24.9 |  |  | 26.3 |  |  | 25.4 |  |
| General and administrative | 6.0 |  |  | 5.9 |  |  | 6.1 |  |  | 5.3 |  |  | 5.4 |  |  | 5.1 |  |  | 5.4 |  |  | 5.0 |  |
| Total stock-based compensation expense | $ | 48.9 |  |  | $ | 50.0 |  |  | $ | 49.6 |  |  | $ | 45.3 |  |  | $ | 43.7 |  |  | $ | 42.4 |  |  | $ | 45.0 |  |  | $ | 43.0 |  |

[0001262039-21-000008:mdna:171]
65

[0001262039-21-000008:mdna:172]
(2) Total amortization included in product costs, service costs, and sales and marketing expense are as follows:

[0001262039-21-000008:mdna:173]
|  | Three Months Ended |
|  | Dec 31,2020 |  | Sept 30,2020 |  | Jun 30,2020 |  | Mar 31,2020 |  | Dec 31,2019 |  | Sept 30,2019 |  | Jun 30,2019 |  | Mar 31,2019 |
|  | (in millions) |
| Amortization of intangible assets | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | 3.7 |  |  | $ | 4.0 |  |  | $ | 2.8 |  |  | $ | 2.2 |  |  | $ | 2.9 |  |  | $ | 3.0 |  |

[0001262039-21-000008:mdna:174]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-21-000008:mdna:175]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, followed by an increase in buying in the second quarter. In 2020, seasonality was impacted by the COVID-19 pandemic. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-21-000008:mdna:176]
Consistent with the seasonality note above, our total quarterly revenue over the past two years has generally increased sequentially each year. Product revenue increased year-over-year as compared to 2019, as we have continued product innovation and successfully launched new product models, expanded our solution sales, with focus on SD-WAN and work from home solutions and continued our investments in our sales and marketing organizations. Due to our growing customer base, we continue to see a relative shift from product revenue to higher-margin, recurring service revenue.

[0001262039-21-000008:mdna:177]
Total gross margin has fluctuated on a quarterly basis primarily due to the relative service and product mix as well as the seasonality of cost increases. Product gross margin varies based on the types of products sold, their cost profile and the average selling prices of our products. In 2020, product gross margin was impacted by new product introductions and the mix of high-end, mid-range and entry-level products and other Fabric appliances as well as increasing software sales. We have been able to improve our direct cost of appliances with newer generations, and our product gross margin continuously benefits from increasing software sales. Service gross margin is impacted by revenue growth and our personnel-related costs, third-party repair and contract fulfillment, data center and cloud hosting, supplies and facility-related costs.

[0001262039-21-000008:mdna:178]
Liquidity and Capital Resources

[0001262039-21-000008:mdna:179]
|  | As of December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,061.8 |  |  | $ | 1,222.5 |  |  | $ | 1,112.4 |  |
| Investments | 893.8 |  |  | 987.4 |  |  | 604.2 |  |
| Total cash, cash equivalents and investments | $ | 1,955.6 |  |  | $ | 2,209.9 |  |  | $ | 1,716.6 |  |
| Working capital | $ | 910.9 |  |  | $ | 1,313.2 |  |  | $ | 975.5 |  |
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 1,083.7 |  |  | $ | 808.0 |  |  | $ | 638.9 |  |
| Net cash used in investing activities | (72.8) |  |  | (502.3) |  |  | (134.9) |  |
| Net cash used in financing activities | (1,171.6) |  |  | (195.6) |  |  | (202.6) |  |
| Net (decrease) increase in cash and cash equivalents | $ | (160.7) |  |  | $ | 110.1 |  |  | $ | 301.4 |  |

[0001262039-21-000008:mdna:180]
Liquidity and capital resources is impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuances of common stock under our the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “2009 Plan”) and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-21-000008:mdna:181]
In recent years, we have received significant capital resources from our billings to customers and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-21-000008:mdna:182]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-21-000008:mdna:183]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. In 2020, we repurchased 11.7 million shares of common stock under the Repurchase Program for an aggregate purchase price of $1.08 billion. As of December 31, 2020, $1.01 billion remained available for future share repurchases under the Repurchase Program.

[0001262039-21-000008:mdna:184]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and related spending will continue until project completion. We estimate 2021 spending on the second building of our headquarters campus project to be between $50.0 million and $60.0 million, which was moved from 2020 due to a delay to the project schedule as a result of the COVID-19 pandemic. We estimate construction to be completed in the first half of 2021.

[0001262039-21-000008:mdna:185]
As of December 31, 2020, our cash, cash equivalents and investments of $1.96 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-21-000008:mdna:186]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $119.8 million and $109.3 million as of December 31, 2020 and as of December 31, 2019, respectively.

[0001262039-21-000008:mdna:187]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our share repurchases, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products, the timing and extent of spending to support development efforts, our investments in purchasing or leasing real estate and macroeconomic impacts such as the COVID-19 pandemic. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-21-000008:mdna:188]
Operating Activities

[0001262039-21-000008:mdna:189]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, deferred contract costs and accounts receivable.

[0001262039-21-000008:mdna:190]
Our operating activities during 2020 provided $1.08 billion in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security services subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, and proceeds from the mutual covenant-not-to-sue and release agreement. Our total deferred revenue balance grew $496.2 million, or 24%, during 2020.

[0001262039-21-000008:mdna:191]
Investing Activities

[0001262039-21-000008:mdna:192]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus ownership decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our engineers and other employees. In certain cases, we have elected to own the facility if we believed that ownership rather than leasing is more in line with our long-term strategy. We may make similar decisions in the future. We may also make cash payments in connection with future business combinations.

[0001262039-21-000008:mdna:193]
During 2020, cash used in investing activities was primarily driven by $125.9 million spent on purchases of property and equipment, a large portion of which relates to our headquarters building construction, and $40.2 million used for the OPAQ and Panopta acquisitions, net of cash acquired, and partially offset by $92.0 million provided by sales and maturities of investments, net of purchases of investments.

[0001262039-21-000008:mdna:194]
Financing Activities

[0001262039-21-000008:mdna:195]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock and taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the 2009 Plan.

[0001262039-21-000008:mdna:196]
During 2020, cash used in financing activities was $1.17 billion, primarily due to $1.08 billion used to repurchase shares of our common stock, $86.1 million used to pay tax withholding, net of proceeds from the issuance of common stock, and $4.1 million used to pay debt assumed in connection with the OPAQ acquisition.

[0001262039-21-000008:mdna:197]
Contractual Obligations and Commitments

[0001262039-21-000008:mdna:198]
The following summarizes our inventory purchase commitments as of December 31, 2020:

[0001262039-21-000008:mdna:199]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in millions) |
| Inventory purchase commitments (1) | $ | 259.4 |  |  | $ | 259.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| (1) Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-21-000008:mdna:200]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2020, we had $28.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-21-000008:mdna:201]
As of December 31, 2020, we had $90.3 million of long-term income tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001262039-21-000008:mdna:202]
Off-Balance Sheet Arrangements

[0001262039-21-000008:mdna:203]
During 2020, 2019 and 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-21-000008:mdna:204]
Recent Accounting Pronouncements

[0001262039-21-000008:mdna:205]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
