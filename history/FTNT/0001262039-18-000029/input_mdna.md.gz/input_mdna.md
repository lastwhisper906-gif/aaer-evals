# FTNT MD&A — 0001262039-18-000029


## mdna

[0001262039-18-000029:mdna:1]
[same as prior period, unchanged from 0001262039-18-000019:mdna:1]

[0001262039-18-000029:mdna:2]
[same as prior period, unchanged from 0001262039-18-000019:mdna:2]

[0001262039-18-000029:mdna:3]
[same as prior period, unchanged from 0001262039-18-000019:mdna:3]

[0001262039-18-000029:mdna:4]
[same as prior period, unchanged from 0001262039-18-000019:mdna:4]

[0001262039-18-000029:mdna:5]
[same as prior period, unchanged from 0001262039-18-000019:mdna:5]

[0001262039-18-000029:mdna:6]
[same as prior period, unchanged from 0001262039-18-000019:mdna:6]

[0001262039-18-000029:mdna:7]
[same as prior period, unchanged from 0001262039-18-000019:mdna:7]

[0001262039-18-000029:mdna:8]
[same as prior period, unchanged from 0001262039-18-000019:mdna:8]

[0001262039-18-000029:mdna:9]
[same as prior period, unchanged from 0001262039-18-000019:mdna:9]

[0001262039-18-000029:mdna:10]
[same as prior period, unchanged from 0001262039-18-000019:mdna:10]

[0001262039-18-000029:mdna:11]
[same as prior period, unchanged from 0001262039-18-000019:mdna:11]

[0001262039-18-000029:mdna:12]
[same as prior period, unchanged from 0001262039-18-000019:mdna:12]

[0001262039-18-000029:mdna:13]
[same as prior period, unchanged from 0001262039-18-000019:mdna:13]

[0001262039-18-000029:mdna:14]
[same as prior period, unchanged from 0001262039-18-000019:mdna:14]

[0001262039-18-000029:mdna:15]
[same as prior period, unchanged from 0001262039-18-000019:mdna:15]

[0001262039-18-000029:mdna:16]
[same as prior period, unchanged from 0001262039-18-000019:mdna:16]

[0001262039-18-000029:mdna:17]
[same as prior period, unchanged from 0001262039-18-000019:mdna:17]

[0001262039-18-000029:mdna:18]
| • | our intentions regarding share repurchases and the repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-18-000029:mdna:19]
[same as prior period, unchanged from 0001262039-18-000019:mdna:19]

[0001262039-18-000029:mdna:20]
[same as prior period, unchanged from 0001262039-18-000019:mdna:20]

[0001262039-18-000029:mdna:21]
[same as prior period, unchanged from 0001262039-18-000019:mdna:22]

[0001262039-18-000029:mdna:22]
Fortinet is a global leader in cybersecurity solutions to a wide variety of businesses, such as enterprises, data centers and distributed offices. Our cybersecurity solutions are designed to provide broad, integrated and automated protection against dynamic and sophisticated security threats, while simplifying the information technology and security infrastructure of our end-customers.

[0001262039-18-000029:mdna:23]
We have four focus areas for our business.

[0001262039-18-000029:mdna:24]
| • | Network Security - We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller, and WAN acceleration, among others. Our network security appliances include our FortiOS operating system, which provides the foundation for FortiGate security functions and FortiSPU, which is designed to enhance the security processing capabilities. Our customers may also purchase FortiGuard subscription services to access threat intelligence updates. We provide standard technical support across all our products through our FortiCare support services. |

[0001262039-18-000029:mdna:25]
| • | Fortinet Security Fabric - The Fortinet Security Fabric, which is one of the fastest growing areas of our business, provides enterprise organizations with unified security across the entire digital attack surface, including network core, endpoints, applications, data centers, access and private and public cloud. It enables disparate security devices to work together as an integrated and collaborative whole. |

[0001262039-18-000029:mdna:26]
| • | Cloud Security - We help customers secure their cloud environments in part by offering security through our virtual firewall software in public cloud environments. In addition, our FortiCASB extends the core capabilities of our security fabric architecture to provide businesses the same level of cybersecurity and threat intelligence in cloud environments as they receive on their physical networks. We experienced significant billings growth in on-demand cloud consumption and bring-your-own-license (“BYOL”), although not yet significant when compared to the rest of our business. The Fortinet cloud security is available across all major cloud providers, including Microsoft Azure, Amazon Web Services, Google Cloud, Oracle Cloud and IBM Cloud. We believe this area provides opportunity for growth. |

[0001262039-18-000029:mdna:27]
| • | Internet of Things and Operational Technology (“OT”) - IoT and OT are new opportunities for us to grow our business. IoT and OT have created an environment where data move freely between devices across locations, network environments, remote offices, mobile workers and public cloud environments, making the data difficult to consistently track and secure. We are increasing our focus on OT to help protect the physical processes and things used in critical infrastructures, industrial and building automation. |

[0001262039-18-000029:mdna:28]
[same as prior period, unchanged from 0001262039-18-000019:mdna:25]

[0001262039-18-000029:mdna:29]
| • | We recorded total revenue of $441.3 million and $840.3 million in the three and six months ended June 30, 2018, an increase of 21% and 19%, respectively, compared to $363.5 million and $704.0 million in the same periods last year. Product revenue was $166.3 million and $309.1 million in the three and six months ended June 30, 2018, an increase of 17% and 11%, respectively, compared to $142.7 million and $277.9 million in the same periods last year. Service revenue was $275.0 million and $531.2 million, respectively, in the three and six months ended June 30, 2018, an increase of 25% for both periods, compared to $220.8 million and $426.1 million in the same period last year. |

[0001262039-18-000029:mdna:30]
| • | We generated operating income of $50.7 million and $83.1 million in the three and six months ended June 30, 2018, an increase of 78% and 145%, respectively, compared to $28.5 million and $33.9 million in the same periods last year. |

[0001262039-18-000029:mdna:31]
[same as prior period, unchanged from 0001262039-18-000019:mdna:61]

[0001262039-18-000029:mdna:32]
| • | Cash, cash equivalents and investments were $1.50 billion as of June 30, 2018, an increase of $149.7 million, or 11%, from December 31, 2017. |

[0001262039-18-000029:mdna:33]
| • | Deferred revenue was $1.47 billion as of June 30, 2018, an increase of $134.5 million, or 10%, from December 31, 2017. |

[0001262039-18-000029:mdna:34]
| • | We generated cash flows from operating activities of $282.0 million in the six months ended June 30, 2018, an increase of $7.5 million, or 3%, compared to the same periods last year. |

[0001262039-18-000029:mdna:35]
| • | During the six months ended June 30, 2018, we repurchased 2.5 million shares of common stock under the Repurchase Program for an aggregate purchase price of $117.1 million. |

[0001262039-18-000029:mdna:36]
During the three and six months ended June 30, 2018, our revenue growth was driven by both product and service revenue. Product revenue grew 17% and 11% in the three and six months ended June 30, 2018, respectively. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, also grew significantly. Service revenue growth of 25% in the three and six months ended June 30, 2018 was driven by the strength of our FortiCare technical support growing 29% and 32%, respectively, and FortiGuard security subscription revenue growing 21% and 20%, respectively.

[0001262039-18-000029:mdna:37]
The percentage of our FortiGate-related billings from entry-level products increased from 32% in the three months ended June 30, 2017 to 34% in the three months ended June 30, 2018. The percentage of our FortiGate-related billings from mid-range products increased from 29% in the three months ended June 30, 2017 to 31% in the three months ended June 30, 2018. The percentage of our FortiGate-related billings from high-end products decreased to 35% in the three months ended June 30, 2018 from 39% in the same period last year. We continue to see our enterprise customers purchasing a fairly balanced mix of products across these product groups.

[0001262039-18-000029:mdna:38]
During the three and six months ended June 30, 2018, operating expenses as a percentage of revenue decreased by 3 percentage points and 4 percentage points, respectively, compared to the same period last year. The decrease was primarily driven by a reduction in sales and marketing expenses as a percentage of revenue, as a result of the adoption of Topic 606 for deferred contract costs, which reduced our commissions expense in absolute dollars and as a percentage of total revenue. Our sales and marketing expenses included a benefit of $11.8 million and $23.5 million in the three and six months ended June 30, 2018, respectively, from the adoption of Topic 606 related to deferred contract costs. Under Topic 606, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of Topic 606, we expensed the commission related to these service contracts upfront. Excluding this benefit, sales and marketing expense as a percentage of revenue would have increased 1 percentage point in the three months ended June 30, 2018 and would have been comparable in the six months ended June 30, 2018. Refer to Note 1 and Note 2 in our notes to the condensed consolidated financial statement for more information. Headcount increased by 4% to 5,462 employees and contractors as of June 30, 2018, up from 5,275 as of March 31, 2018.

[0001262039-18-000029:mdna:39]
[same as prior period, unchanged from 0001262039-18-000019:mdna:35]

[0001262039-18-000029:mdna:40]
Our sales strategy is based on a distribution model whereby we primarily sell our hardware products, software and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across all major cloud providers, and have recognized on demand revenue and BYOL revenue from Microsoft Azure, Amazon Web Services, Oracle Cloud, Google Cloud and IBM Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us and deploys the software in a cloud provider’s environment. While the revenue from such sales are still relatively insignificant, they have increased significantly in recent periods on a percentage basis.

[0001262039-18-000029:mdna:41]
Typically, our customers purchase our hardware products and software licenses as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is payable within 30 to 90 days. We also invoice certain licenses and services on a monthly basis.

[0001262039-18-000029:mdna:42]
Our Security Processing Unit (“SPU”) hardware architecture is an important part of our approach to network security. The SPU includes three lines of proprietary ASICs, content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-18-000029:mdna:43]
[same as prior period, unchanged from 0001262039-18-000019:mdna:39]

[0001262039-18-000029:mdna:44]
[same as prior period, unchanged from 0001262039-18-000019:mdna:40]

[0001262039-18-000029:mdna:45]
|  | Three Months Ended Or As Of |
|  | June 30, 2018 |  | June 30, 2017 |
| Revenue | $ | 441.3 |  |  | $ | 363.5 |  |
| Deferred revenue | $ | 1,470.8 |  |  | $ | 1,161.5 |  |
| Billings (non-GAAP) | $ | 513.4 |  |  | $ | 426.9 |  |
| Cash, cash equivalents and investments | $ | 1,499.0 |  |  | $ | 1,464.9 |  |
| Net cash provided by operating activities | $ | 142.2 |  |  | $ | 144.8 |  |
| Free cash flow (non-GAAP) | $ | 130.6 |  |  | $ | 58.4 |  |

[0001262039-18-000029:mdna:46]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue and free cash flow to be recognized in future periods. Deferred revenue was $1.47 billion as of June 30, 2018, an increase of $134.5 million, or 10%, from December 31, 2017.

[0001262039-18-000029:mdna:47]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $513.4 million for the three months ended June 30, 2018, an increase of 20% compared to $426.9 million in the same period last year.

[0001262039-18-000029:mdna:48]
[same as prior period, unchanged from 0001262039-18-000019:mdna:44]

[0001262039-18-000029:mdna:49]
|  | Three Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Billings: |  |  |  |
| Revenue | $ | 441.3 |  |  | $ | 363.5 |  |
| Add: Change in deferred revenue | 74.4 |  |  | 63.4 |  |
| Less: Deferred revenue balance acquired in business combination | (2.3 | ) |  | — |  |
| Total billings (non-GAAP) | $ | 513.4 |  |  | $ | 426.9 |  |

[0001262039-18-000029:mdna:50]
[same as prior period, unchanged from 0001262039-18-000019:mdna:47]

[0001262039-18-000029:mdna:51]
|  | Three Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 142.2 |  |  | $ | 144.8 |  |
| Less: Purchases of property and equipment | (11.6 | ) |  | (86.4 | ) |
| Free cash flow (non-GAAP) | $ | 130.6 |  |  | $ | 58.4 |  |
| Net cash provided by (used in) investing activities | $ | 7.0 |  |  | $ | (81.9 | ) |
| Net cash used in financing activities | $ | (12.8 | ) |  | $ | (33.0 | ) |

[0001262039-18-000029:mdna:52]
[same as prior period, unchanged from 0001262039-18-000019:mdna:49]

[0001262039-18-000029:mdna:53]
[same as prior period, unchanged from 0001262039-18-000019:mdna:50]

[0001262039-18-000029:mdna:54]
We adopted Topic 606 on January 1, 2018 using the modified retrospective method. Refer to Note 2 in the notes to our condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for a discussion of the impact. Other than the adoption of Topic 606, there were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2018, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-18-000029:mdna:55]
[same as prior period, unchanged from 0001262039-18-000019:mdna:52]

[0001262039-18-000029:mdna:56]
[same as prior period, unchanged from 0001262039-18-000019:mdna:53]

[0001262039-18-000029:mdna:57]
[same as prior period, unchanged from 0001262039-18-000019:mdna:54]

[0001262039-18-000029:mdna:58]
Three Months Ended June 30, 2018 and June 30, 2017

[0001262039-18-000029:mdna:59]
[same as prior period, unchanged from 0001262039-18-000019:mdna:56]

[0001262039-18-000029:mdna:60]
|  | Three Months Ended |  |  |  |  |
| June 30, 2018 (1) |  | June 30, 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 166.3 |  |  | 38 | % |  | $ | 142.7 |  |  | 39 | % |  | $ | 23.6 |  |  | 17 | % |
| Service | 275.0 |  |  | 62 |  |  | 220.8 |  |  | 61 |  |  | 54.2 |  |  | 25 |  |
| Total revenue | $ | 441.3 |  |  | 100 | % |  | $ | 363.5 |  |  | 100 | % |  | $ | 77.8 |  |  | 21 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 189.3 |  |  | 43 | % |  | $ | 160.7 |  |  | 44 | % |  | $ | 28.6 |  |  | 18 | % |
| EMEA | 164.4 |  |  | 37 |  |  | 129.8 |  |  | 36 |  |  | 34.6 |  |  | 27 |  |
| APAC | 87.6 |  |  | 20 |  |  | 73.0 |  |  | 20 |  |  | 14.6 |  |  | 20 |  |
| Total revenue | $ | 441.3 |  |  | 100 | % |  | $ | 363.5 |  |  | 100 | % |  | $ | 77.8 |  |  | 21 | % |

[0001262039-18-000029:mdna:61]
(1) Revenue during the three months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000029:mdna:62]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Revenue: |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 162.1 |  |  | $ | 4.2 |  |
| Service | 275.0 |  |  | 274.0 |  |  | 1.0 |  |
| Total revenue | $ | 441.3 |  |  | $ | 436.1 |  |  | $ | 5.2 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 189.3 |  |  | $ | 185.2 |  |  | $ | 4.1 |  |
| EMEA | 164.4 |  |  | 163.2 |  |  | 1.2 |  |
| APAC | 87.6 |  |  | 87.7 |  |  | (0.1 | ) |
| Total revenue | $ | 441.3 |  |  | $ | 436.1 |  |  | $ | 5.2 |  |

[0001262039-18-000029:mdna:63]
Total revenue increased by $77.8 million, or 21%, during the three months ended June 30, 2018 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all our regions grew, with the EMEA contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $23.6 million, or 17%, during the three months ended June 30, 2018 compared to the same period last year. Product revenue during the three months ended June 30, 2018 included a $4.2 million benefit from the adoption of Topic 606, which primarily relates to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements can now be recognized immediately instead of ratably over the contracted service term. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products also increased significantly. Fortinet Security Fabric and cloud products were the fastest growing products compared to the remainder of our business. Service revenue increased by $54.2 million, or 25%, during the three months ended June 30, 2018 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-18-000029:mdna:64]
[same as prior period, unchanged from 0001262039-18-000019:mdna:93]

[0001262039-18-000029:mdna:65]
[same as prior period, unchanged from 0001262039-18-000019:mdna:62]

[0001262039-18-000029:mdna:66]
|  | Three Months Ended |  |  |  |  |
| June 30, 2018 (1) |  | June 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 73.9 |  |  | $ | 60.8 |  |  | $ | 13.1 |  |  | 22 | % |
| Service | 39.2 |  |  | 34.9 |  |  | 4.3 |  |  | 12 |  |
| Total cost of revenue | $ | 113.1 |  |  | $ | 95.7 |  |  | $ | 17.4 |  |  | 18 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 55.6 | % |  | 57.4 | % |  | (1.8 | )% |  |  |
| Service | 85.7 |  |  | 84.2 |  |  | 1.5 |  |  |  |
| Total gross margin | 74.4 | % |  | 73.7 | % |  | 0.7 | % |  |  |

[0001262039-18-000029:mdna:67]
(1) Cost of revenue and gross margin during the three months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000029:mdna:68]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 73.9 |  |  | $ | 74.1 |  |  | $ | (0.2 | ) |
| Service | 39.2 |  |  | 39.2 |  |  | — |  |
| Total cost of revenue | $ | 113.1 |  |  | $ | 113.3 |  |  | $ | (0.2 | ) |
| Gross margin (%): |  |  |  |  |  |
| Product | 55.6 | % |  | 54.3 | % |  | 1.3 | % |
| Service | 85.7 |  |  | 85.7 | % |  | — | % |
| Total gross margin | 74.4 | % |  | 74.0 | % |  | 0.4 | % |

[0001262039-18-000029:mdna:69]
Total gross margin increased by 0.7 percentage points during the three months ended June 30, 2018 compared to the same period last year, driven by higher margin on service revenue. Service gross margin increased by 1.5 percentage points during the three months ended June 30, 2018 compared to the same period last year, due to the strength of our FortiCare technical support and FortiGuard security subscription revenue growing 29% and 21%, respectively, during the three months ended June 30, 2018 compared to the same period last year, which outpaced the increase in the related personnel costs and headcount growth, resulting in a higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 1.8 percentage point during the three months ended June 30, 2018 compared to the same period last year, primarily due to a shift in product mix, product transition and contract term. The decrease was partially offset by increased revenue in higher margin software licenses.  Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-18-000029:mdna:70]
[same as prior period, unchanged from 0001262039-18-000019:mdna:67]

[0001262039-18-000029:mdna:71]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2018 (1) |  | June 30, 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 61.2 |  |  | 14% |  | $ | 51.2 |  |  | 14 | % |  | $ | 10.0 |  |  | 20 | % |
| Sales and marketing | 192.8 |  |  | 44 |  | 166.3 |  |  | 46 |  |  | 26.5 |  |  | 16 |  |
| General and administrative | 23.5 |  |  | 5 |  | 21.9 |  |  | 6 |  |  | 1.6 |  |  | 7 |  |
| Restructuring charges | — |  |  | — |  | (0.1 | ) |  | — |  |  | 0.1 |  |  | (100 | ) |
| Total operating expenses | $ | 277.5 |  |  | 63% |  | $ | 239.3 |  |  | 66 | % |  | $ | 38.2 |  |  | 16 | % |

[0001262039-18-000029:mdna:72]
(1) Operating expenses during the three months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000029:mdna:73]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 61.2 |  |  | $ | 61.2 |  |  | $ | — |  |
| Sales and marketing expenses | 192.8 |  |  | 204.6 |  |  | (11.8 | ) |
| General and administrative | 23.5 |  |  | 23.5 |  |  | — |  |
| Total operating expenses | $ | 277.5 |  |  | $ | 289.3 |  |  | $ | (11.8 | ) |

[0001262039-18-000029:mdna:74]
[same as prior period, unchanged from 0001262039-18-000019:mdna:71]

[0001262039-18-000029:mdna:75]
Research and development expense increased by $10.0 million, or 20%, during the three months ended June 30, 2018 compared to the same period last year, primarily due to an increase of $6.9 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, product development expenses, such as third-party testing, prototypes and supplies, increased by $2.5 million and depreciation and other occupancy-related costs increased by $0.7 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000029:mdna:76]
[same as prior period, unchanged from 0001262039-18-000019:mdna:73]

[0001262039-18-000029:mdna:77]
Sales and marketing expense increased by $26.5 million, or 16%, during the three months ended June 30, 2018 compared to the same period last year, primarily due to an increase of $18.3 million in personnel-related costs as sales and marketing headcount increased in order to drive market share gains globally. These increases in personnel costs included a benefit of $11.8 million from the adoption of the new accounting standard related to deferred contract costs. Under this new standard, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commission related to these service contracts. Our sales and marketing expense would have increased by $38.3 million or 23% under the prior accounting standard. Refer to Note 2 in our notes to the condensed consolidated financial statement for more information. Marketing-related expense increased by $2.2 million. In addition, travel and entertainment expense increased by $2.1 million and depreciation expense and other occupancy-related expense increased by $2.0 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 47% of total revenue. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000029:mdna:78]
[same as prior period, unchanged from 0001262039-18-000019:mdna:114]

[0001262039-18-000029:mdna:79]
[same as prior period, unchanged from 0001262039-18-000019:mdna:75]

[0001262039-18-000029:mdna:80]
General and administrative expense increased by $1.6 million, or 7%, during the three months ended June 30, 2018 compared to the same period last year. Personnel costs increased by $2.7 million as we continued to increase headcount in order to support our expanding business. The increase in expense was partially offset by a decrease in depreciation and other occupancy-related costs of $1.9 million and decrease in professional fees of $0.5 million. We expect general and administrative expense to increase in absolute dollars during the remainder of 2018.

[0001262039-18-000029:mdna:81]
[same as prior period, unchanged from 0001262039-18-000019:mdna:77]

[0001262039-18-000029:mdna:82]
We generated operating income of $50.7 million during the three months ended June 30, 2018, an increase of $22.2 million, or 78%, compared to $28.5 million in the same period last year. The improvement in operating income was primarily due to the benefit from the adoption of the new accounting standard. As a percentage of total revenue, sales and marketing expenses decreased to 44% in the three months ended June 30, 2018 from 46% in the same period last year. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 47% of total revenue. The adoption of this new standard resulted in an improvement of 3.8 percentage points in our operating margin. In addition, the improvement in gross margin as well as the decrease in general and administrative expenses as a percentage of total revenue contributed to the improvement in operating margin.

[0001262039-18-000029:mdna:83]
[same as prior period, unchanged from 0001262039-18-000019:mdna:79]

[0001262039-18-000029:mdna:84]
|  | Three Months Ended |  |  |  |  |
| June 30, 2018 |  | June 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 5.8 |  |  | $ | 3.2 |  |  | $ | 2.6 |  |  | 81 | % |
| Other income (expense)—net | (5.0 | ) |  | 1.2 |  |  | (6.2 | ) |  | (517 | ) |

[0001262039-18-000029:mdna:85]
Interest income increased during the three months ended June 30, 2018 compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net during the three months ended June 30, 2018 compared to the same period last year was primarily due to higher foreign currency exchange losses.

[0001262039-18-000029:mdna:86]
Provision for (benefit from) income taxes

[0001262039-18-000029:mdna:87]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2018 (1) |  | June 30, 2017 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 2.2 |  |  | $ | 9.9 |  |  | $ | (7.7 | ) |  | (78 | )% |
| Effective tax rate (%) | 4 | % |  | 30 | % |  | (26 | )% |  | — |  |

[0001262039-18-000029:mdna:88]
(1) Provision for (benefit from) income taxes during the three months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000029:mdna:89]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Increase (Decrease) |
| Provision for (benefit from) income taxes | $ | 2.2 |  |  | $ | (1.8 | ) |  | $ | 4.0 |  |
| Effective tax rate (%) | 4 | % |  | (5 | )% |  | 9 | % |

[0001262039-18-000029:mdna:90]
37

[0001262039-18-000029:mdna:91]
Our effective tax rate was 4% for the three months ended June 30, 2018 compared to an effective tax rate of 30% for the same period last year, with the primary difference being the change in the federal tax rate to 21% in 2018 from 35% in the prior year, the release of a reserve on uncertain tax positions including interest due to a statute of limitation expiring and the completion of an IRS audit. The effective tax rate for the periods presented are comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes of $17.2 million, which were offset by a tax provision benefit of $4.9 million for stock-based compensation. The tax rate for the three months ended June 30, 2018 was also impacted by release of a reserve on uncertain tax positions including interest of $10.1 million. The tax rate for the three months ended June 30, 2017 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $14.4 million which were offset by a tax provision benefit of $4.1 million for stock-based compensation.

[0001262039-18-000029:mdna:92]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. Effective January 1, 2018, the 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate.

[0001262039-18-000029:mdna:93]
The SEC staff has issued Staff Accounting Bulletin No. 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the 2017 Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the 2017 Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the 2017 Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the 2017 Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the 2017 Tax Act. At this time, our income tax reporting for these effects is provisional using reasonable estimates.

[0001262039-18-000029:mdna:94]
The 2017 Tax Act creates a new requirement that global intangible low-taxed income (“GILTI”) earned by controlled foreign corporations (“CFCs”) be included currently in the gross income of the CFCs’ U.S. shareholder. Because of the complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the 2017 Tax Act and the application of ASC 740. Under GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. Our selection of an accounting policy for the first quarter of 2018 with respect to the GILTI tax rules was to treat GILTI tax as a current-period expense under the period cost method.

[0001262039-18-000029:mdna:95]
[same as prior period, unchanged from 0001262039-18-000019:mdna:91]

[0001262039-18-000029:mdna:96]
It is our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of June 30, 2018 and December 31, 2017, accrued interest and penalties were $11.1 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.9 million in the next 12 months, primarily due to the lapse of the statute of limitations and audit settlement. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000029:mdna:97]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. In Altera, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. The Tax Court had invalidated those regulations, in part because the Treasury Department failed to adequately consider significant taxpayer comments when adopting them. The Ninth Court decision reverses the Tax Court’s decision on this issue, holding that the Treasury Department’s rule was not arbitrary and capricious because the Treasury Department provided a sufficient basis for its decision making. We are in the process of evaluating the impact of this court decision which occurred subsequent to the quarter end.

[0001262039-18-000029:mdna:98]
38

[0001262039-18-000029:mdna:99]
Six Months Ended June 30, 2018 and June 30, 2017

[0001262039-18-000029:mdna:100]
Revenue

[0001262039-18-000029:mdna:101]
|  | Six Months Ended |  |  |  |  |
| June 30, 2018 (1) |  | June 30, 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 309.1 |  |  | 37 | % |  | $ | 277.9 |  |  | 39 | % |  | $ | 31.2 |  |  | 11 | % |
| Service | 531.2 |  |  | 63 |  |  | 426.1 |  |  | 61 |  |  | 105.1 |  |  | 25 |  |
| Total revenue | $ | 840.3 |  |  | 100 | % |  | $ | 704.0 |  |  | 100 | % |  | $ | 136.3 |  |  | 19 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 365.1 |  |  | 43 | % |  | $ | 307.1 |  |  | 44 | % |  | $ | 58.0 |  |  | 19 | % |
| EMEA | 308.9 |  |  | 37 |  |  | 255.8 |  |  | 36 |  |  | 53.1 |  |  | 21 |  |
| APAC | 166.3 |  |  | 20 |  |  | 141.1 |  |  | 20 |  |  | 25.2 |  |  | 18 |  |
| Total revenue | $ | 840.3 |  |  | 100 | % |  | $ | 704.0 |  |  | 100 | % |  | $ | 136.3 |  |  | 19 | % |

[0001262039-18-000029:mdna:102]
(1) Revenue during the six months ended June 30, 2018 under Topic 606 (As Reported) and Topic 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000029:mdna:103]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Revenue: |  |  |  |  |  |
| Product | $ | 309.1 |  |  | $ | 299.2 |  |  | $ | 9.9 |  |
| Service | 531.2 |  |  | 529.5 |  |  | 1.7 |  |
| Total revenue | $ | 840.3 |  |  | $ | 828.7 |  |  | $ | 11.6 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 365.1 |  |  | $ | 354.3 |  |  | $ | 10.8 |  |
| EMEA | 308.9 |  |  | 307.1 |  |  | 1.8 |  |
| APAC | 166.3 |  |  | 167.3 |  |  | (1.0 | ) |
| Total revenue | $ | 840.3 |  |  | $ | 828.7 |  |  | $ | 11.6 |  |

[0001262039-18-000029:mdna:104]
Total revenue increased by $136.3 million, or 19%, during the six months ended June 30, 2018 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all our regions grew, with EMEA contributing the largest portion of our revenue growth on a percentage basis. Product revenue increased by $31.2 million, or 11%, during the six months ended June 30, 2018 compared to the same period last year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products, were the fastest growing products compared to the remainder of our business. FortiGate unit shipments, including Fortinet Security Fabric, increased year-over-year. Product revenue in the six months ended June 30, 2018 included a $9.9 million benefit from the adoption of Topic 606, which primarily related to sell-through of our U.S. channel inventory and the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements can now be recognized immediately instead of ratably over the contracted service term. Service revenue increased by $105.1 million, or 25%, during the six months ended June 30, 2018 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-18-000029:mdna:105]
39

[0001262039-18-000029:mdna:106]
Cost of revenue and gross margin

[0001262039-18-000029:mdna:107]
|  | Six Months Ended |  |  |  |  |
| June 30, 2018 (1) |  | June 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 132.1 |  |  | $ | 116.1 |  |  | $ | 16.0 |  |  | 14 | % |
| Service | 78.2 |  |  | 70.1 |  |  | 8.1 |  |  | 12 |  |
| Total cost of revenue | $ | 210.3 |  |  | $ | 186.2 |  |  | $ | 24.1 |  |  | 13 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.3 | % |  | 58.2 | % |  | (0.9 | )% |  |  |
| Service | 85.3 |  |  | 83.5 |  |  | 1.8 |  |  |  |
| Total gross margin | 75.0 | % |  | 73.6 | % |  | 1.4 | % |  |  |

[0001262039-18-000029:mdna:108]
(1) Cost of revenue and gross margin during the six months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000029:mdna:109]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 132.1 |  |  | $ | 130.8 |  |  | $ | 1.3 |  |
| Service | 78.2 |  |  | 78.2 |  |  | — |  |
| Total cost of revenue | $ | 210.3 |  |  | $ | 209.0 |  |  | $ | 1.3 |  |
| Gross margin (%): |  |  |  |  |  |
| Product | 57.3 | % |  | 56.3 | % |  | 1.0 | % |
| Service | 85.3 |  |  | 85.2 | % |  | 0.1 | % |
| Total gross margin | 75.0 | % |  | 74.8 | % |  | 0.2 | % |

[0001262039-18-000029:mdna:110]
Total gross margin increased by 1.4 percentage points during the six months ended June 30, 2018 compared to the same period last year, driven by higher margin on service revenue. Service gross margin increased by 1.8 percentage points during the six months ended June 30, 2018 compared to the same period last year, due to the strength of our FortiCare technical support and FortiGuard security subscription revenue growing 32% and 20%, respectively, during the six months ended June 30, 2018 compared to the same period last year, which outpaced the increase in the related personnel costs and headcount growth, resulting in a higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 0.9 percentage point during the six months ended June 30, 2018 compared to the same period last year, primarily due to increase in product mix, product transition and contract term. The decrease was partially offset by increased revenue in higher-margin software licenses. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-18-000029:mdna:111]
Operating expenses

[0001262039-18-000029:mdna:112]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2018 (1) |  | June 30, 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 120.3 |  |  | 14% |  | $ | 102.4 |  |  | 15 | % |  | $ | 17.9 |  |  | 17 | % |
| Sales and marketing | 378.1 |  |  | 45 |  | 336.7 |  |  | 48 |  |  | 41.4 |  |  | 12 |  |
| General and administrative | 48.5 |  |  | 6 |  | 44.5 |  |  | 6 |  |  | 4.0 |  |  | 9 |  |
| Restructuring charges | — |  |  | — |  | 0.3 |  |  | — |  |  | (0.3 | ) |  | (100 | ) |
| Total operating expenses | $ | 546.9 |  |  | 65% |  | $ | 483.9 |  |  | 69 | % |  | $ | 63.0 |  |  | 13 | % |

[0001262039-18-000029:mdna:113]
(1) Operating expenses during the six months ended June 30, 2018 under Topic 606 (As Reported) and Topic 605 (Balances Without Adoption of Topic 606) were as follows (in millions):

[0001262039-18-000029:mdna:114]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 120.3 |  |  | $ | 120.3 |  |  | $ | — |  |
| Sales and marketing expenses | 378.1 |  |  | 401.6 |  |  | (23.5 | ) |
| General and administrative | 48.5 |  |  | 48.5 |  |  | — |  |
| Total operating expenses | $ | 546.9 |  |  | $ | 570.4 |  |  | $ | (23.5 | ) |

[0001262039-18-000029:mdna:115]
Research and development

[0001262039-18-000029:mdna:116]
Research and development expense increased by $17.9 million, or 17%, during the six months ended June 30, 2018 compared to the same period last year, primarily due to an increase of $14.0 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, product development expenses, such as third-party testing, prototypes and supplies, increased by $2.6 million

[0001262039-18-000029:mdna:117]
and depreciation and other occupancy-related costs increased by $1.6 million.

[0001262039-18-000029:mdna:118]
Sales and marketing

[0001262039-18-000029:mdna:119]
Sales and marketing expense increased by $41.4 million, or 12%, during the six months ended June 30, 2018 compared to the same period last year, primarily due to an increase of $30.3 million in personnel-related costs as sales and marketing headcount increased in order to drive market share gains globally. These increases in personnel costs included a benefit of $23.5 million from the adoption of the new accounting standard related to deferred contract costs. Under this new standard, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commission related to these service contracts. Our sales and marketing expense would have increased by $64.9 million, or 19%, under the prior accounting standard. Refer to Note 2 in our notes to the condensed consolidated financial statement for more information. Travel and entertainment expense increased by $4.3 million. In addition, depreciation expense and other occupancy-related expense increased by $3.3 million and marketing-related expense increased by $3.1 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 48% of total revenue.

[0001262039-18-000029:mdna:120]
General and administrative

[0001262039-18-000029:mdna:121]
General and administrative expense increased by $4.0 million, or 9%, during the six months ended June 30, 2018 compared to the same period last year. Personnel costs increased by $6.2 million as we continued to increase headcount in order to support our expanding business. In addition, expense related to supplies and software licenses increased by $2.2 million. The increase in expense was partially offset by a decrease in depreciation and other occupancy-related costs of $3.4 million and a decrease in litigation settlement costs of $1.7 million.

[0001262039-18-000029:mdna:122]
Operating income

[0001262039-18-000029:mdna:123]
We generated operating income of $83.1 million during the six months ended June 30, 2018, an increase of $49.2 million, or 145%, compared to $33.9 million in the same period last year. The improvement in operating income generated was primarily due to the benefit from the adoption of the new accounting standard. As a percentage of total revenue, sales and marketing expenses decreased to 45% in the six months ended June 30, 2018 from 48% in the same period last year. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 48% of total revenue. The adoption of this new standard resulted in an improvement of 4.0 percentage points in our operating margin.

[0001262039-18-000029:mdna:124]
Interest income and other income (expense)—net

[0001262039-18-000029:mdna:125]
|  | Six Months Ended |  |  |  |  |
| June 30, 2018 |  | June 30, 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 10.3 |  |  | $ | 5.6 |  |  | $ | 4.7 |  |  | 84 | % |
| Other income (expense)—net | (5.2 | ) |  | 1.5 |  |  | (6.7 | ) |  | (447 | ) |

[0001262039-18-000029:mdna:126]
Interest income increased during the six months ended June 30, 2018 compared to the same period last year, primarily due to higher interest rates and higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments and market interest rates. The change in other income (expense)—net during the six months ended June 30, 2018 compared to the same period last year was primarily due to higher foreign currency exchange losses.

[0001262039-18-000029:mdna:127]
Provision for (benefit from) income taxes

[0001262039-18-000029:mdna:128]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2018 (1) |  | June 30, 2017 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (2.7 | ) |  | $ | 7.3 |  |  | $ | (10.0 | ) |  | (137 | )% |
| Effective tax rate (%) | (3 | )% |  | 18 | % |  | (21 | )% |  | — |  |

[0001262039-18-000029:mdna:129]
(1) Provision for (benefit from) income taxes during the six months ended June 30, 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows (in millions, except percentages):

[0001262039-18-000029:mdna:130]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Increase (Decrease) |
| Provision for (benefit from) income taxes | $ | (2.7 | ) |  | $ | (10.5 | ) |  | $ | 7.8 |  |
| Effective tax rate (%) | (3 | )% |  | (19 | )% |  | 16 | % |

[0001262039-18-000029:mdna:131]
Our effective tax rate was a benefit of 3% for the six months ended June 30, 2018 compared to an effective tax rate of 18% for the same period last year, with the primary difference being the change in the federal corporate income tax rate to 21% in 2018 from 35% in the prior year and release of reserve for uncertain tax positions, including interest due to a statute of limitation expiring and the IRS audit finalization. The effective tax rate for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $25.7 million, which were offset by a tax benefit of $10.5 million for stock-based compensation. The tax rate for the six month ended June 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million. The tax rate for the six months ended June 30, 2017 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $17.3 million which were offset by a tax provision benefit of $9.6 million for stock-based compensation.

[0001262039-18-000029:mdna:132]
[same as prior period, unchanged from 0001262039-18-000019:mdna:94]

[0001262039-18-000029:mdna:133]
|  | As of |
|  | June 30, 2018 |  | December 31, 2017 |
|  | (in millions) |
| Cash and cash equivalents | $ | 972.1 |  |  | $ | 811.0 |  |
| Investments | 526.9 |  |  | 538.3 |  |
| Total cash, cash equivalents and investments | $ | 1,499.0 |  |  | $ | 1,349.3 |  |
| Working capital | $ | 799.6 |  |  | $ | 689.6 |  |
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 282.0 |  |  | $ | 274.5 |  |
| Net cash used in investing activities | (18.5 | ) |  | (113.2 | ) |
| Net cash used in financing activities | (102.4 | ) |  | (17.2 | ) |
| Net increase in cash and cash equivalents | $ | 161.1 |  |  | $ | 144.1 |  |

[0001262039-18-000029:mdna:134]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of equity awards and business acquisitions. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the proceeds from exercise of stock options and purchases under the ESPP. Additional increases in deferred revenue may depend on a number of factors including our billing growth rate, service contract renewal rates and length of initial and renewals service contracts. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units granted versus stock options and also to vary based on our share price. As of June 30, 2018, $325.8 million remained available for future share repurchase under the Repurchase Program.

[0001262039-18-000029:mdna:135]
Construction on the new headquarters building is expected to start in the fourth quarter of 2018 and related spend will continue in 2019 and until project completion. We estimate 2018 spending for this project to be approximately $10.0 million to $20.0 million.

[0001262039-18-000029:mdna:136]
As of June 30, 2018, our cash, cash equivalents and investments of $1.50 billion were invested primarily in corporate debt securities, certificates of deposit and term deposits, money market funds, commercial paper and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-18-000029:mdna:137]
43

[0001262039-18-000029:mdna:138]
As of June 30, 2018, $915.7 million of our cash and investments were held by our international subsidiaries. Under the 2017 Tax Act signed into law in December 2017, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which were previously deemed indefinitely reinvested. We expect to be able to repatriate an additional $150 million over the remainder of 2018. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. Most of our off-shore cash is located in Singapore. Corporate law in Singapore only allows dividends to be paid to the extent we have retained earnings in Singapore. In Singapore, our retained earnings are lower than our current cash balance. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-18-000029:mdna:139]
[same as prior period, unchanged from 0001262039-18-000019:mdna:100]

[0001262039-18-000029:mdna:140]
[same as prior period, unchanged from 0001262039-18-000019:mdna:101]

[0001262039-18-000029:mdna:141]
Our operating activities during the six months ended June 30, 2018 provided $282.0 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew 27% as of June 30, 2018 compared to the same period last year to $1.47 billion.

[0001262039-18-000029:mdna:142]
Our operating activities during the six months ended June 30, 2017 provided $274.5 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. The increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers was reflected in the increase in our deferred revenue.

[0001262039-18-000029:mdna:143]
[same as prior period, unchanged from 0001262039-18-000019:mdna:104]

[0001262039-18-000029:mdna:144]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment and payments made in connection with a business combination. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believe that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-18-000029:mdna:145]
During the six months ended June 30, 2018, cash used for investing activities was primarily due to the $23.2 million we spent on capital expenditures and $6.0 million used for the acquisition of Bradford, net of cash acquired. This was partially offset by an increase in cash of $10.7 million due to maturities and sales of our investments, net of purchases.

[0001262039-18-000029:mdna:146]
During the six months ended June 30, 2017, cash used in investing activities was primarily due to the $99.9 million we spent on capital expenditures, including the purchase of $84.8 million in real estate in Burnaby, Canada. Cash outflows due to purchases of investments, net of sales and maturities, were $13.3 million.

[0001262039-18-000029:mdna:147]
[same as prior period, unchanged from 0001262039-18-000019:mdna:108]

[0001262039-18-000029:mdna:148]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards and payments of debt assumed in a business combination.

[0001262039-18-000029:mdna:149]
44

[0001262039-18-000029:mdna:150]
During the six months ended June 30, 2018, cash used for financing activities was $102.4 million, primarily due to $117.1 million used to repurchase our common stock and $9.5 million of payments of the debt assumed in business combination. This was partially offset by $24.2 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000029:mdna:151]
During the six months ended June 30, 2017, cash used in financing activities was $17.2 million, primarily due to $33.1 million used to repurchase our common stock. This was partially offset by $15.9 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-18-000029:mdna:152]
[same as prior period, unchanged from 0001262039-18-000019:mdna:112]

[0001262039-18-000029:mdna:153]
There were no material changes outside the ordinary course of business during the six months ended June 30, 2018 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 10 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-18-000029:mdna:154]
[same as prior period, unchanged from 0001262039-18-000019:mdna:115]

[0001262039-18-000029:mdna:155]
As of June 30, 2018, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
