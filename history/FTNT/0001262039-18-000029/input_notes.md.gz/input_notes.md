# FTNT notes — 0001262039-18-000029


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-18-000029:notes:1]
[same as prior period, unchanged from 0001262039-18-000019:notes:1]

[0001262039-18-000029:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Income tax benefit associated with stock-based compensation | $ | 6.1 |  |  | $ | 7.7 |  |  | $ | 12.1 |  |  | $ | 14.4 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-18-000029:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

[0001262039-18-000029:notes:4]
[same as prior period, unchanged from 0001262039-18-000019:notes:4]

[0001262039-18-000029:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-18-000029:notes:6]
[same as prior period, unchanged from 0001262039-18-000019:notes:6]

[0001262039-18-000029:notes:7]
|  | June 30, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 338.7 |  |  | $ | — |  |  | $ | (1.8 | ) |  | $ | 336.9 |  |
| Certificates of deposit and term deposits (1) | 100.2 |  |  | — |  |  | — |  |  | 100.2 |  |
| Commercial paper | 66.8 |  |  | — |  |  | — |  |  | 66.8 |  |
| U.S. government and agency securities | 23.0 |  |  | — |  |  | — |  |  | 23.0 |  |
| Total available-for-sale securities | $ | 528.7 |  |  | $ | — |  |  | $ | (1.8 | ) |  | $ | 526.9 |  |
|  | December 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 391.0 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 389.8 |  |
| Commercial paper | 74.2 |  |  | — |  |  | — |  |  | 74.2 |  |
| Certificates of deposit and term deposits (1) | 45.9 |  |  | — |  |  | — |  |  | 45.9 |  |
| U.S. government and agency securities | 28.5 |  |  | — |  |  | (0.1 | ) |  | 28.4 |  |
| Total available-for-sale securities | $ | 539.6 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 538.3 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-18-000029:notes:8]
[same as prior period, unchanged from 0001262039-18-000019:notes:8]

[0001262039-18-000029:notes:9]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.4 |  |  | 4.4 |  |
| Volatility | 31.1 | % |  | 34.2 | % |  | 31.7 | % |  | 36.3 | % |
| Risk-free interest rate | 2.9 | % |  | 1.9 | % |  | 2.6 | % |  | 1.9 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-18-000029:notes:10]
[same as prior period, unchanged from 0001262039-18-000019:notes:10]

[0001262039-18-000029:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| RSUs | $ | 35.9 |  |  | $ | 30.9 |  |  | $ | 67.9 |  |  | $ | 59.9 |  |
| Stock options | 2.3 |  |  | 1.9 |  |  | 4.3 |  |  | 3.8 |  |
| ESPP | 2.4 |  |  | 2.3 |  |  | 4.9 |  |  | 4.7 |  |
| Total stock-based compensation expense | $ | 40.6 |  |  | $ | 35.1 |  |  | $ | 77.1 |  |  | $ | 68.4 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-18-000029:notes:12]
[same as prior period, unchanged from 0001262039-18-000019:notes:12]

[0001262039-18-000029:notes:13]
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Shares withheld for taxes | 0.7 |  |  | 0.7 |  |
| Amount withheld for taxes | $ | 32.5 |  |  | $ | 25.9 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-18-000029:notes:14]
[same as prior period, unchanged from 0001262039-18-000019:notes:14]

[0001262039-18-000029:notes:15]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Weighted-average fair value per share granted | $ | 17.86 |  |  | $ | 12.18 |  |  | $ | 15.21 |  |  | $ | 12.22 |  |
| Intrinsic value of options exercised | 15.9 |  |  | 9.0 |  |  | 39.5 |  |  | 26.9 |  |
| Fair value of options vested | 1.5 |  |  | 1.7 |  |  | 4.2 |  |  | 5.1 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-18-000029:notes:16]
[same as prior period, unchanged from 0001262039-18-000019:notes:16]

[0001262039-18-000029:notes:17]
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Weighted-average fair value per share granted | $ | 11.27 |  |  | $ | 9.28 |  |
| Shares issued under the ESPP | 0.7 |  |  | 0.6 |  |
| Weighted-average price per share issued | $ | 31.29 |  |  | $ | 27.97 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-18-000029:notes:18]
BUSINESS COMBINATION

[0001262039-18-000029:notes:19]
Bradford Networks, Inc.

[0001262039-18-000029:notes:20]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a leading provider of network security products and services. We believe that this acquisition will extend the Fortinet Security Fabric to include network access control and provide for the assessment and response related to devices accessing the network, including Internet of Things devices.

[0001262039-18-000029:notes:21]
Under the business combination method of accounting, the total preliminary purchase price was allocated to Bradford’s net tangible and intangible assets based upon their estimated fair values as of June 4, 2018. The preliminary purchase price for Bradford was $6.8 million, of which $10.5 million was allocated to goodwill that was non-deductible for tax purposes, $8.8 million was allocated to identifiable intangible assets offset by $12.5 million of net liabilities assumed. The fair values assigned to assets acquired and liabilities assumed are based on management’s best estimates and assumptions as of the reporting date and are considered preliminary pending finalization of our valuation analysis.

[0001262039-18-000029:notes:22]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of June 30, 2018, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the target.

[0001262039-18-000029:notes:23]
Pro forma information has not been presented for these acquisitions as the impact to our Condensed Consolidated Financial Statements was not material.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-18-000029:notes:24]
COMMITMENTS AND CONTINGENCIES

[0001262039-18-000029:notes:25]
The following table summarizes our future principal contractual obligations as of June 30, 2018 (in millions):

[0001262039-18-000029:notes:26]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 53.2 |  |  | $ | 8.9 |  |  | $ | 14.5 |  |  | $ | 11.2 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |
| Inventory purchase commitments | 104.9 |  |  | 100.7 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 158.1 |  |  | $ | 109.6 |  |  | $ | 14.5 |  |  | $ | 15.4 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |

[0001262039-18-000029:notes:27]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.9 million during the three months ended June 30, 2018 and June 30, 2017, respectively. Rent expense was $8.7 million and $8.4 million during the six months ended June 30, 2018 and June 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-18-000029:notes:28]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2018, we had $104.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-18-000029:notes:29]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2018, we had $9.5 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-18-000029:notes:30]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and there can be no assurances and the outcome of these matters is currently not determinable. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-18-000029:notes:31]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act.  We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.  We are currently in settlement discussions with the United States Attorney’s Office.

[0001262039-18-000029:notes:32]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-18-000029:notes:33]
[same as prior period, unchanged from 0001262039-18-000019:notes:27]

[0001262039-18-000029:notes:34]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2018 and June 30, 2017 were $1.5 million and $1.3 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2018 and June 30, 2017 were $3.0 million and $2.6 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-18-000029:notes:35]
[same as prior period, unchanged from 0001262039-18-000019:notes:29]

[0001262039-18-000029:notes:36]
[same as prior period, unchanged from 0001262039-18-000019:notes:30]

[0001262039-18-000029:notes:37]
|  | June 30, 2018 |
|  | Unrealized Losses on Investments |  | Tax provision related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1.3 | ) |  | $ | 0.5 |  |  | $ | (0.8 | ) |
| Other comprehensive loss before reclassifications | (0.5 | ) |  | (0.1 | ) |  | (0.6 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive loss | (0.5 | ) |  | (0.1 | ) |  | (0.6 | ) |
| Ending balance | $ | (1.8 | ) |  | $ | 0.4 |  |  | $ | (1.4 | ) |

[0001262039-18-000029:notes:38]
[same as prior period, unchanged from 0001262039-18-000019:notes:32]


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-18-000029:notes:39]
[same as prior period, unchanged from 0001262039-18-000019:notes:33]

[0001262039-18-000029:notes:40]
Our investments in the equity securities of privately held companies totaled $12.1 million as of June 30, 2018 and December 31, 2017. These investments, which were previously accounted for at cost, are now accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of June 30, 2018, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-18-000029:notes:41]
As of June 30, 2018, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The VIEs are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001262039-18-000029:notes:42]
[same as prior period, unchanged from 0001262039-18-000019:notes:36]

[0001262039-18-000029:notes:43]
[same as prior period, unchanged from 0001262039-18-000019:notes:37]

[0001262039-18-000029:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 (1) |  | June 30, 2018 |  | June 30, 2017(1) |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 147.1 |  |  | 122.0 |  |  | 283.8 |  |  | 235.5 |  |
| Technical support | 116.4 |  |  | 90.1 |  |  | 226.0 |  |  | 171.2 |  |
| Professional services and training | 11.5 |  |  | 8.7 |  |  | 21.4 |  |  | 19.4 |  |
| Total service revenue | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-18-000029:notes:45]
[same as prior period, unchanged from 0001262039-18-000019:notes:39]

[0001262039-18-000029:notes:46]
[same as prior period, unchanged from 0001262039-18-000019:notes:40]

[0001262039-18-000029:notes:47]
We have stock-based compensation plans pursuant to which we have granted RSUs and stock options. We also have an ESPP for eligible employees. As of June 30, 2018, there were a total of 55.1 million shares of common stock available for grant under our stock-based compensation plans.

[0001262039-18-000029:notes:48]
[same as prior period, unchanged from 0001262039-18-000019:notes:42]

[0001262039-18-000029:notes:49]
[same as prior period, unchanged from 0001262039-18-000019:notes:43]

[0001262039-18-000029:notes:50]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2017 | 8.5 |  |  | $ | 34.79 |  |
| Granted | 3.2 |  |  | 50.97 |  |
| Forfeited | (0.6 | ) |  | 37.21 |  |
| Vested | (2.2 | ) |  | 34.21 |  |
| Balance—June 30, 2018 | 8.9 |  |  | $ | 40.90 |  |

[0001262039-18-000029:notes:51]
As of June 30, 2018, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $326.2 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.41 years.

[0001262039-18-000029:notes:52]
[same as prior period, unchanged from 0001262039-18-000019:notes:46]

[0001262039-18-000029:notes:53]
[same as prior period, unchanged from 0001262039-18-000019:notes:47]

[0001262039-18-000029:notes:54]
[same as prior period, unchanged from 0001262039-18-000019:notes:48]

[0001262039-18-000029:notes:55]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2017 | 4.3 |  |  | $ | 27.50 |  |  |  |  |  |  |
| Granted | 0.7 |  |  | 49.70 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 31.97 |  |  |  |  |  |
| Exercised | (1.5 | ) |  | 24.33 |  |  |  |  |  |
| Balance—June 30, 2018 | 3.4 |  |  | $ | 33.42 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2018 | 3.4 |  |  | $ | 33.42 |  |  | 4.15 |  | $ | 100.1 |  |
| Options exercisable—June 30, 2018 | 1.8 |  |  | $ | 27.92 |  |  | 2.72 |  | $ | 62.4 |  |

[0001262039-18-000029:notes:56]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2018, for all in-the-money stock options. As of June 30, 2018, total compensation expense related to unvested stock options granted to employees but not yet recognized was $19.3 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.8 years.

[0001262039-18-000029:notes:57]
[same as prior period, unchanged from 0001262039-18-000019:notes:51]

[0001262039-18-000029:notes:58]
[same as prior period, unchanged from 0001262039-18-000019:notes:52]

[0001262039-18-000029:notes:59]
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 27.0 | % |  | 33.4 | % |
| Risk-free interest rate | 1.8 | % |  | 0.7 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-18-000029:notes:60]
There were no shares granted or issued under the ESPP during the three month ended June 30, 2018 and June 30, 2017.

[0001262039-18-000029:notes:61]
[same as prior period, unchanged from 0001262039-18-000019:notes:54]

[0001262039-18-000029:notes:62]
[same as prior period, unchanged from 0001262039-18-000019:notes:55]

[0001262039-18-000029:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 0.7 |  |
| Cost of service revenue | 2.7 |  |  | 2.5 |  |  | 5.2 |  |  | 4.8 |  |
| Research and development | 9.2 |  |  | 8.3 |  |  | 17.6 |  |  | 16.1 |  |
| Sales and marketing | 23.6 |  |  | 19.7 |  |  | 44.5 |  |  | 38.8 |  |
| General and administrative | 4.7 |  |  | 4.2 |  |  | 9.0 |  |  | 8.0 |  |
| Total stock-based compensation expense | $ | 40.6 |  |  | $ | 35.1 |  |  | $ | 77.1 |  |  | $ | 68.4 |  |

[0001262039-18-000029:notes:64]
[same as prior period, unchanged from 0001262039-18-000019:notes:57]

[0001262039-18-000029:notes:65]
In January 2016, our board of directors approved a Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-18-000029:notes:66]
During the three months ended June 30, 2018, we repurchased 27,245 shares of common stock under the Repurchase Program in open market transactions at an average price of $56.78 per share, for an aggregate purchase price of $1.5 million. As of June 30, 2018, $325.8 million remained available for future share repurchases under the Repurchase Program. See Note 16—Subsequent Event for additional disclosure related to the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-18-000029:notes:67]
[same as prior period, unchanged from 0001262039-18-000019:notes:60]

[0001262039-18-000029:notes:68]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of restricted stock units (“RSUs”), stock options and the Employee Stock Purchase Plan (the “ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-18-000029:notes:69]
[same as prior period, unchanged from 0001262039-18-000019:notes:62]

[0001262039-18-000029:notes:70]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 49.3 |  |  | $ | 23.0 |  |  | $ | 90.9 |  |  | $ | 33.7 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 168.6 |  |  | 175.7 |  |  | 168.1 |  |  | 175.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 168.6 |  |  | 175.7 |  |  | 168.1 |  |  | 175.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 3.4 |  |  | 2.4 |  |  | 3.1 |  |  | 2.3 |  |
| Stock options | 1.4 |  |  | 1.5 |  |  | 1.3 |  |  | 1.5 |  |
| ESPP | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 173.5 |  |  | 179.7 |  |  | 172.6 |  |  | 179.0 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.13 |  |  | $ | 0.54 |  |  | $ | 0.19 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.13 |  |  | $ | 0.53 |  |  | $ | 0.19 |  |

[0001262039-18-000029:notes:71]
[same as prior period, unchanged from 0001262039-18-000019:notes:64]

[0001262039-18-000029:notes:72]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| RSUs | 0.3 |  |  | 1.2 |  |  | 0.7 |  |  | 1.8 |  |
| Stock options | 0.7 |  |  | 1.1 |  |  | 0.6 |  |  | 1.1 |  |
| ESPP | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Total | 1.0 |  |  | 2.3 |  |  | 1.4 |  |  | 3.0 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-18-000029:notes:73]
[same as prior period, unchanged from 0001262039-18-000019:notes:66]

[0001262039-18-000029:notes:74]
[same as prior period, unchanged from 0001262039-18-000019:notes:67]

[0001262039-18-000029:notes:75]
|  | June 30, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 258.2 |  |  | $ | (1.1 | ) |  | $ | 61.1 |  |  | $ | (0.7 | ) |  | $ | 319.3 |  |  | $ | (1.8 | ) |
| Commercial paper | 59.0 |  |  | — |  |  | — |  |  | — |  |  | 59.0 |  |  | — |  |
| Certificates of deposit and term deposits | 48.6 |  |  | — |  |  | — |  |  | — |  |  | 48.6 |  |  | — |  |
| U.S. government and agency securities | 10.4 |  |  | — |  |  | 8.5 |  |  | — |  |  | 18.9 |  |  | — |  |
| Total available-for-sale securities | $ | 376.2 |  |  | $ | (1.1 | ) |  | $ | 69.6 |  |  | $ | (0.7 | ) |  | $ | 445.8 |  |  | $ | (1.8 | ) |

[0001262039-18-000029:notes:76]
[same as prior period, unchanged from 0001262039-18-000019:notes:69]

[0001262039-18-000029:notes:77]
[same as prior period, unchanged from 0001262039-18-000019:notes:70]

[0001262039-18-000029:notes:78]
|  | June 30, 2018 |  | December 31, 2017 |
| Due within one year | $ | 461.6 |  |  | $ | 440.3 |  |
| Due within one to three years | 65.3 |  |  | 98.0 |  |
| Total | $ | 526.9 |  |  | $ | 538.3 |  |

[0001262039-18-000029:notes:79]
[same as prior period, unchanged from 0001262039-18-000019:notes:72]

[0001262039-18-000029:notes:80]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2018.

[0001262039-18-000029:notes:81]
[same as prior period, unchanged from 0001262039-18-000019:notes:74]

[0001262039-18-000029:notes:82]
[same as prior period, unchanged from 0001262039-18-000019:notes:75]

[0001262039-18-000029:notes:83]
[same as prior period, unchanged from 0001262039-18-000019:notes:76]

[0001262039-18-000029:notes:84]
[same as prior period, unchanged from 0001262039-18-000019:notes:77]

[0001262039-18-000029:notes:85]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or on model-driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-18-000029:notes:86]
[same as prior period, unchanged from 0001262039-18-000019:notes:79]

[0001262039-18-000029:notes:87]
We classify items within Level 2 if the investments are valued using model-driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-18-000029:notes:88]
[same as prior period, unchanged from 0001262039-18-000019:notes:81]

[0001262039-18-000029:notes:89]
[same as prior period, unchanged from 0001262039-18-000019:notes:82]

[0001262039-18-000029:notes:90]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of June 30, 2018 and December 31, 2017 (in millions):

[0001262039-18-000029:notes:91]
|  | June 30, 2018 |  | December 31, 2017 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 341.2 |  |  | $ | — |  |  | $ | 341.2 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |
| Certificates of deposit and term deposits | 173.9 |  |  | — |  |  | 173.9 |  |  | — |  |  | 132.1 |  |  | — |  |  | 132.1 |  |  | — |  |
| Money market funds | 116.3 |  |  | 116.3 |  |  | — |  |  | — |  |  | 195.6 |  |  | 195.6 |  |  | — |  |  | — |  |
| Commercial paper | 104.4 |  |  | — |  |  | 104.4 |  |  | — |  |  | 128.9 |  |  | — |  |  | 128.9 |  |  | — |  |
| U.S. government and agency securities | 23.0 |  |  | 19.5 |  |  | 3.5 |  |  | — |  |  | 28.4 |  |  | 24.9 |  |  | 3.5 |  |  | — |  |
| Total | $ | 758.8 |  |  | $ | 135.8 |  |  | $ | 623.0 |  |  | $ | — |  |  | $ | 896.1 |  |  | $ | 220.5 |  |  | $ | 675.6 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 231.9 |  |  |  |  |  |  |  |  | $ | 357.8 |  |  |  |  |  |  |  |
| Short-term investments | 461.6 |  |  |  |  |  |  |  |  | 440.3 |  |  |  |  |  |  |  |
| Long-term investments | 65.3 |  |  |  |  |  |  |  |  | 98.0 |  |  |  |  |  |  |  |
| Total | $ | 758.8 |  |  |  |  |  |  |  |  | $ | 896.1 |  |  |  |  |  |  |  |

[0001262039-18-000029:notes:92]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2018 and year ended December 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-18-000029:notes:93]
[same as prior period, unchanged from 0001262039-18-000019:notes:86]

[0001262039-18-000029:notes:94]
[same as prior period, unchanged from 0001262039-18-000019:notes:87]

[0001262039-18-000029:notes:95]
Changes in the carrying value of goodwill were (in millions):

[0001262039-18-000029:notes:96]
|  | Amount |
| Balance—December 31, 2017 | $ | 14.6 |  |
| Addition due to business combination | 10.5 |  |
| Balance—June 30, 2018 | $ | 25.1 |  |

[0001262039-18-000029:notes:97]
There were no impairments to goodwill during the three and six months ended June 30, 2018.

[0001262039-18-000029:notes:98]
[same as prior period, unchanged from 0001262039-18-000019:notes:89]

[0001262039-18-000029:notes:99]
The following tables present other intangible assets—net as of June 30, 2018 and December 31, 2017 (in millions, except years):

[0001262039-18-000029:notes:100]
|  | June 30, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 32.2 |  |  | $ | 16.4 |  |  | $ | 15.8 |  |
| Customer relationships | 4.5 |  | 16.7 |  |  | 11.1 |  |  | 5.6 |  |
| Total other intangible assets—net |  |  | $ | 48.9 |  |  | $ | 27.5 |  |  | $ | 21.4 |  |

[0001262039-18-000029:notes:101]
[same as prior period, unchanged from 0001262039-18-000019:notes:92]

[0001262039-18-000029:notes:102]
[same as prior period, unchanged from 0001262039-18-000019:notes:93]

[0001262039-18-000029:notes:103]
Amortization expense was $1.8 million and $2.2 million during the three months ended June 30, 2018 and June 30, 2017, respectively. Amortization expense was $3.6 million and $4.5 million during the six months ended June 30, 2018 and June 30, 2017, respectively.

[0001262039-18-000029:notes:104]
The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in millions):

[0001262039-18-000029:notes:105]
|  | Amount |
| Years: |  |
| 2018 | $ | 5.1 |  |
| 2019 | 8.4 |  |
| 2020 | 4.8 |  |
| 2021 and thereafter | 3.1 |  |
| Total | $ | 21.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-18-000029:notes:106]
[same as prior period, unchanged from 0001262039-18-000019:notes:96]

[0001262039-18-000029:notes:107]
Our effective tax rate was 4% for the three months ended June 30, 2018, compared to an effective tax rate of 30% for the same period last year. Our effective tax rate was a benefit of 3% for the six months ended June 30, 2018, compared to an effective tax rate of 18% for the same period last year, with the primary difference being the change in the federal corporate income tax rate to 21% in 2018 from 35% in the prior year, the release of reserve for uncertain tax positions including interest due to a statute of limitation expiring and the completion of the Internal Revenue Service (“IRS”) audit.  The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign taxes, excess tax benefits from stock-based compensation and release of a reserve for uncertain tax positions. The tax rates for the three months ended June 30, 2018 and June 30, 2017 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $17.2 million and $14.4 million, respectively, which were offset by a tax provision benefit of $4.9 million and $4.1 million, respectively, for stock-based compensation. The tax rate for the three months ended June 30, 2018 was also impacted by release of a reserve for uncertain tax positions including interest of $10.1 million. The tax rate for the six months ended June 30, 2018 and June 30, 2017 were impacted by withholding taxes and foreign taxes of $25.7 million and $17.3 million, respectively, which were offset by a tax benefit of $10.5 million and $9.6 million, respectively, for stock-based compensation. The tax rate for the six months ended June 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million. Our effective tax rates fluctuate based on the amount of pre-tax income or loss. The impact of discrete items, such as excess tax benefits from stock-based compensation, on our effective tax rate is greater when our pre-tax income is lower.

[0001262039-18-000029:notes:108]
As of June 30, 2018 and December 31, 2017, unrecognized tax benefits were $61.2 million and $72.5 million, respectively. The amount of $59.8 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of June 30, 2018 and December 31, 2017, accrued interest and penalties were $11.1 million and $13.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $7.9 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-18-000029:notes:109]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2008. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We have closed the Internal Revenue Service audit for tax years 2012, 2013 and 2014. In March 2018, we received a refund of $6.8 million for a carry-back claim approved in this audit. The tax authorities in France are examining the intercompany relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. In May 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015. In April 2018, the tax authorities in Israel initiated a tax audit for tax years from 2008 to 2014.

[0001262039-18-000029:notes:110]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. In Altera, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. The Tax Court had invalidated those regulations, in part because the Treasury Department failed to adequately consider significant taxpayer comments when adopting them. The Ninth Court decision reverses the Tax Court’s decision on this issue, holding that the Treasury Department’s rule was not arbitrary and capricious because the Treasury Department provided a sufficient basis for its decision making. We are in the process of evaluating the impact of this court decision which occurred subsequent to the quarter end.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-18-000029:notes:111]
[same as prior period, unchanged from 0001262039-18-000019:notes:100]

[0001262039-18-000029:notes:112]
[same as prior period, unchanged from 0001262039-18-000019:notes:101]

[0001262039-18-000029:notes:113]
|  | June 30, 2018 |  | December 31, 2017 |
| Raw materials | $ | 13.7 |  |  | $ | 13.0 |  |
| Finished goods | 64.5 |  |  | 64.3 |  |
| Inventory | $ | 78.2 |  |  | $ | 77.3 |  |

[0001262039-18-000029:notes:114]
Inventory includes materials at contract manufacturers of $1.9 million and $2.6 million as of June 30, 2018 and December 31, 2017, respectively. Inventory also includes finished goods held by distributors where revenue is recognized on a sell-through basis of $0.1 million as of December 31, 2017.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-18-000029:notes:115]
| Property and Equipment—net | June 30, 2018 |  | December 31, 2017 |
| Americas: |  |  |  |
| United States | $ | 122.9 |  |  | $ | 115.6 |  |
| Canada | 106.1 |  |  | 103.8 |  |
| LATAM | 0.5 |  |  | 0.3 |  |
| Total Americas | 229.5 |  |  | 219.7 |  |
| EMEA: |  |  |  |
| France | 12.8 |  |  | 11.9 |  |
| Other EMEA | 4.7 |  |  | 5.8 |  |
| Total EMEA | 17.5 |  |  | 17.7 |  |
| APAC | 9.0 |  |  | 8.0 |  |
| Total property and equipment—net | $ | 256.0 |  |  | $ | 245.4 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-18-000029:notes:116]
Recently Adopted Accounting Standards

[0001262039-18-000029:notes:117]
Financial Instruments – Recognition and Measurement

[0001262039-18-000029:notes:118]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

[0001262039-18-000029:notes:119]
Revenue Recognition

[0001262039-18-000029:notes:120]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted ASU 2014-09 and its related amendments (collectively known as Topic 606) as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

[0001262039-18-000029:notes:121]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

[0001262039-18-000029:notes:122]
The cumulative effects of the changes made to our January 1, 2018 consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

[0001262039-18-000029:notes:123]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | $ | 77.3 |  |  | $ | (0.1 | ) |  | $ | 77.2 |  |
| Deferred tax assets | $ | 146.9 |  |  | $ | (18.0 | ) |  | $ | 128.9 |  |
| Deferred contract costs | $ | — |  |  | $ | 137.1 |  |  | $ | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 50.0 |  |  | $ | 13.6 |  |  | $ | 63.6 |  |
| Deferred revenue, current | $ | 793.8 |  |  | $ | 0.3 |  |  | $ | 794.1 |  |
| Deferred revenue, non-current | $ | 542.5 |  |  | $ | (4.4 | ) |  | $ | 538.1 |  |
| Other liabilities, non-current | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

[0001262039-18-000029:notes:124]
Recent Accounting Standards Not Yet Effective

[0001262039-18-000029:notes:125]
Leases

[0001262039-18-000029:notes:126]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of ASC 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

[0001262039-18-000029:notes:127]
Stock Compensation

[0001262039-18-000029:notes:128]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of Accounting Standards Codification Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of this new standards on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-18-000029:notes:129]
[same as prior period, unchanged from 0001262039-18-000019:notes:116]

[0001262039-18-000029:notes:130]
[same as prior period, unchanged from 0001262039-18-000019:notes:117]

[0001262039-18-000029:notes:131]
|  | June 30, 2018 |  | December 31, 2017 |
| Building and building improvements | $ | 136.1 |  |  | $ | 133.2 |  |
| Computer equipment and software | 90.5 |  |  | 79.9 |  |
| Land | 71.9 |  |  | 65.6 |  |
| Leasehold improvements | 21.9 |  |  | 20.8 |  |
| Evaluation units | 19.5 |  |  | 20.1 |  |
| Furniture and fixtures | 15.9 |  |  | 14.7 |  |
| Construction-in-progress | 7.7 |  |  | 6.3 |  |
| Total property and equipment | 363.5 |  |  | 340.6 |  |
| Less: accumulated depreciation | (107.5 | ) |  | (95.2 | ) |
| Property and equipment—net | $ | 256.0 |  |  | $ | 245.4 |  |

[0001262039-18-000029:notes:132]
Depreciation expense was $11.8 million during the three months ended June 30, 2018 and June 30, 2017. Depreciation expense was $23.1 million and $23.0 million during the six months ended June 30, 2018 and June 30, 2017, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-18-000029:notes:133]
[same as prior period, unchanged from 0001262039-18-000019:notes:120]

[0001262039-18-000029:notes:134]
[same as prior period, unchanged from 0001262039-18-000019:notes:121]

[0001262039-18-000029:notes:135]
[same as prior period, unchanged from 0001262039-18-000019:notes:122]

[0001262039-18-000029:notes:136]
[same as prior period, unchanged from 0001262039-18-000019:notes:123]

[0001262039-18-000029:notes:137]
[same as prior period, unchanged from 0001262039-18-000019:notes:124]

[0001262039-18-000029:notes:138]
[same as prior period, unchanged from 0001262039-18-000019:notes:125]

[0001262039-18-000029:notes:139]
| • | identification of the performance obligations in the contract, including evaluation of performance obligations as to being distinct goods or services in a contract, |

[0001262039-18-000029:notes:140]
[same as prior period, unchanged from 0001262039-18-000019:notes:127]

[0001262039-18-000029:notes:141]
[same as prior period, unchanged from 0001262039-18-000019:notes:128]

[0001262039-18-000029:notes:142]
[same as prior period, unchanged from 0001262039-18-000019:notes:129]

[0001262039-18-000029:notes:143]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a substantial majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

[0001262039-18-000029:notes:144]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously, time-based software licenses were recognized over the license term.

[0001262039-18-000029:notes:145]
[same as prior period, unchanged from 0001262039-18-000019:notes:131]

[0001262039-18-000029:notes:146]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-18-000029:notes:147]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

[0001262039-18-000029:notes:148]
Under Topic 605, revenue from contracts that contain our products and services are allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-18-000029:notes:149]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.5 million as of June 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

[0001262039-18-000029:notes:150]
[same as prior period, unchanged from 0001262039-18-000019:notes:136]

[0001262039-18-000029:notes:151]
During the three and six months ended June 30, 2018, we recognized $203.3 million and $442.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.

[0001262039-18-000029:notes:152]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and six months ended June 30, 2018 and 2017.

[0001262039-18-000029:notes:153]
[same as prior period, unchanged from 0001262039-18-000019:notes:139]

[0001262039-18-000029:notes:154]
As of June 30, 2018, we had $1.47 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

[0001262039-18-000029:notes:155]
[same as prior period, unchanged from 0001262039-18-000019:notes:141]

[0001262039-18-000029:notes:156]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of June 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

[0001262039-18-000029:notes:157]
[same as prior period, unchanged from 0001262039-18-000019:notes:143]

[0001262039-18-000029:notes:158]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of June 30, 2018 and January 1, 2018.

[0001262039-18-000029:notes:159]
[same as prior period, unchanged from 0001262039-18-000019:notes:145]

[0001262039-18-000029:notes:160]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and six months ended June 30, 2018 was $22.4 million and $43.2 million, respectively. No impairment loss was recognized during the three months ended June 30, 2018.

[0001262039-18-000029:notes:161]
[same as prior period, unchanged from 0001262039-18-000019:notes:147]

[0001262039-18-000029:notes:162]
[same as prior period, unchanged from 0001262039-18-000019:notes:148]

[0001262039-18-000029:notes:163]
[same as prior period, unchanged from 0001262039-18-000019:notes:149]

[0001262039-18-000029:notes:164]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and six months ended June 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

[0001262039-18-000029:notes:165]
[same as prior period, unchanged from 0001262039-18-000019:notes:151]

[0001262039-18-000029:notes:166]
|  | As of June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 333.6 |  |  | $ | 321.1 |  |  | $ | 12.5 |  |
| Inventory | $ | 78.2 |  |  | $ | 79.6 |  |  | $ | (1.4 | ) |
| Deferred contract costs | $ | 160.6 |  |  | $ | — |  |  | $ | 160.6 |  |
| Deferred tax assets | $ | 141.9 |  |  | $ | 167.8 |  |  | $ | (25.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 59.0 |  |  | $ | 44.7 |  |  | $ | 14.3 |  |
| Deferred revenue, current | $ | 849.5 |  |  | $ | 865.9 |  |  | $ | (16.4 | ) |
| Deferred revenue, non-current | $ | 621.3 |  |  | $ | 622.5 |  |  | $ | (1.2 | ) |
| Other liabilities, non-current | $ | 12.2 |  |  | $ | 6.4 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (214.7 | ) |  | $ | (358.0 | ) |  | $ | 143.3 |  |

[0001262039-18-000029:notes:167]
[same as prior period, unchanged from 0001262039-18-000019:notes:153]

[0001262039-18-000029:notes:168]
|  | Three Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 162.1 |  |  | $ | 4.2 |  |
| Service | 275.0 |  |  | 274.0 |  |  | 1.0 |  |
| Total revenue | 441.3 |  |  | 436.1 |  |  | 5.2 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 73.9 |  |  | 74.1 |  |  | (0.2 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.4 |  |  | 88.0 |  |  | 4.4 |  |
| Service | 235.8 |  |  | 234.8 |  |  | 1.0 |  |
| Total gross profit | 328.2 |  |  | 322.8 |  |  | 5.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 192.8 |  |  | 204.6 |  |  | (11.8 | ) |
| OPERATING INCOME | 50.7 |  |  | 33.5 |  |  | 17.2 |  |
| INCOME BEFORE INCOME TAXES | 51.5 |  |  | 34.3 |  |  | 17.2 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.2 |  |  | (1.8 | ) |  | 4.0 |  |
| NET INCOME | $ | 49.3 |  |  | $ | 36.1 |  |  | $ | 13.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |

[0001262039-18-000029:notes:169]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 309.1 |  |  | $ | 299.2 |  |  | $ | 9.9 |  |
| Service | 531.2 |  |  | 529.5 |  |  | 1.7 |  |
| Total revenue | 840.3 |  |  | 828.7 |  |  | 11.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 132.1 |  |  | 130.8 |  |  | 1.3 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 177.0 |  |  | 168.4 |  |  | 8.6 |  |
| Service | 453.0 |  |  | 451.3 |  |  | 1.7 |  |
| Total gross profit | 630.0 |  |  | 619.7 |  |  | 10.3 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 378.1 |  |  | 401.6 |  |  | (23.5 | ) |
| OPERATING INCOME | 83.1 |  |  | 49.3 |  |  | 33.8 |  |
| INCOME BEFORE INCOME TAXES | 88.2 |  |  | 54.4 |  |  | 33.8 |  |
| BENEFIT FROM INCOME TAXES | (2.7 | ) |  | (10.5 | ) |  | 7.8 |  |
| NET INCOME | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.54 |  |  | $ | 0.39 |  |  | $ | 0.15 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.38 |  |  | $ | 0.15 |  |

[0001262039-18-000029:notes:170]
[same as prior period, unchanged from 0001262039-18-000019:notes:155]

[0001262039-18-000029:notes:171]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 43.2 |  |  | — |  |  | 43.2 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (10.8 | ) |  | (12.2 | ) |  | 1.4 |  |
| Deferred contract costs | (66.7 | ) |  | — |  |  | (66.7 | ) |
| Deferred tax assets | (13.3 | ) |  | (21.1 | ) |  | 7.8 |  |
| Accrued liabilities | (4.7 | ) |  | (5.4 | ) |  | 0.7 |  |
| Deferred revenue | 136.3 |  |  | 148.7 |  |  | (12.4 | ) |
| Net cash provided by operating activities | $ | 282.0 |  |  | $ | 282.0 |  |  | $ | — |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-18-000029:notes:172]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 144.6 |  |  | $ | 126.4 |  |  | $ | 278.5 |  |  | $ | 242.4 |  |
| Latin America (“LATAM”) | 28.7 |  |  | 22.0 |  |  | 55.2 |  |  | 40.2 |  |
| Canada | 16.0 |  |  | 12.3 |  |  | 31.4 |  |  | 24.5 |  |
| Total Americas | 189.3 |  |  | 160.7 |  |  | 365.1 |  |  | 307.1 |  |
| Europe, Middle East and Africa (“EMEA”) | 164.4 |  |  | 129.8 |  |  | 308.9 |  |  | 255.8 |  |
| Asia Pacific (“APAC”) | 87.6 |  |  | 73.0 |  |  | 166.3 |  |  | 141.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001262039-18-000029:notes:173]
[same as prior period, unchanged from 0001262039-18-000019:notes:158]


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001262039-18-000029:notes:174]
[same as prior period, unchanged from 0001262039-18-000019:notes:159]

[0001262039-18-000029:notes:175]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 (1) |  | June 30, 2017 |  | June 30, 2018(1) |  | June 30, 2017 |
| Exclusive Networks Group | 29 | % |  | 20 | % |  | 29 | % |  | 20 | % |
| Ingram Micro | 10 | % |  | 10 | % |  | * |  |  | * |  |
| Fine Tec Computers | * |  |  | 12 | % |  | * |  |  | 12 | % |
| * Represents less than 10% |
| (1) Due to the acquisition by Exclusive Networks Group of the U.S. division of Fine Tec Computers (“Fine Tec U.S.”) in July 2017, Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive Networks Group. |

[0001262039-18-000029:notes:176]
[same as prior period, unchanged from 0001262039-18-000019:notes:161]

[0001262039-18-000029:notes:177]
|  | June 30, 2018 |  | December 31, 2017 |
| Exclusive Networks Group | 32 | % |  | 35 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-18-000029:notes:178]
[same as prior period, unchanged from 0001262039-18-000019:notes:163]

[0001262039-18-000029:notes:179]
[same as prior period, unchanged from 0001262039-18-000019:notes:164]

[0001262039-18-000029:notes:180]
[same as prior period, unchanged from 0001262039-18-000019:notes:165]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-18-000029:notes:181]
[same as prior period, unchanged from 0001262039-18-000019:notes:166]


## us-gaap:SubsequentEventsTextBlock

[0001262039-18-000029:notes:182]
SUBSEQUENT EVENT

[0001262039-18-000029:notes:183]
Share Repurchase

[0001262039-18-000029:notes:184]
In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019.
