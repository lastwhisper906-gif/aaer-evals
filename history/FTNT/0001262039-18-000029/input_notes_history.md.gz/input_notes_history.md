# FTNT note change history — 0001262039-18-000019 → 0001262039-18-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-07):
[0001262039-18-000029:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2018 (in millions):
  (was, 2018-05-08, similarity 0.9573):
[0001262039-18-000019:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2018 (in millions):

- changed (2018-08-07):
[0001262039-18-000029:note_history:2]
|  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 53.2 |  |  | $ | 8.9 |  |  | $ | 14.5 |  |  | $ | 11.2 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |
| Inventory purchase commitments | 104.9 |  |  | 100.7 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 158.1 |  |  | $ | 109.6 |  |  | $ | 14.5 |  |  | $ | 15.4 |  |  | $ | 7.2 |  |  | $ | 4.3 |  |  | $ | 7.1 |  |
  (was, 2018-05-08, similarity 0.9832):
[0001262039-18-000019:note_history:2]
|  | Total |  | 2018 (remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Operating lease commitments | $ | 55.4 |  |  | $ | 12.6 |  |  | $ | 13.9 |  |  | $ | 10.7 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |
| Inventory purchase commitments | 106.1 |  |  | 101.9 |  |  | — |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 161.5 |  |  | $ | 114.5 |  |  | $ | 13.9 |  |  | $ | 14.9 |  |  | $ | 6.8 |  |  | $ | 4.2 |  |  | $ | 7.2 |  |

- changed (2018-08-07):
[0001262039-18-000029:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.9 million during the three months ended June 30, 2018 and June 30, 2017, respectively. Rent expense was $8.7 million and $8.4 million during the six months ended June 30, 2018 and June 30, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2018-05-08, similarity 0.7443):
[0001262039-18-000019:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.1 million and $4.5 million during the three months ended March 31, 2018 and March 31, 2017, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2018-08-07):
[0001262039-18-000029:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2018, we had $104.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2018-05-08, similarity 0.9933):
[0001262039-18-000019:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2018, we had $106.1 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2018-08-07):
[0001262039-18-000029:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2018, we had $9.5 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2018-05-08, similarity 0.9885):
[0001262039-18-000019:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2018, we had $10.0 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2018-08-07):
[0001262039-18-000029:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and there can be no assurances and the outcome of these matters is currently not determinable. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.
  (was, 2018-05-08, similarity 0.8779):
[0001262039-18-000019:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- added (2018-08-07):
[0001262039-18-000029:note_history:7]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act.  We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.  We are currently in settlement discussions with the United States Attorney’s Office.

- changed (2018-08-07):
[0001262039-18-000029:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.
  (was, 2018-05-08, similarity 0.9377):
[0001262039-18-000019:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.

- removed (2018-08-07):
[0001262039-18-000019:note_history:9]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-08-07):
[0001262039-18-000029:note_history:10]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018 (the “Form 10-K”). In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

- changed (2018-08-07):
[0001262039-18-000029:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.
  (was, 2018-05-08, similarity 0.8167):
[0001262039-18-000019:note_history:11]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (“ASU 2014-09”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 2.

- added (2018-08-07):
[0001262039-18-000029:note_history:12]
In January 2016, the Financial Accounting Standard Board (“FASB”) issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

- changed (2018-08-07):
[0001262039-18-000029:note_history:13]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.
  (was, 2018-05-08, similarity 0.9979):
[0001262039-18-000019:note_history:13]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but will capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The capitalized sales commissions for initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts. The deferral of sales commissions generated deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See Note 2 for further details.

- added (2018-08-07):
[0001262039-18-000029:note_history:14]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11 Leases (Topic 842) Targeted Improvements, which address questions about how to apply certain aspects of ASC 2016-02. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASC 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASC 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.

- added (2018-08-07):
[0001262039-18-000029:note_history:15]
Stock Compensation

- added (2018-08-07):
[0001262039-18-000029:note_history:16]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASC 2018-07 expands the scope of Accounting Standards Codification Topic 718, Compensation-Stock Compensation (“ASC 718”) to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505-50 by moving it to ASC 718. This amendment is effective for us beginning January 1, 2019. Early adoption is permitted, but no earlier than an entity’s adoption date of ASC 606. We are currently evaluating the impact of this new standards on our consolidated financial statements.

- removed (2018-08-07):
[0001262039-18-000019:note_history:17]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2017, contained in our Annual Report on Form 10-K filed with the SEC on February 26, 2018. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2018 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2017 is derived from the audited consolidated financial statements for the year ended December 31, 2017.

- removed (2018-08-07):
[0001262039-18-000019:note_history:18]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our condensed consolidated financial statements as of the adoption date.

- removed (2018-08-07):
[0001262039-18-000019:note_history:19]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. ASU 2016-02 will be effective for us beginning on January 1, 2019, using a modified retrospective approach. Based on our current lease portfolio, we currently estimate the value of leased assets and liabilities that may be recognized on the consolidated balance sheet to be at least $45.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations and cash flows. We expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-07):
[0001262039-18-000029:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 (1) |  | June 30, 2018 |  | June 30, 2017(1) |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 147.1 |  |  | 122.0 |  |  | 283.8 |  |  | 235.5 |  |
| Technical support | 116.4 |  |  | 90.1 |  |  | 226.0 |  |  | 171.2 |  |
| Professional services and training | 11.5 |  |  | 8.7 |  |  | 21.4 |  |  | 19.4 |  |
| Total service revenue | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- removed (2018-08-07):
[0001262039-18-000019:note_history:21]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 (1) |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service: |  |  |  |
| Security subscription | 136.6 |  |  | 113.5 |  |
| Technical support | 109.6 |  |  | 81.1 |  |
| Professional services and training | 10.0 |  |  | 10.7 |  |
| Total service revenue | 256.2 |  |  | 205.3 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-07):
[0001262039-18-000029:note_history:22]
| • | identification of the performance obligations in the contract, including evaluation of performance obligations as to being distinct goods or services in a contract, |

- added (2018-08-07):
[0001262039-18-000029:note_history:23]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a substantial majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- changed (2018-08-07):
[0001262039-18-000029:note_history:24]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously, time-based software licenses were recognized over the license term.
  (was, 2018-05-08, similarity 0.8856):
[0001262039-18-000019:note_history:24]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate, FortiSandbox, FortiManager, FortiAnalyzer and other complimentary products. We derive a substantial majority of product sales from our FortiGate products. We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously time-based software licenses were recognized over the license term.

- added (2018-08-07):
[0001262039-18-000029:note_history:25]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- changed (2018-08-07):
[0001262039-18-000029:note_history:26]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.
  (was, 2018-05-08, similarity 0.6081):
[0001262039-18-000019:note_history:26]
Our sales arrangements typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales taxes.

- changed (2018-08-07):
[0001262039-18-000029:note_history:27]
Under Topic 605, revenue from contracts that contain our products and services are allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.
  (was, 2018-05-08, similarity 0.9285):
[0001262039-18-000019:note_history:27]
Under Topic 605, our products and services in a multiple-element arrangement generally qualified as separate units of accounting. We allocated revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- changed (2018-08-07):
[0001262039-18-000029:note_history:28]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.5 million as of June 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.
  (was, 2018-05-08, similarity 0.9958):
[0001262039-18-000019:note_history:28]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.9 million as of March 31, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- changed (2018-08-07):
[0001262039-18-000029:note_history:29]
During the three and six months ended June 30, 2018, we recognized $203.3 million and $442.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.
  (was, 2018-05-08, similarity 0.8554):
[0001262039-18-000019:note_history:29]
During the three months ended March 31, 2018, we recognized $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2017.

- changed (2018-08-07):
[0001262039-18-000029:note_history:30]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and six months ended June 30, 2018 and 2017.
  (was, 2018-05-08, similarity 0.9732):
[0001262039-18-000019:note_history:30]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three months ended March 31, 2018 and 2017.

- added (2018-08-07):
[0001262039-18-000029:note_history:31]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 (1) |  | June 30, 2018 |  | June 30, 2017(1) |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 147.1 |  |  | 122.0 |  |  | 283.8 |  |  | 235.5 |  |
| Technical support | 116.4 |  |  | 90.1 |  |  | 226.0 |  |  | 171.2 |  |
| Professional services and training | 11.5 |  |  | 8.7 |  |  | 21.4 |  |  | 19.4 |  |
| Total service revenue | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |  | $ | 840.3 |  |  | $ | 704.0 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |

- changed (2018-08-07):
[0001262039-18-000029:note_history:32]
As of June 30, 2018, we had $1.47 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.
  (was, 2018-05-08, similarity 0.9882):
[0001262039-18-000019:note_history:32]
As of March 31, 2018, we had $1.40 billion in remaining performance obligations, which is substantially comprised of deferred security subscription and technical support services not yet delivered. We expect to recognize revenue on approximately 75% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- changed (2018-08-07):
[0001262039-18-000029:note_history:33]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of June 30, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.
  (was, 2018-05-08, similarity 0.9917):
[0001262039-18-000019:note_history:33]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.7 million and $0.9 million as of March 31, 2018 and December 31, 2017, respectively. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

- changed (2018-08-07):
[0001262039-18-000029:note_history:34]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. Contract assets were insignificant as of June 30, 2018 and January 1, 2018.
  (was, 2018-05-08, similarity 0.771):
[0001262039-18-000019:note_history:34]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. We did not have contract assets as of March 31, 2018 and January 1, 2018.

- changed (2018-08-07):
[0001262039-18-000029:note_history:35]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three and six months ended June 30, 2018 was $22.4 million and $43.2 million, respectively. No impairment loss was recognized during the three months ended June 30, 2018.
  (was, 2018-05-08, similarity 0.8913):
[0001262039-18-000019:note_history:35]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred commissions is included in sales and marketing expense in our condensed consolidated statement of operations. Amortization of deferred contract costs during the three months ended March 31, 2018 was $20.8 million. No impairment loss was recognized during the three months ended March 31, 2018.

- changed (2018-08-07):
[0001262039-18-000029:note_history:36]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three and six months ended June 30, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.
  (was, 2018-05-08, similarity 0.9349):
[0001262039-18-000019:note_history:36]
The following tables summarize the impact of adopting Topic 606 on our condensed consolidated financial statements as of and for the three months ended March 31, 2018 (in millions). These tables do not represent the full condensed consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

- changed (2018-08-07):
[0001262039-18-000029:note_history:37]
|  | As of June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 333.6 |  |  | $ | 321.1 |  |  | $ | 12.5 |  |
| Inventory | $ | 78.2 |  |  | $ | 79.6 |  |  | $ | (1.4 | ) |
| Deferred contract costs | $ | 160.6 |  |  | $ | — |  |  | $ | 160.6 |  |
| Deferred tax assets | $ | 141.9 |  |  | $ | 167.8 |  |  | $ | (25.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 59.0 |  |  | $ | 44.7 |  |  | $ | 14.3 |  |
| Deferred revenue, current | $ | 849.5 |  |  | $ | 865.9 |  |  | $ | (16.4 | ) |
| Deferred revenue, non-current | $ | 621.3 |  |  | $ | 622.5 |  |  | $ | (1.2 | ) |
| Other liabilities, non-current | $ | 12.2 |  |  | $ | 6.4 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (214.7 | ) |  | $ | (358.0 | ) |  | $ | 143.3 |  |
  (was, 2018-05-08, similarity 0.9941):
[0001262039-18-000019:note_history:37]
|  | As of March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 313.1 |  |  | $ | 300.2 |  |  | $ | 12.9 |  |
| Inventory | $ | 80.0 |  |  | $ | 81.5 |  |  | $ | (1.5 | ) |
| Deferred contract costs | $ | 148.7 |  |  | $ | — |  |  | $ | 148.7 |  |
| Deferred tax assets | $ | 138.7 |  |  | $ | 160.6 |  |  | $ | (21.9 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | 55.6 |  |  | $ | 40.6 |  |  | $ | 15.0 |  |
| Deferred revenue, current | $ | 817.1 |  |  | $ | 828.8 |  |  | $ | (11.7 | ) |
| Deferred revenue, non-current | $ | 579.3 |  |  | $ | 580.2 |  |  | $ | (0.9 | ) |
| Other liabilities, non-current | $ | 13.4 |  |  | $ | 7.6 |  |  | $ | 5.8 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (262.6 | ) |  | $ | (392.6 | ) |  | $ | 130.0 |  |

- changed (2018-08-07):
[0001262039-18-000029:note_history:38]
|  | Three Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 162.1 |  |  | $ | 4.2 |  |
| Service | 275.0 |  |  | 274.0 |  |  | 1.0 |  |
| Total revenue | 441.3 |  |  | 436.1 |  |  | 5.2 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 73.9 |  |  | 74.1 |  |  | (0.2 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.4 |  |  | 88.0 |  |  | 4.4 |  |
| Service | 235.8 |  |  | 234.8 |  |  | 1.0 |  |
| Total gross profit | 328.2 |  |  | 322.8 |  |  | 5.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 192.8 |  |  | 204.6 |  |  | (11.8 | ) |
| OPERATING INCOME | 50.7 |  |  | 33.5 |  |  | 17.2 |  |
| INCOME BEFORE INCOME TAXES | 51.5 |  |  | 34.3 |  |  | 17.2 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.2 |  |  | (1.8 | ) |  | 4.0 |  |
| NET INCOME | $ | 49.3 |  |  | $ | 36.1 |  |  | $ | 13.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |
  (was, 2018-05-08, similarity 0.6089):
[0001262039-18-000019:note_history:38]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 142.8 |  |  | $ | 137.1 |  |  | $ | 5.7 |  |
| Service | 256.2 |  |  | 255.5 |  |  | 0.7 |  |
| Total revenue | 399.0 |  |  | 392.6 |  |  | 6.4 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 58.2 |  |  | 56.7 |  |  | 1.5 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 84.6 |  |  | 80.4 |  |  | 4.2 |  |
| Service | 217.2 |  |  | 216.5 |  |  | 0.7 |  |
| Total gross profit | 301.8 |  |  | 296.9 |  |  | 4.9 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 185.3 |  |  | 197.0 |  |  | (11.7 | ) |
| OPERATING INCOME | 32.4 |  |  | 15.8 |  |  | 16.6 |  |
| INCOME BEFORE INCOME TAXES | 36.7 |  |  | 20.1 |  |  | 16.6 |  |
| BENEFIT FROM INCOME TAXES | (4.9 | ) |  | (8.7 | ) |  | 3.8 |  |
| NET INCOME | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.25 |  |  | $ | 0.17 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.07 |  |

- added (2018-08-07):
[0001262039-18-000029:note_history:39]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 309.1 |  |  | $ | 299.2 |  |  | $ | 9.9 |  |
| Service | 531.2 |  |  | 529.5 |  |  | 1.7 |  |
| Total revenue | 840.3 |  |  | 828.7 |  |  | 11.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 132.1 |  |  | 130.8 |  |  | 1.3 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 177.0 |  |  | 168.4 |  |  | 8.6 |  |
| Service | 453.0 |  |  | 451.3 |  |  | 1.7 |  |
| Total gross profit | 630.0 |  |  | 619.7 |  |  | 10.3 |  |
| OPERATING EXPENSES |  |  |  |  |  |
| Sales and marketing expenses | 378.1 |  |  | 401.6 |  |  | (23.5 | ) |
| OPERATING INCOME | 83.1 |  |  | 49.3 |  |  | 33.8 |  |
| INCOME BEFORE INCOME TAXES | 88.2 |  |  | 54.4 |  |  | 33.8 |  |
| BENEFIT FROM INCOME TAXES | (2.7 | ) |  | (10.5 | ) |  | 7.8 |  |
| NET INCOME | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.54 |  |  | $ | 0.39 |  |  | $ | 0.15 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.38 |  |  | $ | 0.15 |  |

- changed (2018-08-07):
[0001262039-18-000029:note_history:40]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 43.2 |  |  | — |  |  | 43.2 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (10.8 | ) |  | (12.2 | ) |  | 1.4 |  |
| Deferred contract costs | (66.7 | ) |  | — |  |  | (66.7 | ) |
| Deferred tax assets | (13.3 | ) |  | (21.1 | ) |  | 7.8 |  |
| Accrued liabilities | (4.7 | ) |  | (5.4 | ) |  | 0.7 |  |
| Deferred revenue | 136.3 |  |  | 148.7 |  |  | (12.4 | ) |
| Net cash provided by operating activities | $ | 282.0 |  |  | $ | 282.0 |  |  | $ | — |  |
  (was, 2018-05-08, similarity 0.7002):
[0001262039-18-000019:note_history:40]
|  | Three Months Ended March 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 41.6 |  |  | $ | 28.8 |  |  | $ | 12.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 20.8 |  |  | — |  |  | 20.8 |  |
| Other non-cash | 0.3 |  |  | 0.9 |  |  | (0.6 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Inventory | (7.3 | ) |  | (8.7 | ) |  | 1.4 |  |
| Deferred contract costs | (32.5 | ) |  | — |  |  | (32.5 | ) |
| Deferred tax assets | (9.6 | ) |  | (13.6 | ) |  | 4.0 |  |
| Accrued liabilities | (4.7 | ) |  | (6.1 | ) |  | 1.4 |  |
| Deferred revenue | 64.1 |  |  | 71.4 |  |  | (7.3 | ) |
| Net cash provided by operating activities | $ | 139.7 |  |  | $ | 139.7 |  |  | $ | — |  |

- removed (2018-08-07):
[0001262039-18-000019:note_history:41]
•identification of the performance obligations in the contract,

- removed (2018-08-07):
[0001262039-18-000019:note_history:42]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these arrangements ratably over the contractual service period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. Our revenue recognition for other services did not change under Topic 606. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- removed (2018-08-07):
[0001262039-18-000019:note_history:43]
|  | Three Months Ended |
|  | March 31, 2018 |  | March 31, 2017 (1) |
| Product | $ | 142.8 |  |  | $ | 135.3 |  |
| Service: |  |  |  |
| Security subscription | 136.6 |  |  | 113.5 |  |
| Technical support | 109.6 |  |  | 81.1 |  |
| Professional services and training | 10.0 |  |  | 10.7 |  |
| Total service revenue | 256.2 |  |  | 205.3 |  |
| Total revenue | $ | 399.0 |  |  | $ | 340.6 |  |
| (1) As noted above, prior period amounts have not been adjusted under the modified retrospective method. |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-07):
[0001262039-18-000029:note_history:44]
| • | identification of the performance obligations in the contract, including evaluation of performance obligations as to being distinct goods or services in a contract, |

- added (2018-08-07):
[0001262039-18-000029:note_history:45]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate and Fabric products. We derive a substantial majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

- changed (2018-08-07):
[0001262039-18-000029:note_history:46]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously, time-based software licenses were recognized over the license term.
  (was, 2018-05-08, similarity 0.8856):
[0001262039-18-000019:note_history:46]
Product revenue primarily consists of sales of hardware and software licenses of our FortiGate, FortiSandbox, FortiManager, FortiAnalyzer and other complimentary products. We derive a substantial majority of product sales from our FortiGate products. We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. For sales that included end-customer acceptance criteria, revenue was recognized upon acceptance. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from time-based software licenses upon electronic transfer of the license key to the customer. Previously time-based software licenses were recognized over the license term.

- added (2018-08-07):
[0001262039-18-000029:note_history:47]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our application control, intrusion prevention, anti-botnet and mobile, anti-spam, web filtering, cloud sandbox and virus outbreak protection, industry security, security rating service and threat intelligent service functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the maintenance period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

- changed (2018-08-07):
[0001262039-18-000029:note_history:48]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.
  (was, 2018-05-08, similarity 0.6081):
[0001262039-18-000019:note_history:48]
Our sales arrangements typically contain multiple performance obligations, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales taxes.

- changed (2018-08-07):
[0001262039-18-000029:note_history:49]
Under Topic 605, revenue from contracts that contain our products and services are allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.
  (was, 2018-05-08, similarity 0.9285):
[0001262039-18-000019:note_history:49]
Under Topic 605, our products and services in a multiple-element arrangement generally qualified as separate units of accounting. We allocated revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

- changed (2018-08-07):
[0001262039-18-000029:note_history:50]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.5 million as of June 30, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.
  (was, 2018-05-08, similarity 0.9958):
[0001262039-18-000019:note_history:50]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs.  Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $12.9 million as of March 31, 2018 and is included in current liabilities in our condensed consolidated balance sheet. Under Topic 605, a sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

- changed (2018-08-07):
[0001262039-18-000029:note_history:51]
During the three and six months ended June 30, 2018, we recognized $203.3 million and $442.3 million, respectively, in revenue that was included in the deferred revenue balance as of December 31, 2017.
  (was, 2018-05-08, similarity 0.8554):
[0001262039-18-000019:note_history:51]
During the three months ended March 31, 2018, we recognized $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2017.

- changed (2018-08-07):
[0001262039-18-000029:note_history:52]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three and six months ended June 30, 2018 and 2017.
  (was, 2018-05-08, similarity 0.9732):
[0001262039-18-000019:note_history:52]
Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale. Shipping and handling fees recognized as product revenue were not significant during the three months ended March 31, 2018 and 2017.

- removed (2018-08-07):
[0001262039-18-000019:note_history:53]
•identification of the performance obligations in the contract,

- removed (2018-08-07):
[0001262039-18-000019:note_history:54]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services, and other services. Our FortiGuard security subscription services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Our FortiCare support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and internet access to technical support personnel. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not change under Topic 606. We continue to recognize revenue from these arrangements ratably over the contractual service period because of continuous transfer of control to the customer. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. Our revenue recognition for other services did not change under Topic 606. To date, SaaS revenue has not represented a significant percentage of our total revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-08-07):
[0001262039-18-000029:note_history:55]
SUBSEQUENT EVENT

- added (2018-08-07):
[0001262039-18-000029:note_history:56]
Share Repurchase

- added (2018-08-07):
[0001262039-18-000029:note_history:57]
In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase Program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019.
