# FTNT 8-K — 0001262039-18-000025 filed 2018-08-01

## item codes, every 8-K on or before 2018-08-07

- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2018-08-07

- none on or before 2018-08-07

## item 2.02 — earnings release, exhibit 99.1

[0001262039-18-000025:8k_2_02:1]
EX-99.1
2
ftntq2-2018ex991.htm
PRESS RELEASE

[0001262039-18-000025:8k_2_02:2]
Exhibit

[0001262039-18-000025:8k_2_02:3]
Press Release

[0001262039-18-000025:8k_2_02:4]
Fortinet Reports Second Quarter 2018 Financial Results

[0001262039-18-000025:8k_2_02:5]
Fortinet Reports Revenue Growth of 21%, Billings Growth of 20% and Deferred Revenue Growth of 27% Year over Year

[0001262039-18-000025:8k_2_02:6]
Recent Highlights

[0001262039-18-000025:8k_2_02:7]
| • | Revenue of $441.3 million, up 21% year over year |

[0001262039-18-000025:8k_2_02:8]
| • | Product revenue of $166.3 million, up 17% year over year |

[0001262039-18-000025:8k_2_02:9]
| • | Service revenue of $275.0 million, up 25% year over year |

[0001262039-18-000025:8k_2_02:10]
| • | Billings of $513.4 million, up 20% year over year1 |

[0001262039-18-000025:8k_2_02:11]
| • | Deferred revenue of $1.47 billion, up 27% year over year |

[0001262039-18-000025:8k_2_02:12]
| • | GAAP diluted net income per share of $0.28 |

[0001262039-18-000025:8k_2_02:13]
| • | Non-GAAP diluted net income per share of $0.411 |

[0001262039-18-000025:8k_2_02:14]
| • | Cash flow from operations of $142.2 million |

[0001262039-18-000025:8k_2_02:15]
| • | Free cash flow of $130.6 million1 |

[0001262039-18-000025:8k_2_02:16]
| • | Cash, cash equivalents and investments of $1.5 billion |

[0001262039-18-000025:8k_2_02:17]
| • | In July 2018, the Board increased share repurchase authorization by $500.0 million |

[0001262039-18-000025:8k_2_02:18]
SUNNYVALE, Calif. - August 1, 2018 - Fortinet® (NASDAQ: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the second quarter ended June 30, 2018.

[0001262039-18-000025:8k_2_02:19]
“We delivered strong second quarter revenue and billings growth. Our market share gains are being driven by the competitive advantages of our Security Fabric architecture,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “We remain focused on solving customers’ pressing security needs and helping them drive their digital transformation. We are very excited about the sizable opportunities that lie ahead. Fortinet is in a position to empower our customers with the latest evolution in network security.”

[0001262039-18-000025:8k_2_02:20]
Recent Highlights

[0001262039-18-000025:8k_2_02:21]
| • | Revenue: Total revenue was $441.3 million for the second quarter of 2018, an increase of 21% compared to $363.5 million in the same quarter of 2017. |

[0001262039-18-000025:8k_2_02:22]
| • | Product revenue was $166.3 million for the second quarter of 2018, an increase of 17% compared to $142.7 million in the same quarter of 2017. Service revenue was $275.0 million for the second quarter of 2018, an increase of 25% compared to $220.8 million in the same quarter of 2017. |

[0001262039-18-000025:8k_2_02:23]
| • | Billings1: Total billings were $513.4 million for the second quarter of 2018, an increase of 20% compared to $426.9 million in the same quarter of 2017. |

[0001262039-18-000025:8k_2_02:24]
| • | Deferred Revenue: Total deferred revenue was $1.47 billion as of June 30, 2018, an increase of 27% compared to $1.16 billion as of June 30, 2017. |

[0001262039-18-000025:8k_2_02:25]
| • | GAAP Operating Income and Margin: GAAP operating income was $50.7 million for the second quarter of 2018, representing a GAAP operating margin of 11%. GAAP operating income was $28.5 million for the same quarter of 2017, representing a GAAP operating margin of 8%. |

[0001262039-18-000025:8k_2_02:26]
| • | Non-GAAP Operating Income1 and Margin1: Non-GAAP operating income was $93.1 million for the second quarter of 2018, representing a non-GAAP operating margin of 21%. Non-GAAP operating income was $65.7 million for the second quarter of 2017, representing a non-GAAP operating margin of 18%. |

[0001262039-18-000025:8k_2_02:27]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $49.3 million for the second quarter of 2018, compared to GAAP net income of $23.0 million for the same quarter of 2017. GAAP diluted net income per share was $0.28 for the second quarter of 2018, based on 173.5 million diluted weighted-average shares outstanding, compared to $0.13 for the same quarter of 2017, based on 179.7 million diluted weighted-average shares outstanding. GAAP effective tax rate was 4% in the second quarter of 2018, compared to an effective tax rate of 30% for the same quarter in 2017. |

[0001262039-18-000025:8k_2_02:28]
| • | Non-GAAP Net Income1 and Diluted Net Income Per Share1: Non-GAAP net income was $71.4 million for the second quarter of 2018, compared to non-GAAP net income of $47.7 million for the same quarter of 2017. Non-GAAP diluted net income per share was $0.41 for the second quarter of 2018, based on 173.5 million diluted weighted-average shares outstanding, compared to $0.27 for the same quarter of 2017, based on 179.7 million diluted weighted-average shares outstanding. Non-GAAP effective tax rate was 24% in the second quarter of 2018, compared to 32% for the same quarter in 2017. |

[0001262039-18-000025:8k_2_02:29]
| • | Cash, Cash Flow and Free Cash Flow1: As of June 30, 2018, cash, cash equivalents and investments were $1.50 billion, compared to $1.39 billion as of March 31, 2018. In the second quarter of 2018, cash flow from operations was $142.2 million, compared to $144.8 million in the same quarter of 2017. Free cash flow1 was $130.6 million during the second quarter of 2018, compared to $58.4 million in the same quarter of 2017. |

[0001262039-18-000025:8k_2_02:30]
| • | Bradford Networks Acquisition: During the quarter, we acquired Bradford Networks, further enhancing the Fortinet Security Fabric by converging access control and IoT security solutions to provide large enterprises with broader visibility and security for their complex networks. |

[0001262039-18-000025:8k_2_02:31]
| • | Share Repurchase: In July 2018, Fortinet’s Board of Directors approved an increase of $500.0 million in the current share repurchase program, bringing the total amount authorized for repurchase to $1.5 billion, and extended the term of the repurchase program to December 31, 2019. As of June 30, 2018, $325.8 million remained available for future share repurchases under the repurchase program. |

[0001262039-18-000025:8k_2_02:32]
Guidance

[0001262039-18-000025:8k_2_02:33]
For the third quarter of 2018, Fortinet currently expects:

[0001262039-18-000025:8k_2_02:34]
| • | Revenue in the range of $445.0 million to $455.0 million |

[0001262039-18-000025:8k_2_02:35]
| • | Billings in the range of $500.0 million to $515.0 million |

[0001262039-18-000025:8k_2_02:36]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000025:8k_2_02:37]
| • | Non-GAAP operating margin in the range of 21.5% to 22.0%, including a benefit associated with the adoption of ASC 606 of approximately 350 basis points |

[0001262039-18-000025:8k_2_02:38]
| • | Diluted non-GAAP earnings per share in the range of $0.41 to $0.43, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 175 million to 177 million |

[0001262039-18-000025:8k_2_02:39]
For the fiscal year of 2018, Fortinet currently expects:

[0001262039-18-000025:8k_2_02:40]
| • | Revenue in the range of $1.770 billion to $1.790 billion |

[0001262039-18-000025:8k_2_02:41]
| • | Billings in the range of $2.085 billion to $2.110 billion |

[0001262039-18-000025:8k_2_02:42]
| • | Non-GAAP gross margin in the range of 75% to 76% |

[0001262039-18-000025:8k_2_02:43]
| • | Non-GAAP operating margin in the range of 21.2% to 21.7%, including a benefit associated with the adoption of ASC 606 of approximately 350 basis points |

[0001262039-18-000025:8k_2_02:44]
| • | Diluted non-GAAP earnings per share in the range of $1.63 to $1.67, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 174 million to 176 million |

[0001262039-18-000025:8k_2_02:45]
The above guidance for the third quarter and full year of 2018 includes the transition impact of ASC 606 adoption, which was effective January 1, 2018. Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-18-000025:8k_2_02:46]
1 A reconciliation of historic GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-18-000025:8k_2_02:47]
Conference Call Details

[0001262039-18-000025:8k_2_02:48]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 9499689. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm. A replay of this conference call can also be accessed through August 8, 2018, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #9499689.

[0001262039-18-000025:8k_2_02:49]
Third Quarter 2018 Investor Conference Participation Schedule:

[0001262039-18-000025:8k_2_02:50]
| • | Oppenheimer’s 21st Annual Technology, Internet & Communications Conference |

[0001262039-18-000025:8k_2_02:51]
August 7, 2018 - Boston, MA

[0001262039-18-000025:8k_2_02:52]
| • | KeyBanc’s 20th Annual Global Technology Leadership Forum (Meetings Only) |

[0001262039-18-000025:8k_2_02:53]
August 13, 2018 - Vail, CO

[0001262039-18-000025:8k_2_02:54]
| • | Raymond James’ 2nd Annual SMID Cap Growth Conference (Meetings Only) |

[0001262039-18-000025:8k_2_02:55]
August 21, 2018 - Chicago, IL

[0001262039-18-000025:8k_2_02:56]
| • | Citibank’s 2018 Global Technology Conference |

[0001262039-18-000025:8k_2_02:57]
September 5, 2018 - New York, NY

[0001262039-18-000025:8k_2_02:58]
| • | Deutsche Bank’s Technology Conference |

[0001262039-18-000025:8k_2_02:59]
September 12, 2018 - Las Vegas, NV

[0001262039-18-000025:8k_2_02:60]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-18-000025:8k_2_02:61]
About Fortinet (www.fortinet.com)

[0001262039-18-000025:8k_2_02:62]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-18-000025:8k_2_02:63]
#          #          #

[0001262039-18-000025:8k_2_02:64]
Copyright © 2018 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-18-000025:8k_2_02:65]
FTNT-F

[0001262039-18-000025:8k_2_02:66]
Forward-looking Statements

[0001262039-18-000025:8k_2_02:67]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the opportunities ahead, Fortinet’s position to empower customers and our position for future growth, our position to provide our customers the best network security, our ability to continue to grow our market position and address our market opportunity, and all guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein

[0001262039-18-000025:8k_2_02:68]
Non-GAAP Financial Measures

[0001262039-18-000025:8k_2_02:69]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-18-000025:8k_2_02:70]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-18-000025:8k_2_02:71]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-18-000025:8k_2_02:72]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-18-000025:8k_2_02:73]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-18-000025:8k_2_02:74]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-18-000025:8k_2_02:75]
FORTINET, INC.

[0001262039-18-000025:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-18-000025:8k_2_02:77]
(Unaudited, in millions)

[0001262039-18-000025:8k_2_02:78]
|  | June 30, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 972.1 |  |  | $ | 811.0 |  |
| Short-term investments | 461.6 |  |  | 440.3 |  |
| Accounts receivable—net | 333.6 |  |  | 348.2 |  |
| Inventory | 78.2 |  |  | 77.3 |  |
| Prepaid expenses and other current assets | 39.3 |  |  | 40.0 |  |
| Total current assets | 1,884.8 |  |  | 1,716.8 |  |
| LONG-TERM INVESTMENTS | 65.3 |  |  | 98.0 |  |
| PROPERTY AND EQUIPMENT—NET | 256.0 |  |  | 245.4 |  |
| DEFERRED CONTRACT COSTS | 160.6 |  |  | — |  |
| DEFERRED TAX ASSETS | 141.9 |  |  | 146.9 |  |
| OTHER INTANGIBLE ASSETS—NET | 21.4 |  |  | 16.3 |  |
| GOODWILL | 25.1 |  |  | 14.6 |  |
| OTHER ASSETS | 20.6 |  |  | 19.9 |  |
| TOTAL ASSETS | $ | 2,575.7 |  |  | $ | 2,257.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 63.7 |  |  | $ | 70.0 |  |
| Accrued liabilities | 59.0 |  |  | 50.0 |  |
| Accrued payroll and compensation | 91.3 |  |  | 92.0 |  |
| Income taxes payable | 21.7 |  |  | 21.4 |  |
| Deferred revenue | 849.5 |  |  | 793.8 |  |
| Total current liabilities | 1,085.2 |  |  | 1,027.2 |  |
| DEFERRED REVENUE | 621.3 |  |  | 542.5 |  |
| INCOME TAX LIABILITIES | 76.8 |  |  | 90.2 |  |
| OTHER LIABILITIES | 12.2 |  |  | 8.6 |  |
| Total liabilities | 1,795.5 |  |  | 1,668.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 996.1 |  |  | 909.6 |  |
| Accumulated other comprehensive loss | (1.4 | ) |  | (0.8 | ) |
| Accumulated deficit | (214.7 | ) |  | (319.6 | ) |
| Total stockholders’ equity | 780.2 |  |  | 589.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,575.7 |  |  | $ | 2,257.9 |  |

[0001262039-18-000025:8k_2_02:79]
FORTINET, INC.

[0001262039-18-000025:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-18-000025:8k_2_02:81]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000025:8k_2_02:82]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 142.7 |  |  | $ | 309.1 |  |  | $ | 277.9 |  |
| Service | 275.0 |  |  | 220.8 |  |  | 531.2 |  |  | 426.1 |  |
| Total revenue | 441.3 |  |  | 363.5 |  |  | 840.3 |  |  | 704.0 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 73.9 |  |  | 60.8 |  |  | 132.1 |  |  | 116.1 |  |
| Service 1 | 39.2 |  |  | 34.9 |  |  | 78.2 |  |  | 70.1 |  |
| Total cost of revenue | 113.1 |  |  | 95.7 |  |  | 210.3 |  |  | 186.2 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 92.4 |  |  | 81.9 |  |  | 177.0 |  |  | 161.8 |  |
| Service | 235.8 |  |  | 185.9 |  |  | 453.0 |  |  | 356.0 |  |
| Total gross profit | 328.2 |  |  | 267.8 |  |  | 630.0 |  |  | 517.8 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 61.2 |  |  | 51.2 |  |  | 120.3 |  |  | 102.4 |  |
| Sales and marketing 1 | 192.8 |  |  | 166.3 |  |  | 378.1 |  |  | 336.7 |  |
| General and administrative 1 | 23.5 |  |  | 21.9 |  |  | 48.5 |  |  | 44.5 |  |
| Restructuring charges | — |  |  | (0.1 | ) |  | — |  |  | 0.3 |  |
| Total operating expenses | 277.5 |  |  | 239.3 |  |  | 546.9 |  |  | 483.9 |  |
| OPERATING INCOME | 50.7 |  |  | 28.5 |  |  | 83.1 |  |  | 33.9 |  |
| INTEREST INCOME | 5.8 |  |  | 3.2 |  |  | 10.3 |  |  | 5.6 |  |
| OTHER INCOME (EXPENSE)—NET | (5.0 | ) |  | 1.2 |  |  | (5.2 | ) |  | 1.5 |  |
| INCOME BEFORE INCOME TAXES | 51.5 |  |  | 32.9 |  |  | 88.2 |  |  | 41.0 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.2 |  |  | 9.9 |  |  | (2.7 | ) |  | 7.3 |  |
| NET INCOME | $ | 49.3 |  |  | $ | 23.0 |  |  | $ | 90.9 |  |  | $ | 33.7 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.13 |  |  | $ | 0.54 |  |  | $ | 0.19 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.13 |  |  | $ | 0.53 |  |  | $ | 0.19 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 168.6 |  |  | 175.7 |  |  | 168.1 |  |  | 175.1 |  |
| Diluted | 173.5 |  |  | 179.7 |  |  | 172.6 |  |  | 179.0 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 0.7 |  |
| Cost of service revenue | 2.7 |  |  | 2.5 |  |  | 5.2 |  |  | 4.8 |  |
| Research and development | 9.2 |  |  | 8.3 |  |  | 17.6 |  |  | 16.1 |  |
| Sales and marketing | 23.6 |  |  | 19.7 |  |  | 44.5 |  |  | 38.8 |  |
| General and administrative | 4.7 |  |  | 4.2 |  |  | 9.0 |  |  | 8.0 |  |
|  | $ | 40.6 |  |  | $ | 35.1 |  |  | $ | 77.1 |  |  | $ | 68.4 |  |

[0001262039-18-000025:8k_2_02:83]
FORTINET, INC.

[0001262039-18-000025:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-18-000025:8k_2_02:85]
(Unaudited, in millions)

[0001262039-18-000025:8k_2_02:86]
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 90.9 |  |  | $ | 33.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 77.1 |  |  | 68.4 |  |
| Amortization of deferred contract costs | 43.2 |  |  | — |  |
| Depreciation and amortization | 26.8 |  |  | 27.5 |  |
| Other non-cash items—net | 0.4 |  |  | 1.7 |  |
| Amortization of investment premiums | 0.2 |  |  | 1.4 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 28.9 |  |  | 37.9 |  |
| Inventory | (10.8 | ) |  | 9.8 |  |
| Prepaid expenses and other current assets | 0.9 |  |  | (3.2 | ) |
| Deferred contract costs | (66.7 | ) |  | — |  |
| Deferred tax assets | (13.3 | ) |  | (24.4 | ) |
| Other assets | (0.7 | ) |  | 0.7 |  |
| Accounts payable | (9.1 | ) |  | (19.9 | ) |
| Accrued liabilities | (4.7 | ) |  | 1.8 |  |
| Accrued payroll and compensation | (2.0 | ) |  | 1.6 |  |
| Other liabilities | (2.2 | ) |  | (2.7 | ) |
| Deferred revenue | 136.3 |  |  | 125.4 |  |
| Income taxes payable | (13.2 | ) |  | 14.8 |  |
| Net cash provided by operating activities | 282.0 |  |  | 274.5 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (262.3 | ) |  | (270.5 | ) |
| Sales of investments | 28.7 |  |  | 10.0 |  |
| Maturities of investments | 244.3 |  |  | 247.2 |  |
| Purchases of property and equipment | (23.2 | ) |  | (99.9 | ) |
| Payments made in connection with business combination, net of cash acquired | (6.0 | ) |  | — |  |
| Net cash used in investing activities | (18.5 | ) |  | (113.2 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (117.1 | ) |  | (33.1 | ) |
| Proceeds from issuance of common stock | 56.7 |  |  | 41.8 |  |
| Taxes paid related to net share settlement of equity awards | (32.5 | ) |  | (25.9 | ) |
| Payments of debt assumed in connection with business combination | (9.5 | ) |  | — |  |
| Net cash used in financing activities | (102.4 | ) |  | (17.2 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 161.1 |  |  | 144.1 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 811.0 |  |  | 709.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 972.1 |  |  | $ | 853.1 |  |

[0001262039-18-000025:8k_2_02:87]
New Revenue Recognition Standard (ASC 606) Adoption Financial Impact1

[0001262039-18-000025:8k_2_02:88]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000025:8k_2_02:89]
|  | Three Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 166.3 |  |  | $ | 162.1 |  |  | $ | 4.2 |  |
| Service | 275.0 |  |  | 274.0 |  |  | 1.0 |  |
| Total revenue | 441.3 |  |  | 436.1 |  |  | 5.2 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 73.9 |  |  | 74.1 |  |  | (0.2 | ) |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 92.4 |  |  | 88.0 |  |  | 4.4 |  |
| Service | 235.8 |  |  | 234.8 |  |  | 1.0 |  |
| Total gross profit | 328.2 |  |  | 322.8 |  |  | 5.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 192.8 |  |  | 204.6 |  |  | (11.8 | ) |
| OPERATING INCOME | 50.7 |  |  | 33.5 |  |  | 17.2 |  |
| INCOME BEFORE INCOME TAXES | 51.5 |  |  | 34.3 |  |  | 17.2 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 2.2 |  |  | (1.8 | ) |  | 4.0 |  |
| NET INCOME | $ | 49.3 |  |  | $ | 36.1 |  |  | $ | 13.2 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |

[0001262039-18-000025:8k_2_02:90]
|  | Six Months Ended June 30, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 309.1 |  |  | $ | 299.2 |  |  | $ | 9.9 |  |
| Service | 531.2 |  |  | 529.5 |  |  | 1.7 |  |
| Total revenue | 840.3 |  |  | 828.7 |  |  | 11.6 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 132.1 |  |  | 130.8 |  |  | 1.3 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 177.0 |  |  | 168.4 |  |  | 8.6 |  |
| Service | 453.0 |  |  | 451.3 |  |  | 1.7 |  |
| Total gross profit | 630.0 |  |  | 619.7 |  |  | 10.3 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 378.1 |  |  | 401.6 |  |  | (23.5 | ) |
| OPERATING INCOME | 83.1 |  |  | 49.3 |  |  | 33.8 |  |
| INCOME BEFORE INCOME TAXES | 88.2 |  |  | 54.4 |  |  | 33.8 |  |
| BENEFIT FROM INCOME TAXES | (2.7 | ) |  | (10.5 | ) |  | 7.8 |  |
| NET INCOME | $ | 90.9 |  |  | $ | 64.9 |  |  | $ | 26.0 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.54 |  |  | $ | 0.39 |  |  | $ | 0.15 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.38 |  |  | $ | 0.15 |  |
| 1 The tables above do not represent the full condensed consolidated statement of operations as they only present the accounts impacted by the adoption of ASC 606. |

[0001262039-18-000025:8k_2_02:91]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-18-000025:8k_2_02:92]
(Unaudited, in millions, except per share amounts)

[0001262039-18-000025:8k_2_02:93]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-18-000025:8k_2_02:94]
|  | Three Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Net cash provided by operating activities | $ | 142.2 |  |  | $ | 144.8 |  |
| Less: Purchases of property and equipment | (11.6 | ) |  | (86.4 | ) |
| Free cash flow | $ | 130.6 |  |  | $ | 58.4 |  |
| Net cash provided by (used in) investing activities | $ | 7.0 |  |  | $ | (81.9 | ) |
| Net cash used in financing activities | $ | (12.8 | ) |  | $ | (33.0 | ) |

[0001262039-18-000025:8k_2_02:95]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-18-000025:8k_2_02:96]
|  | Three Months Ended June 30, 2018 |  | Three Months Ended June 30, 2017 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 50.7 |  |  | $ | 42.4 |  | (a) | $ | 93.1 |  |  | $ | 28.5 |  |  | $ | 37.2 |  | (b) | $ | 65.7 |  |
| Operating margin | 11 | % |  |  |  | 21 | % |  | 8 | % |  |  |  | 18 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 40.6 |  |  |  |  |  |  | 35.1 |  |  |  |
| Amortization of acquired intangible assets |  |  | 1.8 |  |  |  |  |  |  | 2.2 |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  |  |  | (0.1 | ) |  |  |
| Tax adjustment |  |  | (20.3 | ) | (c) |  |  |  |  | (12.5 | ) | (c) |  |
| Net income | $ | 49.3 |  |  | $ | 22.1 |  |  | $ | 71.4 |  |  | $ | 23.0 |  |  | $ | 24.7 |  |  | $ | 47.7 |  |
| Diluted net income per share | $ | 0.28 |  |  |  |  | $ | 0.41 |  |  | $ | 0.13 |  |  |  |  | $ | 0.27 |  |
| Shares used in diluted net income per share calculations | 173.5 |  |  |  |  | 173.5 |  |  | 179.7 |  |  |  |  | 179.7 |  |

[0001262039-18-000025:8k_2_02:97]
(a) To exclude $40.6 million of stock-based compensation and $1.8 million of amortization of acquired intangible assets in the three months ended June 30, 2018.

[0001262039-18-000025:8k_2_02:98]
(b) To exclude $35.1 million of stock-based compensation, $2.2 million of amortization of acquired intangible assets, and $(0.1) million of restructuring charges in the three months ended June 30, 2017.

[0001262039-18-000025:8k_2_02:99]
(c)  Non-GAAP financial information is adjusted to achieve an overall effective tax rate of 24% and 32% in 2018 and 2017, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-18-000025:8k_2_02:100]
Reconciliation of total revenue to total billings

[0001262039-18-000025:8k_2_02:101]
|  | Three Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
| Total revenue | $ | 441.3 |  |  | $ | 363.5 |  |
| Add: Change in deferred revenue | 74.4 |  |  | 63.4 |  |
| Less: Deferred revenue balance acquired in business combination | (2.3 | ) |  | — |  |
| Total billings | $ | 513.4 |  |  | $ | 426.9 |  |

[0001262039-18-000025:8k_2_02:102]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
