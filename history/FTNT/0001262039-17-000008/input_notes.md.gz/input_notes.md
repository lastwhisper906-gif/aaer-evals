# FTNT notes — 0001262039-17-000008


## ftnt:CashandCashEquivalentsandAvailableforSaleInvestmentsPolicyTextBlock

[0001262039-17-000008:notes:1]
Cash, Cash Equivalents and Available-for-sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds and commercial paper.

[0001262039-17-000008:notes:2]
We classify our investments as available-for-sale at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-17-000008:notes:3]
Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001262039-17-000008:notes:4]
For debt securities in an unrealized loss position which is deemed to be other-than-temporary, the difference between the security’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive loss.


## ftnt:ComprehensiveIncomeLossPolicyTextBlock

[0001262039-17-000008:notes:5]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments and the related tax impact.


## ftnt:ConcentrationRiskPolicyTextBlock

[0001262039-17-000008:notes:6]
Concentration of Credit Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the U.S. and around the world. Balances in the U.S. typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, commercial paper and fixed income securities with major financial institutions that our management believes are financially sound.

[0001262039-17-000008:notes:7]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses.


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-17-000008:notes:8]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of operations is as follows (in thousands):

[0001262039-17-000008:notes:9]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Income tax benefit associated with stock-based compensation | $ | 29,190 |  |  | $ | 25,189 |  |  | $ | 11,086 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-17-000008:notes:10]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the U.S. (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-17-000008:notes:11]
The following table summarizes our investments (in thousands):

[0001262039-17-000008:notes:12]
|  | December 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 379,494 |  |  | $ | 43 |  |  | $ | (925 | ) |  | $ | 378,612 |  |
| Commercial paper | 95,110 |  |  | 23 |  |  | (25 | ) |  | 95,108 |  |
| U.S. government and agency securities | 64,604 |  |  | 16 |  |  | (79 | ) |  | 64,541 |  |
| Municipal bonds | 59,257 |  |  | 3 |  |  | (235 | ) |  | 59,025 |  |
| Certificates of deposit and term deposits (1) | 4,219 |  |  | — |  |  | — |  |  | 4,219 |  |
| Total available-for-sale securities | $ | 602,684 |  |  | $ | 85 |  |  | $ | (1,264 | ) |  | $ | 601,505 |  |
|  | December 31, 2015 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 438,533 |  |  | $ | 30 |  |  | $ | (1,369 | ) |  | $ | 437,194 |  |
| Commercial paper | 66,263 |  |  | 3 |  |  | (34 | ) |  | 66,232 |  |
| Municipal bonds | 61,050 |  |  | 12 |  |  | (40 | ) |  | 61,022 |  |
| Certificates of deposit and term deposits (1) | 14,897 |  |  | — |  |  | — |  |  | 14,897 |  |
| U.S. government and agency securities | 41,727 |  |  | 3 |  |  | (42 | ) |  | 41,688 |  |
| Total available-for-sale securities | $ | 622,470 |  |  | $ | 48 |  |  | $ | (1,485 | ) |  | $ | 621,033 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-17-000008:notes:13]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-17-000008:notes:14]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected term in years | 4.3 |  |  | 4.3 |  |  | 4.8 |  |
| Volatility | 42 | % |  | 39 | % |  | 43 | % |
| Risk-free interest rate | 1.1 | % |  | 1.6 | % |  | 1.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleOfSharesReservedForFutureIssuanceTableTextBlock

[0001262039-17-000008:notes:15]
The following table presents the common stock reserved for future issuance (in thousands):

[0001262039-17-000008:notes:16]
|  | December 31, 2016 |
| Outstanding stock options and RSUs | 15,696 |  |
| Reserved for future equity award grants | 40,312 |  |
| Reserved for future ESPP issuances | 4,066 |  |
| Total common stock reserved for future issuances | 60,074 |  |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-17-000008:notes:17]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-17-000008:notes:18]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| RSUs | $ | 107,124 |  |  | $ | 77,262 |  |  | $ | 37,068 |  |
| Stock options | 6,596 |  |  | 11,425 |  |  | 17,555 |  |
| ESPP | 8,703 |  |  | 6,401 |  |  | 4,371 |  |
| Total stock-based compensation expense | $ | 122,423 |  |  | $ | 95,088 |  |  | $ | 58,994 |  |


## ftnt:ScheduleofEstimatedUsefulLivesofPropertyPlantandEquipmentTableTextBlock

[0001262039-17-000008:notes:19]
Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-17-000008:notes:20]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 20 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 5 years |
| Leasehold improvements | Shorter of useful life or lease term |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-17-000008:notes:21]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-17-000008:notes:22]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Shares withheld for taxes | 1,203 |  |  | 761 |  |  | 461 |  |
| Amount withheld for taxes | $ | 38,266 |  |  | $ | 28,871 |  |  | $ | 10,598 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-17-000008:notes:23]
Additional information related to our stock options is summarized below (in thousands, except per share amounts):

[0001262039-17-000008:notes:24]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Weighted-average fair value per share granted | $ | 9.14 |  |  | $ | 13.20 |  |  | $ | 8.90 |  |
| Intrinsic value of options exercised | 40,306 |  |  | 113,786 |  |  | 76,731 |  |
| Fair value of options vested | 5,444 |  |  | 10,943 |  |  | 17,098 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-17-000008:notes:25]
Additional information related to the ESPP is provided below (in thousands, except per share amounts):

[0001262039-17-000008:notes:26]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Weighted-average fair value per share granted | $ | 7.68 |  |  | $ | 9.56 |  |  | $ | 5.91 |  |
| Shares issued under the ESPP | 1,151 |  |  | 764 |  |  | 770 |  |
| Weighted-average price per share issued | $ | 21.01 |  |  | $ | 24.30 |  |  | $ | 18.17 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001262039-17-000008:notes:27]
The following table summarizes the combined results of operations of Fortinet and Meru as if the acquisition occurred on January 1, 2014. The pro forma results includes purchase accounting adjustments for amortization charges from acquired intangible assets, depreciation of acquired property, plant and equipment, stock-based compensation and related tax effects (in thousands):

[0001262039-17-000008:notes:28]
|  | Years Ended December 31, |
|  | 2015 |  | 2014 |
| Pro forma revenue | $ | 1,046,972 |  |  | $ | 861,255 |  |
| Pro forma income (loss) from operations | (1,983 | ) |  | 34,105 |  |
| Pro forma net income (loss) | (4,634 | ) |  | 5,968 |  |
| Pro forma net income (loss) per share: |  |  |  |
| Basic | (0.03 | ) |  | 0.04 |  |
| Diluted | (0.03 | ) |  | 0.04 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-17-000008:notes:29]
BUSINESS COMBINATIONS

[0001262039-17-000008:notes:30]
AccelOps, Inc.

[0001262039-17-000008:notes:31]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions, for total cash consideration of $22.1 million, net of cash received. We believe this acquisition will extend the Fortinet Security Fabric by enhancing our network security visibility, security data analytics and threat intelligence across multi-vendor solutions.

[0001262039-17-000008:notes:32]
The acquisition of AccelOps is accounted for as a business combination in accordance with the ASC 805, Business Combinations (“ASC 805”), issued by the FASB. We use our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. We included acquisition-related costs of $0.3 million in general and administrative expenses. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The acquisition also included a contingent obligation for up to $4.0 million in future earn out payments to certain former stockholders of AccelOps if specified future financial targets were met as of December 31, 2016. As of the acquisition date, we estimated the fair value of the liability to be zero as we did not believe the targets would be met.  As of December 31, 2016, the financial targets were not met.

[0001262039-17-000008:notes:33]
Total allocation of the purchase price was (in thousands):

[0001262039-17-000008:notes:34]
| Cash and cash equivalents | $ | 171 |  |
| Accounts receivable | 1,126 |  |
| Prepaid expenses and other assets | 430 |  |
| Property and equipment | 203 |  |
| Deferred tax assets | 3,435 |  |
| Finite-lived intangible assets | 14,900 |  |
| Indefinite-lived intangible assets in process research and development | 1,600 |  |
| Goodwill | 9,861 |  |
| Total assets acquired | 31,726 |  |
| Deferred revenue | 4,400 |  |
| Accounts payable and accrued liabilities | 3,348 |  |
| Other liabilities | 1,694 |  |
| Total liabilities assumed | 9,442 |  |
| Total purchase price allocation | $ | 22,284 |  |

[0001262039-17-000008:notes:35]
Finite-lived intangible assets consist of developed technology, customer relationships and other intangible assets. AccelOps’ technology provides a software solution to manage security, performance and compliance from a single platform. The acquired developed technologies include software patents, know-how, process and designs. The value of customer relationships is attributable to the generation of a consistent income source and the avoidance of costs associated with creating new customer relationships.

[0001262039-17-000008:notes:36]
The estimated useful life and fair values of the acquired finite-lived intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-17-000008:notes:37]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Developed technologies | 4 |  | $ | 12,400 |  |
| Customer relationships | 3 |  | 2,300 |  |
| Other | 2 |  | 200 |  |
| Total |  |  | $ | 14,900 |  |

[0001262039-17-000008:notes:38]
The developed technologies and other are amortized on a straight-line basis. The amortization expense of developed technologies is recorded in costs of revenue, and other intangibles is recorded in cost of service revenue. The amortization expense of customer relationships is amortized on an accelerated basis and is recorded in sales and marketing expenses.

[0001262039-17-000008:notes:39]
Indefinite-lived intangible assets consist of in-process research and development, which will begin to be amortized upon completion of development.

[0001262039-17-000008:notes:40]
The goodwill of $9.9 million represents the amount of the purchase price in excess of the fair value of the net tangible liabilities assumed and intangible assets acquired, including AccelOps’ assembled workforce. The goodwill recorded as part of the AccelOps acquisition is not deductible for U.S. federal income tax purposes. The financial results of this acquisition are considered immaterial for purposes of pro forma financial disclosures.

[0001262039-17-000008:notes:41]
Meru Networks, Inc.

[0001262039-17-000008:notes:42]
On July 8, 2015, we completed our acquisition of Meru Networks, Inc. (“Meru”), a provider of Wi-Fi networking products and services.

[0001262039-17-000008:notes:43]
In connection with the acquisition, we paid $41.8 million, comprised of cash consideration of $40.9 million, withholding tax liability of $0.4 million and the estimated fair value associated with RSUs of Meru of $0.5 million that were converted for 53,401 shares of our common stock.

[0001262039-17-000008:notes:44]
We accounted for this transaction as a business combination. We expensed acquisition-related costs of $1.7 million in general and administrative expenses. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-17-000008:notes:45]
Total allocation of the purchase price was as follows (in thousands):

[0001262039-17-000008:notes:46]
| Cash and cash equivalents | $ | 3,268 |  |
| Accounts receivable | 8,191 |  |
| Inventory | 11,610 |  |
| Prepaid expenses and other assets | 2,409 |  |
| Property and equipment | 920 |  |
| Deferred tax assets | 18,585 |  |
| Finite-lived intangible assets | 19,600 |  |
| Goodwill | 1,868 |  |
| Total assets acquired | 66,451 |  |
| Deferred revenue | 9,800 |  |
| Accounts payable and accrued liabilities | 14,887 |  |
| Total liabilities assumed | 24,687 |  |
| Total purchase price allocation | $ | 41,764 |  |

[0001262039-17-000008:notes:47]
The goodwill of $1.9 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to Meru’s assembled workforce. The goodwill recorded as part of the Meru acquisition is not deductible for U.S. federal income tax purposes.

[0001262039-17-000008:notes:48]
Intangible assets consist primarily of customer relationships and developed technologies. Customer relationships represent Meru’s installed base and the ability to sell existing, in-process and future versions of our products and services to its existing customers. Developed technologies represent the virtualized wireless local area network solutions offering centralized coordination and control of various access points on the network. This includes patented and unpatented technology, know-how, processes, designs and computer software. The estimated useful life and fair values of the acquired identifiable intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-17-000008:notes:49]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Customer relationships | 5 |  | $ | 12,200 |  |
| Developed technologies | 4 |  | 7,200 |  |
| Trade name | 0.5 |  | 200 |  |
| Total |  |  | $ | 19,600 |  |

[0001262039-17-000008:notes:50]
Customer relationships and trade name are amortized and the amortization expense is recorded in sales and marketing expenses in the consolidated statement of operations. Developed technologies are amortized and the amortization expense is recorded in cost of product revenue in the consolidated statement of operations.

[0001262039-17-000008:notes:51]
The pro forma financial information presented above is for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition had taken place at the beginning of January 2014, nor it is indicative of any future results.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-17-000008:notes:52]
COMMITMENTS AND CONTINGENCIES

[0001262039-17-000008:notes:53]
The following table summarizes our future principal contractual obligations as of December 31, 2016 (in thousands):

[0001262039-17-000008:notes:54]
|  | Total |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 65,489 |  |  | $ | 17,699 |  |  | $ | 14,103 |  |  | $ | 11,933 |  |  | $ | 9,474 |  |  | $ | 4,003 |  |  | $ | 8,277 |  |
| Inventory purchase commitments | 91,247 |  |  | 91,247 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 50,686 |  |  | 45,953 |  |  | 3,776 |  |  | 693 |  |  | 264 |  |  | — |  |  | — |  |
| Total | $ | 207,422 |  |  | $ | 154,899 |  |  | $ | 17,879 |  |  | $ | 12,626 |  |  | $ | 9,738 |  |  | $ | 4,003 |  |  | $ | 8,277 |  |

[0001262039-17-000008:notes:55]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $18.9 million, $13.8 million and $10.6 million for 2016, 2015 and 2014, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-17-000008:notes:56]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2016, we had $91.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-17-000008:notes:57]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2016, we had $50.7 million in other contractual commitments that may not be cancelable.

[0001262039-17-000008:notes:58]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. With respect to outstanding legal proceedings, including the matter described below, we have not recorded any significant accruals for loss contingencies associated with such legal proceedings, based on our belief that any potential loss, while reasonably possible, is not probable and estimable. Further, a possible range of loss in this matter cannot be reasonably estimated at this time. We currently believe we have reasonable defenses with respect to legal proceedings against us.

[0001262039-17-000008:notes:59]
In October 2016, we received a letter from the United States Attorney's Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

[0001262039-17-000008:notes:60]
In December 2015, we received $9.0 million from a third-party for a release of claims. In addition, we agreed to a three-year covenant-not-to-sue. Of the $9.0 million consideration received, $2.0 million was used to offset contingent legal fees incurred in connection with the litigation and the remaining $7.0 million was deferred, with the short-term portion recorded as accrued liabilities and the long-term portion recorded as other liabilities in the consolidated balance sheet. The deferral will be recognized ratably through 2018 as an offset to general and administrative expenses in the consolidated statement of operations.

[0001262039-17-000008:notes:61]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-17-000008:notes:62]
DEFINED CONTRIBUTION PLANS

[0001262039-17-000008:notes:63]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for 2016, 2015 and 2014 were $4.4 million, $3.5 million and $2.5 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-17-000008:notes:64]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-17-000008:notes:65]
The following table summarizes the changes in accumulated balances of other comprehensive loss for 2016 and 2015 (in thousands):

[0001262039-17-000008:notes:66]
|  | December 31, 2016 |
|  | Unrealized Losses on Investments |  | Tax benefit related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |
| Other comprehensive income before reclassifications | 255 |  |  | (89 | ) |  | 166 |  |
| Amounts reclassified from accumulated other comprehensive income | 3 |  |  | (1 | ) |  | 2 |  |
| Net current-period other comprehensive income | 258 |  |  | (90 | ) |  | 168 |  |
| Ending balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |

[0001262039-17-000008:notes:67]
|  | December 31, 2015 |
|  | Unrealized Losses on Investments |  | Tax benefit related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (540 | ) |  | $ | 191 |  |  | $ | (349 | ) |
| Other comprehensive loss before reclassifications | (896 | ) |  | 313 |  |  | (583 | ) |
| Amounts reclassified from accumulated other comprehensive loss | (1 | ) |  | — |  |  | (1 | ) |
| Net current-period other comprehensive loss | (897 | ) |  | 313 |  |  | (584 | ) |
| Ending balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |

[0001262039-17-000008:notes:68]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to items of other comprehensive income or loss is recorded in Other expense—net and in Provision for income taxes, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-17-000008:notes:69]
INVESTMENTS IN PRIVATELY-HELD COMPANIES

[0001262039-17-000008:notes:70]
Our investments in the equity securities of three privately-held companies totaled $10.3 million as of December 31, 2016 and 2015. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our consolidated balance sheet and would be measured at fair value if indicators of impairment exist. As of December 31, 2016, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-17-000008:notes:71]
We determined that we had a variable interest in these privately-held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities were not required to be consolidated in our consolidated financial statements.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001262039-17-000008:notes:72]
Restructuring— Our restructuring expenses consist of severance and other one-time benefits, contract terminations and other expenses. Liabilities for costs associated with a restructuring activity are measured at fair value. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for terminating a contract before the end of its term, which is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty, is recognized at fair value on the notification date. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Other costs primarily consist of asset write-offs, which are expensed when incurred.

[0001262039-17-000008:notes:73]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plan, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-17-000008:notes:74]
STOCKHOLDERS’ EQUITY

[0001262039-17-000008:notes:75]
Stock-Based Compensation Plans

[0001262039-17-000008:notes:76]
Our stock-based compensation plans include the 2000 Stock Plan (the “2000 Plan”), the 2008 Stock Plan (the “2008 Plan”), the 2009 Equity Incentive Plan (the “2009 Plan”) and the ESPP, as well as an equity plan assumed through the Meru acquisition. Under these plans, we have granted (or, in the case of the acquired plan, we have assumed) stock options and RSUs, including PSUs.

[0001262039-17-000008:notes:77]
Stock Plans—Our board of directors adopted the 2000 Plan in 2000 and the 2008 Plan in 2008. The plans include both incentive and non-statutory stock options, which allowed us to grant options to purchase common stock to employees, directors, and contractors. During 2016, 2015 and 2014, we issued no stock options under these plans. As of December 31, 2015, no shares remain available for grant under these plans.

[0001262039-17-000008:notes:78]
2009 Equity Incentive Plan—In 2009, our board of directors approved the 2009 Plan, which includes awards of stock options, stock appreciation rights, restricted stock, RSUs and PSUs. The maximum aggregate number of shares that may be issued under the 2009 Plan is 9.0 million shares, plus any shares subject to stock options or similar awards granted under the 2008 Plan and the 2000 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2008 Plan and the 2000 Plan that are forfeited to or repurchased by us, with the maximum number of shares to be added to the 2009 Plan pursuant to such terminations, forfeitures and repurchases not to exceed 21.0 million shares. The shares may be authorized but unissued or reacquired, common stock. The number of shares available for issuance under the 2009 Plan is increased on the first day of each year beginning with 2011, in an amount equal to the lesser of (i) 14.0 million shares (as adjusted in connection with the stock split effected in June 2011), (ii) 5% of the outstanding shares on the last day of the immediately preceding year or (iii) such number of shares determined by our board of directors. Under the 2009 Plan, we may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of seven years and options generally vest over four years.

[0001262039-17-000008:notes:79]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permits eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year.

[0001262039-17-000008:notes:80]
Meru 2010 Equity Incentive Plan—In connection with the Meru acquisition, we assumed and exchanged Meru’s outstanding RSUs with an estimated fair value of $2.0 million. Of the total estimated fair value, $0.5 million relating to earned equity awards was allocated to the purchase price and the remainder relating to future services is being recognized over the remaining service period. No new equity awards can be granted under the assumed plan. As of December 31, 2016, RSUs representing 4,199 shares of common stock were outstanding under the awards assumed through the acquisition of Meru.

[0001262039-17-000008:notes:81]
As of December 31, 2016, there were a total of 44,377,942 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-17-000008:notes:82]
Restricted Stock Units

[0001262039-17-000008:notes:83]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-17-000008:notes:84]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2013 | 4,199 |  |  | $ | 22.00 |  |
| Granted | 4,047 |  |  | 23.13 |  |
| Forfeited | (472 | ) |  | 21.92 |  |
| Vested | (1,483 | ) |  | 22.23 |  |
| Balance—December 31, 2014 | 6,291 |  |  | 22.93 |  |
| Granted | 6,303 |  |  | 39.04 |  |
| Forfeited | (1,029 | ) |  | 31.78 |  |
| Vested | (2,308 | ) |  | 22.74 |  |
| Balance—December 31, 2015 | 9,257 |  |  | 32.97 |  |
| Granted | 5,551 |  |  | 27.96 |  |
| Forfeited | (1,673 | ) |  | 32.03 |  |
| Vested | (3,626 | ) |  | 30.45 |  |
| Balance—December 31, 2016 | 9,509 |  |  | $ | 31.01 |  |

[0001262039-17-000008:notes:85]
As of December 31, 2016, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $251.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.73 years.

[0001262039-17-000008:notes:86]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding taxes. Total payment for the employees’ tax obligations to the taxing authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-17-000008:notes:87]
Employee Stock Options

[0001262039-17-000008:notes:88]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-17-000008:notes:89]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding.  We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-17-000008:notes:90]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-17-000008:notes:91]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-17-000008:notes:92]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-17-000008:notes:93]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-17-000008:notes:94]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-17-000008:notes:95]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2013 | 15,521 |  |  | $ | 13.18 |  |  |  |  |  |
| Granted | 387 |  |  | 23.08 |  |  |  |  |  |
| Forfeited | (443 | ) |  | 24.21 |  |  |  |  |  |
| Exercised | (4,763 | ) |  | 8.91 |  |  |  |  |  |
| Balance—December 31, 2014 | 10,702 |  |  | 14.98 |  |  |  |  |  |
| Granted | 819 |  |  | 39.50 |  |  |  |  |  |
| Forfeited | (150 | ) |  | 28.67 |  |  |  |  |  |
| Exercised | (4,403 | ) |  | 11.10 |  |  |  |  |  |
| Balance—December 31, 2015 | 6,968 |  |  | 20.03 |  |  |  |  |  |  |
| Granted | 1,468 |  |  | 25.65 |  |  |  |  |  |
| Forfeited | (268 | ) |  | 34.82 |  |  |  |  |  |
| Exercised | (1,981 | ) |  | 10.45 |  |  |  |  |  |
| Balance—December 31, 2016 | 6,187 |  |  | $ | 23.79 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2016 | 6,187 |  |  | $ | 23.79 |  |  | 3.08 |  | $ | 45,168 |  |
| Options exercisable—December 31, 2016 | 4,313 |  |  | $ | 21.94 |  |  | 1.85 |  | $ | 37,299 |  |

[0001262039-17-000008:notes:96]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2016, for all in-the-money options. As of December 31, 2016, total compensation expense related to unvested stock options granted to employees but not yet recognized was $15.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.8 years.

[0001262039-17-000008:notes:97]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2016, as follows (in thousands, except exercise prices and contractual life):

[0001262039-17-000008:notes:98]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $8.43–8.99 |  | 554 |  |  | 0.19 |  | $ | 8.52 |  |  | 554 |  |  | $ | 8.52 |  |
| 15.28–19.94 |  | 110 |  |  | 1.77 |  | 16.74 |  |  | 100 |  |  | 16.43 |  |
| 20.13–24.92 |  | 3,381 |  |  | 3.22 |  | 22.00 |  |  | 2,187 |  |  | 21.08 |  |
| 26.49–26.70 |  | 1,248 |  |  | 2.18 |  | 26.69 |  |  | 1,226 |  |  | 26.70 |  |
| 31.39–33.31 |  | 627 |  |  | 5.88 |  | 32.75 |  |  | 144 |  |  | 32.92 |  |
| 38.73–48.83 |  | 267 |  |  | 5.46 |  | 46.59 |  |  | 102 |  |  | 46.25 |  |
|  |  | 6,187 |  |  |  |  |  |  | 4,313 |  |  |  |

[0001262039-17-000008:notes:99]
Employee Stock Purchase Plan

[0001262039-17-000008:notes:100]
In determining the fair value of our ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-17-000008:notes:101]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 39 | % |  | 30 | % |  | 34 | % |
| Risk-free interest rate | 0.4 | % |  | 0.2 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-17-000008:notes:102]
Shares Reserved for Future Issuances

[0001262039-17-000008:notes:103]
Stock-based Compensation Expense

[0001262039-17-000008:notes:104]
Stock-based compensation expense is included in costs and expenses as follows (in thousands):

[0001262039-17-000008:notes:105]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Cost of product revenue | $ | 1,200 |  |  | $ | 973 |  |  | $ | 483 |  |
| Cost of service revenue | 8,771 |  |  | 7,121 |  |  | 5,826 |  |
| Research and development | 30,120 |  |  | 24,555 |  |  | 17,264 |  |
| Sales and marketing | 68,113 |  |  | 49,436 |  |  | 26,744 |  |
| General and administrative | 14,219 |  |  | 13,003 |  |  | 8,677 |  |
| Total stock-based compensation expense | $ | 122,423 |  |  | $ | 95,088 |  |  | $ | 58,994 |  |

[0001262039-17-000008:notes:106]
Share Repurchase Program

[0001262039-17-000008:notes:107]
In January 2016, our board of directors approved the 2016 Repurchase Program which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In October 2016, our board of directors authorized the purchase of an additional $100.0 million of shares of our common stock under the 2016 Repurchase Program, increasing our current authorization to $300.0 million through December 31, 2017. Under the 2016 Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The 2016 Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2016, we repurchased 3.9 million shares of common stock under the 2016 Repurchase Program in open market transactions for an aggregate purchase price of $110.8 million. As of December 31, 2016, $189.2 million remained available for future share repurchases under the 2016 Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-17-000008:notes:108]
NET INCOME PER SHARE

[0001262039-17-000008:notes:109]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of RSUs, including PSUs, stock options and the ESPP. Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-17-000008:notes:110]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-17-000008:notes:111]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 32,187 |  |  | $ | 7,987 |  |  | $ | 25,343 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 172,621 |  |  | 170,385 |  |  | 163,831 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 172,621 |  |  | 170,385 |  |  | 163,831 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs (including PSUs) | 1,891 |  |  | 2,260 |  |  | 844 |  |
| Stock options | 1,757 |  |  | 3,427 |  |  | 4,583 |  |
| ESPP | 69 |  |  | 69 |  |  | 31 |  |
| Weighted-average shares used to compute diluted net income per share | 176,338 |  |  | 176,141 |  |  | 169,289 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 0.19 |  |  | $ | 0.05 |  |  | $ | 0.15 |  |
| Diluted | $ | 0.18 |  |  | $ | 0.05 |  |  | $ | 0.15 |  |

[0001262039-17-000008:notes:112]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-17-000008:notes:113]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| RSUs (including PSUs) | 3,319 |  |  | 1,393 |  |  | 768 |  |
| Stock options | 1,024 |  |  | 382 |  |  | 3,469 |  |
| ESPP | 159 |  |  | 94 |  |  | 99 |  |
|  | 4,502 |  |  | 1,869 |  |  | 4,336 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-17-000008:notes:114]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-17-000008:notes:115]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in thousands):

[0001262039-17-000008:notes:116]
|  | December 31, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 311,980 |  |  | $ | (910 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 325,521 |  |  | $ | (925 | ) |
| Municipal bonds | 52,200 |  |  | (235 | ) |  | — |  |  | — |  |  | 52,200 |  |  | (235 | ) |
| U.S. government and agency securities | 33,430 |  |  | (79 | ) |  | — |  |  | — |  |  | 33,430 |  |  | (79 | ) |
| Commercial paper | 17,394 |  |  | (25 | ) |  | — |  |  | — |  |  | 17,394 |  |  | (25 | ) |
| Total available-for-sale securities | $ | 415,004 |  |  | $ | (1,249 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 428,545 |  |  | $ | (1,264 | ) |

[0001262039-17-000008:notes:117]
|  | December 31, 2015 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 348,534 |  |  | $ | (1,187 | ) |  | $ | 42,033 |  |  | $ | (182 | ) |  | $ | 390,567 |  |  | $ | (1,369 | ) |
| Commercial paper | 31,977 |  |  | (34 | ) |  | — |  |  | — |  |  | 31,977 |  |  | (34 | ) |
| Municipal bonds | 41,677 |  |  | (36 | ) |  | 1,008 |  |  | (4 | ) |  | 42,685 |  |  | (40 | ) |
| U.S. government and agency securities | 34,703 |  |  | (42 | ) |  | — |  |  | — |  |  | 34,703 |  |  | (42 | ) |
| Total available-for-sale securities | $ | 456,891 |  |  | $ | (1,299 | ) |  | $ | 43,041 |  |  | $ | (186 | ) |  | $ | 499,932 |  |  | $ | (1,485 | ) |

[0001262039-17-000008:notes:118]
The contractual maturities of our investments are as follows (in thousands):

[0001262039-17-000008:notes:119]
|  | December 31, 2016 |  | December 31, 2015 |
| Due within one year | $ | 376,522 |  |  | $ | 348,074 |  |
| Due within one to three years | 224,983 |  |  | 272,959 |  |
| Total | $ | 601,505 |  |  | $ | 621,033 |  |

[0001262039-17-000008:notes:120]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in total comprehensive income. Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other expense—net in our consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-17-000008:notes:121]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of December 31, 2016.

[0001262039-17-000008:notes:122]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-17-000008:notes:123]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-17-000008:notes:124]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-17-000008:notes:125]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-17-000008:notes:126]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-17-000008:notes:127]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-17-000008:notes:128]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-17-000008:notes:129]
Fair Value of Financial Instruments

[0001262039-17-000008:notes:130]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-17-000008:notes:131]
The following table presents the fair value of our financial assets measured at fair value on a recurring basis as of December 31, 2016 and December 31, 2015 (in thousands):

[0001262039-17-000008:notes:132]
|  | December 31, 2016 |  |  |  | December 31, 2015 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 378,612 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |
| Commercial paper | 105,097 |  |  | — |  |  | 105,097 |  |  | — |  |  | 69,231 |  |  | — |  |  | 69,231 |  |  | — |  |
| U.S. government and agency securities | 64,541 |  |  | 52,082 |  |  | 12,459 |  |  | — |  |  | 41,688 |  |  | 25,693 |  |  | 15,995 |  |  | — |  |
| Municipal bonds | 59,025 |  |  | — |  |  | 59,025 |  |  | — |  |  | 61,022 |  |  | — |  |  | 61,022 |  |  | — |  |
| Money market funds | 38,649 |  |  | 38,649 |  |  | — |  |  | — |  |  | 50,030 |  |  | 50,030 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 4,219 |  |  | — |  |  | 4,219 |  |  | — |  |  | 14,897 |  |  | — |  |  | 14,897 |  |  | — |  |
| Total | $ | 650,143 |  |  | $ | 90,731 |  |  | $ | 559,412 |  |  | $ | — |  |  | $ | 674,062 |  |  | $ | 75,723 |  |  | $ | 598,339 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 48,638 |  |  |  |  |  |  |  |  | $ | 53,029 |  |  |  |  |  |  |  |
| Short-term investments | 376,522 |  |  |  |  |  |  |  |  | 348,074 |  |  |  |  |  |  |  |
| Long-term investments | 224,983 |  |  |  |  |  |  |  |  | 272,959 |  |  |  |  |  |  |  |
| Total | $ | 650,143 |  |  |  |  |  |  |  |  | $ | 674,062 |  |  |  |  |  |  |  |

[0001262039-17-000008:notes:133]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the year ended December 31, 2016 and December 31, 2015.

[0001262039-17-000008:notes:134]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001262039-17-000008:notes:135]
We measure certain assets, including goodwill, other intangible assets—net and investments in privately-held companies at fair value on a nonrecurring basis when there are identifiable events or changes in circumstances that may have a significant adverse impact on the fair value of these assets.

[0001262039-17-000008:notes:136]
During the second quarter of 2015, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationship acquired from the Coyote Point Systems (“Coyote”) business acquisition. Based on this reassessment, we determined a decrease in the projected cash flow and that the remaining net book value of the developed technologies and customer relationships were impaired. As a result, we recorded an impairment charge of $1.6 million associated with these assets. The impairment charge is included within cost of product revenue and sales and marketing in the consolidated statements of operations.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-17-000008:notes:137]
Foreign Currency Translation and Transaction Gains and Losses—Prior to the third quarter of 2014, the assets and liabilities of our international subsidiaries were translated into U.S. dollars using the applicable exchange rates. The resulting foreign translation adjustments were included in the consolidated balance sheets as a component of accumulated other comprehensive income (loss) and in the consolidated statements of comprehensive income.

[0001262039-17-000008:notes:138]
In the third quarter of 2014, we reevaluated the selected functional currency of our international subsidiaries and recorded the cumulative impact of the reevaluation of the functional currency in the consolidated statement of operations.

[0001262039-17-000008:notes:139]
Beginning in the third quarter of 2014, the functional currency of our foreign subsidiaries is the U.S. dollar.   Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-17-000008:notes:140]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-17-000008:notes:141]
Goodwill

[0001262039-17-000008:notes:142]
There were no impairments to goodwill during 2016. The following table presents the changes in the carrying amount of goodwill (in thousands):

[0001262039-17-000008:notes:143]
|  | Amount |
| Balance—December 31, 2015 | $ | 4,692 |  |
| Addition due to business acquisition | 9,861 |  |
| Balance—December 31, 2016 | $ | 14,553 |  |

[0001262039-17-000008:notes:144]
Other Intangible Assets—net

[0001262039-17-000008:notes:145]
The following tables present other intangible assets—net (in thousands):

[0001262039-17-000008:notes:146]
|  | December 31, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 8,750 |  |  | $ | 15,234 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 6,506 |  |  | 7,994 |  |
|  |  |  | 38,484 |  |  | 15,256 |  |  | 23,228 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 15,256 |  |  | $ | 24,828 |  |

[0001262039-17-000008:notes:147]
|  | December 31, 2015 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Customer relationships | 5.0 |  | $ | 12,200 |  |  | $ | 1,220 |  |  | $ | 10,980 |  |
| Developed technologies | 3.6 |  | 11,384 |  |  | 4,724 |  |  | 6,660 |  |
| Total other intangible assets—net |  |  | $ | 23,584 |  |  | $ | 5,944 |  |  | $ | 17,640 |  |

[0001262039-17-000008:notes:148]
During 2015, we reassessed the fair value and the remaining useful life of the developed technologies and customer relationships acquired from the Coyote business acquisition. Based on this reassessment, we determined a decrease in the projected cash flow and that the remaining net book value of the developed technologies and customer relationships were impaired. As a result, we recorded an impairment charge of $1.6 million associated with these assets. The impairment charge is included within cost of product revenue and sales and marketing in the consolidated statements of operations.

[0001262039-17-000008:notes:149]
Amortization expense was $9.3 million, $3.2 million, and $1.5 million in 2016, 2015 and 2014, respectively. The following table summarizes estimated future amortization expense of other intangible assets—net (in thousands):

[0001262039-17-000008:notes:150]
|  | Amount |
| Years: |  |
| 2017 | $ | 8,574 |  |
| 2018 | 6,885 |  |
| 2019 | 5,406 |  |
| 2020 | 2,363 |  |
| Total | $ | 23,228 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001262039-17-000008:notes:151]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-17-000008:notes:152]
INCOME TAXES

[0001262039-17-000008:notes:153]
Income before income taxes consisted of the following (in thousands):

[0001262039-17-000008:notes:154]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Domestic | $ | (49,707 | ) |  | $ | (37,437 | ) |  | $ | 35,778 |  |
| Foreign | 92,855 |  |  | 54,442 |  |  | 25,771 |  |
| Total income before income taxes | $ | 43,148 |  |  | $ | 17,005 |  |  | $ | 61,549 |  |

[0001262039-17-000008:notes:155]
The provision for income taxes consisted of the following (in thousands):

[0001262039-17-000008:notes:156]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Current: |  |  |  |  |  |
| Federal | $ | 7,904 |  |  | $ | 9,864 |  |  | $ | 17,717 |  |
| State | 803 |  |  | (136 | ) |  | 1,110 |  |
| Foreign | 17,829 |  |  | 13,683 |  |  | 8,921 |  |
| Total current | $ | 26,536 |  |  | $ | 23,411 |  |  | $ | 27,748 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (10,037 | ) |  | $ | (9,383 | ) |  | $ | 6,742 |  |
| State | (4,861 | ) |  | (2,988 | ) |  | (36 | ) |
| Foreign | (677 | ) |  | (2,022 | ) |  | 1,752 |  |
| Total deferred | (15,575 | ) |  | (14,393 | ) |  | 8,458 |  |
| Provision for income taxes | $ | 10,961 |  |  | $ | 9,018 |  |  | $ | 36,206 |  |

[0001262039-17-000008:notes:157]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in thousands):

[0001262039-17-000008:notes:158]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Tax at federal statutory tax rate | $ | 15,096 |  |  | $ | 5,951 |  |  | $ | 21,542 |  |
| Stock-based compensation expense | 10,010 |  |  | 6,369 |  |  | 7,367 |  |
| State taxes—net of federal benefit | (4,252 | ) |  | (2,454 | ) |  | 975 |  |
| Foreign tax credit | (34,992 | ) |  | (6,901 | ) |  | (4,433 | ) |
| Research and development credit | (2,713 | ) |  | (3,529 | ) |  | (880 | ) |
| Foreign income taxed at different rates | (13,681 | ) |  | (11,225 | ) |  | (406 | ) |
| Foreign withholding taxes | 14,998 |  |  | 10,962 |  |  | 9,085 |  |
| Foreign dividend distribution | 27,295 |  |  | 9,647 |  |  | — |  |
| Other | (800 | ) |  | 198 |  |  | 2,956 |  |
| Total provision for income taxes | $ | 10,961 |  |  | $ | 9,018 |  |  | $ | 36,206 |  |

[0001262039-17-000008:notes:159]
Significant permanent differences arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock option grants to certain foreign employees, offset by the actual tax benefits in the current periods from disqualifying dispositions of shares held by our U.S. employees. For stock options exercised by our U.S. employees, we receive an income tax benefit calculated as the difference between the fair market value of the stock issued at the time of the exercise and the option price, tax effected. In 2016, we early adopted ASU 2016-09 and all the excess tax benefits were recognized in income tax provision. For 2015, income tax payable was reduced by excess tax benefits from the exercise or vesting of stock-based awards of $1.3 million. For 2014, income tax payable was not reduced by excess tax benefits from the exercise or vesting of stock-based awards, therefore we did not recognize a significant benefit in additional paid-in-capital.

[0001262039-17-000008:notes:160]
During 2016, we repatriated $55.0 million of foreign earnings and profits. A decision was made to bring this cash back to the U.S. as it carried a foreign tax credit of $22.3 million.

[0001262039-17-000008:notes:161]
Our 2015 income tax provision reflected a $1.2 million tax benefit due to a recent U.S. Tax Court opinion involving an independent third party filed on July 27, 2015. Based on the findings of the U.S. Tax Court, we recognized the tax benefit for excluding the share-based compensation from intercompany charges in prior periods.

[0001262039-17-000008:notes:162]
During 2015, we completed a corporate reorganization to convert our Canadian company to a branch of our U.S. company resulting on a $27.6 million deemed dividend distribution. The tax impact of the Canadian deemed dividend distribution of $9.6 million was partially offset by an additional tax benefit of $6.4 million due to the deferred tax benefit of the Canadian stock based compensation expense.

[0001262039-17-000008:notes:163]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in thousands):

[0001262039-17-000008:notes:164]
|  | December 31, 2016 |  | December 31, 2015 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforward | $ | 24,348 |  |  | $ | 9,757 |  |
| Deferred revenue | 41,877 |  |  | 39,509 |  |
| Nondeductible reserves and accruals | 27,029 |  |  | 22,240 |  |
| Depreciation and amortization | 5,776 |  |  | 2,873 |  |
| General business credit carryforward | 62,705 |  |  | 22,121 |  |
| Stock-based compensation expense | 20,943 |  |  | 22,714 |  |
| Other | 67 |  |  | 2 |  |
| Total deferred tax assets | $ | 182,745 |  |  | $ | 119,216 |  |

[0001262039-17-000008:notes:165]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we would be able to realize the benefits of our deferred tax assets in the future.

[0001262039-17-000008:notes:166]
As of December 31, 2016, we had $44.9 million in federal net operating loss carryforwards to offset future income, which is limited by Section 382 of the Internal Revenue Code (“Section 382”) due to the acquisition of Meru and AccelOps. With the acquisition of Meru, we had $22.6 million in federal net operating loss carryforwards which is limited by Section 382 available from year 2020. With the acquisition of AccelOps, we had $22.3 million in federal net operating loss carryforwards which is limited by Section 382 available from year 2016.  We had $54.2 million federal tax credits with certain amount available to carryback and claim federal tax refunds from prior year and the rest available to offset future federal taxes. As of December 31, 2016, we had $47.3 million in California net operating loss carryforwards, $9.9 million of which can be used to offset future income and which will not expire until 2031. With the acquisition of Meru and AccelOps, we also had $22.1 million and $15.3 million in California net operating loss carryforwards, respectively, which is subject to Section 382 limitation. We had state tax credit carryforwards of $17.4 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-17-000008:notes:167]
Our policy with respect to undistributed foreign subsidiaries’ earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision of U.S. federal and state income taxes has been provided on such earnings. Upon distribution of those earnings in the form of dividends or otherwise, we would be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various foreign countries. As of December 31, 2016, we have not recorded U.S. income tax on $45.4 million of foreign earnings that are deemed to be permanently reinvested overseas.

[0001262039-17-000008:notes:168]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2021, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-17-000008:notes:169]
As of December 31, 2016, we had $65.5 million of unrecognized tax benefits, of which, if recognized, $64.1 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2016, 2015 and 2014, accrued interest and penalties were $9.5 million, $5.5 million and $1.7 million, respectively.

[0001262039-17-000008:notes:170]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in thousands):

[0001262039-17-000008:notes:171]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Unrecognized tax benefits, beginning of year | $ | 59,672 |  |  | $ | 44,151 |  |  | $ | 29,604 |  |
| Gross increases for tax positions related to the current year | 4,837 |  |  | 17,478 |  |  | 14,547 |  |
| Gross increases for tax positions related to the prior year | 1,762 |  |  | 8,319 |  |  | — |  |
| Gross decreases for tax positions related to prior year | (737 | ) |  | (9,207 | ) |  | — |  |
| Gross decreases for tax positions related to expiration of statute of limitations | — |  |  | (1,069 | ) |  | — |  |
| Unrecognized tax benefits, end of year | $ | 65,534 |  |  | $ | 59,672 |  |  | $ | 44,151 |  |

[0001262039-17-000008:notes:172]
As of December 31, 2016, 2015 and 2014, $68.6 million, $60.6 million and $45.1 million, respectively, of the amounts reflected above were recorded as Income tax liabilities—non-current in our consolidated balance sheet.

[0001262039-17-000008:notes:173]
As of December 31, 2016, there was no unrecognized tax benefits that we expect would change significantly over the next 12 months.

[0001262039-17-000008:notes:174]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for tax year 2014, 2013 and 2012.


## us-gaap:IncomeTaxPolicyTextBlock

[0001262039-17-000008:notes:175]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-17-000008:notes:176]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-17-000008:notes:177]
INVENTORY

[0001262039-17-000008:notes:178]
Inventory consisted of the following (in thousands):

[0001262039-17-000008:notes:179]
|  | December 31, 2016 |  | December 31, 2015 |
| Raw materials | $ | 18,924 |  |  | $ | 15,425 |  |
| Finished goods | 87,963 |  |  | 68,443 |  |
| Inventory | $ | 106,887 |  |  | $ | 83,868 |  |

[0001262039-17-000008:notes:180]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.0 million and $1.1 million as of December 31, 2016 and 2015, respectively. Inventory also includes materials at contract manufacturers of $6.1 million and $4.9 million as of December 31, 2016 and 2015, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001262039-17-000008:notes:181]
Inventory—Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.


## us-gaap:LeasePolicyTextBlock

[0001262039-17-000008:notes:182]
Leases—We rent certain facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-17-000008:notes:183]
| Property and Equipment—net | December 31, 2016 |  | December 31, 2015 |
| Americas: |  |  |  |
| U.S. | $ | 96,414 |  |  | $ | 61,064 |  |
| Other Americas | 13,488 |  |  | 8,972 |  |
| Total Americas | 109,902 |  |  | 70,036 |  |
| EMEA: |  |  |  |
| France | 13,241 |  |  | 13,201 |  |
| Other EMEA | 6,391 |  |  | 3,977 |  |
| Total EMEA | 19,632 |  |  | 17,178 |  |
| APAC | 7,715 |  |  | 3,853 |  |
| Total property and equipment—net | $ | 137,249 |  |  | $ | 91,067 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-17-000008:notes:184]
Recently Adopted Accounting Standards

[0001262039-17-000008:notes:185]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. ASU 2016-09 also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur.

[0001262039-17-000008:notes:186]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits of $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016.

[0001262039-17-000008:notes:187]
Under the new guidance, we have elected to change our policy and have started to recognize forfeitures of awards as they occur. The change in forfeiture policy was adopted using a modified retrospective transition method. We recorded a cumulative-effect adjustment to decrease retained earnings by $0.8 million upon transition on January 1, 2016 and a retrospective decrease of stock-based compensation of $2.0 million during the first quarter of 2016.

[0001262039-17-000008:notes:188]
The amendment to the minimum statutory withholding tax requirements was adopted on a modified retrospective basis. The adoption had no impact on the January 1, 2016 retained earnings. In addition, we adopted the presentation of taxes paid related to net share settlement of equity awards as a financing activity on the statement of cash flows on a retrospective basis. Our adoption had no impact to any of the periods presented in our consolidated cash flows statements since such cash flows have historically been presented as a financing activity.

[0001262039-17-000008:notes:189]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for the three months ended March 31, 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

[0001262039-17-000008:notes:190]
|  | Three Months Ended |
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Statements of Operations: |  |  |  |
| Stock-based compensation expense | $ | 30,881 |  |  | $ | 28,901 |  |
| Benefit from income taxes | $ | (1,809 | ) |  | $ | (5,376 | ) |
| Net income (loss) | $ | (3,429 | ) |  | $ | 2,118 |  |
| Net income (loss) per share—Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Net income (loss) per share—Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding—Diluted | 171,745 |  |  | 174,421 |  |

[0001262039-17-000008:notes:191]
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Balance Sheets: |  |  |  |
| Deferred tax assets | $ | 131,696 |  |  | $ | 167,625 |  |
| Additional paid-in capital | $ | 718,849 |  |  | $ | 717,671 |  |
| Retained earnings | $ | 23,089 |  |  | $ | 60,196 |  |

[0001262039-17-000008:notes:192]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 has not had any impact on our consolidated financial statements.

[0001262039-17-000008:notes:193]
Recent Accounting Standards Not Yet Effective

[0001262039-17-000008:notes:194]
In January 2017, the FASB issued ASU 2017-04—Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill.  Under this ASU, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2016-06 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We will adopt ASU 2017-04 in the fourth quarter of 2017. We do not believe that this standard will have a material impact on our consolidated financial statements.

[0001262039-17-000008:notes:195]
In November 2016, the FASB issued ASU 2016-18—Statement of Cash Flows, which provides guidance on the classification of restricted cash to be included with cash and cash equivalents when reconciling the beginning of period and end of period total amounts on the statement of cash flows. This pronouncement is effective for us beginning on January 1, 2018, using a retrospective adoption method. We early adopted ASU 2016-18 on January 1, 2017. The adoption of ASU 2016-18 did not have a material impact on our consolidated financial statements.

[0001262039-17-000008:notes:196]
In October 2016, the FASB issued ASU 2016-16—Income Taxes —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

[0001262039-17-000008:notes:197]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of ASU 2016-13 will have on our consolidated financial statements.

[0001262039-17-000008:notes:198]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. We currently anticipate to early adopt this new standard on January 1, 2018 in conjunction with our adoption of the new revenue standard. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to restate prior period financial statements. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized could be at least $50.0 million. We are continuing to evaluate the impact of the standard and our estimate is subject to change.  We do not believe that the standard will have a material impact on our statement of operations.

[0001262039-17-000008:notes:199]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, in doing so, it is possible more judgment and estimates may be required within the revenue recognition process than required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to the standard, including clarification on accounting for licenses of intellectual property and identifying performance obligations. The new standard will be effective for us beginning January 1, 2018 which is the required mandatory adoption date and we do not plan to early adopt. The two permitted transition methods under the new standard are the full retrospective method, in which case the standard would be applied to each prior reporting period presented and the cumulative effect of applying the standard would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying the standard would be recognized at the date of initial application. Currently, we are in the process of reviewing our historical contracts to quantify the impact on our consolidated financial statements. Depending on the results of our review, there could be changes to the timing of revenue recognition and certain costs associated with obtaining and fulfilling our customer contracts. These changes may include the acceleration of revenue and associated costs on sales to certain channel partners that are currently accounted for only once the product is sold through to the end-customer, and the amortization of certain costs related to obtaining customer contracts that include the sales commission we pay to certain employees. We are also in the process of assessing the appropriate changes to our business processes and upgrading our systems and controls to support recognition and disclosure under the new standard. We expect to complete our assessment process, including selecting a transition method for adoption, in the second quarter of 2017.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-17-000008:notes:200]
PROPERTY AND EQUIPMENT—Net

[0001262039-17-000008:notes:201]
Property and equipment—net consisted of the following (in thousands):

[0001262039-17-000008:notes:202]
|  | December 31, 2016 |  | December 31, 2015 |
| Land | $ | 35,079 |  |  | $ | 21,683 |  |
| Building and building improvements | 49,783 |  |  | 28,841 |  |
| Computer equipment and software | 65,323 |  |  | 45,632 |  |
| Evaluation units | 20,173 |  |  | 15,784 |  |
| Leasehold improvements | 18,699 |  |  | 11,179 |  |
| Furniture and fixtures | 13,995 |  |  | 8,901 |  |
| Construction-in-progress | 4,669 |  |  | 8,106 |  |
| Total property and equipment | 207,721 |  |  | 140,126 |  |
| Less: accumulated depreciation | (70,472 | ) |  | (49,059 | ) |
| Property and equipment—net | $ | 137,249 |  |  | $ | 91,067 |  |

[0001262039-17-000008:notes:203]
Depreciation expense was $39.2 million, $28.4 million and $20.5 million in 2016, 2015 and 2014, respectively.

[0001262039-17-000008:notes:204]
In 2016, we purchased certain real estate properties to support the growth in our business operations, for total cash consideration of $27.1 million, of which $13.4 million was allocated to land, $11.0 million was allocated to building and $2.7 million remains in construction in progress as one building has not yet been placed in service.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-17-000008:notes:205]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-17-000008:notes:206]
RELATED PARTY TRANSACTIONS

[0001262039-17-000008:notes:207]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.4 million, $7.2 million and $1.7 million in 2016, 2015 and 2014, respectively. Of such amounts, $2.5 million was incurred under contingent fee arrangements in 2015. There were no expenses incurred under contingent fee arrangements in 2016 and 2014. Amounts due and payable to the law firm were $0.1 million and $5.3 million as of December 31, 2016 and December 31, 2015, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-17-000008:notes:208]
RESTRUCTURING CHARGES

[0001262039-17-000008:notes:209]
The following table provides a summary of restructuring activity for the years 2016 and 2015 (in thousands):

[0001262039-17-000008:notes:210]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Balance as of December 31, 2014 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Costs incurred | 7,109 |  |  | 491 |  |  | 7,600 |  |
| Less cash payments | (3,104 | ) |  | (71 | ) |  | (3,175 | ) |
| Less non-cash items | (316 | ) |  | (191 | ) |  | (507 | ) |
| Balance as of December 31, 2015 | 3,689 |  |  | 229 |  |  | 3,918 |  |
| Costs incurred | 3,246 |  |  | 751 |  |  | 3,997 |  |
| Less cash payments | (5,933 | ) |  | (664 | ) |  | (6,597 | ) |
| Less non-cash items | (89 | ) |  | (78 | ) |  | (167 | ) |
| Balance as of December 31, 2016 | $ | 913 |  |  | $ | 238 |  |  | $ | 1,151 |  |

[0001262039-17-000008:notes:211]
2016 Restructuring

[0001262039-17-000008:notes:212]
In 2016, we implemented a plan to restructure and further improve efficiencies in our operations due to the acquisition of AccelOps and certain other activities. To date, we have incurred $3.7 million related to this restructuring. These charges are primarily related to severance payments to be paid in cash and are included in operating expense in the consolidated statements of operations. We do not anticipate incurring additional significant charges related to this restructuring.

[0001262039-17-000008:notes:213]
The remaining restructuring reserve of $0.5 million is included in accrued liabilities on the consolidated balance sheet as of December 31, 2016 and is expected to be paid in 2017.

[0001262039-17-000008:notes:214]
2015 Meru Restructuring

[0001262039-17-000008:notes:215]
In connection with the acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies starting in the third quarter of 2015. To date, we have incurred $7.9 million of charges related to this restructuring. These charges are primarily related to severance payments to be paid in cash and are included in operating expense in the consolidated statements of operations of the period when incurred. We incurred $0.3 million of charges related to this restructuring during the twelve months ended December 31, 2016, respectively, and these charges are included in operating expense in the consolidated statements of operations. We do not anticipate incurring additional charges related to this restructuring.

[0001262039-17-000008:notes:216]
The remaining restructuring reserve of $0.7 million is included in accrued liabilities on the consolidated balance sheet as of December 31, 2016 and is expected to be paid in 2017.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-17-000008:notes:217]
|  | Year Ended December 31, |
| Revenue | 2016 |  | 2015 |  | 2014 |
| Americas: |  |  |  |  |  |
| U.S. | $ | 332,194 |  |  | $ | 279,564 |  |  | $ | 200,294 |  |
| Canada | 138,486 |  |  | 101,594 |  |  | 81,968 |  |
| Other Americas | 66,026 |  |  | 54,124 |  |  | 42,397 |  |
| Total Americas | 536,706 |  |  | 435,282 |  |  | 324,659 |  |
| EMEA | 477,393 |  |  | 366,018 |  |  | 270,537 |  |
| APAC | 261,344 |  |  | 207,968 |  |  | 175,168 |  |
| Total revenue | $ | 1,275,443 |  |  | $ | 1,009,268 |  |  | $ | 770,364 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001262039-17-000008:notes:218]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over twelve months or longer.

[0001262039-17-000008:notes:219]
Revenue Recognition—We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-17-000008:notes:220]
Revenue is recognized when all of the following criteria have been met:

[0001262039-17-000008:notes:221]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-17-000008:notes:222]
| • | Delivery has occurred or services have been rendered. Product delivery occurs when we fulfill an order and title and risk of loss has been transferred. Delivery of software license occurs upon electronic transfer of the license key to the customer. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and, to a lesser extent, up to five years, and is generally recognized upon delivery or completion of service. |

[0001262039-17-000008:notes:223]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-17-000008:notes:224]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-17-000008:notes:225]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is typically not fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance.

[0001262039-17-000008:notes:226]
We recognize software license revenue upon delivery.  To date, software license revenues have not represented a significant percentage of the Company's total revenues.

[0001262039-17-000008:notes:227]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel and hardware support. We recognize revenue from these services ratably over the contractual service period. Revenue related to subsequent renewals of these services are recognized over the term of the renewal agreement.

[0001262039-17-000008:notes:228]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-17-000008:notes:229]
Service revenue consists of sales from our FortiGuard security subscription and FortiCare technical support services, professional and training services and other services that include SaaS and IaaS (both of which are hosted or cloud-based services). The Company recognizes revenue from these arrangements as the subscription service is delivered over the term which is typically one year or on a monthly usage basis. To date, SaaS and IaaS revenues have not represented a significant percentage of the Company’s total revenues.

[0001262039-17-000008:notes:230]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using VSOE of selling price, if it exists, or TPE of selling price. If neither VSOE nor TPE of selling price exists for a deliverable, we use our BESP for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-17-000008:notes:231]
For our hardware products, we use BESP as our selling price. For our support, software licenses and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-17-000008:notes:232]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0001262039-17-000008:notes:233]
The estimated useful life and fair values of the acquired identifiable intangible assets were as follows (in thousands, except for estimated useful life):


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001262039-17-000008:notes:234]
The notional amount of forward exchange contracts as of December 31, 2016 and 2015 were (in thousands):

[0001262039-17-000008:notes:235]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of December 31, 2016 |  |  |  |
| CAD | Sell |  | $ | 2,615 |  |
| Currency—As of December 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 7,011 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-17-000008:notes:236]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-17-000008:notes:237]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Sales Returns Reserve and Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 6,228 |  |  | $ | 6,204 |  |  | $ | 4,605 |  |
| Charged to costs and expenses, net of deductions | 5,007 |  |  | 24 |  |  | 1,599 |  |
| Ending balance | $ | 11,235 |  |  | $ | 6,228 |  |  | $ | 6,204 |  |

[0001262039-17-000008:notes:238]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-17-000008:notes:239]
| 3. | Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately following the signature page of this Annual Report on Form 10-K. |

[0001262039-17-000008:notes:240]
(b) Exhibits:

[0001262039-17-000008:notes:241]
The exhibit list in the Exhibit Index immediately following the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-17-000008:notes:242]
(c) Financial Statement Schedules: See Item 15(a) above.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-17-000008:notes:243]
SEGMENT INFORMATION

[0001262039-17-000008:notes:244]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.

[0001262039-17-000008:notes:245]
Revenue by geographic region is based on the billing address of the customer. The following tables set forth revenue and property and equipment—net by geographic region (in thousands):


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001262039-17-000008:notes:246]
Shipping and Handling—Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-17-000008:notes:247]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-17-000008:notes:248]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a leading provider of network security appliances to enterprises, service providers and government organizations worldwide. Fortinet’s solutions are designed to integrate multiple levels of security protection, including firewall, VPN, application control, anti-malware, intrusion prevention, web filtering, vulnerability management, anti-spam, mobile security, wireless controller and WAN acceleration. Our security solutions are fast, secure and designed to provide broad, rapid protection against dynamic security threats while simplifying the IT infrastructure of our end-customers worldwide.

[0001262039-17-000008:notes:249]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the BESP for our products and services, stock-based compensation, inventory valuation, fair value of assets acquired and liabilities assumed in business combinations, measurement of liabilities for uncertain tax positions and deferred tax assets, assessment of recoverability of our goodwill and other long-lived assets, sales returns reserve, restructuring expenses and other loss contingencies. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-17-000008:notes:250]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable and we maintain reserves for estimated potential credit losses. As of December 31, 2016, two distributors, Exclusive and Fine Tec Computer, accounted for 26% and 10% of total net accounts receivable, respectively. At December 31, 2015, one distributor, Exclusive, accounted for 23% of total net accounts receivable.

[0001262039-17-000008:notes:251]
During 2014, 2015 and 2016, Exclusive accounted for 15%, 18% and 20% of total revenue, respectively.

[0001262039-17-000008:notes:252]
Financial Instruments and Fair Value—We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-17-000008:notes:253]
Beginning in the third quarter of 2014, the functional currency of our foreign subsidiaries is the U.S. dollar.   Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period. Foreign currency remeasurement losses of $6.6 million, $3.2 million and $3.2 million, are included in other expense—net for 2016, 2015 and 2014, respectively.

[0001262039-17-000008:notes:254]
Other Investments—Investments in privately-held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets and are accounted for under the cost method. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts as well as current fundraising activities and valuations based on information provided by these privately-held companies. If it is determined that an other-than-temporary decline exists in an equity security, we write down the investment to its fair value and record the related impairment as an investment loss in our consolidated statements of operations.

[0001262039-17-000008:notes:255]
Consolidation of Variable Interest Entities—We use a qualitative approach in assessing the consolidation requirement for variable interest entities (“VIEs”). This approach focuses on determining whether we have the power to direct the activities of the VIE that most significantly affect the VIE’s economic performance and whether we have the obligation to absorb losses, or the right to receive benefits, that could potentially be significant to the VIE. For all periods presented in the accompanying consolidated financial statements, we have determined that we are not the primary beneficiary of any VIEs.

[0001262039-17-000008:notes:256]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-17-000008:notes:257]
Goodwill —Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform our annual goodwill impairment analysis at the reporting unit level. As of December 31, 2016, we had one reporting unit.  The impairment analysis utilizes a quantitative assessment using a two-step impairment test. The first step is to compare the reporting unit’s carrying value, including goodwill, to the fair value. If the fair value exceeds the carrying value, then no potential impairment is considered to exist. If the carrying value exceeds the fair value, the second step is performed to determine if the implied fair value of the reporting unit’s goodwill exceeds the carrying value of the reporting unit. An impairment charge would be recorded if the carrying value exceeds the implied fair value. Impairment charges, if any, are recorded in general and administrative expenses. We have not been required to perform this second step of the process because the fair value of our reporting unit exceeded the net book value as of December 31, 2016.

[0001262039-17-000008:notes:258]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line and accelerated method over the estimated economic lives of the assets, which range from one to five years.

[0001262039-17-000008:notes:259]
Stock-Based Compensation—The fair value of RSUs is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes option pricing model to determine the fair value of our employee stock options and ESPP. Performance stock units (“PSUs”) are RSUs that contain both service-based and market-based vesting conditions. PSUs vest over a specified service period upon the satisfaction of certain market-based vesting conditions, and settle into shares of our common stock upon vesting over a two- or three-year period. The fair value of a PSU is calculated using the Monte Carlo simulation model on the date of grant and is based on the market price of our common stock on the date of grant modified to reflect the impact of the market-based vesting condition, including the estimated payout level based on that condition. We do not adjust compensation cost for subsequent changes in the expected outcome of the market-based vesting conditions. Stock-based compensation expense is amortized on a straight-line basis.

[0001262039-17-000008:notes:260]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of operations. Our advertising expenses were not significant for any periods presented.

[0001262039-17-000008:notes:261]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-17-000008:notes:262]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of operations.

[0001262039-17-000008:notes:263]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-17-000008:notes:264]
Accounts Receivable—Trade accounts receivable are recorded at the invoiced amount, net of sales returns reserve and allowances for doubtful accounts. The sales returns reserve is determined based on specific criteria including agreements to provide rebates and other factors known at the time, as well as estimates of the amount of goods shipped that will be returned. To determine the adequacy of the sales returns reserve, we analyze historical experience of actual rebates and returns. The sales returns reserve was $10.3 million and $5.5 million as of December 31, 2016 and 2015, respectively. The allowance for doubtful accounts is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.9 million and $0.7 million as of December 31, 2016 and 2015, respectively.

[0001262039-17-000008:notes:265]
Warranties—We generally provide a 1-year warranty on hardware products and a 90-day warranty on software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as incurred. In the event we change our warranty reserve estimates, the resulting charge against future cost of sales or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2016 and 2015.

[0001262039-17-000008:notes:266]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the CAD, EUR, GBP and CNY. To help protect against significant fluctuations in the value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to minimize the impact of balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have a maturity of one month. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other expense—net in the consolidated statement of operations. As of December 31, 2016, the fair value of the forward exchange contracts was not material.

[0001262039-17-000008:notes:267]
Additionally, independent of our use of foreign currency risk management activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in our consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the EUR, GBP and CNY could adversely impact our operating expenses in the future.
