# FTNT note change history — 0001262039-16-000079 → 0001262039-16-000087


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0001262039-16-000087:note_history:1]
Our future principal contractual obligations as of September 30, 2016 were (in thousands):
  (was, 2016-08-05, similarity 0.9333):
[0001262039-16-000079:note_history:1]
Our future principal contractual obligations as of June 30, 2016 were (in thousands):

- changed (2016-11-08):
[0001262039-16-000087:note_history:2]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 74,107 |  |  | $ | 5,756 |  |  | $ | 17,678 |  |  | $ | 14,653 |  |  | $ | 12,359 |  |  | $ | 10,497 |  |  | $ | 13,164 |  |
| Inventory purchase commitments | 116,494 |  |  | 90,169 |  |  | 26,325 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 48,864 |  |  | 33,805 |  |  | 11,466 |  |  | 2,451 |  |  | 855 |  |  | 287 |  |  | — |  |
| Total | $ | 239,465 |  |  | $ | 129,730 |  |  | $ | 55,469 |  |  | $ | 17,104 |  |  | $ | 13,214 |  |  | $ | 10,784 |  |  | $ | 13,164 |  |
  (was, 2016-08-05, similarity 0.9958):
[0001262039-16-000079:note_history:2]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 75,975 |  |  | $ | 10,984 |  |  | $ | 17,146 |  |  | $ | 15,004 |  |  | $ | 12,595 |  |  | $ | 9,598 |  |  | $ | 10,648 |  |
| Inventory purchase commitments | 86,448 |  |  | 86,448 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 52,085 |  |  | 44,522 |  |  | 3,509 |  |  | 1,273 |  |  | 927 |  |  | 927 |  |  | 927 |  |
| Total | $ | 214,508 |  |  | $ | 141,954 |  |  | $ | 20,655 |  |  | $ | 16,277 |  |  | $ | 13,522 |  |  | $ | 10,525 |  |  | $ | 11,575 |  |

- changed (2016-11-08):
[0001262039-16-000087:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $6.1 million and $3.7 million during the three months ended September 30, 2016 and September 30, 2015, respectively. Rent expense was $14.7 million and $9.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2016-08-05, similarity 0.8996):
[0001262039-16-000079:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $2.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively. Rent expense was $8.5 million and $6.0 million during the six months ended June 30, 2016 and June 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2016-11-08):
[0001262039-16-000087:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2016, we had $116.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2016-08-05, similarity 0.9904):
[0001262039-16-000079:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2016, we had $86.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2016-11-08):
[0001262039-16-000087:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2016, we had $48.9 million in other contractual commitments that may not be cancelable.
  (was, 2016-08-05, similarity 0.9813):
[0001262039-16-000079:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2016, we had $52.1 million in other contractual commitments that may not be cancelable.

- changed (2016-11-08):
[0001262039-16-000087:note_history:6]
|  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (2,260 | ) |  | (3,413 | ) |
| Provision for warranty for the period | 925 |  |  | 3,638 |  |
| Adjustment related to pre-existing warranties | (279 | ) |  | (94 | ) |
| Accrued warranty balance—end of the period | $ | 1,530 |  |  | $ | 4,400 |  |
  (was, 2016-08-05, similarity 0.9194):
[0001262039-16-000079:note_history:6]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (1,481 | ) |  | (2,059 | ) |
| Provision for warranty for the period | 718 |  |  | 2,294 |  |
| Adjustment related to pre-existing warranties | (225 | ) |  | 171 |  |
| Accrued warranty balance—end of the period | $ | 2,156 |  |  | $ | 4,675 |  |

- changed (2016-11-08):
[0001262039-16-000087:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.
  (was, 2016-08-05, similarity 0.9931):
[0001262039-16-000079:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.

- changed (2016-11-08):
[0001262039-16-000087:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.
  (was, 2016-08-05, similarity 0.9956):
[0001262039-16-000079:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0001262039-16-000087:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.
  (was, 2016-08-05, similarity 0.8106):
[0001262039-16-000079:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

- changed (2016-11-08):
[0001262039-16-000087:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”
  (was, 2016-08-05, similarity 0.9158):
[0001262039-16-000079:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”

- changed (2016-11-08):
[0001262039-16-000087:note_history:11]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur.
  (was, 2016-08-05, similarity 0.9559):
[0001262039-16-000079:note_history:11]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur. The new standard is effective for us beginning January 1, 2017, with early adoption permitted.

- changed (2016-11-08):
[0001262039-16-000087:note_history:12]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits of $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016.
  (was, 2016-08-05, similarity 0.9674):
[0001262039-16-000079:note_history:12]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits amounting to $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016 and $2.6 million during the second quarter of 2016.

- changed (2016-11-08):
[0001262039-16-000087:note_history:13]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for the three months ended March 31, 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):
  (was, 2016-08-05, similarity 0.9274):
[0001262039-16-000079:note_history:13]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

- changed (2016-11-08):
[0001262039-16-000087:note_history:14]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 has not had any impact on our consolidated financial statements.
  (was, 2016-08-05, similarity 0.9826):
[0001262039-16-000079:note_history:14]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.

- added (2016-11-08):
[0001262039-16-000087:note_history:15]
In October 2016, the FASB issued ASU 2016-16—Income Taxes —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

- added (2016-11-08):
[0001262039-16-000087:note_history:16]
In August 2016, the FASB issued ASU 2016-15—Statement of Cash Flows—Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us beginning on January 1, 2018. Early adoption is permitted, including adoption in an interim period. We are currently evaluating the impact of adopting ASU 2016-15 on our consolidated financial statements.

- added (2016-11-08):
[0001262039-16-000087:note_history:17]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of ASU 2016-13 will have on our consolidated financial statements.

- changed (2016-11-08):
[0001262039-16-000087:note_history:18]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the impact of adopting ASU 2016-02 on our consolidated financial statements.
  (was, 2016-08-05, similarity 0.9736):
[0001262039-16-000079:note_history:18]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the full impact ASU 2016-02 will have on our consolidated financial statements.

- changed (2016-11-08):
[0001262039-16-000087:note_history:19]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of these new standards on our consolidated financial statements.
  (was, 2016-08-05, similarity 0.9702):
[0001262039-16-000079:note_history:19]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.

- removed (2016-11-08):
[0001262039-16-000079:note_history:20]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall—Recognition and Measurement of Financial Assets and Financial Liabilities, which modifies how entities measure equity investments and present changes in the fair value of financial liabilities. Under the new guidance, entities will have to measure equity investments that do not result in consolidation and are not accounted under the equity method at fair value and recognize any changes in fair value in net income unless the investments qualify for the new practicality exception. The practicality exception will apply to those equity investments that do not have a readily determinable fair value and do not qualify for the practical expedient to estimate fair value, and as such these investments may be measured at cost. ASU 2016-01 will be effective for us beginning on January 1, 2018. We do not expect the impact of ASU 2016-01 on our consolidated financial statements to be significant.

- removed (2016-11-08):
[0001262039-16-000079:note_history:21]
In July 2015, the FASB issued ASU 2015-11—Inventory—Simplifying the Measurement of Inventory, which changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. ASU 2015-11 applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in, first-out or average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2016-11-08):
[0001262039-16-000087:note_history:22]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were not material during the three months ended September 30, 2016 and $0.9 million during the three months ended September 30, 2015.  No contingent fees were incurred during the three months ended September 30, 2016 and September 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $3.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively.  Of such amounts, $0.5 million were incurred under contingent fee arrangements during the nine months ended September 30, 2015. No contingent fees were incurred during the nine months ended September 30, 2016. Amounts due and payable to the law firm were $0.1 million and $5.3 million as of September 30, 2016 and December 31, 2015, respectively.

- removed (2016-11-08):
[0001262039-16-000079:note_history:23]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.1 million and $0.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively.  No contingent fees were incurred during the three months ended June 30, 2016 and June 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.4 million and $2.8 million during the six months ended June 30, 2016 and June 30, 2015, respectively.  Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements during the six months ended June 30, 2016 and June 30, 2015, respectively. Amounts due and payable to the law firm were $0.3 million and $5.3 million as of June 30, 2016 and December 31, 2015, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-11-08):
[0001262039-16-000087:note_history:24]
SUBSEQUENT EVENT

- added (2016-11-08):
[0001262039-16-000087:note_history:25]
Share Repurchase Program

- added (2016-11-08):
[0001262039-16-000087:note_history:26]
In October 2016, our board of directors authorized the repurchase of up to $100.0 million of shares of our common stock under the Program, increasing our current authorization to $300.0 million through December 2017.
