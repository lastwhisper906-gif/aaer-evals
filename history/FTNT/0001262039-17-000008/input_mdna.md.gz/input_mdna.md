# FTNT MD&A — 0001262039-17-000008


## mdna

[0001262039-17-000008:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-17-000008:mdna:2]
| • | continued growth and market share gains; |

[0001262039-17-000008:mdna:3]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-17-000008:mdna:4]
| • | expected impact of sales of certain products and services; |

[0001262039-17-000008:mdna:5]
| • | the impact of macro-economic and geopolitical factors on our international sales; |

[0001262039-17-000008:mdna:6]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-17-000008:mdna:7]
| • | the impact of our product innovation strategy; |

[0001262039-17-000008:mdna:8]
| • | drivers of long-term growth and operating leverage, such as increased functionality and value in our standalone and bundled security subscription and support service offerings; |

[0001262039-17-000008:mdna:9]
| • | growing our sales to enterprise, service provider and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-17-000008:mdna:10]
| • | trends in revenue, costs of revenue and gross margin; |

[0001262039-17-000008:mdna:11]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-17-000008:mdna:12]
| • | continued investments in research and development; |

[0001262039-17-000008:mdna:13]
| • | managing our continued investments in sales and marketing, and the impact of those investments; |

[0001262039-17-000008:mdna:14]
| • | expectations regarding uncertain tax benefits and our effective tax rate; |

[0001262039-17-000008:mdna:15]
| • | expectations regarding spending related to real estate and other capital expenditures; |

[0001262039-17-000008:mdna:16]
| • | competition in our markets; |

[0001262039-17-000008:mdna:17]
| • | integration of acquired companies and technologies and expectations related to acquisitions; |

[0001262039-17-000008:mdna:18]
| • | success and expansion of our recently implemented ERP system; |

[0001262039-17-000008:mdna:19]
| • | our intentions regarding repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-17-000008:mdna:20]
| • | other statements regarding our future operations, financial condition and prospects and business strategies; and |

[0001262039-17-000008:mdna:21]
| • | adoption of new accounting standards, including those related to revenue recognition and accounting for leases. |

[0001262039-17-000008:mdna:22]
These forward-looking statements are subject to certain risks and uncertainties that could cause our actual results to differ materially from those reflected in the forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K and, in particular, the risks

[0001262039-17-000008:mdna:23]
37

[0001262039-17-000008:mdna:24]
Business Overview

[0001262039-17-000008:mdna:25]
We provide high performance cybersecurity solutions to a wide variety of enterprises, service providers and government organizations of all sizes across the globe, including a majority of the 2016 Fortune 100. Our cybersecurity solutions are designed to provide broad, rapid protection against dynamic and sophisticated security threats, while simplifying the IT and security infrastructure of our end-customers.

[0001262039-17-000008:mdna:26]
The evolving cyber threat environment is unprecedented both in terms of volume and sophistication of attacks.  As a result, cybersecurity has increased both in priority and in management complexity for organizations of all sizes, especially enterprises. In addition, the growth of IoT devices and the decision by organizations to increasingly move computing and infrastructure resources to the cloud necessitate increased visibility and security orchestration across a widely distributed ecosystem of networks. Our common operating system, centralized management and open application program interfaces allow many of the solutions in our portfolio, as well as those of our partner community, to be combined to create an integrated security architecture. The Fortinet Security Fabric is designed to address sophisticated threats and next-generation environments, including IoT and the cloud. The Fortinet Security Fabric connects our products, services and ecosystem partner solutions to help provide visibility and protection at all points in the network, from endpoint to data center to the cloud, regardless of whether deployed in physical, virtual or hybrid cloud environments or on endpoint devices. The Fortinet Security Fabric delivers integrated scalability, access control, awareness, security, traffic segmentation, centralized management and orchestration. The Fortinet Security Fabric is built around an open framework to ensure interoperability and synchronization of intelligence and response, and does so across the distributed network security infrastructure, including both from the cloud and for the cloud. At the core of the Fortinet Security Fabric are our FortiGate physical and software licenses, which ship with a broad set of security services, including firewall, VPN, anti-malware, anti-spam, application control, intrusion prevention, access control, web filtering, traffic and device segmentation and ATP. Many of these security services are tuned and updated by our FortiGuard Labs team, which provides threat research and a global cloud network of data collection and intelligence resources to deliver subscription-based services to FortiGate appliances and software products.

[0001262039-17-000008:mdna:27]
Enterprise customers select the form and deployment method that best meet their specific security requirements, such as a high-speed DCFW at the network core, a NGFW at the edge, an internal segmentation firewall (“ISFW”) between network zones, a distributed enterprise firewall at branch sites or software and hardware-based solutions designed for virtualized and cloud environments. Many smaller businesses also tend to deploy UTM devices. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -900 series for medium-sized businesses, to the FortiGate-1000 to -7000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering, and anti-spam functionality. End-customers may also purchase FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide enterprise-class centralized management, analysis and reporting capabilities. FortiSIEM provides organizations with a solution for analyzing and managing network security, performance and compliance standards across our and other vendors’ products. Finally, end-customers may purchase FortiCare technical support services for our products and FortiCare professional services to assist in the design, implementation and maintenance of their networks.

[0001262039-17-000008:mdna:28]
We complement our core FortiGate product line with other appliances and software licenses that offer additional protection from security threats to other critical areas of the enterprise. These products include our FortiMail email security, FortiSandbox ATP, FortiWeb web application firewall, FortiDDoS, and FortiDB database security appliances, as well as our FortiClient endpoint security software, FortiAP secure wireless access points and FortiSwitch secure switch connectivity products.

[0001262039-17-000008:mdna:29]
Sales of complementary products and software licenses have outpaced our overall growth in recent quarters. Our strong technology advantages also position us to effectively deliver security to the cloud and for the cloud. Sales of our cloud related products and services across public, private and hybrid cloud environments continue to grow faster than other part of our business.

[0001262039-17-000008:mdna:30]
38

[0001262039-17-000008:mdna:31]
Financial Highlights

[0001262039-17-000008:mdna:32]
| • | We recorded total revenue of $1.28 billion in 2016, an increase of 26% compared to 2015. Product revenue was $548.1 million in 2016, an increase of 15% compared to 2015. Service revenue was $727.3 million in 2016, an increase of 37% compared to 2015. |

[0001262039-17-000008:mdna:33]
| • | Cash, cash equivalents and investments were $1.31 billion as of December 31, 2016, an increase of $146.2 million, or 13%, from December 31, 2015. |

[0001262039-17-000008:mdna:34]
| • | Deferred revenue was $1.04 billion as of December 31, 2016, an increase of $244.0 million, or 31%, from December 31, 2015. |

[0001262039-17-000008:mdna:35]
| • | We generated cash flows from operating activities of $345.7 million in 2016, an increase of $63.2 million, or 22%, compared to 2015. |

[0001262039-17-000008:mdna:36]
| • | We repurchased 3.9 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $110.8 million in 2016. |

[0001262039-17-000008:mdna:37]
Revenue grew in 2016 as our strategy of investing in sales and marketing enabled us to continue to gain market share and customers. Our sales increased in 2016, primarily due to the strength in sales of our enterprise service bundles and the Fortinet Security Fabric. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-17-000008:mdna:38]
The percentage of our FortiGate related billings from mid-range products increased from 25% in 2015 to 28% in 2016 and the entry-level products remained at 34% in 2016, consistent with billings in 2015. The percentage of our FortiGate related billings from high-end products decreased from 41% in 2015 to 38% in 2016. The sale of non-FortiGate products also grew significantly, such as growth in our FortiSandbox ATP products. We also saw more deals that included multiple Fortinet products in physical, virtual and cloud environments.

[0001262039-17-000008:mdna:39]
In 2016, operating expenses increased by $187.0 million, or 26%, as compared to 2015. The increase was primarily driven by our investments made to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains. In addition, we incurred expenses from business design and reengineering related to the implementation of a new ERP system. Headcount increased by 16% to 4,665 employees and contractors as of December 31, 2016, up from 4,018 as of December 31, 2015.

[0001262039-17-000008:mdna:40]
Business Model

[0001262039-17-000008:mdna:41]
Our sales strategy is based on a distribution model whereby we primarily sell our products, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, which have significant purchasing power and unique customer deployment requirements. We also offer our products through Amazon Web Services and Microsoft Azure. While the revenue from such sales are still relatively insignificant, they are rapidly increasing and are aligned with the networking trends of our customers and the industry as a whole.

[0001262039-17-000008:mdna:42]
Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical products and software licenses, most frequently as part of a bundle offering that includes hardware and services functionality. We generally invoice at the time of our sale for the total price of the products and security and technical support services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis.

[0001262039-17-000008:mdna:43]
We generally recognize product revenue up front and ratably recognize revenue for the sale of new, and the renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize revenue for certain software licenses up front as product revenue and, to a lesser extent, recognize other software licenses over the term of the agreement as services revenue. We recognize the security and support revenue over the service period, which is typically one to three years, but can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which contributes significantly to our positive cash flow from operations.

[0001262039-17-000008:mdna:44]
Key Metrics

[0001262039-17-000008:mdna:45]
We monitor a number of financial and liquidity metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-17-000008:mdna:46]
|  | Year Ended or As of December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Revenue | $ | 1,275,443 |  |  | $ | 1,009,268 |  |  | $ | 770,364 |  |
| Deferred revenue | $ | 1,035,349 |  |  | $ | 791,303 |  |  | $ | 558,757 |  |
| Billings (non-GAAP) | $ | 1,515,089 |  |  | $ | 1,232,014 |  |  | $ | 896,493 |  |
| Cash, cash equivalents and investments | $ | 1,310,508 |  |  | $ | 1,164,310 |  |  | $ | 991,744 |  |
| Net cash provided by operating activities | $ | 345,708 |  |  | $ | 282,547 |  |  | $ | 196,582 |  |
| Free cash flow (non-GAAP) | $ | 278,526 |  |  | $ | 245,189 |  |  | $ | 164,385 |  |

[0001262039-17-000008:mdna:47]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue to be recognized in future periods. Deferred revenue was $1.04 billion as of December 31, 2016, an increase of $244.0 million, or 31%, from December 31, 2015.

[0001262039-17-000008:mdna:48]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $1.52 billion for 2016, an increase of 23% compared to $1.23 billion in 2015.

[0001262039-17-000008:mdna:49]
A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-17-000008:mdna:50]
|  | Year Ended December 31, |
| 2016 |  | 2015 |  | 2014 |
| (in thousands) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 1,275,443 |  |  | $ | 1,009,268 |  |  | $ | 770,364 |  |
| Add change in deferred revenue | 244,046 |  |  | 232,546 |  |  | 126,129 |  |
| Less deferred revenue balance acquired in business combination | (4,400 | ) |  | (9,800 | ) |  | — |  |
| Total billings (Non-GAAP) | $ | 1,515,089 |  |  | $ | 1,232,014 |  |  | $ | 896,493 |  |

[0001262039-17-000008:mdna:51]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic

[0001262039-17-000008:mdna:52]
acquisitions, repurchasing outstanding common stock and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.” A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-17-000008:mdna:53]
|  | Year Ended December 31, |
| 2016 |  | 2015 |  | 2014 |
| (in thousands) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 345,708 |  |  | $ | 282,547 |  |  | $ | 196,582 |  |
| Less purchases of property and equipment | (67,182 | ) |  | (37,358 | ) |  | (32,197 | ) |
| Free cash flow (Non-GAAP) | $ | 278,526 |  |  | $ | 245,189 |  |  | $ | 164,385 |  |

[0001262039-17-000008:mdna:54]
Components of Operating Results

[0001262039-17-000008:mdna:55]
Revenue

[0001262039-17-000008:mdna:56]
We generate the majority of our revenue from sales of our products, software licenses and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. Revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred or services have been rendered, the sales price is fixed or determinable and collectability is reasonably assured.

[0001262039-17-000008:mdna:57]
Our total revenue is comprised of the following:

[0001262039-17-000008:mdna:58]
| • | Product revenue. Product revenue is primarily generated from sales of our appliances. The substantial majority of our product revenue has been generated by our FortiGate line of appliances, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of software. As a percentage of total revenue, we expect that our product revenue may vary from quarter-to-quarter based on seasonal and cyclical factors, as discussed below under “—Quarterly Results of Operations”, and we expect the trend to continue in 2017. |

[0001262039-17-000008:mdna:59]
| • | Service revenue. Service revenue is generated primarily from FortiGuard security subscription services related to application control, antivirus, intrusion prevention, web filtering, anti-spam, ATP and vulnerability management updates, and from FortiCare technical support services for software updates, maintenance releases and patches, Internet access to technical content, telephone and Internet access to technical support personnel and hardware support. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years. We also generate a small portion of our revenue from professional services and training services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues, which reflects our ongoing success in driving sales of low-end and high-end service bundles, as well as increases in certain software sales and time based service models. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings and the renewal of service contracts by our existing customers. |

[0001262039-17-000008:mdna:60]
Our total cost of revenue is comprised of the following:

[0001262039-17-000008:mdna:61]
| • | Cost of product revenue. A substantial majority of the cost of product revenue consists of third-party contract manufacturers' costs, as well as other costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related |

[0001262039-17-000008:mdna:62]
41

[0001262039-17-000008:mdna:63]
costs, excess and obsolete inventory costs, warranty costs, and amortization and impairment of intangible assets, if applicable. Personnel costs include salaries, benefits and bonuses, as well as stock-based compensation.

[0001262039-17-000008:mdna:64]
| • | Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes supplies and facility-related costs. |

[0001262039-17-000008:mdna:65]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, any excess inventory write-offs, product costs, the mix of products sold and the mix of revenue between products, software licenses and services. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to product gross margins. During 2016, product gross margin was positively impacted by higher sales of software products, as well as inventory management and warehouse efficiencies. Service gross margins remained relatively comparable in 2016 compared to 2015. We believe our overall gross margin will remain at a relatively comparable level in 2017.

[0001262039-17-000008:mdna:66]
Operating expenses. Our operating expenses consist of research and development, sales and marketing, general and administrative expenses, and restructuring charges. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, stock-based compensation, and sales commissions, as applicable. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-17-000008:mdna:67]
| • | Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of capital equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our research and development teams are primarily located in Canada and the U.S. |

[0001262039-17-000008:mdna:68]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include promotional lead generation and other marketing expenses, travel, depreciation of capital equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture additional market share in the high-return enterprise market, where customers tend to provide a higher lifetime value. |

[0001262039-17-000008:mdna:69]
| • | General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of capital equipment and software, facility-related expenses, expenses associated with the ERP system implementation and business acquisition costs. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-17-000008:mdna:70]
| • | Restructuring charges. Restructuring charges relate to alignment activities performed in connection with the Meru and AccelOps acquisitions to reduce our cost structure and improve operational efficiencies, resulting in workforce reductions, contract terminations and other charges. |

[0001262039-17-000008:mdna:71]
Interest income. Interest income consists of income earned on our cash, cash equivalents and investments. We have historically invested our cash in corporate debt securities, commercial paper, U.S. government and agency securities, municipal bonds, money market funds and certificates of deposit.

[0001262039-17-000008:mdna:72]
Other expense—net. Other expense—net consists primarily of foreign exchange gains and losses relate to foreign currency exchange remeasurement.

[0001262039-17-000008:mdna:73]
Provision for income taxes. We are subject to tax in the U.S., as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in the local country which are generally lower than U.S. tax rates, and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than the U.S., research and development tax credits, withholding taxes and nondeductible stock-based compensation expense.

[0001262039-17-000008:mdna:74]
42

[0001262039-17-000008:mdna:75]
The income tax provision for 2016 was comprised of domestic income taxes, foreign income taxes and foreign withholding taxes. Our effective tax rate approximates the U.S. federal statutory tax rates plus the impact of state taxes, excess tax benefits related to stock-based compensation expense, research and development tax credits, foreign withholding tax, nondeductible stock-based compensation expense, and foreign income subject to lower tax rates than income earned in the U.S.

[0001262039-17-000008:mdna:76]
Critical Accounting Policies and Estimates

[0001262039-17-000008:mdna:77]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-17-000008:mdna:78]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-17-000008:mdna:79]
Revenue Recognition

[0001262039-17-000008:mdna:80]
We derive the majority of our revenue from sales of our hardware, software, FortiGuard security subscription and FortiCare technical support services, and other services through our channel partners and a direct sales force.

[0001262039-17-000008:mdna:81]
Revenue is recognized when all of the following criteria have been met:

[0001262039-17-000008:mdna:82]
| • | Persuasive evidence of an arrangement exists. Binding contracts or purchase orders are generally used to determine the existence of an arrangement. |

[0001262039-17-000008:mdna:83]
| • | Delivery has occurred or services have been rendered. Product delivery occurs when we fulfill an order and title and risk of loss has been transferred. Software license delivery occurs upon electronic transfer of the license key to the customer. Service revenue is deferred and recognized ratably over the contractual service period, which is typically from one to three years and, to a lesser extent, up to five years, and is generally recognized upon delivery or completion of service. |

[0001262039-17-000008:mdna:84]
| • | Sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on the payment terms associated with the transaction and when the sales price is deemed final. |

[0001262039-17-000008:mdna:85]
| • | Collectability is reasonably assured. We assess collectability based primarily on creditworthiness as determined by credit checks, analysis, and payment history. |

[0001262039-17-000008:mdna:86]
We recognize product revenue for sales to distributors that have no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria have been met. Certain distributors are granted stock rotation rights, limited rights of return and rebates for sales of our products. The arrangement fee for this group of distributors is not typically fixed or determinable when products are shipped and revenue is therefore deferred and recognized upon sell-through. For sales that include end-customer acceptance criteria, revenue is recognized upon acceptance. We recognize software license revenue upon delivery.  Historically, software license revenue has not been material.

[0001262039-17-000008:mdna:87]
Substantially all of our products have been sold in combination with services, which consist of security subscriptions and technical support services. Security services provide access to our antivirus, intrusion prevention, web filtering, and anti-spam functionality. Support services include rights to unspecified software upgrades, maintenance releases and patches, telephone and Internet access to technical support personnel, and hardware support.

[0001262039-17-000008:mdna:88]
Service revenue consists of sales from our FortiGuard security subscription and FortiCare technical support services, professional and training services and other services that include software as a service (“SaaS”) and infrastructure as a service (“IaaS”), both of which are hosted or cloud-based services. We recognize revenue from these arrangements as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis.  To date, SaaS and IaaS revenues have not represented a significant percentage of our total revenue.

[0001262039-17-000008:mdna:89]
43

[0001262039-17-000008:mdna:90]
We reduce revenue for estimates of sales returns and allowances and record reductions to revenue for rebates and estimated commitments related to price protection and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. We estimate and record reserves for sales incentives and sales returns based on historical experience.

[0001262039-17-000008:mdna:91]
Our sales arrangements typically contain multiple elements, such as hardware, security subscription, technical support services and other services. The majority of our hardware appliance products contain our operating system software that together function to deliver the essential functionality of the product. Our products and services generally qualify as separate units of accounting. We allocate revenue to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.

[0001262039-17-000008:mdna:92]
For our hardware appliances, we use BESP as our selling price estimate. For our support and other services, we generally use VSOE as our selling price estimate. We determine VSOE of fair value for elements of an arrangement based on the historical pricing and discounting practices for those services when sold separately. In establishing VSOE, we require that a substantial majority of the selling prices for a service fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range as a percentage of list price. When we are unable to establish a selling price using VSOE for our support and other services, we use BESP in our allocation of arrangement consideration. We determine BESP for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies, customer classes and distribution channels that fall within a reasonably narrow range as a percentage of list price.

[0001262039-17-000008:mdna:93]
For multiple-element arrangements where software deliverables are included, revenue is allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables is then allocated to each software deliverable using the residual method when VSOE of fair value exists. If evidence of VSOE of fair value of one or more undelivered elements does not exist, all software allocated revenue is deferred and recognized when delivery of those elements occurs or when fair value can be established. When the undelivered element for which we do not have VSOE of fair value is support, revenue for the entire arrangement is recognized ratably over the support period. The same residual method and VSOE of fair value principles apply for our multiple element arrangements that contain only software elements.

[0001262039-17-000008:mdna:94]
We currently are evaluating the impact of the new standard related to revenue recognition, and we may incur significant costs to adopt and to comply with this new pronouncement. See Note 1 to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for further discussion.

[0001262039-17-000008:mdna:95]
Stock-Based Compensation

[0001262039-17-000008:mdna:96]
Employee Stock Options. We estimate the fair value of employee stock options awarded to our employees using the Black-Scholes-Merton (“Black-Scholes”) pricing model. For all employee stock options, we recognize expense over the requisite service period using the straight-line method. Our option pricing model requires the input of subjective assumptions, including the expected stock price volatility, expected term, risk-free interest rates and expected dividend yield of our common stock. The assumptions used in our option pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-17-000008:mdna:97]
Employee Stock Purchase Plan. We estimate the fair value of the rights to acquire stock under our employee stock purchase plan (“ESPP”) using the Black-Scholes pricing model and we recognize expense over the requisite service period using the straight-line method. The pricing model requires the input of the fair value of our common stock and assumptions, including the expected term of the award, expected volatility of the price of our common stock, risk-free interest rates and expected dividend yield of our common stock. Our ESPP provides for consecutive six-month offering periods and we use our own historical volatility data in the valuation of ESPP shares. A 10% change in any of these assumptions would not have a significant impact on our stock-based compensation expense.

[0001262039-17-000008:mdna:98]
Valuation of Inventory

[0001262039-17-000008:mdna:99]
Inventory is recorded at the lower of cost (using the first-in, first-out method) or market, after we give appropriate consideration to obsolescence and inventory in excess of anticipated future demand. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-17-000008:mdna:100]
Business Combinations

[0001262039-17-000008:mdna:101]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible assets acquired, liabilities assumed, and intangible assets acquired, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such charges are recorded in the period in which they are identified.

[0001262039-17-000008:mdna:102]
Restructuring

[0001262039-17-000008:mdna:103]
Our restructuring expenses consist of severance and other one-time benefits, contract terminations and other expenses. Liabilities for costs associated with a restructuring activity are measured at fair value. One-time termination benefits are expensed at the date we notify the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. A liability for terminating a contract before the end of its term, which termination is usually done by giving written notice to the counterparty within the notification period specified by the contract or by otherwise negotiating a termination with the counterparty, is recognized at fair value on the notification date. A liability for costs that will continue to be incurred under a contract for its remaining term without economic benefit to the entity is recognized at the cease-use date. Other costs primarily consist of asset write-offs, which are expensed when incurred.

[0001262039-17-000008:mdna:104]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plan, actual results may differ and thereby require us to record an additional provision or reverse a portion of such a provision.

[0001262039-17-000008:mdna:105]
Accounting for Income Taxes

[0001262039-17-000008:mdna:106]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-17-000008:mdna:107]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the taxing authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-17-000008:mdna:108]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of operations become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-17-000008:mdna:109]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may

[0001262039-17-000008:mdna:110]
exist. Any adjustment to the net deferred tax asset valuation allowance would be recorded in the consolidated statements of operations for the period that the adjustment is determined to be required.

[0001262039-17-000008:mdna:111]
We make estimates and judgments about our future taxable income that are based on assumptions that are consistent with our plans and estimates. Should the actual amounts differ from our estimates, the amount of our tax expense and liabilities could be materially impacted.

[0001262039-17-000008:mdna:112]
Results of Operations

[0001262039-17-000008:mdna:113]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-17-000008:mdna:114]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Consolidated Statement of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 548,110 |  |  | $ | 476,782 |  |  | $ | 360,558 |  |
| Service | 727,333 |  |  | 532,486 |  |  | 409,806 |  |
| Total revenue | 1,275,443 |  |  | 1,009,268 |  |  | 770,364 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 208,984 |  |  | 190,398 |  |  | 151,300 |  |
| Service | 128,853 |  |  | 96,379 |  |  | 79,709 |  |
| Total cost of revenue | 337,837 |  |  | 286,777 |  |  | 231,009 |  |
| Gross profit: |  |  |  |  |  |
| Product | 339,126 |  |  | 286,384 |  |  | 209,258 |  |
| Service | 598,480 |  |  | 436,107 |  |  | 330,097 |  |
| Total gross profit | 937,606 |  |  | 722,491 |  |  | 539,355 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 183,084 |  |  | 158,129 |  |  | 122,880 |  |
| Sales and marketing | 626,501 |  |  | 470,371 |  |  | 315,804 |  |
| General and administrative | 81,080 |  |  | 71,514 |  |  | 41,347 |  |
| Restructuring charges | 3,997 |  |  | 7,600 |  |  | — |  |
| Total operating expenses | 894,662 |  |  | 707,614 |  |  | 480,031 |  |
| Operating income | 42,944 |  |  | 14,877 |  |  | 59,324 |  |
| Interest income | 7,303 |  |  | 5,295 |  |  | 5,393 |  |
| Other expense—net | (7,099 | ) |  | (3,167 | ) |  | (3,168 | ) |
| Income before income taxes | 43,148 |  |  | 17,005 |  |  | 61,549 |  |
| Provision for income taxes | 10,961 |  |  | 9,018 |  |  | 36,206 |  |
| Net income | $ | 32,187 |  |  | $ | 7,987 |  |  | $ | 25,343 |  |

[0001262039-17-000008:mdna:115]
46

[0001262039-17-000008:mdna:116]
|  | Year Ended December 31, |
| 2016 |  | 2015 |  | 2014 |
| (as percentage of total revenue) |
| Revenue: |  |  |  |  |  |
| Product | 43 | % |  | 47 | % |  | 47 | % |
| Service | 57 |  |  | 53 |  |  | 53 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 16 |  |  | 19 |  |  | 20 |  |
| Service | 10 |  |  | 10 |  |  | 10 |  |
| Total cost of revenue | 26 |  |  | 28 |  |  | 30 |  |
| Gross profit: |  |  |  |  |  |
| Product | 62 |  |  | 60 |  |  | 58 |  |
| Service | 82 |  |  | 82 |  |  | 81 |  |
| Total gross margin | 74 |  |  | 72 |  |  | 70 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 14 |  |  | 16 |  |  | 16 |  |
| Sales and marketing | 49 |  |  | 47 |  |  | 41 |  |
| General and administrative | 6 |  |  | 7 |  |  | 5 |  |
| Restructuring charges | 0.3 |  |  | 1 |  |  | — |  |
| Total operating expenses | 70 |  |  | 70 |  |  | 62 |  |
| Operating margin | 3 |  |  | 1 |  |  | 8 |  |
| Interest income | 1 |  |  | 1 |  |  | 1 |  |
| Other expense—net | (1 | ) |  | — |  |  | — |  |
| Income before income taxes | 3 |  |  | 2 |  |  | 8 |  |
| Provision for income taxes | 1 |  |  | 1 |  |  | 5 |  |
| Net income | 3 | % |  | 1 | % |  | 3 | % |

[0001262039-17-000008:mdna:117]
2016 and 2015

[0001262039-17-000008:mdna:118]
Revenue

[0001262039-17-000008:mdna:119]
|  | Year Ended December 31, |  |  |  |  |
| 2016 |  | 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 548,110 |  |  | 43 | % |  | $ | 476,782 |  |  | 47 | % |  | $ | 71,328 |  |  | 15 | % |
| Service | 727,333 |  |  | 57 |  |  | 532,486 |  |  | 53 |  |  | 194,847 |  |  | 37 |  |
| Total revenue | $ | 1,275,443 |  |  | 100 | % |  | $ | 1,009,268 |  |  | 100 | % |  | $ | 266,175 |  |  | 26 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 536,706 |  |  | 42 | % |  | $ | 435,282 |  |  | 43 | % |  | $ | 101,424 |  |  | 23 | % |
| Europe, Middle East and Africa (“EMEA”) | 477,393 |  |  | 37 |  |  | 366,018 |  |  | 36 |  |  | 111,375 |  |  | 30 |  |
| Asia Pacific (“APAC”) | 261,344 |  |  | 21 |  |  | 207,968 |  |  | 21 |  |  | 53,376 |  |  | 26 |  |
| Total revenue | $ | 1,275,443 |  |  | 100 | % |  | $ | 1,009,268 |  |  | 100 | % |  | $ | 266,175 |  |  | 26 | % |

[0001262039-17-000008:mdna:120]
Total revenue increased by $266.2 million, or 26%, in 2016 compared to 2015. We continued to experience global diversification of revenue in 2016. Revenue from all our regions grew, with EMEA contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $71.3 million, or 15%, in

[0001262039-17-000008:mdna:121]
47

[0001262039-17-000008:mdna:122]
2016 compared to 2015. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories and in particular for our high-end and mid-range products for large enterprise customers. Sales of non-FortiGate products, such as FortiSandbox, also grew significantly. Service revenue increased by $194.8 million, or 37%, in 2016 compared to 2015. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues, which reflect our ongoing success in driving sales of low-end and high-end service bundles.

[0001262039-17-000008:mdna:123]
Cost of revenue and gross margin

[0001262039-17-000008:mdna:124]
|  | Year Ended December 31, |  |  |  |  |
| 2016 |  | 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 208,984 |  |  | $ | 190,398 |  |  | $ | 18,586 |  |  | 10 | % |
| Service | 128,853 |  |  | 96,379 |  |  | 32,474 |  |  | 34 |  |
| Total cost of revenue | $ | 337,837 |  |  | $ | 286,777 |  |  | $ | 51,060 |  |  | 18 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 61.9 | % |  | 60.1 | % |  | 1.8 | % |  |  |
| Service | 82.3 |  |  | 81.9 |  |  | 0.4 |  |  |  |
| Total gross margin | 73.5 | % |  | 71.6 | % |  | 1.9 | % |  |  |

[0001262039-17-000008:mdna:125]
Total gross margin increased by 1.9 percentage points in 2016 compared to 2015, as both product and service gross margins increased. Product gross margin increased by 1.8 percentage points in 2016 compared to 2015. Product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions and by lower warranty related costs, and was partially offset by higher inventory reserves.

[0001262039-17-000008:mdna:126]
Service gross margin increased during 2016 as compared to 2015, as we scaled efficiencies resulting from an increased mix on higher-margin service revenue. Cost of service revenue increased by $32.5 million, and was comprised primarily of personnel costs.

[0001262039-17-000008:mdna:127]
Operating expenses

[0001262039-17-000008:mdna:128]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 183,084 |  |  | 14 | % |  | $ | 158,129 |  |  | 16 | % |  | $ | 24,955 |  |  | 16 | % |
| Sales and marketing | 626,501 |  |  | 49 |  |  | 470,371 |  |  | 47 |  |  | 156,130 |  |  | 33 |  |
| General and administrative | 81,080 |  |  | 6 |  |  | 71,514 |  |  | 7 |  |  | 9,566 |  |  | 13 |  |
| Restructuring charges | 3,997 |  |  | 0.3 |  |  | 7,600 |  |  | 1 |  |  | (3,603 | ) |  | (47 | ) |
| Total operating expenses | $ | 894,662 |  |  | 70 | % |  | $ | 707,614 |  |  | 70 | % |  | $ | 187,048 |  |  | 26 | % |

[0001262039-17-000008:mdna:129]
Research and development

[0001262039-17-000008:mdna:130]
Research and development expense increased by $25.0 million, or 16%, in 2016 compared to 2015, primarily due to an increase of $19.0 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $6.6 million. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level in 2017.

[0001262039-17-000008:mdna:131]
Sales and marketing

[0001262039-17-000008:mdna:132]
Sales and marketing expense increased by $156.1 million, or 33%, in 2016 compared to 2015, primarily due to an increase of $122.3 million in personnel costs as we continued to increase our sales and marketing headcount in order to drive continued market share gains globally. In addition, depreciation expense and other occupancy-related expense increased by $14.0 million, and travel and entertainment expense increased by $8.1 million. Marketing-related expense increased by $7.6 million as we invested significantly in marketing programs to capture market share, particularly in the large enterprise market, including costs related to trade shows and lead generation. As a percentage of total revenue, sales and marketing expense increased as we accelerated the investment in our sales force and marketing programs to drive future growth. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but expect sales and marketing expense as a percentage of total revenue to decline in 2017.

[0001262039-17-000008:mdna:133]
General and administrative

[0001262039-17-000008:mdna:134]
General and administrative expense increased by $9.6 million, or 13%, in 2016 compared to 2015. Personnel costs increased by $9.6 million as we continued to increase headcount in order to support our expanding business and ERP implementation. During 2016, we expensed $7.8 million of third-party costs relating to the implementation and maintenance of the ERP system implementation compared to $5.4 million in 2015. These increases were partially offset by lower professional fees of $6.7 million in 2016. As a percentage of total revenue, we expect general and administrative expense to increase compared to 2016 as we continue to expand our ERP capabilities and implement the new revenue recognition standard.

[0001262039-17-000008:mdna:135]
Restructuring

[0001262039-17-000008:mdna:136]
Restructuring expenses of $4.0 million in 2016 primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. Restructuring charges of $7.6 million during 2015 relate to restructuring activities in connection with the Meru acquisition. See Note 9 to the consolidated financial statements for additional details, including the types of expenses incurred and cash payments made. See also the “Liquidity and Capital Resources” section of this Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001262039-17-000008:mdna:137]
Interest income and other expense—net

[0001262039-17-000008:mdna:138]
|  | Year Ended December 31, |  |  |  |  |
| 2016 |  | 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 7,303 |  |  | $ | 5,295 |  |  | $ | 2,008 |  |  | 38 | % |
| Other expense—net | (7,099 | ) |  | (3,167 | ) |  | (3,932 | ) |  | 124 |  |

[0001262039-17-000008:mdna:139]
Interest income increased in 2016 as compared to 2015, primarily due to interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates.  The increase in other expense—net in 2016 as compared to 2015 was the result of higher foreign currency exchange losses.

[0001262039-17-000008:mdna:140]
Provision for income taxes

[0001262039-17-000008:mdna:141]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2016 |  | 2015 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 10,961 |  |  | $ | 9,018 |  |  | $ | 1,943 |  |  | 22 | % |
| Effective tax rate (%) | 25 | % |  | 53 | % |  | (28 | )% |  | — |  |

[0001262039-17-000008:mdna:142]
Our effective tax rate was 25% for 2016, compared with an effective tax rate of 53% for 2015. The provision for income taxes for 2016 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, an increase in tax reserves, as well as transfer pricing allocations that impact jurisdictional income taxed at various tax rates. The decrease in the effective tax rate in 2016 was primarily due to the recognition of excess tax benefits for income tax provision from the adoption of ASU 2016-09. In 2016, due to the early adoption of ASU 2016-09, approximately $10.8 million

[0001262039-17-000008:mdna:143]
49

[0001262039-17-000008:mdna:144]
of excess tax benefits were recognized in the income tax provision. In 2015, there were no excess tax benefits included in the income tax provision.

[0001262039-17-000008:mdna:145]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2016, we had accrued $9.5 million for estimated interest related to uncertain tax provisions compared to an accrual of $5.5 million as of December 31, 2015.

[0001262039-17-000008:mdna:146]
Within the next twelve months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-17-000008:mdna:147]
2015 and 2014

[0001262039-17-000008:mdna:148]
Revenue

[0001262039-17-000008:mdna:149]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 476,782 |  |  | 47 | % |  | $ | 360,558 |  |  | 47 | % |  | $ | 116,224 |  |  | 32 | % |
| Service | 532,486 |  |  | 53 |  |  | 409,806 |  |  | 53 |  |  | 122,680 |  |  | 30 |  |
| Total revenue | $ | 1,009,268 |  |  | 100 | % |  | $ | 770,364 |  |  | 100 | % |  | $ | 238,904 |  |  | 31 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 435,282 |  |  | 43 | % |  | $ | 324,659 |  |  | 42 | % |  | $ | 110,623 |  |  | 34 | % |
| EMEA | 366,018 |  |  | 36 |  |  | 270,537 |  |  | 35 |  |  | 95,481 |  |  | 35 |  |
| APAC | 207,968 |  |  | 21 |  |  | 175,168 |  |  | 23 |  |  | 32,800 |  |  | 19 |  |
| Total revenue | $ | 1,009,268 |  |  | 100 | % |  | $ | 770,364 |  |  | 100 | % |  | $ | 238,904 |  |  | 31 | % |

[0001262039-17-000008:mdna:150]
Total revenue increased by $238.9 million, or 31%, in 2015 compared to 2014. Total revenue in 2015 of $1.01 billion included Meru’s revenue from July 8, 2015 to December 31, 2015 of $28.1 million, or 3% of total revenue.  Excluding Meru’s revenue, our revenue was $981.2 million, an increase of 27% compared to the same period last year. We continued to experience global diversification of revenue in 2015. The Americas region contributed the largest portion of our revenue growth on an absolute dollar basis and all three regions showed growth on a percentage basis. Product revenue increased by $116.2 million, or 32%, in 2015 compared to 2014.  The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories, particularly in our high-end products for large enterprise customers. Service revenue increased by $122.7 million, or 30%, in 2015 compared to 2014. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-17-000008:mdna:151]
Cost of revenue and gross margin

[0001262039-17-000008:mdna:152]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 190,398 |  |  | $ | 151,300 |  |  | $ | 39,098 |  |  | 26 | % |
| Service | 96,379 |  |  | 79,709 |  |  | 16,670 |  |  | 21 |  |
| Total cost of revenue | $ | 286,777 |  |  | $ | 231,009 |  |  | $ | 55,768 |  |  | 24 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.1 | % |  | 58.0 | % |  | 2.1 | % |  |  |
| Service | 81.9 |  |  | 80.5 |  |  | 1.4 |  |  |  |
| Total gross margin | 71.6 | % |  | 70.0 | % |  | 1.6 | % |  |  |

[0001262039-17-000008:mdna:153]
Total gross margin increased by 1.6 percentage points in 2015 compared to 2014, as both product and service gross margins increased. Product gross margin increased by 2.1 percentage points in 2015 compared to 2014, primarily due to a greater mix of high-end FortiGate product sales compared to the same period last year, such as our FortiGate-5000 series. In addition, product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as by inventory management efficiencies.

[0001262039-17-000008:mdna:154]
Service gross margin increased during 2015 as compared to 2014, as we scaled efficiencies resulting from our ability to charge more for our FortiGuard security subscription and FortiCare technical support offerings. Cost of service revenue increased by $16.7 million primarily due to an $11.6 million increase in personnel costs related to headcount increases.

[0001262039-17-000008:mdna:155]
Operating expenses

[0001262039-17-000008:mdna:156]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 158,129 |  |  | 16 | % |  | $ | 122,880 |  |  | 16 | % |  | $ | 35,249 |  |  | 29 | % |
| Sales and marketing | 470,371 |  |  | 47 |  |  | 315,804 |  |  | 41 |  |  | 154,567 |  |  | 49 |  |
| General and administrative | 71,514 |  |  | 7 |  |  | 41,347 |  |  | 5 |  |  | 30,167 |  |  | 73 |  |
| Restructuring charges | 7,600 |  |  | 1 |  |  | — |  |  | — |  |  | 7,600 |  |  | * |  |
| Total operating expenses | $ | 707,614 |  |  | 70 | % |  | $ | 480,031 |  |  | 62 | % |  | $ | 227,583 |  |  | 47 | % |

[0001262039-17-000008:mdna:157]
* not meaningful

[0001262039-17-000008:mdna:158]
Research and development

[0001262039-17-000008:mdna:159]
Research and development expense increased by $35.2 million, or 29%, in 2015 compared to 2014, primarily due to an increase of $25.8 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $3.6 million. In addition, during 2014, we had a reversal of $3.0 million related to a previously recorded liability for estimated contingent consideration.

[0001262039-17-000008:mdna:160]
Sales and marketing

[0001262039-17-000008:mdna:161]
Sales and marketing expense increased by $154.6 million, or 49%, in 2015 compared to 2014, primarily due to an increase of $108.0 million in personnel costs as we continued to increase our sales and marketing headcount. Marketing-related expenses increased by $16.9 million as we invested significantly in marketing investments to drive broader market awareness, create a global marketing engine, build broad market lead generation and nurture programs and accelerate pipeline. In addition, we incurred increases in travel expenses of $9.1 million, and depreciation and occupancy-related costs of $9.3 million. As a

[0001262039-17-000008:mdna:162]
percentage of total revenue, sales and marketing expense increased as we accelerated the investment in our sales force and marketing programs to drive future growth.

[0001262039-17-000008:mdna:163]
General and administrative

[0001262039-17-000008:mdna:164]
General and administrative expense increased by $30.2 million, or 73%, in 2015 compared to 2014. Personnel costs increased by $14.6 million as we continued to increase headcount in order to support our expanding business. In addition, professional fees increased by $6.9 million, primarily due to legal services related to the assertion of our intellectual property and other rights. In 2015, we also incurred $5.4 million in third party expenses related to business process design and reengineering in preparation of an ERP system implementation and $1.7 million of costs related to the Meru acquisition.

[0001262039-17-000008:mdna:165]
Restructuring

[0001262039-17-000008:mdna:166]
Restructuring expenses of $7.6 million in 2015, primarily relate to the restructuring activities in connection with the Meru acquisition to reduce our cost structure and improve operational efficiencies. See Note 9 to the consolidated financial statements for additional details, including types of expenses incurred and the timing of future expenses and cash payments. See also the “Liquidity and Capital Resources” section of this Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001262039-17-000008:mdna:167]
Interest income and other expense—net

[0001262039-17-000008:mdna:168]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| (in thousands, except percentages) |
| Interest income | $ | 5,295 |  |  | $ | 5,393 |  |  | $ | (98 | ) |  | (2 | )% |
| Other expense—net | (3,167 | ) |  | (3,168 | ) |  | 1 |  |  | — |  |

[0001262039-17-000008:mdna:169]
Interest income and other expense—net remained relatively consistent in 2015 compared to 2014. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Other expense—net consisted primarily of foreign exchange losses.

[0001262039-17-000008:mdna:170]
Provision for income taxes

[0001262039-17-000008:mdna:171]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2015 |  | 2014 |  |
| (in thousands, except percentages) |
| Provision for income taxes | $ | 9,018 |  |  | $ | 36,206 |  |  | $ | (27,188 | ) |  | (75 | )% |
| Effective tax rate (%) | 53 | % |  | 59 | % |  | (6 | )% |  | — |  |

[0001262039-17-000008:mdna:172]
Our effective tax rate was 53% for 2015, compared with an effective tax rate of 59% for 2014. The provision for income taxes for 2015 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and an increase in tax reserves, as well as the inclusion of stock-based compensation benefits and transfer pricing allocations which impacted jurisdictional income taxed at various tax rates. The decrease in the effective tax rate in 2015 was primarily due to higher research and development credits, additional tax benefits related to stock-based compensation expense and lower foreign withholding taxes.

[0001262039-17-000008:mdna:173]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of December 31, 2015, we had accrued $5.5 million for estimated interest related to uncertain tax provisions compared to an accrual of $1.7 million as of December 31, 2014.

[0001262039-17-000008:mdna:174]
Quarterly Results of Operations

[0001262039-17-000008:mdna:175]
The following table sets forth our unaudited quarterly statements of operations data for the last eight quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-17-000008:mdna:176]
|  | Three Months Ended |
|  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 (3) |  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |
|  | (in thousands, except per share amounts) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 158,925 |  |  | $ | 127,972 |  |  | $ | 136,641 |  |  | $ | 124,572 |  |  | $ | 144,759 |  |  | $ | 119,737 |  |  | $ | 114,777 |  |  | $ | 97,509 |  |
| Service | 203,905 |  |  | 188,674 |  |  | 174,750 |  |  | 160,004 |  |  | 151,770 |  |  | 140,331 |  |  | 125,008 |  |  | 115,377 |  |
| Total revenue | 362,830 |  |  | 316,646 |  |  | 311,391 |  |  | 284,576 |  |  | 296,529 |  |  | 260,068 |  |  | 239,785 |  |  | 212,886 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 56,616 |  |  | 50,267 |  |  | 52,788 |  |  | 49,313 |  |  | 55,466 |  |  | 46,167 |  |  | 47,397 |  |  | 41,368 |  |
| Service (1)(2) | 34,275 |  |  | 34,532 |  |  | 31,715 |  |  | 28,331 |  |  | 26,510 |  |  | 25,534 |  |  | 22,101 |  |  | 22,234 |  |
| Total cost of revenue | 90,891 |  |  | 84,799 |  |  | 84,503 |  |  | 77,644 |  |  | 81,976 |  |  | 71,701 |  |  | 69,498 |  |  | 63,602 |  |
| Total gross profit | 271,939 |  |  | 231,847 |  |  | 226,888 |  |  | 206,932 |  |  | 214,553 |  |  | 188,367 |  |  | 170,287 |  |  | 149,284 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 45,589 |  |  | 47,239 |  |  | 45,502 |  |  | 44,754 |  |  | 42,814 |  |  | 42,110 |  |  | 37,389 |  |  | 35,816 |  |
| Sales and marketing (1)(2) | 162,873 |  |  | 154,831 |  |  | 162,694 |  |  | 146,103 |  |  | 136,840 |  |  | 120,994 |  |  | 111,928 |  |  | 100,609 |  |
| General and administrative (1) | 17,451 |  |  | 22,006 |  |  | 22,184 |  |  | 19,439 |  |  | 20,315 |  |  | 21,220 |  |  | 18,018 |  |  | 11,961 |  |
| Restructuring charges | 833 |  |  | 2,283 |  |  | 553 |  |  | 328 |  |  | 1,717 |  |  | 5,883 |  |  | — |  |  | — |  |
| Total operating expenses | 226,746 |  |  | 226,359 |  |  | 230,933 |  |  | 210,624 |  |  | 201,686 |  |  | 190,207 |  |  | 167,335 |  |  | 148,386 |  |
| Operating income (loss) | 45,193 |  |  | 5,488 |  |  | (4,045 | ) |  | (3,692 | ) |  | 12,867 |  |  | (1,840 | ) |  | 2,952 |  |  | 898 |  |
| Interest income | 1,964 |  |  | 1,888 |  |  | 1,705 |  |  | 1,746 |  |  | 1,176 |  |  | 1,333 |  |  | 1,364 |  |  | 1,422 |  |
| Other expense—net | (3,650 | ) |  | (787 | ) |  | (1,350 | ) |  | (1,312 | ) |  | (1,007 | ) |  | (653 | ) |  | (830 | ) |  | (677 | ) |
| Income (loss) before income taxes | 43,507 |  |  | 6,589 |  |  | (3,690 | ) |  | (3,258 | ) |  | 13,036 |  |  | (1,160 | ) |  | 3,486 |  |  | 1,643 |  |
| Provision for (benefit from) income taxes | 18,341 |  |  | 298 |  |  | (2,302 | ) |  | (5,376 | ) |  | 15,570 |  |  | (9,329 | ) |  | 2,694 |  |  | 83 |  |
| Net income (loss) | $ | 25,166 |  |  | $ | 6,291 |  |  | $ | (1,388 | ) |  | $ | 2,118 |  |  | $ | (2,534 | ) |  | $ | 8,169 |  |  | $ | 792 |  |  | $ | 1,560 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.15 |  |  | $ | 0.04 |  |  | $ | (0.01 | ) |  | 0.01 |  |  | $ | (0.01 | ) |  | $ | 0.05 |  |  | $ | — |  |  | 0.01 |  |
| Diluted | $ | 0.14 |  |  | $ | 0.04 |  |  | $ | (0.01 | ) |  | $ | 0.01 |  |  | $ | (0.01 | ) |  | $ | 0.05 |  |  | $ | — |  |  | $ | 0.01 |  |

[0001262039-17-000008:mdna:177]
_______________________________________________

[0001262039-17-000008:mdna:178]
53

[0001262039-17-000008:mdna:179]
| (1) | Includes stock-based compensation as follows: |

[0001262039-17-000008:mdna:180]
|  | Three Months Ended |
|  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 |  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |
|  | (in thousands) |
| Cost of product revenue | $ | 313 |  |  | $ | 309 |  |  | $ | 298 |  |  | $ | 280 |  |  | $ | 332 |  |  | $ | 291 |  |  | $ | 210 |  |  | $ | 140 |  |
| Cost of service revenue | 2,276 |  |  | 2,238 |  |  | 2,123 |  |  | 2,134 |  |  | 1,980 |  |  | 1,849 |  |  | 1,660 |  |  | 1,632 |  |
| Research and development | 7,871 |  |  | 7,648 |  |  | 7,458 |  |  | 7,143 |  |  | 7,194 |  |  | 6,663 |  |  | 5,541 |  |  | 5,157 |  |
| Sales and marketing | 17,930 |  |  | 17,378 |  |  | 16,990 |  |  | 15,815 |  |  | 14,954 |  |  | 13,904 |  |  | 11,271 |  |  | 9,307 |  |
| General and administrative | 3,691 |  |  | 3,520 |  |  | 3,478 |  |  | 3,530 |  |  | 3,627 |  |  | 3,612 |  |  | 3,078 |  |  | 2,686 |  |
| Total stock-based compensation expense | $ | 32,081 |  |  | $ | 31,093 |  |  | $ | 30,347 |  |  | $ | 28,902 |  |  | $ | 28,087 |  |  | $ | 26,319 |  |  | $ | 21,760 |  |  | $ | 18,922 |  |

[0001262039-17-000008:mdna:181]
_______________________________________________

[0001262039-17-000008:mdna:182]
| (2) | Total amortization included in the product and service costs are as follows: |

[0001262039-17-000008:mdna:183]
|  | Three Months Ended |
|  | Dec 31,2016 |  | Sept 30,2016 |  | Jun 30,2016 |  | Mar 31,2016 |  | Dec 31,2015 |  | Sept 30,2015 |  | Jun 30,2015 |  | Mar 31,2015 |
|  | (in thousands) |
| Amortization of intangible assets | $ | 3,022 |  |  | $ | 2,839 |  |  | $ | 2,269 |  |  | $ | 1,178 |  |  | $ | 1,319 |  |  | $ | 1,319 |  |  | $ | 244 |  |  | $ | 244 |  |
| Impairment of intangible assets | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,593 |  |  | — |  |
| Total amortization and impairment of intangible assets | $ | 3,022 |  |  | $ | 2,839 |  |  | $ | 2,269 |  |  | $ | 1,178 |  |  | $ | 1,319 |  |  | $ | 1,319 |  |  | $ | 1,837 |  |  | $ | 244 |  |

[0001262039-17-000008:mdna:184]
_______________________________________________

[0001262039-17-000008:mdna:185]
| (3) | In March 2016, the Financial Accounting Standards Board issued Accounting Standard Update (“ASU”) No. 2016-09, which allows a company to make a policy election to account for forfeitures as they occur. We early adopted this standard and elected to account for forfeitures as they occur using the modified retrospective transition method. The adoption of this standard resulted in a decrease of $2.0 million in our share-based compensation during the first quarter of 2016. The adoption of ASU 2016-09 resulted in a decrease of $3.6 million in our provision for income taxes during the first quarter of 2016. |

[0001262039-17-000008:mdna:186]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-17-000008:mdna:187]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, which results in lower billings and product revenue. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-17-000008:mdna:188]
Our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first quarters of 2016 and 2015. Product revenue, on average throughout the year, increased in 2016 as compared to the same quarters in 2015, which we believe was due in part to the investments made in our sales and marketing organizations, to a robust security market and to continued product innovation. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues, which reflect our ongoing success in driving sales of low-end and high-end service bundles.

[0001262039-17-000008:mdna:189]
Total gross margin has fluctuated on a quarterly basis primarily due to shifts in the mix of sales between products and services and between products. Product gross margin varies based on the types of products sold and the average selling prices of our products. In addition, product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as inventory management efficiencies. Service gross margins, on average throughout the year, increased in 2016 compared to 2015 due to a mix shift to higher-margin service revenue, as well as scaled efficiencies.

[0001262039-17-000008:mdna:190]
Liquidity and Capital Resources

[0001262039-17-000008:mdna:191]
|  | As of December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 709,003 |  |  | $ | 543,277 |  |  | $ | 283,254 |  |
| Investments | 601,505 |  |  | 621,033 |  |  | 708,490 |  |
| Total cash, cash equivalents and investments | $ | 1,310,508 |  |  | $ | 1,164,310 |  |  | $ | 991,744 |  |
| Working capital | $ | 709,276 |  |  | $ | 591,873 |  |  | $ | 508,925 |  |
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 345,708 |  |  | $ | 282,547 |  |  | $ | 196,582 |  |
| Cash used in investing activities | (74,123 | ) |  | (967 | ) |  | (29,350 | ) |
| Cash provided by (used in) financing activities | (105,859 | ) |  | (21,557 | ) |  | 749 |  |
| Effect of exchange rates on cash and cash equivalents | — |  |  | — |  |  | (600 | ) |
| Net increase in cash and cash equivalents | $ | 165,726 |  |  | $ | 260,023 |  |  | $ | 167,381 |  |

[0001262039-17-000008:mdna:192]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, real estate and other capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the employee stock purchase plan, payment of taxes in connection with the net settlement of equity awards, and investments in strategic relationships that we have made or may make in the future. Our previous stock repurchase program (the “2015 Repurchase Program”) expired on December 31, 2015 with an unused balance under the 2015 Repurchase Program of $62.5 million. In January 2016, our board of directors approved a new share repurchase program, which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In October 2016, our board of directors authorized the purchase of additional $100.0 million of shares of our common stock under the 2016 Repurchase Program, increasing our current authorization to $300.0 million through December 31, 2017. In recent years we have received significant capital resources as a result of the exercise of stock options. We expect proceeds in future years to be impacted by the increased mix of restricted stock units (“RSU”) granted versus stock options and also to vary based on our share price. We expect to spend $140.0 million to $150.0 million in capital expenditures primarily related to purchase of real estate to expand our offices to support worldwide growth.

[0001262039-17-000008:mdna:193]
As of December 31, 2016, our cash, cash equivalents, and investments of $1.31 billion were invested primarily in corporate debt securities, commercial paper, U.S. government and agency securities, municipal bonds, money market funds, certificates of deposit and term deposits. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-17-000008:mdna:194]
As of December 31, 2016, $504.8 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. In the fourth quarter of 2016, we repatriated $55.0 million of cash from offshore.  A decision was made to bring this cash back to the U.S. as it carried a substantial foreign tax credit amounting to $22.3 million. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. We anticipate our capital expenditures spending in 2017 to be approximately $140.0 million to $150.0 million. Such capital expenditures include purchases completed in January 2017, purchases currently in escrow and purchases signed but not yet in escrow totaling $2.7 million, $88.0 million and $13.0 million, respectively. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-17-000008:mdna:195]
55

[0001262039-17-000008:mdna:196]
Operating Activities

[0001262039-17-000008:mdna:197]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-17-000008:mdna:198]
Our operating activities during 2016 provided $345.7 million in cash as a result of our continued growth of our business and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable and payments for inventory purchases. We are also starting to see a shift from product revenues to higher-margin, recurring service revenues. For example, our total revenue grew 26% in 2016 compared to 2015, while our total deferred revenue balance grew 31%.

[0001262039-17-000008:mdna:199]
Our operating activities during 2015 provided $282.5 million in cash as a result of our continued growth in billings and the ability to successfully manage our working capital. Additionally, in 2015, we received $9.0 million related to a mutual three-year covenant-not-to-sue agreement. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, partially offset by an increase in payments to vendors.

[0001262039-17-000008:mdna:200]
Our operating activities during 2014 provided $196.6 million in cash as a result of profitability, timing of billings and collections, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during 2014 consisted of net income of $25.3 million, increased by non-cash adjustments of $93.9 million and changes in operating assets and liabilities of $77.4 million. In 2014, we received $20.0 million pursuant to a six-year mutual covenant-not-to-sue and release agreement with Palo Alto Networks. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payments for inventory purchases, prepayment of certain expenses and payments of income taxes during the period.

[0001262039-17-000008:mdna:201]
Investing Activities

[0001262039-17-000008:mdna:202]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, and payments made in connection with business acquisitions. Historically, in making a lease versus purchase decision related to our larger facilities, we have elected to purchase the facility. We expect to make similar decisions in the future.

[0001262039-17-000008:mdna:203]
During 2016, cash used for investing activities was primarily due to the $67.2 million we spent on capital expenditures, including our purchases of a warehouse in Union City, California for total cash of $18.5 million, and a $22.1 million payment for the acquisition of AccelOps. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $15.1 million.

[0001262039-17-000008:mdna:204]
During 2015, cash used for investing activities was primarily due to $38.0 million used for the acquisition of Meru. In addition we spent $37.4 million on capital expenditures, including our purchases of certain real properties in Sunnyvale, California and Sophia, France for total cash of $13.9 million. The outflow of cash was partially offset by positive cash flow due to maturities, net of purchases, from our investments of $74.4 million.

[0001262039-17-000008:mdna:205]
During 2014, cash used for investing activities was primarily due to $32.2 million spent on capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $2.9 million.

[0001262039-17-000008:mdna:206]
Financing Activities

[0001262039-17-000008:mdna:207]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and ESPP, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-17-000008:mdna:208]
During 2016, cash used for financing activities was $105.9 million, primarily due to $110.8 million used to repurchase our common stock. This was partially offset by $6.6 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-17-000008:mdna:209]
During 2015, cash used for financing activities was $21.6 million primarily due to $60.0 million used to repurchase our common stock. This was partially offset by $38.4 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-17-000008:mdna:210]
During 2014, cash provided by financing activities was $0.7 million as a result of proceeds of $55.3 million from the issuance of common stock under our stock plans. This cash inflow was partially offset by $44.0 million used to repurchase our common stock and $10.6 million of taxes payment related to withholding.

[0001262039-17-000008:mdna:211]
Contractual Obligations and Commitments

[0001262039-17-000008:mdna:212]
The following summarizes our contractual obligations as of December 31, 2016:

[0001262039-17-000008:mdna:213]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in thousands) |
| Operating lease commitments (1) | $ | 65,489 |  |  | $ | 17,699 |  |  | $ | 35,510 |  |  | $ | 6,416 |  |  | $ | 5,864 |  |
| Inventory purchase commitments (2) | 91,247 |  |  | 91,247 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders (3) | 50,686 |  |  | 45,953 |  |  | 4,733 |  |  | — |  |  | — |  |
| Total | $ | 207,422 |  |  | $ | 154,899 |  |  | $ | 40,243 |  |  | $ | 6,416 |  |  | $ | 5,864 |  |

[0001262039-17-000008:mdna:214]
________________________

[0001262039-17-000008:mdna:215]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001262039-17-000008:mdna:216]
| (2) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-17-000008:mdna:217]
| (3) | Consists of an estimate of open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers and suppliers, for which we have not received the goods or services. No tax liabilities related to uncertain tax positions have been included in the table. As of December 31, 2016, we had $68.6 million of long-term tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur. |

[0001262039-17-000008:mdna:218]
Off-Balance Sheet Arrangements

[0001262039-17-000008:mdna:219]
During 2016, 2015 and 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-17-000008:mdna:220]
Recent Accounting Pronouncement

[0001262039-17-000008:mdna:221]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
