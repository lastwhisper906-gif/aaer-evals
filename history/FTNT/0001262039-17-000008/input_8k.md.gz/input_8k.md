# FTNT 8-K — 0001262039-17-000003 filed 2017-02-02

## item codes, every 8-K on or before 2017-03-01

- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2017-03-01

- none on or before 2017-03-01

## item 2.02 — earnings release, exhibit 99.1

[0001262039-17-000003:8k_2_02:1]
EX-99.1
2
ftntq4-2016ex991.htm
PRESS RELEASE

[0001262039-17-000003:8k_2_02:2]
Exhibit

[0001262039-17-000003:8k_2_02:3]
Press Release

[0001262039-17-000003:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Kelly Blough |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 x 81612 |  | 408-391-9408 |
| kblough@fortinet.com |  | swheatley@fortinet.com |

[0001262039-17-000003:8k_2_02:5]
Fortinet Reports Fourth Quarter and Full Year 2016 Financial Results

[0001262039-17-000003:8k_2_02:6]
Revenue and Billings Up 22% in Fourth Quarter

[0001262039-17-000003:8k_2_02:7]
Company Improves Profitability on GAAP and non-GAAP Basis

[0001262039-17-000003:8k_2_02:8]
Fourth Quarter 2016 Highlights

[0001262039-17-000003:8k_2_02:9]
•Revenue of $362.8 million, up 22% year over year

[0001262039-17-000003:8k_2_02:10]
•Billings of $463.4 million, up 22% year over year1

[0001262039-17-000003:8k_2_02:11]
•GAAP diluted net income per share $0.14

[0001262039-17-000003:8k_2_02:12]
•Non-GAAP diluted net income per share grew 67% year over year to $0.301

[0001262039-17-000003:8k_2_02:13]
•Cash flow from operations of $101.0 million

[0001262039-17-000003:8k_2_02:14]
•Free cash flow of $84.2 million1

[0001262039-17-000003:8k_2_02:15]
| • | Cash, cash equivalents and investments of $1.31 billion2 |

[0001262039-17-000003:8k_2_02:16]
| • | Deferred revenue of $1.04 billion, up 31% year over year |

[0001262039-17-000003:8k_2_02:17]
Full Year 2016 Highlights

[0001262039-17-000003:8k_2_02:18]
•Revenue of $1.28 billion, up 26% year over year

[0001262039-17-000003:8k_2_02:19]
•Billings of $1.52 billion, up 23% year over year1

[0001262039-17-000003:8k_2_02:20]
•GAAP diluted net income per share $0.18

[0001262039-17-000003:8k_2_02:21]
•Non-GAAP diluted net income per share grew 43% year over year to $0.731

[0001262039-17-000003:8k_2_02:22]
•Cash flow from operations of $345.7 million

[0001262039-17-000003:8k_2_02:23]
•Free cash flow of $278.5 million1

[0001262039-17-000003:8k_2_02:24]
SUNNYVALE, Calif. - February 2, 2017 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the fourth quarter and full year ended December 31, 2016.

[0001262039-17-000003:8k_2_02:25]
“We are pleased with our strong finish to 2016, demonstrating our strong technology advantage and revenue growth,” said Ken Xie, founder, chairman and chief executive officer. “Our ability to provide a broad, powerful, and automated Security Fabric that protects all points in the network, from IoT to cloud, sets Fortinet apart. This technology advantage, combined with improvements in sales execution delivered strong results in the mid to large enterprise segments of the market and position us well for future growth.”

[0001262039-17-000003:8k_2_02:26]
Financial Highlights for the Fourth Quarter of 2016

[0001262039-17-000003:8k_2_02:27]
| • | Revenue: Total revenue was $362.8 million for the fourth quarter of 2016, an increase of 22% compared to $296.5 million in the same quarter of 2015. Within total revenue, product revenue was $158.9 million, an increase of 10% compared to $144.8 million in the same quarter of 2015. Service revenue was $203.9 million, an increase of 34% compared to $151.8 million in the same quarter of 2015. |

[0001262039-17-000003:8k_2_02:28]
| • | Billings1: Total billings were $463.4 million for the fourth quarter of 2016, an increase of 22% compared to $380.9 million in the same quarter of 2015. |

[0001262039-17-000003:8k_2_02:29]
| • | Deferred Revenue: Total deferred revenue was $1.04 billion as of December 31, 2016, an increase of 31% compared to $791.3 million as of December 31, 2015. Total deferred revenue increased by $100.6 million compared to $934.8 million as of September 30, 2016. |

[0001262039-17-000003:8k_2_02:30]
| • | Cash2 and Cash Flow: As of December 31, 2016, cash, cash equivalents and investments were $1.31 billion, compared to $1.27 billion as of September 30, 2016. In the fourth quarter of 2016, cash flow from operations was $101.0 million compared to $68.6 million in the same quarter of 2015. Free cash flow1 was $84.2 million during the fourth quarter of 2016 compared to $60.2 million in the same quarter of 2015. |

[0001262039-17-000003:8k_2_02:31]
| • | GAAP Operating Income: GAAP operating income was $45.2 million for the fourth quarter of 2016, representing a GAAP operating margin of 12%. GAAP operating income was $12.9 million for the same quarter of 2015, representing a GAAP operating margin of 4%. |

[0001262039-17-000003:8k_2_02:32]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $81.1 million for the fourth quarter of 2016, representing a non-GAAP operating margin of 22%. Non-GAAP operating income was $47.6 million for the same quarter of 2015, representing a non-GAAP operating margin of 16%. |

[0001262039-17-000003:8k_2_02:33]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net income was $25.2 million for the fourth quarter of 2016, compared to GAAP net loss of $2.5 million for the same quarter of 2015. GAAP diluted net income per share was $0.14 for the fourth quarter of 2016, compared to GAAP diluted net loss per share of $0.01 for the same quarter of 2015. |

[0001262039-17-000003:8k_2_02:34]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $53.2 million for the fourth quarter of 2016, compared to non-GAAP net income of $32.4 million for the same quarter of 2015. Non-GAAP diluted net income per share was $0.30 for the fourth quarter of 2016, compared to $0.18 for the same quarter of 2015. |

[0001262039-17-000003:8k_2_02:35]
Financial Highlights for the Full Year 2016

[0001262039-17-000003:8k_2_02:36]
| • | Revenue: Total revenue was $1.28 billion for 2016, an increase of 26% compared to $1.01 billion in 2015. Within total revenue, product revenue was $548.1 million, an increase of 15% compared to $476.8 million in 2015. Service revenue was $727.3 million, an increase of 37% compared to $532.5 million in 2015. |

[0001262039-17-000003:8k_2_02:37]
| • | Billings1: Total billings were $1.52 billion for 2016, an increase of 23% compared to $1.23 billion in 2015. |

[0001262039-17-000003:8k_2_02:38]
| • | Cash Flow: In 2016, cash flow from operations was $345.7 million compared to $282.5 million in 2015. Free cash flow1 was $278.5 million in 2016 compared to $245.2 million in 2015. |

[0001262039-17-000003:8k_2_02:39]
| • | GAAP Operating Income: GAAP operating income was $42.9 million for 2016, representing a GAAP operating margin of 3%. GAAP operating income was $14.9 million for 2015, representing a GAAP operating margin of 1%. |

[0001262039-17-000003:8k_2_02:40]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $193.1 million for 2016, representing a non-GAAP operating margin of 15%. Non-GAAP operating income was $133.3 million for 2015, representing a non-GAAP operating margin of 13%. |

[0001262039-17-000003:8k_2_02:41]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $32.2 million for 2016, compared to GAAP net income of $8.0 million for 2015. GAAP diluted net income per share was $0.18 for 2016, compared to $0.05 for 2015. |

[0001262039-17-000003:8k_2_02:42]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $129.5 million for 2016, compared to non-GAAP net income of $89.4 million for 2015. Non-GAAP diluted net income per share was $0.73 for 2016, compared to $0.51 for 2015. |

[0001262039-17-000003:8k_2_02:43]
1 A reconciliation of GAAP to non-GAAP financial and liquidity measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-17-000003:8k_2_02:44]
2 During the fourth quarter and year ended December 31, 2016, we repurchased $35.8 million and $110.8 million, respectively, of our common stock under our share repurchase program. During the fourth quarter and year ended December 31, 2015, we repurchased $60.0 million of our common stock under our share repurchase program.

[0001262039-17-000003:8k_2_02:45]
Conference Call Details

[0001262039-17-000003:8k_2_02:46]
Fortinet will host a conference call today, February 2, 2017, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 40971273. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through February 9, 2017, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 40971273.

[0001262039-17-000003:8k_2_02:47]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 40987500. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through February 9, 2017 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 40987500.

[0001262039-17-000003:8k_2_02:48]
About Fortinet (www.fortinet.com)

[0001262039-17-000003:8k_2_02:49]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless

[0001262039-17-000003:8k_2_02:50]
protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. More than 300,000 customers worldwide trust Fortinet to protect their businesses. Learn more at http://www.fortinet.com, the Fortinet Blog, or FortiGuard Labs.

[0001262039-17-000003:8k_2_02:51]
#          #          #

[0001262039-17-000003:8k_2_02:52]
Copyright © 2017 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-17-000003:8k_2_02:53]
FTNT-F

[0001262039-17-000003:8k_2_02:54]
Forward-looking Statements

[0001262039-17-000003:8k_2_02:55]
Non-GAAP Financial Measures

[0001262039-17-000003:8k_2_02:56]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-17-000003:8k_2_02:57]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-17-000003:8k_2_02:58]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-17-000003:8k_2_02:59]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-17-000003:8k_2_02:60]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided

[0001262039-17-000003:8k_2_02:61]
by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees’ compensation and may impact their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-17-000003:8k_2_02:62]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income (loss) and diluted net income per share calculated in accordance with GAAP.

[0001262039-17-000003:8k_2_02:63]
FORTINET, INC.

[0001262039-17-000003:8k_2_02:64]
CONSOLIDATED BALANCE SHEETS

[0001262039-17-000003:8k_2_02:65]
(Unaudited, in thousands)

[0001262039-17-000003:8k_2_02:66]
|  | December 31, 2016 |  | December 31, 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 709,003 |  |  | $ | 543,277 |  |
| Short-term investments | 376,522 |  |  | 348,074 |  |
| Accounts receivable—net | 312,998 |  |  | 259,563 |  |
| Inventory | 106,887 |  |  | 83,868 |  |
| Prepaid expenses and other current assets | 33,306 |  |  | 35,761 |  |
| Total current assets | 1,538,716 |  |  | 1,270,543 |  |
| LONG-TERM INVESTMENTS | 224,983 |  |  | 272,959 |  |
| DEFERRED TAX ASSETS | 182,745 |  |  | 119,216 |  |
| PROPERTY AND EQUIPMENT—net | 137,249 |  |  | 91,067 |  |
| OTHER INTANGIBLE ASSETS—net | 24,828 |  |  | 17,640 |  |
| GOODWILL | 14,553 |  |  | 4,692 |  |
| OTHER ASSETS | 16,867 |  |  | 14,393 |  |
| TOTAL ASSETS | $ | 2,139,941 |  |  | $ | 1,790,510 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 56,732 |  |  | $ | 61,500 |  |
| Accrued liabilities | 35,640 |  |  | 33,028 |  |
| Accrued payroll and compensation | 78,138 |  |  | 61,111 |  |
| Income taxes payable | 13,588 |  |  | 8,379 |  |
| Deferred revenue | 645,342 |  |  | 514,652 |  |
| Total current liabilities | 829,440 |  |  | 678,670 |  |
| DEFERRED REVENUE | 390,007 |  |  | 276,651 |  |
| INCOME TAX LIABILITIES | 68,551 |  |  | 60,624 |  |
| OTHER LIABILITIES | 14,262 |  |  | 19,188 |  |
| Total liabilities | 1,302,260 |  |  | 1,035,133 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 173 |  |  | 171 |  |
| Additional paid-in capital | 800,653 |  |  | 687,658 |  |
| Accumulated other comprehensive loss | (765 | ) |  | (933 | ) |
| Retained earnings | 37,620 |  |  | 68,481 |  |
| Total stockholders’ equity | 837,681 |  |  | 755,377 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,139,941 |  |  | $ | 1,790,510 |  |

[0001262039-17-000003:8k_2_02:67]
FORTINET, INC.

[0001262039-17-000003:8k_2_02:68]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-17-000003:8k_2_02:69]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000003:8k_2_02:70]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 158,925 |  |  | $ | 144,759 |  |  | $ | 548,110 |  |  | $ | 476,782 |  |
| Service | 203,905 |  |  | 151,770 |  |  | 727,333 |  |  | 532,486 |  |
| Total revenue | 362,830 |  |  | 296,529 |  |  | 1,275,443 |  |  | 1,009,268 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 56,616 |  |  | 55,466 |  |  | 208,984 |  |  | 190,398 |  |
| Service 1 | 34,275 |  |  | 26,510 |  |  | 128,853 |  |  | 96,379 |  |
| Total cost of revenue | 90,891 |  |  | 81,976 |  |  | 337,837 |  |  | 286,777 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 102,309 |  |  | 89,293 |  |  | 339,126 |  |  | 286,384 |  |
| Service | 169,630 |  |  | 125,260 |  |  | 598,480 |  |  | 436,107 |  |
| Total gross profit | 271,939 |  |  | 214,553 |  |  | 937,606 |  |  | 722,491 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 45,589 |  |  | 42,814 |  |  | 183,084 |  |  | 158,129 |  |
| Sales and marketing 1 | 162,873 |  |  | 136,840 |  |  | 626,501 |  |  | 470,371 |  |
| General and administrative 1 | 17,451 |  |  | 20,315 |  |  | 81,080 |  |  | 71,514 |  |
| Restructuring charges | 833 |  |  | 1,717 |  |  | 3,997 |  |  | 7,600 |  |
| Total operating expenses | 226,746 |  |  | 201,686 |  |  | 894,662 |  |  | 707,614 |  |
| OPERATING INCOME | 45,193 |  |  | 12,867 |  |  | 42,944 |  |  | 14,877 |  |
| INTEREST INCOME | 1,964 |  |  | 1,176 |  |  | 7,303 |  |  | 5,295 |  |
| OTHER EXPENSE—net | (3,650 | ) |  | (1,007 | ) |  | (7,099 | ) |  | (3,167 | ) |
| INCOME BEFORE INCOME TAXES | 43,507 |  |  | 13,036 |  |  | 43,148 |  |  | 17,005 |  |
| PROVISION FOR INCOME TAXES | 18,341 |  |  | 15,570 |  |  | 10,961 |  |  | 9,018 |  |
| NET INCOME (LOSS) | $ | 25,166 |  |  | $ | (2,534 | ) |  | $ | 32,187 |  |  | $ | 7,987 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.15 |  |  | $ | (0.01 | ) |  | $ | 0.19 |  |  | $ | 0.05 |  |
| Diluted | $ | 0.14 |  |  | $ | (0.01 | ) |  | $ | 0.18 |  |  | $ | 0.05 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 173,315 |  |  | 171,831 |  |  | 172,621 |  |  | 170,385 |  |
| Diluted | 176,679 |  |  | 171,831 |  |  | 176,338 |  |  | 176,141 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 313 |  |  | $ | 332 |  |  | $ | 1,200 |  |  | $ | 973 |  |
| Cost of service revenue | 2,276 |  |  | 1,980 |  |  | 8,771 |  |  | 7,121 |  |
| Research and development | 7,871 |  |  | 7,194 |  |  | 30,120 |  |  | 24,555 |  |
| Sales and marketing | 17,930 |  |  | 14,954 |  |  | 68,113 |  |  | 49,436 |  |
| General and administrative | 3,691 |  |  | 3,627 |  |  | 14,219 |  |  | 13,003 |  |
|  | $ | 32,081 |  |  | $ | 28,087 |  |  | $ | 122,423 |  |  | $ | 95,088 |  |

[0001262039-17-000003:8k_2_02:71]
FORTINET, INC.

[0001262039-17-000003:8k_2_02:72]
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-17-000003:8k_2_02:73]
(Unaudited, in thousands)

[0001262039-17-000003:8k_2_02:74]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Net income (loss) | $ | 25,166 |  |  | $ | (2,534 | ) |  | $ | 32,187 |  |  | $ | 7,987 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Unrealized gains (losses) on investments | (1,411 | ) |  | (1,297 | ) |  | 258 |  |  | (897 | ) |
| Tax provision (benefit) related to items of other comprehensive income (loss) | (493 | ) |  | (454 | ) |  | 90 |  |  | (313 | ) |
| Other comprehensive income (loss)—net of taxes | (918 | ) |  | (843 | ) |  | 168 |  |  | (584 | ) |
| Comprehensive income (loss) | $ | 24,248 |  |  | $ | (3,377 | ) |  | $ | 32,355 |  |  | $ | 7,403 |  |

[0001262039-17-000003:8k_2_02:75]
FORTINET, INC.

[0001262039-17-000003:8k_2_02:76]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-17-000003:8k_2_02:77]
(Unaudited, in thousands)

[0001262039-17-000003:8k_2_02:78]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 25,166 |  |  | $ | (2,534 | ) |  | $ | 32,187 |  |  | $ | 7,987 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 13,624 |  |  | 9,383 |  |  | 48,520 |  |  | 31,589 |  |
| Amortization of investment premiums | 952 |  |  | 1,687 |  |  | 4,780 |  |  | 7,457 |  |
| Stock-based compensation | 32,081 |  |  | 28,087 |  |  | 122,423 |  |  | 95,088 |  |
| Other non-cash items—net | (2,202 | ) |  | 1,285 |  |  | 2,644 |  |  | 3,391 |  |
| Changes in operating assets and liabilities, net of assets acquired and liabilities assumed in business acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable—net | (70,663 | ) |  | (86,125 | ) |  | (57,875 | ) |  | (66,464 | ) |
| Inventory | (18,468 | ) |  | (6,661 | ) |  | (43,023 | ) |  | (19,088 | ) |
| Deferred tax assets | 7,183 |  |  | (1,554 | ) |  | (27,822 | ) |  | (29,851 | ) |
| Prepaid expenses and other current assets | (1,685 | ) |  | 5,176 |  |  | 2,616 |  |  | (2,630 | ) |
| Other assets | 243 |  |  | 931 |  |  | (2,352 | ) |  | 667 |  |
| Accounts payable | 1,623 |  |  | 7,325 |  |  | 39 |  |  | (2,517 | ) |
| Accrued liabilities | (3,808 | ) |  | 4,179 |  |  | (3,210 | ) |  | 883 |  |
| Accrued payroll and compensation | 12,443 |  |  | 13,196 |  |  | 15,696 |  |  | 11,301 |  |
| Other liabilities | (1,894 | ) |  | 3,247 |  |  | (5,013 | ) |  | 2,016 |  |
| Deferred revenue | 100,094 |  |  | 84,317 |  |  | 242,961 |  |  | 222,346 |  |
| Income taxes payable | 6,348 |  |  | 6,619 |  |  | 13,137 |  |  | 20,372 |  |
| Net cash provided by operating activities | 101,037 |  |  | 68,558 |  |  | 345,708 |  |  | 282,547 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |  |
| Purchases of investments | (103,035 | ) |  | (130,216 | ) |  | (473,608 | ) |  | (459,903 | ) |
| Sales of investments | 6,506 |  |  | 12,516 |  |  | 28,311 |  |  | 47,900 |  |
| Maturities of investments | 115,484 |  |  | 122,163 |  |  | 460,443 |  |  | 486,419 |  |
| Purchases of property and equipment | (16,863 | ) |  | (8,345 | ) |  | (67,182 | ) |  | (37,358 | ) |
| Payments made in connection with business acquisitions— net of cash acquired | — |  |  | — |  |  | (22,087 | ) |  | (38,025 | ) |
| Net cash provided by (used in) investing activities | 2,092 |  |  | (3,882 | ) |  | (74,123 | ) |  | (967 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock | 2,569 |  |  | 3,771 |  |  | 44,861 |  |  | 67,314 |  |
| Taxes paid related to net share settlement of equity awards | (8,380 | ) |  | (5,882 | ) |  | (38,266 | ) |  | (28,871 | ) |
| Repurchase and retirement of common stock | (35,828 | ) |  | (60,000 | ) |  | (110,828 | ) |  | (60,000 | ) |
| Payments of debt assumed in business acquisition | — |  |  | — |  |  | (1,626 | ) |  | — |  |
| Net cash used in financing activities | (41,639 | ) |  | (62,111 | ) |  | (105,859 | ) |  | (21,557 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 61,490 |  |  | 2,565 |  |  | 165,726 |  |  | 260,023 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 647,513 |  |  | 540,712 |  |  | 543,277 |  |  | 283,254 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 709,003 |  |  | $ | 543,277 |  |  | $ | 709,003 |  |  | $ | 543,277 |  |

[0001262039-17-000003:8k_2_02:79]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-17-000003:8k_2_02:80]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000003:8k_2_02:81]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-17-000003:8k_2_02:82]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Net cash provided by operating activities | $ | 101,037 |  |  | $ | 68,558 |  |  | $ | 345,708 |  |  | $ | 282,547 |  |
| Less purchases of property and equipment | (16,863 | ) |  | (8,345 | ) |  | (67,182 | ) |  | (37,358 | ) |
| Free cash flow | $ | 84,174 |  |  | $ | 60,213 |  |  | $ | 278,526 |  |  | $ | 245,189 |  |

[0001262039-17-000003:8k_2_02:83]
Reconciliation of GAAP operating income to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-17-000003:8k_2_02:84]
|  | Three Months Ended December 31, 2016 |  | Three Months Ended December 31, 2015 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 45,193 |  |  | $ | 35,936 |  | (a) | $ | 81,129 |  |  | $ | 12,867 |  |  | $ | 34,712 |  | (b) | $ | 47,579 |  |
| Operating margin | 12 | % |  |  |  | 22 | % |  | 4 | % |  |  |  | 16 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 32,081 |  |  |  |  |  |  | 28,087 |  |  |  |
| Amortization of acquired intangible assets |  |  | 3,022 |  |  |  |  |  |  | 1,319 |  |  |  |
| ERP-related expenses |  |  | — |  |  |  |  |  |  | 1,558 |  |  |  |
| Acquisition-related charges |  |  | — |  |  |  |  |  |  | 451 |  |  |  |
| Inventory fair value adjustment amortization |  |  | — |  |  |  |  |  |  | 1,580 |  |  |  |
| Restructuring charges |  |  | 833 |  |  |  |  |  |  | 1,717 |  |  |  |
| Tax adjustment |  |  | (7,875 | ) | (c) |  |  |  |  | 213 |  | (c) |  |
| Net income (loss) | $ | 25,166 |  |  | $ | 28,061 |  |  | $ | 53,227 |  |  | $ | (2,534 | ) |  | $ | 34,925 |  |  | $ | 32,391 |  |
| Diluted net income (loss) per share | $ | 0.14 |  |  |  |  | $ | 0.30 |  |  | $ | (0.01 | ) |  |  |  | $ | 0.18 |  |
| Shares used in diluted net income per share calculations | 176,679 |  |  |  |  | 176,679 |  |  | 171,831 |  |  |  |  | 176,657 |  |

[0001262039-17-000003:8k_2_02:85]
(a) To exclude $32.1 million of stock-based compensation, $3.0 million of amortization of acquired intangible assets, and $0.8 million of restructuring charges in the three months ended December 31, 2016.

[0001262039-17-000003:8k_2_02:86]
(b) To exclude $28.1 million of stock-based compensation, $1.3 million of amortization of acquired intangible assets, $1.6 million of ERP-related expenses, $0.5 million of acquisition-related charges, $1.6 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $1.7 million of restructuring charges in the three months ended December 31, 2015.

[0001262039-17-000003:8k_2_02:87]
(c)  Non-GAAP financial information is adjusted to achieve an overall 33% percent and 34% percent effective tax rate in 2016 and 2015, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-17-000003:8k_2_02:88]
|  | Year Ended December 31, 2016 |  | Year Ended December 31, 2015 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 42,944 |  |  | $ | 150,186 |  | (a) | $ | 193,130 |  |  | $ | 14,877 |  |  | $ | 118,447 |  | (b) | $ | 133,324 |  |
| Operating margin | 3 | % |  |  |  | 15 | % |  | 1 | % |  |  |  | 13 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 122,423 |  |  |  |  |  |  | 95,088 |  |  |  |
| Impairment of acquired intangible assets |  |  | — |  |  |  |  |  |  | 1,593 |  |  |  |
| Amortization of acquired intangible assets |  |  | 9,308 |  |  |  |  |  |  | 3,126 |  |  |  |
| ERP-related expenses |  |  | 13,362 |  |  |  |  |  |  | 5,426 |  |  |  |
| Acquisition-related charges |  |  | 254 |  |  |  |  |  |  | 2,732 |  |  |  |
| Inventory fair value adjustment amortization |  |  | 842 |  |  |  |  |  |  | 2,882 |  |  |  |
| Restructuring charges |  |  | 3,997 |  |  |  |  |  |  | 7,600 |  |  |  |
| Tax adjustment |  |  | (52,839 | ) | (c) |  |  |  |  | (37,036 | ) | (c) |  |
| Net income | $ | 32,187 |  |  | $ | 97,347 |  |  | $ | 129,534 |  |  | $ | 7,987 |  |  | $ | 81,411 |  |  | $ | 89,398 |  |
| Diluted net income per share | $ | 0.18 |  |  |  |  | $ | 0.73 |  |  | $ | 0.05 |  |  |  |  | $ | 0.51 |  |
| Shares used in diluted net income per share calculations | 176,338 |  |  |  |  | 176,338 |  |  | 176,141 |  |  |  |  | 176,141 |  |

[0001262039-17-000003:8k_2_02:89]
(a) To exclude $122.4 million of stock-based compensation, $9.3 million of amortization of acquired intangible assets, $13.4 million of ERP-related expenses, $0.3 million of acquisition-related charges, $0.8 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $4.0 million of restructuring charges in 2016.

[0001262039-17-000003:8k_2_02:90]
(b) To exclude $95.1 million of stock-based compensation, $1.6 million of impairment of acquired intangible assets, $3.1 million of amortization of acquired intangible assets, $5.4 million of ERP-related expenses, $2.7 million of acquisition-related charges, $2.9 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $7.6 million of restructuring charges in 2015.

[0001262039-17-000003:8k_2_02:91]
(c)  Non-GAAP financial information is adjusted to achieve an overall 33% percent and 34% percent effective tax rate in 2016 and 2015, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-17-000003:8k_2_02:92]
Reconciliation of diluted weighted average shares outstanding used in the calculation of GAAP and non-GAAP earnings per share

[0001262039-17-000003:8k_2_02:93]
|  |  | Three Months Ended |  | Year Ended |
|  |  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Shares used in diluted net loss per share calculations - GAAP |  | 176,679 |  |  | 171,831 |  |  | 176,338 |  |  | 176,141 |  |
| Adjustment for diluted weighted average shares outstanding | (a) | — |  |  | 4,826 |  |  | — |  |  | — |  |
| Shares used in diluted net income per share calculations - Non-GAAP |  | 176,679 |  |  | 176,657 |  |  | 176,338 |  |  | 176,141 |  |

[0001262039-17-000003:8k_2_02:94]
(a) GAAP diluted weighted average shares outstanding differs from non-GAAP diluted weighted average shares outstanding in periods when we have a GAAP net loss and a non-GAAP net income. The adjustment for diluted weighted average shares outstanding represents the dilutive effect of employee equity incentive plan awards and is calculated by applying the treasury stock method.

[0001262039-17-000003:8k_2_02:95]
Billings Reconciliation

[0001262039-17-000003:8k_2_02:96]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2016 |  | December 31, 2015 |  | December 31, 2016 |  | December 31, 2015 |
| Total revenue | $ | 362,830 |  |  | $ | 296,529 |  |  | $ | 1,275,443 |  |  | $ | 1,009,268 |  |
| Add change in deferred revenue | 100,557 |  |  | 84,392 |  |  | 244,046 |  |  | 232,546 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | — |  |  | (4,400 | ) |  | (9,800 | ) |
| Total billings | $ | 463,387 |  |  | $ | 380,921 |  |  | $ | 1,515,089 |  |  | $ | 1,232,014 |  |
