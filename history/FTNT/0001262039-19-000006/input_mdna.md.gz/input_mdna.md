# FTNT MD&A — 0001262039-19-000006


## mdna

[0001262039-19-000006:mdna:1]
ITEM 7.     Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001262039-19-000006:mdna:2]
| • | continued growth and market share gains; |

[0001262039-19-000006:mdna:3]
| • | variability in sales in certain product categories from year to year and between quarters; |

[0001262039-19-000006:mdna:4]
| • | expected impact of sales of certain products and services; |

[0001262039-19-000006:mdna:5]
| • | the impact of macro-economic and geopolitical factors on our sales; |

[0001262039-19-000006:mdna:6]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-19-000006:mdna:7]
| • | the impact of our product innovation strategy; |

[0001262039-19-000006:mdna:8]
| • | the effects of government regulation, tariffs and other related policies; |

[0001262039-19-000006:mdna:9]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, functionality and value in our standalone and bundled subscription service offerings; |

[0001262039-19-000006:mdna:10]
| • | growing our sales to businesses, service providers and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-19-000006:mdna:11]
| • | trends in revenue, cost of revenue and gross margin; |

[0001262039-19-000006:mdna:12]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses as a percentage of total revenue; |

[0001262039-19-000006:mdna:13]
| • | risks and expectations related to acquisitions or sales of assets, including integration issues related to product plans and products, including the acquired technology; |

[0001262039-19-000006:mdna:14]
| • | continued investments in research and development; |

[0001262039-19-000006:mdna:15]
| • | managing our continued investments in sales and marketing, and the impact of those investments; |

[0001262039-19-000006:mdna:16]
| • | expectations regarding uncertain tax benefits and our effective domestic and global tax rates; |

[0001262039-19-000006:mdna:17]
| • | expectations regarding spending related to real estate and other capital expenditures and to the impact on free cash flows; |

[0001262039-19-000006:mdna:18]
| • | competition in our markets; |

[0001262039-19-000006:mdna:19]
| • | our intentions regarding share repurchases and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-19-000006:mdna:20]
| • | other statements regarding our future operations, financial condition and prospects and business strategies; and |

[0001262039-19-000006:mdna:21]
| • | adoption and impact of new accounting standards, including those related to accounting for leases. |

[0001262039-19-000006:mdna:22]
42

[0001262039-19-000006:mdna:23]
Business Overview

[0001262039-19-000006:mdna:24]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of businesses, such as enterprises, communication service providers and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Security Fabric platform, which features automated protection, detection and responses.

[0001262039-19-000006:mdna:25]
The focus areas of our business consist of:

[0001262039-19-000006:mdna:26]
| • | Network Security—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, SD-WAN, SSL data leak prevention, VPN, switch and wireless controller and WAN acceleration. Our network security appliances include our FortiOS operating system, which provides the foundation for FortiGate security functions, and FortiASIC integrated circuit, which is designed to accelerate the processing of security and networking functions. Our customers may also purchase FortiGuard subscription services to receive threat intelligence updates. We provide standard technical support across all of our products through our FortiCare support services. We also offer services to end-customers including TAMs, REs and professional service consultants for implementations, as well as training services to our end-customers and channel partners. |

[0001262039-19-000006:mdna:27]
| • | Fortinet Security Fabric—The Fortinet Security Fabric platform is an architectural approach that protects the entire digital attack surface, including network core, endpoints, applications, data centers and private and public cloud. Together with our network of Fabric-Ready Partners, the Fortinet Security Fabric platform enables disparate security devices to work together as an integrated, automated and collaborative solution. |

[0001262039-19-000006:mdna:28]
| • | Cloud Security—We help customers connect securely to and across their cloud environments by offering security through our virtual firewall and other software products in public and private cloud environments. Our Cloud Security solutions, including our Client Access Security Broker Solution, FortiCASB, extend the core capabilities of the Fortinet Security Fabric platform to provide businesses with the same level of cybersecurity and threat intelligence in cloud environments that they receive on their physical networks. Fortinet cloud security offerings are available across all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and IBM Cloud. |

[0001262039-19-000006:mdna:29]
| • | Internet of Things and Operational Technology—The proliferation of IoT and OT devices has generated new opportunities for us to grow our business. IoT and OT have created an environment where data move freely between devices across locations, network environments, remote offices, mobile workers and public cloud environments, making the data difficult to consistently track and secure. |

[0001262039-19-000006:mdna:30]
Financial Highlights

[0001262039-19-000006:mdna:31]
| • | We recorded total revenue of $1.80 billion in 2018, an increase of 20% compared to $1.49 billion in 2017. Product revenue was $674.4 million in 2018, an increase of 17% compared to $577.2 million in 2017. Service revenue was $1.13 billion in 2018, an increase of 23% compared to $917.7 million in 2017. |

[0001262039-19-000006:mdna:32]
| • | We generated operating income of $231.0 million in 2018, an increase of 110% compared to $109.8 million in 2017. |

[0001262039-19-000006:mdna:33]
| • | Cash, cash equivalents and investments were $1.72 billion as of December 31, 2018, an increase of $367.3 million, or 27%, from December 31, 2017. |

[0001262039-19-000006:mdna:34]
| • | Deferred revenue was $1.69 billion as of December 31, 2018, an increase of $350.5 million, or 26%, from December 31, 2017. |

[0001262039-19-000006:mdna:35]
43

[0001262039-19-000006:mdna:36]
| • | We generated cash flows from operating activities of $638.9 million in 2018, an increase of $44.5 million, or 7%, compared to 2017. |

[0001262039-19-000006:mdna:37]
| • | In 2018, we repurchased 3.8 million shares of common stock under the Repurchase Program for an aggregate purchase price of $209.1 million. In 2017, we repurchased 11.2 million shares of common stock for a total purchase price of $446.3 million. |

[0001262039-19-000006:mdna:38]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew 17% in 2018. FortiGate unit shipments increased year-over-year. Sales of non-FortiGate products, such as the Fortinet Security Fabric and cloud products and services, also grew significantly. Service revenue growth of 23% in 2018 was driven by the strength of our FortiCare technical support and other service revenue, which combined grew 26%, and FortiGuard security subscription revenue, which grew 20%.

[0001262039-19-000006:mdna:39]
The percentage of our FortiGate-related billings from entry-level products increased from 31% in 2017 to 33% in 2018, the percentage of our FortiGate-related billings from mid-range products increased from 30% in 2017 to 32% in 2018 and the percentage of our FortiGate-related billings from high-end products decreased from 39% in 2017 to 35% in 2018. We continue to see our enterprise customers purchasing a fairly balanced mix of products across these product groups.

[0001262039-19-000006:mdna:40]
In 2018, operating expenses as a percentage of revenue decreased by 5 percentage points compared to 2017. The decrease in operating expenses was primarily driven by a decrease of 4 percentage points in sales and marketing expenses as a percentage of revenue, benefiting from the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”) for deferred contract costs, which reduced our commissions expense in absolute dollars and as a percentage of total revenue. In addition, general and administrative expenses as a percentage of revenue decreased by 1 percentage point while research and development expenses as a percentage of revenue remained consistent. Our sales and marketing expenses included a benefit of $45.5 million in 2018 from the adoption of Topic 606 related to deferred contract costs. Under Topic 606, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of Topic 606, we expensed the commissions related to these service contracts upfront. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 46% in 2018 compared to 47% in 2017. Refer to Note 1 to our consolidated financial statements for more information. Headcount increased by 15% to 5,845 employees and contractors as of December 31, 2018, up from 5,066 as of December 31, 2017.

[0001262039-19-000006:mdna:41]
Business Model

[0001262039-19-000006:mdna:42]
Our sales strategy is based on a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and service providers, who in turn sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across major cloud providers, and have recognized on-demand revenue from Amazon Web Services and Microsoft Azure and from customers who deploy our products at a cloud services provider in a bring-your-own-license (“BYOL”) such as from Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and IBM Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud. While the revenue from such sales is still relatively insignificant, it has increased significantly in recent periods on a percentage basis.

[0001262039-19-000006:mdna:43]
Typically, our customers purchase our hardware products and software licenses, as well as our FortiGuard security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. The invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis.

[0001262039-19-000006:mdna:44]
Our SPU hardware architecture is an important part of our approach to network security. The SPU includes three lines of proprietary ASICs: SPU CP, SPU NP and SPU SOC. The ASICs are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. As such, ASIC-based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-19-000006:mdna:45]
Key Metrics

[0001262039-19-000006:mdna:46]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational

[0001262039-19-000006:mdna:47]
efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Components of Operating Results,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-19-000006:mdna:48]
|  | Year Ended or As of December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Revenue | $ | 1,801.2 |  |  | $ | 1,494.9 |  |  | $ | 1,275.4 |  |
| Deferred revenue | $ | 1,686.8 |  |  | $ | 1,336.3 |  |  | $ | 1,035.3 |  |
| Billings (non-GAAP) | $ | 2,153.3 |  |  | $ | 1,795.9 |  |  | $ | 1,515.1 |  |
| Net cash provided by operating activities | $ | 638.9 |  |  | $ | 594.4 |  |  | $ | 345.7 |  |
| Free cash flow (non-GAAP) | $ | 585.9 |  |  | $ | 459.1 |  |  | $ | 278.5 |  |

[0001262039-19-000006:mdna:49]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue and of free cash flow to be recognized in future periods. Deferred revenue was $1.69 billion as of December 31, 2018, an increase of $350.5 million, or 26%, from December 31, 2017.

[0001262039-19-000006:mdna:50]
Billings (non-GAAP). We define billings as revenue recognized in accordance with generally accepted accounting principles in the United States (“GAAP”) plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of Topic 606 less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $2.15 billion for 2018, an increase of 20% compared to $1.80 billion in 2017.

[0001262039-19-000006:mdna:51]
A reconciliation of revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, to billings is provided below:

[0001262039-19-000006:mdna:52]
|  | Year Ended December 31, |
| 2018 |  | 2017 |  | 2016 |
| (in millions) |
| Billings: |  |  |  |  |  |
| Revenue | $ | 1,801.2 |  |  | $ | 1,494.9 |  |  | $ | 1,275.4 |  |
| Add: Change in deferred revenue | 350.5 |  |  | 301.0 |  |  | 244.1 |  |
| Add: Deferred revenue adjustment due to adoption of Topic 606 | 4.1 |  |  | — |  |  | — |  |
| Less: Deferred revenue balance acquired in business combinations | (2.5 | ) |  | — |  |  | (4.4 | ) |
| Total billings (non-GAAP) | $ | 2,153.3 |  |  | $ | 1,795.9 |  |  | $ | 1,515.1 |  |

[0001262039-19-000006:mdna:53]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used in other investing and financing activities. Management accounts for this limitation by providing information about our capital

[0001262039-19-000006:mdna:54]
45

[0001262039-19-000006:mdna:55]
expenditures and other investing and financing activities on the face of the consolidated statements of cash flows and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure. A reconciliation of net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, to free cash flow is provided below:

[0001262039-19-000006:mdna:56]
|  | Year Ended December 31, |
| 2018 |  | 2017 |  | 2016 |
| (in millions) |
| Free Cash Flow: |  |  |  |  |  |
| Net cash provided by operating activities | $ | 638.9 |  |  | $ | 594.4 |  |  | $ | 345.7 |  |
| Less: Purchases of property and equipment | (53.0 | ) |  | (135.3 | ) |  | (67.2 | ) |
| Free cash flow (non-GAAP) | $ | 585.9 |  |  | $ | 459.1 |  |  | $ | 278.5 |  |
| Net cash used in investing activities | $ | (134.9 | ) |  | $ | (76.8 | ) |  | $ | (74.1 | ) |
| Net cash used in financing activities | $ | (202.6 | ) |  | $ | (415.6 | ) |  | $ | (105.9 | ) |

[0001262039-19-000006:mdna:57]
Components of Operating Results

[0001262039-19-000006:mdna:58]
Revenue. We generate the majority of our revenue from sales of our hardware and software products and amortization of amounts included in deferred revenue related to previous sales of FortiGuard security subscription and FortiCare technical support services. We also recognize revenue from cloud business relationships and from providing professional services and training.

[0001262039-19-000006:mdna:59]
Our total revenue is comprised of the following:

[0001262039-19-000006:mdna:60]
| • | Product revenue. Product revenue is primarily generated from sales of our appliances. The majority of our product revenue has been generated by our FortiGate product line, and we do not expect this to change in the foreseeable future. Product revenue also includes revenue derived from sales of FortiGate software licenses and other software. As a percentage of total revenue, we expect that our product revenue may vary from quarter-to-quarter based on certain factors, as discussed below under “—Quarterly Results of Operations,” and we expect the trend to continue in 2019. |

[0001262039-19-000006:mdna:61]
| • | Service revenue. Service revenue is generated primarily from FortiGuard security subscription services and from FortiCare technical support services. We recognize revenue from FortiGuard security subscription and FortiCare technical support services over the contractual service period. Our typical contractual support and subscription term is one to three years and, to a lesser extent, five years. We also generate a small portion of our revenue from professional services and training services, for which we recognize revenue as the services are provided, and cloud-based services, for which we recognize revenue as the services are delivered or on a monthly usage basis. As a percentage of total revenue, we continue to expect service revenue to be higher than product revenue. Our service revenue growth rate depends significantly on the growth of our customer base, the expansion of our service bundle offerings, the expansion and introduction of new service offerings and the renewal of service contracts by our existing customers. |

[0001262039-19-000006:mdna:62]
Our total cost of revenue is comprised of the following:

[0001262039-19-000006:mdna:63]
| • | Cost of product revenue. The majority of the cost of product revenue consists of third-party contract manufacturers' costs and the costs of materials used in production. Our cost of product revenue also includes supplies, shipping costs, personnel costs associated with logistics and quality control, facility-related costs, excess and obsolete inventory costs, warranty costs, and amortization of intangible assets, if applicable. Personnel costs include direct compensation and benefits. |

[0001262039-19-000006:mdna:64]
| • | Cost of service revenue. Cost of service revenue is primarily comprised of salaries, benefits and bonuses, as well as stock-based compensation. Cost of service revenue also includes third-party repair and contract fulfillment, data center and cloud hosting, supplies and facility-related costs. |

[0001262039-19-000006:mdna:65]
Gross margin. Gross profit as a percentage of revenue, or gross margin, has been and will continue to be affected by a variety of factors, including the average sales price of our products, product costs, the mix of products sold and the mix of revenue between products, software licenses and services and any excess inventory write-offs. Service revenue and software licenses have had a positive effect on our total gross margin given the higher gross margins compared to product gross margins. During 2018, service gross margin benefited from renewals and continued sales of hardware bundled with services and subscriptions, growing faster than related expenses. Product gross margin was negatively impacted by new product introductions. As a result, the service margin expansion was partially offset by a decline in product gross margin in 2018. Overall gross margin in 2019 will be impacted by service and product revenue mix, but we expect it to be comparable to overall gross margin in 2018.

[0001262039-19-000006:mdna:66]
Operating expenses. Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. Personnel costs are the most significant component of operating expenses and consist primarily of salaries, benefits, bonuses, stock-based compensation, and sales commissions, as applicable. We expect personnel costs to continue to increase in absolute dollars as we expand our workforce.

[0001262039-19-000006:mdna:67]
| • | Research and development. Research and development expense consists primarily of personnel costs. Additional research and development expenses include ASIC and system prototypes and certification-related expenses, depreciation of property and equipment and facility-related expenses. The majority of our research and development is focused on both software development and the ongoing development of our hardware platform. We record all research and development expenses as incurred. Our research and development teams are primarily located in Canada and the United States. |

[0001262039-19-000006:mdna:68]
| • | Sales and marketing. Sales and marketing expense is the largest component of our operating expenses and primarily consists of personnel costs. Additional sales and marketing expenses include promotional lead generation and other marketing expenses, travel, depreciation of property and equipment and facility-related expenses. We intend to hire additional personnel focused on sales and marketing and expand our sales and marketing efforts worldwide in order to capture market share in the enterprise market. |

[0001262039-19-000006:mdna:69]
| • | General and administrative. General and administrative expense consists of personnel costs, as well as professional fees, depreciation of property and equipment and software and facility-related expenses. General and administrative personnel include our executive, finance, human resources, information technology and legal organizations. Our professional fees principally consist of outside legal, auditing, accounting, tax, information technology and other consulting costs. |

[0001262039-19-000006:mdna:70]
Interest income. Interest income consists of income earned on our cash, cash equivalents and investments. We have historically invested our cash in corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, and U.S. government and agency securities.

[0001262039-19-000006:mdna:71]
Other income (expense)—net. Other income (expense)—net consists primarily of foreign exchange gains and losses related to foreign currency remeasurement, as well as the gain on the sale of an investment in a privately held company.

[0001262039-19-000006:mdna:72]
Provision for (benefit from) income taxes. We are subject to income taxes in the United States, as well as other tax jurisdictions or countries in which we conduct business. Earnings from our non-U.S. activities are subject to income taxes in a local country, which are generally lower than U.S. tax rates, and may be subject to U.S. income taxes. Our effective tax rate differs from the U.S. statutory rate primarily due to foreign income subject to different tax rates than in the U.S., federal research and development tax credit, withholding taxes, excess tax benefits related to stock-based compensation expense and the tax impacts of the 2017 Tax Act.

[0001262039-19-000006:mdna:73]
47

[0001262039-19-000006:mdna:74]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. In December 2017, the SEC staff issued SAB 118, which allowed us to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As a result, we previously provided a provisional estimate of the effect of the 2017 Tax Act in our financial statements. In the fourth quarter of 2018, we completed our analysis to determine the effect of the 2017 Tax Act within the measurement period under the SEC guidance, and reflected an additional $32.6 million increase related to transition tax in the 2018 income tax expense. We expect further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts. We will continue to monitor and assess the impact of the 2017 Tax Act and the ongoing guidance and accounting interpretations issued in response to the 2017 Tax Act. Our selection of an accounting policy for 2018 with respect to the Global Intangible Low-Taxed Income (“GILTI”) tax rules was to treat GILTI tax as a current period expense under the period cost method.

[0001262039-19-000006:mdna:75]
Our effective tax rate approximates the federal corporate income tax rate and also includes the impact of state taxes, excess tax benefits related to stock-based compensation expense, federal research and development tax credit, foreign withholding tax, nondeductible stock-based compensation expense, foreign income subject to lower tax rates than income earned in the United States, book-to-tax basis differences and the tax impacts of the 2017 Tax Act.

[0001262039-19-000006:mdna:76]
Critical Accounting Policies and Estimates

[0001262039-19-000006:mdna:77]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-19-000006:mdna:78]
We believe that, of the significant accounting policies described in Note 1 to our consolidated financial statements included in Part II, Item 8 of this Annual Report on Form 10-K, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, we believe these are the most critical to fully understand and evaluate our financial condition and results of operations.

[0001262039-19-000006:mdna:79]
Revenue Recognition

[0001262039-19-000006:mdna:80]
On January 1, 2018, we adopted Topic 606, Revenue from Contracts with Customers, using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under ASC Topic 605 (“Topic 605”), Revenue Recognition.

[0001262039-19-000006:mdna:81]
Beginning in 2018, revenues are recognized when control of goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

[0001262039-19-000006:mdna:82]
Under Topic 606, we determine revenue recognition through the following steps:

[0001262039-19-000006:mdna:83]
| • | identification of a contract or contracts with a customer; |

[0001262039-19-000006:mdna:84]
| • | identification of the performance obligations in a contract, including evaluation of performance obligations as to being distinct goods or services in a contract; |

[0001262039-19-000006:mdna:85]
| • | determination of a transaction price; |

[0001262039-19-000006:mdna:86]
| • | allocation of a transaction price to the performance obligations in a contract; and |

[0001262039-19-000006:mdna:87]
| • | recognition of revenue when, or as, we satisfy a performance obligation. |

[0001262039-19-000006:mdna:88]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software licenses were distinct and distinct in the context of a contract from the security subscription and technical support services, as a customer can benefit from the hardware and software licenses without the services and the services are separately identifiable within a contract. We allocate a transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of a service contract that fall within a reasonably range as a percentage of list price.

[0001262039-19-000006:mdna:89]
Under the previous standard, Topic 605, revenue from contracts that contain products and services is allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in an arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-19-000006:mdna:90]
Deferred Contract Costs and Commission Expense

[0001262039-19-000006:mdna:91]
Beginning in 2018, we recognized commission expense based on Topic 606's guidance for contract costs. Under this new guidance, we recognize sales commissions related to product sales upfront while sales commissions for service contracts are deferred as deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term. Significant estimates, assumptions, and judgments in accounting for deferred contract costs include, but are not limited to, identification of contract costs, anticipated billings and the expected period of benefit.

[0001262039-19-000006:mdna:92]
Valuation of Inventory

[0001262039-19-000006:mdna:93]
Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record additional inventory write-downs which would be charged to cost of product revenue. Any write-downs could have an adverse impact on our gross margins and profitability.

[0001262039-19-000006:mdna:94]
Business Combinations

[0001262039-19-000006:mdna:95]
We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such changes are recorded in the period in which they are identified.

[0001262039-19-000006:mdna:96]
Contingent Liabilities

[0001262039-19-000006:mdna:97]
From time to time, we are involved in disputes, litigation and other legal actions. However, there are many uncertainties associated with any litigation, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.

[0001262039-19-000006:mdna:98]
49

[0001262039-19-000006:mdna:99]
Accounting for Income Taxes

[0001262039-19-000006:mdna:100]
We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-19-000006:mdna:101]
We recognize tax benefits from an uncertain tax position only if it is more likely than not, based on the technical merits of the position that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001262039-19-000006:mdna:102]
Effective January 1, 2018, the 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time transition tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. We expect further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts. Our selection of an accounting policy for 2018 with respect to the GILTI tax rules was to treat GILTI tax as a current period expense under the period cost method.

[0001262039-19-000006:mdna:103]
As part of the process of preparing our consolidated financial statements, we are required to estimate our taxes in each of the jurisdictions in which we operate. We estimate actual current tax exposure together with assessing temporary differences resulting from differing treatment of items, such as accruals and allowances not currently deductible for tax purposes. These differences result in deferred tax assets, which are included in our consolidated balance sheets. In general, deferred tax assets represent future tax benefits to be received when certain expenses previously recognized in our consolidated statements of income become deductible expenses under applicable income tax laws, or loss or credit carryforwards are utilized.

[0001262039-19-000006:mdna:104]
In assessing the realizability of deferred tax assets, management considers whether it is more likely than not that some portion or all of the deferred tax assets will be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We continue to assess the need for a valuation allowance on the deferred tax assets by evaluating both positive and negative evidence that may exist. Any adjustment to the valuation allowance on deferred tax assets would be recorded in the consolidated statements of income for the period that the adjustment is determined to be required.

[0001262039-19-000006:mdna:105]
Results of Operations

[0001262039-19-000006:mdna:106]
The following tables set forth our results of operations for the periods presented and as a percentage of our total revenue for those periods. The period-to-period comparison of financial results is not necessarily indicative of financial results to be achieved in future periods.

[0001262039-19-000006:mdna:107]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Consolidated Statements of Income Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 674.4 |  |  | $ | 577.2 |  |  | $ | 548.1 |  |
| Service | 1,126.8 |  |  | 917.7 |  |  | 727.3 |  |
| Total revenue | 1,801.2 |  |  | 1,494.9 |  |  | 1,275.4 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 291.0 |  |  | 243.8 |  |  | 209.0 |  |
| Service | 159.4 |  |  | 141.5 |  |  | 128.8 |  |
| Total cost of revenue | 450.4 |  |  | 385.3 |  |  | 337.8 |  |
| Gross profit: |  |  |  |  |  |
| Product | 383.4 |  |  | 333.4 |  |  | 339.1 |  |
| Service | 967.4 |  |  | 776.2 |  |  | 598.5 |  |
| Total gross profit | 1,350.8 |  |  | 1,109.6 |  |  | 937.6 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 244.5 |  |  | 210.6 |  |  | 183.1 |  |
| Sales and marketing | 782.3 |  |  | 701.0 |  |  | 626.5 |  |
| General and administrative | 93.0 |  |  | 87.9 |  |  | 81.1 |  |
| Restructuring charges | — |  |  | 0.3 |  |  | 4.0 |  |
| Total operating expenses | 1,119.8 |  |  | 999.8 |  |  | 894.7 |  |
| Operating income | 231.0 |  |  | 109.8 |  |  | 42.9 |  |
| Interest income | 26.5 |  |  | 13.5 |  |  | 7.3 |  |
| Other income (expense)—net | (6.6 | ) |  | 0.7 |  |  | (7.1 | ) |
| Income before income taxes | 250.9 |  |  | 124.0 |  |  | 43.1 |  |
| Provision for (benefit from) income taxes | (81.3 | ) |  | 92.6 |  |  | 10.9 |  |
| Net income | $ | 332.2 |  |  | $ | 31.4 |  |  | $ | 32.2 |  |

[0001262039-19-000006:mdna:108]
51

[0001262039-19-000006:mdna:109]
|  | Year Ended December 31, |
| 2018 |  | 2017 |  | 2016 |
| (as percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 37 | % |  | 39 | % |  | 43 | % |
| Service | 63 |  |  | 61 |  |  | 57 |  |
| Total revenue | 100 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 16 |  |  | 16 |  |  | 16 |  |
| Service | 9 |  |  | 9 |  |  | 10 |  |
| Total cost of revenue | 25 |  |  | 26 |  |  | 26 |  |
| Gross margin: |  |  |  |  |  |
| Product | 57 |  |  | 58 |  |  | 62 |  |
| Service | 86 |  |  | 85 |  |  | 82 |  |
| Total gross margin | 75 |  |  | 74 |  |  | 74 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 14 |  |  | 14 |  |  | 14 |  |
| Sales and marketing | 43 |  |  | 47 |  |  | 49 |  |
| General and administrative | 5 |  |  | 6 |  |  | 6 |  |
| Restructuring charges | — |  |  | — |  |  | 0.3 |  |
| Total operating expenses | 62 |  |  | 67 |  |  | 70 |  |
| Operating margin | 13 |  |  | 7 |  |  | 3 |  |
| Interest income | 1 |  |  | 1 |  |  | 1 |  |
| Other income (expense)—net | — |  |  | — |  |  | (1 | ) |
| Income before income taxes | 14 |  |  | 8 |  |  | 3 |  |
| Provision for (benefit from) income taxes | (5 | ) |  | 6 |  |  | 1 |  |
| Net income | 18 | % |  | 2 | % |  | 3 | % |

[0001262039-19-000006:mdna:110]
2018 and 2017

[0001262039-19-000006:mdna:111]
Revenue

[0001262039-19-000006:mdna:112]
|  | Year Ended December 31, |  |  |  |  |
| 2018 (1) |  | 2017 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 674.4 |  |  | 37 | % |  | $ | 577.2 |  |  | 39 | % |  | $ | 97.2 |  |  | 17 | % |
| Service | 1,126.8 |  |  | 63 |  |  | 917.7 |  |  | 61 |  |  | 209.1 |  |  | 23 |  |
| Total revenue | $ | 1,801.2 |  |  | 100 | % |  | $ | 1,494.9 |  |  | 100 | % |  | $ | 306.3 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 762.9 |  |  | 42 | % |  | $ | 642.3 |  |  | 43 | % |  | $ | 120.6 |  |  | 19 | % |
| Europe, Middle East and Africa (“EMEA”) | 678.0 |  |  | 38 |  |  | 554.6 |  |  | 37 |  |  | 123.4 |  |  | 22 |  |
| Asia Pacific (“APAC”) | 360.3 |  |  | 20 |  |  | 298.0 |  |  | 20 |  |  | 62.3 |  |  | 21 |  |
| Total revenue | $ | 1,801.2 |  |  | 100 | % |  | $ | 1,494.9 |  |  | 100 | % |  | $ | 306.3 |  |  | 20 | % |

[0001262039-19-000006:mdna:113]
(1) Revenue during 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows:

[0001262039-19-000006:mdna:114]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
|  | (in millions) |
| Revenue: |  |  |  |  |  |
| Product | $ | 674.4 |  |  | $ | 654.9 |  |  | $ | 19.5 |  |
| Service | 1,126.8 |  |  | 1,126.9 |  |  | (0.1 | ) |
| Total revenue | $ | 1,801.2 |  |  | $ | 1,781.8 |  |  | $ | 19.4 |  |
| Revenue by geography: |  |  |  |  |  |
| Americas | $ | 762.9 |  |  | $ | 746.2 |  |  | $ | 16.7 |  |
| EMEA | 678.0 |  |  | 674.9 |  |  | 3.1 |  |
| APAC | 360.3 |  |  | 360.7 |  |  | (0.4 | ) |
| Total revenue | $ | 1,801.2 |  |  | $ | 1,781.8 |  |  | $ | 19.4 |  |

[0001262039-19-000006:mdna:115]
Total revenue increased by $306.3 million, or 20%, in 2018 compared to 2017. We continued to experience global diversification of revenue in 2018. Revenue from all our regions grew, with EMEA contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $97.2 million, or 17%, in 2018 compared to 2017. Product revenue benefited from the adoption of Topic 606, primarily related to the change in accounting treatment under Topic 606 for some of our software products where revenue from these arrangements can now be recognized upfront instead of ratably over the contracted service term, and partially offset by the lost opportunity to recognize revenue that had been deferred and was written off to equity on the date of adoption. In addition, FortiGate unit shipments increased in 2018 compared to 2017 while sales of non-FortiGate products, such as the Fortinet Security Fabric hardware and software products, also grew significantly. Fortinet Security Fabric products were the fastest growing products compared to the remainder of our business. Service revenue increased by $209.1 million, or 23%, in 2018 compared to 2017. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support and other contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-19-000006:mdna:116]
Cost of revenue and gross margin

[0001262039-19-000006:mdna:117]
|  | Year Ended December 31, |  |  |  |  |
| 2018 (1) |  | 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 291.0 |  |  | $ | 243.8 |  |  | $ | 47.2 |  |  | 19 | % |
| Service | 159.4 |  |  | 141.5 |  |  | 17.9 |  |  | 13 |  |
| Total cost of revenue | $ | 450.4 |  |  | $ | 385.3 |  |  | $ | 65.1 |  |  | 17 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.9 | % |  | 57.8 | % |  |  |  |  |  |
| Service | 85.9 |  |  | 84.6 |  |  |  |  |  |  |
| Total gross margin | 75.0 | % |  | 74.2 | % |  |  |  |  |  |

[0001262039-19-000006:mdna:118]
53

[0001262039-19-000006:mdna:119]
(1) Cost of revenue and gross margin during 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows:

[0001262039-19-000006:mdna:120]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
|  | (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |
| Product | $ | 291.0 |  |  | $ | 289.6 |  |  | $ | 1.4 |  |
| Service | 159.4 |  |  | 159.4 |  |  | — |  |
| Total cost of revenue | $ | 450.4 |  |  | $ | 449.0 |  |  | $ | 1.4 |  |
| Gross margin (%): |  |  |  |  |  |
| Product | 56.9 | % |  | 55.8 | % |  |  |
| Service | 85.9 |  |  | 85.9 |  |  |  |
| Total gross margin | 75.0 | % |  | 74.8 | % |  |  |

[0001262039-19-000006:mdna:121]
Total gross margin increased by 0.8 percentage points in 2018 compared to 2017, driven by higher margin on higher service revenue. Service gross margin increased by 1.3 percentage points during 2018 as compared to 2017, due to the strength of our FortiCare technical support and other revenue growing 26%. FortiGuard security subscription revenue grew 20%, during 2018 compared to 2017, which outpaced the increase in the related personnel costs and headcount growth, resulting in higher margin. Cost of service revenue was comprised primarily of personnel costs. Product gross margin decreased by 0.9 percentage points in 2018 compared to 2017, as we continued to transition to our new product introductions. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges.

[0001262039-19-000006:mdna:122]
Operating expenses

[0001262039-19-000006:mdna:123]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2018 (1) |  | 2017 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 244.5 |  |  | 14 | % |  | $ | 210.6 |  |  | 14 | % |  | $ | 33.9 |  |  | 16 | % |
| Sales and marketing | 782.3 |  |  | 43 |  |  | 701.0 |  |  | 47 |  |  | 81.3 |  |  | 12 |  |
| General and administrative | 93.0 |  |  | 5 |  |  | 87.9 |  |  | 6 |  |  | 5.1 |  |  | 6 |  |
| Restructuring charges | — |  |  | — |  |  | 0.3 |  |  | — |  |  | (0.3 | ) |  | (100 | ) |
| Total operating expenses | $ | 1,119.8 |  |  | 62 | % |  | $ | 999.8 |  |  | 67 | % |  | $ | 120.0 |  |  | 12 | % |

[0001262039-19-000006:mdna:124]
(1) Operating expenses during 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows:

[0001262039-19-000006:mdna:125]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
|  | (in millions) |
| Operating expenses: |  |  |  |  |  |
| Research and development | $ | 244.5 |  |  | $ | 244.5 |  |  | $ | — |  |
| Sales and marketing expenses | 782.3 |  |  | 827.8 |  |  | (45.5 | ) |
| General and administrative | 93.0 |  |  | 93.0 |  |  | — |  |
| Total operating expenses | $ | 1,119.8 |  |  | $ | 1,165.3 |  |  | $ | (45.5 | ) |

[0001262039-19-000006:mdna:126]
Research and development

[0001262039-19-000006:mdna:127]
Research and development expense increased by $33.9 million, or 16%, in 2018 compared to 2017, primarily due to an increase of $28.7 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, depreciation and other occupancy-related costs increased by $2.8 million and product development costs, such as third-party testing and prototypes, increased by $1.2 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars in 2019.

[0001262039-19-000006:mdna:128]
Sales and marketing

[0001262039-19-000006:mdna:129]
Sales and marketing expense increased by $81.3 million, or 12%, in 2018 compared to 2017, primarily due to an increase of $64.9 million in personnel costs, including higher stock-based compensation expense of $17.6 million. Sales and marketing headcount increased in order to drive market share gains globally. The increase in personnel costs included a benefit of $45.5 million from the adoption of Topic 606 related to deferred contract costs. Under Topic 606, we capitalized certain commissions on service contracts and amortize the amount over a certain period. Prior to the adoption of this new standard, we expensed the commissions related to these service contracts. Our sales and marketing expense would have increased by $126.8 million, or 18%, under Topic 605. Refer to Note 1 in our notes to the consolidated financial statements for more information. In addition, depreciation expense and other occupancy-related expense increased by $6.7 million, travel and entertainment expense increased by $6.4 million and supplies expense increased by $2.0 million. As a percentage of total revenue, sales and marketing expense decreased primarily due to the benefit from the new accounting standard on deferred contract costs. Excluding this benefit, sales and marketing expense as a percentage of revenue would have been 46% of total revenue. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, and expect sales and marketing expense to increase in absolute dollars in 2019.

[0001262039-19-000006:mdna:130]
General and administrative

[0001262039-19-000006:mdna:131]
General and administrative expense increased by $5.1 million, or 6%, in 2018 compared to 2017. Personnel costs increased by $9.8 million as we continued to increase headcount in order to support our expanding business. The increase in expense was partially offset by a decrease in litigation costs of $1.2 million and a decrease in professional fees of $0.6 million. Certain facilities, depreciation, and information technology costs are allocated to other organizations based on headcount. We expect general and administrative expense to increase in absolute dollars in 2019.

[0001262039-19-000006:mdna:132]
Operating income and margin

[0001262039-19-000006:mdna:133]
We generated operating income of $231.0 million in 2018, an increase of $121.2 million, or 110%, compared to $109.8 million in 2017. The improvement in operating income included the benefit from the adoption of Topic 606, along with revenue growth outpacing expense growth. Operating income as a percentage of revenue increased to 13% in 2018 compared to 7% in 2017. The increase in operating margin is primarily due to a decline in sales and marketing expenses as a percentage of total revenue to 43% in 2018 compared to 47% in 2017. Excluding the benefit from the adoption of Topic 606, sales and marketing expense as a percentage of revenue would have been 46% of total revenue. The adoption of Topic 606 resulted in an improvement of 3 percentage points in our operating margin. In addition, general and administrative expenses as a percentage of total revenue decreased by 1 percentage point and gross margin improved by 0.8 percentage points, contributing to the improvement in operating margin. Research and development expenses as a percentage of revenue remained consistent.

[0001262039-19-000006:mdna:134]
Interest income and other income (expense)—net

[0001262039-19-000006:mdna:135]
|  | Year Ended December 31, |  |  |  |  |
| 2018 |  | 2017 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 26.5 |  |  | $ | 13.5 |  |  | $ | 13.0 |  |  | 96 | % |
| Other income (expense)—net | (6.6 | ) |  | 0.7 |  |  | (7.3 | ) |  | (1,043 | ) |

[0001262039-19-000006:mdna:136]
Interest income increased in 2018 as compared to 2017, primarily due to higher interest rates on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other income (expense)—net in 2018 as

[0001262039-19-000006:mdna:137]
compared to 2017 was the result of $9.3 million of foreign currency transaction and hedging losses recognized in 2018, offset by $2.2 million in gain on the sale of an investment in a privately held company.

[0001262039-19-000006:mdna:138]
Provision for (benefit from) income taxes

[0001262039-19-000006:mdna:139]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2018 (1) |  | 2017 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | (81.3 | ) |  | $ | 92.6 |  |  | $ | (173.9 | ) |  | (188 | )% |
| Effective tax rate | (32 | )% |  | 75 | % |  |  |  |  |  |  |

[0001262039-19-000006:mdna:140]
(1) Provision for income taxes during 2018 under Topic 606 (As Reported) and 605 (Balances Without Adoption of Topic 606) were as follows:

[0001262039-19-000006:mdna:141]
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | (Increase) Decrease |
|  | (in millions, except percentages) |
| Benefit from income taxes | $ | (81.3 | ) |  | $ | (92.2 | ) |  | $ | 10.9 |  |
| Effective tax rate | (32 | )% |  | (49 | )% |  |  |

[0001262039-19-000006:mdna:142]
Our provision for income taxes for 2018 reflects an effective tax rate benefit of (32)%, compared to an effective tax rate provision of 75% for 2017. The benefit from income taxes for 2018 was comprised primarily of impacts related to the 2017 Tax Act including a benefit of $164.0 million from the realignment of our tax structure and operations that resulted in a book-to-tax basis difference from previously taxed off-shore deferred revenue. These benefits were partially offset by a $32.6 million increase in the transition tax for finalization of the provisional estimates under SAB 118, a $20.5 million tax expense for the impact of the GILTI and a $29.6 million of tax expense related to U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes and a decrease in tax reserves.

[0001262039-19-000006:mdna:143]
Effective January 1, 2018, the 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. In December 2017, the SEC staff issued SAB 118, which allowed us to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As a result, we previously provided a provisional estimate of the effect of the 2017 Tax Act in our financial statements. In the fourth quarter of 2018, we completed our analysis to determine the effect of the 2017 Tax Act within the measurement period under the SEC guidance, and reflected an increase of an additional $32.6 million related to the transition tax in the 2018 income tax expense. We expect further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts.

[0001262039-19-000006:mdna:144]
In 2017, the effective tax rate was 75%, primarily resulting from the deferred tax assets remeasurement and a one-time transition tax due to the 2017 Tax Act. Excluding the tax impacts from the 2017 Tax Act, our 2017 effective tax rate would have been 24%.

[0001262039-19-000006:mdna:145]
2017 and 2016

[0001262039-19-000006:mdna:146]
Revenue

[0001262039-19-000006:mdna:147]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 577.2 |  |  | 39 | % |  | $ | 548.1 |  |  | 43 | % |  | $ | 29.1 |  |  | 5 | % |
| Service | 917.7 |  |  | 61 |  |  | 727.3 |  |  | 57 |  |  | 190.4 |  |  | 26 |  |
| Total revenue | $ | 1,494.9 |  |  | 100 | % |  | $ | 1,275.4 |  |  | 100 | % |  | $ | 219.5 |  |  | 17 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 642.3 |  |  | 43 | % |  | $ | 536.7 |  |  | 42 | % |  | $ | 105.6 |  |  | 20 | % |
| EMEA | 554.6 |  |  | 37 |  |  | 477.4 |  |  | 37 |  |  | 77.2 |  |  | 16 |  |
| APAC | 298.0 |  |  | 20 |  |  | 261.3 |  |  | 21 |  |  | 36.7 |  |  | 14 |  |
| Total revenue | $ | 1,494.9 |  |  | 100 | % |  | $ | 1,275.4 |  |  | 100 | % |  | $ | 219.5 |  |  | 17 | % |

[0001262039-19-000006:mdna:148]
Total revenue increased by $219.5 million, or 17%, in 2017 compared to 2016. We continued to experience global diversification of revenue in 2017. Revenue from all our regions grew, with the Americas contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $29.1 million, or 5%, in 2017 compared to 2016. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family across all product categories. Sales of non-FortiGate products, such as the Fortinet Security Fabric hardware and software products, and services, also grew significantly. Service revenue increased by $190.4 million, or 26%, in 2017 compared to 2016. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods.

[0001262039-19-000006:mdna:149]
Cost of revenue and gross margin

[0001262039-19-000006:mdna:150]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 243.8 |  |  | $ | 209.0 |  |  | $ | 34.8 |  |  | 17 | % |
| Service | 141.5 |  |  | 128.8 |  |  | 12.7 |  |  | 10 |  |
| Total cost of revenue | $ | 385.3 |  |  | $ | 337.8 |  |  | $ | 47.5 |  |  | 14 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 57.8 | % |  | 61.9 | % |  |  |  |  |  |
| Service | 84.6 |  |  | 82.3 |  |  |  |  |  |  |
| Total gross margin | 74.2 | % |  | 73.5 | % |  |  |  |  |  |

[0001262039-19-000006:mdna:151]
Total gross margin increased by 0.7 percentage points in 2017 compared to 2016, driven by higher margin on service revenue. During 2017, service gross margin benefited from the shift to higher-margin service revenue. Product gross margin was negatively impacted by longer term deals, resulting in lower product revenue recognized in 2017 and higher deferred revenue for services that was expected to be recognized in future periods, and as a result of product costs being recognized upon shipment. As a result, the service margin expansion was partially offset by a decline in product gross margin in 2017. Total cost of product revenue was comprised primarily of direct and indirect cost of products sold, inventory reserves and other charges. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-19-000006:mdna:152]
57

[0001262039-19-000006:mdna:153]
Operating expenses

[0001262039-19-000006:mdna:154]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 210.6 |  |  | 14 | % |  | $ | 183.1 |  |  | 14 | % |  | $ | 27.5 |  |  | 15 | % |
| Sales and marketing | 701.0 |  |  | 47 |  |  | 626.5 |  |  | 49 |  |  | 74.5 |  |  | 12 |  |
| General and administrative | 87.9 |  |  | 6 |  |  | 81.1 |  |  | 6 |  |  | 6.8 |  |  | 8 |  |
| Restructuring charges | 0.3 |  |  | — |  |  | 4.0 |  |  | 0.3 |  |  | (3.7 | ) |  | (93 | ) |
| Total operating expenses | $ | 999.8 |  |  | 67 | % |  | $ | 894.7 |  |  | 70 | % |  | $ | 105.1 |  |  | 12 | % |

[0001262039-19-000006:mdna:155]
Research and development

[0001262039-19-000006:mdna:156]
Research and development expense increased by $27.5 million, or 15%, in 2017 compared to 2016, primarily due to an increase of $17.6 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, product development costs, such as third-party testing and prototypes, increased by $6.2 million and depreciation and other occupancy-related costs increased by $3.1 million.

[0001262039-19-000006:mdna:157]
Sales and marketing

[0001262039-19-000006:mdna:158]
Sales and marketing expense increased by $74.5 million, or 12%, in 2017 compared to 2016, primarily due to an increase of $55.1 million in personnel costs as we continued to increase our sales and marketing headcount in order to drive continued market share gains globally. Marketing-related expense increased by $11.9 million as we invested significantly in marketing programs to drive broader market awareness, build lead generation programs and accelerate pipeline. In addition, depreciation expense and other occupancy-related expense increased by $6.8 million. As a percentage of total revenue, sales and marketing expense decreased as revenue grew at a higher pace compared to personnel costs.

[0001262039-19-000006:mdna:159]
General and administrative

[0001262039-19-000006:mdna:160]
General and administrative expense increased by $6.8 million, or 8%, in 2017 compared to 2016. Personnel costs increased by $8.5 million as we continued to increase headcount in order to support our expanding business. Professional fees increased by $10.6 million, primarily due to the implementation of a new revenue recognition system and a litigation settlement expense of $1.8 million. The increase in expense was partially offset by a decrease in third-party costs of $13.4 million related to the substantial completion of our ERP system implementation in 2016.

[0001262039-19-000006:mdna:161]
Operating income and margin

[0001262039-19-000006:mdna:162]
We generated operating income of $109.8 million in 2017, an increase of $66.9 million, or 156%, compared to $42.9 million in 2016. The improvement in operating margin was primarily due to the improvement in gross margin, and the decline in sales and marketing expenses as a percentage of total revenue. As a percentage of total revenue, sales and marketing expenses decreased to 47% in 2017 from 49% in 2016.

[0001262039-19-000006:mdna:163]
Interest income and other income (expense)—net

[0001262039-19-000006:mdna:164]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| (in millions, except percentages) |
| Interest income | $ | 13.5 |  |  | $ | 7.3 |  |  | $ | 6.2 |  |  | 85 | % |
| Other income (expense)—net | 0.7 |  |  | (7.1 | ) |  | 7.8 |  |  | (110 | ) |

[0001262039-19-000006:mdna:165]
Interest income increased in 2017 as compared to 2016, primarily due to higher interest rates on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the

[0001262039-19-000006:mdna:166]
58

[0001262039-19-000006:mdna:167]
period, types and mix of investments, and market interest rates. The change in other income (expense)—net in 2017 as compared to 2016 was the result of a gain of approximately $1.0 million for foreign currency exchange gains in 2017 compared to a loss of $6.6 million in 2016, due primarily to changes in the value of Euro relative to the U.S. dollar.

[0001262039-19-000006:mdna:168]
Provision for income taxes

[0001262039-19-000006:mdna:169]
|  | Year Ended December 31, |  | Change |  | % Change |
| 2017 |  | 2016 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 92.6 |  |  | $ | 10.9 |  |  | $ | 81.7 |  |  | 750 | % |
| Effective tax rate | 75 | % |  | 25 | % |  |  |  |  |  |

[0001262039-19-000006:mdna:170]
Our effective tax rate was 75% for 2017, compared to an effective tax rate of 25% for 2016. The provision for income taxes for 2017 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, an increase in tax reserves, remeasurement of deferred tax assets and a one-time transition tax.

[0001262039-19-000006:mdna:171]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate.

[0001262039-19-000006:mdna:172]
The SEC staff has issued SAB 118, which provides guidance on accounting for the tax effects of the 2017 Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the 2017 Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the 2017 Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the 2017 Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the 2017 Tax Act.

[0001262039-19-000006:mdna:173]
The increase in the effective tax rate in 2017 was primarily due to the deferred tax assets remeasurement and a one-time transition tax due to the 2017 Tax Act. Excluding the tax impact from the 2017 Tax Act, the 2017 effective tax rate would have been 24%, which was relatively consistent with 2016. In 2016, due to the early adoption of ASU 2016-09, approximately $10.8 million of excess tax benefits were recognized in the income tax provision. In 2017, $13.5 million of excess tax benefits was included in the income tax provision.

[0001262039-19-000006:mdna:174]
Quarterly Results of Operations

[0001262039-19-000006:mdna:175]
The following table sets forth our unaudited quarterly statements of income data for the last eight quarters. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods. This data should be read in conjunction with our audited consolidated financial statements and related notes included elsewhere in this annual report. These quarterly operating results are not necessarily indicative of our operating results for any future period.

[0001262039-19-000006:mdna:176]
|  | Three Months Ended |
|  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |
|  | (in millions, except per share amounts) |
| Consolidated Statements of Income Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 200.8 |  |  | $ | 164.5 |  |  | $ | 166.3 |  |  | $ | 142.8 |  |  | $ | 162.1 |  |  | $ | 137.1 |  |  | $ | 142.7 |  |  | $ | 135.3 |  |
| Service | 306.2 |  |  | 289.4 |  |  | 275.0 |  |  | 256.2 |  |  | 254.5 |  |  | 237.1 |  |  | 220.8 |  |  | 205.3 |  |
| Total revenue | 507.0 |  |  | 453.9 |  |  | 441.3 |  |  | 399.0 |  |  | 416.6 |  |  | 374.2 |  |  | 363.5 |  |  | 340.6 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1)(2) | 86.9 |  |  | 72.0 |  |  | 73.9 |  |  | 58.2 |  |  | 69.6 |  |  | 58.1 |  |  | 60.8 |  |  | 55.3 |  |
| Service (1)(2) | 41.6 |  |  | 39.6 |  |  | 39.2 |  |  | 39.0 |  |  | 35.8 |  |  | 35.5 |  |  | 34.9 |  |  | 35.3 |  |
| Total cost of revenue | 128.5 |  |  | 111.6 |  |  | 113.1 |  |  | 97.2 |  |  | 105.4 |  |  | 93.6 |  |  | 95.7 |  |  | 90.6 |  |
| Total gross profit | 378.5 |  |  | 342.3 |  |  | 328.2 |  |  | 301.8 |  |  | 311.2 |  |  | 280.6 |  |  | 267.8 |  |  | 250.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 65.5 |  |  | 58.7 |  |  | 61.2 |  |  | 59.1 |  |  | 54.7 |  |  | 53.5 |  |  | 51.2 |  |  | 51.2 |  |
| Sales and marketing (1)(2) | 205.9 |  |  | 198.3 |  |  | 192.8 |  |  | 185.3 |  |  | 191.9 |  |  | 172.4 |  |  | 166.3 |  |  | 170.4 |  |
| General and administrative (1) | 22.0 |  |  | 22.5 |  |  | 23.5 |  |  | 25.0 |  |  | 22.4 |  |  | 21.0 |  |  | 21.9 |  |  | 22.6 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.1 | ) |  | 0.4 |  |
| Total operating expenses | 293.4 |  |  | 279.5 |  |  | 277.5 |  |  | 269.4 |  |  | 269.0 |  |  | 246.9 |  |  | 239.3 |  |  | 244.6 |  |
| Operating income | 85.1 |  |  | 62.8 |  |  | 50.7 |  |  | 32.4 |  |  | 42.2 |  |  | 33.7 |  |  | 28.5 |  |  | 5.4 |  |
| Interest income | 9.3 |  |  | 6.9 |  |  | 5.8 |  |  | 4.5 |  |  | 4.0 |  |  | 3.9 |  |  | 3.2 |  |  | 2.4 |  |
| Other income (expense)—net | (2.3 | ) |  | 0.9 |  |  | (5.0 | ) |  | (0.2 | ) |  | (1.2 | ) |  | 0.4 |  |  | 1.2 |  |  | 0.3 |  |
| Income before income taxes | 92.1 |  |  | 70.6 |  |  | 51.5 |  |  | 36.7 |  |  | 45.0 |  |  | 38.0 |  |  | 32.9 |  |  | 8.1 |  |
| Provision for (benefit from) income taxes | (90.5 | ) |  | 11.9 |  |  | 2.2 |  |  | (4.9 | ) |  | 74.0 |  |  | 11.3 |  |  | 9.9 |  |  | (2.6 | ) |
| Net income (loss) | $ | 182.6 |  |  | $ | 58.7 |  |  | $ | 49.3 |  |  | $ | 41.6 |  |  | $ | (29.0 | ) |  | $ | 26.7 |  |  | $ | 23.0 |  |  | $ | 10.7 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.07 |  |  | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.25 |  |  | $ | (0.17 | ) |  | $ | 0.15 |  |  | $ | 0.13 |  |  | $ | 0.06 |  |
| Diluted | $ | 1.04 |  |  | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.24 |  |  | $ | (0.17 | ) |  | $ | 0.15 |  |  | $ | 0.13 |  |  | $ | 0.06 |  |

[0001262039-19-000006:mdna:177]
_______________________________________________

[0001262039-19-000006:mdna:178]
(1) Includes stock-based compensation as follows:

[0001262039-19-000006:mdna:179]
|  | Three Months Ended |
|  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |
|  | (in millions) |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |
| Cost of service revenue | 2.8 |  |  | 2.8 |  |  | 2.7 |  |  | 2.5 |  |  | 2.4 |  |  | 2.4 |  |  | 2.5 |  |  | 2.3 |  |
| Research and development | 9.5 |  |  | 9.3 |  |  | 9.2 |  |  | 8.4 |  |  | 8.1 |  |  | 8.0 |  |  | 8.3 |  |  | 7.9 |  |
| Sales and marketing | 25.1 |  |  | 26.0 |  |  | 23.6 |  |  | 20.9 |  |  | 19.6 |  |  | 19.6 |  |  | 19.7 |  |  | 19.0 |  |
| General and administrative | 4.8 |  |  | 4.8 |  |  | 4.7 |  |  | 4.3 |  |  | 4.0 |  |  | 4.0 |  |  | 4.2 |  |  | 3.8 |  |
| Total stock-based compensation expense | $ | 42.6 |  |  | $ | 43.2 |  |  | $ | 40.6 |  |  | $ | 36.5 |  |  | $ | 34.4 |  |  | $ | 34.3 |  |  | $ | 35.1 |  |  | $ | 33.3 |  |

[0001262039-19-000006:mdna:180]
60

[0001262039-19-000006:mdna:181]
(2) Total amortization included in product costs, service costs, and sales and marketing expense are as follows:

[0001262039-19-000006:mdna:182]
|  | Three Months Ended |
|  | Dec 31,2018 |  | Sept 30,2018 |  | Jun 30,2018 |  | Mar 31,2018 |  | Dec 31,2017 |  | Sept 30,2017 |  | Jun 30,2017 |  | Mar 31,2017 |
|  | (in millions) |
| Amortization of intangible assets | $ | 2.9 |  |  | $ | 2.5 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 2.1 |  |  | $ | 2.0 |  |  | $ | 2.2 |  |  | $ | 2.3 |  |

[0001262039-19-000006:mdna:183]
Seasonality, Cyclicality and Quarterly Revenue Trends

[0001262039-19-000006:mdna:184]
Our quarterly results reflect a pattern of increased customer buying at year-end, which has positively impacted billings and product revenue activity in the fourth quarter. In the first quarter, we generally experience lower sequential customer buying, followed by an increase in buying in the second quarter. The third quarter is often consistent with the second quarter. Although these seasonal factors are common in the technology sector, historical patterns should not be considered a reliable indicator of our future sales activity or performance. On a quarterly basis, we have usually generated the majority of our product revenue in the final month of each quarter and a significant amount in the last two weeks of each quarter. We believe this is due to customer buying patterns typical in this industry.

[0001262039-19-000006:mdna:185]
Consistent with the seasonality note above, our total quarterly revenue over the past eight quarters has generally increased sequentially in each quarter, except in the first and third quarters of 2018 and 2017. Product revenue, in each quarter in 2018, increased as compared to the same quarter in 2017, which we believe was due to investments we made in our sales and marketing organizations, continued product innovation and a robust security market. We continue to see a shift from product revenue to higher-margin, recurring service revenue, which is a result of our growing customer base.

[0001262039-19-000006:mdna:186]
Total gross margin has fluctuated on a quarterly basis primarily due to seasonality of product sales and seasonality of cost increases. Product gross margin varies based on the types of products sold and the average selling prices of our products. In 2018, product gross margin was impacted by new product introductions and the mix of high-end, mid-range and entry-level products. Service gross margin benefited from the growth of our customer base and renewals.

[0001262039-19-000006:mdna:187]
61

[0001262039-19-000006:mdna:188]
Liquidity and Capital Resources

[0001262039-19-000006:mdna:189]
|  | As of December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,112.4 |  |  | $ | 811.0 |  |  | $ | 709.0 |  |
| Investments | 604.2 |  |  | 538.3 |  |  | 601.5 |  |
| Total cash, cash equivalents and investments | $ | 1,716.6 |  |  | $ | 1,349.3 |  |  | $ | 1,310.5 |  |
| Working capital | $ | 964.5 |  |  | $ | 689.6 |  |  | $ | 709.3 |  |
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 638.9 |  |  | $ | 594.4 |  |  | $ | 345.7 |  |
| Net cash used in investing activities | (134.9 | ) |  | (76.8 | ) |  | (74.1 | ) |
| Net cash used in financing activities | (202.6 | ) |  | (415.6 | ) |  | (105.9 | ) |
| Net increase in cash and cash equivalents | $ | 301.4 |  |  | $ | 102.0 |  |  | $ | 165.7 |  |

[0001262039-19-000006:mdna:190]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our equity incentive plans, payment of taxes in connection with the net settlement of equity awards and business acquisitions. In recent years, we have received significant capital resources as a result of increases in our deferred revenue and the proceeds from exercise of stock options and purchases under our equity incentive plans. Additional increases in deferred revenue may depend on a number of factors including our billing growth rate, service contract renewal rates and length of initial and renewals service contracts. We expect proceeds from the issuance of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. As of December 31, 2018, $733.8 million remained available for future share repurchase under the Repurchase Program.

[0001262039-19-000006:mdna:191]
Construction to our new headquarters building started in the fourth quarter of 2018 and related spending will continue in 2019 and until project completion. We estimate 2019 spending on the project to be between $60.0 million to $80.0 million dollars.

[0001262039-19-000006:mdna:192]
As of December 31, 2018, our cash, cash equivalents and investments of $1.72 billion were invested primarily in corporate debt securities, certificates of deposit and term deposits, commercial paper, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-19-000006:mdna:193]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $956.6 million as of December 31, 2018. Under the 2017 Tax Act signed into law in December 2017, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which were previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. Most of our off-shore cash is located in Singapore.

[0001262039-19-000006:mdna:194]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and amount of our planned share repurchases, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, share repurchases, capital expenditures and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all.

[0001262039-19-000006:mdna:195]
62

[0001262039-19-000006:mdna:196]
Operating Activities

[0001262039-19-000006:mdna:197]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities, including deferred revenue. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs in connection with the adoption of Topic 606, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-19-000006:mdna:198]
Our operating activities during 2018 provided $638.9 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew 26% as of December 31, 2018 compared to the same period last year to $1.69 billion.

[0001262039-19-000006:mdna:199]
Our operating activities during 2017 provided $594.4 million in cash as a result of our continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable. We continued to see a shift from product revenues to higher-margin, recurring service revenues and longer duration contracts. Our total revenue grew 17% in 2017 compared to 2016 and our total deferred revenue balance grew 29%.

[0001262039-19-000006:mdna:200]
Our operating activities during 2016 provided $345.7 million in cash as a result of our continued growth of our business and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers, as reflected by an increase in our deferred revenue, which was partially offset by an increase in accounts receivable and payments for inventory purchases. We also started to see a shift from product revenues to higher-margin, recurring service revenues. Our total revenue grew 26% in 2016 compared to 2015, while our total deferred revenue balance grew 31%.

[0001262039-19-000006:mdna:201]
Investing Activities

[0001262039-19-000006:mdna:202]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments, purchases of property and equipment, and payments made in connection with business acquisitions. Historically, in making a lease versus purchase decision related to our larger facilities, we have considered various factors including financial metrics and the impact on our employees. In certain cases, we have elected to purchase the facility if we believed that purchasing rather than leasing is more in line with our long-term strategy. We expect to make similar decisions in the future.

[0001262039-19-000006:mdna:203]
During 2018, cash used in investing activities was primarily due to $60.2 million spent for purchases of our investments, net of maturities and sales of investments, $53.0 million spent on capital expenditures and $21.7 million used for the acquisitions of Bradford and ZoneFox, net of cash acquired.

[0001262039-19-000006:mdna:204]
During 2017, cash used in investing activities was primarily due to $135.3 million we spent on capital expenditures, including our purchases of real estate properties in Canada and Sunnyvale, California, for total cash of $107.2 million. The outflow of cash was partially offset by positive cash flow due to maturities and sales, net of purchases, from our investments of $58.5 million.

[0001262039-19-000006:mdna:205]
During 2016, cash used in investing activities was primarily due to $67.2 million we spent on capital expenditures, including our purchases of a warehouse in Union City, California, for total cash of $18.5 million, and a $22.1 million payment for the acquisition of AccelOps. The outflow of cash was partially offset by positive cash flow due to maturities and sales, net of purchases, from our investments of $15.1 million.

[0001262039-19-000006:mdna:206]
Financing Activities

[0001262039-19-000006:mdna:207]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, proceeds from the issuance of common stock under our equity incentive plans, taxes paid related to net share settlement of equity awards and payments of debt assumed in business combinations.

[0001262039-19-000006:mdna:208]
During 2018, cash used in financing activities was $202.6 million, primarily due to $211.8 million used to repurchase our common stock and $10.1 million of payments of the debt assumed in business combinations. This was partially offset by $19.3 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000006:mdna:209]
63

[0001262039-19-000006:mdna:210]
During 2017, cash used in financing activities was $415.6 million, primarily due to $446.3 million used to repurchase our common stock. This was partially offset by $30.7 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000006:mdna:211]
During 2016, cash used in financing activities was $105.9 million, primarily due to $110.8 million used to repurchase our common stock. This was partially offset by $6.5 million of proceeds from the issuance of common stock, net of tax withholding.

[0001262039-19-000006:mdna:212]
Contractual Obligations and Commitments

[0001262039-19-000006:mdna:213]
The following summarizes our contractual obligations as of December 31, 2018:

[0001262039-19-000006:mdna:214]
|  | Payments Due by Period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
|  | (in millions) |
| Operating lease commitments (1) | $ | 50.1 |  |  | $ | 17.1 |  |  | $ | 20.7 |  |  | $ | 8.6 |  |  | $ | 3.7 |  |
| Inventory purchase commitments (2) | 177.3 |  |  | 173.1 |  |  | 4.2 |  |  | — |  |  | — |  |
| Total | $ | 227.4 |  |  | $ | 190.2 |  |  | $ | 24.9 |  |  | $ | 8.6 |  |  | $ | 3.7 |  |

[0001262039-19-000006:mdna:215]
________________________

[0001262039-19-000006:mdna:216]
| (1) | Consists of contractual obligations from non-cancelable office space under operating leases. |

[0001262039-19-000006:mdna:217]
| (2) | Consists of minimum purchase commitments with independent contract manufacturers. |

[0001262039-19-000006:mdna:218]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2018, we had $14.3 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-19-000006:mdna:219]
As of December 31, 2018, we had $77.5 million of long-term income tax liabilities, including interest, related to uncertain tax positions. Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001262039-19-000006:mdna:220]
Off-Balance Sheet Arrangements

[0001262039-19-000006:mdna:221]
During 2018, 2017 and 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-19-000006:mdna:222]
Recent Accounting Pronouncements

[0001262039-19-000006:mdna:223]
See Note 1 of the notes to our consolidated financial statements in Part II, Item 8 of this Annual Report on Form 10-K for a full description of recently adopted accounting pronouncements.
