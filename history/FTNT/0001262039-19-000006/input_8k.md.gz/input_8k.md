# FTNT 8-K — 0001262039-19-000002 filed 2019-02-06

## item codes, every 8-K on or before 2019-02-27

- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2019-02-27

- none on or before 2019-02-27

## item 2.02 — earnings release, exhibit 99.1

[0001262039-19-000002:8k_2_02:1]
EX-99.1
2
ftntq4-2018ex991.htm
PRESS RELEASE

[0001262039-19-000002:8k_2_02:2]
Exhibit

[0001262039-19-000002:8k_2_02:3]
Press Release

[0001262039-19-000002:8k_2_02:4]
Fortinet Reports Fourth Quarter and Full Year 2018 Financial Results

[0001262039-19-000002:8k_2_02:5]
Fourth Quarter 2018 Highlights

[0001262039-19-000002:8k_2_02:6]
| • | Revenue of $507.0 million, up 22% year over year |

[0001262039-19-000002:8k_2_02:7]
| • | Billings of $649.2 million, up 22% year over year1 |

[0001262039-19-000002:8k_2_02:8]
| • | GAAP operating margin of 17% |

[0001262039-19-000002:8k_2_02:9]
| • | Non-GAAP operating margin of 26%1 |

[0001262039-19-000002:8k_2_02:10]
| • | GAAP diluted net income per share of $1.04 |

[0001262039-19-000002:8k_2_02:11]
| • | Non-GAAP diluted net income per share of $0.591 |

[0001262039-19-000002:8k_2_02:12]
| • | Cash flow from operations of $180.2 million |

[0001262039-19-000002:8k_2_02:13]
| • | Free cash flow of $168.6 million1 |

[0001262039-19-000002:8k_2_02:14]
| • | $92.0 million in share repurchases |

[0001262039-19-000002:8k_2_02:15]
Full Year 2018 Highlights

[0001262039-19-000002:8k_2_02:16]
| • | Revenue of $1.80 billion, up 20% year over year |

[0001262039-19-000002:8k_2_02:17]
| • | Billings of $2.15 billion, up 20% year over year1 |

[0001262039-19-000002:8k_2_02:18]
| • | Deferred revenue of $1.69 billion, up 26% year over year |

[0001262039-19-000002:8k_2_02:19]
| • | GAAP operating margin of 13% |

[0001262039-19-000002:8k_2_02:20]
| • | Non-GAAP operating margin of 22%1 |

[0001262039-19-000002:8k_2_02:21]
| • | GAAP diluted net income per share of $1.91 |

[0001262039-19-000002:8k_2_02:22]
| • | Non-GAAP diluted net income per share of $1.841 |

[0001262039-19-000002:8k_2_02:23]
| • | Cash flow from operations of $638.9 million |

[0001262039-19-000002:8k_2_02:24]
| • | Free cash flow grew 28% year over year to $585.9 million1 |

[0001262039-19-000002:8k_2_02:25]
| • | $209.1 million in share repurchases |

[0001262039-19-000002:8k_2_02:26]
SUNNYVALE, Calif. - February 6, 2019 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the fourth quarter and full year ended December 31, 2018.

[0001262039-19-000002:8k_2_02:27]
“Our strong fourth quarter results drove a solid finish to 2018, demonstrating demand for our product and services and illustrating our ability to drive disciplined growth with solid margin improvement,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “We are well-positioned to achieve another year of better than industry growth in 2019, driven by business momentum and strong customer demand for our broad, integrated, and automated security solutions across their entire network infrastructure.”

[0001262039-19-000002:8k_2_02:28]
Financial Highlights for the Fourth Quarter of 2018

[0001262039-19-000002:8k_2_02:29]
| • | Revenue: Total revenue was $507.0 million for the fourth quarter of 2018, an increase of 22% compared to $416.6 million in the same quarter of 2017. |

[0001262039-19-000002:8k_2_02:30]
| • | Product revenue was $200.8 million for the fourth quarter of 2018, an increase of 24% compared to $162.1 million in the same quarter of 2017. |

[0001262039-19-000002:8k_2_02:31]
| • | Service revenue was $306.2 million for the fourth quarter of 2018, an increase of 20% compared to $254.5 million in the same quarter of 2017. |

[0001262039-19-000002:8k_2_02:32]
| • | Billings1: Total billings were $649.2 million for the fourth quarter of 2018, an increase of 22% compared to $534.0 million in the same quarter of 2017. |

[0001262039-19-000002:8k_2_02:33]
| • | GAAP Operating Income and Margin: GAAP operating income was $85.1 million for the fourth quarter of 2018, representing a GAAP operating margin of 17%. GAAP operating income was $42.2 million for the same quarter of 2017, representing a GAAP operating margin of 10%. |

[0001262039-19-000002:8k_2_02:34]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $130.6 million for the fourth quarter of 2018, representing a non-GAAP operating margin of 26%. Non-GAAP operating income was $78.7 million for the fourth quarter of 2017, representing a non-GAAP operating margin of 19%. |

[0001262039-19-000002:8k_2_02:35]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net income was $182.6 million for the fourth quarter of 2018, compared to GAAP net loss of $29.0 million for the same quarter of 2017. GAAP diluted net income per share was $1.04 for the fourth quarter of 2018, based on 175.8 million diluted weighted-average shares outstanding, compared to GAAP diluted net loss per share of $0.17 for the same quarter of 2017, based on 171.5 million diluted weighted-average shares outstanding. |

[0001262039-19-000002:8k_2_02:36]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $104.6 million for the fourth quarter of 2018, compared to non-GAAP net income of $55.4 million for the same quarter of 2017. Non-GAAP diluted net income per share was $0.59 for the fourth quarter of 2018, based on 175.8 million diluted weighted-average shares outstanding, compared to $0.32 for the same quarter of 2017, based on 175.4 million diluted weighted-average shares outstanding. |

[0001262039-19-000002:8k_2_02:37]
| • | Cash Flow and Free Cash Flow1: In the fourth quarter of 2018, cash flow from operations was $180.2 million compared to $157.5 million in the same quarter of 2017. Free cash flow was $168.6 million during the fourth quarter of 2018, compared to $143.9 million in the same quarter of 2017. |

[0001262039-19-000002:8k_2_02:38]
| • | Share Repurchase: During the fourth quarter of 2018, Fortinet repurchased 1.3 million shares of its common stock for a total purchase price of $92.0 million. During the fourth quarter of 2017, Fortinet repurchased 7.9 million shares of its common stock for a total purchase price of $322.4 million. |

[0001262039-19-000002:8k_2_02:39]
Financial Highlights for the Full Year 2018

[0001262039-19-000002:8k_2_02:40]
| • | Revenue: Total revenue was $1.80 billion for 2018, an increase of 20% compared to $1.49 billion in 2017. |

[0001262039-19-000002:8k_2_02:41]
| • | Product revenue was $674.4 million for 2018, an increase of 17% compared to $577.2 million in 2017. |

[0001262039-19-000002:8k_2_02:42]
| • | Service revenue was $1.13 billion for 2018, an increase of 23% compared to $917.7 million in 2017. |

[0001262039-19-000002:8k_2_02:43]
| • | Billings1: Total billings were $2.15 billion for 2018, an increase of 20% compared to $1.80 billion in 2017. |

[0001262039-19-000002:8k_2_02:44]
| • | Deferred Revenue: Total deferred revenue was $1.69 billion as of December 31, 2018, an increase of 26% compared to $1.34 billion as of December 31, 2017. |

[0001262039-19-000002:8k_2_02:45]
| • | GAAP Operating Income and Margin: GAAP operating income was $231.0 million for 2018, representing a GAAP operating margin of 13%. GAAP operating income was $109.8 million for 2017, representing a GAAP operating margin of 7%. |

[0001262039-19-000002:8k_2_02:46]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $402.9 million for 2018, representing a non-GAAP operating margin of 22%. Non-GAAP operating income was $257.4 million for 2017, representing a non-GAAP operating margin of 17%. |

[0001262039-19-000002:8k_2_02:47]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $332.2 million for 2018, compared to GAAP net income of $31.4 million for 2017. GAAP diluted net income per share was $1.91 for 2018, based on 174.2 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.18 for 2017, based on 178.1 million diluted weighted-average shares outstanding. |

[0001262039-19-000002:8k_2_02:48]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $319.7 million for 2018, compared to non-GAAP net income of $184.7 million for 2017. Non-GAAP diluted net income per share was $1.84 for 2018, based on 174.2 million diluted weighted-average shares outstanding, compared to Non-GAAP diluted net income per share of $1.04 for 2017, based on 178.1 million diluted weighted-average shares outstanding. |

[0001262039-19-000002:8k_2_02:49]
| • | Cash Flow and Free Cash Flow1: In 2018, cash flow from operations was $638.9 million, compared to $594.4 million in 2017. Free cash flow was $585.9 million in 2018, compared to $459.1 million in 2017. |

[0001262039-19-000002:8k_2_02:50]
| • | Share Repurchase: During 2018, Fortinet repurchased 3.8 million shares of its common stock for a total purchase price of $209.1 million. During 2017, Fortinet repurchased 11.2 million shares of its common stock for a total purchase price of $446.3 million. |

[0001262039-19-000002:8k_2_02:51]
Guidance

[0001262039-19-000002:8k_2_02:52]
For the first quarter of 2019, Fortinet currently expects:

[0001262039-19-000002:8k_2_02:53]
| • | Revenue in the range of $465 million to $475 million |

[0001262039-19-000002:8k_2_02:54]
| • | Billings in the range of $515 million to $535 million |

[0001262039-19-000002:8k_2_02:55]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000002:8k_2_02:56]
| • | Non-GAAP operating margin in the range of 18.0% to 18.5% |

[0001262039-19-000002:8k_2_02:57]
| • | Diluted non-GAAP earnings per share in the range of $0.37 to $0.39, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 176 million to 178 million |

[0001262039-19-000002:8k_2_02:58]
For the fiscal year 2019, Fortinet currently expects:

[0001262039-19-000002:8k_2_02:59]
| • | Revenue in the range of $2.06 billion to $2.10 billion |

[0001262039-19-000002:8k_2_02:60]
| • | Service revenue in the range of $1.33 billion to $1.36 billion |

[0001262039-19-000002:8k_2_02:61]
| • | Billings in the range of $2.45 billion to $2.50 billion |

[0001262039-19-000002:8k_2_02:62]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000002:8k_2_02:63]
| • | Non-GAAP operating margin in the range of 22.5% to 23.5% |

[0001262039-19-000002:8k_2_02:64]
| • | Diluted non-GAAP earnings per share in the range of $2.05 to $2.10, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 181 million to 183 million |

[0001262039-19-000002:8k_2_02:65]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-19-000002:8k_2_02:66]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-19-000002:8k_2_02:67]
Conference Call Details

[0001262039-19-000002:8k_2_02:68]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 3279155. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through February 13, 2019, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #3279155.

[0001262039-19-000002:8k_2_02:69]
First Quarter 2019 Analyst Day and Investor Conference Participation Schedule:

[0001262039-19-000002:8k_2_02:70]
| • | Goldman Sachs Technology and Internet Conference 2019 |

[0001262039-19-000002:8k_2_02:71]
| • | Morgan Stanley Technology, Media & Telecom Conference |

[0001262039-19-000002:8k_2_02:72]
| • | JMP Securities Technology Conference (Meetings Only) |

[0001262039-19-000002:8k_2_02:73]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-19-000002:8k_2_02:74]
About Fortinet (www.fortinet.com)

[0001262039-19-000002:8k_2_02:75]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical

[0001262039-19-000002:8k_2_02:76]
security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-19-000002:8k_2_02:77]
#          #          #

[0001262039-19-000002:8k_2_02:78]
Copyright © 2018 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiCare, FortiManager, FortiAnalyzer, FortiOS, FortiADC, FortiAP, FortiAppMonitor, FortiASIC, FortiAuthenticator, FortiBridge, FortiCache, FortiCamera, FortiCASB, FortiClient, FortiCloud, FortiConnect, FortiController, FortiConverter, FortiDB, FortiDDoS, FortiExplorer, FortiExtender, FortiFone, FortiCarrier, FortiHypervisor, FortiIsolator, FortiMail, FortiMonitor, FortiNAC, FortiPlanner, FortiPortal, FortiPresence, FortiProxy, FortiRecorder, FortiSandbox, FortiSIEM, FortiSwitch, FortiTester, FortiToken, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-19-000002:8k_2_02:79]
FTNT-F

[0001262039-19-000002:8k_2_02:80]
Forward-looking Statements

[0001262039-19-000002:8k_2_02:81]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding our expectations of future demand for our products and services, our expectations of growth and margin improvements in 2019, and all guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its product and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith;

[0001262039-19-000002:8k_2_02:82]
sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments; competition and pricing pressure; tariffs and other trade barriers; the impact of the shutdown of the U.S. government in December 2018 through January 2019 and any future shutdowns; and the other risk factors set forth from time to time in our most recent Annual Report on Form 10-K, our most recent Quarterly Report on Form 10-Q and our other filings with the Securities and Exchange Commission (SEC), copies of which are

[0001262039-19-000002:8k_2_02:83]
Non-GAAP Financial Measures

[0001262039-19-000002:8k_2_02:84]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-19-000002:8k_2_02:85]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-19-000002:8k_2_02:86]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-19-000002:8k_2_02:87]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in

[0001262039-19-000002:8k_2_02:88]
a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure.

[0001262039-19-000002:8k_2_02:89]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-19-000002:8k_2_02:90]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on sale of investments in privately held companies as well as impairment, and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-19-000002:8k_2_02:91]
FORTINET, INC.

[0001262039-19-000002:8k_2_02:92]
CONSOLIDATED BALANCE SHEETS

[0001262039-19-000002:8k_2_02:93]
(Unaudited, in millions)

[0001262039-19-000002:8k_2_02:94]
|  | December 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,112.4 |  |  | $ | 811.0 |  |
| Short-term investments | 537.2 |  |  | 440.3 |  |
| Accounts receivable—net | 444.5 |  |  | 348.2 |  |
| Inventory | 90.0 |  |  | 77.3 |  |
| Prepaid expenses and other current assets | 36.8 |  |  | 40.0 |  |
| Total current assets | 2,220.9 |  |  | 1,716.8 |  |
| LONG-TERM INVESTMENTS | 67.0 |  |  | 98.0 |  |
| PROPERTY AND EQUIPMENT—NET | 271.4 |  |  | 245.4 |  |
| DEFERRED CONTRACT COSTS | 182.6 |  |  | — |  |
| DEFERRED TAX ASSETS | 255.0 |  |  | 146.9 |  |
| OTHER INTANGIBLE ASSETS—NET | 22.1 |  |  | 16.3 |  |
| GOODWILL | 38.2 |  |  | 14.6 |  |
| OTHER ASSETS | 20.8 |  |  | 19.9 |  |
| TOTAL ASSETS | $ | 3,078.0 |  |  | $ | 2,257.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 86.4 |  |  | $ | 70.0 |  |
| Accrued liabilities | 77.5 |  |  | 50.0 |  |
| Accrued payroll and compensation | 98.4 |  |  | 92.0 |  |
| Income taxes payable | 28.2 |  |  | 21.4 |  |
| Deferred revenue | 965.9 |  |  | 793.8 |  |
| Total current liabilities | 1,256.4 |  |  | 1,027.2 |  |
| DEFERRED REVENUE | 720.9 |  |  | 542.5 |  |
| INCOME TAX LIABILITIES | 77.5 |  |  | 90.2 |  |
| OTHER LIABILITIES | 13.0 |  |  | 8.6 |  |
| Total liabilities | 2,067.8 |  |  | 1,668.5 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,068.3 |  |  | 909.6 |  |
| Accumulated other comprehensive loss | (0.8 | ) |  | (0.8 | ) |
| Accumulated deficit | (57.5 | ) |  | (319.6 | ) |
| Total stockholders’ equity | 1,010.2 |  |  | 589.4 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,078.0 |  |  | $ | 2,257.9 |  |

[0001262039-19-000002:8k_2_02:95]
FORTINET, INC.

[0001262039-19-000002:8k_2_02:96]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-19-000002:8k_2_02:97]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000002:8k_2_02:98]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 200.8 |  |  | $ | 162.1 |  |  | $ | 674.4 |  |  | $ | 577.2 |  |
| Service | 306.2 |  |  | 254.5 |  |  | 1,126.8 |  |  | 917.7 |  |
| Total revenue | 507.0 |  |  | 416.6 |  |  | 1,801.2 |  |  | 1,494.9 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 86.9 |  |  | 69.6 |  |  | 291.0 |  |  | 243.8 |  |
| Service 1 | 41.6 |  |  | 35.8 |  |  | 159.4 |  |  | 141.5 |  |
| Total cost of revenue | 128.5 |  |  | 105.4 |  |  | 450.4 |  |  | 385.3 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 113.9 |  |  | 92.5 |  |  | 383.4 |  |  | 333.4 |  |
| Service | 264.6 |  |  | 218.7 |  |  | 967.4 |  |  | 776.2 |  |
| Total gross profit | 378.5 |  |  | 311.2 |  |  | 1,350.8 |  |  | 1,109.6 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 65.5 |  |  | 54.7 |  |  | 244.5 |  |  | 210.6 |  |
| Sales and marketing 1 | 205.9 |  |  | 191.9 |  |  | 782.3 |  |  | 701.0 |  |
| General and administrative 1 | 22.0 |  |  | 22.4 |  |  | 93.0 |  |  | 87.9 |  |
| Restructuring charges | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Total operating expenses | 293.4 |  |  | 269.0 |  |  | 1,119.8 |  |  | 999.8 |  |
| OPERATING INCOME | 85.1 |  |  | 42.2 |  |  | 231.0 |  |  | 109.8 |  |
| INTEREST INCOME | 9.3 |  |  | 4.0 |  |  | 26.5 |  |  | 13.5 |  |
| OTHER INCOME (EXPENSE)—NET | (2.3 | ) |  | (1.2 | ) |  | (6.6 | ) |  | 0.7 |  |
| INCOME BEFORE INCOME TAXES | 92.1 |  |  | 45.0 |  |  | 250.9 |  |  | 124.0 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | (90.5 | ) |  | 74.0 |  |  | (81.3 | ) |  | 92.6 |  |
| NET INCOME (LOSS) | $ | 182.6 |  |  | $ | (29.0 | ) |  | $ | 332.2 |  |  | $ | 31.4 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.07 |  |  | $ | (0.17 | ) |  | $ | 1.96 |  |  | $ | 0.18 |  |
| Diluted | $ | 1.04 |  |  | $ | (0.17 | ) |  | $ | 1.91 |  |  | $ | 0.18 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 170.4 |  |  | 171.5 |  |  | 169.1 |  |  | 174.3 |  |
| Diluted | 175.8 |  |  | 171.5 |  |  | 174.2 |  |  | 178.1 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 1.5 |  |  | $ | 1.4 |  |
| Cost of service revenue | 2.8 |  |  | 2.3 |  |  | 10.8 |  |  | 9.5 |  |
| Research and development | 9.5 |  |  | 8.1 |  |  | 36.4 |  |  | 32.2 |  |
| Sales and marketing | 25.1 |  |  | 19.6 |  |  | 95.6 |  |  | 78.0 |  |
| General and administrative | 4.8 |  |  | 4.1 |  |  | 18.6 |  |  | 16.1 |  |
|  | $ | 42.6 |  |  | $ | 34.4 |  |  | $ | 162.9 |  |  | $ | 137.2 |  |

[0001262039-19-000002:8k_2_02:99]
FORTINET, INC.

[0001262039-19-000002:8k_2_02:100]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-19-000002:8k_2_02:101]
(Unaudited, in millions)

[0001262039-19-000002:8k_2_02:102]
|  | Year Ended |
|  | December 31, 2018 |  | December 31, 2017 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 332.2 |  |  | $ | 31.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 162.9 |  |  | 137.2 |  |
| Amortization of deferred contract costs | 90.9 |  |  | — |  |
| Depreciation and amortization | 55.7 |  |  | 55.5 |  |
| Other | (0.9 | ) |  | 3.8 |  |
| Amortization of investment premiums | (0.6 | ) |  | 2.5 |  |
| Changes in operating assets and liabilities, net of assets acquired and liabilities assumed in business acquisitions: |  |  |  |
| Accounts receivable—net | (82.0 | ) |  | (38.4 | ) |
| Inventory | (33.4 | ) |  | 9.4 |  |
| Prepaid expenses and other current assets | 4.2 |  |  | (6.7 | ) |
| Deferred contract costs | (136.4 | ) |  | — |  |
| Deferred tax assets | (127.8 | ) |  | 35.8 |  |
| Other assets | (3.8 | ) |  | (1.0 | ) |
| Accounts payable | 14.6 |  |  | 13.1 |  |
| Accrued liabilities | 14.5 |  |  | 14.4 |  |
| Accrued payroll and compensation | 3.5 |  |  | 12.6 |  |
| Other liabilities | (0.8 | ) |  | (5.5 | ) |
| Deferred revenue | 352.1 |  |  | 300.8 |  |
| Income taxes payable | (6.0 | ) |  | 29.5 |  |
| Net cash provided by operating activities | 638.9 |  |  | 594.4 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (681.8 | ) |  | (669.2 | ) |
| Sales of investments | 42.8 |  |  | 300.3 |  |
| Maturities of investments | 578.8 |  |  | 427.4 |  |
| Purchases of property and equipment | (53.0 | ) |  | (135.3 | ) |
| Payments made in connection with business acquisitions, net of cash acquired | (21.7 | ) |  | — |  |
| Net cash used in investing activities | (134.9 | ) |  | (76.8 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (211.8 | ) |  | (446.3 | ) |
| Proceeds from issuance of common stock | 86.5 |  |  | 75.8 |  |
| Taxes paid related to net share settlement of equity awards | (67.2 | ) |  | (45.1 | ) |
| Payments of debt assumed in connection with business acquisitions | (10.1 | ) |  | — |  |
| Net cash used in financing activities | (202.6 | ) |  | (415.6 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 301.4 |  |  | 102.0 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 811.0 |  |  | 709.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,112.4 |  |  | $ | 811.0 |  |

[0001262039-19-000002:8k_2_02:103]
New Revenue Recognition Standard (ASC 606) Adoption Financial Impact1

[0001262039-19-000002:8k_2_02:104]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000002:8k_2_02:105]
|  | Three Months Ended December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 200.8 |  |  | $ | 193.4 |  |  | $ | 7.4 |  |
| Service | 306.2 |  |  | 307.8 |  |  | (1.6 | ) |
| Total revenue | 507.0 |  |  | 501.2 |  |  | 5.8 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 86.9 |  |  | 86.5 |  |  | 0.4 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 113.9 |  |  | 106.9 |  |  | 7.0 |  |
| Service | 264.6 |  |  | 266.2 |  |  | (1.6 | ) |
| Total gross profit | 378.5 |  |  | 373.1 |  |  | 5.4 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 205.9 |  |  | 218.9 |  |  | (13.0 | ) |
| OPERATING INCOME | 85.1 |  |  | 66.7 |  |  | 18.4 |  |
| INCOME BEFORE INCOME TAXES | 92.1 |  |  | 73.7 |  |  | 18.4 |  |
| BENEFIT FROM INCOME TAXES | (90.5 | ) |  | (91.5 | ) |  | 1.0 |  |
| NET INCOME | $ | 182.6 |  |  | $ | 165.2 |  |  | $ | 17.4 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.07 |  |  | $ | 0.97 |  |  | $ | 0.10 |  |
| Diluted | $ | 1.04 |  |  | $ | 0.94 |  |  | $ | 0.10 |  |

[0001262039-19-000002:8k_2_02:106]
|  | Year Ended December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of ASC 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product | $ | 674.4 |  |  | $ | 654.9 |  |  | $ | 19.5 |  |
| Service | 1,126.8 |  |  | 1,126.9 |  |  | (0.1 | ) |
| Total revenue | 1,801.2 |  |  | 1,781.8 |  |  | 19.4 |  |
| COST OF REVENUE: |  |  |  |  |  |
| Product | 291.0 |  |  | 289.6 |  |  | 1.4 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 383.4 |  |  | 365.3 |  |  | 18.1 |  |
| Service | 967.4 |  |  | 967.5 |  |  | (0.1 | ) |
| Total gross profit | 1,350.8 |  |  | 1,332.8 |  |  | 18.0 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 782.3 |  |  | 827.8 |  |  | (45.5 | ) |
| OPERATING INCOME | 231.0 |  |  | 167.5 |  |  | 63.5 |  |
| INCOME BEFORE INCOME TAXES | 250.9 |  |  | 187.4 |  |  | 63.5 |  |
| BENEFIT FROM INCOME TAXES | (81.3 | ) |  | (92.2 | ) |  | 10.9 |  |
| NET INCOME | $ | 332.2 |  |  | $ | 279.6 |  |  | $ | 52.6 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.96 |  |  | $ | 1.65 |  |  | $ | 0.31 |  |
| Diluted | $ | 1.91 |  |  | $ | 1.61 |  |  | $ | 0.30 |  |
| 1 The tables above do not represent the full consolidated statement of operations as they only present the accounts impacted by the adoption of ASC 606. |

[0001262039-19-000002:8k_2_02:107]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-19-000002:8k_2_02:108]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000002:8k_2_02:109]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-19-000002:8k_2_02:110]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| Net cash provided by operating activities | $ | 180.2 |  |  | $ | 157.5 |  |  | $ | 638.9 |  |  | $ | 594.4 |  |
| Less: Purchases of property and equipment | (11.6 | ) |  | (13.6 | ) |  | (53.0 | ) |  | (135.3 | ) |
| Free cash flow | $ | 168.6 |  |  | $ | 143.9 |  |  | $ | 585.9 |  |  | $ | 459.1 |  |
| Net cash provided by (used in) investing activities | $ | (127.5 | ) |  | $ | 65.3 |  |  | $ | (134.9 | ) |  | $ | (76.8 | ) |
| Net cash used in financing activities | $ | (109.7 | ) |  | $ | (317.6 | ) |  | $ | (202.6 | ) |  | $ | (415.6 | ) |

[0001262039-19-000002:8k_2_02:111]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income (loss) and diluted net income (loss) per share

[0001262039-19-000002:8k_2_02:112]
|  | Three Months Ended December 31, 2018 |  | Three Months Ended December 31, 2017 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 85.1 |  |  | $ | 45.5 |  | (a) | $ | 130.6 |  |  | $ | 42.2 |  |  | $ | 36.5 |  | (b) | $ | 78.7 |  |
| Operating margin | 17 | % |  |  |  | 26 | % |  | 10 | % |  |  |  | 19 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 42.6 |  |  |  |  |  |  | 34.4 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.9 |  |  |  |  |  |  | 2.1 |  |  |  |
| Tax adjustment |  |  | (123.5 | ) | (c) |  |  |  |  | 47.9 |  | (c) |  |
| Net income (loss) | $ | 182.6 |  |  | $ | (78.0 | ) |  | $ | 104.6 |  |  | $ | (29.0 | ) |  | $ | 84.4 |  |  | $ | 55.4 |  |
| Diluted net income (loss) per share | $ | 1.04 |  |  |  |  | $ | 0.59 |  |  | $ | (0.17 | ) |  |  |  | $ | 0.32 |  |
| Shares used in diluted net income (loss) per share calculations | 175.8 |  |  |  |  | 175.8 |  |  | 171.5 |  |  |  |  | 175.4 |  |

[0001262039-19-000002:8k_2_02:113]
(a) To exclude $42.6 million of stock-based compensation and $2.9 million of amortization of acquired intangible assets in the three months ended December 31, 2018.

[0001262039-19-000002:8k_2_02:114]
(b) To exclude $34.4 million of stock-based compensation and $2.1 million of amortization of acquired intangible assets in the three months ended December 31, 2017.

[0001262039-19-000002:8k_2_02:115]
(c)  Non-GAAP financial information is adjusted to an overall effective tax rate of 24% and 32% in 2018 and 2017, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate. The Company changed its non-GAAP effective rate from 32% to 24% for 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act.

[0001262039-19-000002:8k_2_02:116]
|  | Year Ended December 31, 2018 |  | Year Ended December 31, 2017 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 231.0 |  |  | $ | 171.9 |  | (a) | $ | 402.9 |  |  | $ | 109.8 |  |  | $ | 147.6 |  | (b) | $ | 257.4 |  |
| Operating margin | 13 | % |  |  |  | 22 | % |  | 7 | % |  |  |  | 17 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 162.9 |  |  |  |  |  |  | 137.2 |  |  |  |
| Amortization of acquired intangible assets |  |  | 9.0 |  |  |  |  |  |  | 8.6 |  |  |  |
| Litigation settlement expenses |  |  | — |  |  |  |  |  |  | 1.5 |  |  |  |
| Restructuring charges |  |  | — |  |  |  |  |  |  | 0.3 |  |  |  |
| Operating income |  |  | 171.9 |  |  |  |  |  |  | 147.6 |  |  |  |
| Gain on sale of investment in privately-held company |  |  | (2.2 | ) | (c) |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (182.2 | ) | (d) |  |  |  |  | 5.7 |  | (d) |  |
| Net income | $ | 332.2 |  |  | $ | (12.5 | ) |  | $ | 319.7 |  |  | $ | 31.4 |  |  | $ | 153.3 |  |  | $ | 184.7 |  |
| Diluted net income per share | $ | 1.91 |  |  |  |  | $ | 1.84 |  |  | $ | 0.18 |  |  |  |  | $ | 1.04 |  |
| Shares used in diluted net income per share calculations | 174.2 |  |  |  |  | 174.2 |  |  | 178.1 |  |  |  |  | 178.1 |  |

[0001262039-19-000002:8k_2_02:117]
(a) To exclude $162.9 million of stock-based compensation and $9.0 million of amortization of acquired intangible assets in 2018.

[0001262039-19-000002:8k_2_02:118]
(b) To exclude $137.2 million of stock-based compensation, $8.6 million of amortization of acquired intangible assets, $1.5 million litigation settlement expenses, and $0.3 million of restructuring charges in 2017.

[0001262039-19-000002:8k_2_02:119]
(c) To exclude $2.2 million of gain on sale of investment in privately-held company.

[0001262039-19-000002:8k_2_02:120]
(d)  Non-GAAP financial information is adjusted to an overall effective tax rate of 24% and 32% in 2018 and 2017, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate. The Company changed its non-GAAP effective rate from 32% to 24% for 2018 due to the reduction of the U.S. federal corporate income tax rate under the U.S. Tax Cuts and Jobs Act.

[0001262039-19-000002:8k_2_02:121]
Reconciliation of diluted weighted-average shares outstanding used in the calculation of GAAP and non-GAAP earnings per share

[0001262039-19-000002:8k_2_02:122]
|  |  | Three Months Ended |  | Year Ended |
|  |  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| Shares used in diluted net income (loss) per share calculations - GAAP |  | 175.8 |  |  | 171.5 |  |  | 174.2 |  |  | 178.1 |  |
| Adjustment for diluted weighted-average shares outstanding | (a) | — |  |  | 3.9 |  |  | — |  |  | — |  |
| Shares used in diluted net income per share calculations - Non-GAAP |  | 175.8 |  |  | 175.4 |  |  | 174.2 |  |  | 178.1 |  |

[0001262039-19-000002:8k_2_02:123]
(a) GAAP diluted weighted-average shares outstanding differs from non-GAAP diluted weighted-average shares outstanding in periods when we have a GAAP net loss and a non-GAAP net income. The adjustment for diluted weighted-average shares outstanding represents the dilutive effect of employee equity incentive plan awards and is calculated by applying the treasury stock method.

[0001262039-19-000002:8k_2_02:124]
Reconciliation of total revenue to total billings

[0001262039-19-000002:8k_2_02:125]
|  | Three Months Ended |  | Year Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| Total revenue | $ | 507.0 |  |  | $ | 416.6 |  |  | $ | 1,801.2 |  |  | $ | 1,494.9 |  |
| Add: Change in deferred revenue | 142.4 |  |  | 117.4 |  |  | 350.5 |  |  | 301.0 |  |
| Add: Deferred revenue adjustment due to adoption of the new revenue recognition standard | — |  |  | — |  |  | 4.1 |  |  | — |  |
| Less: Deferred revenue balance acquired in business acquisitions | (0.2 | ) |  | — |  |  | (2.5 | ) |  | — |  |
| Total billings | $ | 649.2 |  |  | $ | 534.0 |  |  | $ | 2,153.3 |  |  | $ | 1,795.9 |  |

[0001262039-19-000002:8k_2_02:126]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
