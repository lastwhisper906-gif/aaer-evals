# FTNT notes — 0001262039-19-000006


## ftnt:CashandCashEquivalentsandAvailableforSaleInvestmentsPolicyTextBlock

[0001262039-19-000006:notes:1]
Cash, Cash Equivalents and Available-for-Sale Investments—We consider all highly liquid investments, purchased with original maturities of three months or less, to be cash equivalents. Cash and cash equivalents consist of balances with banks and highly liquid investments in money market funds, commercial paper, term deposits and corporate debt.

[0001262039-19-000006:notes:2]
We classify our investments as available-for-sale at the time of purchase, since it is our intent that these investments are available for current operations. Investments with original maturities greater than three months that mature less than one year from the consolidated balance sheet date are classified as short-term investments. Investments with maturities greater than one year from the consolidated balance sheet date are classified as long-term investments.

[0001262039-19-000006:notes:3]
Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. We consult with our investment managers and consider available quantitative and qualitative evidence in evaluating potential impairment of our investments on a quarterly basis. If the cost of an individual investment exceeds its fair value, we evaluate, among other factors, general market conditions, the duration and extent to which the fair value is less than cost, and our intent and ability to hold the investment. Once a decline in fair value is determined to be other-than-temporary, an impairment charge is recorded and a new cost basis in the investment is established.

[0001262039-19-000006:notes:4]
For debt securities in an unrealized loss position which is deemed to be other-than-temporary, the difference between the security’s then-current amortized cost basis and fair value is separated into (i) the amount of the impairment related to the credit loss (i.e., the credit loss component) and (ii) the amount of the impairment related to all other factors (i.e., the non-credit loss component). The credit loss component is recognized in earnings. The non-credit loss component is recognized in accumulated other comprehensive loss.


## ftnt:ComprehensiveIncomeLossPolicyTextBlock

[0001262039-19-000006:notes:5]
Comprehensive Income—Comprehensive income includes certain changes in equity from non-owner sources that are excluded from net income, specifically, unrealized gains and losses on available-for-sale investments and the related tax impact.


## ftnt:ConcentrationRiskPolicyTextBlock

[0001262039-19-000006:notes:6]
Concentration of Credit Risk—Financial instruments that subject us to concentrations of credit risk consist primarily of cash, cash equivalents, short-term and long-term investments and accounts receivable. Our cash balances are maintained as deposits with various large financial institutions in the United States and around the world. Balances in the United States typically exceed the amount of insurance provided on such deposits. We maintain our cash equivalents and investments in money market funds, commercial paper and fixed income securities with major financial institutions that our management believes are financially sound.

[0001262039-19-000006:notes:7]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated potential credit losses.


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-19-000006:notes:8]
Total income tax benefit associated with stock-based compensation that is recognized in the consolidated statements of income is as follows (in millions):

[0001262039-19-000006:notes:9]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Income tax benefit associated with stock-based compensation | $ | 24.9 |  |  | $ | 30.9 |  |  | $ | 29.2 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-19-000006:notes:10]
Basis of Presentation and Preparation—The consolidated financial statements of Fortinet and its wholly owned subsidiaries (collectively, the “Company,” “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany transactions and balances have been eliminated in consolidation.


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-19-000006:notes:11]
The following tables summarize our investments (in millions):

[0001262039-19-000006:notes:12]
|  | December 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 299.5 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 298.3 |  |
| Commercial paper | 102.5 |  |  | — |  |  | — |  |  | 102.5 |  |
| Certificates of deposit and term deposits (1) | 145.8 |  |  | — |  |  | — |  |  | 145.8 |  |
| U.S. government and agency securities | 57.7 |  |  | — |  |  | (0.1 | ) |  | 57.6 |  |
| Total available-for-sale securities | $ | 605.5 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 604.2 |  |
|  | December 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 391.0 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 389.8 |  |
| Commercial paper | 74.2 |  |  | — |  |  | — |  |  | 74.2 |  |
| Certificates of deposit and term deposits (1) | 45.9 |  |  | — |  |  | — |  |  | 45.9 |  |
| U.S. government and agency securities | 28.5 |  |  | — |  |  | (0.1 | ) |  | 28.4 |  |
| Total available-for-sale securities | $ | 539.6 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 538.3 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-19-000006:notes:13]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-19-000006:notes:14]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.3 |  |
| Volatility | 31.8 | % |  | 36.0 | % |  | 42.2 | % |
| Risk-free interest rate | 2.7 | % |  | 1.9 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |


## ftnt:ScheduleOfSharesReservedForFutureIssuanceTableTextBlock

[0001262039-19-000006:notes:15]
The following table presents the common stock reserved for future issuance (in millions):

[0001262039-19-000006:notes:16]
|  | December 31, 2018 |
| Reserved for future equity award grants | 52.7 |  |
| Outstanding stock options and RSUs | 10.8 |  |
| Reserved for future ESPP issuances | 1.9 |  |
| Total common stock reserved for future issuances | 65.4 |  |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-19-000006:notes:17]
The following table summarizes stock-based compensation expense by award type (in millions):

[0001262039-19-000006:notes:18]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| RSUs | $ | 143.9 |  |  | $ | 119.8 |  |  | $ | 107.1 |  |
| Stock options | 8.8 |  |  | 7.3 |  |  | 6.6 |  |
| ESPP | 10.2 |  |  | 10.1 |  |  | 8.7 |  |
| Total stock-based compensation expense | $ | 162.9 |  |  | $ | 137.2 |  |  | $ | 122.4 |  |


## ftnt:ScheduleofEstimatedUsefulLivesofPropertyPlantandEquipmentTableTextBlock

[0001262039-19-000006:notes:19]
Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-19-000006:notes:20]
|  | Estimated Useful Lives |
| Building and building improvements | 2 to 30 years |
| Computer equipment and software | 1 to 7 years |
| Evaluation units | 1 year |
| Furniture and fixtures | 3 to 5 years |
| Leasehold improvements | Shorter of useful life or lease term |


## ftnt:ScheduleofFiniteLivedandIndefiniteLivedIntangibleAssetsTableTextBlock

[0001262039-19-000006:notes:21]
The following tables present other intangible assets—net as of December 31, 2018 and 2017 (in millions, except years):

[0001262039-19-000006:notes:22]
|  | December 31, 2018 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 34.4 |  |  | $ | 17.0 |  |  | $ | 17.4 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 12.8 |  |  | 4.7 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 29.8 |  |  | $ | 22.1 |  |

[0001262039-19-000006:notes:23]
|  | December 31, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 24.0 |  |  | $ | 13.7 |  |  | $ | 10.3 |  |
| Customer relationships | 4.7 |  | 14.5 |  |  | 10.1 |  |  | 4.4 |  |
|  |  |  | 38.5 |  |  | 23.8 |  |  | 14.7 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Total other intangible assets—net |  |  | $ | 40.1 |  |  | $ | 23.8 |  |  | $ | 16.3 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-19-000006:notes:24]
The following summarizes the number and value of the shares withheld for employee taxes (in millions):

[0001262039-19-000006:notes:25]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Shares withheld for taxes | 1.2 |  |  | 1.2 |  |  | 1.2 |  |
| Amount withheld for taxes | $ | 67.2 |  |  | $ | 45.1 |  |  | $ | 38.3 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-19-000006:notes:26]
Additional information related to our stock options is summarized below (in millions, except per share amounts):

[0001262039-19-000006:notes:27]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Weighted-average fair value per share granted | $ | 16.03 |  |  | $ | 12.15 |  |  | $ | 9.14 |  |
| Intrinsic value of options exercised | 62.2 |  |  | 42.7 |  |  | 40.3 |  |
| Fair value of options vested | 7.2 |  |  | 8.1 |  |  | 5.4 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-19-000006:notes:28]
Additional information related to the ESPP is provided below (in millions, except per share amounts):

[0001262039-19-000006:notes:29]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Weighted-average fair value per share granted | $ | 14.14 |  |  | $ | 8.73 |  |  | $ | 7.68 |  |
| Shares issued under the ESPP | 1.1 |  |  | 1.1 |  |  | 1.2 |  |
| Weighted-average price per share issued | $ | 35.32 |  |  | $ | 29.52 |  |  | $ | 21.01 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-19-000006:notes:30]
BUSINESS COMBINATIONS

[0001262039-19-000006:notes:31]
ZoneFox Holdings Limited

[0001262039-19-000006:notes:32]
On October 22, 2018, we acquired all outstanding shares of ZoneFox Holdings Limited (“ZoneFox”), a privately held cloud-based insider threat detection and response company headquartered in Edinburgh, Scotland. We expect the ZoneFox acquisition will allow us to provide additional user and entity behavior analytics features.

[0001262039-19-000006:notes:33]
Under the business combination method of accounting in accordance with ASC Topic 805, Business Combinations (“ASC 805”), the total preliminary purchase price was allocated to ZoneFox’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management’s best estimates and assumptions to assign fair value as of the acquisition date, and our estimates and assumptions are subject to change within the measurement period. The allocation of the purchase price for this acquisition has been prepared on a preliminary basis and changes to the allocation of certain assets and liabilities may occur as additional information becomes available. The primary area that remains preliminary relates to finalization of valuation analyses pertaining to intangible assets acquired and tax liabilities assumed. The preliminary purchase price for ZoneFox was $16.1 million, of which $12.5 million was allocated to goodwill that was non-deductible for tax purposes, and $6.8 million was allocated to identifiable intangible assets the majority of which was developed technology offset by $3.2 million of net liabilities assumed. Acquisition-related costs related to the ZoneFox acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000006:notes:34]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of December 31, 2018, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the target.

[0001262039-19-000006:notes:35]
Bradford Networks, Inc.

[0001262039-19-000006:notes:36]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services. We believe that this acquisition will extend the Fortinet Security Fabric to include network access control and provide for the security assessment and response related to devices accessing the network, including Internet of Things devices.

[0001262039-19-000006:notes:37]
Under the business combination method of accounting in accordance with ASC 805, the total purchase price was allocated to Bradford’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values using management's best estimates and assumptions to assign fair value as of the acquisition date. The purchase price for Bradford was $6.8 million, of which $11.1 million was allocated to goodwill that was non-deductible for tax purposes, and $8.0 million was allocated to identifiable intangible assets the majority of which was developed technology offset by $12.3 million of net liabilities assumed.  Acquisition-related costs related to the Bradford acquisition were not material. Goodwill recorded in connection with this acquisition represents the value we expect to be created through expansion into markets within our existing business, and potential cost savings and synergies.

[0001262039-19-000006:notes:38]
AccelOps, Inc.

[0001262039-19-000006:notes:39]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions. This acquisition extended the Fortinet Security Fabric.

[0001262039-19-000006:notes:40]
The acquisition of AccelOps was accounted as a business combination in accordance with ASC 805, and we used our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. The total purchase price for AccelOps was $22.3 million, of which $9.9 million was allocated to goodwill that was non-deductible for tax purposes, and $16.5 million was allocated to identifiable intangible assets with average estimated lives of approximately two to four years, offset by $4.1 million of net liabilities assumed.

[0001262039-19-000006:notes:41]
Additional Acquisition-Related Information

[0001262039-19-000006:notes:42]
The operating results of the acquired companies are included in our consolidated statements of income from the respective dates of acquisition. Pro forma results of operations have not been presented because the effects of these acquisitions, individually and in the aggregate, were not material to our consolidated statements of income.


## us-gaap:CommissionsExpensePolicyPolicyTextBlock

[0001262039-19-000006:notes:43]
Commission Expense—In 2017, we recognized commission expense on both product sales and service contracts at the time of sale. Beginning on January 1, 2018, we recognize sales commissions related to product sales upfront while sales commissions for service contracts are deferred as Deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-19-000006:notes:44]
COMMITMENTS AND CONTINGENCIES

[0001262039-19-000006:notes:45]
The following table summarizes our future principal contractual obligations as of December 31, 2018 (in millions):

[0001262039-19-000006:notes:46]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Operating lease commitments | $ | 50.1 |  |  | $ | 17.1 |  |  | $ | 12.2 |  |  | $ | 8.5 |  |  | $ | 5.0 |  |  | $ | 3.6 |  |  | $ | 3.7 |  |
| Inventory purchase commitments | 177.3 |  |  | 173.1 |  |  | 4.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 227.4 |  |  | $ | 190.2 |  |  | $ | 16.4 |  |  | $ | 8.5 |  |  | $ | 5.0 |  |  | $ | 3.6 |  |  | $ | 3.7 |  |

[0001262039-19-000006:notes:47]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $17.1 million, $16.7 million and $18.9 million for 2018, 2017 and 2016, respectively. Rent expense is recognized using the straight-line method over the term of a lease.

[0001262039-19-000006:notes:48]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of December 31, 2018, we had $177.3 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-19-000006:notes:49]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of December 31, 2018, we had $14.3 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-19-000006:notes:50]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-19-000006:notes:51]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to events from over two years ago related to our compliance with the Trade Agreements Act. We have been fully cooperating with this ongoing inquiry and have periodically met and spoken with the United States Attorney’s Office in connection with this matter. We are currently in settlement discussions with the United States Attorney's Office.

[0001262039-19-000006:notes:52]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001262039-19-000006:notes:53]
Contingent Liabilities—From time to time, we are involved in disputes, litigation, and other legal actions. However, there are many uncertainties associated with such legal action, and these actions or other third-party claims against us may cause us to incur substantial settlement charges, which are inherently difficult to estimate and could adversely affect our results of operations. We review significant new claims and litigation for the probability of an adverse outcome. Estimates can change as individual claims develop. The actual liability in any such matters may be materially different from our estimates, which could result in the need to adjust our liability and record additional expenses.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-19-000006:notes:54]
DEFINED CONTRIBUTION PLANS

[0001262039-19-000006:notes:55]
Our tax-deferred savings plan under our 401(k) Plan, permits participating U.S. employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for 2018, 2017 and 2016 were $5.7 million, $4.7 million and $4.4 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-19-000006:notes:56]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-19-000006:notes:57]
The following table summarizes the changes in accumulated balances of other comprehensive loss for 2017 (in millions):

[0001262039-19-000006:notes:58]
|  | Year Ended December 31, 2017 |
|  | Unrealized Losses on Investments |  | Tax benefit (provision) related to unrealized gains or losses on investments |  | Total |
| Beginning balance | $ | (1.2 | ) |  | $ | 0.4 |  |  | $ | (0.8 | ) |
| Other comprehensive income before reclassifications | (0.9 | ) |  | 0.3 |  |  | (0.6 | ) |
| Amounts reclassified from accumulated other comprehensive loss | 0.8 |  |  | (0.2 | ) |  | 0.6 |  |
| Net current-period other comprehensive income | (0.1 | ) |  | 0.1 |  |  | — |  |
| Ending balance | $ | (1.3 | ) |  | $ | 0.5 |  |  | $ | (0.8 | ) |

[0001262039-19-000006:notes:59]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in Other income (expense)—net and in Provision for income taxes, respectively. We do not have any material changes to accumulated other comprehensive income during 2018.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-19-000006:notes:60]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-19-000006:notes:61]
Our investments in the equity securities of privately held companies totaled $9.1 million and $12.1 million as of December 31, 2018 and 2017, respectively. These investments, which were previously accounted for at cost, are now accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as other assets on our consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. During the third quarter of 2018, we sold equity securities of a privately held company for $5.2 million and recognized a gain of $2.2 million as other income in our consolidated statements of income. As of December 31, 2018, no events have occurred that would affect the carrying value of these investments.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001262039-19-000006:notes:62]
The following table presents our revenue disaggregated by major product and service lines (in millions):

[0001262039-19-000006:notes:63]
|  | Years Ended |
|  | December 31, 2018 |  | December 31, 2017 (1) |
| Product | $ | 674.4 |  |  | $ | 577.2 |  |
| Service: |  |  |  |
| Security subscription | 606.1 |  |  | 504.8 |  |
| Technical support and other (2) | 520.7 |  |  | 412.9 |  |
| Total service revenue | 1,126.8 |  |  | 917.7 |  |
| Total revenue | $ | 1,801.2 |  |  | $ | 1,494.9 |  |
| (1) Prior period amounts have not been adjusted under the modified retrospective method. |
| (2) During 2018, the amounts previously reported as professional services and training have been combined with the amounts previously reported as technical support. The combined amounts are now being presented as technical support and other. The professional service and training amounts are not material, and the reclassification did not have any impact on our service revenue or total revenue. Prior periods have been reclassified to conform with current period presentation. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-19-000006:notes:64]
STOCKHOLDERS’ EQUITY

[0001262039-19-000006:notes:65]
Stock-Based Compensation Plans

[0001262039-19-000006:notes:66]
Our stock-based compensation plans include the 2000 Stock Plan (the “2000 Plan”), the 2008 Stock Plan (the “2008 Plan”), the 2009 Equity Incentive Plan (the “2009 Plan”) and the ESPP. Under these plans, we have granted stock options and RSUs.

[0001262039-19-000006:notes:67]
Stock Plans—Our board of directors adopted the 2000 Plan in 2000 and the 2008 Plan in 2008. During 2018, 2017 and 2016, we issued no stock options under these plans. As of December 31, 2015, no shares remain available for grant under these plans.

[0001262039-19-000006:notes:68]
2009 Equity Incentive Plan—In 2009, our board of directors approved the 2009 Plan, which includes awards of stock options, stock appreciation rights, restricted stock, RSUs and performance stock units. The maximum aggregate number of shares that may be issued under the 2009 Plan is 9.0 million shares, plus any shares subject to stock options or similar awards granted under the 2008 Plan and the 2000 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2008 Plan and the 2000 Plan that are forfeited to or repurchased by us, with the maximum number of shares to be added to the 2009 Plan pursuant to such terminations, forfeitures and repurchases not to exceed 21.0 million shares. The shares may be authorized but unissued or reacquired common stock. The number of shares available for issuance under the 2009 Plan is increased on the first day of each year beginning with 2011, in an amount equal to the lesser of (i) 14.0 million shares (as adjusted in connection with the stock split effected in June 2011), (ii) 5% of the outstanding shares on the last day of the immediately preceding year or (iii) such number of shares determined by our board of directors. Under the 2009 Plan, we may grant awards to employees, directors and other service providers. In the case of an incentive stock option granted to an employee who, at the time of the grant, owns stock representing more than 10% of the voting power of all classes of stock, the exercise price shall be no less than 110% of the fair market value per share on the date of grant and expire five years from the date of grant, and options granted to any other employee, the per share exercise price shall be no less than 100% of the closing stock price on the date of grant. In the case of a non-statutory stock option and options granted to other service providers, the per share exercise price shall be no less than 100% of the fair market value per share on the date of grant. Options granted to individuals owning less than 10% of the total combined voting power of all classes of stock generally have a contractual term of seven years and options generally vest over four years.

[0001262039-19-000006:notes:69]
2011 Employee Stock Purchase Plan—In June 2011, our stockholders approved the ESPP. The ESPP permitted eligible employees to purchase common stock through regular, systematic payroll deductions, up to a maximum of 15% of employees’ compensation for each purchase period at purchase prices equal to 85% of the lesser of the fair market value of our common stock at the first trading date of the applicable offering period or the purchase date, subject to purchase limits of 4,000 shares for each purchase period or $25,000 worth of stock for each calendar year. Our board of directors voluntarily determined to terminate the ESPP, effective February 2019 at the completion of the prior offering period.

[0001262039-19-000006:notes:70]
As of December 31, 2018, there were a total of 54,512,197 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-19-000006:notes:71]
Restricted Stock Units

[0001262039-19-000006:notes:72]
The following table summarizes the activity and related information for RSUs for the periods presented below (in millions, except per share amounts):

[0001262039-19-000006:notes:73]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2015 | 9.3 |  |  | $ | 32.97 |  |
| Granted | 5.5 |  |  | 27.96 |  |
| Forfeited | (1.7 | ) |  | 32.03 |  |
| Vested | (3.6 | ) |  | 30.45 |  |
| Balance—December 31, 2016 | 9.5 |  |  | 31.01 |  |
| Granted | 4.2 |  |  | 37.60 |  |
| Forfeited | (1.3 | ) |  | 34.12 |  |
| Vested | (3.9 | ) |  | 29.42 |  |
| Balance—December 31, 2017 | 8.5 |  |  | 34.79 |  |
| Granted | 4.1 |  |  | 57.37 |  |
| Forfeited | (0.9 | ) |  | 39.29 |  |
| Vested | (3.9 | ) |  | 34.67 |  |
| Balance—December 31, 2018 | 7.8 |  |  | $ | 46.07 |  |

[0001262039-19-000006:notes:74]
As of December 31, 2018, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $306.1 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.70 years.

[0001262039-19-000006:notes:75]
RSUs settle into shares of common stock upon vesting. Upon the vesting of the RSUs, we net-settle the RSUs and withhold a portion of the shares to satisfy minimum statutory employee withholding tax requirement. Total payment of the employees’ tax obligations to the tax authorities is reflected as a financing activity within the consolidated statements of cash flows.

[0001262039-19-000006:notes:76]
Employee Stock Options

[0001262039-19-000006:notes:77]
In determining the fair value of our employee stock options, we use the Black-Scholes option pricing model, which employs the following assumptions.

[0001262039-19-000006:notes:78]
Expected Term—The expected term represents the period that our stock-based awards are expected to be outstanding. We believe that we have sufficient historical experience for determining the expected term of the stock option award, and therefore, we calculated our expected term based on historical experience instead of using the simplified method.

[0001262039-19-000006:notes:79]
Expected Volatility—The expected volatility of our common stock is based on our weighted-average implied and historical volatility.

[0001262039-19-000006:notes:80]
Fair Value of Common Stock—The fair value of our common stock is the closing sales price of the common stock effective on the date of grant.

[0001262039-19-000006:notes:81]
Risk-Free Interest Rate—We base the risk-free interest rate on the implied yield available on U.S. Treasury zero-coupon issues with an equivalent remaining term.

[0001262039-19-000006:notes:82]
Expected Dividend—The expected dividend weighted-average assumption is zero.

[0001262039-19-000006:notes:83]
The following table summarizes the stock option activity and related information for the periods presented below (in millions, except exercise prices and contractual life):

[0001262039-19-000006:notes:84]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2015 | 7.0 |  |  | $ | 20.03 |  |  |  |  |  |
| Granted | 1.5 |  |  | 25.65 |  |  |  |  |  |
| Forfeited | (0.3 | ) |  | 34.82 |  |  |  |  |  |
| Exercised | (2.0 | ) |  | 10.45 |  |  |  |  |  |
| Balance—December 31, 2016 | 6.2 |  |  | 23.79 |  |  |  |  |  |
| Granted | 0.5 |  |  | 37.34 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | 31.75 |  |  |  |  |  |
| Exercised | (2.2 | ) |  | 19.19 |  |  |  |  |  |
| Balance—December 31, 2017 | 4.3 |  |  | 27.50 |  |  |  |  |  |  |
| Granted | 0.8 |  |  | 52.09 |  |  |  |  |  |
| Forfeited | (0.2 | ) |  | 32.24 |  |  |  |  |  |
| Exercised | (1.9 | ) |  | 24.96 |  |  |  |  |  |
| Balance—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  |  |  |  |
| Options vested and expected to vest—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  | 4.00 |  | $ | 105.6 |  |
| Options exercisable—December 31, 2018 | 1.6 |  |  | $ | 28.91 |  |  | 2.67 |  | $ | 66.3 |  |

[0001262039-19-000006:notes:85]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on December 31, 2018, for all in-the-money stock options. As of December 31, 2018, total compensation expense related to unvested stock options granted to employees but not yet recognized was $16.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 2.60 years.

[0001262039-19-000006:notes:86]
The following table summarizes information about outstanding and exercisable stock options as of December 31, 2018, as follows (in millions, except exercise prices and contractual life):

[0001262039-19-000006:notes:87]
|  |  | Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife (Years) |  | Weighted-AverageExercisePrice |  | NumberExercisable |  | Weighted-AverageExercisePrice |
| $19.94–24.92 |  | 1.0 |  |  | 3.34 |  | 23.50 |  |  | 0.7 |  |  | 23.37 |  |
| 26.49–33.31 |  | 0.7 |  |  | 1.69 |  | 29.30 |  |  | 0.6 |  |  | 28.90 |  |
| 36.70–39.49 |  | 0.4 |  |  | 5.06 |  | 37.42 |  |  | 0.2 |  |  | 37.50 |  |
| 48.83–49.06 |  | 0.8 |  |  | 5.74 |  | 49.02 |  |  | 0.1 |  |  | 48.85 |  |
| 58.29–76.22 |  | 0.1 |  |  | 6.52 |  | 68.29 |  |  | — |  |  | — |  |
|  |  | 3.0 |  |  |  |  |  |  | 1.6 |  |  |  |

[0001262039-19-000006:notes:88]
Employee Stock Purchase Plan

[0001262039-19-000006:notes:89]
In determining the fair value of the ESPP, which was terminated in February 2019, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-19-000006:notes:90]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 28.9 | % |  | 29.5 | % |  | 39.4 | % |
| Risk-free interest rate | 2.0 | % |  | 0.9 | % |  | 0.4 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001262039-19-000006:notes:91]
Shares Reserved for Future Issuances

[0001262039-19-000006:notes:92]
Stock-based Compensation Expense

[0001262039-19-000006:notes:93]
Stock-based compensation expense is included in costs and expenses as follows (in millions):

[0001262039-19-000006:notes:94]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Cost of product revenue | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |
| Cost of service revenue | 10.8 |  |  | 9.5 |  |  | 8.8 |  |
| Research and development | 36.4 |  |  | 32.2 |  |  | 30.1 |  |
| Sales and marketing | 95.6 |  |  | 78.0 |  |  | 68.1 |  |
| General and administrative | 18.6 |  |  | 16.1 |  |  | 14.2 |  |
| Total stock-based compensation expense | $ | 162.9 |  |  | $ | 137.2 |  |  | $ | 122.4 |  |

[0001262039-19-000006:notes:95]
Share Repurchase Program

[0001262039-19-000006:notes:96]
In January 2016, our board of directors approved the Share Repurchase Program (the “Repurchase Program”), which authorized the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In 2016 and 2017, our board of directors approved the increases in the aggregate authorized repurchase amount under the Repurchase Program by $100.0 million and $700.0 million, respectively, to a total of $1.0 billion. In July 2018, our board of directors approved a $500.0 million increase in the authorized stock repurchase under the Repurchase program and extended the term of the Repurchase Program to December 31, 2019, bringing the aggregate amount authorized to be repurchased to $1.5 billion of our outstanding common stock through December 31, 2019. Under the Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. In 2018, we repurchased 3.8 million shares of common stock under the Repurchase Program in open market transactions for an aggregate purchase price of $209.1 million. As of December 31, 2018, $733.8 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-19-000006:notes:97]
NET INCOME PER SHARE

[0001262039-19-000006:notes:98]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period, plus the dilutive effects of RSUs, stock options and our Employee Stock Purchase Plan (the “ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-19-000006:notes:99]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in millions, except per share amounts):

[0001262039-19-000006:notes:100]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 332.2 |  |  | $ | 31.4 |  |  | $ | 32.2 |  |
| Denominator: |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 169.1 |  |  | 174.3 |  |  | 172.6 |  |
| Diluted shares: |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 169.1 |  |  | 174.3 |  |  | 172.6 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |
| RSUs | 3.6 |  |  | 2.3 |  |  | 1.9 |  |
| Stock options | 1.4 |  |  | 1.4 |  |  | 1.7 |  |
| ESPP | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 174.2 |  |  | 178.1 |  |  | 176.3 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.96 |  |  | $ | 0.18 |  |  | $ | 0.19 |  |
| Diluted | $ | 1.91 |  |  | $ | 0.18 |  |  | $ | 0.18 |  |

[0001262039-19-000006:notes:101]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in millions):

[0001262039-19-000006:notes:102]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| RSUs | 0.5 |  |  | 1.4 |  |  | 3.3 |  |
| Stock options | 0.3 |  |  | 1.0 |  |  | 1.0 |  |
| ESPP | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
|  | 0.9 |  |  | 2.6 |  |  | 4.5 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-19-000006:notes:103]
FINANCIAL INSTRUMENTS AND FAIR VALUE

[0001262039-19-000006:notes:104]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in millions):

[0001262039-19-000006:notes:105]
|  | December 31, 2018 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 150.1 |  |  | $ | (0.2 | ) |  | $ | 93.5 |  |  | $ | (1.0 | ) |  | $ | 243.6 |  |  | $ | (1.2 | ) |
| Certificates of deposit and term deposits | 51.7 |  |  | — |  |  | — |  |  | — |  |  | 51.7 |  |  | — |  |
| Commercial paper | 75.6 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 75.6 |  |  | (0.1 | ) |
| U.S. government and agency securities | 39.0 |  |  | — |  |  | 3.5 |  |  | — |  |  | 42.5 |  |  | — |  |
| Total available-for-sale securities | $ | 316.4 |  |  | $ | (0.3 | ) |  | $ | 97.0 |  |  | $ | (1.0 | ) |  | $ | 413.4 |  |  | $ | (1.3 | ) |

[0001262039-19-000006:notes:106]
|  | December 31, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 317.4 |  |  | $ | (0.9 | ) |  | $ | 58.2 |  |  | $ | (0.3 | ) |  | $ | 375.6 |  |  | $ | (1.2 | ) |
| Certificates of deposit and term deposits | 37.2 |  |  | — |  |  | — |  |  | — |  |  | 37.2 |  |  | — |  |
| Commercial paper | 29.1 |  |  | — |  |  | — |  |  | — |  |  | 29.1 |  |  | — |  |
| U.S. government and agency securities | 17.0 |  |  | — |  |  | 11.4 |  |  | (0.1 | ) |  | 28.4 |  |  | (0.1 | ) |
| Total available-for-sale securities | $ | 400.7 |  |  | $ | (0.9 | ) |  | $ | 69.6 |  |  | $ | (0.4 | ) |  | $ | 470.3 |  |  | $ | (1.3 | ) |

[0001262039-19-000006:notes:107]
The contractual maturities of our investments were as follows (in millions):

[0001262039-19-000006:notes:108]
|  | December 31, 2018 |  | December 31, 2017 |
| Due within one year | $ | 537.2 |  |  | $ | 440.3 |  |
| Due within one to three years | 67.0 |  |  | 98.0 |  |
| Total | $ | 604.2 |  |  | $ | 538.3 |  |

[0001262039-19-000006:notes:109]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Realized losses on available-for-sale securities were insignificant in the periods presented and are included in Other income (expense)—net in our consolidated statements of income. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-19-000006:notes:110]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of December 31, 2018.

[0001262039-19-000006:notes:111]
Fair Value Accounting—We apply the following fair value hierarchy for disclosure of the inputs used to measure fair value. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001262039-19-000006:notes:112]
Level 1—Inputs are unadjusted quoted prices in active markets for identical assets or liabilities.

[0001262039-19-000006:notes:113]
Level 2—Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the assets or liabilities, either directly or indirectly through market corroboration, for substantially the full term of the financial instruments.

[0001262039-19-000006:notes:114]
Level 3—Unobservable inputs based on our own assumptions used to measure assets and liabilities at fair value. The inputs require significant management judgment or estimation.

[0001262039-19-000006:notes:115]
We measure the fair value of money market funds and certain U.S. government and agency securities using quoted prices in active markets for identical assets. The fair value of all other financial instruments was based on quoted prices for similar assets in active markets, or model driven valuations using significant inputs derived from or corroborated by observable market data.

[0001262039-19-000006:notes:116]
We classify investments within Level 1 if quoted prices are available in active markets for identical securities.

[0001262039-19-000006:notes:117]
We classify items within Level 2 if the investments are valued using model driven valuations using observable inputs such as quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models.

[0001262039-19-000006:notes:118]
Fair Value of Financial Instruments

[0001262039-19-000006:notes:119]
Assets Measured at Fair Value on a Recurring Basis

[0001262039-19-000006:notes:120]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of December 31, 2018 and 2017 (in millions):

[0001262039-19-000006:notes:121]
|  | December 31, 2018 |  | December 31, 2017 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 299.3 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |  | $ | 411.1 |  |  | $ | — |  |
| Certificates of deposit and term deposits | 217.4 |  |  | — |  |  | 217.4 |  |  | — |  |  | 132.1 |  |  | — |  |  | 132.1 |  |  | — |  |
| Money market funds | 58.6 |  |  | 58.6 |  |  |  |  |  | — |  |  | 195.6 |  |  | 195.6 |  |  | — |  |  | — |  |
| Commercial paper | 184.7 |  |  | — |  |  | 184.7 |  |  | — |  |  | 128.9 |  |  | — |  |  | 128.9 |  |  | — |  |
| U.S. government and agency securities | 57.6 |  |  | 45.3 |  |  | 12.3 |  |  | — |  |  | 28.4 |  |  | 24.9 |  |  | 3.5 |  |  | — |  |
| Total | $ | 817.6 |  |  | $ | 103.9 |  |  | $ | 713.7 |  |  | $ | — |  |  | $ | 896.1 |  |  | $ | 220.5 |  |  | $ | 675.6 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 213.4 |  |  |  |  |  |  |  |  | $ | 357.8 |  |  |  |  |  |  |  |
| Short-term investments | 537.2 |  |  |  |  |  |  |  |  | 440.3 |  |  |  |  |  |  |  |
| Long-term investments | 67.0 |  |  |  |  |  |  |  |  | 98.0 |  |  |  |  |  |  |  |
| Total | $ | 817.6 |  |  |  |  |  |  |  |  | $ | 896.1 |  |  |  |  |  |  |  |

[0001262039-19-000006:notes:122]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the years ended December 31, 2018 and December 31, 2017.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001262039-19-000006:notes:123]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-19-000006:notes:124]
GOODWILL AND OTHER INTANGIBLE ASSETS—Net

[0001262039-19-000006:notes:125]
Goodwill

[0001262039-19-000006:notes:126]
The following table presents the changes in the carrying amount of goodwill (in millions):

[0001262039-19-000006:notes:127]
|  | Amount |
| Balance—December 31, 2017 | $ | 14.6 |  |
| Additions due to business combinations | 23.6 |  |
| Balance—December 31, 2018 | $ | 38.2 |  |

[0001262039-19-000006:notes:128]
There were no impairments to goodwill during 2018, 2017, 2016 or any previous years.

[0001262039-19-000006:notes:129]
Other Intangible Assets—net

[0001262039-19-000006:notes:130]
The project related to in-process research and development intangible asset of $1.6 million was completed in the first quarter of 2018. Upon completion, the cost was transferred to developed technology and is amortized over the estimated useful life of four years. Amortization expense of finite-lived intangible assets was $9.0 million, $8.6 million and $9.3 million in 2018, 2017, and 2016, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in millions):

[0001262039-19-000006:notes:131]
|  | Amount |
| Years: |  |
| 2019 | $ | 10.2 |  |
| 2020 | 6.2 |  |
| 2021 | 3.6 |  |
| 2022 | 2.1 |  |
| Total | $ | 22.1 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001262039-19-000006:notes:132]
Impairment of Long-Lived Assets—We evaluate events and changes in circumstances that could indicate carrying amounts of long-lived assets, including intangible assets, may not be recoverable. When such events or changes in circumstances occur, we assess the recoverability of long-lived assets by determining whether the carrying value of such assets will be recovered through undiscounted expected future cash flows. If the total of the future undiscounted cash flows is less than the carrying amount of those assets, we record an impairment charge in the period in which we make the determination. If such assets are considered to be impaired, the impairment to be recognized is measured by the amount by which the carrying amount of the assets exceeds the fair value of the assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-19-000006:notes:133]
INCOME TAXES

[0001262039-19-000006:notes:134]
Income before income taxes consisted of the following (in millions):

[0001262039-19-000006:notes:135]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Domestic | $ | 0.3 |  |  | $ | (40.7 | ) |  | $ | (49.7 | ) |
| Foreign | 250.6 |  |  | 164.7 |  |  | 92.8 |  |
| Total income before income taxes | $ | 250.9 |  |  | $ | 124.0 |  |  | $ | 43.1 |  |

[0001262039-19-000006:notes:136]
The provision for (benefit from) income taxes consisted of the following (in millions):

[0001262039-19-000006:notes:137]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Current: |  |  |  |  |  |
| Federal | $ | (12.6 | ) |  | $ | 34.7 |  |  | $ | 7.9 |  |
| State | 2.0 |  |  | 0.8 |  |  | 0.8 |  |
| Foreign | 36.9 |  |  | 27.7 |  |  | 17.8 |  |
| Total current | $ | 26.3 |  |  | $ | 63.2 |  |  | $ | 26.5 |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | (125.5 | ) |  | $ | 39.1 |  |  | $ | (10.0 | ) |
| State | 14.4 |  |  | (9.3 | ) |  | (4.9 | ) |
| Foreign | 3.5 |  |  | (0.4 | ) |  | (0.7 | ) |
| Total deferred | (107.6 | ) |  | 29.4 |  |  | (15.6 | ) |
| Provision for (benefit from) income taxes | $ | (81.3 | ) |  | $ | 92.6 |  |  | $ | 10.9 |  |

[0001262039-19-000006:notes:138]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001262039-19-000006:notes:139]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Tax at federal statutory tax rate | $ | 52.7 |  |  | $ | 43.4 |  |  | $ | 15.1 |  |
| Foreign income taxed at different rates | (21.5 | ) |  | (19.5 | ) |  | (13.7 | ) |
| Foreign withholding taxes | 20.1 |  |  | 17.4 |  |  | 15.0 |  |
| Stock-based compensation expense | (14.3 | ) |  | 9.5 |  |  | 10.0 |  |
| Foreign tax credit | (15.8 | ) |  | (12.8 | ) |  | (35.0 | ) |
| State taxes—net of federal benefit | 1.2 |  |  | (3.5 | ) |  | (4.2 | ) |
| Research and development credit | (5.0 | ) |  | (4.0 | ) |  | (2.7 | ) |
| Valuation allowance | 14.9 |  |  | — |  |  | — |  |
| Dividend distribution | (3.8 | ) |  | — |  |  | 27.3 |  |
| Impact of the 2017 Tax Act: |  |  |  |  |  |
| Deferred tax asset remeasurement due to reduction in the federal corporate income tax rate | — |  |  | 47.9 |  |  | — |  |
| One-time transition tax | 32.6 |  |  | 15.2 |  |  | — |  |
| Global Intangible Low-Taxed Income | 20.5 |  |  | — |  |  | — |  |
| Book-to-Tax Basis differences | (164.0 | ) |  | — |  |  | — |  |
| Other | 1.1 |  |  | (1.0 | ) |  | (0.9 | ) |
| Total provision for (benefit from) income taxes | $ | (81.3 | ) |  | $ | 92.6 |  |  | $ | 10.9 |  |

[0001262039-19-000006:notes:140]
There are permanent differences that arise from the portion of stock-based compensation expense that is not expected to generate a tax deduction, such as stock-based compensation expense on stock grants to certain foreign employees, this is offset by the actual tax benefits in the current periods from shares held by our U.S. employees. In 2018, this excess tax benefit was greater than the non-deductible stock-based compensation expense.

[0001262039-19-000006:notes:141]
We have realigned our tax structure in order to maximize the tax efficiency of our group structure and better align with our business operations as a result of the Tax Cuts and Jobs Act (the “2017 Tax Act”). This realignment resulted in a book-to-tax basis difference for previously taxed off-shore deferred revenue as well as other book-to-tax difference. The basis differences resulted in a $164.0 million benefit to the 2018 tax provision.

[0001262039-19-000006:notes:142]
In December 2017, the U.S. federal government enacted the 2017 Tax Act. The 2017 Tax Act reduced the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018 and created a territorial tax system with a one-time mandatory tax on foreign earnings of U.S. subsidiaries not previously subject to U.S. income tax. Under GAAP, changes in tax rates and tax law are accounted for in the period of enactment and deferred tax assets and liabilities are measured at the enacted tax rate. In December 2017, the staff of the Securities and Exchange Commission (the “SEC”) issued Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allowed us to record provisional amounts during a measurement period not to extend beyond one year of the enactment date. As a result, we previously provided a provisional estimate of the effect of the 2017 Tax Act in our financial statements. In the fourth quarter of 2018, we completed our analysis to determine the effect of the 2017 Tax Act within the measurement period under the SEC guidance, and reflected an additional $32.6 million increase related to the transition tax in the 2018 income tax expense. We expect further guidance may be forthcoming from the FASB and the SEC, as well as regulations, interpretations and rulings from federal and state tax agencies, which could result in additional impacts. The 2017 Tax Act also creates a new requirement that Global Intangible Low-Taxed Income (“GILTI”) earned by controlled foreign corporations (“CFCs”) must be included currently in the gross income of a CFC’s U.S. shareholder. In 2018, there was also a $20.5 million expense for the GILTI tax regime that was introduced by the 2017 Tax Act.

[0001262039-19-000006:notes:143]
Under GAAP, we are allowed to make an accounting policy choice of either (i) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (ii) factoring such amounts into a company’s measurement of its deferred taxes. Our selection of an accounting policy for 2018 with respect to the GILTI tax rules was to treat GILTI tax as a current period expense under the period cost method.

[0001262039-19-000006:notes:144]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets as of the years ended are presented below (in millions):

[0001262039-19-000006:notes:145]
|  | December 31, 2018 |  | December 31, 2017 |
| Deferred tax assets: |  |  |  |
| General business credit carryforward | $ | 29.5 |  |  | $ | 49.9 |  |
| Deferred revenue | 223.9 |  |  | 37.4 |  |
| Reserves and accruals | 26.6 |  |  | 23.0 |  |
| Net operating loss carryforward | 13.5 |  |  | 15.7 |  |
| Stock-based compensation expense | 16.2 |  |  | 12.3 |  |
| Depreciation and amortization | 3.3 |  |  | 8.8 |  |
| Other | — |  |  | (0.2 | ) |
| Total deferred tax assets | 313.0 |  |  | 146.9 |  |
| Less: Valuation allowance | (14.9 | ) |  | — |  |
| Deferred tax assets, net of valuation allowance | 298.1 |  |  | 146.9 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred contract costs | (52.1 | ) |  | — |  |
| Total deferred tax liabilities | (52.1 | ) |  | — |  |
| Net deferred tax assets | $ | 246.0 |  |  | $ | 146.9 |  |

[0001262039-19-000006:notes:146]
In assessing the realizability of deferred tax assets, we considered whether it is more likely than not that some portion or all of our deferred tax assets will be realized. This realization is dependent upon the generation of future taxable income during the periods in which those temporary differences become deductible. We concluded that it is more likely than not that we would be able to realize the benefits of our deferred tax assets in the future except for California research and development (“R&D”) credits carryforward. We anticipate having sufficient current year generated California R&D credits to cover the same year California tax liability for tax year 2018 and subsequent years. As a result, we recorded a valuation allowance of $14.9 million against California R&D credits carryforwards (net of the unrecognized tax benefits), as it is more likely than not these deferred tax assets will not be realized.

[0001262039-19-000006:notes:147]
As of December 31, 2018, we had $47.3 million in federal net operating loss carryforwards to offset future income, which is limited by Section 382 of the Internal Revenue Code (“Section 382”) due to the acquisition of Meru, AccelOps and Bradford. With the acquisition of Meru, we had $22.6 million in federal net operating loss carryforwards which is limited by Section 382 available from year 2020. With the acquisition of AccelOps, we had $19.9 million in federal net operating loss carryforwards from 2016 and that are limited by Section 382. With the acquisition of Bradford, we had $8.6 million in federal net operating loss carryforwards from 2018 and that are limited by Section 382 available from July 2018. In 2018, it is estimated that the NOL carryforwards of $3.0 million from AccelOps and $0.8 million from Bradford will be utilized. We had $7.8 million federal tax credits to offset future federal taxes. As of December 31, 2018, we had $36.7 million in California net operating loss carryforwards including $22.1 million from Meru and $14.6 million from AccelOps, both of which are limited by Section 382. We had state tax credit carryforwards of $24.0 million available to offset our future state taxes. The state credits carry forward indefinitely.

[0001262039-19-000006:notes:148]
Under the 2017 Tax Act, starting on January 1, 2018, we are no longer subject to federal income tax on earnings remitted from our foreign subsidiaries. We have analyzed our global working capital and cash requirements and the potential tax liabilities attributable to repatriation, and have determined that we will be repatriating certain unremitted foreign earnings which was previously deemed indefinitely reinvested. For those investments from which we were able to make a reasonable estimate of the tax effects of such repatriation, we have recorded a provisional estimate for withholding and state taxes. For those investments from which we were not able to make a reasonable estimate, we have not recorded any deferred taxes.

[0001262039-19-000006:notes:149]
We operate under a tax incentive agreement in Singapore, which is effective through December 31, 2021, and may be extended if certain additional requirements are satisfied. The tax incentive agreement is conditional upon our meeting certain employment and investment thresholds.

[0001262039-19-000006:notes:150]
As of December 31, 2018, we had $63.5 million of unrecognized tax benefits, of which, if recognized, $58.8 million would favorably affect our effective tax rate. Our policy is to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of December 31, 2018, 2017 and 2016, accrued interest and penalties were $11.6 million, $13.5 million and $9.5 million, respectively.

[0001262039-19-000006:notes:151]
The aggregate changes in the balance of unrecognized tax benefits are as follows (in millions):

[0001262039-19-000006:notes:152]
|  | Year Ended December 31, |
|  | 2018 |  | 2017 |  | 2016 |
| Unrecognized tax benefits, beginning of year | $ | 72.5 |  |  | $ | 65.5 |  |  | $ | 59.7 |  |
| Gross increases for tax positions related to the current year | 8.6 |  |  | 13.2 |  |  | 4.8 |  |
| Gross decreases for tax positions related to the current year | — |  |  | (10.7 | ) |  | — |  |
| Gross increases for tax positions related to the prior year | 6.0 |  |  | 7.0 |  |  | 1.7 |  |
| Gross decreases for tax positions related to prior year | (9.5 | ) |  | (0.9 | ) |  | (0.7 | ) |
| Gross decreases for tax positions related to prior year audit settlements | (6.4 | ) |  | (1.6 | ) |  | — |  |
| Gross decreases for tax positions related to expiration of statute of limitations | (7.7 | ) |  | — |  |  | — |  |
| Unrecognized tax benefits, end of year | $ | 63.5 |  |  | $ | 72.5 |  |  | $ | 65.5 |  |

[0001262039-19-000006:notes:153]
As of December 31, 2018, 2017 and 2016, $77.5 million, $90.2 million and $68.6 million, respectively, of the amounts reflected above were recorded as Income tax liabilities—non-current in our consolidated balance sheet.

[0001262039-19-000006:notes:154]
We recorded a net decrease of gross unrecognized tax benefits of approximately $9.0 million during the year ended December 31, 2018. The net decrease was primarily due to the reversal of gross unrecognized tax benefit in connection with the lapse of statutes of limitations in foreign jurisdictions and the audit settlement, offset by the increases related to 2018 gross unrecognized tax benefits.

[0001262039-19-000006:notes:155]
It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $10.1 million in the next 12 months, primarily due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-19-000006:notes:156]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We have closed the Internal Revenue Service audit for tax years 2012, 2013 and 2014 at the field level. In March 2018, we received a refund of $6.8 million for a carry-back claim approved in this audit. In October 2018, the French tax authorities notified us that they had closed the permanent establishment audits of Fortinet, Inc. and Fortinet Singapore for tax years from 2007 to 2015 with no tax adjustments. We currently have ongoing tax audits in the United Kingdom, Israel, India and Italy. The focus of these audits is the inter-company profit allocation.

[0001262039-19-000006:notes:157]
On July 24, 2018, the U.S. Court of Appeals for the Ninth Circuit overturned the U.S. Tax Court’s unanimous 2015 decision in Altera Corp v. Commissioner, holding that the IRS did not violate the rulemaking procedures required by the Administrative Procedures Act. On August 7, 2018, the Ninth Circuit withdrew the opinions filed July 24, 2018 to allow time for the reconstituted panel to confer on the appeal. In the Altera case, the taxpayer challenged IRS regulations that required participants in qualified cost sharing arrangements to share stock-based compensation costs. We continue to treat our stock-based compensation expense in accordance with Tax Court Opinion. We also continue to monitor developments in this case and any impact it could have on our tax provision.


## us-gaap:IncomeTaxPolicyTextBlock

[0001262039-19-000006:notes:158]
Income Taxes—We record income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in our financial statements or tax returns. In addition, deferred tax assets are recorded for the future benefit of utilizing net operating losses and research and development credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets and liabilities are expected to be realized or settled. Valuation allowances are provided when necessary to reduce deferred tax assets to the amount expected to be realized.

[0001262039-19-000006:notes:159]
We recognize tax benefits from an uncertain tax positions only if it is more likely than not, based on the technical merits of the position, that the tax position will be sustained on examination by the tax authorities. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-19-000006:notes:160]
INVENTORY

[0001262039-19-000006:notes:161]
Inventory consisted of the following (in millions):

[0001262039-19-000006:notes:162]
|  | December 31, 2018 |  | December 31, 2017 |
| Raw materials | $ | 13.3 |  |  | $ | 13.0 |  |
| Finished goods | 76.7 |  |  | 64.3 |  |
| Inventory | $ | 90.0 |  |  | $ | 77.3 |  |

[0001262039-19-000006:notes:163]
Inventory includes materials at contract manufacturers of $2.4 million and $2.6 million as of December 31, 2018 and 2017, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001262039-19-000006:notes:164]
Inventory—Inventory is recorded at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. In assessing the ultimate recoverability of inventory, we make estimates regarding future customer demand, the timing of new product introductions, economic trends and market conditions. If the actual product demand is significantly lower than forecasted, we could be required to record inventory write-downs which would be charged to cost of product revenue.


## us-gaap:LesseeLeasesPolicyTextBlock

[0001262039-19-000006:notes:165]
Leases—We rent certain facilities under operating lease agreements and recognize related rent expense on a straight-line basis over the term of the lease. Some of our lease agreements contain rent holidays, scheduled rent increases, lease incentives and renewal options. Rent holidays and scheduled rent increases are included in the determination of rent expense to be recorded over the lease term. Lease incentives are recognized as a reduction of rent expense on a straight-line basis over the term of the lease. Renewals are not assumed in the determination of the lease term unless they are deemed to be reasonably assured at the inception of the lease. We begin recognizing rent expense on the date that we obtain the legal right to use and control the leased space.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-19-000006:notes:166]
| Property and Equipment—net | December 31, 2018 |  | December 31, 2017 |
| Americas: |  |  |  |
| United States | $ | 132.1 |  |  | $ | 115.6 |  |
| Canada | 113.5 |  |  | 103.8 |  |
| LATAM | 0.4 |  |  | 0.3 |  |
| Total Americas | 246.0 |  |  | 219.7 |  |
| EMEA | 16.2 |  |  | 17.7 |  |
| APAC | 9.2 |  |  | 8.0 |  |
| Total property and equipment—net | $ | 271.4 |  |  | $ | 245.4 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-19-000006:notes:167]
Recently Adopted Accounting Standards

[0001262039-19-000006:notes:168]
Financial Instruments – Recognition and Measurement

[0001262039-19-000006:notes:169]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, with further clarifications made recently with the issuance of ASU 2018-03—Technical Corrections and Improvements to Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which requires most equity investments to be measured at fair value, with subsequent changes in fair value recognized in net income. A practicality exception applies to those equity investments that do not have a readily determinable fair value. These investments may be measured at cost, adjusted for changes in observable prices minus impairment. ASU 2016-01 was effective prospectively for us beginning on January 1, 2018 for our equity investments, which were previously accounted for under the cost-method. We adopted ASU 2016-01 on January 1, 2018. There was no material impact on our consolidated financial statements as of the adoption date.

[0001262039-19-000006:notes:170]
Revenue Recognition

[0001262039-19-000006:notes:171]
In May 2014, the FASB issued Topic 606, which supersedes the revenue recognition requirements in Topic 605 and requires entities to recognize revenue when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. We adopted Topic 606 as of January 1, 2018 using the modified retrospective transition method. The comparative information has not been restated and continues to be reported under the accounting standards in effect for those periods.

[0001262039-19-000006:notes:172]
We recorded a net reduction to our accumulated deficit as of January 1, 2018 of $117.3 million due to the cumulative impact of adopting Topic 606. The primary impact of adopting Topic 606 relates to the deferral of our incremental contract costs, which are comprised of sales commissions. Prior to January 1, 2018, we expensed all sales commissions upfront. Beginning on January 1, 2018, we continue to expense sales commissions related to product sales upfront, but capitalize and then amortize certain sales commissions on service contracts over the applicable amortization period. The deferred contract costs for capitalized sales commissions related to the initial service contracts are deferred and then amortized as expense on a straight-line basis over the period of benefit which we have determined to be five years. Sales commissions for renewal contracts are deferred and then amortized on a straight-line basis over the contractual period of the underlying contracts. The deferral of contract costs generated a deferred tax liability of $23.8 million, of which $18.0 million was recorded against deferred tax assets and the remaining $5.8 million was recorded in other long-term liabilities on our consolidated balance sheet. The impact on deferred revenue as of January 1, 2018 was $4.1 million, which primarily relates to certain changes in revenue recognition on software license sales and the acceleration of revenue from U.S.-based channel partners which were previously deferred until the product was sold through. Beginning on January 1, 2018, our sales returns reserve is now included on the balance sheet in accrued liabilities and no longer as a reduction to our accounts receivable. See above significant accounting policies for further details.

[0001262039-19-000006:notes:173]
The cumulative effects of the changes made to our January 1, 2018 consolidated balance sheet for the adoption of Topic 606 were as follows (in millions):

[0001262039-19-000006:notes:174]
|  | Balance at December 31, 2017 |  | Adjustments due to Topic 606 |  | Balance at January 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 348.2 |  |  | $ | 13.6 |  |  | $ | 361.8 |  |
| Inventory | 77.3 |  |  | (0.1 | ) |  | 77.2 |  |
| Deferred tax assets | 146.9 |  |  | (18.0 | ) |  | 128.9 |  |
| Deferred contract costs | — |  |  | 137.1 |  |  | 137.1 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | 50.0 |  |  | 13.6 |  |  | 63.6 |  |
| Deferred revenue, current | 793.8 |  |  | 0.3 |  |  | 794.1 |  |
| Deferred revenue, non-current | 542.5 |  |  | (4.4 | ) |  | 538.1 |  |
| Other liabilities, non-current | 8.6 |  |  | 5.8 |  |  | 14.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Accumulated deficit | $ | (319.6 | ) |  | $ | 117.3 |  |  | $ | (202.3 | ) |

[0001262039-19-000006:notes:175]
Recent Accounting Standards Not Yet Effective

[0001262039-19-000006:notes:176]
Cloud Computing

[0001262039-19-000006:notes:177]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other-Internal—Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in Accounting Standards Codification (“ASC”) Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our consolidated financial statements.

[0001262039-19-000006:notes:178]
Fair Value Measurements

[0001262039-19-000006:notes:179]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

[0001262039-19-000006:notes:180]
Stock Compensation

[0001262039-19-000006:notes:181]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of ASC Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. This amendment was effective for us beginning January 1, 2019. The adoption of this standard will not have a material impact on our consolidated financial statements.

[0001262039-19-000006:notes:182]
Comprehensive Income

[0001262039-19-000006:notes:183]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the 2017 Tax Act, from accumulated other comprehensive income to retained earnings. ASU 2018-02 also requires certain new disclosures regardless of the election. ASU 2018-02 was effective for us beginning January 1, 2019. We are currently assessing the impact of ASU 2018-02 on our consolidated financial statements and we expect the standard will not have a material impact on our consolidated financial statements.

[0001262039-19-000006:notes:184]
Financial Instruments

[0001262039-19-000006:notes:185]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset (or a group of financial assets) to be measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. ASU 2016-13 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of ASU 2016-13 on our consolidated financial statements.

[0001262039-19-000006:notes:186]
Leases

[0001262039-19-000006:notes:187]
In February 2016, the FASB issued ASU 2016-02—Leases (Topic 842), which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. ASU 2016-02 includes a number of optional practical expedients that entities may elect to apply. ASU 2016-02 will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. In July 2018, the FASB issued ASU 2018-10—Codification Improvements to Topic 842, Leases, and ASU 2018-11—Leases (Topic 842): Targeted Improvements, which address questions about how to apply certain aspects for the adoption of Topic 842. The clarifications address the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options and variable payments that depend on an index or rate, and provide an alternative transition approach that allows companies to initially apply the new leases standard by recognizing a cumulative-effect adjustment on adoption date. ASU 2016-02 was effective for us beginning on January 1, 2019, and we expect to apply a modified retrospective transition approach through a cumulative-effect adjustment at the beginning of the first quarter of 2019. Based on our current lease portfolio, we currently estimate that the value of leased assets and liabilities that may be recognized to be at least $40.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of income and cash flows. Upon adoption, we expect to expand our disclosures in the notes to consolidated financial statements to include more details on our leases, significant judgments and lease-related amounts recognized in the consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-19-000006:notes:188]
PROPERTY AND EQUIPMENT—Net

[0001262039-19-000006:notes:189]
Property and equipment—net consisted of the following (in millions):

[0001262039-19-000006:notes:190]
|  | December 31, 2018 |  | December 31, 2017 |
| Building and building improvements | $ | 144.2 |  |  | $ | 133.2 |  |
| Computer equipment and software | 95.9 |  |  | 79.9 |  |
| Land | 75.7 |  |  | 65.6 |  |
| Leasehold improvements | 17.9 |  |  | 20.8 |  |
| Evaluation units | 20.5 |  |  | 20.1 |  |
| Furniture and fixtures | 15.7 |  |  | 14.7 |  |
| Construction-in-progress | 12.3 |  |  | 6.3 |  |
| Total property and equipment | 382.2 |  |  | 340.6 |  |
| Less: accumulated depreciation | (110.8 | ) |  | (95.2 | ) |
| Property and equipment—net | $ | 271.4 |  |  | $ | 245.4 |  |

[0001262039-19-000006:notes:191]
Depreciation expense was $46.7 million, $46.9 million and $39.2 million in 2018, 2017 and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-19-000006:notes:192]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-19-000006:notes:193]
REVENUE RECOGNITION

[0001262039-19-000006:notes:194]
Transaction Price Allocated to the Remaining Performance Obligations

[0001262039-19-000006:notes:195]
As of December 31, 2018, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.69 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

[0001262039-19-000006:notes:196]
Accounts Receivable

[0001262039-19-000006:notes:197]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.9 million as of December 31, 2018 and December 31, 2017. As of December 31, 2017, accounts receivable was also reduced by sales return reserve of $13.6 million, which we reclassified to accrued liabilities account as of January 1, 2018 in accordance with the adoption of Topic 606.

[0001262039-19-000006:notes:198]
Contract Assets

[0001262039-19-000006:notes:199]
Contract assets represent amounts that have been recognized as revenue but for which we did not have the unconditional right to invoice the customer. We did not have contract assets as of December 31, 2018 and January 1, 2018.

[0001262039-19-000006:notes:200]
Deferred Contract Costs

[0001262039-19-000006:notes:201]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for the sale of products and software licenses are recognized at the time of sale. Sales commissions for initial service contracts are deferred and then amortized as an expense on a straight-line basis over the period of benefit which we have determined to be five years. We determined the period of benefit taking into consideration our customer contracts, our technology and other factors. Sales commissions for renewal contracts are deferred and then amortized on a straight-line basis over the contractual period of the underlying contracts which ranges from one to three years and, to a lesser extent, five years. The amortization of deferred contract costs is included in sales and marketing expense in our consolidated statement of income. Amortization of deferred contract costs during 2018 was $90.9 million. No impairment loss was recognized during 2018.

[0001262039-19-000006:notes:202]
Deferred Revenue

[0001262039-19-000006:notes:203]
Our deferred revenue consists of amounts that have been invoiced but have not been recognized as revenue as of period end. During 2018, we recognized $753.3 million in revenue that was included in the deferred revenue balance as of January 1, 2018.

[0001262039-19-000006:notes:204]
Practical Expedient

[0001262039-19-000006:notes:205]
We elected to use the contract modification practical expedient. This practical expedient allows for all contract modifications before January 1, 2018 to be aggregated and evaluated at adoption date.

[0001262039-19-000006:notes:206]
Impact on Consolidated Financial Statements

[0001262039-19-000006:notes:207]
The following tables summarize the impact of adopting Topic 606 on our consolidated financial statements as of and for 2018 (in millions). These tables do not represent the full consolidated financial statements as they only reflect the accounts impacted by the adoption of Topic 606.

[0001262039-19-000006:notes:208]
Consolidated Balance Sheet

[0001262039-19-000006:notes:209]
|  | As of December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Assets: |  |  |  |  |  |
| Accounts receivable | $ | 444.5 |  |  | $ | 422.4 |  |  | $ | 22.1 |  |
| Prepaid and other current assets | 36.8 |  |  | 37.2 |  |  | (0.4 | ) |
| Inventory | 90.0 |  |  | 91.5 |  |  | (1.5 | ) |
| Deferred contract costs | 182.6 |  |  | — |  |  | 182.6 |  |
| Deferred tax assets | 255.0 |  |  | 279.6 |  |  | (24.6 | ) |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | 77.5 |  |  | 53.4 |  |  | 24.1 |  |
| Deferred revenue, current | 965.9 |  |  | 988.9 |  |  | (23.0 | ) |
| Deferred revenue, non-current | 720.9 |  |  | 723.4 |  |  | (2.5 | ) |
| Income taxes payable | 28.2 |  |  | 27.4 |  |  | 0.8 |  |
| Other liabilities, non-current | 13.0 |  |  | 4.1 |  |  | 8.9 |  |
| Stockholders’ Equity |  |  |  |  |  |
| Accumulated deficit | $ | (57.5 | ) |  | $ | (227.4 | ) |  | $ | 169.9 |  |

[0001262039-19-000006:notes:210]
Consolidated Statement of Income

[0001262039-19-000006:notes:211]
|  | Year Ended December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| REVENUE: |  |  |  |  |  |
| Product (1) | $ | 674.4 |  |  | $ | 654.9 |  |  | $ | 19.5 |  |
| Service | 1,126.8 |  |  | 1,126.9 |  |  | (0.1 | ) |
| Total revenue | 1,801.2 |  |  | 1,781.8 |  |  | 19.4 |  |
| COSTS OF REVENUE: |  |  |  |  |  |
| Product | 291.0 |  |  | 289.6 |  |  | 1.4 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Product | 383.4 |  |  | 365.3 |  |  | 18.1 |  |
| Service | 967.4 |  |  | 967.5 |  |  | (0.1 | ) |
| Total gross profit | 1,350.8 |  |  | 1,332.8 |  |  | 18.0 |  |
| OPERATING EXPENSES: |  |  |  |  |  |
| Sales and marketing expenses | 782.3 |  |  | 827.8 |  |  | (45.5 | ) |
| OPERATING INCOME | 231.0 |  |  | 167.5 |  |  | 63.5 |  |
| INCOME BEFORE INCOME TAXES | 250.9 |  |  | 187.4 |  |  | 63.5 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | (81.3 | ) |  | (92.2 | ) |  | 10.9 |  |
| NET INCOME | $ | 332.2 |  |  | $ | 279.6 |  |  | $ | 52.6 |  |
| Net income per share: |  |  |  |  |  |
| Basic | $ | 1.96 |  |  | $ | 1.65 |  |  | $ | 0.31 |  |
| Diluted | $ | 1.91 |  |  | $ | 1.61 |  |  | $ | 0.30 |  |

[0001262039-19-000006:notes:212]
(1) Product revenue during 2018 included a $19.5 million benefit from the adoption of Topic 606, which primarily related to the change in accounting treatment under Topic 606 for some of our software products such that revenue from these arrangements is now recognized upfront instead of ratably over the contracted service term, net of the lost opportunity to recognize revenue that had been deferred and was written off to equity on the date of adoption.

[0001262039-19-000006:notes:213]
Consolidated Statement of Cash Flows

[0001262039-19-000006:notes:214]
|  | Year Ended December 31, 2018 |
|  | As Reported |  | Balances Without Adoption of Topic 606 |  | Effect of ChangeIncrease (Decrease) |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income | $ | 332.2 |  |  | $ | 279.6 |  |  | $ | 52.6 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Amortization of deferred contract costs | 90.9 |  |  | — |  |  | 90.9 |  |
| Other | (0.9 | ) |  | 7.6 |  |  | (8.5 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Prepaid expenses and other current assets | 4.2 |  |  | 3.7 |  |  | 0.5 |  |
| Inventory | (33.4 | ) |  | (34.8 | ) |  | 1.4 |  |
| Deferred contract costs | (136.4 | ) |  | — |  |  | (136.4 | ) |
| Deferred tax assets | (127.8 | ) |  | (134.3 | ) |  | 6.5 |  |
| Accrued liabilities | 14.5 |  |  | 4.0 |  |  | 10.5 |  |
| Other liabilities | (0.8 | ) |  | (3.9 | ) |  | 3.1 |  |
| Deferred revenue | 352.1 |  |  | 373.5 |  |  | (21.4 | ) |
| Income taxes payable | (6.0 | ) |  | (6.8 | ) |  | 0.8 |  |
| Net cash provided by operating activities | $ | 638.9 |  |  | $ | 638.9 |  |  | $ | — |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-19-000006:notes:215]
Revenue by geographic region is based on the billing address of our distributors and direct customer. The following tables set forth revenue and property and equipment—net by geographic region (in millions):

[0001262039-19-000006:notes:216]
|  | Year Ended December 31, |
| Revenue | 2018 |  | 2017 |  | 2016 |
| Americas: |  |  |  |  |  |
| United States | $ | 577.2 |  |  | $ | 496.9 |  |  | $ | 426.4 |  |
| Latin America (“LATAM”) | 120.8 |  |  | 92.1 |  |  | 66.0 |  |
| Canada | 64.9 |  |  | 53.3 |  |  | 44.3 |  |
| Total Americas | 762.9 |  |  | 642.3 |  |  | 536.7 |  |
| Europe, Middle East and Africa (“EMEA”) | 678.0 |  |  | 554.6 |  |  | 477.4 |  |
| Asia Pacific (“APAC”) | 360.3 |  |  | 298.0 |  |  | 261.3 |  |
| Total revenue | $ | 1,801.2 |  |  | $ | 1,494.9 |  |  | $ | 1,275.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001262039-19-000006:notes:217]
Revenue Recognition—On January 1, 2018 we adopted Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606) (“Topic 606”) using the modified retrospective method applied to those contracts which were not completed as of January 1, 2018. Results for reporting periods beginning after January 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported under ASU 2009-13, Revenue Recognition (Topic 605) (“Topic 605”). The details of significant changes and quantitative impact of the changes are discussed below.

[0001262039-19-000006:notes:218]
Beginning in 2018, revenues are recognized when control of these goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. Prior to 2018, revenue was recognized under Topic 605 when all of the following criteria were met: (i) persuasive evidence of an arrangement existed, (ii) delivery has occurred or services have been rendered, (iii) sales price was fixed or determinable and (iv) collectability was reasonably assured.

[0001262039-19-000006:notes:219]
Under Topic 606, we determine revenue recognition through the following steps:

[0001262039-19-000006:notes:220]
•identification of a contract or contracts with a customer,

[0001262039-19-000006:notes:221]
| • | identification of the performance obligations in a contract, including evaluation of performance obligations and evaluating the distinct goods or services in a contract, |

[0001262039-19-000006:notes:222]
•determination of a transaction price,

[0001262039-19-000006:notes:223]
•allocation of a transaction price to the performance obligations in a contract, and

[0001262039-19-000006:notes:224]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0001262039-19-000006:notes:225]
We derive a majority of product sales from our FortiGate products. Our FortiGate products include a broad set of built-in security and networking features and functionalities including firewall, SD-WAN, data leak prevention, VPN, switch and wireless controller and WAN acceleration, among others.

[0001262039-19-000006:notes:226]
We previously recognized product revenue for sales to distributors that had no general right of return and direct sales to end-customers upon shipment, based on general revenue recognition accounting guidance once all other revenue recognition criteria were met. Certain distributors are granted stock rotation rights, limited rights of return or rebates for sales of our products. The arrangement fee for this group of distributors was not fixed or determinable when products were shipped and revenue was therefore deferred and recognized upon sell-through. Under Topic 606, we recognize product revenue upon shipment when control of the promised goods is transferred to the customer. We recognize revenue from term licenses upon electronic transfer of the license key to a customer. Previously, term licenses were recognized over the license period.

[0001262039-19-000006:notes:227]
Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services. Our typical subscription and contractual support term is one to three years, and to a lesser extent, five years. Our revenue recognition for service arrangements did not significantly change under Topic 606. We continue to recognize revenue from these services ratably over the contractual service period because of continuous transfer of control to the customer over the support period. Revenue related to subsequent renewals of these services are recognized over the support term of the renewal agreement. We also generate a small portion of our revenue from other services consisting of professional services, training and software-as-a-service (“SaaS”) which is either hosted or cloud-based services. We recognize revenue from professional and training services as the services are provided. We recognize revenue from SaaS as the subscription service is delivered over the term, which is typically one year, or on a monthly usage basis. To date, SaaS revenue has not represented a significant percentage of our total revenue.

[0001262039-19-000006:notes:228]
Our sales contracts typically contain multiple deliverables, such as hardware, software license, security subscription, technical support services and other services, which are generally capable of being distinct and accounted for as separate performance obligations. We evaluated the criteria to be distinct under Topic 606 and concluded that the hardware and software license were distinct and distinct in the context of the contract from the security subscription and technical support services, as the customer can benefit from the hardware and license without the services and the services are separately identifiable within the contract. We allocate the transaction price to each performance obligation based on relative standalone selling price. We determine standalone selling price based on the historical pricing and discounting practices for those services when sold separately. We determine standalone selling price for a product or service by considering multiple historical factors including, but not limited to, cost of products, gross margin objectives, pricing practices, geographies and the term of the service contract that fall within a reasonably range as a percentage of list price. Revenue is reported net of sales tax.

[0001262039-19-000006:notes:229]
Under Topic 605, revenue from contracts that contain our products and services were allocated to each unit of accounting based on an estimated selling price using vendor-specific objective evidence (“VSOE”) of selling price, if it existed, or third-party evidence (“TPE”) of selling price. If neither VSOE nor TPE of selling price existed for a deliverable, we used our best estimate of selling price for that deliverable. For multiple-element arrangements where software deliverables were included, revenue was allocated to the non-software deliverables and to the software deliverables as a group using the relative estimated selling prices of each of the deliverables in the arrangement based on the estimated selling price hierarchy. The amount allocated to the software deliverables was then allocated to each software deliverable using the residual method when VSOE of fair value existed. If evidence of VSOE of fair value of one or more undelivered elements did not exist, all software allocated revenue was deferred and recognized when delivery of those elements occurred or when fair value was established. When the undelivered element for which we did not have VSOE of fair value was support, revenue for the entire arrangement was recognized ratably over the support period. The same residual method and VSOE of fair value principles applied for our multiple element arrangements that contained only software elements.

[0001262039-19-000006:notes:230]
In certain circumstances, our contracts include provisions for sales rebates and other customer incentive programs. Additionally, in limited circumstances, we may permit end-customers, distributors and resellers to return our products, subject to varying limitations, for a refund within a reasonably short period from the date of purchase. These amounts are accounted for as variable consideration that can decrease the transaction price. We estimate variable consideration at the most likely amounts to which we expect our customers to be entitled. We include estimated amounts in the transaction price to the extent that it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimate for sales return reserve was $20.8 million as of December 31, 2018 and is included in current liabilities in our consolidated balance sheet. Under Topic 605, the sales return reserve of $13.6 million was presented as a reduction to accounts receivable as of December 31, 2017.

[0001262039-19-000006:notes:231]
We generally invoice at the time of our sale for the total price of the hardware, software licenses, security and technical support and other services, and the invoice is payable within 30 to 45 days. We also invoice certain services on a monthly basis. Amounts billed and due from our customers are classified as receivables on the balance sheet and do not bear interest. Our deferred revenue primarily consists of amounts that have been invoiced but have not been recognized as revenue as of period end.

[0001262039-19-000006:notes:232]
Shipping and handling fees charged to our customers are recognized as revenue in the period shipped and the related costs for providing these services are recorded in cost of revenue. Shipping and handling fees recognized were not significant during 2018 and 2017.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001262039-19-000006:notes:233]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0001262039-19-000006:notes:234]
|  | Year Ended December 31, |
|  | 2018 (1) |  | 2017 |  | 2016 |
|  | (in millions) |
| Sales Returns Reserve and Allowance for Doubtful Accounts: |  |  |  |  |  |
| Beginning balance | $ | 14.5 |  |  | $ | 11.2 |  |  | $ | 6.2 |  |
| Charged to costs and expenses, net of deductions | — |  |  | 3.3 |  |  | 5.0 |  |
| Reclassification due to adoption of Topic 606 (1) | (13.6 | ) |  | — |  |  | — |  |
| Ending balance | $ | 0.9 |  |  | $ | 14.5 |  |  | $ | 11.2 |  |
| (1) Effective January 1, 2018, we reclassified our sales returns reserve in the amount of $13.6 million from accounts receivable to accrued liabilities, in connection with the adoption of Topic 606. The ending balance for the year ended December 31, 2018 consists only of the allowance for doubtful accounts. |

[0001262039-19-000006:notes:235]
Schedules not listed above have been omitted because they are not applicable or are not required or the information required to be set forth therein is included in the consolidated financial statements or notes thereto.

[0001262039-19-000006:notes:236]
| 3. | Exhibits: See Item 15(b) below. We have filed, or incorporated into this Annual Report on Form 10-K by reference, the exhibits listed on the accompanying Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K. |

[0001262039-19-000006:notes:237]
(b) Exhibits:

[0001262039-19-000006:notes:238]
The exhibit list in the Exhibit Index immediately preceding the signature page of this Annual Report on Form 10-K is incorporated herein by reference as the list of exhibits required by this Item 15(b).

[0001262039-19-000006:notes:239]
(c) Financial Statement Schedules: See Item 15(a) above.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-19-000006:notes:240]
SEGMENT INFORMATION

[0001262039-19-000006:notes:241]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. Our chief operating decision maker is our chief executive officer. Our chief executive officer reviews financial information presented on a consolidated basis, accompanied by information about revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one business activity, and there are no segment managers who are held accountable for operations, operating results and plans for levels or components below the consolidated unit level. Accordingly, we have determined that we have one operating segment, and therefore, one reportable segment.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-19-000006:notes:242]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001262039-19-000006:notes:243]
Business—Fortinet, Inc. (“Fortinet”) was incorporated in Delaware in November 2000 and is a global leader in broad, integrated and automated cybersecurity solutions. Fortinet provides high performance cybersecurity solutions to a wide variety of businesses, such as enterprises, communication service providers and small businesses. Fortinet’s cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface, through our integrated Security Fabric Platform with automated protection, detection and responses.

[0001262039-19-000006:notes:244]
Use of Estimates—The preparation of consolidated financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Such management estimates include, but are not limited to, the standalone selling price for each distinct performance obligation included in customer contracts with multiple performance obligations, the period of benefit for deferred contract costs for commissions, stock-based compensation, inventory valuation, fair value of assets acquired and liabilities assumed in business combinations, measurement of liabilities for uncertain tax positions and deferred tax assets and liabilities, assessment of recoverability of our goodwill and other long-lived assets, sales returns reserve and contingent liabilities. We base our estimates on historical experience and also on assumptions that we believe are reasonable. Actual results could differ from those estimates.

[0001262039-19-000006:notes:245]
Our accounts receivables are primarily derived from our channel partners in various geographic locations. We perform ongoing credit evaluations of our customers. We generally do not require collateral on accounts receivable, and we maintain reserves for estimated potential credit losses. In July 2017, Exclusive Networks Group (“Exclusive”), which distributes our solutions to a large group of resellers and end-customers, acquired the U.S. division of Fine Tec Computers (“Fine Tec U.S.”). Fine Tec U.S.’s revenue and accounts receivable have been combined with Exclusive’s from the date of acquisition. As of December 31, 2018 and 2017 Exclusive accounted for 38% and 35% of total net accounts receivable, respectively.

[0001262039-19-000006:notes:246]
During 2018, Exclusive and Ingram Micro Inc. accounted for 30% and 10% of total revenue, respectively. During 2017 and 2016, Exclusive accounted for 25% and 20% of total revenue, respectively.

[0001262039-19-000006:notes:247]
Financial Instruments and Fair Value—We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. Due to their short-term nature, the carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and accrued payroll and compensation.

[0001262039-19-000006:notes:248]
Foreign Currency and Transaction Gains and Losses—The functional currency of our foreign subsidiaries is the U.S. dollar. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet dates. Foreign currency denominated income and expenses have been remeasured using the exchange rates in effect during each period. Foreign currency remeasurement gains (losses) of $(8.2) million, $1.0 million and $(6.6) million are included in other income (expense)—net for 2018, 2017 and 2016, respectively.

[0001262039-19-000006:notes:249]
Other Investments—Investments in privately held companies where we own less than 20% of the voting stock and have no indicators of significant influence over operating and financial policies of those companies are included in other assets in the consolidated balance sheets. As of December 31, 2017, these investments were accounted for under the cost method. As of December 31, 2018, with the adoption of the ASU 2016-01—Financial Instruments—Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, these investments are accounted for at cost, adjusted for changes in observable prices minus impairment. Adoption of ASU 2016-01 did not have an impact on our consolidated financial statements. For these non-quoted investments, we regularly review the assumptions underlying the operating performance and cash flow forecasts as well as current fundraising activities and valuations based on information provided by these privately held companies. If it is determined that an other-than-temporary decline or increase in value exists in an investment without readily determinable value, we adjust the value of the investment to its fair value and record the related impairment or increase in value as an investment loss or gain in our consolidated statements of income.

[0001262039-19-000006:notes:250]
Business Combinations—We include the results of operations of the businesses that we acquire as of the respective dates of acquisition. We allocate the fair value of the purchase price of our business acquisitions to the tangible and intangible assets acquired and liabilities assumed, based on their estimated fair values. The excess of the purchase price over the fair values of these identifiable assets and liabilities is recorded as goodwill. We often continue to gather additional information throughout the measurement period, and if we make changes to the amounts recorded, such amounts are recorded in the period in which they are identified.

[0001262039-19-000006:notes:251]
Goodwill—Goodwill represents the excess of purchase consideration over the estimated fair value of net assets of businesses acquired in a business combination. Goodwill acquired in a business combination is not amortized, but instead tested for impairment at least annually during the fourth quarter, or sooner when circumstances indicate an impairment may exist. We perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. Then we perform a quantitative impairment test by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001262039-19-000006:notes:252]
We performed our annual goodwill impairment analysis and did not identify any impairment indicators as a result of the review. As of December 31, 2018, we had one reporting unit.

[0001262039-19-000006:notes:253]
Other Intangible Assets—Intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed using the straight-line or accelerated method over the estimated economic lives of the assets, which range from three to five years.

[0001262039-19-000006:notes:254]
Deferred Revenue—Deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of deferred revenue is comprised of security subscription and technical support services which are invoiced upfront and delivered over 12 months or longer.

[0001262039-19-000006:notes:255]
Stock-Based Compensation—The fair value of restricted stock units (“RSUs”) is based on the closing market price of our common stock on the date of grant. We have elected to use the Black-Scholes-Merton (“Black-Scholes”) pricing model to determine the fair value of our employee stock options and our equity incentive plans. Stock-based compensation expense is amortized on a straight-line basis over the service period.

[0001262039-19-000006:notes:256]
Advertising Expense—Advertising costs are expensed when incurred and are included in operating expenses in the accompanying consolidated statements of income. Our advertising expenses were not significant for any periods presented.

[0001262039-19-000006:notes:257]
Research and Development Costs—Research and development costs are expensed as incurred.

[0001262039-19-000006:notes:258]
Deferred Contract Costs and Commission Expense—In 2017, we recognized commission expense on both product sales and service contracts at the time of sale. Beginning on January 1, 2018, we recognize sales commissions related to product sales upfront while sales commissions for service contracts are deferred as Deferred contract costs in the consolidated balance sheets and amortized over the applicable amortization period. Costs for initial contracts that are not commensurate with renewal commissions are amortized on a straight-line basis over the period of benefit, which we have determined to be five years and which is typically longer than the initial contract term.

[0001262039-19-000006:notes:259]
Software Development Costs—The costs to develop software that is marketed have not been capitalized as we believe our current software development process is essentially completed concurrently with the establishment of technological feasibility. Such costs are expensed as incurred and included in research and development in our consolidated statements of income.

[0001262039-19-000006:notes:260]
The costs to obtain or develop software for internal use are capitalized based on qualifying criteria, which includes a determination of whether such costs are incurred during the application development stage. Such costs are amortized over the software’s estimated useful life.

[0001262039-19-000006:notes:261]
Warranties—We generally provide a one-year warranty on most hardware products and a 90-day warranty on software. We also provide extended warranties under the terms of our support agreements. A provision for estimated future costs related to warranty activities in the first year after product sale is recorded as a component of cost of product revenues when the product revenue is recognized, based upon historical product failure rates and historical costs incurred in correcting product failures. Warranty costs related to extended warranties sold under support agreements are recognized as cost of service revenue. In the event we change our warranty reserve estimates, the resulting charge against future cost of revenue or reversal of previously recorded charges may materially affect our gross margins and operating results. Accrued warranty was not significant as of December 31, 2018 and 2017.


## us-gaap:SubsequentEventsTextBlock

[0001262039-19-000006:notes:262]
SUBSEQUENT EVENTS

[0001262039-19-000006:notes:263]
Subsequent to December 31, 2018, through the filing of this Annual Report on Form 10-K, we repurchased 0.8 million shares of our common stock, for an aggregate purchase price of $56.3 million at an average price of $72.19 per share, under the Repurchase Program.

[0001262039-19-000006:notes:264]
2011 Employee Stock Purchase Plan

[0001262039-19-000006:notes:265]
Our board of directors voluntarily determined to terminate the ESPP, effective February 2019 at the completion of the prior offering period.
