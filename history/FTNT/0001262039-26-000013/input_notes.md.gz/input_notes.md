# FTNT notes — 0001262039-26-000013


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-26-000013:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2025, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2026. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2026 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2025 is derived from the audited consolidated financial statements for the year ended December 31, 2025.

[0001262039-26-000013:notes:2]
The condensed consolidated financial statements include the accounts of Fortinet, Inc. and its subsidiaries. As of March 31, 2026, the functional currency of our foreign subsidiaries is the U.S. dollar. Effective January 1, 2026, the Company transitioned the functional currency of one of its subsidiaries to the U.S. dollar following its full operational integration. We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany balances and transactions have been eliminated in consolidation.

[0001262039-26-000013:notes:3]
[same as prior period, unchanged from 0001262039-25-000039:notes:4]

[0001262039-26-000013:notes:4]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2026, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2025 filed with the SEC.

[0001262039-26-000013:notes:5]
Recent Adopted Accounting Standards

[0001262039-26-000013:notes:6]
[same as prior period, unchanged from 0001262039-25-000039:notes:11]

[0001262039-26-000013:notes:7]
In July 2025, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting periods beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We adopted ASU 2025-05 on January 1, 2026 and the adoption of this standard did not have a material impact on our condensed consolidated financial statements.

[0001262039-26-000013:notes:8]
[same as prior period, unchanged from 0001262039-25-000039:notes:6]

[0001262039-26-000013:notes:9]
Expense Disaggregation Disclosures

[0001262039-26-000013:notes:10]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting periods beginning fiscal year 2027 and our interim reporting periods beginning in fiscal year 2028, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

[0001262039-26-000013:notes:11]
[same as prior period, unchanged from 0001262039-25-000039:notes:13]

[0001262039-26-000013:notes:12]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual periods beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-26-000013:notes:13]
[same as prior period, unchanged from 0001262039-25-000039:notes:15]

[0001262039-26-000013:notes:14]
[same as prior period, unchanged from 0001262039-25-000039:notes:16]

[0001262039-26-000013:notes:15]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Product | $ | 645.1 |  |  | $ | 459.1 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 694.0 |  |  | 623.1 |  |  |  |  |  |
| Technical support and other | 510.5 |  |  | 457.5 |  |  |  |  |  |
| Total service revenue | 1,204.5 |  |  | 1,080.6 |  |  |  |  |  |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |  |  |  |  |

[0001262039-26-000013:notes:16]
[same as prior period, unchanged from 0001262039-25-000039:notes:18]

[0001262039-26-000013:notes:17]
During the three months ended March 31, 2026 and 2025, we recognized $1.09 billion and $972.5 million in revenue that was included in the deferred revenue balance as of December 31, 2025 and 2024, respectively.

[0001262039-26-000013:notes:18]
[same as prior period, unchanged from 0001262039-25-000039:notes:20]

[0001262039-26-000013:notes:19]
As of March 31, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations was $7.45 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.76 billion as revenue over the next 12 months, $2.94 billion in years two and three, and the remainder thereafter.

[0001262039-26-000013:notes:20]
[same as prior period, unchanged from 0001262039-25-000039:notes:22]

[0001262039-26-000013:notes:21]
Amortization of deferred contract costs, primarily consisting of sales commissions earned by our sales force, was $94.2 million and $78.0 million during the three months ended March 31, 2026 and 2025, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-26-000013:notes:22]
[same as prior period, unchanged from 0001262039-25-000039:notes:25]

[0001262039-26-000013:notes:23]
[same as prior period, unchanged from 0001262039-25-000039:notes:26]

[0001262039-26-000013:notes:24]
|  | March 31, 2026 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 544.4 |  |  | $ | 0.2 |  |  | $ | (0.5) |  |  | $ | 544.1 |  |
| Corporate debt securities | 443.9 |  |  | — |  |  | (1.0) |  |  | 442.9 |  |
| Commercial paper | 289.4 |  |  | — |  |  | (0.1) |  |  | 289.3 |  |
| Certificates of deposit and term deposits | 105.1 |  |  | — |  |  | (0.1) |  |  | 105.0 |  |
| Total available-for-sale investments | 1,382.8 |  |  | 0.2 |  |  | (1.7) |  |  | 1,381.3 |  |
| Marketable equity securities |  |  |  |  |  |  | 29.5 |  |
| Total short-term and long-term investments | $ | 1,382.8 |  |  | $ | 0.2 |  |  | $ | (1.7) |  |  | $ | 1,410.8 |  |

[0001262039-26-000013:notes:25]
|  | December 31, 2025 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| U.S. government and agency securities | $ | 513.7 |  |  | $ | 0.9 |  |  | $ | — |  |  | $ | 514.6 |  |
| Corporate debt securities | 368.5 |  |  | 0.4 |  |  | (0.1) |  |  | 368.8 |  |
| Commercial paper | 354.8 |  |  | 0.1 |  |  | — |  |  | 354.9 |  |
| Certificates of deposit and term deposits | 90.3 |  |  | 0.1 |  |  | — |  |  | 90.4 |  |
| Total available-for-sale investments | 1,327.3 |  |  | 1.5 |  |  | (0.1) |  |  | 1,328.7 |  |
| Marketable equity securities |  |  |  |  |  |  | 98.2 |  |
| Total short-term and long-term investments | $ | 1,327.3 |  |  | $ | 1.5 |  |  | $ | (0.1) |  |  | $ | 1,426.9 |  |

[0001262039-26-000013:notes:26]
[same as prior period, unchanged from 0001262039-25-000039:notes:29]

[0001262039-26-000013:notes:27]
|  | March 31, 2026 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 544.1 |  |  | $ | (0.5) |  |  | $ | — |  |  | $ | — |  |  | $ | 544.1 |  |  | $ | (0.5) |  |
| Corporate debt securities | 442.9 |  |  | (1.0) |  |  | — |  |  | — |  |  | 442.9 |  |  | (1.0) |  |
| Commercial paper | 289.3 |  |  | (0.1) |  |  | — |  |  | — |  |  | 289.3 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 105.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 105.0 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 1,381.3 |  |  | $ | (1.7) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,381.3 |  |  | $ | (1.7) |  |

[0001262039-26-000013:notes:28]
|  | December 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 514.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 514.5 |  |  | $ | — |  |
| Corporate debt securities | 368.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | 368.9 |  |  | (0.1) |  |
| Commercial paper | 354.9 |  |  | — |  |  | — |  |  | — |  |  | 354.9 |  |  | — |  |
| Certificates of deposit and term deposits | 90.4 |  |  | — |  |  | — |  |  | — |  |  | 90.4 |  |  | — |  |
| Total available-for-sale investments | $ | 1,328.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,328.7 |  |  | $ | (0.1) |  |

[0001262039-26-000013:notes:29]
[same as prior period, unchanged from 0001262039-25-000039:notes:32]

[0001262039-26-000013:notes:30]
|  | March 31,2026 |  | December 31,2025 |
| Due within one year | $ | 1,041.6 |  |  | $ | 989.0 |  |
| Due within one to three years | 339.7 |  |  | 339.7 |  |
| Total | $ | 1,381.3 |  |  | $ | 1,328.7 |  |

[0001262039-26-000013:notes:31]
[same as prior period, unchanged from 0001262039-25-000039:notes:34]

[0001262039-26-000013:notes:32]
Realized gains and losses on available-for-sale investments were not material in the periods presented.

[0001262039-26-000013:notes:33]
Gains and losses on our marketable equity securities are recorded in other income—net on the condensed consolidated statements of income. During the three months ended March 31, 2026, we sold certain marketable equity securities for net proceeds of $115.9 million, for which we recognized net gains of $50.7 million during the period. We had no sales of marketable equity securities during the three months ended March 31, 2025. During the three months ended March 31, 2026 and 2025, we recognized a $3.6 million and $14.7 million unrealized loss, respectively, related to the changes in the fair value of our marketable equity securities still held at the reporting date.

[0001262039-26-000013:notes:34]
[same as prior period, unchanged from 0001262039-25-000039:notes:37]

[0001262039-26-000013:notes:35]
[same as prior period, unchanged from 0001262039-25-000039:notes:38]

[0001262039-26-000013:notes:36]
|  | March 31, 2026 |  | December 31, 2025 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 239.8 |  |  | $ | 239.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 174.4 |  |  | $ | 174.4 |  |  | $ | — |  |  | $ | — |  |
| U.S. government and agency securities | 24.0 |  |  | 24.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | 2.7 |  |  | — |  |  | 2.7 |  |  | — |  |  | 1.1 |  |  | — |  |  | 1.1 |  |  | — |  |
| Commercial paper | 21.9 |  |  | — |  |  | 21.9 |  |  | — |  |  | 38.1 |  |  | — |  |  | 38.1 |  |  | — |  |
| Total cash equivalents | 288.4 |  |  | 263.8 |  |  | 24.6 |  |  | — |  |  | 213.6 |  |  | 174.4 |  |  | 39.2 |  |  | — |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 427.9 |  |  | 427.9 |  |  | — |  |  | — |  |  | 383.5 |  |  | 381.5 |  |  | 2.0 |  |  | — |  |
| Corporate debt securities | 219.4 |  |  | — |  |  | 219.4 |  |  | — |  |  | 160.2 |  |  | — |  |  | 160.2 |  |  | — |  |
| Commercial paper | 289.3 |  |  | — |  |  | 289.3 |  |  | — |  |  | 354.9 |  |  | — |  |  | 354.9 |  |  | — |  |
| Certificates of deposit and term deposits | 105.0 |  |  | — |  |  | 105.0 |  |  | — |  |  | 90.4 |  |  | — |  |  | 90.4 |  |  | — |  |
| Marketable equity securities | 29.5 |  |  | 29.5 |  |  | — |  |  | — |  |  | 98.2 |  |  | 98.2 |  |  | — |  |  | — |  |
| Total short-term investments | 1,071.1 |  |  | 457.4 |  |  | 613.7 |  |  | — |  |  | 1,087.2 |  |  | 479.7 |  |  | 607.5 |  |  | — |  |
| Long-term investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agency securities | 116.2 |  |  | 103.7 |  |  | 12.5 |  |  | — |  |  | 131.1 |  |  | 121.8 |  |  | 9.3 |  |  | — |  |
| Corporate debt securities | 223.5 |  |  | — |  |  | 223.5 |  |  | — |  |  | 208.6 |  |  | — |  |  | 208.6 |  |  | — |  |
| Total long-term investments | 339.7 |  |  | 103.7 |  |  | 236.0 |  |  | — |  |  | 339.7 |  |  | 121.8 |  |  | 217.9 |  |  | — |  |
| Total | $ | 1,699.2 |  |  | $ | 824.9 |  |  | $ | 874.3 |  |  | $ | — |  |  | $ | 1,640.5 |  |  | $ | 775.9 |  |  | $ | 864.6 |  |  | $ | — |  |

[0001262039-26-000013:notes:37]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2026 and year ended December 31, 2025.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-26-000013:notes:38]
[same as prior period, unchanged from 0001262039-25-000039:notes:41]

[0001262039-26-000013:notes:39]
|  | March 31,2026 |  | December 31,2025 |
| Raw materials | $ | 62.6 |  |  | $ | 61.9 |  |
| Work in process | 1.9 |  |  | 3.0 |  |
| Finished goods | 305.1 |  |  | 334.6 |  |
| Inventory | $ | 369.6 |  |  | $ | 399.5 |  |

[0001262039-26-000013:notes:40]
The excess and obsolete inventory reserve was $125.3 million and $137.5 million as of March 31, 2026 and December 31, 2025, respectively. Inventory write-downs related to excess and obsolete inventory were immaterial during the

[0001262039-26-000013:notes:41]
three months ended March 31, 2026 and 2025, respectively. These were recorded in cost of product revenue on the condensed consolidated statements of income.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-26-000013:notes:42]
[same as prior period, unchanged from 0001262039-25-000039:notes:45]

[0001262039-26-000013:notes:43]
|  | March 31,2026 |  | December 31,2025 |
| Land | $ | 636.3 |  |  | $ | 592.4 |  |
| Buildings and improvements | 980.8 |  |  | 974.0 |  |
| Computer equipment and software | 374.5 |  |  | 341.0 |  |
| Leasehold improvements | 58.3 |  |  | 58.5 |  |
| Evaluation units | 22.0 |  |  | 24.1 |  |
| Furniture and fixtures | 38.0 |  |  | 36.3 |  |
| Construction-in-progress | 84.7 |  |  | 74.6 |  |
| Total property and equipment | 2,194.6 |  |  | 2,100.9 |  |
| Less: accumulated depreciation | (503.1) |  |  | (481.9) |  |
| Property and equipment—net | $ | 1,691.5 |  |  | $ | 1,619.0 |  |

[0001262039-26-000013:notes:44]
During the three months ended March 31, 2026, we purchased certain real estate property in the United States totaling $47.1 million, to be used for future development to expand our data center and office space. The purchase was accounted for under the asset acquisition method, with $45.1 million allocated to land and $2.0 million allocated to buildings and improvements, based on their relative fair values.
Depreciation expense was $29.5 million and $24.0 million during the three months ended March 31, 2026 and 2025, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-26-000013:notes:45]
[same as prior period, unchanged from 0001262039-25-000039:notes:51]

[0001262039-26-000013:notes:46]
[same as prior period, unchanged from 0001262039-25-000039:notes:52]

[0001262039-26-000013:notes:47]
[same as prior period, unchanged from 0001262039-25-000039:notes:53]

[0001262039-26-000013:notes:48]
This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the aggregate purchase price, $17.5 million was allocated to identifiable intangible assets acquired, and $64.7 million was allocated to other net assets acquired which predominantly included deferred tax asset of $45.8 million, inventory of $21.4 million, and cash of $8.8 million, offset by $11.3 million of net other assets and liabilities assumed. The excess of the fair values of the net assets acquired over the net purchase consideration was recorded as a gain on bargain purchase of $39.9 million within other income—net on the condensed consolidated statements of income. The gain on bargain purchase occurred primarily due to the recognition of the deferred tax assets, which were comprised primarily of pre-acquisition federal net operating loss carryforwards with an indefinite carryforward period. In addition, we had previously recorded a deferred tax asset of $30.6 million for an outside basis difference in our investment in Linksys when it was accounted for under the equity method. As a result of the acquisition of the remaining shares, we now account for our investment in Linksys under the consolidation method, and therefore we have derecognized this deferred tax asset. The charge is included in the provision for income taxes on the condensed consolidated statements of income. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expenses.

[0001262039-26-000013:notes:49]
Other Acquisitions

[0001262039-26-000013:notes:50]
In 2025, we completed other acquisitions for total purchase consideration of $38.3 million in cash. We have accounted for the transactions as business combinations and recorded goodwill of $21.9 million, among which $8.6 million of goodwill is expected to be deductible and $13.3 million of goodwill is not deductible for income tax purposes. Acquisition-related costs were not material and were recorded as general and administrative expenses.

[0001262039-26-000013:notes:51]
[same as prior period, unchanged from 0001262039-25-000039:notes:69]

[0001262039-26-000013:notes:52]
The operating results of the acquired companies are included in our condensed consolidated statements of income from the respective dates of acquisition. Acquisition-related costs related to each acquisition were not material. The operating results of the acquired companies were not material in the period presented. Pro forma information has not been presented, as the impact of these acquisitions, individually and in the aggregate, in each period were not material to our condensed consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-26-000013:notes:53]
[same as prior period, unchanged from 0001262039-25-000039:notes:71]

[0001262039-26-000013:notes:54]
As of March 31, 2026 and December 31, 2025, we had goodwill of $257.4 million. There were no impairments to goodwill during the three months ended March 31, 2026 or during prior periods.

[0001262039-26-000013:notes:55]
[same as prior period, unchanged from 0001262039-25-000039:notes:75]

[0001262039-26-000013:notes:56]
[same as prior period, unchanged from 0001262039-25-000039:notes:76]

[0001262039-26-000013:notes:57]
|  | March 31, 2026 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 159.1 |  |  | $ | 101.0 |  |  | $ | 58.1 |  |
| Customer relationships | 5.3 |  | 66.9 |  |  | 45.6 |  |  | 21.3 |  |
| Trade names | 4.2 |  | 11.3 |  |  | 6.7 |  |  | 4.6 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 10.5 |  |  | 3.0 |  |
| Total other intangible assets—net |  |  | $ | 250.8 |  |  | $ | 163.8 |  |  | $ | 87.0 |  |

[0001262039-26-000013:notes:58]
|  | December 31, 2025 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.3 |  | $ | 159.1 |  |  | $ | 96.0 |  |  | $ | 63.1 |  |
| Customer relationships | 5.3 |  | 66.9 |  |  | 42.4 |  |  | 24.5 |  |
| Trade names | 4.2 |  | 11.3 |  |  | 5.4 |  |  | 5.9 |  |
| Backlog | 2.5 |  | 13.5 |  |  | 9.7 |  |  | 3.8 |  |
| Total other intangible assets—net |  |  | $ | 250.8 |  |  | $ | 153.5 |  |  | $ | 97.3 |  |

[0001262039-26-000013:notes:59]
Amortization expense was $10.3 million and $11.8 million during the three months ended March 31, 2026 and 2025, respectively.

[0001262039-26-000013:notes:60]
[same as prior period, unchanged from 0001262039-25-000039:notes:80]

[0001262039-26-000013:notes:61]
|  | Amount |
| Years: |  |
| 2026 (the remainder of 2026) | $ | 26.9 |  |
| 2027 | 27.5 |  |
| 2028 | 20.0 |  |
| 2029 | 9.3 |  |
| 2030 | 1.0 |  |
| Thereafter | 2.3 |  |
| Total | $ | 87.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-26-000013:notes:62]
[same as prior period, unchanged from 0001262039-25-000039:notes:82]

[0001262039-26-000013:notes:63]
[same as prior period, unchanged from 0001262039-25-000039:notes:83]

[0001262039-26-000013:notes:64]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 534.5 |  |  | $ | 433.4 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 738.8 |  |  | 768.3 |  |  |  |  |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 738.8 |  |  | 768.3 |  |  |  |  |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 1.2 |  |  | 3.3 |  |  |  |  |  |
| Stock options | 2.5 |  |  | 4.6 |  |  |  |  |  |
| PSUs | 0.3 |  |  | 0.6 |  |  |  |  |  |
| Weighted-average shares used to compute diluted net income per share | 742.8 |  |  | 776.8 |  |  |  |  |  |
| Net income per share |  |  |  |  |  |  |  |
| Basic | $ | 0.72 |  |  | $ | 0.56 |  |  |  |  |  |
| Diluted | $ | 0.72 |  |  | $ | 0.56 |  |  |  |  |  |

[0001262039-26-000013:notes:65]
[same as prior period, unchanged from 0001262039-25-000039:notes:85]

[0001262039-26-000013:notes:66]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| RSUs | 2.3 |  |  | 0.8 |  |  |  |  |  |
| Stock options | 1.3 |  |  | 0.4 |  |  |  |  |  |
| PSUs | 0.1 |  |  | — |  |  |  |  |  |
| Total | 3.7 |  |  | 1.2 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001262039-26-000013:notes:67]
DEBT
2026 and 2031 Senior Notes

[0001262039-26-000013:notes:68]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations.

[0001262039-26-000013:notes:69]
Upon maturity on March 15, 2026, we repaid the full $500.0 million aggregate principal amount of the 2026 Senior Notes.

[0001262039-26-000013:notes:70]
We may redeem the 2031 Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The Senior Notes were recorded net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-26-000013:notes:71]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-26-000013:notes:72]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2026 |  | December 31,2025 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | — |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 500.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 3.2 |  |  | 3.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  | 499.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.8 |  |  | $ | 496.6 |  |

[0001262039-26-000013:notes:73]
As of March 31, 2026 and December 31, 2025, we accrued interest payable of $0.5 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2026 and 2025, we recorded $4.2 million and $4.5 million of total interest expense in relation to these Senior Notes in each period, respectively. No interest costs were capitalized for the three months ended March 31, 2026 and 2025, as the costs that qualified for capitalization were not material.

[0001262039-26-000013:notes:74]
The total estimated fair value of the outstanding 2031 Senior Notes was approximately $445.2 million, including accrued and unpaid interest, as of March 31, 2026. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-26-000013:notes:75]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2026 (in millions):

[0001262039-26-000013:notes:76]
|  | Total |  | 2026 |  | Thereafter |
| Inventory purchase commitments | $ | 1,365.6 |  |  | $ | 1,297.6 |  |  | $ | 68.0 |  |

[0001262039-26-000013:notes:77]
Inventory Purchase Commitments—We purchase components of our inventory from certain suppliers and use several independent contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to reschedule and adjust our requirements based on our business needs prior to firm orders being placed.

[0001262039-26-000013:notes:78]
As of March 31, 2026, we had $1.37 billion of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2026 and December 31, 2025, the liability for these inventory purchase commitments was $27.2 million and $26.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was immaterial and a $4.5 million benefit during the three months ended March 31, 2026 and 2025, respectively.

[0001262039-26-000013:notes:79]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2026, we had $127.8 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

[0001262039-26-000013:notes:80]
As of March 31, 2026, we had $70.4 million in contractual commitments related to payments for operating leases.

[0001262039-26-000013:notes:81]
Litigation—We are subject to legal proceedings arising in the ordinary course of business. We record accruals for litigation contingencies when a loss is probable and reasonably estimable, based on management’s assessment of the expected outcome and currently available information. As of March 31, 2026 and December 31, 2025, litigation loss contingency accruals associated with outstanding matters were not material.

[0001262039-26-000013:notes:82]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 3:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. The court subsequently consolidated these actions under a new caption, In re Fortinet, Inc. Securities Litigation, Lead Case No. 3:25-cv-08037 (the “Consolidated Securities Class Action”), and appointed a lead plaintiff and lead counsel. A consolidated amended complaint was filed on April 24, 2026, which asserts claims under Section 10(b), 20(a) and 20A of the Exchange Act against our chief executive officer, our chief technology officer, our current chief financial officer, and our former chief financial officer relating to the same events and circumstances alleged in the initial complaints, and adds a Section 10(b) claim against our head of investor relations. The Consolidated Securities Class Action seeks damages, attorneys fees and costs, and other relief that the court may deem appropriate. The time to respond to the consolidated amended complaint has not yet passed. We believe the Consolidated Securities Class Action is without merit and intend to defend the suit vigorously. Based on the preliminary nature of the proceedings in the Consolidated Securities Class Action, the outcome of that matter remains uncertain

[0001262039-26-000013:notes:83]
and we cannot estimate the potential impact, if any, on our business or financial statements at this time. Accordingly, no loss accrual was recorded as of March 31, 2026 related to this litigation.

[0001262039-26-000013:notes:84]
On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Pittrof v. Xie, et al., Case No. 3:2025-cv-08592 (“Pittrof”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for violations of Section 10(b) of the Exchange Act. On November 5, 2025, Plaintiff Michael J. Marrinan filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Marrinan v. Xie, et al., Case No. 3:25-cv-09546 (“Marrinan”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, gross mismanagement, waste of corporate assets, violations of California Corporations Code §§ 24400, 25500, et. seq., and violations of Section 10(b) of the Exchange Act. On November 6, 2025, Plaintiff Bryan Foster filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Foster v. Xie, et al., Case No. 3:25-cv-09611 (“Foster”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, for violations of Section 10(b), 14(a), and 20(a) of the Exchange Act, and for contribution under Section 21D of the Exchange Act. On December 2, 2025, Plaintiff LR Trust filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned LR Trust v. Xie, et al., Case No. 3:25-cv-10350 (“LR Trust,” together with Pittrof, Marrinan, and Foster, the “Derivative Actions”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, aiding and abetting, violations of Sections 10(b) and 14(a) of the Exchange Act, and for contribution under Section 21D of the Exchange Act. On behalf of the Company, the Derivative Actions seek damages, disgorgement, remedial actions, restitution, and attorneys’ fees and costs. The Derivative Actions have been consolidated under a new caption, In re Fortinet, Inc. Stockholder Derivative Litigation, Lead Case No. 3:2025-cv-08592 (the “Consolidated Derivative Action”). On April 2, 2026, the Court stayed all proceedings in the Consolidated Derivative Action pending the final resolution of the Consolidated Securities Class Action.

[0001262039-26-000013:notes:85]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of March 31, 2026 or December 31, 2025 related to this litigation.

[0001262039-26-000013:notes:86]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain Intellectual Property (“IP”) rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-26-000013:notes:87]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position, results of operations or cash flows.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-26-000013:notes:88]
[same as prior period, unchanged from 0001262039-25-000039:notes:106]

[0001262039-26-000013:notes:89]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs, stock options and PSUs. As of March 31, 2026, there were a total of 45.5 million shares of common stock available for grant under the Amended Plan.

[0001262039-26-000013:notes:90]
Restricted Stock Units and Market/Performance-Based PSUs

[0001262039-26-000013:notes:91]
[same as prior period, unchanged from 0001262039-25-000039:notes:109]

[0001262039-26-000013:notes:92]
|  | RSUs Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2025 | 7.6 |  |  | $ | 81.51 |  |
| Granted | 2.6 |  |  | 80.00 |  |
| Forfeited | (0.2) |  |  | 78.87 |  |
| Vested | (1.1) |  |  | 82.49 |  |
| Balance—March 31, 2026 | 8.9 |  |  | $ | 81.02 |  |

[0001262039-26-000013:notes:93]
We grant RSUs under the Amended Plan to employees and non-employees. Subject to certain exceptions, RSUs vest generally over four years subject to continued service.

[0001262039-26-000013:notes:94]
We grant market/performance-based PSUs under the Amended Plan to certain of our executives. Based on the achievement of the market/performance-based vesting conditions during the applicable performance period for such PSUs, the final settlement of the PSUs will range between 0% and 200% of the target shares underlying the PSUs based on the percentile ranking of our total stockholder return over one-, two-, three- and four-year periods among companies included in the S&P 500 Index. 20%, 20%, 20% and 40% of the PSUs vest over one-, two-, three- and four-year service periods, respectively.

[0001262039-26-000013:notes:95]
During each of the three months ended March 31, 2026 and 2025, we granted approximately 0.1 million shares of PSU awards to certain of our executives, with a weighted-average grant date fair value of $103.01 and $168.93 per share, respectively. The grant date fair value of these awards was determined using a Monte Carlo simulation pricing model. The following table summarizes the weighted-average assumptions relating to our PSUs:

[0001262039-26-000013:notes:96]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Expected term in years | 2.8 |  | 2.7 |  |  |  |  |
| Volatility | 42.4 | % |  | 41.5 | % |  |  |  |  |
| Risk-free interest rate | 3.5 | % |  | 4.2 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-26-000013:notes:97]
Approximately 0.1 million and 0.2 million shares of PSUs vested during the three months ended March 31, 2026 and 2025, respectively. Less than 0.1 million shares of PSUs were forfeited during the three months ended March 31, 2026 and none of the PSUs were forfeited during the three months ended March 31, 2025.

[0001262039-26-000013:notes:98]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU while compensation expense for PSUs is recognized on a graded vesting method. As of March 31, 2026, total compensation expense related to unvested RSUs and PSUs that were granted to employees, non-employees and certain executives, but not yet recognized, was $665.7 million, with a weighted-average vesting period of 2.9 years and $29.8 million, with a weighted-average vesting period of 2.3 years, respectively.

[0001262039-26-000013:notes:99]
[same as prior period, unchanged from 0001262039-25-000039:notes:117]

[0001262039-26-000013:notes:100]
[same as prior period, unchanged from 0001262039-25-000039:notes:118]

[0001262039-26-000013:notes:101]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Shares withheld for taxes | 0.4 |  |  | 0.5 |  |  |  |  |  |
| Amount withheld for taxes | $ | 36.5 |  |  | $ | 53.8 |  |  |  |  |  |

[0001262039-26-000013:notes:102]
[same as prior period, unchanged from 0001262039-25-000039:notes:120]

[0001262039-26-000013:notes:103]
[same as prior period, unchanged from 0001262039-25-000039:notes:121]

[0001262039-26-000013:notes:104]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Expected term in years | 4.6 |  | 4.5 |  |  |  |  |
| Volatility | 43.6 | % |  | 41.6 | % |  |  |  |  |
| Risk-free interest rate | 3.6 | % |  | 4.2 | % |  |  |  |  |
| Dividend rate | — | % |  | — | % |  |  |  |  |

[0001262039-26-000013:notes:105]
[same as prior period, unchanged from 0001262039-25-000039:notes:123]

[0001262039-26-000013:notes:106]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2025 | 7.4 |  |  | $ | 49.39 |  |  | 3.0 |  | $ | 241.7 |  |
| Granted | 0.6 |  |  | 80.00 |  |  |  |  |  |
| Forfeited | — |  |  | 90.29 |  |  |  |  |  |
| Exercised | (0.8) |  |  | 22.24 |  |  |  |  |  |
| Balance—March 31, 2026 | 7.2 |  |  | $ | 54.66 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2026 | 7.2 |  |  | $ | 54.66 |  |  | 3.3 |  | $ | 210.2 |  |
| Options exercisable—March 31, 2026 | 5.2 |  |  | $ | 44.89 |  |  | 2.4 |  | $ | 197.3 |  |

[0001262039-26-000013:notes:107]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock at the date of the balance sheet for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of March 31, 2026, total compensation expense related to unvested stock options granted to employees but not yet recognized was $61.6 million, with a weighted-average remaining vesting period of 2.9 years.

[0001262039-26-000013:notes:108]
[same as prior period, unchanged from 0001262039-25-000039:notes:126]

[0001262039-26-000013:notes:109]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Weighted-average fair value per share granted | $ | 32.91 |  |  | $ | 44.34 |  |  |  |  |  |
| Intrinsic value of options exercised | $ | 47.8 |  |  | $ | 102.3 |  |  |  |  |  |
| Fair value of options vested | $ | 10.9 |  |  | $ | 9.5 |  |  |  |  |  |

[0001262039-26-000013:notes:110]
[same as prior period, unchanged from 0001262039-25-000039:notes:128]

[0001262039-26-000013:notes:111]
[same as prior period, unchanged from 0001262039-25-000039:notes:129]

[0001262039-26-000013:notes:112]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Cost of product revenue | $ | 0.6 |  |  | $ | 0.5 |  |  |  |  |  |
| Cost of service revenue | 7.1 |  |  | 6.5 |  |  |  |  |  |
| Research and development | 25.1 |  |  | 23.0 |  |  |  |  |  |
| Sales and marketing | 31.9 |  |  | 26.5 |  |  |  |  |  |
| General and administrative | 8.5 |  |  | 10.4 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 73.2 |  |  | $ | 66.9 |  |  |  |  |  |

[0001262039-26-000013:notes:113]
[same as prior period, unchanged from 0001262039-25-000039:notes:131]

[0001262039-26-000013:notes:114]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| RSUs | $ | 63.1 |  |  | $ | 56.3 |  |  |  |  |  |
| Stock options | 6.6 |  |  | 6.6 |  |  |  |  |  |
| PSUs | 3.5 |  |  | 4.0 |  |  |  |  |  |
| Total stock-based compensation expense | $ | 73.2 |  |  | $ | 66.9 |  |  |  |  |  |

[0001262039-26-000013:notes:115]
[same as prior period, unchanged from 0001262039-25-000039:notes:133]

[0001262039-26-000013:notes:116]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 16.0 |  |  | $ | 14.7 |  |  |  |  |  |

[0001262039-26-000013:notes:117]
[same as prior period, unchanged from 0001262039-25-000039:notes:135]

[0001262039-26-000013:notes:118]
In January 2026, our board of directors approved a $1.0 billion increase in the authorized stock repurchase amount under the Repurchase Program, bringing the aggregate amount authorized for repurchases to $10.25 billion of our outstanding common stock through February 28, 2027. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.
During the three months ended March 31, 2026, we repurchased 10.6 million shares of our common stock under the Repurchase Program in open-market transactions, at a weighted-average price of $77.69 per share, for an aggregate purchase price of $826.9 million, which excludes a $7.0 million accrual related to the 1% excise tax imposed by the Inflation Reduction Act of 2022. As of March 31, 2026, approximately $911.7 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-26-000013:notes:119]
INCOME TAXES
Our effective tax rate was 19% for the three months ended March 31, 2026, compared to an effective tax rate of 19% for the same period last year. The tax rates for the three months ended March 31, 2026 and 2025 were comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $166.6 million and $128.5 million, respectively. The tax rate for the three months ended March 31, 2026 included a tax benefit of $35.2 million from the Foreign-Derived Deduction Eligible Income (“FDDEI”) deduction, and excess tax benefits from stock-based compensation expense of $9.4 million. The tax rate for the three months ended March 31, 2025 included a tax provision of $30.6 million related to the derecognition of deferred tax assets from the business combination with Linksys, a tax benefit of $25.8 million from the FDDEI deduction, and excess tax benefits from stock-based compensation expense of $36.8 million.

[0001262039-26-000013:notes:120]
On July 4, 2025, H.R. 1, an Act to Provide for Reconciliation Pursuant to Title II of House Concurrent Resolution 14 (the “Act”) commonly referred to as the One Big Beautiful Bill Act, was enacted. The Act makes permanent certain elements of the Tax Cuts and Jobs Act, including immediate expensing of U.S. research and development expenditures, immediate expensing of certain eligible assets, and various modifications to the international tax framework. The income tax effects of the Act have been recognized in our provision for income taxes as of March 31, 2026.

[0001262039-26-000013:notes:121]
As of March 31, 2026 and December 31, 2025, unrecognized tax benefits were $91.7 million and $90.4 million, respectively. If recognized, $74.9 million of the unrecognized tax benefits as of March 31, 2026 would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of March 31, 2026 and December 31, 2025, accrued interest and penalties were $13.3 million and $12.5 million, respectively.

[0001262039-26-000013:notes:122]
[same as prior period, unchanged from 0001262039-25-000039:notes:141]

[0001262039-26-000013:notes:123]
On January 4, 2022, the U.S. Treasury published another tranche of final regulations regarding the foreign tax credit. These final regulations impose new requirements that a foreign tax must meet in order to be creditable against U.S. income taxes, and generally apply to tax years beginning on or after December 28, 2021. On July 26, 2022, the U.S. Treasury released corrections to the final regulations. On July 21, 2023, the Internal Revenue Service (“IRS”) released a notice that suspended the application of significant portions of the final regulations regarding the foreign tax credit for tax years 2022 and 2023. The notice released in July 2023 favorably impacted our ability to claim foreign tax credits in the United States for certain taxes imposed by certain foreign jurisdictions. On December 11, 2023, the IRS released a notice that extended the suspension of significant portions of the final regulations beyond December 31, 2023, until further guidance is issued. 
In December 2021, the Organisation for Economic Co-operation and Development (the “OECD”) enacted model rules for a new global minimum tax framework (“BEPS Pillar Two”), and various governments around the world have enacted, or are in the process of enacting, legislation on this. In January 2026, the OECD released additional guidance related to the global minimum tax framework, including new safe harbors and potential exemptions for certain U.S.-based multinational companies, and continues to release additional guidance on these rules. Based on the enacted laws, BEPS Pillar Two has no impact to our effective tax rate or cash flows for the three months ended March 31, 2026. We will continue to evaluate the impact of these tax law changes on future reporting periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-26-000013:notes:124]
SEGMENT INFORMATION
Operating segments are determined based on the financial information that is regularly reviewed by the Chief Operating Decision Maker (“CODM”) to allocate resources and assess performance. The Company’s CODM is our Chief Executive Officer, who reviews financial information presented on a consolidated basis, accompanied by information about

[0001262039-26-000013:notes:125]
revenue by geographic region for purposes of allocating resources and evaluating financial performance. We have one operating and reportable segment.

[0001262039-26-000013:notes:126]
[same as prior period, unchanged from 0001262039-25-000039:notes:145]

[0001262039-26-000013:notes:127]
|  | Three Months Ended |  |  |
| March 31, 2026 |  | March 31, 2025 |  |  |  |  |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |
| Cost of product revenue | 208.3 |  |  | 149.9 |  |  |  |  |  |
| Cost of service revenue | 156.2 |  |  | 143.2 |  |  |  |  |  |
| Research and development expenses | 214.0 |  |  | 198.6 |  |  |  |  |  |
| Adjusted sales and marketing expenses (1) | 514.8 |  |  | 439.7 |  |  |  |  |  |
| Commission expense | 121.5 |  |  | 103.0 |  |  |  |  |  |
| General and administrative expenses | 56.2 |  |  | 57.8 |  |  |  |  |  |
| Provision for income taxes | 122.0 |  |  | 96.5 |  |  |  |  |  |
| Add: Other segment items (2) | 77.9 |  |  | 82.4 |  |  |  |  |  |
| Net income | $ | 534.5 |  |  | $ | 433.4 |  |  |  |  |  |

[0001262039-26-000013:notes:128]
[same as prior period, unchanged from 0001262039-25-000039:notes:147]

[0001262039-26-000013:notes:129]
(2) Includes gain on intellectual property matters, interest income, interest expense, other income—net and gain (loss) from equity method investments.

[0001262039-26-000013:notes:130]
[same as prior period, unchanged from 0001262039-25-000039:notes:152]

[0001262039-26-000013:notes:131]
|  | Three Months Ended |  |  |
| Revenue | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 526.5 |  |  | $ | 455.4 |  |  |  |  |  |
| Other Americas | 213.3 |  |  | 174.4 |  |  |  |  |  |
| Total Americas | 739.8 |  |  | 629.8 |  |  |  |  |  |
| Europe, Middle East and Africa (“EMEA”) | 784.8 |  |  | 628.4 |  |  |  |  |  |
| Asia Pacific (“APAC”) | 325.0 |  |  | 281.5 |  |  |  |  |  |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |  |  |  |  |

[0001262039-26-000013:notes:132]
| Property and Equipment—net | March 31,2026 |  | December 31,2025 |
| Americas: |  |  |  |
| United States | $ | 1,072.1 |  |  | $ | 1,000.8 |  |
| Canada | 330.9 |  |  | 329.2 |  |
| Latin America | 4.4 |  |  | 4.9 |  |
| Total Americas | 1,407.4 |  |  | 1,334.9 |  |
| EMEA | 211.4 |  |  | 211.3 |  |
| APAC | 72.7 |  |  | 72.8 |  |
| Total property and equipment—net | $ | 1,691.5 |  |  | $ | 1,619.0 |  |

[0001262039-26-000013:notes:133]
The following distributor customers accounted for 10% or more of our revenue:

[0001262039-26-000013:notes:134]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Distributor A | 28 | % |  | 28 | % |  |  |  |  |
| Distributor B | 15 | % |  | 14 | % |  |  |  |  |
| Distributor C | 12 | % |  | 12 | % |  |  |  |  |

[0001262039-26-000013:notes:135]
The following distributor customers accounted for 10% or more of net accounts receivable:

[0001262039-26-000013:notes:136]
|  | March 31,2026 |  | December 31, 2025 |
| Distributor A | 28 | % |  | 32 | % |
| Distributor B | 12 | % |  | 12 | % |
| Distributor C | 11 | % |  | * |

[0001262039-26-000013:notes:137]
* Represents less than 10%


## us-gaap:SubsequentEventsTextBlock

[0001262039-26-000013:notes:138]
SUBSEQUENT EVENT
Share Repurchase Program

[0001262039-26-000013:notes:139]
Subsequent to March 31, 2026 and through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.9 million shares of our common stock at an average price of $77.95 per share, for an aggregate purchase price of $145.9 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $765.8 million remained available for future share repurchases through February 28, 2027 under the Repurchase Program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001262039-26-000013:notes:140]
On March 3, 2026, Ken Xie, our Chief Executive Officer and one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Ken Xie Plan”) during an open trading window in accordance with our insider trading policy. The Ken Xie Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Ken Xie Plan provides for the potential sale by Mr. Ken Xie of up to (a) 1,164,981 shares of our common stock, issued upon the vesting and settlement of RSUs for shares of our common stock and the exercise of vested options to purchase shares of our common stock and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement of RSUs and PSUs, in each case, at the market price, all between June 2, 2026 and November 30, 2027.

[0001262039-26-000013:notes:141]
On March 4, 2026, Michael Xie, our Chief Technology Officer and one of our directors, entered into a pre-arranged written stock sale plan in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Michael Xie Plan”) during an open trading window in accordance with our insider trading policy. The Michael Xie Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The Michael Xie Plan provides for the potential sale by Mr. Michael Xie of up to (a) 466,239 shares of our common stock, issued upon the vesting and settlement of RSUs for shares of our common stock and the exercise of vested options to purchase shares of our common stock and (b) the net shares (which are not yet determinable) after shares are withheld to satisfy tax obligations upon such vesting and settlement of RSUs and PSUs, in each case, at the market price, all between June 3, 2026 and November 30, 2027.

[0001262039-26-000013:notes:142]
On February 19, 2026, John Whittle, our Chief Operating Officer, modified an existing trading plan, which was originally adopted on March 3, 2025 in accordance with Rule 10b5-1 under the Exchange Act for the sale of shares of our common stock (the “Whittle Plan”) during an open trading window in accordance with our insider trading policy. The modified Whittle Plan is intended to satisfy the affirmative defense of Rule 10b5-1(c) under the Exchange Act. The modified Whittle Plan provides for the potential sale by Mr. Whittle of up to 146,015 shares of our common stock, issued upon the exercise of vested stock options for shares of our common stock, at the market price, between May 21, 2026 and May 28, 2027.
