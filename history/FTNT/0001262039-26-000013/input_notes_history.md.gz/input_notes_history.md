# FTNT note change history — 0001262039-25-000039 → 0001262039-26-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2026 (in millions):
  (was, 2025-11-07, similarity 0.9609):
[0001262039-25-000039:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of September 30, 2025 (in millions):

- changed (2026-05-08):
[0001262039-26-000013:note_history:2]
As of March 31, 2026, we had $1.37 billion of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of March 31, 2026 and December 31, 2025, the liability for these inventory purchase commitments was $27.2 million and $26.7 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was immaterial and a $4.5 million benefit during the three months ended March 31, 2026 and 2025, respectively.
  (was, 2025-11-07, similarity 0.9071):
[0001262039-25-000039:note_history:2]
As of September 30, 2025, we had $732.5 million of non-cancelable inventory purchase commitments with our independent contract manufacturers. We recorded a liability for these purchase commitments for quantities in excess of our future estimated demand forecasts, consistent with the valuation of our excess and obsolete inventory. As of September 30, 2025 and December 31, 2024, the liability for these inventory purchase commitments was $35.2 million and $54.0 million, respectively, and was recorded in accrued liabilities on our condensed consolidated balance sheets. The expense related to such accrued liability for inventory purchase commitments is recorded in cost of product revenue on the condensed consolidated statements of income. The expense related to such accrued liability for inventory purchase commitments was immaterial during the three and nine months ended September 30, 2025, and was a $27.4 million benefit and a $11.2 million cost during the three and nine months ended September 30, 2024, respectively.

- changed (2026-05-08):
[0001262039-26-000013:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our requirements based on our business needs prior to firm orders being placed. As of March 31, 2026, we had $127.8 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.
  (was, 2025-11-07, similarity 0.8089):
[0001262039-25-000039:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. A significant portion of our reported purchase commitments consist of non-cancelable commitments. In certain instances, contractual commitments allow us the option to cancel, reschedule and adjust our

- changed (2026-05-08):
[0001262039-26-000013:note_history:4]
As of March 31, 2026, we had $70.4 million in contractual commitments related to payments for operating leases.
  (was, 2025-11-07, similarity 0.9519):
[0001262039-25-000039:note_history:4]
As of September 30, 2025, we had $92.9 million in contractual commitments related to payments for operating leases.

- added (2026-05-08):
[0001262039-26-000013:note_history:5]
Litigation—We are subject to legal proceedings arising in the ordinary course of business. We record accruals for litigation contingencies when a loss is probable and reasonably estimable, based on management’s assessment of the expected outcome and currently available information. As of March 31, 2026 and December 31, 2025, litigation loss contingency accruals associated with outstanding matters were not material.

- added (2026-05-08):
[0001262039-26-000013:note_history:6]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 3:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. The court subsequently consolidated these actions under a new caption, In re Fortinet, Inc. Securities Litigation, Lead Case No. 3:25-cv-08037 (the “Consolidated Securities Class Action”), and appointed a lead plaintiff and lead counsel. A consolidated amended complaint was filed on April 24, 2026, which asserts claims under Section 10(b), 20(a) and 20A of the Exchange Act against our chief executive officer, our chief technology officer, our current chief financial officer, and our former chief financial officer relating to the same events and circumstances alleged in the initial complaints, and adds a Section 10(b) claim against our head of investor relations. The Consolidated Securities Class Action seeks damages, attorneys fees and costs, and other relief that the court may deem appropriate. The time to respond to the consolidated amended complaint has not yet passed. We believe the Consolidated Securities Class Action is without merit and intend to defend the suit vigorously. Based on the preliminary nature of the proceedings in the Consolidated Securities Class Action, the outcome of that matter remains uncertain

- added (2026-05-08):
[0001262039-26-000013:note_history:7]
and we cannot estimate the potential impact, if any, on our business or financial statements at this time. Accordingly, no loss accrual was recorded as of March 31, 2026 related to this litigation.

- added (2026-05-08):
[0001262039-26-000013:note_history:8]
On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Pittrof v. Xie, et al., Case No. 3:2025-cv-08592 (“Pittrof”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for violations of Section 10(b) of the Exchange Act. On November 5, 2025, Plaintiff Michael J. Marrinan filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Marrinan v. Xie, et al., Case No. 3:25-cv-09546 (“Marrinan”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, gross mismanagement, waste of corporate assets, violations of California Corporations Code §§ 24400, 25500, et. seq., and violations of Section 10(b) of the Exchange Act. On November 6, 2025, Plaintiff Bryan Foster filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned Foster v. Xie, et al., Case No. 3:25-cv-09611 (“Foster”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, for violations of Section 10(b), 14(a), and 20(a) of the Exchange Act, and for contribution under Section 21D of the Exchange Act. On December 2, 2025, Plaintiff LR Trust filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California, captioned LR Trust v. Xie, et al., Case No. 3:25-cv-10350 (“LR Trust,” together with Pittrof, Marrinan, and Foster, the “Derivative Actions”). The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, unjust enrichment, insider trading, aiding and abetting, violations of Sections 10(b) and 14(a) of the Exchange Act, and for contribution under Section 21D of the Exchange Act. On behalf of the Company, the Derivative Actions seek damages, disgorgement, remedial actions, restitution, and attorneys’ fees and costs. The Derivative Actions have been consolidated under a new caption, In re Fortinet, Inc. Stockholder Derivative Litigation, Lead Case No. 3:2025-cv-08592 (the “Consolidated Derivative Action”). On April 2, 2026, the Court stayed all proceedings in the Consolidated Derivative Action pending the final resolution of the Consolidated Securities Class Action.

- changed (2026-05-08):
[0001262039-26-000013:note_history:9]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of March 31, 2026 or December 31, 2025 related to this litigation.
  (was, 2025-11-07, similarity 0.9902):
[0001262039-25-000039:note_history:9]
On March 21, 2019, we were sued by Alorica Inc. (“Alorica”) in Santa Clara County Superior Court in California. Alorica alleged breach of warranty and misrepresentation claims, which we denied. After trial, a jury returned a verdict fully in favor of us and against Alorica on October 4, 2024. Alorica has filed a notice of appeal. We believe that the ultimate outcome of this matter will not materially impact our financial position, results of operations or cash flows. However, any further legal proceedings, including Alorica’s appeal, would be subject to inherent uncertainties, and a future unfavorable ruling could occur. No loss accrual had been recorded as of September 30, 2025 or December 31, 2024 related to this litigation.

- changed (2026-05-08):
[0001262039-26-000013:note_history:10]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain Intellectual Property (“IP”) rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.
  (was, 2025-11-07, similarity 0.9216):
[0001262039-25-000039:note_history:10]
Indemnification and Other Matters—We enter into indemnification provisions in the ordinary course of business with other companies such as partners, customers, and vendors, where we agree to indemnify, hold harmless, and reimburse the indemnified party for certain losses suffered or incurred by the indemnified party as a result of our activities, including defending against third-party claims asserting various allegations such as product defects, breach of representations or covenants, and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are

- changed (2026-05-08):
[0001262039-26-000013:note_history:11]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position, results of operations or cash flows.
  (was, 2025-11-07, similarity 0.9645):
[0001262039-25-000039:note_history:11]
Similar to other security companies and companies in other industries, we have experienced and may experience in the future, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any claims or proceedings related to these types of matters that we believe are likely to have a material adverse effect on our financial position.

- removed (2026-05-08):
[0001262039-25-000039:note_history:12]
requirements based on our business needs prior to firm orders being placed. As of September 30, 2025, we had $112.7 million in other contractual commitments having a remaining term in excess of one year that are non-cancelable.

- removed (2026-05-08):
[0001262039-25-000039:note_history:13]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property (“IP”) litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. These accruals are generally based on a range of possible outcomes that require significant management judgment. If no amount within a range is a better estimate than any other, we accrue the minimum amount. Litigation loss contingency accruals associated with outstanding cases were not material as of September 30, 2025 and December 31, 2024.

- removed (2026-05-08):
[0001262039-25-000039:note_history:14]
On September 22, 2025, a securities class action was filed against us, our chief executive officer, our chief technology officer, our current chief financial officer and our former chief financial officer in the United States District Court, Northern District of California, captioned Oklahoma Firefighters Pension and Retirement System v. Fortinet, Inc., et al., Case No. 5:25-cv-08037. On October 16, 2025, a securities class action was filed against us, our chief executive Officer, our current chief financial officer and our former chief financial officer in the same court, captioned State of Rhode Island Office of the General Treasurer v. Fortinet, Inc., et al., Case No. 3:25-cv-08888. These suits are brought on behalf of an alleged class of stockholders who purchased or acquired shares of our common stock between November 8, 2024 through August 6, 2025. The complaints allege that defendants made false or misleading statements about our business, operations and prospects, including regarding the 2026 firewall refresh cycle, and purport to assert claims under Sections 10(b) and 20(a) of the Exchange Act. The time to respond to the complaints has not yet passed. We believe these cases are without merit and defendants intend to defend the suits vigorously. Based on the preliminary nature of the proceedings in these cases, the outcome of these matters remains uncertain and we cannot estimate the potential impact, if any, on its business or financial statements at this time. Accordingly, no loss accrual was recorded as of September 30, 2025 related to these litigations. On October 8, 2025, Plaintiff Jack Pittrof filed a stockholder derivative complaint against us as a nominal defendant and certain of our current and former directors and officers in the United States District Court for the Northern District of California. The complaint alleges claims based on events similar to those in the securities class action and asserts causes of action against the individual defendants for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, waste of corporate assets, and for making false and misleading statements about our business, operations, and prospects in violation of Section 10(b) of the Exchange Act. The time to respond to the complaint has not yet passed.

- removed (2026-05-08):
[0001262039-25-000039:note_history:15]
indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:16]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2025, contained in our Annual Report on Form 10-K filed with the SEC on February 25, 2026. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three months ended March 31, 2026 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2025 is derived from the audited consolidated financial statements for the year ended December 31, 2025.
  (was, 2025-11-07, similarity 0.9813):
[0001262039-25-000039:note_history:16]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2024, contained in our Annual Report on Form 10-K filed with the SEC on February 21, 2025. In the opinion of management, all adjustments, which include normal recurring adjustments, considered necessary for a fair presentation, have been included. The results of operations for the three and nine months ended September 30, 2025 are not necessarily indicative of the results to be expected for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2024 is derived from the audited consolidated financial statements for the year ended December 31, 2024.

- added (2026-05-08):
[0001262039-26-000013:note_history:17]
The condensed consolidated financial statements include the accounts of Fortinet, Inc. and its subsidiaries. As of March 31, 2026, the functional currency of our foreign subsidiaries is the U.S. dollar. Effective January 1, 2026, the Company transitioned the functional currency of one of its subsidiaries to the U.S. dollar following its full operational integration. We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany balances and transactions have been eliminated in consolidation.

- changed (2026-05-08):
[0001262039-26-000013:note_history:18]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2026, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2025 filed with the SEC.
  (was, 2025-11-07, similarity 0.9074):
[0001262039-25-000039:note_history:18]
There have been no material changes to our significant accounting policies as of and for the nine months ended September 30, 2025, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

- added (2026-05-08):
[0001262039-26-000013:note_history:19]
Recent Adopted Accounting Standards

- changed (2026-05-08):
[0001262039-26-000013:note_history:20]
In July 2025, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting periods beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We adopted ASU 2025-05 on January 1, 2026 and the adoption of this standard did not have a material impact on our condensed consolidated financial statements.
  (was, 2025-11-07, similarity 0.779):
[0001262039-25-000039:note_history:20]
In July 2025, the FASB issued ASU 2025-05—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets (“ASU 2025-05”), which provides a practical expedient for estimating expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under Revenue from Contracts with Customers (Topic 606). The amendments are effective for our annual reporting period beginning with fiscal year 2026 and interim reporting periods within those annual reporting periods on a prospective basis, with early adoption permitted. We are currently evaluating ASU 2025-05 to determine its impact on our consolidated financial statements and related disclosures.

- added (2026-05-08):
[0001262039-26-000013:note_history:21]
Expense Disaggregation Disclosures

- changed (2026-05-08):
[0001262039-26-000013:note_history:22]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (“ASU 2024-03”), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting periods beginning fiscal year 2027 and our interim reporting periods beginning in fiscal year 2028, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.
  (was, 2025-11-07, similarity 0.9611):
[0001262039-25-000039:note_history:22]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03), and in January 2025, the FASB issued ASU No. 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarified the effective date of ASU 2024-03. ASU 2024-03 enhances the disclosures required for expense disaggregation in our annual and interim consolidated financial statements. The amendments are effective for our annual reporting period beginning fiscal year 2027, with early adoption permitted, and can be applied prospectively or retrospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

- changed (2026-05-08):
[0001262039-26-000013:note_history:23]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual periods beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.
  (was, 2025-11-07, similarity 0.9994):
[0001262039-25-000039:note_history:23]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software (“ASU 2025-06”), which amends the cost capitalization criteria for internal-use software development costs by removing all references to prescriptive and sequential software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. The amendments are effective for our annual period beginning fiscal year 2028 and interim reporting periods within those annual reporting periods and can be applied prospectively, retrospectively, or via a modified prospective transition method, with early adoption permitted. We are currently assessing adoption timing and the method of adoption.

- removed (2026-05-08):
[0001262039-25-000039:note_history:24]
Amounts previously reported as gain on bargain purchase are included in other income—net in prior periods to conform with current period presentation in our condensed consolidated statements of income. Amounts previously reported as loss from equity method investments and gain on bargain purchase are included in other in prior periods to conform with current period presentation in section of net cash provided by operating activities in our condensed consolidated statements of cash flows.

- removed (2026-05-08):
[0001262039-25-000039:note_history:25]
The condensed consolidated financial statements include the accounts of Fortinet, Inc. and its subsidiaries. We consolidate all legal entities in which we have an absolute controlling financial interest. All intercompany balances and transactions have been eliminated in consolidation.

- removed (2026-05-08):
[0001262039-25-000039:note_history:26]
Income Taxes

- removed (2026-05-08):
[0001262039-25-000039:note_history:27]
In December 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for our annual period beginning fiscal year 2025, with early adoption permitted, and should be applied prospectively. We are currently evaluating the ASU to determine its impact on our disclosures.

- removed (2026-05-08):
[0001262039-25-000039:note_history:28]
Income Statement


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-08):
[0001262039-26-000013:note_history:29]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations.

- added (2026-05-08):
[0001262039-26-000013:note_history:30]
Upon maturity on March 15, 2026, we repaid the full $500.0 million aggregate principal amount of the 2026 Senior Notes.

- added (2026-05-08):
[0001262039-26-000013:note_history:31]
We may redeem the 2031 Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The Senior Notes were recorded net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2026-05-08):
[0001262039-26-000013:note_history:32]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2026 |  | December 31,2025 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | — |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 500.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 3.2 |  |  | 3.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  | 499.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.8 |  |  | $ | 496.6 |  |
  (was, 2025-11-07, similarity 0.8263):
[0001262039-25-000039:note_history:32]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.4 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.5 |  |  | $ | 994.3 |  |

- changed (2026-05-08):
[0001262039-26-000013:note_history:33]
As of March 31, 2026 and December 31, 2025, we accrued interest payable of $0.5 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended March 31, 2026 and 2025, we recorded $4.2 million and $4.5 million of total interest expense in relation to these Senior Notes in each period, respectively. No interest costs were capitalized for the three months ended March 31, 2026 and 2025, as the costs that qualified for capitalization were not material.
  (was, 2025-11-07, similarity 0.7913):
[0001262039-25-000039:note_history:33]
As of September 30, 2025 and December 31, 2024, we accrued interest payable of $0.7 million and $4.7 million, respectively, and there are no financial covenants with which we must comply. During the three months ended September 30, 2025 and 2024, we recorded $4.5 million of total interest expense in relation to these Senior Notes in each period. During the nine months ended September 30, 2025 and 2024, we recorded $13.5 million of total interest expense in relation to these Senior Notes in each period. No interest costs were capitalized for the nine months ended September 30, 2025 and 2024, as the costs that qualified for capitalization were not material.

- added (2026-05-08):
[0001262039-26-000013:note_history:34]
The total estimated fair value of the outstanding 2031 Senior Notes was approximately $445.2 million, including accrued and unpaid interest, as of March 31, 2026. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2026-05-08):
[0001262039-25-000039:note_history:35]
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. The 2026 Senior Notes were recorded as current portion of long-term debt and the 2031 Senior Notes were recorded as long-term debt as of September 30, 2025 and both of the Senior Notes were recorded as long-term debt as of December 31, 2024, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- removed (2026-05-08):
[0001262039-25-000039:note_history:36]
The total estimated fair value of the outstanding Senior Notes was approximately $939.4 million, including accrued and unpaid interest, as of September 30, 2025. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:37]
|  | March 31, 2026 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 544.1 |  |  | $ | (0.5) |  |  | $ | — |  |  | $ | — |  |  | $ | 544.1 |  |  | $ | (0.5) |  |
| Corporate debt securities | 442.9 |  |  | (1.0) |  |  | — |  |  | — |  |  | 442.9 |  |  | (1.0) |  |
| Commercial paper | 289.3 |  |  | (0.1) |  |  | — |  |  | — |  |  | 289.3 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 105.0 |  |  | (0.1) |  |  | — |  |  | — |  |  | 105.0 |  |  | (0.1) |  |
| Total available-for-sale investments | $ | 1,381.3 |  |  | $ | (1.7) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,381.3 |  |  | $ | (1.7) |  |
  (was, 2025-11-07, similarity 0.7093):
[0001262039-25-000039:note_history:37]
|  | September 30, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 560.5 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 560.5 |  |  | $ | (0.1) |  |
| Commercial paper | 370.5 |  |  | — |  |  | — |  |  | — |  |  | 370.5 |  |  | — |  |
| Corporate debt securities | 285.4 |  |  | (0.1) |  |  | — |  |  | — |  |  | 285.4 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 102.3 |  |  | — |  |  | — |  |  | — |  |  | 102.3 |  |  | — |  |
| Total available-for-sale investments | $ | 1,318.7 |  |  | $ | (0.2) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,318.7 |  |  | $ | (0.2) |  |

- changed (2026-05-08):
[0001262039-26-000013:note_history:38]
|  | December 31, 2025 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 514.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 514.5 |  |  | $ | — |  |
| Corporate debt securities | 368.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | 368.9 |  |  | (0.1) |  |
| Commercial paper | 354.9 |  |  | — |  |  | — |  |  | — |  |  | 354.9 |  |  | — |  |
| Certificates of deposit and term deposits | 90.4 |  |  | — |  |  | — |  |  | — |  |  | 90.4 |  |  | — |  |
| Total available-for-sale investments | $ | 1,328.7 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,328.7 |  |  | $ | (0.1) |  |
  (was, 2025-11-07, similarity 0.8926):
[0001262039-25-000039:note_history:38]
|  | December 31, 2024 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| U.S. government and agency securities | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| Commercial paper | 149.4 |  |  | (0.2) |  |  | — |  |  | — |  |  | 149.4 |  |  | (0.2) |  |
| Corporate debt securities | 63.5 |  |  | (0.1) |  |  | — |  |  | — |  |  | 63.5 |  |  | (0.1) |  |
| Certificates of deposit and term deposits | 10.9 |  |  | — |  |  | — |  |  | — |  |  | 10.9 |  |  | — |  |
| Total available-for-sale investments | $ | 251.6 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 251.6 |  |  | $ | (0.3) |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:39]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31,2026 |  | December 31,2025 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | — |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 500.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 3.2 |  |  | 3.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  | 499.7 |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.8 |  |  | $ | 496.6 |  |
  (was, 2025-11-07, similarity 0.8263):
[0001262039-25-000039:note_history:39]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | September 30,2025 |  | December 31,2024 |
| Debt |  |  |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0% |  | 1.3% |  | $ | 500.0 |  |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2% |  | 2.3% |  | 500.0 |  |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | 4.1 |  |  | 5.7 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | $ | 499.4 |  |  | $ | — |  |
| Total long-term debt |  |  |  |  |  |  | $ | 496.5 |  |  | $ | 994.3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:40]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Product | $ | 645.1 |  |  | $ | 459.1 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 694.0 |  |  | 623.1 |  |  |  |  |  |
| Technical support and other | 510.5 |  |  | 457.5 |  |  |  |  |  |
| Total service revenue | 1,204.5 |  |  | 1,080.6 |  |  |  |  |  |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |  |  |  |  |
  (was, 2025-11-07, similarity 0.6518):
[0001262039-25-000039:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 672.0 |  |  | 595.8 |  |  | 1,939.5 |  |  | 1,691.4 |  |
| Technical support and other | 493.6 |  |  | 438.4 |  |  | 1,427.8 |  |  | 1,269.6 |  |
| Total service revenue | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-08):
[0001262039-26-000013:note_history:41]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Product | $ | 645.1 |  |  | $ | 459.1 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 694.0 |  |  | 623.1 |  |  |  |  |  |
| Technical support and other | 510.5 |  |  | 457.5 |  |  |  |  |  |
| Total service revenue | 1,204.5 |  |  | 1,080.6 |  |  |  |  |  |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |  |  |  |  |
  (was, 2025-11-07, similarity 0.6518):
[0001262039-25-000039:note_history:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30,2025 |  | September 30,2024 |  | September 30,2025 |  | September 30,2024 |
| Product | $ | 559.3 |  |  | $ | 473.9 |  |  | $ | 1,527.3 |  |  | $ | 1,334.7 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 672.0 |  |  | 595.8 |  |  | 1,939.5 |  |  | 1,691.4 |  |
| Technical support and other | 493.6 |  |  | 438.4 |  |  | 1,427.8 |  |  | 1,269.6 |  |
| Total service revenue | 1,165.6 |  |  | 1,034.2 |  |  | 3,367.3 |  |  | 2,961.0 |  |
| Total revenue | $ | 1,724.9 |  |  | $ | 1,508.1 |  |  | $ | 4,894.6 |  |  | $ | 4,295.7 |  |

- added (2026-05-08):
[0001262039-26-000013:note_history:42]
During the three months ended March 31, 2026 and 2025, we recognized $1.09 billion and $972.5 million in revenue that was included in the deferred revenue balance as of December 31, 2025 and 2024, respectively.

- changed (2026-05-08):
[0001262039-26-000013:note_history:43]
As of March 31, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations was $7.45 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.76 billion as revenue over the next 12 months, $2.94 billion in years two and three, and the remainder thereafter.
  (was, 2025-11-07, similarity 0.9858):
[0001262039-25-000039:note_history:43]
As of September 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was $6.72 billion, which was substantially comprised of deferred security subscription and technical support services revenue as well as unbilled contract revenue from non-cancellable contracts that will be recognized in future periods. We expect to recognize approximately $3.49 billion as revenue over the next 12 months, $2.62 billion in years two and three, and the remainder thereafter.

- changed (2026-05-08):
[0001262039-26-000013:note_history:44]
Amortization of deferred contract costs, primarily consisting of sales commissions earned by our sales force, was $94.2 million and $78.0 million during the three months ended March 31, 2026 and 2025, respectively.
  (was, 2025-11-07, similarity 0.9282):
[0001262039-25-000039:note_history:44]
Amortization of deferred contract costs, primarily consisting of sales commissions earned by our sales force, was $86.0 million and $73.6 million during the three months ended September 30, 2025 and 2024, respectively. Amortization of

- removed (2026-05-08):
[0001262039-25-000039:note_history:45]
During the three and nine months ended September 30, 2025, we recognized $759.2 million and $2.61 billion in revenue that was included in the deferred revenue balance as of December 31, 2024, respectively. During the three and nine months ended September 30, 2024, we recognized $660.3 million and $2.28 billion in revenue that was included in the deferred revenue balance as of December 31, 2023, respectively.

- removed (2026-05-08):
[0001262039-25-000039:note_history:46]
deferred contract costs was $246.0 million and $218.3 million during the nine months ended September 30, 2025 and 2024, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2026-05-08):
[0001262039-26-000013:note_history:47]
SUBSEQUENT EVENT
Share Repurchase Program

- added (2026-05-08):
[0001262039-26-000013:note_history:48]
Subsequent to March 31, 2026 and through the filing of this Quarterly Report on Form 10-Q, we repurchased 1.9 million shares of our common stock at an average price of $77.95 per share, for an aggregate purchase price of $145.9 million, under the Repurchase Program. As of the filing of this Quarterly Report on Form 10-Q, approximately $765.8 million remained available for future share repurchases through February 28, 2027 under the Repurchase Program.
