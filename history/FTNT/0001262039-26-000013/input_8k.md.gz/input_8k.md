# FTNT 8-K — 0001262039-26-000010 filed 2026-05-06

## item codes, every 8-K on or before 2026-05-08

- 2026-05-06 0001262039-26-000010 — 2.02, 9.01
- 2026-02-05 0001262039-26-000003 — 2.02, 9.01
- 2025-11-05 0001262039-25-000036 — 2.02, 9.01
- 2025-08-22 0001262039-25-000033 — 8.01
- 2025-08-06 0001262039-25-000025 — 2.02, 9.01
- 2025-06-18 0001262039-25-000022 — 5.07
- 2025-05-15 0001262039-25-000020 — 5.02 — amendment, the index does not say of what
- 2025-05-07 0001262039-25-000014 — 2.02, 9.01
- 2025-02-06 0001262039-25-000007 — 2.02, 5.02, 9.01
- 2025-01-22 0001262039-25-000003 — 5.02 — amendment, the index does not say of what
- 2024-11-12 0001262039-24-000045 — 5.02, 9.01
- 2024-11-07 0001262039-24-000040 — 2.02, 9.01
- 2024-08-07 0001262039-24-000034 — 2.02, 9.01 — amendment of 0001262039-24-000032
- 2024-08-06 0001262039-24-000032 — 2.02, 9.01
- 2024-07-24 0001262039-24-000028 — 5.02 — amendment, the index does not say of what
- 2024-06-20 0001262039-24-000025 — 5.07
- 2024-05-02 0001262039-24-000017 — 2.02, 9.01
- 2024-02-23 0001262039-24-000011 — 5.02, 9.01
- 2024-02-06 0001262039-24-000006 — 2.02, 9.01
- 2024-01-18 0001262039-24-000003 — 5.02
- 2023-12-01 0001262039-23-000041 — 5.02
- 2023-11-02 0001262039-23-000035 — 2.02, 9.01
- 2023-08-03 0001262039-23-000027 — 2.02, 9.01
- 2023-06-23 0001262039-23-000024 — 5.03, 5.07, 9.01
- 2023-05-04 0001262039-23-000013 — 2.02, 9.01
- 2023-02-08 0001262039-23-000006 — 5.03, 9.01
- 2023-02-07 0001262039-23-000003 — 2.02, 9.01
- 2022-11-02 0001262039-22-000035 — 2.02, 9.01
- 2022-08-03 0001262039-22-000026 — 2.02, 9.01
- 2022-06-22 0001262039-22-000023 — 5.03, 9.01
- 2022-06-21 0001262039-22-000021 — 5.07
- 2022-05-04 0001262039-22-000015 — 2.02, 9.01
- 2022-05-02 0001262039-22-000012 — 5.02
- 2022-04-22 0001262039-22-000010 — 8.01
- 2022-02-03 0001262039-22-000005 — 2.02, 9.01
- 2022-01-26 0001262039-22-000002 — 5.02, 9.01 — amendment, the index does not say of what
- 2021-11-04 0001262039-21-000027 — 2.02, 9.01
- 2021-10-06 0001262039-21-000024 — 5.02, 9.01
- 2021-07-29 0001262039-21-000019 — 2.02, 9.01
- 2021-06-23 0001262039-21-000016 — 5.07
- 2021-04-30 0001104659-21-059008 — 5.03 — amendment, the index does not say of what
- 2021-04-29 0001262039-21-000011 — 2.02, 9.01
- 2021-04-28 0001104659-21-056360 — 5.02, 5.03, 9.01
- 2021-03-05 0001193125-21-071498 — 1.01, 9.01
- 2021-02-25 0001193125-21-057281 — 1.01, 9.01
- 2021-02-04 0001262039-21-000005 — 2.02, 9.01
- 2020-12-08 0001262039-20-000070 — 8.01
- 2020-10-29 0001262039-20-000063 — 2.02, 9.01
- 2020-10-20 0001262039-20-000060 — 5.02 — amendment, the index does not say of what
- 2020-08-26 0001262039-20-000056 — 5.02, 9.01
- 2020-08-06 0001262039-20-000051 — 2.02, 9.01
- 2020-07-21 0001262039-20-000044 — 5.03, 8.01, 9.01
- 2020-06-24 0001262039-20-000038 — 5.07
- 2020-05-06 0001262039-20-000029 — 2.02, 9.01
- 2020-04-23 0001262039-20-000025 — 5.03, 9.01
- 2020-04-23 0001262039-20-000024 — 5.02 — amendment of 0001262039-20-000025
- 2020-02-28 0001262039-20-000015 — 5.02, 9.01
- 2020-02-06 0001262039-20-000004 — 2.02, 9.01
- 2019-12-12 0001262039-19-000038 — 8.01
- 2019-10-31 0001262039-19-000032 — 2.02, 9.01
- 2019-10-28 0001262039-19-000027 — 8.01
- 2019-10-23 0001262039-19-000025 — 5.02, 9.01
- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2026-05-08

- none on or before 2026-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-26-000010:8k_2_02:1]
EX-99.1
2
ftntq1-2026ex991.htm
PRESS RELEASE

[0001262039-26-000010:8k_2_02:2]
Document

[0001262039-26-000010:8k_2_02:3]
Press Release

[0001262039-26-000010:8k_2_02:4]
Fortinet Reports Strong First Quarter 2026 Financial Results

[0001262039-26-000010:8k_2_02:5]
Exceeds high end of first quarter guidance on revenue and profitability

[0001262039-26-000010:8k_2_02:6]
Raises 2026 revenue guidance to 15% year over year growth

[0001262039-26-000010:8k_2_02:7]
Highlights

[0001262039-26-000010:8k_2_02:8]
•Revenue grew 20% year over year to $1.85 billion

[0001262039-26-000010:8k_2_02:9]
•Product revenue grew 41% year over year to $645 million

[0001262039-26-000010:8k_2_02:10]
•Billings grew 31% year over year to $2.09 billion1

[0001262039-26-000010:8k_2_02:11]
•GAAP operating margin of 31%

[0001262039-26-000010:8k_2_02:12]
•Non-GAAP operating margin of 36%1

[0001262039-26-000010:8k_2_02:13]
•GAAP earnings per share grew 29% year over year to $0.72

[0001262039-26-000010:8k_2_02:14]
•Non-GAAP earnings per share grew 41% year over year to $0.821

[0001262039-26-000010:8k_2_02:15]
•Record operating cash flow of $1.08 billion

[0001262039-26-000010:8k_2_02:16]
•Record free cash flow of $1.01 billion1

[0001262039-26-000010:8k_2_02:17]
SUNNYVALE, Calif. - May 6, 2026 - Fortinet® (Nasdaq: FTNT), a global cybersecurity leader driving the convergence of networking and security, today announced financial results for the first quarter ended March 31, 2026.

[0001262039-26-000010:8k_2_02:18]
“We are very pleased with our excellent first quarter results, exceeding the high end of our guidance through strong execution and broad-based demand across our portfolio and geographies,” said Ken Xie, Founder, Chairman and Chief Executive Officer of Fortinet. “Billings grew 31% year over year, driven by the continued convergence of networking and security, an approach Fortinet has led for 26 years, and by an increasingly complex threat environment that is being intensified by AI. As network security evolves towards the SASE Firewall, innovations such as our new FortiOS 8.0 and FortiASIC technology continue to differentiate our platform and support ongoing market share gains, while our direct operations, manufacturing model and strong execution turn supply chain challenges into opportunities to gain market share.”

[0001262039-26-000010:8k_2_02:19]
Recent Business Highlights

[0001262039-26-000010:8k_2_02:20]
•Introduced FortiOS 8.0, the latest release of the operating system that powers the Fortinet Security Fabric. FortiOS 8.0 delivers powerful new AI-driven security, next-generation SASE, and quantum-safe capabilities to help organizations simplify their security architectures while delivering consistent protection and performance across the entire digital infrastructure.

[0001262039-26-000010:8k_2_02:21]
•Announced new additions to the FortiGate G Series portfolio, with the FortiGate 3500G and FortiGate 400G designed to deliver high‑performance security that helps organizations secure and scale modern enterprise networks while keeping pace with growing encrypted traffic.

[0001262039-26-000010:8k_2_02:22]
•Fortinet is collaborating closely with multiple leading AI companies, including Anthropic as part of “Project Glasswing”, OpenAI and others.

[0001262039-26-000010:8k_2_02:23]
•Recognized as a Gartner Peer Insights™ Customers’ Choice for SD-WAN, marking the seventh consecutive year customers have validated Fortinet Secure SD-WAN based on real-world experience and outcomes.

[0001262039-26-000010:8k_2_02:24]
Guidance

[0001262039-26-000010:8k_2_02:25]
For the second quarter of 2026, Fortinet currently expects:

[0001262039-26-000010:8k_2_02:26]
•Revenue in the range of $1.830 billion to $1.930 billion

[0001262039-26-000010:8k_2_02:27]
•Billings in the range of $2.090 billion to $2.190 billion

[0001262039-26-000010:8k_2_02:28]
•Non-GAAP gross margin in the range of 79.5% to 80.5%

[0001262039-26-000010:8k_2_02:29]
•Non-GAAP operating margin in the range of 33.0% to 35.0%

[0001262039-26-000010:8k_2_02:30]
•Diluted non-GAAP net income per share in the range of $0.72 to $0.76, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 736 million to 740 million.

[0001262039-26-000010:8k_2_02:31]
For the fiscal year 2026, Fortinet currently expects:

[0001262039-26-000010:8k_2_02:32]
•Revenue in the range of $7.710 billion to $7.870 billion

[0001262039-26-000010:8k_2_02:33]
•Service revenue in the range of $5.090 billion to $5.150 billion

[0001262039-26-000010:8k_2_02:34]
•Billings in the range of $8.800 billion to $9.100 billion

[0001262039-26-000010:8k_2_02:35]
•Non-GAAP gross margin in the range of 79.0% to 81.0%

[0001262039-26-000010:8k_2_02:36]
•Non-GAAP operating margin in the range of 33.0% to 36.0%

[0001262039-26-000010:8k_2_02:37]
•Diluted non-GAAP net income per share in the range of $3.10 to $3.16, assuming a non-GAAP effective tax rate of 18%. This assumes a diluted share count of 743 million to 749 million.

[0001262039-26-000010:8k_2_02:38]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation, amortization of acquired intangible assets, gain on intellectual property matters and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control or cannot be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-26-000010:8k_2_02:39]
Conference Call Details

[0001262039-26-000010:8k_2_02:40]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations.

[0001262039-26-000010:8k_2_02:41]
Second Quarter 2026 Conference Participation Schedule:

[0001262039-26-000010:8k_2_02:42]
•J.P. Morgan Global Technology, Media and Communications Conference

[0001262039-26-000010:8k_2_02:43]
May 19, 2026

[0001262039-26-000010:8k_2_02:44]
•Bank of America Global Technology Conference

[0001262039-26-000010:8k_2_02:45]
June 2, 2026

[0001262039-26-000010:8k_2_02:46]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s website. To access the most updated information, pre-register and listen to the webcast of each event, please visit the Investor Presentation & Events page of Fortinet’s website at https://investor.fortinet.com/events-and-presentations. The schedule is subject to change.

[0001262039-26-000010:8k_2_02:47]
About Fortinet (www.fortinet.com)

[0001262039-26-000010:8k_2_02:48]
Fortinet (Nasdaq: FTNT) is a driving force in the evolution of cybersecurity and the convergence of networking and security. Our mission is to secure people, devices and data everywhere, and today we deliver cybersecurity everywhere our customers need it with the largest integrated portfolio of over 50 enterprise-grade products. Well over half a million customers trust Fortinet’s solutions, which are among the most deployed, most patented and most validated in the industry. The Fortinet Training Institute, one of the largest and broadest training programs in the industry, is dedicated to making cybersecurity training and new career opportunities available to everyone. Collaboration with esteemed organizations from both the public and private sectors, including Computer Emergency Response Teams (“CERTs”), government entities, and academia, is a fundamental aspect of Fortinet’s commitment to enhance cyber resilience globally. FortiGuard Labs, Fortinet’s elite threat intelligence and research organization, develops and utilizes leading-edge machine learning and AI technologies to provide customers with timely and consistently top-rated protection and actionable threat intelligence. Learn more at https://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-26-000010:8k_2_02:49]
Forward-Looking Statements

[0001262039-26-000010:8k_2_02:50]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding any indications related to future growth and market share gains, our strategy going forward, and guidance and expectations around future financial results, including guidance and expectations for the second quarter and full year 2026, and any statements regarding our market opportunity and market size, and business momentum. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks, including those caused by economic challenges, a possible economic downturn or recession and the effects of inflation or stagflation, changing interest rates or reduced information technology spending; supply chain challenges; negative impacts from global conflicts and their related macroeconomic effects; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; sales execution risks, including risks in connection with the timing and completion of large strategic deals; uncertainties around continued success in sales growth and market share gains; uncertainties in market opportunities and the market size; actual or perceived vulnerabilities in our supply chain, products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith, including, among other risks, changes in plans related to product and services integrations, product and services plans and sales strategies; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; cybersecurity threats, breaches and other disruptions; market acceptance of new products and services; the ability to

[0001262039-26-000010:8k_2_02:51]
Use of Non-GAAP Financial Measures

[0001262039-26-000010:8k_2_02:52]
We believe that the presentation of non-GAAP financial information provides important supplemental information to management and investors regarding financial and business trends relating to our financial condition and results of operations. For further information regarding why we believe that these non-GAAP measures provide useful information to investors, the specific manner in which management uses these measures, and some of the limitations associated with the use of these measures, please refer to the “Explanation of Non-GAAP Financial Measures” section of this press release.

[0001262039-26-000010:8k_2_02:53]
FORTINET, INC.

[0001262039-26-000010:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-26-000010:8k_2_02:55]
(Unaudited, in millions)

[0001262039-26-000010:8k_2_02:56]
|  | March 31,2026 |  | December 31,2025 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 2,223.8 |  |  | $ | 2,495.3 |  |
| Short-term investments | 1,071.1 |  |  | 1,087.2 |  |
| Accounts receivable—net | 1,486.2 |  |  | 1,691.2 |  |
| Inventory | 369.6 |  |  | 399.5 |  |
| Prepaid expenses and other current assets | 181.9 |  |  | 227.0 |  |
| Total current assets | 5,332.6 |  |  | 5,900.2 |  |
| LONG-TERM INVESTMENTS | 339.7 |  |  | 339.7 |  |
| PROPERTY AND EQUIPMENT—NET | 1,691.5 |  |  | 1,619.0 |  |
| DEFERRED CONTRACT COSTS | 753.7 |  |  | 735.5 |  |
| DEFERRED TAX ASSETS | 1,304.5 |  |  | 1,314.9 |  |
| GOODWILL AND OTHER INTANGIBLE ASSETS—NET | 344.4 |  |  | 354.7 |  |
| OTHER ASSETS | 117.1 |  |  | 125.2 |  |
| TOTAL ASSETS | $ | 9,883.5 |  |  | $ | 10,389.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 238.7 |  |  | $ | 230.8 |  |
| Accrued liabilities | 366.1 |  |  | 354.6 |  |
| Accrued payroll and compensation | 292.4 |  |  | 312.9 |  |
| Current portion of long-term debt | — |  |  | 499.7 |  |
| Deferred revenue | 3,726.3 |  |  | 3,636.0 |  |
| Total current liabilities | 4,623.5 |  |  | 5,034.0 |  |
| DEFERRED REVENUE | 3,625.2 |  |  | 3,479.8 |  |
| LONG-TERM DEBT | 496.8 |  |  | 496.6 |  |
| OTHER LIABILITIES | 148.3 |  |  | 141.3 |  |
| Total liabilities | 8,893.8 |  |  | 9,151.7 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.7 |  |  | 0.7 |  |
| Additional paid-in capital | 1,798.7 |  |  | 1,770.1 |  |
| Accumulated other comprehensive loss | (27.7) |  |  | (25.4) |  |
| Accumulated deficit | (782.0) |  |  | (507.9) |  |
| Total stockholders’ equity | 989.7 |  |  | 1,237.5 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 9,883.5 |  |  | $ | 10,389.2 |  |

[0001262039-26-000010:8k_2_02:57]
FORTINET, INC.

[0001262039-26-000010:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-26-000010:8k_2_02:59]
(Unaudited, in millions, except per share amounts)

[0001262039-26-000010:8k_2_02:60]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 645.1 |  |  | $ | 459.1 |  |  |  |  |  |
| Service | 1,204.5 |  |  | 1,080.6 |  |  |  |  |  |
| Total revenue | 1,849.6 |  |  | 1,539.7 |  |  |  |  |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 208.3 |  |  | 149.9 |  |  |  |  |  |
| Service | 156.2 |  |  | 143.2 |  |  |  |  |  |
| Total cost of revenue | 364.5 |  |  | 293.1 |  |  |  |  |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 436.8 |  |  | 309.2 |  |  |  |  |  |
| Service | 1,048.3 |  |  | 937.4 |  |  |  |  |  |
| Total gross profit | 1,485.1 |  |  | 1,246.6 |  |  |  |  |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 214.0 |  |  | 198.6 |  |  |  |  |  |
| Sales and marketing | 636.3 |  |  | 542.7 |  |  |  |  |  |
| General and administrative | 56.2 |  |  | 57.8 |  |  |  |  |  |
| Gain on intellectual property matters | (1.4) |  |  | (6.3) |  |  |  |  |  |
| Total operating expenses | 905.1 |  |  | 792.8 |  |  |  |  |  |
| OPERATING INCOME | 580.0 |  |  | 453.8 |  |  |  |  |  |
| INTEREST INCOME | 32.9 |  |  | 44.3 |  |  |  |  |  |
| INTEREST EXPENSE | (4.2) |  |  | (4.9) |  |  |  |  |  |
| OTHER INCOME—NET | 47.9 |  |  | 26.1 |  |  |  |  |  |
| INCOME BEFORE INCOME TAXES AND GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | 656.6 |  |  | 519.3 |  |  |  |  |  |
| PROVISION FOR INCOME TAXES | 122.0 |  |  | 96.5 |  |  |  |  |  |
| GAIN (LOSS) FROM EQUITY METHOD INVESTMENTS | (0.1) |  |  | 10.6 |  |  |  |  |  |
| NET INCOME | $ | 534.5 |  |  | $ | 433.4 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.72 |  |  | $ | 0.56 |  |  |  |  |  |
| Diluted | $ | 0.72 |  |  | $ | 0.56 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 738.8 |  |  | 768.3 |  |  |  |  |  |
| Diluted | 742.8 |  |  | 776.8 |  |  |  |  |  |

[0001262039-26-000010:8k_2_02:61]
FORTINET, INC.

[0001262039-26-000010:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-26-000010:8k_2_02:63]
(Unaudited, in millions)

[0001262039-26-000010:8k_2_02:64]
|  | Three Months Ended |
|  | March 31,2026 |  | March 31,2025 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 534.5 |  |  | $ | 433.4 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 72.5 |  |  | 66.1 |  |
| Amortization of deferred contract costs | 94.2 |  |  | 78.0 |  |
| Depreciation and amortization | 39.8 |  |  | 35.8 |  |
| Amortization of investment discounts | (4.8) |  |  | (10.3) |  |
| Other | (44.9) |  |  | (35.5) |  |
| Changes in operating assets and liabilities, net of impact of business combinations: |  |  |  |
| Accounts receivable—net | 205.2 |  |  | 303.9 |  |
| Inventory | 23.6 |  |  | (34.1) |  |
| Prepaid expenses and other current assets | 62.8 |  |  | 3.4 |  |
| Deferred contract costs | (112.4) |  |  | (91.3) |  |
| Deferred tax assets | 11.0 |  |  | (30.0) |  |
| Other assets | (5.4) |  |  | 1.5 |  |
| Accounts payable | (26.0) |  |  | 24.6 |  |
| Accrued liabilities | 12.5 |  |  | 63.7 |  |
| Accrued payroll and compensation | (20.6) |  |  | (8.2) |  |
| Deferred revenue | 235.7 |  |  | 57.0 |  |
| Other liabilities | (0.6) |  |  | 5.3 |  |
| Net cash provided by operating activities | 1,077.1 |  |  | 863.3 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (350.7) |  |  | (503.0) |  |
| Sales of investments | 115.9 |  |  | 2.8 |  |
| Maturities of investments | 299.7 |  |  | 466.9 |  |
| Purchases of property and equipment | (70.6) |  |  | (66.5) |  |
| Payments made in connection with business combinations, net of cash acquired | — |  |  | (11.2) |  |
| Other | — |  |  | 0.2 |  |
| Net cash used in investing activities | (5.7) |  |  | (110.8) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (823.0) |  |  | — |  |
| Repayment of senior notes | (500.0) |  |  | — |  |
| Proceeds from issuance of common stock | 17.6 |  |  | 20.2 |  |
| Taxes paid related to net share settlement of equity awards | (36.3) |  |  | (52.9) |  |
| Other | (1.2) |  |  | — |  |
| Net cash used in financing activities | (1,342.9) |  |  | (32.7) |  |
| EFFECT OF EXCHANGE RATE CHANGES ON CASH AND CASH EQUIVALENTS | — |  |  | 0.9 |  |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (271.5) |  |  | 720.7 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 2,495.3 |  |  | 2,875.9 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 2,223.8 |  |  | $ | 3,596.6 |  |

[0001262039-26-000010:8k_2_02:65]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-26-000010:8k_2_02:66]
(Unaudited, in millions, except per share amounts)

[0001262039-26-000010:8k_2_02:67]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-26-000010:8k_2_02:68]
|  | Three Months Ended |  |  |
|  | March 31,2026 |  | March 31,2025 |  |  |  |  |
| Reconciliation of non-GAAP operating income: |  |  |  |  |  |  |  |
| GAAP operating income | $ | 580.0 |  |  | $ | 453.8 |  |  |  |  |  |
| GAAP operating margin | 31.4 | % |  | 29.5 | % |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 73.2 |  |  | 66.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 10.3 |  |  | 11.8 |  |  |  |  |  |
| Gain on intellectual property matters | (1.4) |  |  | (6.3) |  |  |  |  |  |
| Non‐GAAP operating income | $ | 662.1 |  |  | $ | 526.2 |  |  |  |  |  |
| Non‐GAAP operating margin | 35.8 | % |  | 34.2 | % |  |  |  |  |
| Reconciliation of non-GAAP net income: |  |  |  |  |  |  |  |
| GAAP net income | $ | 534.5 |  |  | $ | 433.4 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Stock‐based compensation | 73.2 |  |  | 66.9 |  |  |  |  |  |
| Amortization of acquired intangible assets | 10.3 |  |  | 11.8 |  |  |  |  |  |
| Gain on intellectual property matters | (1.4) |  |  | (6.3) |  |  |  |  |  |
| Gain on bargain purchase | — |  |  | (39.9) |  |  |  |  |  |
| Tax adjustment (a) | (11.0) |  |  | (2.8) |  |  |  |  |  |
| Gain from equity method investment | — |  |  | (10.8) |  |  |  |  |  |
| Non-GAAP net income | $ | 605.6 |  |  | $ | 452.3 |  |  |  |  |  |
| Non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 605.6 |  |  | $ | 452.3 |  |  |  |  |  |
| Non-GAAP shares used in diluted net income per share calculations | 742.8 |  |  | 776.8 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.82 |  |  | $ | 0.58 |  |  |  |  |  |
| Reconciliation of non-GAAP net income per share, diluted |  |  |  |  |  |  |  |
| GAAP net income per share, diluted | $ | 0.72 |  |  | $ | 0.56 |  |  |  |  |  |
| Add back: |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income per share | 0.10 |  |  | 0.02 |  |  |  |  |  |
| Non-GAAP net income per share, diluted | $ | 0.82 |  |  | $ | 0.58 |  |  |  |  |  |

[0001262039-26-000010:8k_2_02:69]
(a) Non-GAAP financial information is adjusted to an effective tax rate of 18% in the three months ended March 31, 2026 and 2025, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-26-000010:8k_2_02:70]
Reconciliation of net cash provided by operating activities to adjusted free cash flow

[0001262039-26-000010:8k_2_02:71]
|  | Three Months Ended |
|  | March 31,2026 |  | March 31,2025 |
| Net cash provided by operating activities | $ | 1,077.1 |  |  | $ | 863.3 |  |
| Less: Purchases of property and equipment | (70.6) |  |  | (66.5) |  |
| Less: Proceeds from intellectual property matter | — |  |  | (14.0) |  |
| Free cash flow | $ | 1,006.5 |  |  | $ | 782.8 |  |
| Add: Real estate related purchases | 58.5 |  |  | 56.2 |  |
| Adjusted free cash flow | $ | 1,065.0 |  |  | $ | 839.0 |  |
| Free cash flow margin | 54.4 | % |  | 50.8 | % |
| Adjusted free cash flow margin | 57.6 | % |  | 54.5 | % |
| Net cash used in investing activities | $ | (5.7) |  |  | $ | (110.8) |  |
| Net cash used in financing activities | $ | (1,342.9) |  |  | $ | (32.7) |  |

[0001262039-26-000010:8k_2_02:72]
Reconciliation of total revenue to total billings

[0001262039-26-000010:8k_2_02:73]
|  | Three Months Ended |
|  | March 31,2026 |  | March 31,2025 |
| Total revenue | $ | 1,849.6 |  |  | $ | 1,539.7 |  |
| Add: Change in deferred revenue | 235.7 |  |  | 57.5 |  |
| Total billings | $ | 2,085.3 |  |  | $ | 1,597.2 |  |

[0001262039-26-000010:8k_2_02:74]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Explanation of Non-GAAP Financial Measures”.

[0001262039-26-000010:8k_2_02:75]
Explanation of Non-GAAP Financial Measures

[0001262039-26-000010:8k_2_02:76]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-26-000010:8k_2_02:77]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-26-000010:8k_2_02:78]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue as well as cash flows. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings are impacted by the term of security subscription and support agreements and do not provide an indication as to the timing of revenue being recognized from these service contracts. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-26-000010:8k_2_02:79]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment and excluding any significant non-recurring items, such as proceeds from intellectual property matters. Free cash flow margin is defined as free cash flow divided by GAAP revenue. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures and net of proceeds from intellectual property matters, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from significant non-recurring items, such as proceeds from intellectual property matters, investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our proceeds from intellectual property matters, our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-26-000010:8k_2_02:80]
Adjusted free cash flow (non-GAAP). We define adjusted free cash flow as free cash flow plus cash payments associated with real estate related purchases. Adjusted free cash flow margin is defined as adjusted free cash flow divided by GAAP revenue.

[0001262039-26-000010:8k_2_02:81]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation and amortization of acquired intangible assets, less gain on intellectual property matters and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-26-000010:8k_2_02:82]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for a gain on bargain purchase related to acquisition, a gain from an equity method investment related to acquisition and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-26-000010:8k_2_02:83]
#          #          #

[0001262039-26-000010:8k_2_02:84]
Copyright © 2026 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and common law trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, the Fortinet logo, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, FortiADC, FortiAgent, FortiAI, FortiAIOps, FortiAntenna, FortiAP, FortiAPCam, FortiAppSec, FortiAuthenticator, FortiBranchSASE, FortiCall, FortiCam, FortiCamera, FortiCarrier, FortiCART, FortiCASB, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiDAST, FortiDATA, FortiDB, FortiDevice, FortiDDoS, FortiDeceptor, FortiDeploy, FortiDevice, FortiDevSec, FortiDLP, FortiEdge, FortiEDR, FortiEndpoint, FortiExplorer, FortiExtender, FortiFirewall, FortiFlex, FortiFone, FortiGSLB, FortiGuest, FortiHSM, FortiHypervisor, FortiIdentity, FortiInsight, FortiIsolator, FortiLink, FortiMonitor, FortiNAC, FortiNDR, FortiPAM, FortiPhish, FortiPoint, FortiPoints, FortiPortal, FortiPresence, FortiProxy, FortiRecon, FortiRecorder, FortiSASE, FortiSAT, FortiSEC, FortiSIEM, FortiSMS, FortiSOAR, FortiSOC, FortiSRA, FortiSwitch, FortiTelemetry, FortiTester, FortiTIP, FortiToken, FortiTrust, FortiVoice, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLM, FortiXDR, Lacework FortiCNAPP, Linksys, Intelligent Mesh, Velop, Max-Stream, Performance Perfected and SECURITY FABRIC. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-26-000010:8k_2_02:85]
FTNT-F

[0001262039-26-000010:8k_2_02:86]
Gartner, Voice of the Customer for SD-WAN, By Peer Contributors, 27 February 2026

[0001262039-26-000010:8k_2_02:87]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally. All rights reserved.

[0001262039-26-000010:8k_2_02:88]
Gartner does not endorse any vendor, product, or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-26-000010:8k_2_02:89]
Note for Gartner Peer Insights™: Reviews from vendor partners or end users of companies with less than $50 million in revenue are excluded from this methodology. See the full “Voice of the Customer” methodology.

[0001262039-26-000010:8k_2_02:90]
Gartner and Peer Insights are trademarks of Gartner, Inc. and/or its affiliates. All rights reserved. Gartner Peer Insights content consists of the opinions of individual end users based on their own experiences, and should not be construed as statements of fact, nor do they represent the views of Gartner or its affiliates. Gartner does not endorse any vendor, product or service depicted in this content nor makes any warranties, expressed or implied, with respect to this content, about its accuracy or completeness, including any warranties of merchantability or fitness for a particular purpose.

[0001262039-26-000010:8k_2_02:91]
| Investor Contact: |  | Media Contact: |
| Anthony Luscri |  | Stephanie Lira |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 |  | 408-235-7700 |
| investors@fortinet.com |  | pr@fortinet.com |
