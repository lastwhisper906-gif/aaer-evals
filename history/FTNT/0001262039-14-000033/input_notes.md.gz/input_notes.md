# FTNT notes — 0001262039-14-000033


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-14-000033:notes:1]
[same as prior period, unchanged from 0001262039-14-000025:notes:1]

[0001262039-14-000033:notes:2]
[same as prior period, unchanged from 0001262039-14-000025:notes:2]

[0001262039-14-000033:notes:3]
On March 21, 2013, we acquired all of the outstanding equity securities of Coyote, a provider of application delivery, load balancing and acceleration solutions, for $6.0 million in cash. The acquisition also included a contingent obligation for up to $5.5 million in future earn-out payments to former stockholders of Coyote, if specified future operational objectives, service conditions and financial results are met within two years of the acquisition date.  As of June 30, 2014, we have estimated there are no contingent earn-out payments.

[0001262039-14-000033:notes:4]
[same as prior period, unchanged from 0001262039-14-000025:notes:4]

[0001262039-14-000033:notes:5]
[same as prior period, unchanged from 0001262039-14-000025:notes:5]

[0001262039-14-000033:notes:6]
[same as prior period, unchanged from 0001262039-14-000025:notes:6]

[0001262039-14-000033:notes:7]
Of the total acquired identified intangible assets, we allocated $2.3 million to developed technology, $0.5 million to customer relationships, and $2.6 million to in-process research and development (“IPR&D”) as of the acquisition date. Identified finite-lived intangible assets consist of developed technology and customer relationships that are being amortized as cost of revenue and sales and marketing expense, respectively, ratably on a straight-line basis, each over an estimated useful life of six years. The goodwill of $2.8 million represents the premium we paid over the fair value of the net tangible liabilities assumed and identified intangible assets acquired, due primarily to acquire developed and in-process technology. None of the goodwill recognized as a result of the acquisition is deductible for income tax purposes. The financial results of this acquisition were considered immaterial for purposes of pro-forma financial disclosures. During the three months ended September 30, 2013, we completed the development of technology associated with the IPR&D projects, and started amortizing this developed technology as cost of revenue ratably on a straight-line basis over an estimated remaining useful life of approximately five years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-14-000033:notes:8]
COMMITMENTS AND CONTINGENCIES

[0001262039-14-000033:notes:9]
The following table summarizes our future principal contractual obligations as of June 30, 2014 (in thousands):

[0001262039-14-000033:notes:10]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 34,431 |  |  | $ | 4,905 |  |  | $ | 7,814 |  |  | $ | 6,120 |  |  | $ | 5,190 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |
| Less: Sublease rental income | 876 |  |  | 404 |  |  | 472 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 33,555 |  |  | 4,501 |  |  | 7,342 |  |  | 6,120 |  |  | 5,190 |  |  | 3,966 |  |  | 6,436 |  |
| Purchase commitments | 46,379 |  |  | 46,379 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 15,987 |  |  | 12,131 |  |  | 2,717 |  |  | 743 |  |  | 396 |  |  | — |  |  | — |  |
| Total | $ | 95,921 |  |  | $ | 63,011 |  |  | $ | 10,059 |  |  | $ | 6,863 |  |  | $ | 5,586 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |

[0001262039-14-000033:notes:11]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.4 million during the three months ended June 30, 2014 and June 30, 2013. Rent expense was $5.1 million and $4.7 million during the six months ended June 30, 2014 and June 30, 2013, respectively.

[0001262039-14-000033:notes:12]
Purchase Commitments and Other Contractual Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2014, we had $46.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-14-000033:notes:13]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2014, we had $16.0 million in other purchase commitments.

[0001262039-14-000033:notes:14]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-14-000033:notes:15]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (1,728 | ) |  | (1,744 | ) |
| Provision for warranty for the period | 2,560 |  |  | 2,204 |  |
| Adjustment related to pre-existing warranties | (415 | ) |  | 208 |  |
| Accrued warranty balance—end of the period | $ | 3,454 |  |  | $ | 2,977 |  |

[0001262039-14-000033:notes:16]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

[0001262039-14-000033:notes:17]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-14-000033:notes:18]
EMPLOYEE BENEFIT PLANS

[0001262039-14-000033:notes:19]
Our tax-deferred savings plan, under the 401(k) Plan, allows participating employees to defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”) which permits participants to make tax deductible contributions up to the maximum contribution limits under the Income Tax Act. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plans and RRSP for the three months ended June 30, 2014 and June 30, 2013 were $0.6 million and $0.5 million, respectively. Our matching contributions to the 401(k) Plans and RRSP for the six months ended June 30, 2014 and June 30, 2013 were $1.2 million and $1.1 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-14-000033:notes:20]
[same as prior period, unchanged from 0001262039-14-000025:notes:20]

[0001262039-14-000033:notes:21]
The following table summarizes the changes in accumulated balances of other comprehensive income for the six months ended June 30, 2014 (in thousands):

[0001262039-14-000033:notes:22]
|  | June 30, 2014 |
|  | Foreign Currency Translation Gains And Losses |  | Unrealized Gains And Losses On Investments |  | Tax Benefit Or Provision Related To Items Of Other Comprehensive Income Or Loss |  | Total |
| Balance as of December 31, 2013 | $ | 333 |  |  | $ | 1,168 |  |  | $ | (409 | ) |  | $ | 1,092 |  |
| Other comprehensive income before reclassifications | 101 |  |  | (10 | ) |  | 4 |  |  | 95 |  |
| Amounts reclassified from accumulated other comprehensive income | — |  |  | (9 | ) |  | 3 |  |  | (6 | ) |
| Net current-period other comprehensive income | 101 |  |  | (19 | ) |  | 7 |  |  | 89 |  |
| Balance as of June 30, 2014 | $ | 434 |  |  | $ | 1,149 |  |  | $ | (402 | ) |  | $ | 1,181 |  |

[0001262039-14-000033:notes:23]
The following table provides details about the reclassification out of accumulated other comprehensive income for the six months ended June 30, 2014 (in thousands):

[0001262039-14-000033:notes:24]
| June 30, 2014 |
| Details About Accumulated Other Comprehensive Income Components |  | Amount Reclassified From Accumulated Other Comprehensive Income |  | Affected Line Item In The Statement Where Net Income Is Presented |
| Unrealized gains on investments |  | $ | (9 | ) |  | Other (expense) income—net |
| Tax provision related to items of other comprehensive income or loss |  | 3 |  |  | Provision for income taxes |
| Total reclassification for the period |  | $ | (6 | ) |  |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001262039-14-000033:notes:25]
[same as prior period, unchanged from 0001262039-14-000025:notes:25]

[0001262039-14-000033:notes:26]
|  | June 30, 2014 |  | December 31, 2013 |
| Product | $ | 4,063 |  |  | $ | 2,915 |  |
| Services and other | 476,139 |  |  | 429,713 |  |
| Total deferred revenue | $ | 480,202 |  |  | $ | 432,628 |  |
| Reported As: |  |  |  |
| Current | $ | 321,359 |  |  | $ | 293,664 |  |
| Non-current | 158,843 |  |  | 138,964 |  |
| Total deferred revenue | $ | 480,202 |  |  | $ | 432,628 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001262039-14-000033:notes:27]
[same as prior period, unchanged from 0001262039-14-000025:notes:27]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001262039-14-000033:notes:28]
[same as prior period, unchanged from 0001262039-14-000025:notes:28]

[0001262039-14-000033:notes:29]
Foreign Currency Derivatives—Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the U.S. are denominated in foreign currencies and are subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities, including forward contracts, to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. We record changes in the fair value of forward exchange contracts related to balance sheet accounts as Other (expense) income—net in the consolidated statement of operations.

[0001262039-14-000033:notes:30]
Additionally, independent of any hedging activities, fluctuations in foreign currency exchange rates may cause us to recognize transaction gains and losses in Other (expense) income—net in our condensed consolidated statements of operations. Our hedging activities are intended to reduce, but not eliminate, the impact of currency exchange rate movements. As our hedging activities are relatively short-term in nature and are focused on CAD, long-term material changes in the value of the U.S. dollar against other foreign currencies, such as the GBP, EUR and JPY could adversely impact our operating expenses in the future.

[0001262039-14-000033:notes:31]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of June 30, 2014 and December 31, 2013 were (in thousands):

[0001262039-14-000033:notes:32]
|  | Buy/Sell |  | Notional |
| Currency—As of June 30, 2014 |  |  |  |
| CAD | Buy |  | $ | 20,587 |  |
| Currency—As of December 31, 2013 |  |  |  |
| CAD | Buy |  | $ | 21,867 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-14-000033:notes:33]
[same as prior period, unchanged from 0001262039-14-000025:notes:33]

[0001262039-14-000033:notes:34]
Our 2009 Equity Incentive Plan (“Plan”) permits us to grant awards of stock options, stock appreciation rights, restricted stock, restricted stock units, and performance units or performance shares.

[0001262039-14-000033:notes:35]
[same as prior period, unchanged from 0001262039-14-000025:notes:35]

[0001262039-14-000033:notes:36]
The following table summarizes the weighted-average assumptions relating to our employee stock options for the periods presented below:

[0001262039-14-000033:notes:37]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2014 |
| Expected term in years | 4.9 |  |  | 4.9 |  |
| Volatility | 43.3 | % |  | 43.3% - 44.5% |  |
| Risk-free interest rate | 1.7 | % |  | 1.7 | % |
| Dividend rate | — |  |  | — |  |

[0001262039-14-000033:notes:38]
There were no stock options granted during the three and six months ended June 30, 2013.

[0001262039-14-000033:notes:39]
[same as prior period, unchanged from 0001262039-14-000025:notes:39]

[0001262039-14-000033:notes:40]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2013 | 15,521 |  |  | $ | 13.18 |  |  |  |  |  |  |
| Granted | 218 |  |  | 21.36 |  |  |  |  |  |
| Forfeited | (284 | ) |  | 23.84 |  |  |  |  |  |
| Exercised | (2,082 | ) |  | 7.32 |  |  |  |  |  |
| Balance—June 30, 2014 | 13,373 |  |  | 14.00 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2014 | 13,337 |  |  | $ | 13.98 |  |  | 2.97 |  | $ | 152,067 |  |
| Options exercisable—June 30, 2014 | 10,952 |  |  | $ | 11.97 |  |  | 2.61 |  | $ | 146,189 |  |

[0001262039-14-000033:notes:41]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2014, for all in-the-money options. As of June 30, 2014, total compensation expense related to unvested stock options granted to employees but not yet recognized was $28.2 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 1.5 years.

[0001262039-14-000033:notes:42]
[same as prior period, unchanged from 0001262039-14-000025:notes:42]

[0001262039-14-000033:notes:43]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Weighted-average fair value per share granted | $ | 8.18 |  |  | $ | — |  |  | $ | 8.58 |  |  | $ | — |  |
| Intrinsic value of options exercised | $ | 16,441 |  |  | $ | 3,058 |  |  | $ | 31,762 |  |  | $ | 29,117 |  |
| Fair value of options vested | $ | 4,209 |  |  | $ | 5,486 |  |  | $ | 8,771 |  |  | $ | 16,489 |  |

[0001262039-14-000033:notes:44]
[same as prior period, unchanged from 0001262039-14-000025:notes:44]

[0001262039-14-000033:notes:45]
[same as prior period, unchanged from 0001262039-14-000025:notes:45]

[0001262039-14-000033:notes:46]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant-Date-Fair Value per Share |
| Balance—December 31, 2013 | 4,199 |  |  | $ | 22.00 |  |
| Granted | 2,222 |  |  | 21.37 |  |
| Forfeited | (237 | ) |  | 21.81 |  |
| Vested | (791 | ) |  | 22.55 |  |
| Balance—June 30, 2014 | 5,393 |  |  | $ | 21.75 |  |
| RSUs expected to vest—June 30, 2014 | 5,094 |  |  | $ | 21.78 |  |

[0001262039-14-000033:notes:47]
As of June 30, 2014, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the Plan, but not yet recognized, was $112.5 million, net of estimated forfeitures. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 3.0 years.

[0001262039-14-000033:notes:48]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-14-000033:notes:49]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2014 |
| Shares withheld for taxes | 86 |  |  | 257 |  |
| Amount withheld for taxes | $ | 1,888 |  |  | $ | 5,521 |  |

[0001262039-14-000033:notes:50]
No RSUs vested in the three and six months ended June 30, 2013.

[0001262039-14-000033:notes:51]
[same as prior period, unchanged from 0001262039-14-000025:notes:50]

[0001262039-14-000033:notes:52]
[same as prior period, unchanged from 0001262039-14-000025:notes:51]

[0001262039-14-000033:notes:53]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 35.9 | % |  | 48.0 | % |
| Risk-free interest rate | 0.1 | % |  | 0.1 | % |
| Dividend rate | — |  |  | — |  |

[0001262039-14-000033:notes:54]
[same as prior period, unchanged from 0001262039-14-000025:notes:53]

[0001262039-14-000033:notes:55]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Weighted-average fair value per share granted | $ | 5.35 |  |  | $ | 7.02 |  |
| Shares issued under the ESPP | 424 |  |  | 329 |  |
| Weighted-average price per share issued | $ | 17.18 |  |  | $ | 19.91 |  |

[0001262039-14-000033:notes:56]
There were no shares granted or issued under the ESPP during the three months ended June 30, 2014 and June 30, 2013.

[0001262039-14-000033:notes:57]
[same as prior period, unchanged from 0001262039-14-000025:notes:55]

[0001262039-14-000033:notes:58]
[same as prior period, unchanged from 0001262039-14-000025:notes:56]

[0001262039-14-000033:notes:59]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Cost of product revenue | $ | 178 |  |  | $ | 96 |  |  | $ | 291 |  |  | $ | 186 |  |
| Cost of services and other revenue | 1,363 |  |  | 1,226 |  |  | 2,692 |  |  | 2,246 |  |
| Research and development | 4,171 |  |  | 3,291 |  |  | 8,053 |  |  | 6,057 |  |
| Sales and marketing | 5,747 |  |  | 4,594 |  |  | 11,493 |  |  | 8,712 |  |
| General and administrative | 3,257 |  |  | 1,500 |  |  | 5,117 |  |  | 2,805 |  |
| Total stock-based compensation expense | $ | 14,716 |  |  | $ | 10,707 |  |  | $ | 27,646 |  |  | $ | 20,006 |  |

[0001262039-14-000033:notes:60]
[same as prior period, unchanged from 0001262039-14-000025:notes:58]

[0001262039-14-000033:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Stock options | $ | 4,421 |  |  | $ | 5,135 |  |  | $ | 9,113 |  |  | $ | 10,622 |  |
| RSUs | 9,248 |  |  | 4,357 |  |  | 16,611 |  |  | 7,030 |  |
| ESPP | 1,047 |  |  | 1,215 |  |  | 1,922 |  |  | 2,354 |  |
| Total stock-based compensation expense | $ | 14,716 |  |  | $ | 10,707 |  |  | $ | 27,646 |  |  | $ | 20,006 |  |

[0001262039-14-000033:notes:62]
Total income tax benefit associated with stock-based compensation that is included as part of the provision for income taxes in the condensed consolidated statements of operations is as follows (in thousands):

[0001262039-14-000033:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Income tax benefit associated with stock-based compensation | $ | 4,247 |  |  | $ | 2,794 |  |  | $ | 7,813 |  |  | $ | 6,381 |  |

[0001262039-14-000033:notes:64]
[same as prior period, unchanged from 0001262039-14-000025:notes:62]

[0001262039-14-000033:notes:65]
On December 6, 2013, our Board of Directors authorized a Share Repurchase Program (“Program”) to repurchase up to $200.0 million of our outstanding common stock through December 31, 2014. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program may be suspended, modified or discontinued at any time without prior notice.  During the three and six months ended June 30, 2014, we repurchased 0.7 million and 1.0 million shares of common stock under the Program in open market transactions for an aggregate purchase price of $14.9 million and $22.5 million, respectively. As of June 30, 2014, $138.6 million remains authorized for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-14-000033:notes:66]
[same as prior period, unchanged from 0001262039-14-000025:notes:64]

[0001262039-14-000033:notes:67]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, restricted stock units (“RSUs”), and the employee stock purchase plan (“ESPP”). Potentially dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-14-000033:notes:68]
[same as prior period, unchanged from 0001262039-14-000025:notes:66]

[0001262039-14-000033:notes:69]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 6,081 |  |  | $ | 8,979 |  |  | $ | 14,474 |  |  | $ | 21,228 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163,161 |  |  | 162,247 |  |  | 162,778 |  |  | 161,767 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163,161 |  |  | 162,247 |  |  | 162,778 |  |  | 161,767 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 4,583 |  |  | 5,734 |  |  | 4,753 |  |  | 6,152 |  |
| RSUs | 600 |  |  | 32 |  |  | 462 |  |  | 46 |  |
| ESPP | 1 |  |  | 29 |  |  | 22 |  |  | 68 |  |
| Weighted-average shares used to compute diluted net income per share | 168,345 |  |  | 168,042 |  |  | 168,015 |  |  | 168,033 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.06 |  |  | $ | 0.09 |  |  | $ | 0.13 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.09 |  |  | $ | 0.13 |  |

[0001262039-14-000033:notes:70]
[same as prior period, unchanged from 0001262039-14-000025:notes:68]

[0001262039-14-000033:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Stock options | 4,201 |  |  | 7,472 |  |  | 4,323 |  |  | 7,483 |  |
| RSUs | 593 |  |  | 2,554 |  |  | 1,871 |  |  | 1,804 |  |
| ESPP | — |  |  | — |  |  | 261 |  |  | — |  |
|  | 4,794 |  |  | 10,026 |  |  | 6,455 |  |  | 9,287 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-14-000033:notes:72]
FINANCIAL INSTRUMENTS AND FAIR VALUE MEASUREMENTS

[0001262039-14-000033:notes:73]
The following table summarizes our investments as of June 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000033:notes:74]
|  | June 30, 2014 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 567,252 |  |  | $ | 1,313 |  |  | $ | (205 | ) |  | $ | 568,360 |  |
| Commercial paper | 75,154 |  |  | 2 |  |  | (3 | ) |  | 75,153 |  |
| Municipal bonds | 37,938 |  |  | 50 |  |  | (12 | ) |  | 37,976 |  |
| Certificates of deposit and term deposits | 17,402 |  |  | 2 |  |  | — |  |  | 17,404 |  |
| U.S. government and agency securities | 7,749 |  |  | 7 |  |  | (2 | ) |  | 7,754 |  |
| Total available-for-sale securities | $ | 705,495 |  |  | $ | 1,374 |  |  | $ | (222 | ) |  | $ | 706,647 |  |

[0001262039-14-000033:notes:75]
[same as prior period, unchanged from 0001262039-14-000025:notes:75]

[0001262039-14-000033:notes:76]
The following table shows the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of June 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000033:notes:77]
|  | June 30, 2014 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 149,229 |  |  | $ | (204 | ) |  | $ | 1,019 |  |  | $ | (1 | ) |  | $ | 150,248 |  |  | $ | (205 | ) |
| Commercial paper | 10,884 |  |  | (3 | ) |  | — |  |  | — |  |  | 10,884 |  |  | (3 | ) |
| Municipal bonds | 6,215 |  |  | (10 | ) |  | 4,018 |  |  | (2 | ) |  | 10,233 |  |  | (12 | ) |
| U.S. government and agency securities | 1,998 |  |  | (2 | ) |  | — |  |  | — |  |  | 1,998 |  |  | (2 | ) |
| Total available-for-sale securities | $ | 168,326 |  |  | $ | (219 | ) |  | $ | 5,037 |  |  | $ | (3 | ) |  | $ | 173,363 |  |  | $ | (222 | ) |

[0001262039-14-000033:notes:78]
[same as prior period, unchanged from 0001262039-14-000025:notes:78]

[0001262039-14-000033:notes:79]
[same as prior period, unchanged from 0001262039-14-000025:notes:79]

[0001262039-14-000033:notes:80]
|  | June 30, 2014 |  | December 31, 2013 |
| Due within one year | $ | 354,174 |  |  | $ | 375,497 |  |
| Due within one to three years | 352,473 |  |  | 351,675 |  |
| Total | $ | 706,647 |  |  | $ | 727,172 |  |

[0001262039-14-000033:notes:81]
[same as prior period, unchanged from 0001262039-14-000025:notes:81]

[0001262039-14-000033:notes:82]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the declines in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor it is more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2014.

[0001262039-14-000033:notes:83]
[same as prior period, unchanged from 0001262039-14-000025:notes:83]

[0001262039-14-000033:notes:84]
Fair Value of Financial Instruments

[0001262039-14-000033:notes:85]
Assets and Liabilities Measured at Fair Value on a Recurring Basis

[0001262039-14-000033:notes:86]
The following table presents the fair value of our financial assets and liabilities measured at fair value on a recurring basis as of June 30, 2014 and December 31, 2013 (in thousands):

[0001262039-14-000033:notes:87]
|  | June 30, 2014 |  |  |  | December 31, 2013 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 568,360 |  |  | $ | — |  |  | $ | 568,360 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |  | $ | 604,317 |  |  | $ | — |  |
| Commercial paper | 75,153 |  |  | — |  |  | 75,153 |  |  | — |  |  | 71,363 |  |  | — |  |  | 71,363 |  |  | — |  |
| Municipal bonds | 37,976 |  |  | — |  |  | 37,976 |  |  | — |  |  | 38,843 |  |  | — |  |  | 38,843 |  |  | — |  |
| Certificates of deposit and term deposits | 17,404 |  |  | — |  |  | 17,404 |  |  | — |  |  | 12,648 |  |  | — |  |  | 12,648 |  |  | — |  |
| Money market funds | 21,139 |  |  | 21,139 |  |  | — |  |  | — |  |  | 5,724 |  |  | 5,724 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 7,754 |  |  | 1,998 |  |  | 5,756 |  |  | — |  |  | 2,001 |  |  | — |  |  | 2,001 |  |  | — |  |
| Total | $ | 727,786 |  |  | $ | 23,137 |  |  | $ | 704,649 |  |  | $ | — |  |  | $ | 734,896 |  |  | $ | 5,724 |  |  | $ | 729,172 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Total | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,850 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 21,139 |  |  |  |  |  |  |  |  | $ | 7,724 |  |  |  |  |  |  |  |
| Short-term investments | 354,174 |  |  |  |  |  |  |  |  | 375,497 |  |  |  |  |  |  |  |
| Long-term investments | 352,473 |  |  |  |  |  |  |  |  | 351,675 |  |  |  |  |  |  |  |
| Total | $ | 727,786 |  |  |  |  |  |  |  |  | $ | 734,896 |  |  |  |  |  |  |  |

[0001262039-14-000033:notes:88]
[same as prior period, unchanged from 0001262039-14-000025:notes:86]

[0001262039-14-000033:notes:89]
[same as prior period, unchanged from 0001262039-14-000025:notes:87]

[0001262039-14-000033:notes:90]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three and six months ended June 30, 2014.

[0001262039-14-000033:notes:91]
We have classified the fair value of contingent consideration arising from the acquisition of Coyote Point Systems, Inc. (“Coyote”) (see Note 5), as a Level 3 liability since it is based on a probability-based income approach that includes significant unobservable inputs. The significant unobservable inputs include projected revenues and the percentage probability of occurrence to determine the fair value of the payment. A decrease in the projected revenue during the six months ended June 30, 2014 resulted in no fair value being attributable to the contingent consideration as of June 30, 2014.

[0001262039-14-000033:notes:92]
The change in the fair value of our contingent consideration liability was as follows (in thousands):

[0001262039-14-000033:notes:93]
| As of December 31, 2013 | $1,850 |
| Less change in fair value of contingent consideration | (1,143) |
| As of March 31, 2014 | 707 |
| Less change in fair value of contingent consideration | (707) |
| As of June 30, 2014 | $— |

[0001262039-14-000033:notes:94]
The change in fair value is included in research and development expense in the condensed consolidated statements of operations.

[0001262039-14-000033:notes:95]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis

[0001262039-14-000033:notes:96]
We measure certain assets, including Goodwill, Other intangible assets—net, and investments in privately-held companies at fair value on a nonrecurring basis when there are identifiable events or changes in circumstances that may have a significant adverse impact on the fair value of these assets.

[0001262039-14-000033:notes:97]
During the three and six months ended June 30, 2014, a decrease in the projected cash flow from Coyote resulted in an impairment charge of $2.4 million to adjust the intangible assets acquired from Coyote to a fair value of $2.0 million as of June 30, 2014. The impairment charge is included within Cost of product revenue in the condensed consolidated statements of operations.

[0001262039-14-000033:notes:98]
We have classified these intangible assets acquired from Coyote as Level 3 assets due to the lack of observable inputs to determine fair value. Significant inputs used in the determination of fair value based on the probability-weighted income approach primarily include internal cash flow projections and discount rates.

[0001262039-14-000033:notes:99]
As of December 31, 2013, we did not have any assets or liabilities measured at fair value on a nonrecurring basis.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-14-000033:notes:100]
[same as prior period, unchanged from 0001262039-14-000025:notes:92]

[0001262039-14-000033:notes:101]
The effective tax rate was 49% for the three months ended June 30, 2014, compared to an effective tax rate of 40% for the three months ended June 30, 2013. The effective tax rate was 44% for the six months ended June 30, 2014, compared to an effective tax of 34% for the six months ended June 30, 2013. The provision for income taxes for the periods presented is comprised of U.S. federal and state taxes, Singapore and other foreign income taxes, and withholding tax, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates.

[0001262039-14-000033:notes:102]
As of June 30, 2014 and December 31, 2013, unrecognized tax benefits were $35.7 million and $30.2 million, respectively. The total amount of $35.7 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate.

[0001262039-14-000033:notes:103]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of June 30, 2014, we had accrued approximately $1.4 million for estimated interest related to uncertain tax positions.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001262039-14-000033:notes:104]
[same as prior period, unchanged from 0001262039-14-000025:notes:97]

[0001262039-14-000033:notes:105]
We recorded $2.8 million of goodwill from the acquisition of Coyote. There were no impairments to goodwill during the three and six months ended June 30, 2014.

[0001262039-14-000033:notes:106]
During the three months ended June 30, 2014, we reassessed the fair value and the remaining useful life of the developed technologies acquired from Coyote. Based on this reassessment, we recorded an impairment charge of $2.4 million, which reduced the carrying value of the Coyote developed technologies to $2.0 million. The impairment charge is included within Cost of product revenue in the condensed consolidated statements of operations. Subsequent to the impairment, the remaining carrying value of the Coyote developed technologies will be amortized on a straight-line basis over an estimated remaining useful life of approximately five years.

[0001262039-14-000033:notes:107]
[same as prior period, unchanged from 0001262039-14-000025:notes:99]

[0001262039-14-000033:notes:108]
|  | June 30, 2014 |
|  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |
| Developed technology | $ | 5,606 |  |  | $ | 2,625 |  |  | $ | 2,981 |  |
| Customer relationships | 500 |  |  | 104 |  |  | 396 |  |
| Total other intangible assets—net | $ | 6,106 |  |  | $ | 2,729 |  |  | $ | 3,377 |  |

[0001262039-14-000033:notes:109]
[same as prior period, unchanged from 0001262039-14-000025:notes:101]

[0001262039-14-000033:notes:110]
Amortization expense was $0.5 million and $0.4 million during the three months ended June 30, 2014 and June 30, 2013, respectively. Amortization expense was $1.0 million and $0.7 million for the six months ended June 30, 2014 and June 30, 2013, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net (in thousands):

[0001262039-14-000033:notes:111]
|  | Amount |
| Years Ending December 31: |  |
| 2014 (remainder) | $ | 545 |  |
| 2015 | 1,091 |  |
| 2016 | 785 |  |
| 2017 | 425 |  |
| 2018 | 425 |  |
| Thereafter | 106 |  |
| Total | $ | 3,377 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001262039-14-000033:notes:112]
[same as prior period, unchanged from 0001262039-14-000025:notes:104]

[0001262039-14-000033:notes:113]
[same as prior period, unchanged from 0001262039-14-000025:notes:105]

[0001262039-14-000033:notes:114]
|  | June 30, 2014 |  | December 31, 2013 |
| Raw materials | $ | 5,284 |  |  | $ | 4,319 |  |
| Finished goods | 37,424 |  |  | 40,093 |  |
| Consigned inventory | 4,116 |  |  | 4,260 |  |
| Inventory | $ | 46,824 |  |  | $ | 48,672 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-14-000033:notes:115]
[same as prior period, unchanged from 0001262039-14-000025:notes:107]

[0001262039-14-000033:notes:116]
| Property and Equipment—Net | June 30, 2014 |  | December 31, 2013 |
| Americas: |  |  |  |
| United States | $ | 43,834 |  |  | $ | 29,334 |  |
| Canada | 6,828 |  |  | 4,372 |  |
| Other Americas | 29 |  |  | 45 |  |
| Total Americas | 50,691 |  |  | 33,751 |  |
| EMEA | 2,300 |  |  | 1,273 |  |
| APAC | 2,309 |  |  | 1,628 |  |
| Total property and equipment—net | $ | 55,300 |  |  | $ | 36,652 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-14-000033:notes:117]
[same as prior period, unchanged from 0001262039-14-000025:notes:109]

[0001262039-14-000033:notes:118]
[same as prior period, unchanged from 0001262039-14-000025:notes:110]

[0001262039-14-000033:notes:119]
|  | June 30, 2014 |  | December 31, 2013 |
| Land | $ | 13,895 |  |  | $ | 13,895 |  |
| Building and building improvements | 17,779 |  |  | 610 |  |
| Evaluation units | 26,904 |  |  | 23,442 |  |
| Computer equipment and software | 29,948 |  |  | 23,556 |  |
| Furniture and fixtures | 4,552 |  |  | 1,697 |  |
| Construction-in-progress | 4,332 |  |  | 10,947 |  |
| Leasehold improvements | 7,314 |  |  | 4,303 |  |
| Total property and equipment | 104,724 |  |  | 78,450 |  |
| Less: accumulated depreciation | (49,424 | ) |  | (41,798 | ) |
| Property and equipment—net | $ | 55,300 |  |  | $ | 36,652 |  |

[0001262039-14-000033:notes:120]
Beginning in the first quarter of 2014, we reclassified certain fixed assets between categories in the table above to better reflect the nature of these fixed assets. Prior period amounts have also been reclassified to conform to the current period presentation. We believe the impact of the reclassification is not material.

[0001262039-14-000033:notes:121]
Depreciation expense was $6.0 million and $3.4 million during the three months ended June 30, 2014 and June 30, 2013, respectively. Depreciation expense was $9.9 million and $6.6 million during the six months ended June 30, 2014 and June 30, 2013, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001262039-14-000033:notes:122]
Property and Equipment—Property and equipment—net is stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

[0001262039-14-000033:notes:123]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment and software | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

[0001262039-14-000033:notes:124]
[same as prior period, unchanged from 0001262039-14-000025:notes:116]


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-14-000033:notes:125]
[same as prior period, unchanged from 0001262039-14-000025:notes:117]

[0001262039-14-000033:notes:126]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 49,672 |  |  | $ | 38,815 |  |  | $ | 94,465 |  |  | $ | 73,603 |  |
| Other Americas | 28,713 |  |  | 21,211 |  |  | 56,352 |  |  | 39,050 |  |
| Total Americas | 78,385 |  |  | 60,026 |  |  | 150,817 |  |  | 112,653 |  |
| Europe, Middle East, and Africa (“EMEA”) | 62,554 |  |  | 50,801 |  |  | 119,197 |  |  | 98,127 |  |
| Asia Pacific and Japan (“APAC”) | 43,159 |  |  | 36,601 |  |  | 83,033 |  |  | 72,468 |  |
| Total revenue | $ | 184,098 |  |  | $ | 147,428 |  |  | $ | 353,047 |  |  | $ | 283,248 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-14-000033:notes:127]
[same as prior period, unchanged from 0001262039-14-000025:notes:119]

[0001262039-14-000033:notes:128]
During the three months and six months ended June 30, 2014, Exclusive Networks Group accounted for 14% of total revenue. During the three and six months ended June 30, 2013, Exclusive Networks Group accounted for 11% and 12% of total revenue, respectively.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-14-000033:notes:129]
[same as prior period, unchanged from 0001262039-14-000025:notes:121]

[0001262039-14-000033:notes:130]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

[0001262039-14-000033:notes:131]
[same as prior period, unchanged from 0001262039-14-000025:notes:123]

[0001262039-14-000033:notes:132]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures.

[0001262039-14-000033:notes:133]
[same as prior period, unchanged from 0001262039-14-000025:notes:125]

[0001262039-14-000033:notes:134]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the condensed consolidated statements of operations. The combined amounts are now being presented as Services and other revenue in the condensed consolidated statements of operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material, and the reclassification did not have any impact on our gross margin or net income.

[0001262039-14-000033:notes:135]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.
