# FTNT MD&A — 0001262039-14-000033


## mdna

[0001262039-14-000033:mdna:1]
[same as prior period, unchanged from 0001262039-14-000025:mdna:1]

[0001262039-14-000033:mdna:2]
[same as prior period, unchanged from 0001262039-14-000025:mdna:2]

[0001262039-14-000033:mdna:3]
| • | expected impact of certain acquisitions and investments in strategic relationships; |

[0001262039-14-000033:mdna:4]
[same as prior period, unchanged from 0001262039-14-000025:mdna:4]

[0001262039-14-000033:mdna:5]
[same as prior period, unchanged from 0001262039-14-000025:mdna:6]

[0001262039-14-000033:mdna:6]
[same as prior period, unchanged from 0001262039-14-000025:mdna:7]

[0001262039-14-000033:mdna:7]
[same as prior period, unchanged from 0001262039-14-000025:mdna:8]

[0001262039-14-000033:mdna:8]
[same as prior period, unchanged from 0001262039-14-000025:mdna:9]

[0001262039-14-000033:mdna:9]
[same as prior period, unchanged from 0001262039-14-000025:mdna:10]

[0001262039-14-000033:mdna:10]
[same as prior period, unchanged from 0001262039-14-000025:mdna:11]

[0001262039-14-000033:mdna:11]
[same as prior period, unchanged from 0001262039-14-000025:mdna:12]

[0001262039-14-000033:mdna:12]
[same as prior period, unchanged from 0001262039-14-000025:mdna:13]

[0001262039-14-000033:mdna:13]
| • | expectations regarding spending related to capital expenditures, including improvements and expansion of our new corporate headquarters and other offices and the implementation of our enterprise resource planning system; |

[0001262039-14-000033:mdna:14]
| • | competition in our market segment; |

[0001262039-14-000033:mdna:15]
[same as prior period, unchanged from 0001262039-14-000025:mdna:14]

[0001262039-14-000033:mdna:16]
[same as prior period, unchanged from 0001262039-14-000025:mdna:15]

[0001262039-14-000033:mdna:17]
[same as prior period, unchanged from 0001262039-14-000025:mdna:16]

[0001262039-14-000033:mdna:18]
We provide high performance network security solutions, which enable broad, integrated and high performance protection against advanced security threats while simplifying the IT security infrastructure for enterprises, service providers and governmental entities worldwide. Since inception through June 30, 2014, we had shipped over 1,600,000 appliances via more than 28,000 channel partners to more than 200,000 end-customers worldwide, including a majority of the 2013 Fortune Global 100.

[0001262039-14-000033:mdna:19]
23

[0001262039-14-000033:mdna:20]
Our core product line, comprised of FortiGate physical and virtual appliances, ships with a set of broad security and networking capabilities, including firewall, virtual private network (VPN), application control, antivirus, intrusion prevention, Web filtering, vulnerability management, anti-spam, wireless controller, wide area network (WAN) acceleration and native internet protocol version 6 (IPv6) support functionality. Customers select the functions or combination of functions that best meet their specific security requirements - whether that be a high-speed data center firewall (DCFW) at the network core, a next-generation firewall (NGFW) at the edge, or a broad unified threat management (UTM) solution at branch sites. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -800 series for mid-sized enterprises, to the FortiGate-1000 to -5000 series for large enterprises, telecommunications carriers, and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to intrusion prevention, application control, anti-malware, Web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management, analysis and reporting capabilities. We complement our core FortiGate product line with other appliances and software that offer additional protection from security threats to other critical areas of the enterprise, such as our advanced persistent threats (APTs) sandboxing product, messaging security product, Web application firewalls, databases security product, distributed denial of service attack (DDoS) security product, and endpoint security product for employee computers and mobile devices. Sales of these complementary products and related services represent less than 10% of our total revenue.

[0001262039-14-000033:mdna:21]
[same as prior period, unchanged from 0001262039-14-000025:mdna:20]

[0001262039-14-000033:mdna:22]
| • | We recorded total revenue of $184.1 million and $353.0 million during the three and six months ended June 30, 2014, respectively. This represents an increase of 25% during each of these periods compared to the same periods last year. Product revenue was $85.4 million and $162.1 million, respectively, an increase of 28% and 30% during the three and six months ended June 30, 2014, respectively, compared to the same periods last year. Services and other revenue was $98.7 million and $190.9 million during the three and six months ended June 30, 2014, respectively, an increase of 22% and 20%, respectively, compared to the same periods last year. |

[0001262039-14-000033:mdna:23]
| • | Cash, cash equivalents and investments were $910.6 million as of June 30, 2014, an increase of $67.5 million from December 31, 2013. |

[0001262039-14-000033:mdna:24]
| • | Deferred revenue was $480.2 million as of June 30, 2014, an increase of $47.6 million from December 31, 2013. |

[0001262039-14-000033:mdna:25]
| • | We generated cash flows from operating activities of $104.7 million during the six months ended June 30, 2014, an increase of 39% compared to the same period last year. |

[0001262039-14-000033:mdna:26]
| • | We received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. during the six months ended June 30, 2014. |

[0001262039-14-000033:mdna:27]
| • | We repurchased 1.0 million shares of common stock under our previously-announced Share Repurchase Program for an aggregate purchase price of $22.5 million during the six months ended June 30, 2014. |

[0001262039-14-000033:mdna:28]
During the three and six months ended June 30, 2014, revenue grew as a result of our focus on growth and our strategy to invest in our marketing and increase sales capacity. We also continued to gain traction with several recently introduced FortiGate products, including demand for certain of our high speed, low latency next-generation enterprise data center security product.

[0001262039-14-000033:mdna:29]
We continue to invest in sales and marketing to expand brand awareness, our global sales team and distribution channels to expand our global reach and sales capacity and meet increasing customer expectations about the quality and functionality of our products, and research and development to strengthen our technology leadership position. We continue to focus on selling to large customers, such as enterprise and service providers. As a result, we experienced increased deal volumes driven by traction in enterprise data center deployments and large enterprise deals.

[0001262039-14-000033:mdna:30]
During the three months ended June 30, 2014, our high-end FortiGate products (FortiGate-1000 to -5000 series) accounted for 40% of billings primarily due to an increase in billings from large enterprise and service provider customers. Our mid-range products (FortiGate-200 to -800 series) accounted for 26% of billings, and our entry-level products (FortiGate-20 to -100 series) accounted for 34% of billings. In prior periods, sales of FortiGate products have generally been balanced across product categories, with some degree of variability from year to year and between quarters.

[0001262039-14-000033:mdna:31]
[same as prior period, unchanged from 0001262039-14-000025:mdna:31]

[0001262039-14-000033:mdna:32]
During the three and six months ended June 30, 2014, operating expenses increased by 28% and 29%, respectively, compared to the same periods last year. The increase was primarily driven by our accelerated pace of hiring and marketing investments to support our growth as we continued to invest in expanding our sales coverage, marketing capabilities, developing new products and scaling our customer support organization to meet the needs of our growing customer base. Headcount increased to 2,532 as of June 30, 2014 from 2,182 as of June 30, 2013.

[0001262039-14-000033:mdna:33]
[same as prior period, unchanged from 0001262039-14-000025:mdna:32]

[0001262039-14-000033:mdna:34]
We monitor the key financial metrics set forth below to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “—Results of Operations,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-14-000033:mdna:35]
|  | Three Months Ended Or As Of |
|  | June 30, 2014 |  | June 30, 2013 |
|  | (in thousands) |
| Revenue | $ | 184,098 |  |  | $ | 147,428 |  |
| Deferred revenue | $ | 480,202 |  |  | $ | 389,682 |  |
| Increase in deferred revenue | $ | 28,899 |  |  | $ | 13,268 |  |
| Billings (non-GAAP) | $ | 212,997 |  |  | $ | 160,696 |  |
| Cash, cash equivalents and investments | $ | 910,594 |  |  | $ | 814,410 |  |
| Net cash provided by operating activities | $ | 43,798 |  |  | $ | 37,221 |  |
| Free cash flow (non-GAAP) | $ | 34,094 |  |  | $ | 35,186 |  |

[0001262039-14-000033:mdna:36]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unamortized portion of services revenue from FortiGuard subscription and support service contracts. We monitor our deferred revenue balance because it represents a significant portion of revenue to be recognized in future periods.

[0001262039-14-000033:mdna:37]
Billings (Non-GAAP). We define billings as revenue recognized during a period plus the change in deferred revenue from the beginning to the end of the period less deferred revenue balances acquired from business combinations, if any. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically, represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from other companies that report similar financial measures. We compensate for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP. A reconciliation of billings to revenue, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000033:mdna:38]
|  | Three Months Ended |
| June 30, 2014 |  | June 30, 2013 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 184,098 |  |  | $ | 147,428 |  |
| Add increase in deferred revenue | 28,899 |  |  | 13,268 |  |
| Total billings (Non-GAAP) | $ | 212,997 |  |  | $ | 160,696 |  |

[0001262039-14-000033:mdna:39]
Free cash flow (Non-GAAP). Free cash flow is defined as net cash provided by operating activities less capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and

[0001262039-14-000033:mdna:40]
[same as prior period, unchanged from 0001262039-14-000025:mdna:39]

[0001262039-14-000033:mdna:41]
investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making acquisitions, repurchasing shares of our outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates comparisons of our operating results to competitors’ operating results. A limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash balance from operations for the period because it excludes cash used for capital expenditures. We compensate for this limitation by providing information about our capital expenditures on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-14-000033:mdna:42]
|  | Three Months Ended |
| June 30, 2014 |  | June 30, 2013 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 43,798 |  |  | $ | 37,221 |  |
| Less purchases of property and equipment | (9,704 | ) |  | (2,035 | ) |
| Free cash flow (Non-GAAP) | $ | 34,094 |  |  | $ | 35,186 |  |

[0001262039-14-000033:mdna:43]
Critical Accounting Policies and Estimates—Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expenses, cash flow and related disclosure of contingent assets and liabilities. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-14-000033:mdna:44]
There have been no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2014, as compared to the critical accounting policies and estimates described in the Form 10-K.

[0001262039-14-000033:mdna:45]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the condensed consolidated statements of operations. The combined amounts are now being presented as Services and other revenue in the condensed consolidated statements of operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material, and the reclassification did not have any impact on our gross margin or net income.

[0001262039-14-000033:mdna:46]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) ”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration the entity expects to be entitled to in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.

[0001262039-14-000033:mdna:47]
[same as prior period, unchanged from 0001262039-14-000025:mdna:50]

[0001262039-14-000033:mdna:48]
[same as prior period, unchanged from 0001262039-14-000025:mdna:52]

[0001262039-14-000033:mdna:49]
Three Months Ended June 30, 2014 and June 30, 2013

[0001262039-14-000033:mdna:50]
[same as prior period, unchanged from 0001262039-14-000025:mdna:53]

[0001262039-14-000033:mdna:51]
|  | Three Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 85,384 |  |  | 46 | % |  | $ | 66,525 |  |  | 45 | % |  | $ | 18,859 |  |  | 28 | % |
| Services and other | 98,714 |  |  | 54 |  |  | 80,903 |  |  | 55 |  |  | 17,811 |  |  | 22 |  |
| Total revenue | $ | 184,098 |  |  | 100 | % |  | $ | 147,428 |  |  | 100 | % |  | $ | 36,670 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 78,385 |  |  | 43 | % |  | $ | 60,026 |  |  | 41 | % |  | $ | 18,359 |  |  | 31 | % |
| EMEA | 62,554 |  |  | 34 |  |  | 50,801 |  |  | 34 |  |  | 11,753 |  |  | 23 |  |
| APAC | 43,159 |  |  | 23 |  |  | 36,601 |  |  | 25 |  |  | 6,558 |  |  | 18 |  |
| Total revenue | $ | 184,098 |  |  | 100 | % |  | $ | 147,428 |  |  | 100 | % |  | $ | 36,670 |  |  | 25 | % |

[0001262039-14-000033:mdna:52]
Total revenue increased by $36.7 million, or 25%, in the three months ended June 30, 2014 compared to the same period last year. All three regions experienced revenue growth compared to the same period last year, with Americas contributing the largest portion of our revenue growth. Product revenue increased by $18.9 million, or 28%, in the three months ended June 30, 2014, compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories, particularly in our high-end products including our recently introduced FortiGate 1500D and 3700D enterprise security appliances.

[0001262039-14-000033:mdna:53]
Services and other revenue increased by $17.8 million, or 22%, in the three months ended June 30, 2014 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard subscription and support contracts sold to a larger customer base. In addition, we experienced growth in our FortiGuard subscription offerings, FortiCare support, and our professional services revenues from existing large enterprise customers.

[0001262039-14-000033:mdna:54]
Cost of revenue and Gross margin

[0001262039-14-000033:mdna:55]
|  | Three Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 37,455 |  |  | $ | 26,948 |  |  | $ | 10,507 |  |  | 39 | % |
| Services and other | 20,302 |  |  | 16,760 |  |  | 3,542 |  |  | 21 |  |
| Total cost of revenue | $ | 57,757 |  |  | $ | 43,708 |  |  | $ | 14,049 |  |  | 32 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 56.1 | % |  | 59.5 | % |  | (3.4 | )% |  |  |
| Services and other | 79.4 |  |  | 79.3 |  |  | 0.1 |  |  |  |
| Total gross margin | 68.6 | % |  | 70.4 | % |  | (1.8 | )% |  |  |

[0001262039-14-000033:mdna:56]
Total gross margin decreased by 1.8 percentage points in the three months ended June 30, 2014 compared to the same period last year, as product gross margin declined. Product gross margin decreased by 3.4 percentage points in the three months ended June 30, 2014 compared to the same period last year primarily due to a $2.4 million impairment charge related to certain intangible assets. We also experienced higher warranty-related costs of $1.0 million and higher excess inventory write-offs of $0.3 million. Services and other gross margin increased by 0.1 percentage points during the three months ended June 30, 2014

[0001262039-14-000033:mdna:57]
as our continued investments in our technical support and global threat research organizations were relatively in line with our rate of growth of services and other revenue. Cost of services and other revenue increased by $3.5 million primarily due to a $1.7 million increase in personnel costs related to headcount increases and a $1.0 million increase in depreciation and occupancy-related costs.

[0001262039-14-000033:mdna:58]
[same as prior period, unchanged from 0001262039-14-000025:mdna:61]

[0001262039-14-000033:mdna:59]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2014 |  | June 30, 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 29,938 |  |  | 16 | % |  | $ | 25,158 |  |  | 17 | % |  | $ | 4,780 |  |  | 19 | % |
| Sales and marketing | 74,817 |  |  | 41 |  |  | 55,997 |  |  | 38 |  |  | 18,820 |  |  | 34 |  |
| General and administrative | 10,444 |  |  | 6 |  |  | 8,788 |  |  | 6 |  |  | 1,656 |  |  | 19 |  |
| Total operating expenses | $ | 115,199 |  |  | 63 | % |  | $ | 89,943 |  |  | 61 | % |  | $ | 25,256 |  |  | 28 | % |

[0001262039-14-000033:mdna:60]
[same as prior period, unchanged from 0001262039-14-000025:mdna:63]

[0001262039-14-000033:mdna:61]
Research and development expense increased by $4.8 million, or 19%, in the three months ended June 30, 2014 compared to the same period last year primarily due to an increase of $2.2 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, we incurred higher product development expenses, such as third-party testing, prototypes and supplies, of $1.6 million, higher depreciation and occupancy-related costs of $1.3 million, and higher stock-based compensation expense of $0.9 million. This increase in expense was partially offset by a $0.7 million reversal of estimated contingent consideration. We intend to continue to invest in our research and development organization but expect research and development expense as a percentage of total revenue to remain at similar levels during the remainder of fiscal 2014.

[0001262039-14-000033:mdna:62]
[same as prior period, unchanged from 0001262039-14-000025:mdna:65]

[0001262039-14-000033:mdna:63]
Sales and marketing expense increased by $18.8 million, or 34%, in the three months ended June 30, 2014 compared to the same period last year, primarily due to an increase of $12.3 million in personnel costs as we continued to increase our headcount in order to drive continued market share gains. In addition, we incurred increases in tradeshows, lead generation campaigns and marketing-related expenses of $3.7 million. Our stock-based compensation expense increased by $1.2 million, depreciation expense and occupancy-related costs increased by $0.9 million and marketing supplies expense increased by $0.6 million. As a percentage of revenue, sales and marketing expenses increased as we are accelerating the investment in our sales force and marketing campaigns to drive future growth. We intend to continue to make investments in sales and marketing and expect sales and marketing expense as a percentage of total revenue to remain at similar levels or increase during the remainder of fiscal 2014.

[0001262039-14-000033:mdna:64]
[same as prior period, unchanged from 0001262039-14-000025:mdna:69]

[0001262039-14-000033:mdna:65]
General and administrative expense increased by $1.7 million, or 19%, in the three months ended June 30, 2014 compared to the same period last year. Stock-based compensation expense increased by $1.8 million and personnel costs increased by $0.6 million as we continued to increase our headcount in order to support our expanding business. This increase was partially offset by a decrease in legal fees of $0.5 million. We expect general and administrative expense as a percentage of total revenue to remain at similar levels during the remainder of fiscal 2014.

[0001262039-14-000033:mdna:66]
[same as prior period, unchanged from 0001262039-14-000025:mdna:67]

[0001262039-14-000033:mdna:67]
Interest income and Other expense—net

[0001262039-14-000033:mdna:68]
|  | Three Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Interest income | $ | 1,319 |  |  | $ | 1,337 |  |  | $ | (18 | ) |  | (1 | )% |
| Other expense—net | (574 | ) |  | (100 | ) |  | (474 | ) |  | 474 |  |

[0001262039-14-000033:mdna:69]
Interest income decreased in the three months ended June 30, 2014 compared to the same period last year due to lower interest earned despite higher invested balances of cash, cash equivalents and investments. The change in other expense—net, for the three months ended June 30, 2014 when compared to the same period last year, was the result of higher foreign exchange losses, partially offset by gains on forward contracts.

[0001262039-14-000033:mdna:70]
[same as prior period, unchanged from 0001262039-14-000025:mdna:74]

[0001262039-14-000033:mdna:71]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2014 |  | June 30, 2013 |  |
| (in thousands except percentages) |
| Provision for income taxes | $ | 5,806 |  |  | $ | 6,035 |  |  | $ | (229 | ) |  | (4 | )% |
| Effective tax rate | 49 | % |  | 40 | % |  | 9 | % |  | — | % |

[0001262039-14-000033:mdna:72]
Our effective tax rate was 49% for the three months ended June 30, 2014, compared to 40% for the same period last year. The provision for income taxes for the three months ended June 30, 2014 was comprised primarily of U.S. federal and state taxes, Singapore and other foreign income taxes, and withholding tax, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate for the three months ended June 30, 2014 as compared to the same period last year was primarily due to a change in the mix of profitability between jurisdictions, an increase in non-tax deductible stock-based compensation expense, limitations on utilizing foreign tax credits, and expiration of the U.S. federal research and development credit effective December 31, 2013. The U.S. Congress has not extended the research and development tax credit as of June 30, 2014.

[0001262039-14-000033:mdna:73]
It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of June 30, 2014, we had accrued approximately $1.4 million for estimated interest related to uncertain tax positions.

[0001262039-14-000033:mdna:74]
[same as prior period, unchanged from 0001262039-14-000025:mdna:79]

[0001262039-14-000033:mdna:75]
29

[0001262039-14-000033:mdna:76]
Six Months Ended June 30, 2014 and June 30, 2013

[0001262039-14-000033:mdna:77]
Revenue

[0001262039-14-000033:mdna:78]
|  | Six Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 162,149 |  |  | 46 | % |  | $ | 124,475 |  |  | 44 | % |  | $ | 37,674 |  |  | 30 | % |
| Services and other | 190,898 |  |  | 54 |  |  | 158,773 |  |  | 56 |  |  | 32,125 |  |  | 20 |  |
| Total revenue | $ | 353,047 |  |  | 100 | % |  | $ | 283,248 |  |  | 100 | % |  | $ | 69,799 |  |  | 25 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 150,817 |  |  | 43 | % |  | $ | 112,653 |  |  | 40 | % |  | $ | 38,164 |  |  | 34 | % |
| EMEA | 119,197 |  |  | 34 |  |  | 98,127 |  |  | 35 |  |  | 21,070 |  |  | 21 |  |
| APAC | 83,033 |  |  | 23 |  |  | 72,468 |  |  | 25 |  |  | 10,565 |  |  | 15 |  |
| Total revenue | $ | 353,047 |  |  | 100 |  |  | $ | 283,248 |  |  | 100 | % |  | $ | 69,799 |  |  | 25 | % |

[0001262039-14-000033:mdna:79]
Total revenue increased by $69.8 million, or 25%, in the six months ended June 30, 2014 compared to the same period last year. All three regions experienced revenue growth compared to the same period last year, with Americas contributing the largest portion of our revenue growth. Product revenue increased by $37.7 million, or 30%, in the six months ended June 30, 2014, compared to the same period last year. The increase in product revenue was primarily driven by greater sales volume in our FortiGate product family due to increased demand across all product categories, particularly in our high-end products including our recently introduced FortiGate 1500D and 3700D enterprise security appliances.

[0001262039-14-000033:mdna:80]
Services and other revenue increased by $32.1 million, or 20%, in the six months ended June 30, 2014 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard subscription and support contracts sold to a larger customer base. In addition, we experienced growth in our FortiGuard subscription offerings, FortiCare support, and our professional services revenues from existing large enterprise customers.

[0001262039-14-000033:mdna:81]
Cost of revenue and Gross margin

[0001262039-14-000033:mdna:82]
|  | Six Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 69,594 |  |  | $ | 49,906 |  |  | $ | 19,688 |  |  | 39 | % |
| Services and other | 38,906 |  |  | 32,930 |  |  | 5,976 |  |  | 18 |  |
| Total cost of revenue | $ | 108,500 |  |  | $ | 82,836 |  |  | $ | 25,664 |  |  | 31 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 57.1 | % |  | 59.9 | % |  | (2.8 | )% |  |  |
| Services and other | 79.6 |  |  | 79.3 |  |  | 0.3 |  |  |  |
| Total gross margin | 69.3 | % |  | 70.8 | % |  | (1.5 | )% |  |  |

[0001262039-14-000033:mdna:83]
Total gross margin decreased by 1.5 percentage points in the six months ended June 30, 2014 compared to the same period last year, as product gross margin declined. Product gross margin decreased by 2.8 percentage points in the six months ended June 30, 2014 compared to the same period last year primarily due to a $2.4 million impairment charge related to certain intangible assets. In addition, warranty-related costs increased by $1.3 million, excess inventory write-offs increased by $1.3 million, and personnel costs increased by $0.5 million. Services and other gross margin increased by 0.3 percentage points during the six months ended June 30, 2014 as our continued investments in our technical support and global threat research organizations were relatively in line with our rate of growth of services and other revenue. Cost of services and other revenue

[0001262039-14-000033:mdna:84]
[same as prior period, unchanged from 0001262039-14-000025:mdna:85]

[0001262039-14-000033:mdna:85]
increased by $6.0 million primarily due to a $3.5 million increase in personnel costs related to headcount increases and a $1.4 million increase in depreciation and occupancy-related costs.

[0001262039-14-000033:mdna:86]
Operating expenses

[0001262039-14-000033:mdna:87]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2014 |  | June 30, 2013 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 58,993 |  |  | 17 | % |  | $ | 48,492 |  |  | 17 | % |  | $ | 10,501 |  |  | 22 | % |
| Sales and marketing | 142,143 |  |  | 40 |  |  | 105,973 |  |  | 37 |  |  | 36,170 |  |  | 34 |  |
| General and administrative | 19,454 |  |  | 6 |  |  | 16,779 |  |  | 6 |  |  | 2,675 |  |  | 16 |  |
| Total operating expenses | $ | 220,590 |  |  | 62 | % |  | $ | 171,244 |  |  | 60 | % |  | $ | 49,346 |  |  | 29 | % |

[0001262039-14-000033:mdna:88]
Research and development

[0001262039-14-000033:mdna:89]
Research and development expense increased by $10.5 million, or 22%, in the six months ended June 30, 2014 compared to the same period last year primarily due to an increase of $5.3 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. In addition, we incurred higher product development expenses, such as third-party testing, prototypes and supplies, of $3.8 million and higher stock-based compensation expense of $2.0 million, and higher depreciation and occupancy-related costs of $1.8 million. This increase in expense was partially offset by a $1.9 million reversal of estimated contingent consideration.

[0001262039-14-000033:mdna:90]
Sales and marketing

[0001262039-14-000033:mdna:91]
Sales and marketing expense increased by $36.2 million, or 34%, in the six months ended June 30, 2014 compared to the same period last year, primarily due to an increase of $24.0 million in personnel costs as we continued to increase our headcount in order to drive continued market share gains. We also increased marketing-related expenses by $5.6 million as we invested in tradeshows and lead generation campaigns. In addition, we incurred increases in stock-based compensation of $2.8 million, depreciation and occupancy-related costs of $1.3 million, travel expense of $1.0 million and marketing supplies of $0.8 million. As a percentage of revenue, sales and marketing expenses increased as we are accelerating the investment in our sales force and marketing campaigns to drive future growth.

[0001262039-14-000033:mdna:92]
General and administrative

[0001262039-14-000033:mdna:93]
General and administrative expense increased by $2.7 million, or 16%, in the six months ended June 30, 2014 compared to the same period last year. Stock-based compensation expense increased by $2.3 million and personnel costs increased by $1.6 million as we continued to increase our headcount in order to support our expanding business. The increase in expense was partially offset by a decrease of $0.7 million in legal fees and $0.6 million in other expenses.

[0001262039-14-000033:mdna:94]
Interest income and Other (expense) income—net

[0001262039-14-000033:mdna:95]
|  | Six Months Ended |  |  |  |  |
| June 30, 2014 |  | June 30, 2013 |  | Change |  | % Change |
| (in thousands except percentages) |
| Interest income | $ | 2,652 |  |  | $ | 2,706 |  |  | $ | (54 | ) |  | (2 | )% |
| Other (expense) income—net | (963 | ) |  | 115 |  |  | (1,078 | ) |  | (937 | ) |

[0001262039-14-000033:mdna:96]
Interest income decreased in the six months ended June 30, 2014 compared to the same period last year due to lower interest earned despite higher invested balances of cash, cash equivalents and investments. The change in other (expense) income—net, for the six months ended June 30, 2014 when compared to the same period last year, was the result of higher foreign exchange losses, partially offset by gains on forward contracts.

[0001262039-14-000033:mdna:97]
31

[0001262039-14-000033:mdna:98]
Provision for income taxes

[0001262039-14-000033:mdna:99]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2014 |  | June 30, 2013 |  |
| (in thousands except percentages) |
| Provision for income taxes | $ | 11,172 |  |  | $ | 10,761 |  |  | $ | 411 |  |  | 4 | % |
| Effective tax rate | 44 | % |  | 34 | % |  | 10 | % |  | — | % |

[0001262039-14-000033:mdna:100]
Our effective tax rate was 44% for the six months ended June 30, 2014, compared to 34% for the same period last year. The provision for income taxes for the six months ended June 30, 2014 was comprised primarily of U.S. federal and state taxes, Singapore and other foreign income taxes, and withholding tax, as well as the inclusion of stock compensation benefits and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The increase in the effective tax rate for the six months ended June 30, 2014 as compared to the same period last year was primarily due to a change in the mix of profitability between jurisdictions, an increase in non-tax deductible stock-based compensation expense, limitations on utilizing foreign tax credits, and expiration of the U.S. federal research and development credit effective December 31, 2013.

[0001262039-14-000033:mdna:101]
[same as prior period, unchanged from 0001262039-14-000025:mdna:80]

[0001262039-14-000033:mdna:102]
|  | June 30, 2014 |  | December 31, 2013 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 203,947 |  |  | $ | 115,873 |  |
| Investments | 706,647 |  |  | 727,172 |  |
| Total cash, cash equivalents and investments | $ | 910,594 |  |  | $ | 843,045 |  |
| Working capital | $ | 380,861 |  |  | $ | 322,485 |  |
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
|  | (in thousands) |
| Net cash provided by operating activities | $ | 104,700 |  |  | $ | 75,332 |  |
| Net cash used in investing activities | (8,299 | ) |  | (91,514 | ) |
| Net cash (used in) provided by financing activities | (7,727 | ) |  | 17,484 |  |
| Effect of exchange rates on cash and cash equivalents | (600 | ) |  | (809 | ) |
| Net increase in cash and cash equivalents | $ | 88,074 |  |  | $ | 493 |  |

[0001262039-14-000033:mdna:103]
Liquidity and capital resources may be impacted by our operating activities, as well as acquisitions, capital expenditures and investments in strategic relationships that we have made or may make in the future. During the six months ended June 30, 2014, we received a cash payment of $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. We expect to spend up to $20.0 million related to our capital expenditures, primarily related to the improvement and expansion of our corporate headquarters and other offices, as well as the implementation of our enterprise resource planning system during the remainder of fiscal 2014. Additionally, our liquidity may be impacted if we were to repurchase additional shares of our outstanding common stock under our Share Repurchase Program. As of June 30, 2014, $138.6 million remained available for future share repurchases under this program, which will be financed through our available working capital.

[0001262039-14-000033:mdna:104]
As of June 30, 2014, our cash, cash equivalents and investments of $910.6 million were held for working-capital purposes and were invested primarily in corporate debt securities, commercial paper, municipal bonds, certificates of deposit and term deposits, money market funds, and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return.

[0001262039-14-000033:mdna:105]
32

[0001262039-14-000033:mdna:106]
As of June 30, 2014, $180.5 million of our cash and investments was held by our international subsidiaries and is therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, it would be subject to U.S. federal income tax which would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products, share repurchases, and future capital expenditures related to real estate and infrastructure. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases, and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-14-000033:mdna:107]
[same as prior period, unchanged from 0001262039-14-000025:mdna:86]

[0001262039-14-000033:mdna:108]
[same as prior period, unchanged from 0001262039-14-000025:mdna:87]

[0001262039-14-000033:mdna:109]
Our operating activities during the six months ended June 30, 2014 provided $104.7 million in cash as a result of our growth in billings, profitability, and the ability to successfully manage our working capital. The primary sources of cash from operating activities during the six months ended June 30, 2014 consisted of net income of $14.5 million increased by non-cash adjustments of $44.4 million and changes in operating assets and liabilities of $45.8 million. During the six months ended June 30, 2014, we received $20.0 million pursuant to a six year mutual covenant-not-to-sue and release agreement with Palo Alto Networks, Inc. Changes in operating assets and liabilities primarily included an increase in payments received from customers and a receipt of cash related to the mutual covenant-not-to-sue and release agreement, partially offset by payment of income taxes during the period.

[0001262039-14-000033:mdna:110]
Our operating activities during the six months ended June 30, 2013 provided $75.3 million in cash. The primary sources of cash from operating activities during the six months ended June 30, 2013 consisted of net income of $21.2 million increased by non-cash adjustments of $30.4 million and changes in operating assets and liabilities of $23.7 million. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by payment for inventory purchases.

[0001262039-14-000033:mdna:111]
[same as prior period, unchanged from 0001262039-14-000025:mdna:90]

[0001262039-14-000033:mdna:112]
[same as prior period, unchanged from 0001262039-14-000025:mdna:91]

[0001262039-14-000033:mdna:113]
During the six months ended June 30, 2014, cash used was primarily due to $21.0 million for our capital expenditures, partially offset by positive cash flow due to maturities, net of purchases, from our investments of $12.7 million.

[0001262039-14-000033:mdna:114]
During the six months ended June 30, 2013, cash used was primarily due to $82.0 million net purchases of investments, $6.0 million for acquisitions, and $3.6 million for the purchases of property and equipment.

[0001262039-14-000033:mdna:115]
[same as prior period, unchanged from 0001262039-14-000025:mdna:94]

[0001262039-14-000033:mdna:116]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation, and repurchase and retirement of common stock.

[0001262039-14-000033:mdna:117]
During the six months ended June 30, 2014, we used $27.2 million and $5.5 million of our cash to repurchase and retire our common stock and pay taxes related to withholding upon the issuance of restricted stock units, respectively.  This cash outflow was partially offset by proceeds of $22.5 million from the issuance of common stock under our stock plans, as well as excess tax benefit from employee stock-based compensation of $2.4 million.

[0001262039-14-000033:mdna:118]
During the six months ended June 30, 2013, we had positive cash flow of $17.5 million as a result of proceeds of $15.6 million from the issuance of common stock under our stock plans and an excess tax benefit from employee stock option exercises of $1.9 million.

[0001262039-14-000033:mdna:119]
[same as prior period, unchanged from 0001262039-14-000025:mdna:98]

[0001262039-14-000033:mdna:120]
There have been no material changes outside the ordinary course of business during the six months ended June 30, 2014, to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K.

[0001262039-14-000033:mdna:121]
[same as prior period, unchanged from 0001262039-14-000025:mdna:100]

[0001262039-14-000033:mdna:122]
As of June 30, 2014, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
