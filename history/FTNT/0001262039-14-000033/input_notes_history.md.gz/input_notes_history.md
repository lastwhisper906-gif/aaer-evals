# FTNT note change history — 0001262039-14-000025 → 0001262039-14-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001262039-14-000033:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2014 (in thousands):
  (was, 2014-05-07, similarity 0.9577):
[0001262039-14-000025:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2014 (in thousands):

- changed (2014-08-05):
[0001262039-14-000033:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 34,431 |  |  | $ | 4,905 |  |  | $ | 7,814 |  |  | $ | 6,120 |  |  | $ | 5,190 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |
| Less: Sublease rental income | 876 |  |  | 404 |  |  | 472 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 33,555 |  |  | 4,501 |  |  | 7,342 |  |  | 6,120 |  |  | 5,190 |  |  | 3,966 |  |  | 6,436 |  |
| Purchase commitments | 46,379 |  |  | 46,379 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments | 15,987 |  |  | 12,131 |  |  | 2,717 |  |  | 743 |  |  | 396 |  |  | — |  |  | — |  |
| Total | $ | 95,921 |  |  | $ | 63,011 |  |  | $ | 10,059 |  |  | $ | 6,863 |  |  | $ | 5,586 |  |  | $ | 3,966 |  |  | $ | 6,436 |  |
  (was, 2014-05-07, similarity 0.7429):
[0001262039-14-000025:note_history:2]
|  | Total |  | 2014 (remainder) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |
| Operating lease commitments | $ | 31,592 |  |  | $ | 6,543 |  |  | $ | 6,547 |  |  | $ | 5,385 |  |  | $ | 4,639 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |
| Less: Sublease rental income | 1,040 |  |  | 585 |  |  | 455 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating lease commitments—net | 30,552 |  |  | 5,958 |  |  | 6,092 |  |  | 5,385 |  |  | 4,639 |  |  | 3,649 |  |  | 4,829 |  |
| Purchase commitments | 38,880 |  |  | 38,880 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contract commitments | 24,182 |  |  | 18,502 |  |  | 3,914 |  |  | 889 |  |  | 877 |  |  | — |  |  | — |  |
| Total | $ | 93,614 |  |  | $ | 63,340 |  |  | $ | 10,006 |  |  | $ | 6,274 |  |  | $ | 5,516 |  |  | $ | 3,649 |  |  | $ | 4,829 |  |

- changed (2014-08-05):
[0001262039-14-000033:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.4 million during the three months ended June 30, 2014 and June 30, 2013. Rent expense was $5.1 million and $4.7 million during the six months ended June 30, 2014 and June 30, 2013, respectively.
  (was, 2014-05-07, similarity 0.6988):
[0001262039-14-000025:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2020. The terms of certain operating leases provide for renewal options. Future minimum payments under the non-cancelable operating leases totaled $31.6 million as of March 31, 2014. Rent expense is recognized using the straight-line method over the term of the lease. Rent expense was $2.7 million and $2.3 million during the three months ended March 31, 2014 and March 31, 2013, respectively.

- changed (2014-08-05):
[0001262039-14-000033:note_history:4]
Purchase Commitments and Other Contractual Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2014, we had $46.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2014-05-07, similarity 0.9409):
[0001262039-14-000025:note_history:4]
Contract Manufacturer and Other Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2014, we had $38.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2014-08-05):
[0001262039-14-000033:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2014, we had $16.0 million in other purchase commitments.
  (was, 2014-05-07, similarity 0.9828):
[0001262039-14-000025:note_history:5]
In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2014, we had $24.2 million in other purchase commitments.

- changed (2014-08-05):
[0001262039-14-000033:note_history:6]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (1,728 | ) |  | (1,744 | ) |
| Provision for warranty for the period | 2,560 |  |  | 2,204 |  |
| Adjustment related to pre-existing warranties | (415 | ) |  | 208 |  |
| Accrued warranty balance—end of the period | $ | 3,454 |  |  | $ | 2,977 |  |
  (was, 2014-05-07, similarity 0.608):
[0001262039-14-000025:note_history:6]
|  | Three Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Accrued warranty balance—beginning of the period | $ | 3,037 |  |  | $ | 2,309 |  |
| Warranty costs incurred | (756 | ) |  | (759 | ) |
| Provision for warranty for the period, including warranty liabilities assumed in connection with an acquisition | 837 |  |  | 674 |  |
| Changes in prior period estimates | (313 | ) |  | 60 |  |
| Accrued warranty balance—end of the period | $ | 2,805 |  |  | $ | 2,284 |  |

- changed (2014-08-05):
[0001262039-14-000033:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.
  (was, 2014-05-07, similarity 0.9745):
[0001262039-14-000025:note_history:7]
Litigation—We are involved in disputes, litigation, and other legal actions. We are defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation or substantial settlement charges. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any material accrual for loss contingencies associated with such legal proceedings; determined that an unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- changed (2014-08-05):
[0001262039-14-000033:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.
  (was, 2014-05-07, similarity 0.9988):
[0001262039-14-000025:note_history:8]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting infringement of certain intellectual property rights, which may include patents, copyrights, trademarks, or trade secrets, and to pay judgments entered on such claims. Our exposure under these indemnification provisions is generally limited by the terms of our contracts to the total amount paid by our customer under the agreement. However, certain agreements include indemnification provisions beyond indemnification for third party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement. To date, there have been no awards under such indemnification provisions.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-05):
[0001262039-14-000033:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.
  (was, 2014-05-07, similarity 0.9752):
[0001262039-14-000025:note_history:9]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us,” or “our”) have been prepared in accordance with generally accepted accounting principles (“GAAP”) in the United States (“U.S.”) for interim financial information as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended December 31, 2013, contained in our Annual Report on Form 10-K (“Form 10-K”) filed with the SEC on March 3, 2014. In the opinion of management, all adjustments, which includes normal recurring adjustments, except as otherwise noted, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2014 are not necessarily indicative of the operating results for any subsequent quarter, for the full year or for any future periods. The condensed consolidated balance sheets as of December 31, 2013 are derived from the audited consolidated financial statements for the year ended December 31, 2013.

- changed (2014-08-05):
[0001262039-14-000033:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2014.  During the first quarter of fiscal 2014, we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements, and furniture and fixtures.
  (was, 2014-05-07, similarity 0.8547):
[0001262039-14-000025:note_history:10]
There have been no material changes to our significant accounting policies for the three months ended March 31, 2014. During the quarter we prospectively modified the expected term calculation used in accounting for stock-based compensation expense and the estimated useful lives of building improvements and furniture and fixtures.

- changed (2014-08-05):
[0001262039-14-000033:note_history:11]
Property and Equipment—Property and equipment—net is stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:
  (was, 2014-05-07, similarity 0.9739):
[0001262039-14-000025:note_history:11]
Property and Equipment—Property and equipment are stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets as follows:

- changed (2014-08-05):
[0001262039-14-000033:note_history:12]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment and software | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |
  (was, 2014-05-07, similarity 0.9681):
[0001262039-14-000025:note_history:12]
|  | Estimated Useful Lives |
| Building and building improvements | 20 years |
| Evaluation units | 1 year |
| Computer equipment, software and tooling | 1-2 years |
| Furniture and fixtures | 3 - 5 years |
| Leasehold improvements | Shorter of useful life or lease term |

- changed (2014-08-05):
[0001262039-14-000033:note_history:13]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the condensed consolidated statements of operations. The combined amounts are now being presented as Services and other revenue in the condensed consolidated statements of operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material, and the reclassification did not have any impact on our gross margin or net income.
  (was, 2014-05-07, similarity 0.9359):
[0001262039-14-000025:note_history:13]
Reclassification—Beginning in the first quarter of 2014, the amounts previously reported as Ratable and other revenue have been combined with the amounts previously reported as Services revenue in the Condensed Consolidated Statements of Operations. The combined amounts are being presented as Services and other revenue in the Condensed Consolidated Statements of Operations. The related Cost of revenue and Gross profit, including prior period amounts, have also been combined to conform to the current period presentation.  The Ratable and other revenue amounts, including the related Cost of revenue and Gross profit amounts, are not material.

- added (2014-08-05):
[0001262039-14-000033:note_history:14]
Recent Accounting Pronouncement—In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers (“ASU 2014-09”) to create a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with U.S. GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. ASU 2014-09 is effective for us beginning on January 1, 2017. We are currently evaluating the impact of ASU 2014-09 on our consolidated financial statements.
