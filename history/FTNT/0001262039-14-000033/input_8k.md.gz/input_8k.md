# FTNT 8-K — 0001262039-14-000030 filed 2014-07-23

## item codes, every 8-K on or before 2014-08-05

- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2014-08-05

- none on or before 2014-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001262039-14-000030:8k_2_02:1]
EX-99.1
2
ftntq2-2014ex991.htm
PRESS RELEASE

[0001262039-14-000030:8k_2_02:2]
FTNT Q2-2014 EX 99.1

[0001262039-14-000030:8k_2_02:3]
Press Release

[0001262039-14-000030:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Chris McKie |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-486-5406 |
| mspolver@fortinet.com |  | cmckie@fortinet.com |

[0001262039-14-000030:8k_2_02:5]
Fortinet Reports Strong Second Quarter 2014 Financial Results:

[0001262039-14-000030:8k_2_02:6]
Billings Grow 33% and Revenues Grow 25% Year-Over-Year

[0001262039-14-000030:8k_2_02:7]
•Billings of $213.0 million, up 33% year over year1

[0001262039-14-000030:8k_2_02:8]
•Revenues of $184.1 million, up 25% year over year

[0001262039-14-000030:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.111

[0001262039-14-000030:8k_2_02:10]
| • | Cash, cash equivalents and investments of $910.6 million2, with no debt |

[0001262039-14-000030:8k_2_02:11]
| • | Deferred revenue of $480.2 million, up 23% year over year |

[0001262039-14-000030:8k_2_02:12]
SUNNYVALE, Calif. - July 23, 2014 - Fortinet® (NASDAQ: FTNT), a global leader in high-performance network security, today announced financial results for the second quarter ended June 30, 2014.

[0001262039-14-000030:8k_2_02:13]
“Our strong second quarter results highlight that our growth strategy is working and our sales and marketing investments are paying off, especially in the high-end enterprise where we saw significant traction with large deals over $500,000 growing 95 percent year over year" said Ken Xie, founder, chairman and chief executive officer.  “Our ability to exceed expectations across all operating metrics during Q2 was driven by the combination of superior sales execution, improved marketing, and strong demand for new high-performance enterprise products. With continued focused execution and an exciting portfolio of new products that further strengthen our competitive advantage, we believe Fortinet remains well-positioned for growth and market share gains.”

[0001262039-14-000030:8k_2_02:14]
Financial Highlights for the Second Quarter of 2014

[0001262039-14-000030:8k_2_02:15]
| • | Billings1: Total billings were $213.0 million for the second quarter of 2014, an increase of 33% compared to $160.7 million in the same quarter of 2013. |

[0001262039-14-000030:8k_2_02:16]
| • | Revenue3: Total revenue was $184.1 million for the second quarter of 2014, an increase of 25% compared to $147.4 million in the same quarter of 2013. Within total revenue, product revenue was $85.4 million, an increase of 28% compared to the same quarter of |

[0001262039-14-000030:8k_2_02:17]
2013.  Services and other revenue was $98.7 million, an increase of 22% compared to the same quarter of 2013.

[0001262039-14-000030:8k_2_02:18]
| • | Deferred Revenue: Total deferred revenue was $480.2 million as of June 30, 2014, an increase of 23% compared to deferred revenue of $389.7 million as of June 30, 2013, and an increase of $28.9 million from $451.3 million as of March 31, 2014. |

[0001262039-14-000030:8k_2_02:19]
| • | Cash and Cash Flow2: As of June 30, 2014, cash, cash equivalents and investments were $910.6 million, compared to $888.3 million as of March 31, 2014. In the second quarter of 2014, cash flow from operations was $43.8 million and free cash flow1 was $34.1 million. |

[0001262039-14-000030:8k_2_02:20]
| • | GAAP Operating Income: GAAP operating income was $11.1 million for the second quarter of 2014, representing a GAAP operating margin of 6%. GAAP operating income was $13.8 million for the same quarter of 2013, representing a GAAP operating margin of 9.0%. |

[0001262039-14-000030:8k_2_02:21]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $6.1 million for the second quarter of 2014, compared to GAAP net income of $9.0 million for the same quarter of 2013. GAAP diluted net income per share was $0.04 for the second quarter of 2014, compared to $0.05 for the same quarter of 2013. |

[0001262039-14-000030:8k_2_02:22]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $28.7 million for the second quarter of 2014, representing a non-GAAP operating margin of 16%. Non-GAAP operating income was $24.8 million for the same quarter of 2013, representing a non-GAAP operating margin of 17%. |

[0001262039-14-000030:8k_2_02:23]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $18.6 million for the second quarter of 2014, compared to non-GAAP net income of $17.5 million for the same quarter of 2013. Non-GAAP diluted net income per share was $0.11 for the second quarter of 2014 , compared to $0.10 for the same quarter of 2013. |

[0001262039-14-000030:8k_2_02:24]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-14-000030:8k_2_02:25]
2 During the second quarter of fiscal 2014, we repurchased $14.9 million of our common stock under our share repurchase program.

[0001262039-14-000030:8k_2_02:26]
3 Beginning in the first quarter of 2014, we combined ratable and other revenue with services revenue to present the combined amounts as services and other revenue in the condensed consolidated statements of operations. The related cost of revenue and gross profit, including prior period amounts, have also been combined to conform to the current period presentation. We believe the ratable and other revenue amounts, including the related cost of revenue and gross profit amounts, are not material.

[0001262039-14-000030:8k_2_02:27]
Conference Call Details

[0001262039-14-000030:8k_2_02:28]
Fortinet will host a conference call today, July 23, 2014, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results.  To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 72208196. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at

[0001262039-14-000030:8k_2_02:29]
http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through July 30, 2014, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 72208196.

[0001262039-14-000030:8k_2_02:30]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 72216231. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through July 30, 2014 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 72216231.

[0001262039-14-000030:8k_2_02:31]
About Fortinet

[0001262039-14-000030:8k_2_02:32]
Fortinet (NASDAQ: FTNT) is a worldwide provider of network security appliances and a market leader in unified threat management (UTM). Our products and services provide broad, integrated and high-performance protection against dynamic security threats while simplifying the IT security infrastructure. Our customers include enterprises, service providers and government entities worldwide, including the majority of the 2013 Fortune Global 100. Fortinet's flagship FortiGate product delivers ASIC-accelerated performance and integrates multiple layers of security designed to help protect against application and network threats. Fortinet's broad product line goes beyond UTM to help secure the extended enterprise -- from endpoints, to the perimeter and the core, including databases and applications. Fortinet is headquartered in Sunnyvale, Calif., with offices around the world.

[0001262039-14-000030:8k_2_02:33]
#          #          #

[0001262039-14-000030:8k_2_02:34]
Copyright © 2014 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-14-000030:8k_2_02:35]
FTNT-F

[0001262039-14-000030:8k_2_02:36]
Forward-looking Statements

[0001262039-14-000030:8k_2_02:37]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding the momentum in our business, growth of our business, and market share gains. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks in different geographies and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product

[0001262039-14-000030:8k_2_02:38]
Non-GAAP Financial Measures

[0001262039-14-000030:8k_2_02:39]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with other companies in our industry, many of which present similar non-GAAP financial measures to investors.

[0001262039-14-000030:8k_2_02:40]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures below. As previously mentioned, a reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included below in this press release.

[0001262039-14-000030:8k_2_02:41]
Billings. We define billings as revenue recognized plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive deferred revenue, which is an important indicator of the health and visibility of our business, and has historically represented a majority of the quarterly revenue that we recognize. There are a number of limitations related to the use of billings versus revenue calculated in accordance with GAAP. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from other companies that report similar financial measures. Management compensates for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with revenues calculated in accordance with GAAP.

[0001262039-14-000030:8k_2_02:42]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management's comparisons of our operating results to competitors' operating results. A

[0001262039-14-000030:8k_2_02:43]
limitation of using free cash flow versus the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash balance from operations for the period because it excludes cash used for capital expenditures. Management compensates for this limitation by providing information about our capital expenditures on the face of the cash flow statement and under the caption “Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-14-000030:8k_2_02:44]
Non-GAAP operating income and operating margin. Beginning in the first quarter of fiscal 2014, we define non-GAAP operating income as operating income plus stock-based compensation expense, acquisition related charges, including amortization, impairments and other purchase accounting adjustments, and when applicable, any other significant non-recurring items in a given quarter. Prior period amounts have been adjusted to conform to the current period presentation. Non-GAAP operating margin is defined as non-GAAP operating income divided by revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the effect of stock-based compensation expense, acquisition related charges, including amortization, impairments and other purchase accounting adjustments, and when applicable, any other significant non-recurring items  so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income versus operating income calculated in accordance with GAAP. First, non-GAAP operating income excludes stock-based compensation expense and acquisition-related charges and any other significant non-recurring items. Stock-based compensation expense has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees' compensation and impacts their performance. Third, the components of the costs that we exclude in our calculation of non-GAAP operating income may differ from the components that other companies exclude when they report their non-GAAP results of operations. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-14-000030:8k_2_02:45]
Non-GAAP net income and diluted net income per share. Beginning in the first quarter of fiscal 2014, we define non-GAAP net income as net income plus stock-based compensation expense, acquisition-related charges, including amortization, impairments and other purchase accounting adjustments, and, when applicable, any other significant non-recurring charges, adjusted for the impact of the tax adjustment, if any, required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the weighted-average diluted shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required to achieve the effective tax rate on a non-GAAP basis, which could differ from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. Our estimated tax rate on non-GAAP income is determined annually and may be adjusted during the year to take into account events or trends that we believe materially impact the estimated annual rate including, but not limited to, significant changes resulting from tax legislation, material changes in the geographic mix of revenues and expenses and other significant events.  The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net

[0001262039-14-000030:8k_2_02:46]
income and non-GAAP diluted net income per share. Management compensates for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-14-000030:8k_2_02:47]
Changes to non-GAAP financial measures.  Beginning in the first quarter of 2014, we will no longer adjust our GAAP results for insignificant non-recurring items. As a result, insignificant patent sale, license or settlement income amounts are no longer being excluded from our non-GAAP financial measures. All prior amounts reported in our earnings release have been adjusted to conform to the current period presentation. These changes do not restate or amend any previously published non-GAAP financial measures or other financial results.

[0001262039-14-000030:8k_2_02:48]
FORTINET, INC.

[0001262039-14-000030:8k_2_02:49]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-14-000030:8k_2_02:50]
(Unaudited, in thousands)

[0001262039-14-000030:8k_2_02:51]
|  | June 30, 2014 |  | December 31, 2013 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 203,947 |  |  | $ | 115,873 |  |
| Short-term investments | 354,174 |  |  | 375,497 |  |
| Accounts receivable—Net | 127,825 |  |  | 130,471 |  |
| Inventory | 46,824 |  |  | 48,672 |  |
| Deferred tax assets | 50,984 |  |  | 50,980 |  |
| Prepaid expenses and other current assets | 23,195 |  |  | 14,053 |  |
| Total current assets | 806,949 |  |  | 735,546 |  |
| PROPERTY AND EQUIPMENT—Net | 55,300 |  |  | 36,652 |  |
| DEFERRED TAX ASSETS—Non-current | 36,531 |  |  | 30,058 |  |
| LONG-TERM INVESTMENTS | 352,473 |  |  | 351,675 |  |
| GOODWILL | 2,824 |  |  | 2,872 |  |
| OTHER INTANGIBLE ASSETS—Net | 3,377 |  |  | 6,841 |  |
| OTHER ASSETS | 7,658 |  |  | 4,820 |  |
| TOTAL ASSETS | $ | 1,265,112 |  |  | $ | 1,168,464 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable | $ | 35,848 |  |  | $ | 35,599 |  |
| Accrued liabilities | 25,176 |  |  | 27,380 |  |
| Accrued payroll and compensation | 43,705 |  |  | 34,997 |  |
| Income taxes payable | — |  |  | 21,421 |  |
| Deferred revenue | 321,359 |  |  | 293,664 |  |
| Total current liabilities | 426,088 |  |  | 413,061 |  |
| DEFERRED REVENUE—Non-current | 158,843 |  |  | 138,964 |  |
| INCOME TAXES PAYABLE—Non-current | 36,551 |  |  | 30,208 |  |
| OTHER LIABILITIES | 18,411 |  |  | 471 |  |
| Total liabilities | 639,893 |  |  | 582,704 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |  |
| Common stock | 163 |  |  | 161 |  |
| Additional paid-in capital | 507,053 |  |  | 462,644 |  |
| Accumulated other comprehensive income | 1,181 |  |  | 1,092 |  |
| Retained earnings | 116,822 |  |  | 121,863 |  |
| Total stockholders’ equity | 625,219 |  |  | 585,760 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,265,112 |  |  | $ | 1,168,464 |  |

[0001262039-14-000030:8k_2_02:52]
FORTINET, INC.

[0001262039-14-000030:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-14-000030:8k_2_02:54]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000030:8k_2_02:55]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 85,384 |  |  | $ | 66,525 |  |  | $ | 162,149 |  |  | $ | 124,475 |  |
| Services and other | 98,714 |  |  | 80,903 |  |  | 190,898 |  |  | 158,773 |  |
| Total revenue | 184,098 |  |  | 147,428 |  |  | 353,047 |  |  | 283,248 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 37,455 |  |  | 26,948 |  |  | 69,594 |  |  | 49,906 |  |
| Services and other1 | 20,302 |  |  | 16,760 |  |  | 38,906 |  |  | 32,930 |  |
| Total cost of revenue | 57,757 |  |  | 43,708 |  |  | 108,500 |  |  | 82,836 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 47,929 |  |  | 39,577 |  |  | 92,555 |  |  | 74,569 |  |
| Services and other | 78,412 |  |  | 64,143 |  |  | 151,992 |  |  | 125,843 |  |
| Total gross profit | 126,341 |  |  | 103,720 |  |  | 244,547 |  |  | 200,412 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 29,938 |  |  | 25,158 |  |  | 58,993 |  |  | 48,492 |  |
| Sales and marketing 1 | 74,817 |  |  | 55,997 |  |  | 142,143 |  |  | 105,973 |  |
| General and administrative 1 | 10,444 |  |  | 8,788 |  |  | 19,454 |  |  | 16,779 |  |
| Total operating expenses | 115,199 |  |  | 89,943 |  |  | 220,590 |  |  | 171,244 |  |
| OPERATING INCOME | 11,142 |  |  | 13,777 |  |  | 23,957 |  |  | 29,168 |  |
| INTEREST INCOME | 1,319 |  |  | 1,337 |  |  | 2,652 |  |  | 2,706 |  |
| OTHER (EXPENSE) INCOME—Net | (574 | ) |  | (100 | ) |  | (963 | ) |  | 115 |  |
| INCOME BEFORE INCOME TAXES | 11,887 |  |  | 15,014 |  |  | 25,646 |  |  | 31,989 |  |
| PROVISION FOR INCOME TAXES | 5,806 |  |  | 6,035 |  |  | 11,172 |  |  | 10,761 |  |
| NET INCOME | $ | 6,081 |  |  | $ | 8,979 |  |  | $ | 14,474 |  |  | $ | 21,228 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.06 |  |  | $ | 0.09 |  |  | $ | 0.13 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.09 |  |  | $ | 0.13 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 163,161 |  |  | 162,247 |  |  | 162,778 |  |  | 161,767 |  |
| Diluted | 168,345 |  |  | 168,042 |  |  | 168,015 |  |  | 168,033 |  |
| 1 Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 178 |  |  | $ | 96 |  |  | $ | 291 |  |  | $ | 186 |  |
| Cost of services and other revenue | 1,363 |  |  | 1,226 |  |  | 2,692 |  |  | 2,246 |  |
| Research and development | 4,171 |  |  | 3,291 |  |  | 8,053 |  |  | 6,057 |  |
| Sales and marketing | 5,747 |  |  | 4,594 |  |  | 11,493 |  |  | 8,712 |  |
| General and administrative | 3,257 |  |  | 1,500 |  |  | 5,117 |  |  | 2,805 |  |
|  | $ | 14,716 |  |  | $ | 10,707 |  |  | $ | 27,646 |  |  | $ | 20,006 |  |

[0001262039-14-000030:8k_2_02:56]
FORTINET, INC.

[0001262039-14-000030:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-14-000030:8k_2_02:58]
(Unaudited, in thousands)

[0001262039-14-000030:8k_2_02:59]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Net income | $ | 6,081 |  |  | $ | 8,979 |  |  | $ | 14,474 |  |  | $ | 21,228 |  |
| Other comprehensive income (loss), net of taxes: |  |  |  |  |  |  |  |
| Foreign currency translation gains (losses) | 1,118 |  |  | (861 | ) |  | 101 |  |  | (1,813 | ) |
| Unrealized losses on investments | (21 | ) |  | (1,468 | ) |  | (19 | ) |  | (1,426 | ) |
| Tax benefit related to items of other comprehensive income or loss | 7 |  |  | 513 |  |  | 7 |  |  | 498 |  |
| Other comprehensive income (loss), net of taxes | 1,104 |  |  | (1,816 | ) |  | 89 |  |  | (2,741 | ) |
| Comprehensive income | $ | 7,185 |  |  | $ | 7,163 |  |  | $ | 14,563 |  |  | $ | 18,487 |  |

[0001262039-14-000030:8k_2_02:60]
FORTINET, INC.

[0001262039-14-000030:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-14-000030:8k_2_02:62]
(Unaudited, in thousands)

[0001262039-14-000030:8k_2_02:63]
|  | Six Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 14,474 |  |  | $ | 21,228 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 10,914 |  |  | 7,322 |  |
| Amortization of investment premiums | 4,752 |  |  | 5,889 |  |
| Stock-based compensation | 27,646 |  |  | 20,006 |  |
| Excess tax benefit from stock-based compensation | (2,443 | ) |  | (1,894 | ) |
| Other non-cash items—net | 3,549 |  |  | (925 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—Net | 2,228 |  |  | (801 | ) |
| Inventory | (3,307 | ) |  | (16,375 | ) |
| Deferred tax assets | (6,470 | ) |  | (13,205 | ) |
| Prepaid expenses and other current assets | (4,523 | ) |  | (258 | ) |
| Other assets | 159 |  |  | 778 |  |
| Accounts payable | 1,253 |  |  | 14,255 |  |
| Accrued liabilities | 1,544 |  |  | 732 |  |
| Other liabilities | 15,375 |  |  | (989 | ) |
| Accrued payroll and compensation | 8,665 |  |  | 2,287 |  |
| Deferred revenue | 47,871 |  |  | 25,943 |  |
| Income taxes payable | (16,987 | ) |  | 11,339 |  |
| Net cash provided by operating activities | 104,700 |  |  | 75,332 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (283,338 | ) |  | (275,029 | ) |
| Sales of investments | 22,864 |  |  | 16,691 |  |
| Maturities of investments | 273,214 |  |  | 176,378 |  |
| Purchases of property and equipment | (21,022 | ) |  | (3,569 | ) |
| Payments made in connection with business acquisitions—net of cash acquired | (17 | ) |  | (5,985 | ) |
| Net cash used in investing activities | (8,299 | ) |  | (91,514 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 22,518 |  |  | 15,590 |  |
| Taxes paid related to net share settlement of equity awards | (5,521 | ) |  | — |  |
| Excess tax benefit from stock-based compensation | 2,443 |  |  | 1,894 |  |
| Repurchase and retirement of common stock | (27,167 | ) |  | — |  |
| Net cash (used in) provided by financing activities | (7,727 | ) |  | 17,484 |  |
| EFFECT OF EXCHANGE RATES ON CASH AND CASH EQUIVALENTS | (600 | ) |  | (809 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 88,074 |  |  | 493 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 115,873 |  |  | 122,975 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 203,947 |  |  | $ | 123,468 |  |

[0001262039-14-000030:8k_2_02:64]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-14-000030:8k_2_02:65]
(Unaudited, in thousands)

[0001262039-14-000030:8k_2_02:66]
Reconciliation of GAAP revenue to billings

[0001262039-14-000030:8k_2_02:67]
|  | Three Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Total revenue | $ | 184,098 |  |  | $ | 147,428 |  |
| Add increase in deferred revenue | 28,899 |  |  | 13,268 |  |
| Total billings (Non-GAAP) | $ | 212,997 |  |  | $ | 160,696 |  |

[0001262039-14-000030:8k_2_02:68]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-14-000030:8k_2_02:69]
|  | Three Months Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Net cash provided by operating activities | $ | 43,798 |  |  | $ | 37,221 |  |
| Less purchases of property and equipment | (9,704 | ) |  | (2,035 | ) |
| Free cash flow (Non-GAAP) | $ | 34,094 |  |  | $ | 35,186 |  |

[0001262039-14-000030:8k_2_02:70]
Reconciliation of non-GAAP results of operations to the nearest comparable GAAP measures

[0001262039-14-000030:8k_2_02:71]
(Unaudited, in thousands, except per share amounts)

[0001262039-14-000030:8k_2_02:72]
Reconciliation of GAAP to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-14-000030:8k_2_02:73]
|  | Three Months Ended June 30, 2014 |  | Three Months Ended June 30, 2013 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 11,142 |  |  | $ | 17,528 |  | (a) | $ | 28,670 |  |  | $ | 13,777 |  |  | $ | 11,061 |  | (b) | $ | 24,838 |  |
| Operating margin | 6 | % |  |  |  | 16 | % |  | 9 | % |  |  |  | 17 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 14,716 |  |  |  |  |  |  | 10,707 |  |  |  |
| Impairment charge related to certain intangible assets |  |  | 2,404 |  |  |  |  |  |  | — |  |  |  |
| Amortization expense of certain intangible assets |  |  | 408 |  |  |  |  |  |  | 354 |  |  |  |
| Tax adjustment |  |  | (5,033 | ) | (c) |  |  |  |  | (2,570 | ) | (c) |  |
| Net income | $ | 6,081 |  |  | $ | 12,495 |  |  | $ | 18,576 |  |  | $ | 8,979 |  |  | $ | 8,491 |  |  | $ | 17,470 |  |
| Diluted net income per share | $ | 0.04 |  |  |  |  | $ | 0.11 |  |  | $ | 0.05 |  |  |  |  | $ | 0.10 |  |
| Shares used in diluted net income per share calculations | 168,345 |  |  |  |  | 168,345 |  |  | 168,042 |  |  |  |  | 168,042 |  |

[0001262039-14-000030:8k_2_02:74]
(a) To exclude $14.7 million of stock-based compensation expense, $2.4 million of impairment charge related to certain intangible assets, and $0.4 million of amortization expense of certain intangible assets in the three months ended June 30, 2014.

[0001262039-14-000030:8k_2_02:75]
(b) To exclude $10.7 million of stock-based compensation expense and $0.4 million of amortization expense of certain intangible assets in the three months ended June 30, 2013.

[0001262039-14-000030:8k_2_02:76]
(c)  Non-GAAP financial information is adjusted to achieve an overall 35 percent and 33 percent effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate, in fiscal 2014 and 2013, respectively.
