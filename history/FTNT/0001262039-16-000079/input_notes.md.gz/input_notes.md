# FTNT notes — 0001262039-16-000079


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-16-000079:notes:1]
[same as prior period, unchanged from 0001262039-16-000064:notes:1]

[0001262039-16-000079:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Income tax benefit associated with stock-based compensation | $ | 7,416 |  |  | $ | 4,266 |  |  | $ | 14,737 |  |  | $ | 7,643 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-16-000079:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

[0001262039-16-000079:notes:4]
[same as prior period, unchanged from 0001262039-16-000064:notes:4]

[0001262039-16-000079:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-16-000079:notes:6]
Our investments as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:7]
|  | June 30, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 415,008 |  |  | $ | 948 |  |  | $ | (78 | ) |  | $ | 415,878 |  |
| Commercial paper | 68,406 |  |  | 5 |  |  | (3 | ) |  | 68,408 |  |
| Municipal bonds | 52,531 |  |  | 81 |  |  | (1 | ) |  | 52,611 |  |
| Certificates of deposit and term deposits (1) | 19,823 |  |  | — |  |  | — |  |  | 19,823 |  |
| U.S. government and agency securities | 68,731 |  |  | 160 |  |  | — |  |  | 68,891 |  |
| Total available-for-sale securities | $ | 624,499 |  |  | $ | 1,194 |  |  | $ | (82 | ) |  | $ | 625,611 |  |

[0001262039-16-000079:notes:8]
[same as prior period, unchanged from 0001262039-16-000064:notes:8]

[0001262039-16-000079:notes:9]
[same as prior period, unchanged from 0001262039-16-000064:notes:9]


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-16-000079:notes:10]
The weighted-average assumptions relating to our employee stock options were:

[0001262039-16-000079:notes:11]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Expected term in years | 4.3 |  |  | 4.3 |  |  | 4.3 |  |  | 4.3 |  |
| Volatility | 39 | % |  | 38 | % |  | 39% - 43% |  |  | 38% - 40% |  |
| Risk-free interest rate | 1.2 | % |  | 1.5 | % |  | 1.0% - 1.2% |  |  | 1.5 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-16-000079:notes:12]
The stock-based compensation expense by award type was (in thousands):

[0001262039-16-000079:notes:13]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| RSUs | $ | 26,799 |  |  | $ | 17,386 |  |  | $ | 51,902 |  |  | $ | 31,678 |  |
| Stock options | 1,592 |  |  | 3,017 |  |  | 3,546 |  |  | 6,472 |  |
| ESPP | 1,956 |  |  | 1,357 |  |  | 3,801 |  |  | 2,532 |  |
| Total stock-based compensation expense | $ | 30,347 |  |  | $ | 21,760 |  |  | $ | 59,249 |  |  | $ | 40,682 |  |


## ftnt:ScheduleofMajorCustomersbyAccountsReceivableTableTextBlock

[0001262039-16-000079:notes:14]
[same as prior period, unchanged from 0001262039-16-000064:notes:14]

[0001262039-16-000079:notes:15]
|  | June 30, 2016 |  | December 31, 2015 |
| Exclusive Networks Group | 24 | % |  | 23 | % |
| Fine Tec Computers | 11 | % |  | * |  |

[0001262039-16-000079:notes:16]
[same as prior period, unchanged from 0001262039-16-000064:notes:16]


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-16-000079:notes:17]
The number of shares and amount withheld for employee taxes were (in thousands):

[0001262039-16-000079:notes:18]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Shares withheld for taxes | 247 |  |  | 124 |  |  | 590 |  |  | 345 |  |
| Amount withheld for taxes | $ | 8,051 |  |  | $ | 4,762 |  |  | $ | 17,358 |  |  | $ | 11,362 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-16-000079:notes:19]
[same as prior period, unchanged from 0001262039-16-000064:notes:19]

[0001262039-16-000079:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Weighted-average fair value per share granted | $ | 10.92 |  |  | $ | 12.75 |  |  | $ | 8.90 |  |  | $ | 11.54 |  |
| Intrinsic value of options exercised | $ | 6,829 |  |  | $ | 22,034 |  |  | $ | 26,253 |  |  | $ | 63,038 |  |
| Fair value of options vested | $ | 793 |  |  | $ | 2,718 |  |  | $ | 2,876 |  |  | $ | 6,510 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-16-000079:notes:21]
[same as prior period, unchanged from 0001262039-16-000064:notes:21]

[0001262039-16-000079:notes:22]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Weighted-average fair value per share granted | $ | 7.19 |  |  | $ | 7.56 |  |
| Shares issued under the ESPP | 614 |  |  | 427 |  |
| Weighted-average price per share issued | $ | 20.49 |  |  | $ | 21.34 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-16-000079:notes:23]
[same as prior period, unchanged from 0001262039-16-000064:notes:23]

[0001262039-16-000079:notes:24]
AccelOps, Inc.

[0001262039-16-000079:notes:25]
On June 7, 2016, we completed our acquisition of AccelOps, Inc., (“AccelOps”), a provider of network security monitoring and analytics solutions for total cash consideration of $22.3 million, of which $20.7 million was paid as of June 30, 2016 and the remaining balance was recorded as a current liability in the consolidated balance sheet as of June 30, 2016. We believe this acquisition will extend the Fortinet Security Fabric (as defined below) by enhancing our network security visibility, security data analytics, and threat intelligence across multi-vendor solutions.

[0001262039-16-000079:notes:26]
The acquisition of AccelOps is accounted as a business combination in accordance with the Accounting Standards Codification Topic 805 “Business Combinations” (“ASC 805”) issued by the FASB. We use our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. We included acquisition-related costs of $0.3 million in general and administrative expenses. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The total purchase price was allocated using the information currently available. As a result, we may continue to adjust the estimated purchase price allocation as and when additional information is available. The acquisition also included a contingent obligation for up to $4.0 million in future earn out payments to certain stockholders of AccelOps, if specified future financial targets are met for the three and six months period ended June 30, 2016 and December 31, 2016. The financial target for the three months period ended June 30, 2016 was not met.  As of June 30, 2016, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the remaining target. We will remeasure the contingent consideration periodically during the six-month contingency period for the remaining target, with changes in fair value to be recorded in our consolidated statements of operations.

[0001262039-16-000079:notes:27]
Total preliminary allocation of the purchase price was (in thousands):

[0001262039-16-000079:notes:28]
| Cash and cash equivalents | $ | 171 |  |
| Accounts receivable | 1,126 |  |
| Prepaid expenses and other assets | 430 |  |
| Property and equipment | 203 |  |
| Deferred tax assets | 2,977 |  |
| Finite-lived intangible assets | 15,800 |  |
| Indefinite-lived intangible assets in process research and development | 1,500 |  |
| Goodwill | 9,543 |  |
| Total assets acquired | 31,750 |  |
| Deferred revenue | 4,400 |  |
| Accounts payable and accrued liabilities | 3,311 |  |
| Other liabilities | 1,694 |  |
| Total liabilities assumed | 9,405 |  |
| Total purchase price allocation | $ | 22,345 |  |

[0001262039-16-000079:notes:29]
Finite-lived intangible assets consist of developed technology, customer relationships, and other. AccelOps’ technology provides a software solution to manage security, performance and compliance from a single platform. The acquired developed technologies include software patents, know-how, process and designs. The value of customer relationships is attributable to the generation of a consistent income source and the avoidance of costs associated with creating new customer relationships.

[0001262039-16-000079:notes:30]
Indefinite-lived intangible assets consist of in-process research and development, which will begin to be amortized upon completion of development.

[0001262039-16-000079:notes:31]
The estimated useful life and fair values of the acquired finite-lived intangible assets were as follows (in thousands, except for estimated useful life):

[0001262039-16-000079:notes:32]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Developed technologies | 4 |  | $ | 11,600 |  |
| Customer relationships | 3 |  | 4,000 |  |
| Other | 2 |  | 200 |  |
| Total |  |  | $ | 15,800 |  |

[0001262039-16-000079:notes:33]
The developed technologies and other are amortized on a straight-line basis. The amortization expense of developed technologies and other are recorded in cost of product revenue. The amortization expense of customer relationships is amortized on an accelerated basis and is recorded in sales and marketing expenses.

[0001262039-16-000079:notes:34]
The goodwill of $9.5 million represents the amount of the purchase price in excess of the fair value of the net tangible liabilities assumed and intangible assets acquired, including AccelOps’ assembled workforce. The goodwill recorded as part of the AccelOps acquisition is not deductible for U.S. federal income tax purposes. The financial results of this acquisition are considered immaterial for purposes of pro forma financial disclosures.

[0001262039-16-000079:notes:35]
Meru Networks, Inc.

[0001262039-16-000079:notes:36]
On July 8, 2015, we completed our acquisition of Meru Networks, Inc. (“Meru”), a provider of Wi-Fi networking products and services.

[0001262039-16-000079:notes:37]
In connection with the acquisition, we paid $41.8 million, comprised of cash consideration of $40.9 million, withholding tax liability of $0.4 million and $0.5 million in estimated fair value associated with restricted stock units (“RSUs”) of Meru that were converted for 53,401 shares of our common stock.

[0001262039-16-000079:notes:38]
We accounted for this transaction as a business combination. In 2015, we included acquisition-related costs of $1.7 million in general and administrative expenses. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-16-000079:notes:39]
[same as prior period, unchanged from 0001262039-16-000064:notes:28]

[0001262039-16-000079:notes:40]
| Cash and cash equivalents | $ | 3,268 |  |
| Accounts receivable | 8,191 |  |
| Inventory | 11,610 |  |
| Prepaid expenses and other assets | 2,409 |  |
| Property and equipment | 920 |  |
| Deferred tax assets | 18,585 |  |
| Finite-lived intangible assets | 19,600 |  |
| Goodwill | 1,868 |  |
| Total assets acquired | 66,451 |  |
| Deferred revenue | 9,800 |  |
| Accounts payable and accrued liabilities | 14,887 |  |
| Total liabilities assumed | 24,687 |  |
| Total purchase price allocation | $ | 41,764 |  |

[0001262039-16-000079:notes:41]
[same as prior period, unchanged from 0001262039-16-000064:notes:30]

[0001262039-16-000079:notes:42]
[same as prior period, unchanged from 0001262039-16-000064:notes:31]

[0001262039-16-000079:notes:43]
[same as prior period, unchanged from 0001262039-16-000064:notes:32]

[0001262039-16-000079:notes:44]
[same as prior period, unchanged from 0001262039-16-000064:notes:33]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-16-000079:notes:45]
COMMITMENTS AND CONTINGENCIES

[0001262039-16-000079:notes:46]
Our future principal contractual obligations as of June 30, 2016 were (in thousands):

[0001262039-16-000079:notes:47]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 75,975 |  |  | $ | 10,984 |  |  | $ | 17,146 |  |  | $ | 15,004 |  |  | $ | 12,595 |  |  | $ | 9,598 |  |  | $ | 10,648 |  |
| Inventory purchase commitments | 86,448 |  |  | 86,448 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 52,085 |  |  | 44,522 |  |  | 3,509 |  |  | 1,273 |  |  | 927 |  |  | 927 |  |  | 927 |  |
| Total | $ | 214,508 |  |  | $ | 141,954 |  |  | $ | 20,655 |  |  | $ | 16,277 |  |  | $ | 13,522 |  |  | $ | 10,525 |  |  | $ | 11,575 |  |

[0001262039-16-000079:notes:48]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $2.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively. Rent expense was $8.5 million and $6.0 million during the six months ended June 30, 2016 and June 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-16-000079:notes:49]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2016, we had $86.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-16-000079:notes:50]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2016, we had $52.1 million in other contractual commitments that may not be cancelable.

[0001262039-16-000079:notes:51]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-16-000079:notes:52]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (1,481 | ) |  | (2,059 | ) |
| Provision for warranty for the period | 718 |  |  | 2,294 |  |
| Adjustment related to pre-existing warranties | (225 | ) |  | 171 |  |
| Accrued warranty balance—end of the period | $ | 2,156 |  |  | $ | 4,675 |  |

[0001262039-16-000079:notes:53]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.

[0001262039-16-000079:notes:54]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-16-000079:notes:55]
[same as prior period, unchanged from 0001262039-16-000064:notes:44]

[0001262039-16-000079:notes:56]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plan and RRSP for the three months ended June 30, 2016 and June 30, 2015 were $1.2 million and $0.9 million, respectively. Our matching contributions to the 401(k) Plan and RRSP during the six months ended June 30, 2016 and June 30, 2015 were $2.2 million and $1.8 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-16-000079:notes:57]
[same as prior period, unchanged from 0001262039-16-000064:notes:46]

[0001262039-16-000079:notes:58]
The changes in accumulated balances of other comprehensive income or loss were (in thousands):

[0001262039-16-000079:notes:59]
|  | June 30, 2016 |
|  | Unrealized Gains/Losses on Investments |  | Tax benefit (provision) related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |
| Other comprehensive income (loss) before reclassifications | 2,552 |  |  | (893 | ) |  | 1,659 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | (3 | ) |  | 1 |  |  | (2 | ) |
| Net current-period other comprehensive income (loss) | 2,549 |  |  | (892 | ) |  | 1,657 |  |
| Ending balance | $ | 1,112 |  |  | $ | (388 | ) |  | $ | 724 |  |

[0001262039-16-000079:notes:60]
The details of reclassification out of accumulated other comprehensive income (loss) were (in thousands):

[0001262039-16-000079:notes:61]
| Six Months Ended June 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized losses on investments | $ | (3 | ) |  | Other expense—net |
| Tax benefit related to items of other comprehensive loss | 1 |  |  | Provision for income taxes |
| Total reclassification for the period | $ | (2 | ) |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-16-000079:notes:62]
[same as prior period, unchanged from 0001262039-16-000064:notes:51]

[0001262039-16-000079:notes:63]
Our investments in the equity securities of three privately-held companies totaled $10.3 million as of June 30, 2016 and December 31, 2015. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our condensed consolidated balance sheet and would be measured at fair value if indicators of impairment exist. As of June 30, 2016, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-16-000079:notes:64]
[same as prior period, unchanged from 0001262039-16-000064:notes:53]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-16-000079:notes:65]
[same as prior period, unchanged from 0001262039-16-000064:notes:54]

[0001262039-16-000079:notes:66]
[same as prior period, unchanged from 0001262039-16-000064:notes:55]

[0001262039-16-000079:notes:67]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs and PSUs. We also have an ESPP for all eligible employees.  As of June 30, 2016, there were a total of 45,162,348 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-16-000079:notes:68]
[same as prior period, unchanged from 0001262039-16-000064:notes:57]

[0001262039-16-000079:notes:69]
The activity and related information for RSUs, including PSUs, was (in thousands, except per share amounts):

[0001262039-16-000079:notes:70]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2015 | 9,257 |  |  | $ | 32.97 |  |
| Granted | 3,698 |  |  | 25.92 |  |
| Forfeited | (707 | ) |  | 32.24 |  |
| Vested | (1,752 | ) |  | 27.87 |  |
| Balance—June 30, 2016 | 10,496 |  |  | $ | 31.22 |  |

[0001262039-16-000079:notes:71]
As of June 30, 2016, total compensation expense related to unvested RSUs, including PSUs, that were granted to employees and non-employees, but not yet recognized, was $279.3 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.94 years. We did not grant any PSUs during the three and six months ended June 30, 2016. The stock-based compensation expense related to PSU awards is not material.

[0001262039-16-000079:notes:72]
[same as prior period, unchanged from 0001262039-16-000064:notes:61]

[0001262039-16-000079:notes:73]
[same as prior period, unchanged from 0001262039-16-000064:notes:62]

[0001262039-16-000079:notes:74]
The stock option activity and related information was (in thousands, except exercise prices and contractual life):

[0001262039-16-000079:notes:75]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2015 | 6,968 |  |  | $ | 20.03 |  |  |  |  |  |
| Granted | 1,298 |  |  | $ | 24.77 |  |  |  |  |  |
| Forfeited | (102 | ) |  | $ | 37.49 |  |  |  |  |  |
| Exercised | (1,263 | ) |  | $ | 8.18 |  |  |  |  |  |
| Balance—June 30, 2016 | 6,901 |  |  | $ | 22.83 |  |  | 3.33 |  | 65,715 |  |
| Options exercisable—June 30, 2016 | 4,821 |  |  | $ | 20.30 |  |  | 2.09 |  | $ | 54,924 |  |

[0001262039-16-000079:notes:76]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2016, for all in-the-money options. As of June 30, 2016, total compensation expense related to unvested stock options granted to employees but not yet recognized was $18.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.2 years.

[0001262039-16-000079:notes:77]
[same as prior period, unchanged from 0001262039-16-000064:notes:66]

[0001262039-16-000079:notes:78]
[same as prior period, unchanged from 0001262039-16-000064:notes:67]

[0001262039-16-000079:notes:79]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 48 | % |  | 28 | % |
| Risk-free interest rate | 0.4 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-16-000079:notes:80]
There were no shares granted or issued under the ESPP during the three month ended June 30, 2016 and June 30, 2015.

[0001262039-16-000079:notes:81]
[same as prior period, unchanged from 0001262039-16-000064:notes:69]

[0001262039-16-000079:notes:82]
[same as prior period, unchanged from 0001262039-16-000064:notes:70]

[0001262039-16-000079:notes:83]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Cost of product revenue | $ | 298 |  |  | $ | 210 |  |  | $ | 578 |  |  | $ | 350 |  |
| Cost of service revenue | 2,123 |  |  | 1,660 |  |  | 4,257 |  |  | 3,292 |  |
| Research and development | 7,458 |  |  | 5,541 |  |  | 14,601 |  |  | 10,698 |  |
| Sales and marketing | 16,990 |  |  | 11,271 |  |  | 32,805 |  |  | 20,578 |  |
| General and administrative | 3,478 |  |  | 3,078 |  |  | 7,008 |  |  | 5,764 |  |
| Total stock-based compensation expense | $ | 30,347 |  |  | $ | 21,760 |  |  | $ | 59,249 |  |  | $ | 40,682 |  |

[0001262039-16-000079:notes:84]
[same as prior period, unchanged from 0001262039-16-000064:notes:72]

[0001262039-16-000079:notes:85]
In January 2016, our board of directors approved a new Share Repurchase Program (the “Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. There were no shares repurchased under the Program during the three months ended June 30, 2016. During the six months ended June 30, 2016, we repurchased 2.0 million shares of common stock under the Program in open market transactions at an average price of $24.97 per share, for an aggregate purchase price of $50.0 million. As of June 30, 2016, $150.0 million remained available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-16-000079:notes:86]
[same as prior period, unchanged from 0001262039-16-000064:notes:74]

[0001262039-16-000079:notes:87]
[same as prior period, unchanged from 0001262039-16-000064:notes:75]

[0001262039-16-000079:notes:88]
[same as prior period, unchanged from 0001262039-16-000064:notes:76]

[0001262039-16-000079:notes:89]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (1,388 | ) |  | $ | 792 |  |  | $ | 730 |  |  | $ | 2,352 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 172,075 |  |  | 169,930 |  |  | 171,910 |  |  | 169,009 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 172,075 |  |  | 169,930 |  |  | 171,910 |  |  | 169,009 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | — |  |  | 3,720 |  |  | 1,796 |  |  | 3,779 |  |
| RSUs (including PSUs) | — |  |  | 2,521 |  |  | 1,580 |  |  | 2,131 |  |
| ESPP | — |  |  | 63 |  |  | 74 |  |  | 64 |  |
| Weighted-average shares used to compute diluted net income per share | 172,075 |  |  | 176,234 |  |  | 175,360 |  |  | 174,983 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.01 | ) |  | $ | — |  |  | $ | — |  |  | $ | 0.01 |  |
| Diluted | $ | (0.01 | ) |  | $ | — |  |  | $ | — |  |  | $ | 0.01 |  |

[0001262039-16-000079:notes:90]
[same as prior period, unchanged from 0001262039-16-000064:notes:78]

[0001262039-16-000079:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Stock options | 7,058 |  |  | 299 |  |  | 1,182 |  |  | 274 |  |
| RSUs (including PSUs) | 10,577 |  |  | 414 |  |  | 4,715 |  |  | 873 |  |
| ESPP | 554 |  |  | — |  |  | 141 |  |  | 84 |  |
|  | 18,189 |  |  | 713 |  |  | 6,038 |  |  | 1,231 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-16-000079:notes:92]
[same as prior period, unchanged from 0001262039-16-000064:notes:80]

[0001262039-16-000079:notes:93]
The gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:94]
|  | June 30, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 77,153 |  |  | $ | (36 | ) |  | $ | 40,207 |  |  | $ | (42 | ) |  | $ | 117,360 |  |  | $ | (78 | ) |
| Commercial paper | 6,964 |  |  | (3 | ) |  | — |  |  | — |  |  | 6,964 |  |  | (3 | ) |
| Municipal bonds | 4,548 |  |  | (1 | ) |  | — |  |  | — |  |  | 4,548 |  |  | (1 | ) |
| Total available-for-sale securities | $ | 88,665 |  |  | $ | (40 | ) |  | $ | 40,207 |  |  | $ | (42 | ) |  | $ | 128,872 |  |  | $ | (82 | ) |

[0001262039-16-000079:notes:95]
[same as prior period, unchanged from 0001262039-16-000064:notes:83]

[0001262039-16-000079:notes:96]
The contractual maturities of our investments as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:97]
|  | June 30, 2016 |  | December 31, 2015 |
| Due within one year | $ | 388,388 |  |  | $ | 348,074 |  |
| Due within one to three years | 237,223 |  |  | 272,959 |  |
| Total | $ | 625,611 |  |  | $ | 621,033 |  |

[0001262039-16-000079:notes:98]
[same as prior period, unchanged from 0001262039-16-000064:notes:86]

[0001262039-16-000079:notes:99]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2016.

[0001262039-16-000079:notes:100]
[same as prior period, unchanged from 0001262039-16-000064:notes:88]

[0001262039-16-000079:notes:101]
[same as prior period, unchanged from 0001262039-16-000064:notes:89]

[0001262039-16-000079:notes:102]
[same as prior period, unchanged from 0001262039-16-000064:notes:90]

[0001262039-16-000079:notes:103]
[same as prior period, unchanged from 0001262039-16-000064:notes:91]

[0001262039-16-000079:notes:104]
[same as prior period, unchanged from 0001262039-16-000064:notes:92]

[0001262039-16-000079:notes:105]
[same as prior period, unchanged from 0001262039-16-000064:notes:93]

[0001262039-16-000079:notes:106]
[same as prior period, unchanged from 0001262039-16-000064:notes:94]

[0001262039-16-000079:notes:107]
[same as prior period, unchanged from 0001262039-16-000064:notes:95]

[0001262039-16-000079:notes:108]
[same as prior period, unchanged from 0001262039-16-000064:notes:96]

[0001262039-16-000079:notes:109]
The fair values of our financial assets measured at fair value on a recurring basis as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:110]
|  | June 30, 2016 |  |  |  | December 31, 2015 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 415,878 |  |  | $ | — |  |  | $ | 415,878 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |
| Commercial paper | 78,406 |  |  | — |  |  | 78,406 |  |  | — |  |  | 69,231 |  |  | — |  |  | 69,231 |  |  | — |  |
| Municipal bonds | 52,611 |  |  | — |  |  | 52,611 |  |  | — |  |  | 61,022 |  |  | — |  |  | 61,022 |  |  | — |  |
| Certificates of deposit and term deposits | 19,823 |  |  | — |  |  | 19,823 |  |  | — |  |  | 14,897 |  |  | — |  |  | 14,897 |  |  | — |  |
| Money market funds | 49,231 |  |  | 49,231 |  |  | — |  |  | — |  |  | 50,030 |  |  | 50,030 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 68,891 |  |  | 58,869 |  |  | 10,022 |  |  | — |  |  | 41,688 |  |  | 25,693 |  |  | 15,995 |  |  | — |  |
| Total | $ | 684,840 |  |  | $ | 108,100 |  |  | $ | 576,740 |  |  | $ | — |  |  | $ | 674,062 |  |  | $ | 75,723 |  |  | $ | 598,339 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 59,229 |  |  |  |  |  |  |  |  | $ | 53,029 |  |  |  |  |  |  |  |
| Short-term investments | 388,388 |  |  |  |  |  |  |  |  | 348,074 |  |  |  |  |  |  |  |
| Long-term investments | 237,223 |  |  |  |  |  |  |  |  | 272,959 |  |  |  |  |  |  |  |
| Total | $ | 684,840 |  |  |  |  |  |  |  |  | $ | 674,062 |  |  |  |  |  |  |  |

[0001262039-16-000079:notes:111]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2016.


## us-gaap:ForeignCurrencyDisclosureTextBlock

[0001262039-16-000079:notes:112]
[same as prior period, unchanged from 0001262039-16-000064:notes:100]

[0001262039-16-000079:notes:113]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States is denominated in foreign currencies and is subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), Euro (“EUR”), Great British pound (“GBP”), and Chinese yen (“CNY”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other expense—net in the condensed consolidated statement of operations. As of June 30, 2016, the fair value of the forward exchange contracts was not material.

[0001262039-16-000079:notes:114]
[same as prior period, unchanged from 0001262039-16-000064:notes:102]

[0001262039-16-000079:notes:115]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:116]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of June 30, 2016 |  |  |  |
| CAD | Sell |  | $ | 7,209 |  |
| Currency—As of December 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 7,011 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-16-000079:notes:117]
[same as prior period, unchanged from 0001262039-16-000064:notes:105]

[0001262039-16-000079:notes:118]
[same as prior period, unchanged from 0001262039-16-000064:notes:106]

[0001262039-16-000079:notes:119]
Changes in the carrying amount of goodwill were (in thousands):

[0001262039-16-000079:notes:120]
|  | Amount |
| Balance—December 31, 2015 | $ | 4,692 |  |
| Addition due to business acquisition | 9,543 |  |
| Balance—June 30, 2016 | $ | 14,235 |  |

[0001262039-16-000079:notes:121]
There were no impairments to goodwill during the three and six months ended June 30, 2016.

[0001262039-16-000079:notes:122]
[same as prior period, unchanged from 0001262039-16-000064:notes:108]

[0001262039-16-000079:notes:123]
Other intangible assets—net as of June 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000079:notes:124]
|  | June 30, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Customer relationships | 4.5 |  | $ | 16,200 |  |  | $ | 3,257 |  |  | $ | 12,943 |  |
| Developed technologies and other | 3.8 |  | 23,184 |  |  | 6,139 |  |  | 17,045 |  |
|  |  |  | 39,384 |  |  | 9,396 |  |  | 29,988 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,500 |  |  | — |  |  | 1,500 |  |
| Total other intangible assets—net |  |  | $ | 40,884 |  |  | $ | 9,396 |  |  | $ | 31,488 |  |

[0001262039-16-000079:notes:125]
[same as prior period, unchanged from 0001262039-16-000064:notes:111]

[0001262039-16-000079:notes:126]
Amortization expense was $2.3 million and $0.3 million during the three months ended June 30, 2016 and June 30, 2015, respectively.  Amortization expense was $3.5 million and $0.5 million during the six months ended June 30, 2016 and June 30, 2015, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net with finite lives (in thousands):

[0001262039-16-000079:notes:127]
|  | Amount |
| Years: |  |
| 2016 (remainder) | $ | 6,032 |  |
| 2017 | 8,878 |  |
| 2018 | 7,281 |  |
| 2019 | 5,517 |  |
| 2020 | 2,280 |  |
| Total | $ | 29,988 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-16-000079:notes:128]
[same as prior period, unchanged from 0001262039-16-000064:notes:114]

[0001262039-16-000079:notes:129]
Our effective tax rate was 62% for the three months ended June 30, 2016, compared to an effective tax rate of 77% for the same period last year.  The effective tax rate was 111% for the six months ended June 30, 2016, compared to an effective tax rate of 54% for the same period last year.  The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, foreign withholding taxes and foreign income taxes. The changes in the tax provision and effective tax rate were primarily due to the tax benefit from the adoption of the new accounting guidance relating to stock-based compensation and the tax benefit from the U.S. federal research and development credit (the “U.S. federal R&D credit”). The tax rate for the three and six months ended June 30, 2015 did not include a benefit from the U.S. federal R&D credit, as the credit had expired in December 2014. In December 2015, the U.S. federal R&D credit was made permanent and the tax benefit was reflected on the income tax provision for the three and six months ended June 30, 2016. There was a pretax loss for the three and six months ended June 30, 2016, as compared to having a pretax income for the same periods last year.

[0001262039-16-000079:notes:130]
As of June 30, 2016 and December 31, 2015, unrecognized tax benefits were $63.7 million and $59.7 million, respectively. The total amount of $62.4 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate. It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of June 30, 2016, we had accrued $7.9 million for estimated interest related to uncertain tax positions.

[0001262039-16-000079:notes:131]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S. federal tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for the tax years 2012, 2013, and 2014. In addition, the tax authorities in France are examining the inter-company relationship between Fortinet Inc., Fortinet France and Fortinet Singapore. We are in the early stages of this inquiry and as of yet no official audit has been opened.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-16-000079:notes:132]
[same as prior period, unchanged from 0001262039-16-000064:notes:118]

[0001262039-16-000079:notes:133]
Our inventory as of June 30, 2016 and December 31, 2015 consisted of (in thousands):

[0001262039-16-000079:notes:134]
|  | June 30, 2016 |  | December 31, 2015 |
| Raw materials | $ | 17,042 |  |  | $ | 15,425 |  |
| Finished goods | 64,205 |  |  | 68,443 |  |
| Inventory | $ | 81,247 |  |  | $ | 83,868 |  |

[0001262039-16-000079:notes:135]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.7 million and $1.1 million as of June 30, 2016 and December 31, 2015, respectively. Inventory also includes materials at contract manufacturers of $5.5 million and $4.9 million as of June 30, 2016 and December 31, 2015, respectively.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-16-000079:notes:136]
| Property and Equipment—net | June 30, 2016 |  | December 31, 2015 |
| Americas: |  |  |  |
| United States | $ | 90,457 |  |  | $ | 61,064 |  |
| Other Americas | 10,123 |  |  | 8,972 |  |
| Total Americas | 100,580 |  |  | 70,036 |  |
| EMEA: |  |  |  |
| France | 14,841 |  |  | 13,201 |  |
| Other EMEA | 6,109 |  |  | 3,977 |  |
| Total EMEA | 20,950 |  |  | 17,178 |  |
| APAC | 4,106 |  |  | 3,853 |  |
| Total property and equipment—net | $ | 125,636 |  |  | $ | 91,067 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-16-000079:notes:137]
Recently Adopted Accounting Standards

[0001262039-16-000079:notes:138]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur. The new standard is effective for us beginning January 1, 2017, with early adoption permitted.

[0001262039-16-000079:notes:139]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits amounting to $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016 and $2.6 million during the second quarter of 2016.

[0001262039-16-000079:notes:140]
Under the new guidance, we have elected to change our policy and have started to recognize forfeitures of awards as they occur. The change in forfeiture policy was adopted using a modified retrospective transition method. We recorded a cumulative-effect adjustment to decrease retained earnings by $0.8 million upon transition on January 1, 2016 and a retrospective decrease of stock-based compensation of $2.0 million during the first quarter of 2016.

[0001262039-16-000079:notes:141]
The amendment to the minimum statutory withholding tax requirements was adopted on a modified retrospective basis. The adoption had no impact on the January 1, 2016 retained earnings. In addition, we adopted the presentation of taxes paid related to net share settlement of equity awards as a financing activity on the statement of cash flows on a retrospective basis.  Our adoption had no impact to any of the periods presented in our consolidated cash flows statements since such cash flows have historically been presented as a financing activity.

[0001262039-16-000079:notes:142]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

[0001262039-16-000079:notes:143]
|  | Three Months Ended |
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Statements of Operations: |  |  |  |
| Stock-based compensation expense | $ | 30,881 |  |  | $ | 28,901 |  |
| Benefit from income taxes | $ | (1,809 | ) |  | $ | (5,376 | ) |
| Net income (loss) | $ | (3,429 | ) |  | $ | 2,118 |  |
| Net income (loss) per share—Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Net income (loss) per share—Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding—Diluted | 171,745 |  |  | 174,421 |  |

[0001262039-16-000079:notes:144]
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Balance Sheets: |  |  |  |
| Deferred tax assets | $ | 131,696 |  |  | $ | 167,625 |  |
| Additional paid-in capital | $ | 718,849 |  |  | $ | 717,671 |  |
| Retained earnings | $ | 23,089 |  |  | $ | 60,196 |  |

[0001262039-16-000079:notes:145]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.

[0001262039-16-000079:notes:146]
Recent Accounting Standards Not Yet Effective

[0001262039-16-000079:notes:147]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the full impact ASU 2016-02 will have on our consolidated financial statements.

[0001262039-16-000079:notes:148]
In January 2016, the FASB issued ASU 2016-01—Financial Instruments—Overall—Recognition and Measurement of Financial Assets and Financial Liabilities, which modifies how entities measure equity investments and present changes in the fair value of financial liabilities. Under the new guidance, entities will have to measure equity investments that do not result in consolidation and are not accounted under the equity method at fair value and recognize any changes in fair value in net income unless the investments qualify for the new practicality exception. The practicality exception will apply to those equity investments that do not have a readily determinable fair value and do not qualify for the practical expedient to estimate fair value, and as such these investments may be measured at cost. ASU 2016-01 will be effective for us beginning on January 1, 2018. We do not expect the impact of ASU 2016-01 on our consolidated financial statements to be significant.

[0001262039-16-000079:notes:149]
In July 2015, the FASB issued ASU 2015-11—Inventory—Simplifying the Measurement of Inventory, which changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. ASU 2015-11 applies to entities that measure inventory using a method other than last-in, first-out or the retail inventory method (e.g., first-in, first-out or average cost). ASU 2015-11 will be effective for us beginning on January 1, 2017. We do not expect the impact of ASU 2015-11 on our consolidated financial statements to be significant.

[0001262039-16-000079:notes:150]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-16-000079:notes:151]
[same as prior period, unchanged from 0001262039-16-000064:notes:133]

[0001262039-16-000079:notes:152]
Our property and equipment—net as of June 30, 2016 and December 31, 2015 consisted of (in thousands):

[0001262039-16-000079:notes:153]
|  | June 30, 2016 |  | December 31, 2015 |
| Land | $ | 31,251 |  |  | $ | 21,683 |  |
| Building and building improvements | 42,060 |  |  | 28,841 |  |
| Evaluation units | 18,299 |  |  | 15,784 |  |
| Computer equipment and software | 52,907 |  |  | 45,632 |  |
| Furniture and fixtures | 10,893 |  |  | 8,901 |  |
| Construction-in-progress | 13,681 |  |  | 8,106 |  |
| Leasehold improvements | 15,554 |  |  | 11,179 |  |
| Total property and equipment | 184,645 |  |  | 140,126 |  |
| Less: accumulated depreciation | (59,009 | ) |  | (49,059 | ) |
| Property and equipment—net | $ | 125,636 |  |  | $ | 91,067 |  |

[0001262039-16-000079:notes:154]
Depreciation expense was $9.0 million and $6.8 million during the three months ended June 30, 2016 and June 30, 2015, respectively.  Depreciation expense was $18.4 million and $12.8 million during the six months ended June 30, 2016 and June 30, 2015, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-16-000079:notes:155]
RELATED PARTY TRANSACTIONS

[0001262039-16-000079:notes:156]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.1 million and $0.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively.  No contingent fees were incurred during the three months ended June 30, 2016 and June 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.4 million and $2.8 million during the six months ended June 30, 2016 and June 30, 2015, respectively.  Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements during the six months ended June 30, 2016 and June 30, 2015, respectively. Amounts due and payable to the law firm were $0.3 million and $5.3 million as of June 30, 2016 and December 31, 2015, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-16-000079:notes:157]
[same as prior period, unchanged from 0001262039-16-000064:notes:140]

[0001262039-16-000079:notes:158]
The following table provides a summary of restructuring activity as of June 30, 2016 (in thousands):

[0001262039-16-000079:notes:159]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Balance as of December 31, 2015 | $ | 3,689 |  |  | $ | 229 |  |  | $ | 3,918 |  |
| Costs incurred | 837 |  |  | 44 |  |  | 881 |  |
| Less cash payments | (2,757 | ) |  | (171 | ) |  | (2,928 | ) |
| Less non-cash charges | (89 | ) |  | — |  |  | (89 | ) |
| Balance as of June 30, 2016 | $ | 1,680 |  |  | $ | 102 |  |  | $ | 1,782 |  |

[0001262039-16-000079:notes:160]
2015 Meru Restructuring

[0001262039-16-000079:notes:161]
In connection with the acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies starting in the third quarter of 2015. We estimate that we will incur approximately $8.0 million of restructuring charges, consisting of severance and other benefits, contract terminations and other charges. We did not incur any material restructuring charges during the three and six months ended June 30, 2016. To date, we have incurred $7.8 million of charges related to this restructuring. These charges are primarily related to severance payments to be paid in cash and are included in operating expense in the condensed consolidated statements of operations of the period when incurred.

[0001262039-16-000079:notes:162]
Cash payments for the restructuring activities are expected to be paid through 2017, primarily relating to severance payments. The remaining restructuring reserve balance of $1.5 million is included in accrued liabilities on the condensed consolidated balance sheet as of June 30, 2016.

[0001262039-16-000079:notes:163]
2016 AccelOps Restructuring

[0001262039-16-000079:notes:164]
In connection with the acquisition of AccelOps, we initiated alignment activities in the second quarter of 2016. We estimate that we will incur approximately $0.7 million of restructuring charges, primarily consisting of severance and other benefits, all of which were incurred during the three and six months ended June 30, 2016, which are included in operating expense in the condensed consolidated statements of operations.

[0001262039-16-000079:notes:165]
Cash payments for the restructuring activities are expected to be made in 2016, primarily relating to severance payments. The remaining restructuring reserve accrual of $0.2 million is included in accrued liabilities on the condensed consolidated balance sheet as of June 30, 2016.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-16-000079:notes:166]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 80,811 |  |  | $ | 71,224 |  |  | $ | 156,369 |  |  | $ | 129,725 |  |
| Canada | 33,782 |  |  | 26,191 |  |  | 65,087 |  |  | 46,649 |  |
| Other Americas | 18,053 |  |  | 11,178 |  |  | 31,236 |  |  | 23,779 |  |
| Total Americas | 132,646 |  |  | 108,593 |  |  | 252,692 |  |  | 200,153 |  |
| Europe, Middle East, and Africa (“EMEA”) | 114,453 |  |  | 83,404 |  |  | 219,944 |  |  | 159,068 |  |
| Asia Pacific (“APAC”) | 64,292 |  |  | 47,788 |  |  | 123,331 |  |  | 93,450 |  |
| Total revenue | $ | 311,391 |  |  | $ | 239,785 |  |  | $ | 595,967 |  |  | $ | 452,671 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001262039-16-000079:notes:167]
The following customers, each of which is a distributor, accounted for 10% or more of our revenue:

[0001262039-16-000079:notes:168]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Exclusive Networks Group | 20 | % |  | 17 | % |  | 20 | % |  | 17 | % |
| Ingram Micro | 10 | % |  | * |  |  | * |  |  | * |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-16-000079:notes:169]
[same as prior period, unchanged from 0001262039-16-000064:notes:148]

[0001262039-16-000079:notes:170]
[same as prior period, unchanged from 0001262039-16-000064:notes:149]

[0001262039-16-000079:notes:171]
[same as prior period, unchanged from 0001262039-16-000064:notes:150]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-16-000079:notes:172]
[same as prior period, unchanged from 0001262039-16-000064:notes:151]
