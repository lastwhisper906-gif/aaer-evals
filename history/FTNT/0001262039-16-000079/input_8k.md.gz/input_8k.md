# FTNT 8-K — 0001262039-16-000076 filed 2016-07-28

## item codes, every 8-K on or before 2016-08-05

- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2016-08-05

- none on or before 2016-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001262039-16-000076:8k_2_02:1]
EX-99.1
2
ftntq2-2016ex991.htm
PRESS RELEASE

[0001262039-16-000076:8k_2_02:2]
Exhibit

[0001262039-16-000076:8k_2_02:3]
Press Release

[0001262039-16-000076:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-391-9408 |
| mspolver@fortinet.com |  | swheatley@fortinet.com |

[0001262039-16-000076:8k_2_02:5]
Fortinet Reports Second Quarter 2016 Financial Results

[0001262039-16-000076:8k_2_02:6]
Revenue and Billings Outperformance Highlights Fortinet’s Best-in-Class Security Fabric

[0001262039-16-000076:8k_2_02:7]
•Revenue of $311.4 million, up 30% year over year

[0001262039-16-000076:8k_2_02:8]
•Billings of $373.8 million, up 26% year over year1

[0001262039-16-000076:8k_2_02:9]
•GAAP diluted net loss per share $0.01

[0001262039-16-000076:8k_2_02:10]
•Non-GAAP diluted net income per share of $0.141

[0001262039-16-000076:8k_2_02:11]
•Cash flow from operations of $67.9 million

[0001262039-16-000076:8k_2_02:12]
•Free cash flow of $53.5 million1

[0001262039-16-000076:8k_2_02:13]
| • | Cash, cash equivalents and investments of $1.22 billion |

[0001262039-16-000076:8k_2_02:14]
| • | Deferred revenue of $904.0 million, up 37% year over year |

[0001262039-16-000076:8k_2_02:15]
SUNNYVALE, Calif. - July 28, 2016 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the second quarter ended June 30, 2016.

[0001262039-16-000076:8k_2_02:16]
“We are pleased with our billings and revenue over performance and ability to meet our expense and profitability targets while still investing for growth,” said Ken Xie, founder, chairman and chief executive officer. “The threat landscape and network architectures are evolving and shifting to integrated end-to-end platforms, which is the vision Fortinet was founded upon.  Our strong innovation and ability to provide a seamless, tightly-integrated and intelligent Security Fabric that protects all points in the network - from IoT to cloud - positions us well for continued growth and share gains in 2016 and beyond.”

[0001262039-16-000076:8k_2_02:17]
Financial Highlights for the Second Quarter of 2016

[0001262039-16-000076:8k_2_02:18]
| • | Revenue: Total revenue was $311.4 million for the second quarter of 2016, an increase of 30% compared to $239.8 million in the same quarter of 2015. Within total revenue, product revenue was $136.6 million, an increase of 19% compared to $114.8 million in the same quarter of 2015. Service revenue was $174.8 million, an increase of 40% compared to $125.0 million in the same quarter of 2015. |

[0001262039-16-000076:8k_2_02:19]
| • | Billings1: Total billings were $373.8 million for the second quarter of 2016, an increase of 26% compared to $297.2 million in the same quarter of 2015. |

[0001262039-16-000076:8k_2_02:20]
| • | Deferred Revenue: Total deferred revenue was $904.0 million as of June 30, 2016, an increase of $66.8 million compared to $837.2 million as of March 31, 2016. |

[0001262039-16-000076:8k_2_02:21]
| • | Cash and Cash Flow: As of June 30, 2016, cash, cash equivalents and investments were $1.22 billion, compared to $1.19 billion as of March 31, 2016. In the second quarter of 2016, cash flow from operations was $67.9 million compared to $84.3 million in the same quarter of 2015. Free cash flow1 was $53.5 million during the second quarter of 2016 compared to $73.5 million in the same quarter of 2015. |

[0001262039-16-000076:8k_2_02:22]
| • | GAAP Operating Income or Loss: GAAP operating loss was $4.0 million for the second quarter of 2016, representing a GAAP operating margin of -1%. GAAP operating income was $3.0 million for the same quarter of 2015, representing a GAAP operating margin of 1%. |

[0001262039-16-000076:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $36.0 million for the second quarter of 2016, representing a non-GAAP operating margin of 12%. Non-GAAP operating income was $29.3 million for the same quarter of 2015, representing a non-GAAP operating margin of 12%. |

[0001262039-16-000076:8k_2_02:24]
| • | GAAP Net Income or Loss and Diluted Net Income or Loss Per Share: GAAP net loss was $1.4 million for the second quarter of 2016, compared to GAAP net income of $0.8 million for the same quarter of 2015. GAAP diluted net loss per share was $0.01 for the second quarter of 2016. GAAP diluted net income per share was break-even for the second quarter of 2015. |

[0001262039-16-000076:8k_2_02:25]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $24.0 million for the second quarter of 2016, compared to non-GAAP net income of $19.4 million for the same quarter of 2015. Non-GAAP diluted net income per share was $0.14 for the second quarter of 2016, compared to $0.11 for the same quarter of 2015. |

[0001262039-16-000076:8k_2_02:26]
1 A reconciliation of GAAP to non-GAAP financial measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-16-000076:8k_2_02:27]
Conference Call Details

[0001262039-16-000076:8k_2_02:28]
Fortinet will host a conference call today, July 28, 2016, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 25654626. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through August 4, 2016, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 25654626.

[0001262039-16-000076:8k_2_02:29]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 25664452. This follow-up call will be webcast live and accessible at http://investor.fortinet.com,

[0001262039-16-000076:8k_2_02:30]
and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through August 4, 2016 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 25664452.

[0001262039-16-000076:8k_2_02:31]
About Fortinet (www.fortinet.com)

[0001262039-16-000076:8k_2_02:32]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. More than 280,000 customers worldwide trust Fortinet to protect their businesses. Learn more at http://www.fortinet.com, the Fortinet Blog, or FortiGuard Labs.

[0001262039-16-000076:8k_2_02:33]
#          #          #

[0001262039-16-000076:8k_2_02:34]
Copyright © 2016 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-16-000076:8k_2_02:35]
FTNT-F

[0001262039-16-000076:8k_2_02:36]
Forward-looking Statements

[0001262039-16-000076:8k_2_02:37]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding market adoption of cybersecurity and expectations regarding positioning for market share gains and growth potential. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions and foreign currency risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise customers; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; execution risks around new product development and introductions, and innovation and market acceptance of new products; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments; competition and pricing pressure; risks related to integrating acquisitions; and the other risk factors set forth from time to time in our most recent Annual Report on Form 10-K, our most

[0001262039-16-000076:8k_2_02:38]
Non-GAAP Financial Measures

[0001262039-16-000076:8k_2_02:39]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-16-000076:8k_2_02:40]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-16-000076:8k_2_02:41]
Billings. We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drives future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000076:8k_2_02:42]
Free cash flow. We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-16-000076:8k_2_02:43]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, including inventory fair value adjustment amortization and other purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees’ compensation and may impact their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income or loss calculated in accordance with GAAP.

[0001262039-16-000076:8k_2_02:44]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, adjusted for the impact of the tax adjustment, if any required, resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income (loss) and diluted net income per share calculated in accordance with GAAP.

[0001262039-16-000076:8k_2_02:45]
FORTINET, INC.

[0001262039-16-000076:8k_2_02:46]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-16-000076:8k_2_02:47]
(Unaudited, in thousands)

[0001262039-16-000076:8k_2_02:48]
|  | June 30, 2016 |  | December 31, 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 596,380 |  |  | $ | 543,277 |  |
| Short-term investments | 388,388 |  |  | 348,074 |  |
| Accounts receivable—net | 254,379 |  |  | 259,563 |  |
| Inventory | 81,247 |  |  | 83,868 |  |
| Prepaid expenses and other current assets | 33,490 |  |  | 35,761 |  |
| Total current assets | 1,353,884 |  |  | 1,270,543 |  |
| LONG-TERM INVESTMENTS | 237,223 |  |  | 272,959 |  |
| DEFFERRED TAX ASSETS | 180,782 |  |  | 119,216 |  |
| PROPERTY AND EQUIPMENT—net | 125,636 |  |  | 91,067 |  |
| OTHER INTANGIBLE ASSETS—net | 31,488 |  |  | 17,640 |  |
| GOODWILL | 14,235 |  |  | 4,692 |  |
| OTHER ASSETS | 16,930 |  |  | 14,393 |  |
| TOTAL ASSETS | $ | 1,960,178 |  |  | $ | 1,790,510 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 56,920 |  |  | $ | 61,500 |  |
| Accrued liabilities | 32,901 |  |  | 33,028 |  |
| Accrued payroll and compensation | 70,787 |  |  | 61,111 |  |
| Income taxes payable | 8,161 |  |  | 8,379 |  |
| Deferred revenue | 563,195 |  |  | 514,652 |  |
| Total current liabilities | 731,964 |  |  | 678,670 |  |
| DEFERRED REVENUE | 340,786 |  |  | 276,651 |  |
| INCOME TAXES LIABILITIES | 66,304 |  |  | 60,624 |  |
| OTHER LIABILITIES | 16,498 |  |  | 19,188 |  |
| Total liabilities | 1,155,552 |  |  | 1,035,133 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 172 |  |  | 171 |  |
| Additional paid-in capital | 744,922 |  |  | 687,658 |  |
| Accumulated other comprehensive income (loss) | 724 |  |  | (933 | ) |
| Retained earnings | 58,808 |  |  | 68,481 |  |
| Total stockholders’ equity | 804,626 |  |  | 755,377 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,960,178 |  |  | $ | 1,790,510 |  |

[0001262039-16-000076:8k_2_02:49]
FORTINET, INC.

[0001262039-16-000076:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-16-000076:8k_2_02:51]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000076:8k_2_02:52]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 136,641 |  |  | $ | 114,777 |  |  | $ | 261,213 |  |  | $ | 212,286 |  |
| Service | 174,750 |  |  | 125,008 |  |  | 334,754 |  |  | 240,385 |  |
| Total revenue | 311,391 |  |  | 239,785 |  |  | 595,967 |  |  | 452,671 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 52,788 |  |  | 47,397 |  |  | 102,101 |  |  | 88,765 |  |
| Service 1 | 31,715 |  |  | 22,101 |  |  | 60,046 |  |  | 44,335 |  |
| Total cost of revenue | 84,503 |  |  | 69,498 |  |  | 162,147 |  |  | 133,100 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 83,853 |  |  | 67,380 |  |  | 159,112 |  |  | 123,521 |  |
| Service | 143,035 |  |  | 102,907 |  |  | 274,708 |  |  | 196,050 |  |
| Total gross profit | 226,888 |  |  | 170,287 |  |  | 433,820 |  |  | 319,571 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 45,502 |  |  | 37,389 |  |  | 90,256 |  |  | 73,205 |  |
| Sales and marketing 1 | 162,694 |  |  | 111,928 |  |  | 308,797 |  |  | 212,537 |  |
| General and administrative 1 | 22,184 |  |  | 18,018 |  |  | 41,623 |  |  | 29,979 |  |
| Restructuring charges | 553 |  |  | — |  |  | 881 |  |  | — |  |
| Total operating expenses | 230,933 |  |  | 167,335 |  |  | 441,557 |  |  | 315,721 |  |
| OPERATING INCOME (LOSS) | (4,045 | ) |  | 2,952 |  |  | (7,737 | ) |  | 3,850 |  |
| INTEREST INCOME | 1,705 |  |  | 1,364 |  |  | 3,451 |  |  | 2,786 |  |
| OTHER EXPENSE—net | (1,350 | ) |  | (830 | ) |  | (2,662 | ) |  | (1,507 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | (3,690 | ) |  | 3,486 |  |  | (6,948 | ) |  | 5,129 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES 2 | (2,302 | ) |  | 2,694 |  |  | (7,678 | ) |  | 2,777 |  |
| NET INCOME (LOSS) | $ | (1,388 | ) |  | $ | 792 |  |  | $ | 730 |  |  | $ | 2,352 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.01 | ) |  | $ | — |  |  | $ | — |  |  | $ | 0.01 |  |
| Diluted | $ | (0.01 | ) |  | $ | — |  |  | $ | — |  |  | $ | 0.01 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 172,075 |  |  | 169,930 |  |  | 171,910 |  |  | 169,009 |  |
| Diluted | 172,075 |  |  | 176,234 |  |  | 175,360 |  |  | 174,983 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 298 |  |  | $ | 210 |  |  | $ | 578 |  |  | $ | 350 |  |
| Cost of service revenue | 2,123 |  |  | 1,660 |  |  | 4,257 |  |  | 3,292 |  |
| Research and development | 7,458 |  |  | 5,541 |  |  | 14,601 |  |  | 10,698 |  |
| Sales and marketing | 16,990 |  |  | 11,271 |  |  | 32,805 |  |  | 20,578 |  |
| General and administrative | 3,478 |  |  | 3,078 |  |  | 7,008 |  |  | 5,764 |  |
|  | $ | 30,347 |  |  | $ | 21,760 |  |  | $ | 59,249 |  |  | $ | 40,682 |  |
| In March 2016, the Financial Accounting Standards Board issued Accounting Standard Update ("ASU") No. 2016-09, which allows a company to make a policy election to account for forfeitures as they occur. We early adopted this standard and elected to account for forfeitures as they occur using the modified retrospective transition method. The adoption of this standard resulted in a decrease of $2.0 million in our share-based compensation during the first quarter of 2016. The adjustment was reflected in the six-months ended June 30, 2016 condensed consolidated statement of operations. |
| 2 The adoption of ASU 2016-09 resulted in a decrease of $3.6 million in our provision for income taxes during the first quarter of 2016. The adjustment was reflected in the six-months ended June 30, 2016 condensed consolidated statement of operations. |

[0001262039-16-000076:8k_2_02:53]
FORTINET, INC.

[0001262039-16-000076:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)

[0001262039-16-000076:8k_2_02:55]
(Unaudited, in thousands)

[0001262039-16-000076:8k_2_02:56]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Net income (loss) | $ | (1,388 | ) |  | $ | 792 |  |  | $ | 730 |  |  | $ | 2,352 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Unrealized gains (losses) on investments | 662 |  |  | (822 | ) |  | 2,549 |  |  | 63 |  |
| Tax provision (benefit) related to items of other comprehensive income | 232 |  |  | (287 | ) |  | 892 |  |  | 23 |  |
| Other comprehensive income (loss)—net of taxes | 430 |  |  | (535 | ) |  | 1,657 |  |  | 40 |  |
| Comprehensive income (loss) | $ | (958 | ) |  | $ | 257 |  |  | $ | 2,387 |  |  | $ | 2,392 |  |

[0001262039-16-000076:8k_2_02:57]
FORTINET, INC.

[0001262039-16-000076:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-16-000076:8k_2_02:59]
(Unaudited, in thousands)

[0001262039-16-000076:8k_2_02:60]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 730 |  |  | $ | 2,352 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 21,841 |  |  | 13,382 |  |
| Amortization of investment premiums | 2,794 |  |  | 3,881 |  |
| Stock-based compensation | 59,249 |  |  | 40,525 |  |
| Other non-cash items—net | 1,192 |  |  | 1,891 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 2,022 |  |  | 9,523 |  |
| Inventory | (8,019 | ) |  | (7,917 | ) |
| Deferred tax assets | (27,120 | ) |  | (13,072 | ) |
| Prepaid expenses and other current assets | 2,442 |  |  | (3,492 | ) |
| Other assets | (2,409 | ) |  | (513 | ) |
| Accounts payable | (130 | ) |  | (8,383 | ) |
| Accrued liabilities | (6,426 | ) |  | (228 | ) |
| Accrued payroll and compensation | 8,679 |  |  | 5,670 |  |
| Other liabilities | (2,858 | ) |  | (1,884 | ) |
| Deferred revenue | 111,082 |  |  | 97,156 |  |
| Income taxes payable | 5,463 |  |  | 10,033 |  |
| Net cash provided by operating activities | 168,532 |  |  | 148,924 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (230,855 | ) |  | (229,479 | ) |
| Sales of investments | 7,366 |  |  | 22,472 |  |
| Maturities of investments | 219,131 |  |  | 240,625 |  |
| Purchases of property and equipment | (44,399 | ) |  | (15,688 | ) |
| Payments made in connection with business acquisition, net of cash acquired | (20,660 | ) |  | — |  |
| Net cash provided by (used in) investing activities | (69,417 | ) |  | 17,930 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 22,972 |  |  | 42,647 |  |
| Taxes paid related to net share settlement of equity awards | (17,358 | ) |  | (11,362 | ) |
| Repurchase and retirement of common stock | (50,000 | ) |  | — |  |
| Payments of debt assumed in connection with business acquisition | (1,626 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (46,012 | ) |  | 31,285 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 53,103 |  |  | 198,139 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 543,277 |  |  | 283,254 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 596,380 |  |  | $ | 481,393 |  |

[0001262039-16-000076:8k_2_02:61]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-16-000076:8k_2_02:62]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000076:8k_2_02:63]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-16-000076:8k_2_02:64]
|  | Three Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Net cash provided by operating activities | $ | 67,941 |  |  | $ | 84,305 |  |
| Less purchases of property and equipment | (14,443 | ) |  | (10,761 | ) |
| Free cash flow | $ | 53,498 |  |  | $ | 73,544 |  |

[0001262039-16-000076:8k_2_02:65]
Reconciliation of GAAP operating income or loss to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-16-000076:8k_2_02:66]
|  | Three Months Ended June 30, 2016 |  | Three Months Ended June 30, 2015 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income (loss) | $ | (4,045 | ) |  | $ | 40,016 |  | (a) | $ | 35,971 |  |  | $ | 2,952 |  |  | $ | 26,339 |  | (b) | $ | 29,291 |  |
| Operating margin | -1 | % |  |  |  | 12 | % |  | 1 | % |  |  |  | 12 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 30,347 |  |  |  |  |  |  | 21,760 |  |  |  |
| Impairment of intangible assets |  |  | — |  |  |  |  |  |  | 1,593 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,269 |  |  |  |  |  |  | 244 |  |  |  |
| ERP-related expenses |  |  | 6,316 |  |  |  |  |  |  | 1,395 |  |  |  |
| Acquisition-related charges |  |  | 254 |  |  |  |  |  |  | 1,347 |  |  |  |
| Inventory fair value adjustment amortization |  |  | 277 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 553 |  |  |  |  |  |  | — |  |  |  |
| Tax adjustment |  |  | (14,653 | ) | (c) |  |  |  |  | (7,745 | ) | (c) |  |
| Net income (loss) | $ | (1,388 | ) |  | $ | 25,363 |  |  | $ | 23,975 |  |  | $ | 792 |  |  | $ | 18,594 |  |  | $ | 19,386 |  |
| Diluted net income (loss) per share | $ | (0.01 | ) |  |  |  | $ | 0.14 |  |  | $ | — |  |  |  |  | $ | 0.11 |  |
| Shares used in diluted net income (loss) per share calculations | 172,075 |  |  |  |  | 176,298 |  |  | 176,234 |  |  |  |  | 176,234 |  |

[0001262039-16-000076:8k_2_02:67]
(a) To exclude $30.3 million of stock-based compensation, $2.3 million of amortization of acquired intangible assets, $6.3 million of ERP-related expenses, $0.3 million of acquisition-related charges, $0.3 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition and $0.6 million of restructuring charges in the three months ended June 30, 2016.

[0001262039-16-000076:8k_2_02:68]
(b) To exclude $21.8 million of stock-based compensation, $1.6 million impairment of acquired intangible assets, $0.2 million of amortization of acquired intangible assets, $1.4 million of ERP-related expenses, and $1.3 million in acquisition-related charges in the three months ended June 30, 2015.

[0001262039-16-000076:8k_2_02:69]
(c)  Non-GAAP financial information is adjusted to achieve an overall 34% percent and 35% percent effective tax rate in the three months ended June 30, 2016 and June 30, 2015, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-16-000076:8k_2_02:70]
Reconciliation of diluted weighted average shares outstanding used in the calculation of GAAP and non-GAAP earnings per share

[0001262039-16-000076:8k_2_02:71]
|  |  | Three Months Ended |
|  |  | June 30, 2016 |  | June 30, 2015 |
| Shares used in diluted net loss per share calculations - GAAP |  | 172,075 |  |  | 176,234 |  |
| Adjustment for diluted weighted average shares outstanding | (a) | 4,223 |  |  | — |  |
| Shares used in diluted net income per share calculations - Non-GAAP |  | 176,298 |  |  | 176,234 |  |

[0001262039-16-000076:8k_2_02:72]
(a) GAAP diluted weighted average shares outstanding differs from non-GAAP diluted weighted average shares outstanding in periods when we have a GAAP net loss and a non-GAAP net income. The adjustment for diluted weighted average shares outstanding represents the dilutive effect of employee equity incentive plan awards and is calculated by applying the treasury stock method.

[0001262039-16-000076:8k_2_02:73]
Billings Reconciliation

[0001262039-16-000076:8k_2_02:74]
|  | Three Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Total revenue | $ | 311,391 |  |  | $ | 239,785 |  |
| Add increase in deferred revenue | 66,793 |  |  | 57,390 |  |
| Less deferred revenue balance acquired in business acquisition | (4,400 | ) |  | — |  |
| Total billings | $ | 373,784 |  |  | $ | 297,175 |  |
