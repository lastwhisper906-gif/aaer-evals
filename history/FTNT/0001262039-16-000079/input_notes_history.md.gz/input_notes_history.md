# FTNT note change history — 0001262039-16-000064 → 0001262039-16-000079


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001262039-16-000079:note_history:1]
Our future principal contractual obligations as of June 30, 2016 were (in thousands):
  (was, 2016-05-06, similarity 0.7594):
[0001262039-16-000064:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2016 (in thousands):

- changed (2016-08-05):
[0001262039-16-000079:note_history:2]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $2.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively. Rent expense was $8.5 million and $6.0 million during the six months ended June 30, 2016 and June 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2016-05-06, similarity 0.7443):
[0001262039-16-000064:note_history:2]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.6 million and $3.1 million during the three months ended March 31, 2016 and March 31, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2016-08-05):
[0001262039-16-000079:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2016, we had $86.4 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2016-05-06, similarity 0.9933):
[0001262039-16-000064:note_history:3]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2016, we had $77.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2016-08-05):
[0001262039-16-000079:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2016, we had $52.1 million in other contractual commitments that may not be cancelable.
  (was, 2016-05-06, similarity 0.987):
[0001262039-16-000064:note_history:4]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2016, we had $49.0 million in other contractual commitments that may not be cancelable.

- added (2016-08-05):
[0001262039-16-000079:note_history:5]
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (1,481 | ) |  | (2,059 | ) |
| Provision for warranty for the period | 718 |  |  | 2,294 |  |
| Adjustment related to pre-existing warranties | (225 | ) |  | 171 |  |
| Accrued warranty balance—end of the period | $ | 2,156 |  |  | $ | 4,675 |  |

- changed (2016-08-05):
[0001262039-16-000079:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.
  (was, 2016-05-06, similarity 0.9961):
[0001262039-16-000064:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible loss is reasonably estimable.

- removed (2016-08-05):
[0001262039-16-000064:note_history:7]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (511 | ) |  | (1,095 | ) |
| Provision for warranty for the period | 377 |  |  | 945 |  |
| Adjustment related to pre-existing warranties | (353 | ) |  | 222 |  |
| Accrued warranty balance—end of the period | $ | 2,657 |  |  | $ | 4,341 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001262039-16-000079:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.
  (was, 2016-05-06, similarity 0.9841):
[0001262039-16-000064:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

- added (2016-08-05):
[0001262039-16-000079:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”

- added (2016-08-05):
[0001262039-16-000079:note_history:10]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur. The new standard is effective for us beginning January 1, 2017, with early adoption permitted.

- added (2016-08-05):
[0001262039-16-000079:note_history:11]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits amounting to $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016 and $2.6 million during the second quarter of 2016.

- added (2016-08-05):
[0001262039-16-000079:note_history:12]
Under the new guidance, we have elected to change our policy and have started to recognize forfeitures of awards as they occur. The change in forfeiture policy was adopted using a modified retrospective transition method. We recorded a cumulative-effect adjustment to decrease retained earnings by $0.8 million upon transition on January 1, 2016 and a retrospective decrease of stock-based compensation of $2.0 million during the first quarter of 2016.

- added (2016-08-05):
[0001262039-16-000079:note_history:13]
The amendment to the minimum statutory withholding tax requirements was adopted on a modified retrospective basis. The adoption had no impact on the January 1, 2016 retained earnings. In addition, we adopted the presentation of taxes paid related to net share settlement of equity awards as a financing activity on the statement of cash flows on a retrospective basis.  Our adoption had no impact to any of the periods presented in our consolidated cash flows statements since such cash flows have historically been presented as a financing activity.

- added (2016-08-05):
[0001262039-16-000079:note_history:14]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

- added (2016-08-05):
[0001262039-16-000079:note_history:15]
|  | Three Months Ended |
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Statements of Operations: |  |  |  |
| Stock-based compensation expense | $ | 30,881 |  |  | $ | 28,901 |  |
| Benefit from income taxes | $ | (1,809 | ) |  | $ | (5,376 | ) |
| Net income (loss) | $ | (3,429 | ) |  | $ | 2,118 |  |
| Net income (loss) per share—Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Net income (loss) per share—Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding—Diluted | 171,745 |  |  | 174,421 |  |

- added (2016-08-05):
[0001262039-16-000079:note_history:16]
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Balance Sheets: |  |  |  |
| Deferred tax assets | $ | 131,696 |  |  | $ | 167,625 |  |
| Additional paid-in capital | $ | 718,849 |  |  | $ | 717,671 |  |
| Retained earnings | $ | 23,089 |  |  | $ | 60,196 |  |

- changed (2016-08-05):
[0001262039-16-000079:note_history:17]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.
  (was, 2016-05-06, similarity 0.9289):
[0001262039-16-000064:note_history:17]
In September 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 did not have any impact on our consolidated financial statements.

- changed (2016-08-05):
[0001262039-16-000079:note_history:18]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the full impact ASU 2016-02 will have on our consolidated financial statements.
  (was, 2016-05-06, similarity 0.9274):
[0001262039-16-000064:note_history:18]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We are currently evaluating the impact ASU 2016-02 will have on our consolidated financial statements.

- changed (2016-08-05):
[0001262039-16-000079:note_history:19]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.
  (was, 2016-05-06, similarity 0.725):
[0001262039-16-000064:note_history:19]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. These standards will be effective for us beginning on January 1, 2018, with the option to adopt earlier on January 1, 2017. We are currently evaluating the impact of these new standards on our consolidated financial statements.

- removed (2016-08-05):
[0001262039-16-000064:note_history:20]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2016.

- removed (2016-08-05):
[0001262039-16-000064:note_history:21]
In April 2015, the FASB issued ASU 2015-05—Intangibles—Goodwill and Other—Internal—Use Software— Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a significant impact on our consolidated financial statements.

- removed (2016-08-05):
[0001262039-16-000064:note_history:22]
In February 2015, the FASB issued ASU 2015-02—Consolidation—Amendments to the Consolidation Analysis, which updates the accounting guidance on consolidation requirements. This update changes the guidance with respect to the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. ASU 2015-02 also makes several modifications to the consolidation guidance for variable interest entities (“VIEs”). We adopted ASU 2015-02 on January 1, 2016. The adoption of ASU 2015-02 did not have any impact on our consolidated financial statements.

- removed (2016-08-05):
[0001262039-16-000064:note_history:23]
In March 2016, the FASB issued ASU 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting, which changes certain aspects of accounting for shared-based payments to employees. The new guidance will require all income tax effects of awards to be recognized in the income statement for the period in which the awards vest or are settled. It also allows an employer to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting and to make a policy election to account for forfeitures as they occur. This new guidance will be effective for us beginning on January 1, 2017, and interim periods within those fiscal years. Early adoption is permitted in any annual or interim period for which financial statements have not been issued or made available for issuance, but all of the guidance must be adopted in the same period. We are currently evaluating the impact ASU 2016-09 will have on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0001262039-16-000079:note_history:24]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.1 million and $0.9 million during the three months ended June 30, 2016 and June 30, 2015, respectively.  No contingent fees were incurred during the three months ended June 30, 2016 and June 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.4 million and $2.8 million during the six months ended June 30, 2016 and June 30, 2015, respectively.  Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements during the six months ended June 30, 2016 and June 30, 2015, respectively. Amounts due and payable to the law firm were $0.3 million and $5.3 million as of June 30, 2016 and December 31, 2015, respectively.

- removed (2016-08-05):
[0001262039-16-000064:note_history:25]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $1.9 million in the three months ended March 31, 2016 and March 31, 2015, respectively. Of such amounts, $0.2 million and $0.5 million were incurred under contingent fee arrangements in the three months ended March 31, 2016 and March 31, 2015, respectively. Amounts due and payable to the law firm were $0.4 million and $5.3 million as of March 31, 2016 and December 31, 2015, respectively.
