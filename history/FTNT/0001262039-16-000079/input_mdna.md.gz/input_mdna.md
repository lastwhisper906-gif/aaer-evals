# FTNT MD&A — 0001262039-16-000079


## mdna

[0001262039-16-000079:mdna:1]
[same as prior period, unchanged from 0001262039-16-000064:mdna:1]

[0001262039-16-000079:mdna:2]
[same as prior period, unchanged from 0001262039-16-000064:mdna:2]

[0001262039-16-000079:mdna:3]
[same as prior period, unchanged from 0001262039-16-000064:mdna:3]

[0001262039-16-000079:mdna:4]
| • | expected impact of sales of certain products and services; |

[0001262039-16-000079:mdna:5]
| • | the proportion of our revenue that consists of our product and service and other revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-16-000079:mdna:6]
[same as prior period, unchanged from 0001262039-16-000064:mdna:6]

[0001262039-16-000079:mdna:7]
[same as prior period, unchanged from 0001262039-16-000064:mdna:7]

[0001262039-16-000079:mdna:8]
| • | growing our sales to enterprise, service provider and government organizations, and the impact of sales to these organizations on our long-term growth, expansion and operating results; |

[0001262039-16-000079:mdna:9]
| • | trends in revenue, costs of revenue and gross margin; |

[0001262039-16-000079:mdna:10]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses as a percentage of revenue; |

[0001262039-16-000079:mdna:11]
[same as prior period, unchanged from 0001262039-16-000064:mdna:11]

[0001262039-16-000079:mdna:12]
| • | managing our continued investments in sales and marketing, and the impact of those investments; |

[0001262039-16-000079:mdna:13]
[same as prior period, unchanged from 0001262039-16-000064:mdna:13]

[0001262039-16-000079:mdna:14]
[same as prior period, unchanged from 0001262039-16-000064:mdna:14]

[0001262039-16-000079:mdna:15]
[same as prior period, unchanged from 0001262039-16-000064:mdna:15]

[0001262039-16-000079:mdna:16]
| • | integration of acquired companies and technologies and expectations related to acquisitions; |

[0001262039-16-000079:mdna:17]
| • | success of our recently implemented enterprise resource planning (“ERP”) system; |

[0001262039-16-000079:mdna:18]
[same as prior period, unchanged from 0001262039-16-000064:mdna:18]

[0001262039-16-000079:mdna:19]
[same as prior period, unchanged from 0001262039-16-000064:mdna:19]

[0001262039-16-000079:mdna:20]
[same as prior period, unchanged from 0001262039-16-000064:mdna:20]

[0001262039-16-000079:mdna:21]
[same as prior period, unchanged from 0001262039-16-000064:mdna:21]

[0001262039-16-000079:mdna:22]
Our common operating system, centralized management and open application program interfaces allow many of the solutions in our portfolio to be combined to create an integrated security architecture (“Fortinet Security Fabric”) designed to address sophisticated threats and next-generation environments. The Fortinet Security Fabric connects our products, services and ecosystem partner solutions to help provide seamless protection at all points in the network, from endpoint to data center to cloud, regardless of whether deployed in physical, virtual or hybrid environments. Our Security Fabric delivers integrated scalability, access, awareness, security and openness both from the cloud and for the cloud.  At the core of our Security Fabric is our FortiGate physical and virtual appliances, which ship with a set of broad security services, including firewall, virtual private network, application control, intrusion prevention, web filtering and advanced threat protection. These security services are enabled by our FortiGuard Labs, which provides extensive threat research and a global cloud network to deliver protection services to each FortiGate appliance. FortiGate also has extensive networking capabilities such as switching, routing, native internet protocol version 6 and different modes of deployment. FortiManager provides central management and FortiAnalyzer provides reporting and analytics.

[0001262039-16-000079:mdna:23]
Enterprise customers select the form factor and deployment method that best meet their specific security requirements, such as a high-speed data center firewall at the network core, a next generation firewall at the edge or a distributed firewall solutions at branch sites. Small businesses tend to deploy unified threat management devices. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses or distributed enterprises, FortiGate-200 to -900 series for mid-sized enterprises, to the FortiGate-1000 to -6000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, to which end-customers can subscribe in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering, and anti-spam functionality. End-customers can also choose to purchase FortiCare technical support services for our products. End-customers also often use FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide centralized management and analysis and reporting capabilities.

[0001262039-16-000079:mdna:24]
[same as prior period, unchanged from 0001262039-16-000064:mdna:24]

[0001262039-16-000079:mdna:25]
[same as prior period, unchanged from 0001262039-16-000064:mdna:25]

[0001262039-16-000079:mdna:26]
| • | We recorded total revenue of $311.4 million and $596.0 million during the three and six months ended June 30, 2016, respectively, an increase of 30% and 32%, respectively, compared to the same periods last year. Product revenue was $136.6 million and $261.2 million during the three and six months ended June 30, 2016, an increase of 19% and 23% compared to the same periods last year. Service revenue was $174.8 million and $334.8 million during the three and six months ended June 30, 2016, an increase of 40% and 39% compared to the same periods last year. |

[0001262039-16-000079:mdna:27]
| • | Cash, cash equivalents and investments were $1.22 billion as of June 30, 2016, an increase of $57.7 million, or 5%, from December 31, 2015. |

[0001262039-16-000079:mdna:28]
| • | Deferred revenue was $904.0 million as of June 30, 2016, an increase of $112.7 million, or 14%, from December 31, 2015. |

[0001262039-16-000079:mdna:29]
| • | We generated cash flows from operating activities of $168.5 million during the six months ended June 30, 2016, an increase of $19.6 million, or 13%, compared to the same period last year. |

[0001262039-16-000079:mdna:30]
| • | In June 2016, we acquired AccelOps, a provider of network security monitoring and analytics solutions, for a total cash consideration of $22.3 million. |

[0001262039-16-000079:mdna:31]
Revenue grew during the three and six months ended June 30, 2016 compared to the same periods last year, as our Security Fabric put us in a strong competitive position in a robust security market. Our strategy to invest in sales and marketing has enabled us to gain more enterprise customers today than we have had in the past. Large enterprises represent significant opportunity for cross-sell and upsell, as they tend to purchase more products and services over time. During the three months ended June 30, 2016, our revenue growth was driven by greater sales of our FortiGate and FortiGuard offerings, as we continued to see diversity of FortiGate product sales across all segments. Our high-end FortiGate products (FortiGate-1000 to -6000 series) accounted for 36% of billings. Our mid-range products (FortiGate-200 to -900 series) accounted for 28% of billings, and our entry-level products (FortiGate-20 to -100 series) accounted for 36% of billings. Service revenue also increased as we continue to add to and charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000079:mdna:32]
During the three and six months ended June 30, 2016, operating expenses increased by 38% and 40%, respectively, as compared to the same period last year. The increase was primarily driven by our accelerated pace of hiring and investments made to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains. In addition, we incurred expenses from business design and reengineering related to the implementation of an ERP system. Headcount increased by 37% to 4,562 employees and contractors as of June 30, 2016, up from 3,336 as of June 30, 2015.

[0001262039-16-000079:mdna:33]
[same as prior period, unchanged from 0001262039-16-000064:mdna:35]

[0001262039-16-000079:mdna:34]
Our sales strategy is based on a distribution model whereby we primarily sell our products and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, which have significant purchasing power and unique customer deployment requirements. Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical and virtual appliances, most frequently as part of a bundle offering that includes hardware and services. We invoice at the time of our sale for the total price of the products and subscription and technical support services for what has been delivered, and the invoice is generally payable within 30 to 90 days. We generally recognize product revenue up-front and defer revenue for the sale of new, and renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize the related service revenue over the service period, which is typically one to three years, although it can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which contributes significantly to our increase in gross margin, as well as our positive cash flow from operations.

[0001262039-16-000079:mdna:35]
[same as prior period, unchanged from 0001262039-16-000064:mdna:37]

[0001262039-16-000079:mdna:36]
We monitor a number of financial and operating metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings, cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow. We discuss revenue below under “—Results of Operations,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP) and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-16-000079:mdna:37]
|  | Three Months Ended Or As Of |
|  | June 30, 2016 |  | June 30, 2015 |
|  | (in thousands) |
| Revenue | $ | 311,391 |  |  | $ | 239,785 |  |
| Deferred revenue | $ | 903,981 |  |  | $ | 657,561 |  |
| Billings (Non-GAAP) | $ | 373,784 |  |  | $ | 297,175 |  |
| Cash, cash equivalents and investments | $ | 1,221,991 |  |  | $ | 1,148,371 |  |
| Net cash provided by operating activities | $ | 67,941 |  |  | $ | 84,305 |  |
| Free cash flow (Non-GAAP) | $ | 53,498 |  |  | $ | 73,544 |  |

[0001262039-16-000079:mdna:38]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance and the mix of short-term and long-term deferred revenue because it represents a significant portion, and the timing, of revenue to be recognized in future periods.

[0001262039-16-000079:mdna:39]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000079:mdna:40]
[same as prior period, unchanged from 0001262039-16-000064:mdna:43]

[0001262039-16-000079:mdna:41]
|  | Three Months Ended |
| June 30, 2016 |  | June 30, 2015 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 311,391 |  |  | $ | 239,785 |  |
| Add increase in deferred revenue | 66,793 |  |  | 57,390 |  |
| Less deferred revenue balance acquired in business acquisition | (4,400 | ) |  | — |  |
| Total billings (Non-GAAP) | $ | 373,784 |  |  | $ | 297,175 |  |

[0001262039-16-000079:mdna:42]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources.”  A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-16-000079:mdna:43]
|  | Three Months Ended |
| June 30, 2016 |  | June 30, 2015 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 67,941 |  |  | $ | 84,305 |  |
| Less purchases of property and equipment | (14,443 | ) |  | (10,761 | ) |
| Free cash flow (Non-GAAP) | $ | 53,498 |  |  | $ | 73,544 |  |

[0001262039-16-000079:mdna:44]
[same as prior period, unchanged from 0001262039-16-000064:mdna:63]

[0001262039-16-000079:mdna:45]
[same as prior period, unchanged from 0001262039-16-000064:mdna:47]

[0001262039-16-000079:mdna:46]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. Our estimates include those related to revenue recognition, stock-based compensation expense, valuation of inventory, warranty liabilities, investments, business combinations, restructuring charges, goodwill and other long-lived assets, and accounting for income taxes. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-16-000079:mdna:47]
Except for the change in certain policies around stock-based compensation as a result of the early adoption of ASU 2016-09, there have been no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2016, as compared to the critical accounting policies and estimates described in the Form 10-K. See Note 1 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for a discussion relating to our change in certain accounting policies related to stock-based compensation.

[0001262039-16-000079:mdna:48]
[same as prior period, unchanged from 0001262039-16-000064:mdna:52]

[0001262039-16-000079:mdna:49]
[same as prior period, unchanged from 0001262039-16-000064:mdna:53]

[0001262039-16-000079:mdna:50]
[same as prior period, unchanged from 0001262039-16-000064:mdna:55]

[0001262039-16-000079:mdna:51]
Three Months Ended June 30, 2016 and 2015

[0001262039-16-000079:mdna:52]
[same as prior period, unchanged from 0001262039-16-000064:mdna:57]

[0001262039-16-000079:mdna:53]
|  | Three Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 136,641 |  |  | 44 | % |  | $ | 114,777 |  |  | 48 | % |  | $ | 21,864 |  |  | 19 | % |
| Service | 174,750 |  |  | 56 |  |  | 125,008 |  |  | 52 |  |  | 49,742 |  |  | 40 |  |
| Total revenue | $ | 311,391 |  |  | 100 | % |  | $ | 239,785 |  |  | 100 | % |  | $ | 71,606 |  |  | 30 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 132,646 |  |  | 43 | % |  | $ | 108,593 |  |  | 45 | % |  | $ | 24,053 |  |  | 22 | % |
| EMEA | 114,453 |  |  | 36 |  |  | 83,404 |  |  | 35 |  |  | 31,049 |  |  | 37 |  |
| APAC | 64,292 |  |  | 21 |  |  | 47,788 |  |  | 20 |  |  | 16,504 |  |  | 35 |  |
| Total revenue | $ | 311,391 |  |  | 100 | % |  | $ | 239,785 |  |  | 100 | % |  | $ | 71,606 |  |  | 30 | % |

[0001262039-16-000079:mdna:54]
Total revenue increased by $71.6 million, or 30%, during the three months ended June 30, 2016 compared to the same period last year. On a geographic basis, revenue continued to be diversified globally. All three regions experienced revenue growth compared to the same period last year, with EMEA contributing to the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $21.9 million, or 19%, during the three months ended June 30, 2016 compared to the same period last year. The increase in product revenue was primarily driven by greater sales of our FortiGate product family, as well as growth in other product lines. Service revenue increased by $49.7 million, or 40%, during the three months ended June 30, 2016 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. Service revenue also increased as we continue to add to and charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000079:mdna:55]
[same as prior period, unchanged from 0001262039-16-000064:mdna:60]

[0001262039-16-000079:mdna:56]
|  | Three Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 52,788 |  |  | $ | 47,397 |  |  | $ | 5,391 |  |  | 11 | % |
| Service | 31,715 |  |  | 22,101 |  |  | 9,614 |  |  | 44 |  |
| Total cost of revenue | $ | 84,503 |  |  | $ | 69,498 |  |  | $ | 15,005 |  |  | 22 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.4 | % |  | 58.7 | % |  | 2.7 | % |  |  |
| Service | 81.9 |  |  | 82.3 |  |  | (0.4 | ) |  |  |
| Total gross margin | 72.9 | % |  | 71.0 | % |  | 1.9 | % |  |  |

[0001262039-16-000079:mdna:57]
Total gross margin increased by 1.9 percentage points during the three months ended June 30, 2016 compared to the same period last year, primarily driven by an increase in product gross margin. Product gross margin increased by 2.7 percentage points during the three months ended June 30, 2016 compared to the same period last year. Product gross margin was positively impacted by lower warranty expense, as well as higher sales of software products such as certain of our virtualized security solutions.

[0001262039-16-000079:mdna:58]
32

[0001262039-16-000079:mdna:59]
Service gross margin decreased by 0.4 percentage points during the three months ended June 30, 2016 as compared to the same period last year. Cost of service revenue increased by $9.6 million primarily due to a $5.8 million increase in personnel costs related to headcount increases. In addition, cost of service revenue increased due to an increase in product replacement costs related to our extended support service offerings.

[0001262039-16-000079:mdna:60]
[same as prior period, unchanged from 0001262039-16-000064:mdna:65]

[0001262039-16-000079:mdna:61]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2016 |  | June 30, 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 45,502 |  |  | 15 | % |  | $ | 37,389 |  |  | 16 | % |  | $ | 8,113 |  |  | 22 | % |
| Sales and marketing | 162,694 |  |  | 52 |  |  | 111,928 |  |  | 47 |  |  | 50,766 |  |  | 45 |  |
| General and administrative | 22,184 |  |  | 7 |  |  | 18,018 |  |  | 8 |  |  | 4,166 |  |  | 23 |  |
| Restructuring charges | 553 |  |  | — |  |  | — |  |  | — |  |  | 553 |  |  | * |  |
| Total operating expenses | $ | 230,933 |  |  | 74 | % |  | $ | 167,335 |  |  | 70 | % |  | $ | 63,598 |  |  | 38 | % |

[0001262039-16-000079:mdna:62]
[same as prior period, unchanged from 0001262039-16-000064:mdna:81]

[0001262039-16-000079:mdna:63]
[same as prior period, unchanged from 0001262039-16-000064:mdna:67]

[0001262039-16-000079:mdna:64]
Research and development expense increased by $8.1 million, or 22%, during the three months ended June 30, 2016 compared to the same period last year, primarily due to an increase of $6.1 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $1.5 million. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000079:mdna:65]
[same as prior period, unchanged from 0001262039-16-000064:mdna:69]

[0001262039-16-000079:mdna:66]
Sales and marketing expense increased by $50.8 million, or 45%, during the three months ended June 30, 2016 compared to the same period last year, primarily due to an increase of $40.1 million in personnel costs as we continued to increase our sales and marketing headcount. Marketing-related expenses increased by $2.8 million as we invested in marketing to drive broader market awareness, create a global marketing engine, build broad market lead generation, nurture programs and accelerate pipeline. In addition, we incurred increases in travel and entertainment expenses of $3.1 million and depreciation expense and occupancy-related costs of $2.1 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but at a slower pace. As such, we expect sales and marketing expense as a percentage of total revenue to slightly decrease during the remainder of 2016.

[0001262039-16-000079:mdna:67]
[same as prior period, unchanged from 0001262039-16-000064:mdna:71]

[0001262039-16-000079:mdna:68]
General and administrative expense increased by $4.2 million, or 23%, during the three months ended June 30, 2016 compared to the same period last year. During the three months ended June 30, 2016, we expensed an additional $4.9 million relating to business process design and reengineering in preparation of implementing a new ERP system compared to the same period last year. In addition, personnel costs increased by $2.8 million due to increase in headcount in order to support our expanding business. The increase in expense was partially offset by lower  professional fees, such as legal fees, of $1.8 million and other costs of $1.2 million. As a percentage of total revenue, we expect general and administrative expense to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000079:mdna:69]
[same as prior period, unchanged from 0001262039-16-000064:mdna:73]

[0001262039-16-000079:mdna:70]
Restructuring charges of $0.6 million during the three months ended June 30, 2016 primarily relate to our restructuring activities related to the acquisition of AccelOps. See Note 9 to the condensed consolidated financial statements for additional details, including types of expenses incurred and the timing of future expenses and cash payments. See also the

[0001262039-16-000079:mdna:71]
“Liquidity and Capital Resources” section of this Part I, Item 2, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001262039-16-000079:mdna:72]
[same as prior period, unchanged from 0001262039-16-000064:mdna:76]

[0001262039-16-000079:mdna:73]
|  | Three Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 1,705 |  |  | $ | 1,364 |  |  | $ | 341 |  |  | 25 | % |
| Other expense—net | (1,350 | ) |  | (830 | ) |  | (520 | ) |  | 63 |  |

[0001262039-16-000079:mdna:74]
Interest income increased during the three months ended June 30, 2016 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in Other expense—net during the three months ended June 30, 2016 as compared to the same period last year was the result of higher foreign currency exchange losses. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000079:mdna:75]
[same as prior period, unchanged from 0001262039-16-000064:mdna:79]

[0001262039-16-000079:mdna:76]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2016 |  | June 30, 2015 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | (2,302 | ) |  | $ | 2,694 |  |  | $ | (4,996 | ) |  | (185 | )% |
| Effective tax rate (%) | 62 | % |  | 77 | % |  | (15 | )% |  | * |  |

[0001262039-16-000079:mdna:77]
* not meaningful

[0001262039-16-000079:mdna:78]
Our effective tax rate was 62% for the three months ended June 30, 2016, as compared to an effective tax rate of 77% for the same period last year. The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, and foreign withholding and income taxes. The changes in the tax provision and effective tax rate were primarily due to the tax benefit from adoption of the new accounting guidance relating to stock-based compensation and the tax benefit from the U.S. federal R&D credit. The tax rate for the three months ended June 30, 2015 did not include a benefit from the U.S. federal R&D credit as the credit had expired in December 2014. In December 2015, the U.S. federal R&D credit was made permanent and the tax benefit was reflected on the income tax provision for the three months ended June 30, 2016.

[0001262039-16-000079:mdna:79]
[same as prior period, unchanged from 0001262039-16-000064:mdna:83]

[0001262039-16-000079:mdna:80]
Six Months Ended June 30, 2016 and June 30, 2015

[0001262039-16-000079:mdna:81]
Revenue

[0001262039-16-000079:mdna:82]
|  | Six Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 261,213 |  |  | 44 | % |  | $ | 212,286 |  |  | 47 | % |  | $ | 48,927 |  |  | 23 | % |
| Service | 334,754 |  |  | 56 |  |  | 240,385 |  |  | 53 |  |  | 94,369 |  |  | 39 |  |
| Total revenue | $ | 595,967 |  |  | 100 | % |  | $ | 452,671 |  |  | 100 | % |  | $ | 143,296 |  |  | 32 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 252,692 |  |  | 42 | % |  | $ | 200,153 |  |  | 44 | % |  | $ | 52,539 |  |  | 26 | % |
| EMEA | 219,944 |  |  | 37 |  |  | 159,068 |  |  | 35 |  |  | 60,876 |  |  | 38 |  |
| APAC | 123,331 |  |  | 21 |  |  | 93,450 |  |  | 21 |  |  | 29,881 |  |  | 32 |  |
| Total revenue | $ | 595,967 |  |  | 100 | % |  | $ | 452,671 |  |  | 100 | % |  | $ | 143,296 |  |  | 32 | % |

[0001262039-16-000079:mdna:83]
Total revenue increased by $143.3 million, or 32%, during the six months ended June 30, 2016 compared to the same period last year.  All three regions experienced revenue growth compared to the same period last year, with EMEA contributing the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $48.9 million, or 23%, during the six months ended June 30, 2016 compared to the same period last year. The increase in product revenue was primarily driven by greater sales in our FortiGate product family, as well as growth in other product lines.

[0001262039-16-000079:mdna:84]
Service revenue increased by $94.4 million, or 39%, during the six months ended June 30, 2016 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, particularly our large enterprise customers, as well as the renewals of similar contracts sold in earlier periods. Service revenue also increased as we continue to add to and charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000079:mdna:85]
Cost of revenue and gross margin

[0001262039-16-000079:mdna:86]
|  | Six Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 102,101 |  |  | $ | 88,765 |  |  | $ | 13,336 |  |  | 15 | % |
| Service | 60,046 |  |  | 44,335 |  |  | 15,711 |  |  | 35 |  |
| Total cost of revenue | $ | 162,147 |  |  | $ | 133,100 |  |  | $ | 29,047 |  |  | 22 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.9 | % |  | 58.2 | % |  | 2.7 | % |  |  |
| Service | 82.1 |  |  | 81.6 |  |  | 0.5 |  |  |  |
| Total gross margin | 72.8 | % |  | 70.6 | % |  | 2.2 | % |  |  |

[0001262039-16-000079:mdna:87]
Total gross margin increased by 2.2 percentage points during the six months ended June 30, 2016 compared to the same period last year, as both product and service gross margins increased. Product gross margin increased by 2.7 percentage points during the six months ended June 30, 2016 compared to the same period last year. Product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions, as well as lower warranty expense.

[0001262039-16-000079:mdna:88]
35

[0001262039-16-000079:mdna:89]
Service gross margin increased by 0.5 percentage points during the six months ended June 30, 2016 as compared to the same period last year as we scaled efficiencies resulting from our ability to add to and charge more for functionality and value to our service offerings, which have translated into improved service margins. Cost of service revenue increased by $15.7 million primarily due to a $9.8 million increase in personnel costs as a result of increased headcount.

[0001262039-16-000079:mdna:90]
Operating expenses

[0001262039-16-000079:mdna:91]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2016 |  | June 30, 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 90,256 |  |  | 15 | % |  | $ | 73,205 |  |  | 16 | % |  | $ | 17,051 |  |  | 23 | % |
| Sales and marketing | 308,797 |  |  | 52 |  |  | 212,537 |  |  | 47 |  |  | 96,260 |  |  | 45 |  |
| General and administrative | 41,623 |  |  | 7 |  |  | 29,979 |  |  | 7 |  |  | 11,644 |  |  | 39 |  |
| Restructuring charges | 881 |  |  | — |  |  | — |  |  | — |  |  | 881 |  |  | * |  |
| Total operating expenses | $ | 441,557 |  |  | 74 | % |  | $ | 315,721 |  |  | 70 | % |  | $ | 125,836 |  |  | 40 | % |

[0001262039-16-000079:mdna:92]
* not meaningful

[0001262039-16-000079:mdna:93]
Research and development

[0001262039-16-000079:mdna:94]
Research and development expense increased by $17.1 million, or 23%, during the six months ended June 30, 2016 compared to the same period last year primarily due to an increase of $10.9 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation expense and other occupancy-related costs increased by $3.4 million and costs of test supplies and prototype materials used in product development increased by $1.4 million.

[0001262039-16-000079:mdna:95]
Sales and marketing

[0001262039-16-000079:mdna:96]
Sales and marketing expense increased by $96.3 million, or 45%, during the six months ended June 30, 2016 compared to the same period last year, primarily due to an increase of $73.9 million in personnel costs as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expense increased by $8.0 million as we invested significantly in marketing programs to capture market share, particularly in the large enterprise market, including costs related to trade-shows and lead generation. In addition, depreciation expense and other occupancy-related expense increased by $5.6 million and travel and entertainment expense increased by $5.1 million.

[0001262039-16-000079:mdna:97]
General and administrative

[0001262039-16-000079:mdna:98]
General and administrative expense increased by $11.6 million, or 39%, during the six months ended June 30, 2016 compared to the same period last year. During the six months ended June 30, 2016, we expensed an additional $7.8 million - relating to business process design and reengineering in preparation of the ERP system implementation compared to the same period last year. In addition, personnel costs increased by $6.5 million, as we continued to increase our headcount in order to support our expanding business. The increase in expense was partially offset by lower professional fees, such as legal fees, of $2.4 million.

[0001262039-16-000079:mdna:99]
36

[0001262039-16-000079:mdna:100]
Interest income and other expense—net

[0001262039-16-000079:mdna:101]
|  | Six Months Ended |  |  |  |  |
| June 30, 2016 |  | June 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 3,451 |  |  | $ | 2,786 |  |  | $ | 665 |  |  | 24 | % |
| Other expense—net | (2,662 | ) |  | (1,507 | ) |  | (1,155 | ) |  | 77 |  |

[0001262039-16-000079:mdna:102]
Interest income increased during the six months ended June 30, 2016 compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in Other expense—net for the six months ended June 30, 2016 when compared to the same period last year, was the result of higher foreign currency exchange losses. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000079:mdna:103]
Provision for (benefit from) income taxes

[0001262039-16-000079:mdna:104]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2016 |  | June 30, 2015 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | (7,678 | ) |  | $ | 2,777 |  |  | $ | (10,455 | ) |  | (376 | )% |
| Effective tax rate (%) | 111 | % |  | 54 | % |  | 57 | % |  | * |  |

[0001262039-16-000079:mdna:105]
* not meaningful

[0001262039-16-000079:mdna:106]
Our effective tax rate was 111% for the six months ended June 30, 2016, compared with an effective tax rate of 54% for the same period last year. The benefit from income taxes for the six months ended June 30, 2016 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The changes in the tax provision and effective tax rate were primarily due to the tax benefit from the adoption of the new accounting guidance relating to stock-based compensation and the tax benefit from the U.S. federal R&D credit. The tax rate for the six months ended June 30, 2015 did not include a benefit from the U.S. federal R&D credit as the credit had expired in December 2014. In December 2015, the U.S. federal R&D credit was made permanent and the tax benefit was reflected on the income tax provision for the six months ended June 30, 2016.

[0001262039-16-000079:mdna:107]
37

[0001262039-16-000079:mdna:108]
[same as prior period, unchanged from 0001262039-16-000064:mdna:84]

[0001262039-16-000079:mdna:109]
|  | As of |
|  | June 30, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 596,380 |  |  | $ | 543,277 |  |
| Investments | 625,611 |  |  | 621,033 |  |
| Total cash, cash equivalents and investments | $ | 1,221,991 |  |  | $ | 1,164,310 |  |
| Working capital (1) | $ | 621,920 |  |  | $ | 591,873 |  |
|  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 168,532 |  |  | $ | 148,924 |  |
| Cash provided by (used in) investing activities | (69,417 | ) |  | 17,930 |  |
| Cash provided by (used in) financing activities | (46,012 | ) |  | 31,285 |  |
| Net increase in cash and cash equivalents | $ | 53,103 |  |  | $ | 198,139 |  |

[0001262039-16-000079:mdna:110]
(1) Working capital is defined as current assets less current liabilities.

[0001262039-16-000079:mdna:111]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of equity awards, the timing of sales within an accounting period, and investments in strategic relationships that we have made or may make in the future. Our liquidity may be impacted by our customer-buying patterns and the efforts of our sales force and channel partners, which have historically resulted in our receiving a substantial portion of our billings during the last two weeks of the quarter. Billings during the last two weeks of the second quarter of 2016 were in excess of 40% compared to the historical eight-quarter average of 33%. As of June 30, 2016, $150.0 million remains available for future share repurchases under our share repurchase program, which will be financed through our available working capital. In recent years we have received significant capital as a result of the exercise of stock options and purchases under our ESPP. We expect proceeds in future years to decrease due to the increased mix of RSUs granted versus stock options and also to be impacted by our share price. During 2016, we expect to spend $80.0 million to $90.0 million in capital expenditures primarily related to expansion of our offices to support worldwide growth and the implementation of our ERP system.

[0001262039-16-000079:mdna:112]
As of June 30, 2016, our cash, cash equivalents, and investments of $1.2 billion were invested primarily in U.S. government and agency securities, municipal bonds, corporate debt securities, commercial paper, certificates of deposit and term deposits, and money market funds. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-16-000079:mdna:113]
As of June 30, 2016, $455.2 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes. We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity and the continuing market acceptance of our products. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-16-000079:mdna:114]
38

[0001262039-16-000079:mdna:115]
[same as prior period, unchanged from 0001262039-16-000064:mdna:89]

[0001262039-16-000079:mdna:116]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income or loss, as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-16-000079:mdna:117]
Our operating activities during the six months ended June 30, 2016 provided $168.5 million in cash as a result of our continued growth in billings and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, which was partially offset by an increase in payments to vendors.

[0001262039-16-000079:mdna:118]
Our operating activities during the six months ended June 30, 2015 provided $148.9 million in cash as a result of our continued growth in billings and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily included an increase in payments received from customers, partially offset by an increase in payments to vendors for inventory-related purchases and prepayment of certain expenses.

[0001262039-16-000079:mdna:119]
[same as prior period, unchanged from 0001262039-16-000064:mdna:93]

[0001262039-16-000079:mdna:120]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments purchases of property and equipment, and payments made in connection with business acquisitions. Historically, in making a lease versus purchase decision related to our larger facilities, we have elected to purchase the facility. We expect to make similar decisions in the future.

[0001262039-16-000079:mdna:121]
During the six months ended June 30, 2016, cash used for investing activities was primarily due to the $44.4 million we spent on capital expenditures, including our purchase of a warehouse in Union City, California for total cash of $18.5 million, and a $20.7 million payment for the acquisition of AccelOps. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $4.4 million.

[0001262039-16-000079:mdna:122]
During the six months ended June 30, 2015, cash provided by investing activities was a result of positive cash flow due to maturities, net of purchases, from our investments of $33.6 million, partially offset by capital expenditures of $15.7 million.

[0001262039-16-000079:mdna:123]
[same as prior period, unchanged from 0001262039-16-000064:mdna:97]

[0001262039-16-000079:mdna:124]
[same as prior period, unchanged from 0001262039-16-000064:mdna:98]

[0001262039-16-000079:mdna:125]
During the six months ended June 30, 2016, cash used for financing activities was $46.0 million, primarily due to $50.0 million used to repurchase our common stock. This was partially offset by $5.6 million of proceeds from the issuance of common stock, net of taxes paid, related to withholding upon issuance of equity awards.

[0001262039-16-000079:mdna:126]
During the six months ended June 30, 2015, cash provided by financing activities was $31.3 million as a result of proceeds of $42.6 million from the issuance of common stock under our stock-based compensation plans. This cash inflow was partially offset by $11.4 million of withholding tax payments upon issuance of equity awards.

[0001262039-16-000079:mdna:127]
[same as prior period, unchanged from 0001262039-16-000064:mdna:101]

[0001262039-16-000079:mdna:128]
There were no material changes outside the ordinary course of business during the six months ended June 30, 2016 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 10 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-16-000079:mdna:129]
39

[0001262039-16-000079:mdna:130]
[same as prior period, unchanged from 0001262039-16-000064:mdna:103]

[0001262039-16-000079:mdna:131]
As of June 30, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001262039-16-000079:mdna:132]
40
