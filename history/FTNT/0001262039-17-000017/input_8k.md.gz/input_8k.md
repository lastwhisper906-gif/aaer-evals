# FTNT 8-K — 0001262039-17-000013 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-03

- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2017-05-03

- none on or before 2017-05-03

## item 2.02 — earnings release, exhibit 99.1

[0001262039-17-000013:8k_2_02:1]
EX-99.1
2
ftntq1-2017ex991.htm
PRESS RELEASE

[0001262039-17-000013:8k_2_02:2]
Exhibit

[0001262039-17-000013:8k_2_02:3]
Press Release

[0001262039-17-000013:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Kelly Blough |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-235-7700 x 81612 |  | 408-391-9408 |
| kblough@fortinet.com |  | swheatley@fortinet.com |

[0001262039-17-000013:8k_2_02:5]
Fortinet Reports First Quarter 2017 Financial Results

[0001262039-17-000013:8k_2_02:6]
Company Reports Revenue Growth of 20% and Billings Growth of 22%

[0001262039-17-000013:8k_2_02:7]
First Quarter 2017 Highlights

[0001262039-17-000013:8k_2_02:8]
•Revenue of $340.6 million, up 20% year over year

[0001262039-17-000013:8k_2_02:9]
•Billings of $403.3 million, up 22% year over year1

[0001262039-17-000013:8k_2_02:10]
•GAAP diluted net income per share of $0.06

[0001262039-17-000013:8k_2_02:11]
•Non-GAAP diluted net income per share of $0.171, up 42% year over year

[0001262039-17-000013:8k_2_02:12]
•Cash flow from operations of $129.7 million

[0001262039-17-000013:8k_2_02:13]
•Free cash flow of $116.2 million1, up 65% year over year

[0001262039-17-000013:8k_2_02:14]
•Cash, cash equivalents and investments of $1.44 billion

[0001262039-17-000013:8k_2_02:15]
•Deferred revenue of $1.10 billion, up 31% year over year

[0001262039-17-000013:8k_2_02:16]
SUNNYVALE, Calif. — April 27, 2017—Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the first quarter ended March 31, 2017.

[0001262039-17-000013:8k_2_02:17]
“In the first quarter, Fortinet delivered billings and revenue growth that exceeded our guidance and continued to outgrow the market,” said Ken Xie, founder, chairman and chief executive officer. “The Fortinet Security Fabric is gaining significant traction with customers as demonstrated by the strength in large, multi-product deals and our continued expansion into the largest enterprises around the world.”

[0001262039-17-000013:8k_2_02:18]
| • | Revenue: Total revenue was $340.6 million for the first quarter of 2017, an increase of 20% compared to $284.6 million in the same quarter of 2016. Within total revenue, product revenue was $135.3 million, an increase of 9% compared to $124.6 million in the same quarter of 2016. Service revenue was $205.3 million, an increase of 28% compared to $160.0 million in the same quarter of 2016. |

[0001262039-17-000013:8k_2_02:19]
| • | Billings1: Total billings were $403.3 million for the first quarter of 2017, an increase of 22% compared to $330.5 million in the same quarter of 2016. |

[0001262039-17-000013:8k_2_02:20]
| • | Deferred Revenue: Total deferred revenue was $1.10 billion as of March 31, 2017, an increase of 31% compared to $837.2 million as of March 31, 2016. Total deferred revenue increased by $62.7 million compared to $1.04 billion as of December 31, 2016. |

[0001262039-17-000013:8k_2_02:21]
| • | Cash and Cash Flow: As of March 31, 2017, cash, cash equivalents and investments were $1.44 billion, compared to $1.31 billion as of December 31, 2016. In the first quarter of 2017, cash flow from operations was $129.7 million compared to $100.6 million in the same quarter of 2016. Free cash flow1 was $116.2 million during the first quarter of 2017 compared to $70.6 million in the same quarter of 2016, an increase of 65%. |

[0001262039-17-000013:8k_2_02:22]
| • | GAAP Operating Income or Loss: GAAP operating income was $5.4 million for the first quarter of 2017, representing a GAAP operating margin of 2%. GAAP operating loss was $3.7 million for the same quarter of 2016, representing a GAAP operating margin of -1%. |

[0001262039-17-000013:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $43.0 million for the first quarter of 2017, representing a non-GAAP operating margin of 13%. Non-GAAP operating income was $30.1 million for the same quarter of 2016, representing a non-GAAP operating margin of 11%. |

[0001262039-17-000013:8k_2_02:24]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $10.7 million for the first quarter of 2017, compared to GAAP net income of $2.1 million for the same quarter of 2016. GAAP diluted net income per share was $0.06 for the first quarter of 2017, compared to $0.01 for the same quarter of 2016. |

[0001262039-17-000013:8k_2_02:25]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $31.0 million for the first quarter of 2017, compared to non-GAAP net income of $20.1 million for the same quarter of 2016. Non-GAAP diluted net income per share was $0.17 for the first quarter of 2017, compared to $0.12 for the same quarter of 2016. |

[0001262039-17-000013:8k_2_02:26]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-17-000013:8k_2_02:27]
Conference Call Details

[0001262039-17-000013:8k_2_02:28]
Fortinet will host a conference call today, April 27, 2017, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 93617593. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through May 4, 2017, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 93617593.

[0001262039-17-000013:8k_2_02:29]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 93622812. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through May 4, 2017 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 93622812.

[0001262039-17-000013:8k_2_02:30]
About Fortinet (www.fortinet.com)

[0001262039-17-000013:8k_2_02:31]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. More than 310,000 customers worldwide trust Fortinet to protect their businesses. Learn more at http://www.fortinet.com, the Fortinet Blog, or FortiGuard Labs.

[0001262039-17-000013:8k_2_02:32]
#          #          #

[0001262039-17-000013:8k_2_02:33]
Copyright © 2017 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice, FortiWeb and FortiCASB. Other trademarks belong to their respective owners.

[0001262039-17-000013:8k_2_02:34]
FTNT-F

[0001262039-17-000013:8k_2_02:35]
Forward-looking Statements

[0001262039-17-000013:8k_2_02:36]
Non-GAAP Financial Measures

[0001262039-17-000013:8k_2_02:37]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-17-000013:8k_2_02:38]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-17-000013:8k_2_02:39]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-17-000013:8k_2_02:40]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-17-000013:8k_2_02:41]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as

[0001262039-17-000013:8k_2_02:42]
non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-17-000013:8k_2_02:43]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, including a tax adjustment to achieve our effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-17-000013:8k_2_02:44]
FORTINET, INC.

[0001262039-17-000013:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-17-000013:8k_2_02:46]
(Unaudited, in thousands)

[0001262039-17-000013:8k_2_02:47]
|  | March 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 823,249 |  |  | $ | 709,003 |  |
| Short-term investments | 375,423 |  |  | 376,522 |  |
| Accounts receivable—net | 270,111 |  |  | 312,998 |  |
| Inventory | 104,978 |  |  | 106,887 |  |
| Prepaid expenses and other current assets | 42,321 |  |  | 33,306 |  |
| Total current assets | 1,616,082 |  |  | 1,538,716 |  |
| LONG-TERM INVESTMENTS | 242,333 |  |  | 224,983 |  |
| DEFERRED TAX ASSETS | 199,186 |  |  | 182,745 |  |
| PROPERTY AND EQUIPMENT—NET | 155,476 |  |  | 137,249 |  |
| OTHER INTANGIBLE ASSETS—NET | 22,535 |  |  | 24,828 |  |
| GOODWILL | 14,553 |  |  | 14,553 |  |
| OTHER ASSETS | 17,218 |  |  | 16,867 |  |
| TOTAL ASSETS | $ | 2,267,383 |  |  | $ | 2,139,941 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 48,689 |  |  | $ | 56,732 |  |
| Accrued liabilities | 43,449 |  |  | 35,640 |  |
| Accrued payroll and compensation | 73,204 |  |  | 78,138 |  |
| Income taxes payable | 14,129 |  |  | 13,588 |  |
| Deferred revenue | 677,114 |  |  | 645,342 |  |
| Total current liabilities | 856,585 |  |  | 829,440 |  |
| DEFERRED REVENUE | 420,937 |  |  | 390,007 |  |
| INCOME TAX LIABILITIES | 72,993 |  |  | 68,551 |  |
| OTHER LIABILITIES | 18,619 |  |  | 14,262 |  |
| Total liabilities | 1,369,134 |  |  | 1,302,260 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 175 |  |  | 173 |  |
| Additional paid-in capital | 850,226 |  |  | 800,653 |  |
| Accumulated other comprehensive loss | (489 | ) |  | (765 | ) |
| Retained earnings | 48,337 |  |  | 37,620 |  |
| Total stockholders’ equity | 898,249 |  |  | 837,681 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,267,383 |  |  | $ | 2,139,941 |  |

[0001262039-17-000013:8k_2_02:48]
FORTINET, INC.

[0001262039-17-000013:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-17-000013:8k_2_02:50]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000013:8k_2_02:51]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| REVENUE: |  |  |  |
| Product | $ | 135,253 |  |  | $ | 124,572 |  |
| Service | 205,323 |  |  | 160,004 |  |
| Total revenue | 340,576 |  |  | 284,576 |  |
| COST OF REVENUE: |  |  |  |
| Product 1 | 55,297 |  |  | 49,313 |  |
| Service 1 | 35,267 |  |  | 28,331 |  |
| Total cost of revenue | 90,564 |  |  | 77,644 |  |
| GROSS PROFIT: |  |  |  |
| Product | 79,956 |  |  | 75,259 |  |
| Service | 170,056 |  |  | 131,673 |  |
| Total gross profit | 250,012 |  |  | 206,932 |  |
| OPERATING EXPENSES: |  |  |  |
| Research and development 1 | 51,195 |  |  | 44,754 |  |
| Sales and marketing 1 | 170,400 |  |  | 146,103 |  |
| General and administrative 1 | 22,577 |  |  | 19,439 |  |
| Restructuring charges | 430 |  |  | 328 |  |
| Total operating expenses | 244,602 |  |  | 210,624 |  |
| OPERATING INCOME (LOSS) | 5,410 |  |  | (3,692 | ) |
| INTEREST INCOME | 2,392 |  |  | 1,746 |  |
| OTHER INCOME (EXPENSE)—NET | 302 |  |  | (1,312 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | 8,104 |  |  | (3,258 | ) |
| BENEFIT FROM INCOME TAXES | (2,613 | ) |  | (5,376 | ) |
| NET INCOME | $ | 10,717 |  |  | $ | 2,118 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.06 |  |  | $ | 0.01 |  |
| Diluted | $ | 0.06 |  |  | $ | 0.01 |  |
| Weighted-average shares outstanding: |  |  |  |
| Basic | 174,489 |  |  | 171,745 |  |
| Diluted | 178,278 |  |  | 174,421 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |
| Cost of product revenue | $ | 342 |  |  | $ | 280 |  |
| Cost of service revenue | 2,310 |  |  | 2,134 |  |
| Research and development | 7,898 |  |  | 7,143 |  |
| Sales and marketing | 19,026 |  |  | 15,815 |  |
| General and administrative | 3,755 |  |  | 3,530 |  |
|  | $ | 33,331 |  |  | $ | 28,902 |  |

[0001262039-17-000013:8k_2_02:52]
FORTINET, INC.

[0001262039-17-000013:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-17-000013:8k_2_02:54]
(Unaudited, in thousands)

[0001262039-17-000013:8k_2_02:55]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Net income | $ | 10,717 |  |  | $ | 2,118 |  |
| Other comprehensive income: |  |  |  |
| Change in unrealized loss on investments | 425 |  |  | 1,888 |  |
| Tax provision related to change in unrealized loss on investments | 149 |  |  | 661 |  |
| Other comprehensive income—net of taxes | 276 |  |  | 1,227 |  |
| Comprehensive income | $ | 10,993 |  |  | $ | 3,345 |  |

[0001262039-17-000013:8k_2_02:56]
FORTINET, INC.

[0001262039-17-000013:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-17-000013:8k_2_02:58]
(Unaudited, in thousands)

[0001262039-17-000013:8k_2_02:59]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 10,717 |  |  | $ | 2,118 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 13,493 |  |  | 10,550 |  |
| Amortization of investment premiums | 973 |  |  | 1,497 |  |
| Stock-based compensation | 33,331 |  |  | 28,902 |  |
| Other non-cash items—net | 1,469 |  |  | (372 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 42,437 |  |  | 38,920 |  |
| Inventory | (3,545 | ) |  | (527 | ) |
| Deferred tax assets | (16,589 | ) |  | (16,709 | ) |
| Prepaid expenses and other current assets | (8,261 | ) |  | 1,029 |  |
| Other assets | 653 |  |  | (911 | ) |
| Accounts payable | (8,287 | ) |  | (11,426 | ) |
| Accrued liabilities | 2,923 |  |  | 300 |  |
| Accrued payroll and compensation | (5,267 | ) |  | (2,945 | ) |
| Other liabilities | (1,057 | ) |  | (1,332 | ) |
| Deferred revenue | 61,776 |  |  | 46,106 |  |
| Income taxes payable | 4,983 |  |  | 5,391 |  |
| Net cash provided by operating activities | 129,749 |  |  | 100,591 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (133,006 | ) |  | (115,672 | ) |
| Sales of investments | 6,000 |  |  | 2,867 |  |
| Maturities of investments | 109,207 |  |  | 108,557 |  |
| Purchases of property and equipment | (13,526 | ) |  | (29,956 | ) |
| Net cash used in investing activities | (31,325 | ) |  | (34,204 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 29,515 |  |  | 17,785 |  |
| Taxes paid related to net share settlement of equity awards | (13,693 | ) |  | (9,441 | ) |
| Repurchase and retirement of common stock | — |  |  | (50,000 | ) |
| Net cash provided by (used in) financing activities | 15,822 |  |  | (41,656 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 114,246 |  |  | 24,731 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 709,003 |  |  | 543,277 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 823,249 |  |  | $ | 568,008 |  |

[0001262039-17-000013:8k_2_02:60]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-17-000013:8k_2_02:61]
(Unaudited, in thousands, except per share amounts)

[0001262039-17-000013:8k_2_02:62]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-17-000013:8k_2_02:63]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Net cash provided by operating activities | $ | 129,749 |  |  | $ | 100,591 |  |
| Less purchases of property and equipment | (13,526 | ) |  | (29,956 | ) |
| Free cash flow | $ | 116,223 |  |  | $ | 70,635 |  |

[0001262039-17-000013:8k_2_02:64]
Reconciliation of GAAP operating income or loss to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-17-000013:8k_2_02:65]
|  | Three Months Ended March 31, 2017 |  | Three Months Ended March 31, 2016 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income (loss) | $ | 5,410 |  |  | $ | 37,553 |  | (a) | $ | 42,963 |  |  | $ | (3,692 | ) |  | $ | 33,787 |  | (b) | $ | 30,095 |  |
| Operating margin | 2 | % |  |  |  | 13 | % |  | -1 | % |  |  |  | 11 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 33,331 |  |  |  |  |  |  | 28,902 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,292 |  |  |  |  |  |  | 1,178 |  |  |  |
| Litigation settlement expenses |  |  | 1,500 |  |  |  |  |  |  | — |  |  |  |
| Restructuring charges |  |  | 430 |  |  |  |  |  |  | 328 |  |  |  |
| ERP-related expenses |  |  | — |  |  |  |  |  |  | 2,986 |  |  |  |
| Inventory fair value adjustment amortization |  |  | — |  |  |  |  |  |  | 393 |  |  |  |
| Tax adjustment |  |  | (17,223 | ) | (c) |  |  |  |  | (15,756 | ) | (c) |  |
| Net income | $ | 10,717 |  |  | $ | 20,330 |  |  | $ | 31,047 |  |  | $ | 2,118 |  |  | $ | 18,031 |  |  | $ | 20,149 |  |
| Diluted net income per share | $ | 0.06 |  |  |  |  | $ | 0.17 |  |  | $ | 0.01 |  |  |  |  | $ | 0.12 |  |
| Shares used in diluted net income per share calculations | 178,278 |  |  |  |  | 178,278 |  |  | 174,421 |  |  |  |  | 174,421 |  |

[0001262039-17-000013:8k_2_02:66]
(a) To exclude $33.3 million of stock-based compensation, $2.3 million of amortization of acquired intangible assets, $1.5 million litigation settlement expenses, and $0.4 million of restructuring charges in the three months ended March 31, 2017.

[0001262039-17-000013:8k_2_02:67]
(b) To exclude $28.9 million of stock-based compensation, $1.2 million of amortization of acquired intangible assets, $3.0 million of ERP-related expenses, $0.4 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $0.3 million of restructuring charges in the three months ended March 31, 2016.

[0001262039-17-000013:8k_2_02:68]
(c)  Non-GAAP financial information is adjusted to achieve an overall 32% percent and 33% percent effective tax rate in 2017 and 2016, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-17-000013:8k_2_02:69]
Billings Reconciliation

[0001262039-17-000013:8k_2_02:70]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Total revenue | $ | 340,576 |  |  | $ | 284,576 |  |
| Add change in deferred revenue | 62,702 |  |  | 45,885 |  |
| Total billings | $ | 403,278 |  |  | $ | 330,461 |  |
