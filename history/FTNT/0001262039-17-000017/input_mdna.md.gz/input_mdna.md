# FTNT MD&A — 0001262039-17-000017


## mdna

[0001262039-17-000017:mdna:1]
[same as prior period, unchanged from 0001262039-16-000087:mdna:1]

[0001262039-17-000017:mdna:2]
[same as prior period, unchanged from 0001262039-16-000087:mdna:2]

[0001262039-17-000017:mdna:3]
[same as prior period, unchanged from 0001262039-16-000087:mdna:3]

[0001262039-17-000017:mdna:4]
[same as prior period, unchanged from 0001262039-16-000087:mdna:4]

[0001262039-17-000017:mdna:5]
[same as prior period, unchanged from 0001262039-16-000087:mdna:5]

[0001262039-17-000017:mdna:6]
[same as prior period, unchanged from 0001262039-16-000087:mdna:6]

[0001262039-17-000017:mdna:7]
[same as prior period, unchanged from 0001262039-16-000087:mdna:7]

[0001262039-17-000017:mdna:8]
| • | drivers of long-term growth and operating leverage, such as increased sales productivity, increased functionality and value in our standalone and bundled security subscription and support service offerings; |

[0001262039-17-000017:mdna:9]
| • | growing our sales to enterprise, service provider and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-17-000017:mdna:10]
[same as prior period, unchanged from 0001262039-16-000087:mdna:10]

[0001262039-17-000017:mdna:11]
[same as prior period, unchanged from 0001262039-16-000087:mdna:11]

[0001262039-17-000017:mdna:12]
[same as prior period, unchanged from 0001262039-16-000087:mdna:12]

[0001262039-17-000017:mdna:13]
[same as prior period, unchanged from 0001262039-16-000087:mdna:13]

[0001262039-17-000017:mdna:14]
[same as prior period, unchanged from 0001262039-16-000087:mdna:14]

[0001262039-17-000017:mdna:15]
| • | expectations regarding spending related to real estate and other capital expenditures and the impact on free cash flows; |

[0001262039-17-000017:mdna:16]
[same as prior period, unchanged from 0001262039-16-000087:mdna:16]

[0001262039-17-000017:mdna:17]
[same as prior period, unchanged from 0001262039-16-000087:mdna:17]

[0001262039-17-000017:mdna:18]
| • | success and expansion of our enterprise resource planning system; |

[0001262039-17-000017:mdna:19]
| • | our intentions regarding repatriation of cash, cash equivalents and investments held by our international subsidiaries and the sufficiency of our existing cash, cash equivalents and investments to meet our cash needs for at least the next 12 months; |

[0001262039-17-000017:mdna:20]
| • | other statements regarding our future operations, financial condition and prospects and business strategies; and |

[0001262039-17-000017:mdna:21]
| • | adoption of new accounting standards, including those related to revenue recognition and accounting for leases. |

[0001262039-17-000017:mdna:22]
These forward-looking statements are subject to certain risks and uncertainties that could cause our actual results to differ materially from those reflected in the forward-looking statements. Factors that could cause or contribute to such

[0001262039-17-000017:mdna:23]
21

[0001262039-17-000017:mdna:24]
[same as prior period, unchanged from 0001262039-16-000087:mdna:22]

[0001262039-17-000017:mdna:25]
We provide high performance cybersecurity solutions to a wide variety of enterprises, service providers and government organizations of all sizes across the globe, including a majority of the 2016 Fortune 100. Our cybersecurity solutions are designed to provide broad, rapid protection against dynamic and sophisticated security threats, while simplifying the information technology (“IT”) and security infrastructure of our end-customers.

[0001262039-17-000017:mdna:26]
The three key areas driving our business are the changing cyber threat landscape, expanding need for regulatory compliance and evolving network security infrastructure. The cyber threat landscape continues to change at a rapid pace, with network attacks continually morphing into vehicles for malware, such as ransomware, and the challenge of having to comply with a variety of constantly changing regulatory requirements. Our end-customers’ infrastructures are rapidly evolving to leverage new technologies such as on-demand cloud and internet on demand, and changing web traffic patterns require end-customers to increase the bandwidth available across their network. These three drivers mean end-customers are constantly evaluating upgrades or deployments of new cybersecurity solutions.

[0001262039-17-000017:mdna:27]
The Fortinet Security Fabric has been developed to provide unified security across the entire network, including network core, endpoints, applications, data centers, access and private and public cloud, and is designed to enable traditionally disparate security devices to work together as an integrated and collaborative whole. It delivers integrated scalability, access control, awareness, security, traffic segmentation, centralized management and orchestration. It is built around an open framework to ensure interoperability and synchronization of intelligence and response, and does so across the distributed network security infrastructure, including both from the cloud and for the cloud. At the core of the Fortinet Security Fabric are our FortiGate physical products and software licenses, which ship with a broad set of security services, including firewall, virtual private network, anti-malware, anti-spam, application control, intrusion prevention, access control, web filtering, traffic and device segmentation and advanced threat protection (“ATP”). Through these security services, our FortiGuard Labs team provides updates using threat research and a global cloud network of data collection and intelligence resources to deliver subscription-based security services to FortiGate appliances and software products. We continually certify the security effectiveness of our security updates through independent test organizations, such as NSS Labs. Our FortiOS operating system provides the foundation for all FortiGate security functions. The latest enhancements to the FortiOS 5.6 offers end-customers the ability to manage security capabilities across their cloud assets’ and software-defined wireless area networks.

[0001262039-17-000017:mdna:28]
Enterprise customers select the form and deployment method that best meet their specific security requirements, such as a high-speed data center firewall at the network core, a next generation firewall at the edge, an internal segmentation firewall between network zones, a distributed enterprise firewall at branch sites or software- and hardware-based solutions designed for virtualized and cloud environments. Many smaller businesses also tend to deploy unified threat management devices. We derive a substantial majority of product sales from our FortiGate appliances, which range from the FortiGate-20 to -100 series, designed for small businesses, FortiGate-200 to -900 series for medium-sized businesses, to the FortiGate-1000 to -7000 series for large enterprises and service providers. Our network security platform also includes our FortiGuard security subscription services, which end-customers can subscribe to in order to obtain access to dynamic updates to application control, anti-virus, intrusion prevention, web filtering and anti-spam functionality. End-customers may also purchase FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide enterprise-class centralized management, analysis and reporting capabilities. FortiSIEM provides organizations with a solution for analyzing and managing network security, performance and compliance standards across our and other vendors’ products. Finally, end-customers may purchase FortiCare technical support services for our products and FortiCare professional services to assist in the design, implementation and maintenance of their networks.

[0001262039-17-000017:mdna:29]
We complement our core FortiGate product line with other products and software that offer additional protection from security threats to other critical areas of the enterprise. These products include our FortiMail email security, FortiSandbox ATP, FortiWeb web application firewall and FortiDDoS security appliances, as well as our FortiClient endpoint security software, FortiSIEM software, FortiAP secure wireless access points and FortiSwitch secure switch connectivity products. Our technology also positions us to deliver security to the cloud and for the cloud. Sales of our cloud-related products and services across public, private and hybrid cloud environments continue to grow faster on a percentage basis than other parts of our business.

[0001262039-17-000017:mdna:30]
22

[0001262039-17-000017:mdna:31]
[same as prior period, unchanged from 0001262039-16-000087:mdna:27]

[0001262039-17-000017:mdna:32]
| • | We recorded total revenue of $340.6 million in the three months ended March 31, 2017, an increase of 20% compared to the same period last year. Product revenue was $135.3 million in the three months ended March 31, 2017, an increase of 9% compared to the same period last year. Service revenue was $205.3 million in the three months ended March 31, 2017, an increase of 28% compared to the same period last year. |

[0001262039-17-000017:mdna:33]
| • | Cash, cash equivalents and investments were $1.44 billion as of March 31, 2017, an increase of $130.5 million, or 10%, from December 31, 2016. |

[0001262039-17-000017:mdna:34]
| • | Deferred revenue was $1.10 billion as of March 31, 2017, an increase of $62.7 million, or 6%, from December 31, 2016. |

[0001262039-17-000017:mdna:35]
| • | We generated cash flows from operating activities of $129.7 million in the three months ended March 31, 2017, an increase of $29.2 million, or 29%, compared to the same period last year. |

[0001262039-17-000017:mdna:36]
During the three months ended March 31, 2017, our revenue growth was driven by the strength in sales of our products, including FortiGate products, our renewals of service contracts and the sale of our enterprise bundles. Our high-end products accounted for 36% of billings, which reflected strong sales to large enterprises and an increase in large deals. Our mid-range products accounted for 31% of billings, and our entry-level products accounted for 33% of billings. In addition, we continue to see a shift to higher services growth, which reflects our ongoing success in driving higher-priced subscription bundles and metered model business. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business.

[0001262039-17-000017:mdna:37]
During the three months ended March 31, 2017, operating expenses increased by $34.0 million, or 16%, as compared to the same period last year. The increase was primarily driven by our investments made to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continued to invest in research and development to strengthen our technology. We believe that continued product innovation has strengthened our technology and resulted in market share gains. Headcount increased by 1% to 4,711 employees and contractors as of March 31, 2017, up from 4,665 as of December 31, 2016.

[0001262039-17-000017:mdna:38]
[same as prior period, unchanged from 0001262039-16-000087:mdna:35]

[0001262039-17-000017:mdna:39]
Our sales strategy is based on a distribution model whereby we primarily sell our products, software licenses and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products through Amazon Web Services and Microsoft Azure. While the revenue from such sales are still relatively insignificant, they have increased significantly in recent periods on a percentage basis and are aligned with the networking trends of our customers and the industry as a whole.

[0001262039-17-000017:mdna:40]
Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical products and software licenses, most frequently as part of a bundle offering that includes hardware and services functionality. We generally invoice at the time of our sale for the total price of the products and security and technical support services, and the invoice is payable within 30 to 90 days. We also invoice certain software licenses and services on a monthly basis.

[0001262039-17-000017:mdna:41]
We generally recognize product revenue up front, and recognize revenue for the sale of new and the renewal of existing FortiGuard security subscription services and FortiCare technical support services contracts ratably. We recognize revenue for certain software licenses up front as product revenue and, to a lesser extent, recognize other software licenses over the term of the agreement as services revenue. We recognize the security and support revenue over the service period, which is typically one to three years, but can be as long as five years. Sales of new and renewal services are a source of recurring revenue and increase our deferred revenue balance, which has contributed to our positive cash flow from operations.

[0001262039-17-000017:mdna:42]
Our approach to network security is defined by our Security Processing Unit (“SPU”) hardware architecture. The SPU includes three lines of proprietary Applications-Specific Integrated Circuits (“ASICs”), content processor, network processor and the system on a chip. The ASICs are designed for highly efficient execution of computationally intensive tasks such as policy enforcement, threat detection and encryption. As such ASIC based solutions can run many security applications simultaneously without a significant reduction in performance.

[0001262039-17-000017:mdna:43]
[same as prior period, unchanged from 0001262039-16-000087:mdna:37]

[0001262039-17-000017:mdna:44]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss our cash, cash equivalents and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP) and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-17-000017:mdna:45]
|  | Three Months Ended Or As Of |
|  | March 31, 2017 |  | March 31, 2016 |
|  | (in thousands) |
| Revenue | $ | 340,576 |  |  | $ | 284,576 |  |
| Deferred revenue | $ | 1,098,051 |  |  | $ | 837,188 |  |
| Billings (non-GAAP) | $ | 403,278 |  |  | $ | 330,461 |  |
| Cash, cash equivalents and investments | $ | 1,441,005 |  |  | $ | 1,194,487 |  |
| Net cash provided by operating activities | $ | 129,749 |  |  | $ | 100,591 |  |
| Free cash flow (non-GAAP) | $ | 116,223 |  |  | $ | 70,635 |  |

[0001262039-17-000017:mdna:46]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of revenue to be recognized in future periods. Deferred revenue was $1.10 billion as of March 31, 2017, an increase of $62.7 million, or 6%, from December 31, 2016.

[0001262039-17-000017:mdna:47]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures.

[0001262039-17-000017:mdna:48]
[same as prior period, unchanged from 0001262039-16-000087:mdna:43]

[0001262039-17-000017:mdna:49]
|  | Three Months Ended |
| March 31, 2017 |  | March 31, 2016 |  |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 340,576 |  |  | $ | 284,576 |  |
| Add change in deferred revenue | 62,702 |  |  | 45,885 |  |
| Total billings (non-GAAP) | $ | 403,278 |  |  | $ | 330,461 |  |

[0001262039-17-000017:mdna:50]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock and strengthening the balance sheet. However, free cash flow is not intended to represent our residual cash flow available for discretionary expenditures, since we may have other non-discretionary expenditures that are not deducted from the measure. A limitation of using free cash flow rather than the GAAP

[0001262039-17-000017:mdna:51]
measure of net cash provided by operating activities is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting cash flow from investing and financing activities in our reconciliation of free cash flows. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flows as a comparative measure. A reconciliation of free cash flow to net cash provided by operating activities, the most directly comparable financial measure calculated and presented in accordance with GAAP, is provided below:

[0001262039-17-000017:mdna:52]
|  | Three Months Ended |
| March 31, 2017 |  | March 31, 2016 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 129,749 |  |  | $ | 100,591 |  |
| Less purchases of property and equipment | (13,526 | ) |  | (29,956 | ) |
| Free cash flow (non-GAAP) | $ | 116,223 |  |  | $ | 70,635 |  |
| Net cash used in investing activities | $ | (31,325 | ) |  | $ | (34,204 | ) |
| Net cash provided by (used in) financing activities | $ | 15,822 |  |  | $ | (41,656 | ) |

[0001262039-17-000017:mdna:53]
[same as prior period, unchanged from 0001262039-16-000087:mdna:48]

[0001262039-17-000017:mdna:54]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-17-000017:mdna:55]
There were no material changes to our critical accounting policies and estimates as of and for the three months ended March 31, 2017, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on March 1, 2017 (the “Form 10-K”).

[0001262039-17-000017:mdna:56]
[same as prior period, unchanged from 0001262039-16-000087:mdna:51]

[0001262039-17-000017:mdna:57]
[same as prior period, unchanged from 0001262039-16-000087:mdna:52]

[0001262039-17-000017:mdna:58]
25

[0001262039-17-000017:mdna:59]
[same as prior period, unchanged from 0001262039-16-000087:mdna:54]

[0001262039-17-000017:mdna:60]
Three Months Ended March 31, 2017 and March 31, 2016

[0001262039-17-000017:mdna:61]
[same as prior period, unchanged from 0001262039-16-000087:mdna:56]

[0001262039-17-000017:mdna:62]
|  | Three Months Ended |  |  |  |  |
| March 31, 2017 |  | March 31, 2016 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 135,253 |  |  | 40 | % |  | $ | 124,572 |  |  | 44 | % |  | $ | 10,681 |  |  | 9 | % |
| Service | 205,323 |  |  | 60 |  |  | 160,004 |  |  | 56 |  |  | 45,319 |  |  | 28 |  |
| Total revenue | $ | 340,576 |  |  | 100 | % |  | $ | 284,576 |  |  | 100 | % |  | $ | 56,000 |  |  | 20 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 146,364 |  |  | 43 | % |  | $ | 120,046 |  |  | 42 | % |  | $ | 26,318 |  |  | 22 | % |
| Europe, Middle East and Africa | 126,149 |  |  | 37 |  |  | 105,491 |  |  | 37 |  |  | 20,658 |  |  | 20 |  |
| Asia Pacific | 68,063 |  |  | 20 |  |  | 59,039 |  |  | 21 |  |  | 9,024 |  |  | 15 |  |
| Total revenue | $ | 340,576 |  |  | 100 | % |  | $ | 284,576 |  |  | 100 | % |  | $ | 56,000 |  |  | 20 | % |

[0001262039-17-000017:mdna:63]
Total revenue increased by $56.0 million, or 20%, during the three months ended March 31, 2017 compared to the same period last year. On a geographic basis, we continued to experience diversification globally. Revenue from all our regions grew, with the Americas contributing the largest portion of our revenue growth both on an absolute dollar and on a percentage basis. Product revenue increased by $10.7 million, or 9%, in the three months ended March 31, 2017 compared to the same period last year. The increase in product revenue was primarily driven by the strength in sales of our FortiGate products and our enterprise bundles. Service revenue increased by $45.3 million, or 28%, in the three months ended March 31, 2017 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. We continued to see the shift from product revenue to higher-margin, recurring service revenue, which reflected our ongoing success in driving sales of enterprise bundles.

[0001262039-17-000017:mdna:64]
[same as prior period, unchanged from 0001262039-16-000087:mdna:59]

[0001262039-17-000017:mdna:65]
|  | Three Months Ended |  |  |  |  |
| March 31, 2017 |  | March 31, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 55,297 |  |  | $ | 49,313 |  |  | $ | 5,984 |  |  | 12 | % |
| Service | 35,267 |  |  | 28,331 |  |  | 6,936 |  |  | 25 |  |
| Total cost of revenue | $ | 90,564 |  |  | $ | 77,644 |  |  | $ | 12,920 |  |  | 17 | % |
| Gross margin: |  |  |  |  |  |  |  |
| Product | 59.1 | % |  | 60.4 | % |  | (1.3 | )% |  |  |
| Service | 82.8 |  |  | 82.3 |  |  | 0.5 |  |  |  |
| Total gross margin | 73.4 | % |  | 72.7 | % |  | 0.7 | % |  |  |

[0001262039-17-000017:mdna:66]
Total gross margin increased by 0.7 percentage points in the three months ended March 31, 2017 compared to the same period last year. Product gross margin decreased by 1.3 percentage points in the three months ended March 31, 2017

[0001262039-17-000017:mdna:67]
compared to the same period last year. The decrease in product gross margin was primarily due to higher inventory reserves and other charges.

[0001262039-17-000017:mdna:68]
Service gross margin increased by 0.5 percentage points in the three months ended March 31, 2017 as compared to the same period last year, as we scaled efficiencies resulting from an increased mix of higher-margin service revenue. Cost of service revenue increased by $6.9 million and was comprised primarily of personnel costs.

[0001262039-17-000017:mdna:69]
[same as prior period, unchanged from 0001262039-16-000087:mdna:64]

[0001262039-17-000017:mdna:70]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2017 |  | March 31, 2016 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 51,195 |  |  | 15 | % |  | $ | 44,754 |  |  | 16 | % |  | $ | 6,441 |  |  | 14 | % |
| Sales and marketing | 170,400 |  |  | 50 |  |  | 146,103 |  |  | 51 |  |  | 24,297 |  |  | 17 |  |
| General and administrative | 22,577 |  |  | 7 |  |  | 19,439 |  |  | 7 |  |  | 3,138 |  |  | 16 |  |
| Restructuring charges | 430 |  |  | — |  |  | 328 |  |  | — |  |  | 102 |  |  | 31 |  |
| Total operating expenses | $ | 244,602 |  |  | 72 | % |  | $ | 210,624 |  |  | 74 | % |  | $ | 33,978 |  |  | 16 | % |

[0001262039-17-000017:mdna:71]
[same as prior period, unchanged from 0001262039-16-000087:mdna:66]

[0001262039-17-000017:mdna:72]
Research and development expense increased by $6.4 million, or 14%, in the three months ended March 31, 2017 compared to the same period last year, primarily due to an increase of $4.5 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Historically, we have refreshed our ASICs on a three- to four-year cycle and the refreshes have demonstrated significant performance improvements. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level during the remainder of 2017.

[0001262039-17-000017:mdna:73]
[same as prior period, unchanged from 0001262039-16-000087:mdna:68]

[0001262039-17-000017:mdna:74]
Sales and marketing expense increased by $24.3 million, or 17%, in the three months ended March 31, 2017 compared to the same period last year, primarily due to an increase of $19.4 million in personnel costs as we continued to increase our sales and marketing headcount. In addition, amortization expense increased by $1.5 million related to intangible assets acquired from AccelOps, Inc. (“AccelOps”). As a percentage of total revenue, sales and marketing expense decreased as we focused on scaling our investments in our sales force and marketing programs. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but expect sales and marketing expense as a percentage of total revenue to decrease during the remainder of 2017.

[0001262039-17-000017:mdna:75]
[same as prior period, unchanged from 0001262039-16-000087:mdna:70]

[0001262039-17-000017:mdna:76]
General and administrative expense increased by $3.1 million, or 16%, in the three months ended March 31, 2017 compared to the same period last year. Personnel costs increased by $1.7 million as we continued to increase headcount. In addition, litigation settlement expense increased by $1.6 million. We also incurred expense of $1.1 million due to third-party costs related to the preparation and implementation of the new revenue recognition standards. As a percentage of total revenue, we expect general and administrative expense to increase during the remainder of 2017 as we continue to implement the new revenue recognition standard.

[0001262039-17-000017:mdna:77]
Restructuring

[0001262039-17-000017:mdna:78]
Restructuring expenses of $0.4 million in the three months ended March 31, 2017 primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. Restructuring charges of $0.3 million during the three months ended March 31, 2016 primarily related to continued restructuring activities related to the acquisition of Meru Networks, Inc. (“Meru”) and reducing our combined cost structure relative to Meru. See Note 8 of the

[0001262039-17-000017:mdna:79]
notes to our condensed consolidated financial statements for additional details, including the types of expenses incurred and cash payments made. See also the “Liquidity and Capital Resources” below.

[0001262039-17-000017:mdna:80]
Interest income and other income (expense)—net

[0001262039-17-000017:mdna:81]
|  | Three Months Ended |  |  |  |  |
| March 31, 2017 |  | March 31, 2016 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 2,392 |  |  | $ | 1,746 |  |  | $ | 646 |  |  | 37 | % |
| Other income (expense)—net | 302 |  |  | (1,312 | ) |  | 1,614 |  |  | (123 | ) |

[0001262039-17-000017:mdna:82]
Interest income increased by $0.6 million, or 37%, during the three months ended March 31, 2017 as compared to the same period last year due to interest earned on higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in other income (expense)—net in the three months ended March 31, 2017 as compared to the same period last year was the result of higher foreign currency exchange gains.

[0001262039-17-000017:mdna:83]
Benefit from income taxes

[0001262039-17-000017:mdna:84]
|  | Three Months Ended |  | Change |  | % Change |
| March 31, 2017 |  | March 31, 2016 |  |
| (in thousands, except percentages) |
| Benefit from income taxes | $ | (2,613 | ) |  | $ | (5,376 | ) |  | $ | 2,763 |  |  | (51 | )% |
| Effective tax rate (%) | (32 | )% |  | 165.0 | % |  | (197 | )% |  | — |  |

[0001262039-17-000017:mdna:85]
Our effective tax rate was a benefit of (32)% for the three months ended March 31, 2017, compared to an effective tax rate of 165% for the same period last year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign income taxes. The tax rate for the three months ended March 31, 2017 is impacted by the excess tax benefits of $5.5 million on stock options, which was a significant benefit on our income before income taxes. The tax rate for the three months ended March 31, 2016 was also impacted by significant excess tax benefits of $3.6 million on stock options on our loss before income taxes.

[0001262039-17-000017:mdna:86]
Within the next 12 months, we do not believe there will be a decrease in uncertain tax benefits that could significantly impact our effective tax rate.

[0001262039-17-000017:mdna:87]
[same as prior period, unchanged from 0001262039-16-000087:mdna:21]

[0001262039-17-000017:mdna:88]
[same as prior period, unchanged from 0001262039-16-000087:mdna:112]

[0001262039-17-000017:mdna:89]
|  | As of |
|  | March 31, 2017 |  | December 31, 2016 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 823,249 |  |  | $ | 709,003 |  |
| Investments | 617,756 |  |  | 601,505 |  |
| Total cash, cash equivalents and investments | $ | 1,441,005 |  |  | $ | 1,310,508 |  |
| Working capital | $ | 759,497 |  |  | $ | 709,276 |  |
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 129,749 |  |  | $ | 100,591 |  |
| Cash used in investing activities | (31,325 | ) |  | (34,204 | ) |
| Cash provided by (used in) financing activities | 15,822 |  |  | (41,656 | ) |
| Net increase in cash and cash equivalents | $ | 114,246 |  |  | $ | 24,731 |  |

[0001262039-17-000017:mdna:90]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, real estate and other capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under our employee stock purchase plan (the “ESPP”), payment of taxes in connection with the net settlement of equity awards and investments in strategic relationships that we have made or may make in the future. As of March 31, 2017, $189.2 million remained available for future share repurchase under our 2016 Repurchase Program (the “2016 Repurchase Program”). In recent years we have received significant capital resources as a result of the exercise of stock options. We expect proceeds in future years to be impacted by the increased mix of restricted stock units (“RSUs”) granted versus stock options and also to vary based on our share price. In April 2017, we purchased a real estate in Vancouver, Canada for approximately $85.0 million which will affect our free cash flows in the second quarter of 2017. We expect our free cash flows to improve in the second half of 2017.

[0001262039-17-000017:mdna:91]
As of March 31, 2017, our cash, cash equivalents and investments of $1.44 billion were invested primarily in corporate debt securities, commercial paper, U.S. government and agency securities, municipal bonds, money market funds, certificates of deposit and term deposits. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-17-000017:mdna:92]
As of March 31, 2017, $599.5 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. While we do not intend to do so, should this amount be repatriated, most of it would be subject to U.S. federal income tax that would be partially offset by foreign tax credits. We do not enter into investments for trading or speculative purposes.

[0001262039-17-000017:mdna:93]
[same as prior period, unchanged from 0001262039-16-000087:mdna:118]

[0001262039-17-000017:mdna:94]
[same as prior period, unchanged from 0001262039-16-000087:mdna:120]

[0001262039-17-000017:mdna:95]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment and amortization of intangible assets.

[0001262039-17-000017:mdna:96]
Our operating activities during the three months ended March 31, 2017 provided $129.7 million in cash as a result of our continued growth in the sales of FortiGuard security subscriptions and FortiCare support contracts, as well as product sales, and the ability to successfully manage our working capital. The increase in sales of our FortiGuard security subscription and FortiCare technical supports to new and existing customers was reflected in the increase in our deferred revenue. We continued to see the shift from product revenue to higher-margin, recurring service revenue. For example, our total revenue grew 20% during the three months ended March 31, 2017 compared to the same period last year, while our total deferred revenue balance grew 31% during the three months ended March 31, 207 compared to the same period last year.

[0001262039-17-000017:mdna:97]
Our operating activities during the three months ended March 31, 2016 provided $100.6 million in cash as a result of our continued growth in billings and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in payments received from customers, which was partially offset by an increase in payments to vendors.

[0001262039-17-000017:mdna:98]
[same as prior period, unchanged from 0001262039-16-000087:mdna:124]

[0001262039-17-000017:mdna:99]
The changes in cash flows from investing activities primarily relate to timing of purchases, maturities and sales of investments and purchases of property and equipment. Historically, in making a lease versus purchase decision related to our larger facilities, we have elected to purchase the facility. We expect to make similar decisions in the future.

[0001262039-17-000017:mdna:100]
During the three months ended March 31, 2017, cash used for investing activities was primarily due to the $13.5 million we spent on capital expenditures and $17.8 million due to purchases, net of maturities, of our investments.

[0001262039-17-000017:mdna:101]
During the three months ended March 31, 2016, cash used for investing activities was primarily due to the $30.0 million we spent on capital expenditures, including our purchase of certain real property in Union City, California for total cash of $18.5 million. Cash outflows due to sales and maturities of our investments, net of purchases, amounted to $4.2 million.

[0001262039-17-000017:mdna:102]
[same as prior period, unchanged from 0001262039-16-000087:mdna:128]

[0001262039-17-000017:mdna:103]
The changes in cash flows from financing activities primarily relate to proceeds from the issuance of common stock under our equity incentive plan and the ESPP, taxes paid related to net share settlement of equity awards, excess tax benefit from stock-based compensation and repurchase and retirement of common stock.

[0001262039-17-000017:mdna:104]
During the three months ended March 31, 2017, cash used for financing activities was $15.8 million, proceeds from the issuance of common stock, net of tax withholding.

[0001262039-17-000017:mdna:105]
During the three months ended March 31, 2016, cash used for financing activities was $41.7 million, primarily due to $50.0 million used to repurchase our common stock. This was partially offset by $8.3 million of proceeds from the issuance of common stock, net of taxes paid, related to withholding upon issuance of RSUs.

[0001262039-17-000017:mdna:106]
[same as prior period, unchanged from 0001262039-16-000087:mdna:132]

[0001262039-17-000017:mdna:107]
There were no material changes outside the ordinary course of business during the three months ended March 31, 2017 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 9 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-17-000017:mdna:108]
[same as prior period, unchanged from 0001262039-16-000087:mdna:135]

[0001262039-17-000017:mdna:109]
As of March 31, 2017, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
