# FTNT note change history — 0001262039-16-000087 → 0001262039-17-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001262039-17-000017:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2017 (in thousands):
  (was, 2016-11-08, similarity 0.7604):
[0001262039-16-000087:note_history:1]
Our future principal contractual obligations as of September 30, 2016 were (in thousands):

- changed (2017-05-03):
[0001262039-17-000017:note_history:2]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 61,354 |  |  | $ | 13,083 |  |  | $ | 14,401 |  |  | $ | 11,972 |  |  | $ | 9,497 |  |  | $ | 4,088 |  |  | $ | 8,313 |  |
| Inventory purchase commitments | 68,846 |  |  | 68,846 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 71,534 |  |  | 60,959 |  |  | 8,402 |  |  | 1,522 |  |  | 560 |  |  | 91 |  |  | — |  |
| Total | $ | 201,734 |  |  | $ | 142,888 |  |  | $ | 22,803 |  |  | $ | 13,494 |  |  | $ | 10,057 |  |  | $ | 4,179 |  |  | $ | 8,313 |  |
  (was, 2016-11-08, similarity 0.9979):
[0001262039-16-000087:note_history:2]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 74,107 |  |  | $ | 5,756 |  |  | $ | 17,678 |  |  | $ | 14,653 |  |  | $ | 12,359 |  |  | $ | 10,497 |  |  | $ | 13,164 |  |
| Inventory purchase commitments | 116,494 |  |  | 90,169 |  |  | 26,325 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 48,864 |  |  | 33,805 |  |  | 11,466 |  |  | 2,451 |  |  | 855 |  |  | 287 |  |  | — |  |
| Total | $ | 239,465 |  |  | $ | 129,730 |  |  | $ | 55,469 |  |  | $ | 17,104 |  |  | $ | 13,214 |  |  | $ | 10,784 |  |  | $ | 13,164 |  |

- changed (2017-05-03):
[0001262039-17-000017:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.5 million and $4.6 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.
  (was, 2016-11-08, similarity 0.8536):
[0001262039-16-000087:note_history:3]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $6.1 million and $3.7 million during the three months ended September 30, 2016 and September 30, 2015, respectively. Rent expense was $14.7 million and $9.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

- changed (2017-05-03):
[0001262039-17-000017:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2017, we had $68.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2016-11-08, similarity 0.9897):
[0001262039-16-000087:note_history:4]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2016, we had $116.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2017-05-03):
[0001262039-17-000017:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2017, we had $71.5 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate properties adjacent to our corporate headquarters amounting to $12.8 million, which we capitalized as part of property and equipment.
  (was, 2016-11-08, similarity 0.7508):
[0001262039-16-000087:note_history:5]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2016, we had $48.9 million in other contractual commitments that may not be cancelable.

- added (2017-05-03):
[0001262039-17-000017:note_history:6]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

- added (2017-05-03):
[0001262039-17-000017:note_history:7]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

- removed (2017-05-03):
[0001262039-16-000087:note_history:8]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

- removed (2017-05-03):
[0001262039-16-000087:note_history:9]
|  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (2,260 | ) |  | (3,413 | ) |
| Provision for warranty for the period | 925 |  |  | 3,638 |  |
| Adjustment related to pre-existing warranties | (279 | ) |  | (94 | ) |
| Accrued warranty balance—end of the period | $ | 1,530 |  |  | $ | 4,400 |  |

- removed (2017-05-03):
[0001262039-16-000087:note_history:10]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001262039-17-000017:note_history:11]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.
  (was, 2016-11-08, similarity 0.9684):
[0001262039-16-000087:note_history:11]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

- changed (2017-05-03):
[0001262039-17-000017:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2017, except for changes to our policies related to inventory and business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”
  (was, 2016-11-08, similarity 0.757):
[0001262039-16-000087:note_history:12]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”

- added (2017-05-03):
[0001262039-17-000017:note_history:13]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

- added (2017-05-03):
[0001262039-17-000017:note_history:14]
In July 2015, the FASB issued ASU 2015-11—Inventory: Simplifying the Measurement of Inventory, which requires entities to measure most inventory at the lower of cost and net realizable value, replacing the former methodology of measuring inventory at the lower of cost or market. We adopted ASU 2015-11 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2015-11 did not have a significant impact on our consolidated financial statements.

- added (2017-05-03):
[0001262039-17-000017:note_history:15]
In January 2017, the FASB issued ASU 2017-04—Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2016-06 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We intend to adopt ASU 2017-04 in the fourth quarter of 2017. We do not believe that ASU 2017-04 will have a material impact on our consolidated financial statements.

- changed (2017-05-03):
[0001262039-17-000017:note_history:16]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.
  (was, 2016-11-08, similarity 0.9988):
[0001262039-16-000087:note_history:16]
In October 2016, the FASB issued ASU 2016-16—Income Taxes —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

- changed (2017-05-03):
[0001262039-17-000017:note_history:17]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of adopting ASU 2016-13 on our consolidated financial statements.
  (was, 2016-11-08, similarity 0.9774):
[0001262039-16-000087:note_history:17]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of ASU 2016-13 will have on our consolidated financial statements.

- added (2017-05-03):
[0001262039-17-000017:note_history:18]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations.

- added (2017-05-03):
[0001262039-17-000017:note_history:19]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for us beginning January 1, 2018.

- added (2017-05-03):
[0001262039-17-000017:note_history:20]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. Currently, we are in the process of reviewing our historical contracts to quantify the impact on our consolidated financial statements. Depending on the results of our review, there could be changes to the timing of revenue recognition and certain sales commission and related costs associated with obtaining and fulfilling our customer contracts. These changes may include the acceleration of revenue and associated costs on sales to certain channel partners that are currently accounted for only once the product is sold through to the end-customer. We will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs. We are also in the process of assessing the appropriate changes to our business processes and upgrading our systems and controls to support recognition and disclosure under ASU 2014-09. We otherwise expect to complete our assessment process, including selecting a transition method for adoption, in the next two quarters of 2017.

- removed (2017-05-03):
[0001262039-16-000087:note_history:21]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur.

- removed (2017-05-03):
[0001262039-16-000087:note_history:22]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits of $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016.

- removed (2017-05-03):
[0001262039-16-000087:note_history:23]
Under the new guidance, we have elected to change our policy and have started to recognize forfeitures of awards as they occur. The change in forfeiture policy was adopted using a modified retrospective transition method. We recorded a cumulative-effect adjustment to decrease retained earnings by $0.8 million upon transition on January 1, 2016 and a retrospective decrease of stock-based compensation of $2.0 million during the first quarter of 2016.

- removed (2017-05-03):
[0001262039-16-000087:note_history:24]
The amendment to the minimum statutory withholding tax requirements was adopted on a modified retrospective basis. The adoption had no impact on the January 1, 2016 retained earnings. In addition, we adopted the presentation of taxes paid related to net share settlement of equity awards as a financing activity on the statement of cash flows on a retrospective basis.  Our adoption had no impact to any of the periods presented in our consolidated cash flows statements since such cash flows have historically been presented as a financing activity.

- removed (2017-05-03):
[0001262039-16-000087:note_history:25]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for the three months ended March 31, 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

- removed (2017-05-03):
[0001262039-16-000087:note_history:26]
|  | Three Months Ended |
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Statements of Operations: |  |  |  |
| Stock-based compensation expense | $ | 30,881 |  |  | $ | 28,901 |  |
| Benefit from income taxes | $ | (1,809 | ) |  | $ | (5,376 | ) |
| Net income (loss) | $ | (3,429 | ) |  | $ | 2,118 |  |
| Net income (loss) per share—Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Net income (loss) per share—Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding—Diluted | 171,745 |  |  | 174,421 |  |

- removed (2017-05-03):
[0001262039-16-000087:note_history:27]
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Balance Sheets: |  |  |  |
| Deferred tax assets | $ | 131,696 |  |  | $ | 167,625 |  |
| Additional paid-in capital | $ | 718,849 |  |  | $ | 717,671 |  |
| Retained earnings | $ | 23,089 |  |  | $ | 60,196 |  |

- removed (2017-05-03):
[0001262039-16-000087:note_history:28]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 has not had any impact on our consolidated financial statements.

- removed (2017-05-03):
[0001262039-16-000087:note_history:29]
In August 2016, the FASB issued ASU 2016-15—Statement of Cash Flows—Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us beginning on January 1, 2018. Early adoption is permitted, including adoption in an interim period. We are currently evaluating the impact of adopting ASU 2016-15 on our consolidated financial statements.

- removed (2017-05-03):
[0001262039-16-000087:note_history:30]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the impact of adopting ASU 2016-02 on our consolidated financial statements.

- removed (2017-05-03):
[0001262039-16-000087:note_history:31]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of these new standards on our consolidated financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2017-05-03):
[0001262039-17-000017:note_history:32]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.1 million and $0.3 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Of such amounts, $0.2 million was incurred under contingent fee arrangements in the three months ended March 31, 2016. There were no expenses incurred under contingent fee arrangements during the three months ended March 31, 2017. Amounts due and payable to the law firm were $0.1 million as of March 31, 2017 and December 31, 2016.

- removed (2017-05-03):
[0001262039-16-000087:note_history:33]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were not material during the three months ended September 30, 2016 and $0.9 million during the three months ended September 30, 2015.  No contingent fees were incurred during the three months ended September 30, 2016 and September 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $3.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively.  Of such amounts, $0.5 million were incurred under contingent fee arrangements during the nine months ended September 30, 2015. No contingent fees were incurred during the nine months ended September 30, 2016. Amounts due and payable to the law firm were $0.1 million and $5.3 million as of September 30, 2016 and December 31, 2015, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-05-03):
[0001262039-17-000017:note_history:34]
In April 2017, we purchased real estate property in Vancouver, Canada totaling approximately 282,000 square feet for a total cash payment of approximately $85.0 million.

- removed (2017-05-03):
[0001262039-16-000087:note_history:35]
Share Repurchase Program

- removed (2017-05-03):
[0001262039-16-000087:note_history:36]
In October 2016, our board of directors authorized the repurchase of up to $100.0 million of shares of our common stock under the Program, increasing our current authorization to $300.0 million through December 2017.
