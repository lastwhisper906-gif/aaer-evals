# FTNT notes — 0001262039-17-000017


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-17-000017:notes:1]
Total income tax benefit associated with stock-based compensation that is recognized in the condensed consolidated statements of operations is as follows (in thousands):

[0001262039-17-000017:notes:2]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Income tax benefit associated with stock-based compensation | $ | 6,645 |  |  | $ | 7,321 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-17-000017:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2016, contained in our Annual Report on Form 10-K filed with the SEC on March 1, 2017. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2017 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2016 is derived from the audited consolidated financial statements for the year ended December 31, 2016.

[0001262039-17-000017:notes:4]
[same as prior period, unchanged from 0001262039-16-000087:notes:4]

[0001262039-17-000017:notes:5]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2017, except for changes to our policies related to inventory and business combinations. For more information, refer to the “Recently Adopted Accounting Standards.”


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-17-000017:notes:6]
The following tables summarize our investments (in thousands):

[0001262039-17-000017:notes:7]
|  | March 31, 2017 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 405,681 |  |  | $ | 80 |  |  | $ | (754 | ) |  | $ | 405,007 |  |
| Commercial paper | 110,434 |  |  | 68 |  |  | (26 | ) |  | 110,476 |  |
| U.S. government and agency securities | 55,764 |  |  | 2 |  |  | (89 | ) |  | 55,677 |  |
| Municipal bonds | 46,227 |  |  | 24 |  |  | (59 | ) |  | 46,192 |  |
| Certificates of deposit and term deposits (1) | 404 |  |  | — |  |  | — |  |  | 404 |  |
| Total available-for-sale securities | $ | 618,510 |  |  | $ | 174 |  |  | $ | (928 | ) |  | $ | 617,756 |  |
|  | December 31, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 379,494 |  |  | $ | 43 |  |  | $ | (925 | ) |  | $ | 378,612 |  |
| Commercial paper | 95,110 |  |  | 23 |  |  | (25 | ) |  | 95,108 |  |
| U.S. government and agency securities | 64,604 |  |  | 16 |  |  | (79 | ) |  | 64,541 |  |
| Municipal bonds | 59,257 |  |  | 3 |  |  | (235 | ) |  | 59,025 |  |
| Certificates of deposit and term deposits (1) | 4,219 |  |  | — |  |  | — |  |  | 4,219 |  |
| Total available-for-sale securities | $ | 602,684 |  |  | $ | 85 |  |  | $ | (1,264 | ) |  | $ | 601,505 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |


## ftnt:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsAndAllocationOfRecognizedPeriodCostsTableTextBlock

[0001262039-17-000017:notes:8]
The following table summarizes the weighted-average assumptions relating to our employee stock options:

[0001262039-17-000017:notes:9]
|  | Three months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Expected term in years | 4.4 |  |  | 4.3 |  |
| Volatility | 36 | % |  | 43 | % |
| Risk-free interest rate | 1.9 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-17-000017:notes:10]
The following table summarizes stock-based compensation expense by award type (in thousands):

[0001262039-17-000017:notes:11]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| RSUs | $ | 29,041 |  |  | $ | 25,103 |  |
| Stock options | 1,845 |  |  | 1,954 |  |
| ESPP | 2,445 |  |  | 1,845 |  |
| Total stock-based compensation expense | $ | 33,331 |  |  | $ | 28,902 |  |


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-17-000017:notes:12]
The following summarizes the number and value of the shares withheld for employee taxes (in thousands):

[0001262039-17-000017:notes:13]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Shares withheld for taxes | 413 |  |  | 343 |  |
| Amount withheld for taxes | $ | 13,693 |  |  | $ | 9,441 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-17-000017:notes:14]
[same as prior period, unchanged from 0001262039-16-000087:notes:17]

[0001262039-17-000017:notes:15]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Weighted-average fair value per share granted | $ | 12.22 |  |  | $ | 8.68 |  |
| Intrinsic value of options exercised | 17,898 |  |  | 19,424 |  |
| Fair value of options vested | 3,395 |  |  | 2,084 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-17-000017:notes:16]
[same as prior period, unchanged from 0001262039-16-000087:notes:19]

[0001262039-17-000017:notes:17]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Weighted-average fair value per share granted | $ | 9.28 |  |  | $ | 7.19 |  |
| Shares issued under the ESPP | 634 |  |  | 614 |  |
| Weighted-average price per share issued | $ | 27.97 |  |  | $ | 20.49 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-17-000017:notes:18]
COMMITMENTS AND CONTINGENCIES

[0001262039-17-000017:notes:19]
The following table summarizes our future principal contractual obligations as of March 31, 2017 (in thousands):

[0001262039-17-000017:notes:20]
|  | Total |  | 2017 (remainder) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Operating lease commitments | $ | 61,354 |  |  | $ | 13,083 |  |  | $ | 14,401 |  |  | $ | 11,972 |  |  | $ | 9,497 |  |  | $ | 4,088 |  |  | $ | 8,313 |  |
| Inventory purchase commitments | 68,846 |  |  | 68,846 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 71,534 |  |  | 60,959 |  |  | 8,402 |  |  | 1,522 |  |  | 560 |  |  | 91 |  |  | — |  |
| Total | $ | 201,734 |  |  | $ | 142,888 |  |  | $ | 22,803 |  |  | $ | 13,494 |  |  | $ | 10,057 |  |  | $ | 4,179 |  |  | $ | 8,313 |  |

[0001262039-17-000017:notes:21]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2024. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $4.5 million and $4.6 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-17-000017:notes:22]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2017, we had $68.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-17-000017:notes:23]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2017, we had $71.5 million in other contractual commitments that may not be cancelable. We also had other contractual commitments for the purchase of certain real estate properties adjacent to our corporate headquarters amounting to $12.8 million, which we capitalized as part of property and equipment.

[0001262039-17-000017:notes:24]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees with related parties, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. As required under ASC 450, Contingencies, issued by the FASB, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-17-000017:notes:25]
In October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information relating to our compliance with the Trade Agreements Act. This inquiry is ongoing and we are fully cooperating with this inquiry.

[0001262039-17-000017:notes:26]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-17-000017:notes:27]
[same as prior period, unchanged from 0001262039-16-000087:notes:53]

[0001262039-17-000017:notes:28]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended March 31, 2017 and March 31, 2016 were $1.3 million and $1.0 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-17-000017:notes:29]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001262039-17-000017:notes:30]
The following table summarizes the changes in accumulated balances of other comprehensive loss (in thousands):

[0001262039-17-000017:notes:31]
|  | March 31, 2017 |
|  | Unrealized losses on investments |  | Tax provision related to items of other comprehensive income or loss |  | Total |
| Beginning balance | $ | (1,179 | ) |  | $ | 414 |  |  | $ | (765 | ) |
| Other comprehensive income before reclassifications | 424 |  |  | (149 | ) |  | 275 |  |
| Amounts reclassified from accumulated other comprehensive loss | 1 |  |  | — |  |  | 1 |  |
| Net current-period other comprehensive income | 425 |  |  | (149 | ) |  | 276 |  |
| Ending balance | $ | (754 | ) |  | $ | 265 |  |  | $ | (489 | ) |

[0001262039-17-000017:notes:32]
Amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to items of other comprehensive income or loss are recorded in Other income (expense)—net and in Benefit from income taxes, respectively.


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-17-000017:notes:33]
INVESTMENTS IN PRIVATELY HELD COMPANIES

[0001262039-17-000017:notes:34]
Our investments in the equity securities of privately held companies totaled $11.3 million and $10.3 million as of March 31, 2017 and December 31, 2016, respectively. These investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities in each these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as other assets on our condensed consolidated balance sheets and would be measured at fair value if indicators of impairment existed. As of March 31, 2017, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-17-000017:notes:35]
As of March 31, 2017, we determined that we had a variable interest in these privately held companies. However, we determined that we were not the primary beneficiary as we did not have the power to direct their activities that most significantly affect their economic performance. The variable interest entities are not required to be consolidated in our condensed consolidated financial statements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-17-000017:notes:36]
[same as prior period, unchanged from 0001262039-16-000087:notes:63]

[0001262039-17-000017:notes:37]
[same as prior period, unchanged from 0001262039-16-000087:notes:64]

[0001262039-17-000017:notes:38]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs. We also have an ESPP for all eligible employees. As of March 31, 2017, there were a total of 50,087,833 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-17-000017:notes:39]
[same as prior period, unchanged from 0001262039-16-000087:notes:66]

[0001262039-17-000017:notes:40]
The following table summarizes the activity and related information for RSUs for the periods presented below (in thousands, except per share amounts):

[0001262039-17-000017:notes:41]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2016 | 9,509 |  |  | $ | 31.01 |  |
| Granted | 2,582 |  |  | 37.21 |  |
| Forfeited | (301 | ) |  | 33.80 |  |
| Vested | (1,299 | ) |  | 27.43 |  |
| Balance—March 31, 2017 | 10,491 |  |  | $ | 33.04 |  |

[0001262039-17-000017:notes:42]
As of March 31, 2017, total compensation expense related to unvested RSUs that were granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $310.3 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.9 years.

[0001262039-17-000017:notes:43]
[same as prior period, unchanged from 0001262039-16-000087:notes:70]

[0001262039-17-000017:notes:44]
[same as prior period, unchanged from 0001262039-16-000087:notes:71]

[0001262039-17-000017:notes:45]
The following table summarizes the stock option activity and related information for the periods presented below (in thousands, except exercise prices and contractual life):

[0001262039-17-000017:notes:46]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2016 | 6,187 |  |  | $ | 23.79 |  |  |  |  |  |  |
| Granted | 498 |  |  | 37.24 |  |  |  |  |  |
| Forfeited | (46 | ) |  | 27.24 |  |  |  |  |  |
| Exercised | (855 | ) |  | 14.67 |  |  |  |  |  |
| Balance—March 31, 2017 | 5,784 |  |  | $ | 26.27 |  |  |  |  |  |
| Options vested and expected to vest—March 31, 2017 | 5,784 |  |  | $ | 26.27 |  |  | 3.4 |  | $ | 71,951 |  |
| Options exercisable—March 31, 2017 | 3,820 |  |  | $ | 23.91 |  |  | 2.2 |  | $ | 56,071 |  |

[0001262039-17-000017:notes:47]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on March 31, 2017, for all in-the-money stock options. As of March 31, 2017, total compensation expense related to unvested stock options granted to employees but not yet recognized was $19.5 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.0 years.

[0001262039-17-000017:notes:48]
[same as prior period, unchanged from 0001262039-16-000087:notes:77]

[0001262039-17-000017:notes:49]
In determining the fair value of the ESPP, we use the Black-Scholes option pricing model that employs the following weighted-average assumptions:

[0001262039-17-000017:notes:50]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Expected term in years | 0.5 |  |  | 0.5 |  |
| Volatility | 33 | % |  | 48 | % |
| Risk-free interest rate | 0.7 | % |  | 0.4 | % |
| Dividend rate | — | % |  | — | % |

[0001262039-17-000017:notes:51]
[same as prior period, unchanged from 0001262039-16-000087:notes:80]

[0001262039-17-000017:notes:52]
[same as prior period, unchanged from 0001262039-16-000087:notes:81]

[0001262039-17-000017:notes:53]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Cost of product revenue | $ | 342 |  |  | $ | 280 |  |
| Cost of service revenue | 2,310 |  |  | 2,134 |  |
| Research and development | 7,898 |  |  | 7,143 |  |
| Sales and marketing | 19,026 |  |  | 15,815 |  |
| General and administrative | 3,755 |  |  | 3,530 |  |
| Total stock-based compensation expense | $ | 33,331 |  |  | $ | 28,902 |  |

[0001262039-17-000017:notes:54]
[same as prior period, unchanged from 0001262039-16-000087:notes:83]

[0001262039-17-000017:notes:55]
In January 2016, our board of directors approved the 2016 Share Repurchase Program (the “2016 Repurchase Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. In October 2016, our board of directors authorized the purchase of an additional $100.0 million of shares of our common stock under the 2016 Repurchase Program, increasing our current authorization to $300.0 million through December 31, 2017. Under the 2016 Repurchase Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The 2016 Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. There were no shares repurchased under the 2016 Repurchase Program during the three months ended March 31, 2017. As of March 31, 2017, $189.2 million remained available for future share repurchases under the 2016 Repurchase Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-17-000017:notes:56]
[same as prior period, unchanged from 0001262039-16-000087:notes:85]

[0001262039-17-000017:notes:57]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of restricted stock units (“RSUs”), stock options and the employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-17-000017:notes:58]
[same as prior period, unchanged from 0001262039-16-000087:notes:87]

[0001262039-17-000017:notes:59]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Numerator: |  |  |  |
| Net income | $ | 10,717 |  |  | $ | 2,118 |  |
| Denominator: |  |  |  |
| Basic shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 174,489 |  |  | 171,745 |  |
| Diluted shares: |  |  |  |
| Weighted-average common stock outstanding-basic | 174,489 |  |  | 171,745 |  |
| Effect of potentially dilutive securities: |  |  |  |
| RSUs | 2,216 |  |  | 1,020 |  |
| Stock options | 1,523 |  |  | 1,632 |  |
| ESPP | 50 |  |  | 24 |  |
| Weighted-average shares used to compute diluted net income per share | 178,278 |  |  | 174,421 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.06 |  |  | $ | 0.01 |  |
| Diluted | $ | 0.06 |  |  | $ | 0.01 |  |

[0001262039-17-000017:notes:60]
The following weighted-average shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-17-000017:notes:61]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| RSUs | 2,505 |  |  | 6,351 |  |
| Stock options | 1,118 |  |  | 1,559 |  |
| ESPP | 262 |  |  | 282 |  |
|  | 3,885 |  |  | 8,192 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-17-000017:notes:62]
[same as prior period, unchanged from 0001262039-16-000087:notes:91]

[0001262039-17-000017:notes:63]
The following tables show the gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position (in thousands):

[0001262039-17-000017:notes:64]
|  | March 31, 2017 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 325,615 |  |  | $ | (751 | ) |  | $ | 11,751 |  |  | $ | (3 | ) |  | $ | 337,366 |  |  | $ | (754 | ) |
| U.S. government and agency securities | 46,388 |  |  | (89 | ) |  | — |  |  | — |  |  | 46,388 |  |  | (89 | ) |
| Municipal bonds | 26,833 |  |  | (59 | ) |  | — |  |  | — |  |  | 26,833 |  |  | (59 | ) |
| Commercial paper | 31,172 |  |  | (26 | ) |  | — |  |  | — |  |  | 31,172 |  |  | (26 | ) |
| Total available-for-sale securities | $ | 430,008 |  |  | $ | (925 | ) |  | $ | 11,751 |  |  | $ | (3 | ) |  | $ | 441,759 |  |  | $ | (928 | ) |

[0001262039-17-000017:notes:65]
|  | December 31, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 311,980 |  |  | $ | (910 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 325,521 |  |  | $ | (925 | ) |
| Municipal bonds | 52,200 |  |  | (235 | ) |  | — |  |  | — |  |  | 52,200 |  |  | (235 | ) |
| U.S. government and agency securities | 33,430 |  |  | (79 | ) |  | — |  |  | — |  |  | 33,430 |  |  | (79 | ) |
| Commercial paper | 17,394 |  |  | (25 | ) |  | — |  |  | — |  |  | 17,394 |  |  | (25 | ) |
| Total available-for-sale securities | $ | 415,004 |  |  | $ | (1,249 | ) |  | $ | 13,541 |  |  | $ | (15 | ) |  | $ | 428,545 |  |  | $ | (1,264 | ) |

[0001262039-17-000017:notes:66]
The contractual maturities of our investments were as follows (in thousands):

[0001262039-17-000017:notes:67]
|  | March 31, 2017 |  | December 31, 2016 |
| Due within one year | $ | 375,423 |  |  | $ | 376,522 |  |
| Due within one to three years | 242,333 |  |  | 224,983 |  |
| Total | $ | 617,756 |  |  | $ | 601,505 |  |

[0001262039-17-000017:notes:68]
Available-for-sale securities are reported at fair value, with unrealized gains and losses, net of tax, included as a separate component of stockholders’ equity and in comprehensive income. Realized gains and losses on available-for-sale securities are insignificant in the periods presented and are included in Other income (expense)—net in our condensed consolidated statements of operations. We use the specific identification method to determine the cost basis of investments sold.

[0001262039-17-000017:notes:69]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of March 31, 2017.

[0001262039-17-000017:notes:70]
[same as prior period, unchanged from 0001262039-16-000087:notes:99]

[0001262039-17-000017:notes:71]
[same as prior period, unchanged from 0001262039-16-000087:notes:100]

[0001262039-17-000017:notes:72]
[same as prior period, unchanged from 0001262039-16-000087:notes:101]

[0001262039-17-000017:notes:73]
[same as prior period, unchanged from 0001262039-16-000087:notes:102]

[0001262039-17-000017:notes:74]
[same as prior period, unchanged from 0001262039-16-000087:notes:103]

[0001262039-17-000017:notes:75]
[same as prior period, unchanged from 0001262039-16-000087:notes:104]

[0001262039-17-000017:notes:76]
[same as prior period, unchanged from 0001262039-16-000087:notes:105]

[0001262039-17-000017:notes:77]
[same as prior period, unchanged from 0001262039-16-000087:notes:106]

[0001262039-17-000017:notes:78]
[same as prior period, unchanged from 0001262039-16-000087:notes:107]

[0001262039-17-000017:notes:79]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of March 31, 2017 and December 31, 2016 (in thousands):

[0001262039-17-000017:notes:80]
|  | March 31, 2017 |  | December 31, 2016 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 405,007 |  |  | $ | — |  |  | $ | 405,007 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |  | $ | 378,612 |  |  | $ | — |  |
| Commercial paper | 119,965 |  |  | — |  |  | 119,965 |  |  | — |  |  | 105,097 |  |  | — |  |  | 105,097 |  |  | — |  |
| U.S. government and agency securities | 55,677 |  |  | 45,222 |  |  | 10,455 |  |  | — |  |  | 64,541 |  |  | 52,082 |  |  | 12,459 |  |  | — |  |
| Municipal bonds | 46,192 |  |  | — |  |  | 46,192 |  |  | — |  |  | 59,025 |  |  | — |  |  | 59,025 |  |  | — |  |
| Money market funds | 21,069 |  |  | 21,069 |  |  | — |  |  | — |  |  | 38,649 |  |  | 38,649 |  |  | — |  |  | — |  |
| Certificates of deposit and term deposits | 404 |  |  | — |  |  | 404 |  |  | — |  |  | 4,219 |  |  | — |  |  | 4,219 |  |  | — |  |
| Total | $ | 648,314 |  |  | $ | 66,291 |  |  | $ | 582,023 |  |  | $ | — |  |  | $ | 650,143 |  |  | $ | 90,731 |  |  | $ | 559,412 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 30,558 |  |  |  |  |  |  |  |  | $ | 48,638 |  |  |  |  |  |  |  |
| Short-term investments | 375,423 |  |  |  |  |  |  |  |  | 376,522 |  |  |  |  |  |  |  |
| Long-term investments | 242,333 |  |  |  |  |  |  |  |  | 224,983 |  |  |  |  |  |  |  |
| Total | $ | 648,314 |  |  |  |  |  |  |  |  | $ | 650,143 |  |  |  |  |  |  |  |

[0001262039-17-000017:notes:81]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the three months ended March 31, 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-17-000017:notes:82]
GOODWILL AND OTHER INTANGIBLE ASSETS—NET

[0001262039-17-000017:notes:83]
[same as prior period, unchanged from 0001262039-16-000087:notes:117]

[0001262039-17-000017:notes:84]
As of March 31, 2017, we had goodwill of $14.6 million. There were no impairments to goodwill during the three months ended March 31, 2017 or during previous periods.

[0001262039-17-000017:notes:85]
[same as prior period, unchanged from 0001262039-16-000087:notes:121]

[0001262039-17-000017:notes:86]
The following tables present other intangible assets—net as of March 31, 2017 and December 31, 2016 (in thousands, except years):

[0001262039-17-000017:notes:87]
|  | March 31, 2017 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 10,000 |  |  | $ | 13,984 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 7,549 |  |  | 6,951 |  |
|  |  |  | 38,484 |  |  | 17,549 |  |  | 20,935 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 17,549 |  |  | $ | 22,535 |  |

[0001262039-17-000017:notes:88]
|  | December 31, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies and other | 3.8 |  | $ | 23,984 |  |  | $ | 8,750 |  |  | $ | 15,234 |  |
| Customer relationships | 4.7 |  | 14,500 |  |  | 6,506 |  |  | 7,994 |  |
|  |  |  | 38,484 |  |  | 15,256 |  |  | 23,228 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 15,256 |  |  | $ | 24,828 |  |

[0001262039-17-000017:notes:89]
Amortization expense was $2.3 million and $1.2 million during the three months ended March 31, 2017 and March 31, 2016, respectively. The following table summarizes estimated future amortization expense of finite-lived intangible assets—net (in thousands):

[0001262039-17-000017:notes:90]
|  | Amount |
| Years: |  |
| 2017 (remainder) | $ | 6,280 |  |
| 2018 | 6,885 |  |
| 2019 | 5,406 |  |
| 2020 | 2,364 |  |
| Total | $ | 20,935 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-17-000017:notes:91]
[same as prior period, unchanged from 0001262039-16-000087:notes:127]

[0001262039-17-000017:notes:92]
Our effective tax rate was a benefit of (32)% for the three months ended March 31, 2017, compared to an effective tax rate of 165% for the same period last year. The effective tax rates for the periods presented are comprised of U.S. federal and state taxes, withholding taxes and foreign income taxes. The tax rate for the three months ended March 31, 2017 was impacted by the excess tax benefits of $5.5 million on stock options, which was a significant benefit on our income before income taxes. The tax rate for the three months ended March 31, 2016 was also impacted by significant excess tax benefits of $3.6 million on stock options on our loss before income taxes.

[0001262039-17-000017:notes:93]
As of March 31, 2017 and December 31, 2016, unrecognized tax benefits were $69.4 million and $65.5 million, respectively. The total amount of $67.7 million in unrecognized tax benefits, if recognized, would favorably affect our effective tax rate.

[0001262039-17-000017:notes:94]
It is our policy to classify accrued interest and penalties related to uncertain tax benefits in the provision for income taxes. As of March 31, 2017 and December 31, 2016, accrued interest and penalties were $10.5 million and $9.5 million, respectively.

[0001262039-17-000017:notes:95]
As of March 31, 2017, there was no unrecognized tax benefits that we expect would change significantly over the next 12 months.

[0001262039-17-000017:notes:96]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for tax years 2012, 2013 and 2014. We have filed a waiver extending the statute of limitations to September 15, 2018 for U.S. federal income tax returns for tax years 2012 and 2013. In addition, the tax authorities in France are examining the inter-company relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. Subsequent to the three months ended March 31, 2017, we received a notice from the French tax authorities that an audit was officially opened for tax years from 2007 to 2015. Our Japan tax audit for tax years 2013, 2014 and 2015 was closed with no material adjustment.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-17-000017:notes:97]
[same as prior period, unchanged from 0001262039-16-000087:notes:131]

[0001262039-17-000017:notes:98]
Inventory consisted of the following (in thousands):

[0001262039-17-000017:notes:99]
|  | March 31, 2017 |  | December 31, 2016 |
| Raw materials | $ | 16,540 |  |  | $ | 18,924 |  |
| Finished goods | 88,438 |  |  | 87,963 |  |
| Inventory | $ | 104,978 |  |  | $ | 106,887 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-17-000017:notes:100]
| Property and Equipment—net | March 31, 2017 |  | December 31, 2016 |
| Americas: |  |  |  |
| U.S. | $ | 111,464 |  |  | $ | 96,414 |  |
| Canada | 16,274 |  |  | 12,881 |  |
| LATAM | 475 |  |  | 607 |  |
| Total Americas | 128,213 |  |  | 109,902 |  |
| EMEA: |  |  |  |
| France | 12,854 |  |  | 13,241 |  |
| Other EMEA | 6,232 |  |  | 6,391 |  |
| Total EMEA | 19,086 |  |  | 19,632 |  |
| APAC | 8,177 |  |  | 7,715 |  |
| Total property and equipment—net | $ | 155,476 |  |  | $ | 137,249 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-17-000017:notes:101]
Recently Adopted Accounting Standards

[0001262039-17-000017:notes:102]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) ASU 2017-01—Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business to assist organizations with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses. The definition of a business affects many areas of accounting including acquisitions, disposals, goodwill and consolidation. We elected to early adopt ASU 2017-01 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2017-01 did not have a material impact on our consolidated financial statements.

[0001262039-17-000017:notes:103]
In July 2015, the FASB issued ASU 2015-11—Inventory: Simplifying the Measurement of Inventory, which requires entities to measure most inventory at the lower of cost and net realizable value, replacing the former methodology of measuring inventory at the lower of cost or market. We adopted ASU 2015-11 on a prospective basis beginning on January 1, 2017. The adoption of ASU 2015-11 did not have a significant impact on our consolidated financial statements.

[0001262039-17-000017:notes:104]
Recent Accounting Standards Not Yet Effective

[0001262039-17-000017:notes:105]
In January 2017, the FASB issued ASU 2017-04—Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. ASU 2017-04 eliminates Step 2 from the goodwill impairment test which measures a goodwill impairment loss by comparing the implied fair value of a reporting unit’s goodwill with the carrying amount of that goodwill. Under ASU 2017-04, an entity should perform its annual or interim goodwill impairment test by comparing the fair value of the reporting unit with its carrying amount, and should recognize an impairment loss for the amount by which the carrying amount exceeds the reporting unit’s fair value, with the loss not exceeding the total amount of goodwill allocated to that reporting unit. ASU 2016-06 will be effective for us beginning on January 1, 2020. Early adoption is permitted for interim or annual goodwill impairment tests performed after January 1, 2017. At adoption, this update will require a prospective approach. We intend to adopt ASU 2017-04 in the fourth quarter of 2017. We do not believe that ASU 2017-04 will have a material impact on our consolidated financial statements.

[0001262039-17-000017:notes:106]
In October 2016, the FASB issued ASU 2016-16—Income Taxes: —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

[0001262039-17-000017:notes:107]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of adopting ASU 2016-13 on our consolidated financial statements.

[0001262039-17-000017:notes:108]
In February 2016, the FASB issued ASU 2016-02—Leases, which requires the recognition of right-of-use assets and lease liabilities on the consolidated balance sheet for substantially all leases. The new guidance includes a number of optional practical expedients that entities may elect to apply. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019, using a modified retrospective approach. We currently anticipate to early adopt ASU 2016-02 on January 1, 2018. Our ability to early adopt is dependent on system readiness, including software procured from third-party providers, if any, and the completion of our analysis of information necessary to quantify the impact on the prior period financial statements. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized could be at least $50.0 million. We are continuing to evaluate the impact of ASU 2016-02 and our estimate is subject to change. We do not believe that ASU 2016-02 will have a material impact on our consolidated statements of operations.

[0001262039-17-000017:notes:109]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for us beginning January 1, 2018.

[0001262039-17-000017:notes:110]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. Currently, we are in the process of reviewing our historical contracts to quantify the impact on our consolidated financial statements. Depending on the results of our review, there could be changes to the timing of revenue recognition and certain sales commission and related costs associated with obtaining and fulfilling our customer contracts. These changes may include the acceleration of revenue and associated costs on sales to certain channel partners that are currently accounted for only once the product is sold through to the end-customer. We will be required to capitalize and amortize incremental costs related to obtaining customer contracts, such as sales commission costs. We are also in the process of assessing the appropriate changes to our business processes and upgrading our systems and controls to support recognition and disclosure under ASU 2014-09. We otherwise expect to complete our assessment process, including selecting a transition method for adoption, in the next two quarters of 2017.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-17-000017:notes:111]
PROPERTY AND EQUIPMENT—NET

[0001262039-17-000017:notes:112]
Property and equipment—net consisted of the following (in thousands):

[0001262039-17-000017:notes:113]
|  | March 31, 2017 |  | December 31, 2016 |
| Computer equipment and software | $ | 70,048 |  |  | $ | 65,323 |  |
| Building and building improvements | 56,373 |  |  | 49,783 |  |
| Land | 44,198 |  |  | 35,079 |  |
| Leasehold improvements | 20,542 |  |  | 18,699 |  |
| Evaluation units | 19,701 |  |  | 20,173 |  |
| Furniture and fixtures | 14,153 |  |  | 13,995 |  |
| Construction-in-progress | 6,201 |  |  | 4,669 |  |
| Total property and equipment | 231,216 |  |  | 207,721 |  |
| Less: accumulated depreciation | (75,740 | ) |  | (70,472 | ) |
| Property and equipment—net | $ | 155,476 |  |  | $ | 137,249 |  |

[0001262039-17-000017:notes:114]
Depreciation expense was $11.2 million and $9.4 million for the three months ended March 31, 2017 and March 31, 2016, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-17-000017:notes:115]
RELATED PARTY TRANSACTIONS

[0001262039-17-000017:notes:116]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm were $0.1 million and $0.3 million during the three months ended March 31, 2017 and March 31, 2016, respectively. Of such amounts, $0.2 million was incurred under contingent fee arrangements in the three months ended March 31, 2016. There were no expenses incurred under contingent fee arrangements during the three months ended March 31, 2017. Amounts due and payable to the law firm were $0.1 million as of March 31, 2017 and December 31, 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-17-000017:notes:117]
[same as prior period, unchanged from 0001262039-16-000087:notes:157]

[0001262039-17-000017:notes:118]
In 2016 and 2015, we implemented plans to restructure and further improve efficiencies in our operations due primarily to acquisitions. The remaining restructuring reserve as of March 31, 2017 is included in accrued liabilities on the condensed consolidated balance sheets and is expected to be paid in 2017. Restructuring charges related to these plans consisted primarily of employee severance and other one-time benefits paid in cash and are included in operating expense in the condensed consolidated statements of operations.

[0001262039-17-000017:notes:119]
Activities related to the restructuring actions are summarized as follows (in thousands):

[0001262039-17-000017:notes:120]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Balance at beginning of period | $ | 1,151 |  |  | $ | 3,918 |  |
| Costs incurred | 430 |  |  | 328 |  |
| Cash payments | (567 | ) |  | (1,407 | ) |
| Non-cash items | — |  |  | (89 | ) |
| Balance at end of period | $ | 1,014 |  |  | $ | 2,750 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-17-000017:notes:121]
|  | Three Months Ended |
| Revenue | March 31, 2017 |  | March 31, 2016 |
| Americas: |  |  |  |
| U.S. | $ | 90,772 |  |  | $ | 75,558 |  |
| Canada | 37,345 |  |  | 31,305 |  |
| Latin America (“LATAM”) | 18,247 |  |  | 13,183 |  |
| Total Americas | 146,364 |  |  | 120,046 |  |
| Europe, Middle East and Africa (“EMEA”) | 126,149 |  |  | 105,491 |  |
| Asia Pacific (“APAC”) | 68,063 |  |  | 59,039 |  |
| Total revenue | $ | 340,576 |  |  | $ | 284,576 |  |

[0001262039-17-000017:notes:122]
The following customers, each of which is a distributor, accounted for 10% or more of our revenue:

[0001262039-17-000017:notes:123]
|  | Three Months Ended |
|  | March 31, 2017 |  | March 31, 2016 |
| Exclusive Networks Group | 20 | % |  | 19 | % |
| Fine Tec Computers | 12 | % |  | * |  |

[0001262039-17-000017:notes:124]
* Represents less than 10%

[0001262039-17-000017:notes:125]
The following customers, each of which is a distributor, accounted for 10% or more of net accounts receivable:

[0001262039-17-000017:notes:126]
|  | March 31, 2017 |  | December 31, 2016 |
| Exclusive Networks Group | 22 | % |  | 26 | % |
| Fine Tec Computers | 15 | % |  | 10 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-17-000017:notes:127]
[same as prior period, unchanged from 0001262039-16-000087:notes:169]

[0001262039-17-000017:notes:128]
[same as prior period, unchanged from 0001262039-16-000087:notes:170]

[0001262039-17-000017:notes:129]
[same as prior period, unchanged from 0001262039-16-000087:notes:171]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-17-000017:notes:130]
[same as prior period, unchanged from 0001262039-16-000087:notes:172]


## us-gaap:SubsequentEventsTextBlock

[0001262039-17-000017:notes:131]
SUBSEQUENT EVENT

[0001262039-17-000017:notes:132]
In April 2017, we purchased real estate property in Vancouver, Canada totaling approximately 282,000 square feet for a total cash payment of approximately $85.0 million.
