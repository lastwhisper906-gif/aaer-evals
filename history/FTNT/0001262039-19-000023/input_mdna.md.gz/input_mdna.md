# FTNT MD&A — 0001262039-19-000023


## mdna

[0001262039-19-000023:mdna:1]
[same as prior period, unchanged from 0001262039-19-000014:mdna:1]

[0001262039-19-000023:mdna:2]
[same as prior period, unchanged from 0001262039-19-000014:mdna:2]

[0001262039-19-000023:mdna:3]
[same as prior period, unchanged from 0001262039-19-000014:mdna:3]

[0001262039-19-000023:mdna:4]
[same as prior period, unchanged from 0001262039-19-000014:mdna:4]

[0001262039-19-000023:mdna:5]
[same as prior period, unchanged from 0001262039-19-000014:mdna:5]

[0001262039-19-000023:mdna:6]
[same as prior period, unchanged from 0001262039-19-000014:mdna:6]

[0001262039-19-000023:mdna:7]
[same as prior period, unchanged from 0001262039-19-000014:mdna:7]

[0001262039-19-000023:mdna:8]
[same as prior period, unchanged from 0001262039-19-000014:mdna:8]

[0001262039-19-000023:mdna:9]
[same as prior period, unchanged from 0001262039-19-000014:mdna:9]

[0001262039-19-000023:mdna:10]
| • | growing our sales to businesses, service providers and government organizations, our ability to execute these sales and of the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our internal sales organization; |

[0001262039-19-000023:mdna:11]
| • | our ability to hire properly qualified and effective sales, support and engineering employees; |

[0001262039-19-000023:mdna:12]
[same as prior period, unchanged from 0001262039-19-000014:mdna:11]

[0001262039-19-000023:mdna:13]
| • | trends in our operating expenses, including sales and marketing expense, research and development expense, general and administrative expense, and expectations regarding these expenses; |

[0001262039-19-000023:mdna:14]
[same as prior period, unchanged from 0001262039-19-000014:mdna:13]

[0001262039-19-000023:mdna:15]
| • | continued investments in research and development, and expectations that our research and development expense will increase in absolute dollars during the remainder of 2019; |

[0001262039-19-000023:mdna:16]
| • | continued investments in our sales resources and infrastructure and marketing strategy, and expectations that our sales and marketing expense will increase in absolute dollars during the remainder of 2019; |

[0001262039-19-000023:mdna:17]
| • | expectations that our general and administrative expense will increase in absolute dollars during the remainder of 2019; |

[0001262039-19-000023:mdna:18]
| • | expectations that proceeds from the exercise of stock options in future years will be impacted by the increased mix of restricted stock units versus stock options granted; |

[0001262039-19-000023:mdna:19]
| • | estimates of a range of 2019 spending on our new headquarters project; |

[0001262039-19-000023:mdna:20]
| • | expectations regarding uncertain tax benefits and our effective domestic and global tax rates, and the impact of the Tax Cuts and Jobs Act (the “2017 Tax Act”) and the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements; |

[0001262039-19-000023:mdna:21]
[same as prior period, unchanged from 0001262039-19-000014:mdna:17]

[0001262039-19-000023:mdna:22]
[same as prior period, unchanged from 0001262039-19-000014:mdna:18]

[0001262039-19-000023:mdna:23]
| • | statements regarding expected outcomes and liabilities in litigation; |

[0001262039-19-000023:mdna:24]
[same as prior period, unchanged from 0001262039-19-000014:mdna:20]

[0001262039-19-000023:mdna:25]
[same as prior period, unchanged from 0001262039-19-000014:mdna:21]

[0001262039-19-000023:mdna:26]
| • | adoption and impact of new accounting standards. |

[0001262039-19-000023:mdna:27]
[same as prior period, unchanged from 0001262039-19-000014:mdna:23]

[0001262039-19-000023:mdna:28]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, such as enterprises, communication service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and responses.

[0001262039-19-000023:mdna:29]
[same as prior period, unchanged from 0001262039-19-000014:mdna:25]

[0001262039-19-000023:mdna:30]
| • | Network Security—We derive a majority of product sales from our FortiGate network security appliances. Our FortiGate network security appliances include a broad set of built-in security and networking features and functionalities, including firewall, software-defined wide-area network (“SD-WAN”), secure sockets layer data leak prevention, virtual private network, switch and wireless controller and wide area network edge. Our network security appliances are managed by our FortiOS network operating system, which provides the foundation for FortiGate security functions. Our Security Processing Unit (“SPU”) hardware architecture is an important part of our approach to network security and results in high performance across all of our appliances, from branch to data center. Our proprietary Application-Specific Integrated Circuits (“ASICs”) are designed for highly efficient execution of computationally intensive tasks, including policy enforcement, threat detection and encryption. |

[0001262039-19-000023:mdna:31]
| • | Fortinet Security Fabric—The Fortinet Security Fabric extends beyond the network to cover other attack vectors. Our products include endpoint security products, application security products (including for email and web application security), ethernet switches, wireless access points and other security products. |

[0001262039-19-000023:mdna:32]
| • | Cloud Security—We help customers connect securely to and across their cloud environments by offering security through our virtual firewall and other software products in public and private cloud environments. Our Cloud Security solutions, including virtual appliances such as FortiGateVM, FortiSIEM and FortiManager, extend the core capabilities of the Fortinet Security Fabric to provide businesses with the same level of cybersecurity and threat intelligence in cloud environments that they receive on their physical networks. Our virtual appliances can be deployed as bring-your-own-license (“BYOL”) or on-demand with all major cloud providers, including Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud, IBM Cloud and Alibaba Cloud. Cloud security solutions also include FortiCloud, which offers a range of cloud-based management solutions and services across FortiGates and access points. |

[0001262039-19-000023:mdna:33]
26

[0001262039-19-000023:mdna:34]
| • | Internet of Things and Operational Technology—The proliferation of Internet of Things (“IoT”) and the digitization of Operational Technology devices has generated new opportunities for us to grow our business. We offer network access control solutions that provide visibility, control and automated event responses in order to secure IoT devices. |

[0001262039-19-000023:mdna:35]
Our customers may also purchase FortiGuard subscription services to receive threat intelligence updates. We provide standard technical support across all of our products through our FortiCare support services. We also offer services to end-customers including Technical Account Managers, Resident Engineers and professional service consultants for implementations, as well as training services to our end-customers and channel partners.

[0001262039-19-000023:mdna:36]
[same as prior period, unchanged from 0001262039-19-000014:mdna:30]

[0001262039-19-000023:mdna:37]
| • | We recorded total revenue of $521.7 million and $994.3 million during the three and six months ended June 30, 2019, an increase of 18% in both periods compared to $441.3 million and $840.3 million in the same periods last year. Product revenue was $189.9 million and $352.6 million during the three and six months ended June 30, 2019, an increase of 14% in both periods compared to $166.3 million and $309.1 million in the same periods last year. Service revenue was $331.8 million and $641.7 million during the three and six months ended June 30, 2019, an increase of 21% in both periods compared to $275.0 million and $531.2 million in the same periods last year. |

[0001262039-19-000023:mdna:38]
| • | We generated operating income of $75.2 million and $125.8 million during the three and six months ended June 30, 2019, an increase of 48% and 51%, respectively, compared to $50.7 million and $83.1 million in the same periods last year. |

[0001262039-19-000023:mdna:39]
| • | Cash, cash equivalents and investments were $1.98 billion as of June 30, 2019, an increase of $263.1 million, or 15%, from December 31, 2018. |

[0001262039-19-000023:mdna:40]
| • | Deferred revenue was $1.87 billion as of June 30, 2019, an increase of $179.7 million, or 11%, from December 31, 2018. |

[0001262039-19-000023:mdna:41]
| • | We generated cash flows from operating activities of $396.4 million during the six months ended June 30, 2019, an increase of $114.4 million, or 41%, compared to the same period last year. |

[0001262039-19-000023:mdna:42]
| • | During the six months ended June 30, 2019, we repurchased 1.3 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for an aggregate purchase price of $91.1 million. |

[0001262039-19-000023:mdna:43]
During the three and six months ended June 30, 2019, our revenue growth was primarily driven by our service revenue growth. On a geographic basis, revenue continues to be diversified globally, which remains a key strength of our business. Product revenue grew14% during the three and six months ended June 30, 2019 compared to the same periods last year. We experienced revenue growth across several of our hardware and software products. Service revenue growth of 21% during the three and six months ended June 30, 2019 compared to the same periods last year was driven by the strength of our FortiGuard and other security subscription revenue, which grew 24% in both periods compared to the same periods last year. During the three and six months ended June 30, 2019, FortiCare technical support and other service revenue grew 16% and 17%, respectively, compared to the same periods last year.

[0001262039-19-000023:mdna:44]
During the second quarter of 2019, we reclassified the 100 series of our FortiGate product from an entry-level product to a mid-range product. Prior periods have been reclassified to conform with current period presentation. Including this reclassification, we saw a mix shift to mid-range products, with the percentage of our FortiGate-related billings from mid-range products increasing from 42% during the three months ended June 30, 2018 to 46% during the three months ended June 30, 2019. Accordingly, the percentage of our FortiGate-related billings from entry-level and high-end products decreased.

[0001262039-19-000023:mdna:45]
During the three and six months ended June 30, 2019, operating expenses as a percentage of revenue decreased by two percentage points in both periods compared to the same periods last year. The deferral of sales commissions for service contracts had a minimal impact to the changes in operating expenses as a percentage of revenue compared to the same periods last year. Headcount increased by 5% and 8% to 6,293 employees and contractors as of June 30, 2019, from 6,015 as of March 31, 2019 and from 5,845 as of December 31, 2018, respectively.

[0001262039-19-000023:mdna:46]
[same as prior period, unchanged from 0001262039-19-000014:mdna:41]

[0001262039-19-000023:mdna:47]
Our sales strategy is based on a two-tier distribution model. We sell to distributors that sell to networking security and enterprise-focused resellers and service providers, who in turn sell to our end-customers. In certain cases, we sell directly to large service providers and major systems integrators. We also offer our products across major cloud providers, and have recognized on-demand revenue from Amazon Web Services, Microsoft Azure, IBM Cloud and Google Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement at a cloud provider such as Amazon Web Services, Microsoft Azure, Google Cloud, Oracle Cloud and Alibaba Cloud. In a BYOL arrangement, a customer purchases a perpetual license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in their private cloud.

[0001262039-19-000023:mdna:48]
[same as prior period, unchanged from 0001262039-19-000014:mdna:43]

[0001262039-19-000023:mdna:49]
[same as prior period, unchanged from 0001262039-19-000014:mdna:45]

[0001262039-19-000023:mdna:50]
We monitor a number of key metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings (non-GAAP), net cash provided by operating activities, and free cash flow (non-GAAP). We discuss revenue below under “Results of Operations,” and we discuss net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP), and free cash flow (non-GAAP) are discussed immediately below the following table:

[0001262039-19-000023:mdna:51]
|  | Three Months Ended Or As Of |
|  | June 30, 2019 |  | June 30, 2018 |
|  | (in millions) |
| Revenue | $ | 521.7 |  |  | $ | 441.3 |  |
| Deferred revenue | $ | 1,866.5 |  |  | $ | 1,470.8 |  |
| Billings (non-GAAP) | $ | 622.4 |  |  | $ | 513.4 |  |
| Net cash provided by operating activities | $ | 195.1 |  |  | $ | 142.2 |  |
| Free cash flow (non-GAAP) | $ | 177.8 |  |  | $ | 130.6 |  |

[0001262039-19-000023:mdna:52]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, growth and the mix of short-term and long-term deferred revenue because it represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $1.87 billion as of June 30, 2019, an increase of $179.7 million, or 11%, from December 31, 2018.

[0001262039-19-000023:mdna:53]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $622.4 million for the three months ended June 30, 2019, an increase of 21% compared to $513.4 million in the same period last year.

[0001262039-19-000023:mdna:54]
[same as prior period, unchanged from 0001262039-19-000014:mdna:51]

[0001262039-19-000023:mdna:55]
|  | Three Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 521.7 |  |  | $ | 441.3 |  |
| Add: Change in deferred revenue | 100.7 |  |  | 74.4 |  |
| Add: Deferred revenue balance acquired in business combination | — |  |  | (2.3 | ) |
| Total billings (non-GAAP) | $ | 622.4 |  |  | $ | 513.4 |  |

[0001262039-19-000023:mdna:56]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under “—Liquidity and Capital Resources” and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-19-000023:mdna:57]
[same as prior period, unchanged from 0001262039-19-000014:mdna:56]

[0001262039-19-000023:mdna:58]
|  | Three Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 195.1 |  |  | $ | 142.2 |  |
| Less: Purchases of property and equipment | (17.3 | ) |  | (11.6 | ) |
| Free cash flow (non-GAAP) | $ | 177.8 |  |  | $ | 130.6 |  |
| Net cash provided by (used in) investing activities | $ | (336.6 | ) |  | $ | 7.0 |  |
| Net cash used in financing activities | $ | (53.3 | ) |  | $ | (12.8 | ) |

[0001262039-19-000023:mdna:59]
[same as prior period, unchanged from 0001262039-19-000014:mdna:58]

[0001262039-19-000023:mdna:60]
[same as prior period, unchanged from 0001262039-19-000014:mdna:59]

[0001262039-19-000023:mdna:61]
There were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2019, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 27, 2019 (the “Form 10-K”).

[0001262039-19-000023:mdna:62]
[same as prior period, unchanged from 0001262039-19-000014:mdna:61]

[0001262039-19-000023:mdna:63]
[same as prior period, unchanged from 0001262039-19-000014:mdna:62]

[0001262039-19-000023:mdna:64]
[same as prior period, unchanged from 0001262039-19-000014:mdna:63]

[0001262039-19-000023:mdna:65]
Three Months Ended June 30, 2019 and June 30, 2018

[0001262039-19-000023:mdna:66]
[same as prior period, unchanged from 0001262039-19-000014:mdna:65]

[0001262039-19-000023:mdna:67]
|  | Three Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 189.9 |  |  | 36 | % |  | $ | 166.3 |  |  | 38 | % |  | $ | 23.6 |  |  | 14 | % |
| Service | 331.8 |  |  | 64 |  |  | 275.0 |  |  | 62 |  |  | 56.8 |  |  | 21 |  |
| Total revenue | $ | 521.7 |  |  | 100 | % |  | $ | 441.3 |  |  | 100 | % |  | $ | 80.4 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 225.5 |  |  | 43 | % |  | $ | 189.3 |  |  | 43 | % |  | $ | 36.2 |  |  | 19 | % |
| Europe, Middle East and Africa (“EMEA”) | 192.0 |  |  | 37 |  |  | 164.4 |  |  | 37 |  |  | 27.6 |  |  | 17 |  |
| Asia Pacific (“APAC”) | 104.2 |  |  | 20 |  |  | 87.6 |  |  | 20 |  |  | 16.6 |  |  | 19 |  |
| Total revenue | $ | 521.7 |  |  | 100 | % |  | $ | 441.3 |  |  | 100 | % |  | $ | 80.4 |  |  | 18 | % |

[0001262039-19-000023:mdna:68]
Total revenue increased by $80.4 million, or 18%, during the three months ended June 30, 2019 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all regions grew, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-19-000023:mdna:69]
Product revenue increased by $23.6 million, or 14%, during the three months ended June 30, 2019 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in unit shipments year-over-year, and we saw a mix shift toward mid-range FortiGate appliances.

[0001262039-19-000023:mdna:70]
Service revenue increased by $56.8 million, or 21%, during the three months ended June 30, 2019 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support and other contracts, which increased by $36.0 million, or 24%, and $20.8 million, or 16%, respectively, during the three months ended June 30, 2019 compared to the same period last year.

[0001262039-19-000023:mdna:71]
[same as prior period, unchanged from 0001262039-19-000014:mdna:69]

[0001262039-19-000023:mdna:72]
|  | Three Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 82.7 |  |  | $ | 73.9 |  |  | $ | 8.8 |  |  | 12 | % |
| Service | 45.6 |  |  | 39.2 |  |  | 6.4 |  |  | 16 |  |
| Total cost of revenue | $ | 128.3 |  |  | $ | 113.1 |  |  | $ | 15.2 |  |  | 13 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.5 | % |  | 55.6 | % |  |  |  |  |
| Service | 86.3 |  |  | 85.7 |  |  |  |  |  |
| Total gross margin | 75.4 | % |  | 74.4 | % |  |  |  |  |

[0001262039-19-000023:mdna:73]
Total gross margin increased by 1.0 percentage points during the three months ended June 30, 2019 compared to the same period last year, driven by improvements to both product and service gross margins.

[0001262039-19-000023:mdna:74]
Product gross margin increased by 0.9 percentage points during the three months ended June 30, 2019 compared to the same period last year. Product gross margin benefited from lower indirect product costs as a percentage of revenue, partially offset by an increase in direct product costs as a percentage of revenue, reflecting our shift in product mix. Cost of product revenue was comprised of direct product costs and indirect costs, including inventory reserves and other manufacturing overhead.

[0001262039-19-000023:mdna:75]
Service gross margin increased by 0.6 percentage points during the three months ended June 30, 2019 compared to the same period last year, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-19-000023:mdna:76]
[same as prior period, unchanged from 0001262039-19-000014:mdna:73]

[0001262039-19-000023:mdna:77]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2019 |  | June 30, 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 67.4 |  |  | 13% |  | $ | 61.2 |  |  | 14 | % |  | $ | 6.2 |  |  | 10 | % |
| Sales and marketing | 226.5 |  |  | 43 |  | 192.8 |  |  | 44 |  |  | 33.7 |  |  | 17 |  |
| General and administrative | 24.3 |  |  | 5 |  | 23.5 |  |  | 5 |  |  | 0.8 |  |  | 3 |  |
| Total operating expenses | $ | 318.2 |  |  | 61% |  | $ | 277.5 |  |  | 63 | % |  | $ | 40.7 |  |  | 15 | % |

[0001262039-19-000023:mdna:78]
[same as prior period, unchanged from 0001262039-19-000014:mdna:75]

[0001262039-19-000023:mdna:79]
Research and development expense increased by $6.2 million, or 10%, during the three months ended June 30, 2019 compared to the same period last year, primarily due to an increase of $6.9 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. The increase in expense was offset by a decrease in product development expenses, such as third-party testing, prototypes and supplies of $2.3 million. We intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000023:mdna:80]
[same as prior period, unchanged from 0001262039-19-000014:mdna:77]

[0001262039-19-000023:mdna:81]
Sales and marketing expense increased by $33.7 million, or 17%, during the three months ended June 30, 2019 compared to the same period last year, primarily due to an increase of $25.0 million in personnel-related costs, including higher stock-based compensation expense of $2.7 million, as sales and marketing headcount increased in order to drive market share gains globally. Marketing-related expense increased by $3.7 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000023:mdna:82]
[same as prior period, unchanged from 0001262039-19-000014:mdna:79]

[0001262039-19-000023:mdna:83]
General and administrative expense increased by $0.8 million, or 3%, during the three months ended June 30, 2019 compared to the same period last year, due to an increase of $1.4 million in legal expenses and an increase of $0.5 million in personnel-related costs. The increase in expenses was partially offset by a decrease of $0.4 million in professional services cost and a decrease of $0.7 million in other expenses. We expect general and administrative expense to increase in absolute dollars during the remainder of 2019.

[0001262039-19-000023:mdna:84]
[same as prior period, unchanged from 0001262039-19-000014:mdna:81]

[0001262039-19-000023:mdna:85]
|  | Three Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 11.0 |  |  | $ | 5.8 |  |  | $ | 5.2 |  |  | 90 | % |
| Other expense—net | $ | (0.4 | ) |  | $ | (5.0 | ) |  | $ | 4.6 |  |  | (92 | )% |

[0001262039-19-000023:mdna:86]
Interest income increased during the three months ended June 30, 2019 compared to the same period last year, primarily due to higher interest rates and, to a lesser extent, higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net during the three months ended June 30, 2019 compared to the same period last year was primarily due to lower foreign currency exchange losses.

[0001262039-19-000023:mdna:87]
Provision for income taxes

[0001262039-19-000023:mdna:88]
|  | Three Months Ended |  | Change |  | % Change |
| June 30, 2019 |  | June 30, 2018 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 13.1 |  |  | $ | 2.2 |  |  | $ | 10.9 |  |  | 495 | % |
| Effective tax rate (%) | 15 | % |  | 4 | % |  |  |  |  |  |  |

[0001262039-19-000023:mdna:89]
Our effective tax rate was 15% for the three months ended June 30, 2019 compared to an effective tax rate of 4% for the same period last year. The effective tax rate for the three months ended June 30, 2019 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $24.5 million, which were offset by excess tax benefits from stock-based compensation expense of $11.7 million. The tax rate for the three months ended June 30, 2019 was impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements. This expense was offset by release of reserves of $10.0 million on uncertain tax positions and the associated interests due to the expiration of the statute of limitations. The tax rate for the three months ended June 30, 2018 are comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes of $17.2 million, which were offset by excess tax benefits from stock-based compensation expense of $4.9 million. The tax rate for the three months ended by June 30, 2018 was also impacted by release of a reserve on uncertain tax positions, including interest, of $10.1 million.

[0001262039-19-000023:mdna:90]
Results of Operations

[0001262039-19-000023:mdna:91]
Six Months Ended June 30, 2019 and June 30, 2018

[0001262039-19-000023:mdna:92]
Revenue

[0001262039-19-000023:mdna:93]
|  | Six Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 352.6 |  |  | 35 | % |  | $ | 309.1 |  |  | 37 | % |  | $ | 43.5 |  |  | 14 | % |
| Service | 641.7 |  |  | 65 |  |  | 531.2 |  |  | 63 |  |  | 110.5 |  |  | 21 |  |
| Total revenue | $ | 994.3 |  |  | 100 | % |  | $ | 840.3 |  |  | 100 | % |  | $ | 154.0 |  |  | 18 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 426.0 |  |  | 43 | % |  | $ | 365.1 |  |  | 43 | % |  | $ | 60.9 |  |  | 17 | % |
| EMEA | 369.2 |  |  | 37 |  |  | 308.9 |  |  | 37 |  |  | 60.3 |  |  | 20 |  |
| APAC | 199.1 |  |  | 20 |  |  | 166.3 |  |  | 20 |  |  | 32.8 |  |  | 20 |  |
| Total revenue | $ | 994.3 |  |  | 100 | % |  | $ | 840.3 |  |  | 100 | % |  | $ | 154.0 |  |  | 18 | % |

[0001262039-19-000023:mdna:94]
Total revenue increased by $154.0 million, or 18%, during the six months ended June 30, 2019 compared to the same period last year. We continued to experience diversification of revenue globally. Revenue from all regions grew, with the Americas contributing the largest portion of our revenue growth on an absolute dollar basis.

[0001262039-19-000023:mdna:95]
Product revenue increased by $43.5 million, or 14%, during the six months ended June 30, 2019 compared to the same period last year. We experienced revenue growth across many of our hardware and software products due to an increase in unit shipments year-over-year, and we saw a mix shift toward mid-range FortiGate appliances.

[0001262039-19-000023:mdna:96]
Service revenue increased by $110.5 million, or 21%, during the six months ended June 30, 2019 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support and other contracts, which increased by $68.9 million, or 24%, and $41.6 million, or 17%, respectively, during the six months ended June 30, 2019 compared to the same period last year.

[0001262039-19-000023:mdna:97]
Cost of revenue and gross margin

[0001262039-19-000023:mdna:98]
|  | Six Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 152.9 |  |  | $ | 132.1 |  |  | $ | 20.8 |  |  | 16 | % |
| Service | 88.4 |  |  | 78.2 |  |  | 10.2 |  |  | 13 |  |
| Total cost of revenue | $ | 241.3 |  |  | $ | 210.3 |  |  | $ | 31.0 |  |  | 15 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 56.6 | % |  | 57.3 | % |  |  |  |  |
| Service | 86.2 |  |  | 85.3 |  |  |  |  |  |
| Total gross margin | 75.7 | % |  | 75.0 | % |  |  |  |  |

[0001262039-19-000023:mdna:99]
Total gross margin increased by 0.7 percentage points during the six months ended June 30, 2019 compared to the same period last year, driven primarily by an increase in service gross margin, which was partially offset by a decrease in product gross margin.

[0001262039-19-000023:mdna:100]
Product gross margin decreased by 0.7 percentage points, reflecting changes in our product mix during the six months ended June 30, 2019 compared to the same period last year. Cost of product revenue was comprised of direct product costs and indirect costs, including inventory reserves and other manufacturing overhead.

[0001262039-19-000023:mdna:101]
Service gross margin increased by 0.9 percentage points during the six months ended June 30, 2019 compared to the same period last year, as our service revenue growth outpaced our growth in related personnel costs. Cost of service revenue was comprised primarily of personnel costs.

[0001262039-19-000023:mdna:102]
Operating expenses

[0001262039-19-000023:mdna:103]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2019 |  | June 30, 2018 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 136.0 |  |  | 14% |  | $ | 120.3 |  |  | 14 | % |  | $ | 15.7 |  |  | 13 | % |
| Sales and marketing | 442.4 |  |  | 44 |  | 378.1 |  |  | 45 |  |  | 64.3 |  |  | 17 |  |
| General and administrative | 48.8 |  |  | 5 |  | 48.5 |  |  | 6 |  |  | 0.3 |  |  | 1 |  |
| Total operating expenses | $ | 627.2 |  |  | 63% |  | $ | 546.9 |  |  | 65 | % |  | $ | 80.3 |  |  | 15 | % |

[0001262039-19-000023:mdna:104]
Research and development

[0001262039-19-000023:mdna:105]
Research and development expense increased by $15.7 million, or 13%, during the six months ended June 30, 2019 compared to the same period last year, primarily due to an increase of $14.1 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products.

[0001262039-19-000023:mdna:106]
Sales and marketing

[0001262039-19-000023:mdna:107]
Sales and marketing expense increased by $64.3 million, or 17%, during the six months ended June 30, 2019 compared to the same period last year, primarily due to an increase of $47.1 million in personnel-related costs, including higher stock-based compensation expense of $7.2 million, as sales and marketing headcount increased in order to drive market share gains globally. In addition, marketing-related expense increased by $6.4 million.

[0001262039-19-000023:mdna:108]
General and administrative

[0001262039-19-000023:mdna:109]
General and administrative expense increased by $0.3 million, or 1%, during the six months ended June 30, 2019 compared to the same period last year, due to an increase of $2.4 million in legal expenses and an increase of $1.3 million in personnel-related costs. The increase in expense was partially offset by a decrease of $3.0 million in professional services and a decrease of other expenses of $0.5 million.

[0001262039-19-000023:mdna:110]
Interest income and other expense—net

[0001262039-19-000023:mdna:111]
|  | Six Months Ended |  |  |  |  |
| June 30, 2019 |  | June 30, 2018 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 21.2 |  |  | $ | 10.3 |  |  | $ | 10.9 |  |  | 106 | % |
| Other expense—net | $ | (0.9 | ) |  | $ | (5.2 | ) |  | $ | 4.3 |  |  | (83 | )% |

[0001262039-19-000023:mdna:112]
Interest income increased during the six months ended June 30, 2019 compared to the same period last year, primarily due to higher interest rates and, to a lesser extent, higher invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The change in other expense—net during the six months ended June 30, 2019 compared to the same period last year was primarily due to lower foreign currency exchange losses.

[0001262039-19-000023:mdna:113]
[same as prior period, unchanged from 0001262039-19-000014:mdna:84]

[0001262039-19-000023:mdna:114]
|  | Six Months Ended |  | Change |  | % Change |
| June 30, 2019 |  | June 30, 2018 |  |
| (in millions, except percentages) |
| Provision for (benefit from) income taxes | $ | 14.6 |  |  | $ | (2.7 | ) |  | $ | 17.3 |  |  | (641 | )% |
| Effective tax rate (%) | 10 | % |  | (3 | )% |  |  |  |  |  |  |

[0001262039-19-000023:mdna:115]
Our effective tax rate was 10% for the six months ended June 30, 2019 compared to an effective tax rate benefit of 3% for the same period last year. The effective tax rate for the six months ended June 30, 2019 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $42.0 million, which were offset by excess tax benefits from stock-based compensation expense of $27.7 million. The tax rate for the six months ended June 30, 2019 was impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision regarding stock-based compensation expense in cost sharing arrangements. This expense was offset by release of reserves of $10.0 million on uncertain tax positions and the associated interests due to the expiration of the statute of limitations. The tax rate for the six months ended June 30, 2018 was comprised of U.S. federal and state taxes, withholding taxes and foreign taxes of $25.7 million, which were offset by excess tax benefits from stock-based compensation expense of $10.5 million. The tax rate for the six month ended June 30, 2018 was also impacted by release of reserve for uncertain tax positions including interest of $18.0 million.

[0001262039-19-000023:mdna:116]
35

[0001262039-19-000023:mdna:117]
[same as prior period, unchanged from 0001262039-19-000014:mdna:87]

[0001262039-19-000023:mdna:118]
|  | As of |
|  | June 30, 2019 |  | December 31, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,022.1 |  |  | $ | 1,112.4 |  |
| Investments | 957.6 |  |  | 604.2 |  |
| Total cash, cash equivalents and investments | $ | 1,979.7 |  |  | $ | 1,716.6 |  |
| Working capital | $ | 1,067.0 |  |  | $ | 964.5 |  |
|  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 396.4 |  |  | $ | 282.0 |  |
| Net cash used in investing activities | (375.6 | ) |  | (18.5 | ) |
| Net cash used in financing activities | (111.1 | ) |  | (102.4 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (90.3 | ) |  | $ | 161.1 |  |

[0001262039-19-000023:mdna:119]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, real estate and other capital expenditures, proceeds associated with stock option exercises and issuances of common stock under our equity incentive plans and payment of taxes in connection with the net settlement of equity awards. In recent years, we have received significant capital resources from billings, the exercise of stock options and ESPP purchases. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted and also to vary based on our share price. We expect there to be no future proceeds from purchases under our ESPP, which was terminated in February 2019. As of June 30, 2019, $642.7 million remained available for future share repurchase under the Repurchase Program.

[0001262039-19-000023:mdna:120]
Construction of our new headquarters building started in the fourth quarter of 2018 and related spending will continue in 2019 and until project completion. We estimate 2019 spending on the project to be between $50.0 million to $70.0 million dollars.

[0001262039-19-000023:mdna:121]
As of June 30, 2019, our cash, cash equivalents and investments of $1.98 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government and agency securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-19-000023:mdna:122]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $138.5 million as of June 30, 2019 and $956.6 million as of December 31, 2018. The decrease in cash, cash equivalents and investments held by our international subsidiaries was due to our international tax restructure.

[0001262039-19-000023:mdna:123]
[same as prior period, unchanged from 0001262039-19-000014:mdna:94]

[0001262039-19-000023:mdna:124]
36

[0001262039-19-000023:mdna:125]
[same as prior period, unchanged from 0001262039-19-000014:mdna:95]

[0001262039-19-000023:mdna:126]
[same as prior period, unchanged from 0001262039-19-000014:mdna:96]

[0001262039-19-000023:mdna:127]
Our operating activities during the six months ended June 30, 2019 provided $396.4 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $395.7 million, or 27%, as of June 30, 2019 compared to the same period last year.

[0001262039-19-000023:mdna:128]
Our operating activities during the six months ended June 30, 2018 provided $282.0 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $309.3 million, or 27%, as of June 30, 2018 compared to the same period in the prior year.

[0001262039-19-000023:mdna:129]
[same as prior period, unchanged from 0001262039-19-000014:mdna:99]

[0001262039-19-000023:mdna:130]
[same as prior period, unchanged from 0001262039-19-000014:mdna:100]

[0001262039-19-000023:mdna:131]
During the six months ended June 30, 2019, cash used in investing activities was primarily due to $348.1 million spent for purchases of investments, net of maturities and sales of investments and $27.5 million spent on capital expenditures.

[0001262039-19-000023:mdna:132]
During the six months ended June 30, 2018, cash used for investing activities was primarily due to the $23.2 million we spent on capital expenditures and $6.0 million used for the acquisition of Bradford, net of cash acquired. This was partially offset by an increase in cash of $10.7 million due to maturities and sales of our investments, net of purchases.

[0001262039-19-000023:mdna:133]
[same as prior period, unchanged from 0001262039-19-000014:mdna:103]

[0001262039-19-000023:mdna:134]
[same as prior period, unchanged from 0001262039-19-000014:mdna:104]

[0001262039-19-000023:mdna:135]
During the six months ended June 30, 2019, cash used in financing activities was $111.1 million, primarily due to $94.2 million used to repurchase our common stock and $16.9 million used to pay tax withholding, net of proceeds, from the issuance of common stock.

[0001262039-19-000023:mdna:136]
During the six months ended June 30, 2018, cash used for financing activities was $102.4 million, primarily due to $117.1 million used to repurchase our common stock and $9.5 million of payments of the debt assumed in business combinations. This was partially offset by $24.2 million of proceeds, net of tax withholding, from the issuance of common stock.

[0001262039-19-000023:mdna:137]
[same as prior period, unchanged from 0001262039-19-000014:mdna:107]

[0001262039-19-000023:mdna:138]
Except for presentation changes resulting from the adoption of Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”) during the period, there were no material changes outside the ordinary course of business during the six months ended June 30, 2019 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 11 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-19-000023:mdna:139]
37

[0001262039-19-000023:mdna:140]
[same as prior period, unchanged from 0001262039-19-000014:mdna:109]

[0001262039-19-000023:mdna:141]
As of June 30, 2019, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
