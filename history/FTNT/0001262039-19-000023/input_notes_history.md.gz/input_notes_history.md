# FTNT note change history — 0001262039-19-000014 → 0001262039-19-000023


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0001262039-19-000023:note_history:1]
The following table summarizes our future principal contractual obligations as of June 30, 2019 (in millions):
  (was, 2019-05-08, similarity 0.9573):
[0001262039-19-000014:note_history:1]
The following table summarizes our future principal contractual obligations as of March 31, 2019 (in millions):

- changed (2019-08-01):
[0001262039-19-000023:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2019, we had $218.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2019-05-08, similarity 0.9933):
[0001262039-19-000014:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of March 31, 2019, we had $202.2 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2019-08-01):
[0001262039-19-000023:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2019, we had $22.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2019-05-08, similarity 0.9885):
[0001262039-19-000014:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2019, we had $15.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- changed (2019-08-01):
[0001262039-19-000023:note_history:4]
Indemnification and other matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.
  (was, 2019-05-08, similarity 0.9923):
[0001262039-19-000014:note_history:4]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

- added (2019-08-01):
[0001262039-19-000023:note_history:5]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, threats to our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We are in the process of investigating and evaluating this matter, and, although at this time there can be no assurances as to the outcome and impact of this matter, which are currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings related to this matter, including any that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with these types of incidents and possible impacts associated with a cybersecurity attack or other events may include remediation costs related to lost, stolen or compromised

- added (2019-08-01):
[0001262039-19-000023:note_history:6]
data, repairs to data processing systems, increased cybersecurity protection costs, adverse effects on our compliance with laws and regulations, litigation and reputational damage.

- removed (2019-08-01):
[0001262039-19-000014:note_history:7]
As previously disclosed, in October 2016, we received a letter from the United States Attorney’s Office for the Northern District of California requesting information on events from over two years ago related to our compliance with the Trade Agreements Act. We cooperated with the inquiry, and settled this matter with the United States Attorney’s Office.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0001262039-19-000023:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.
  (was, 2019-05-08, similarity 0.9839):
[0001262039-19-000014:note_history:8]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

- changed (2019-08-01):
[0001262039-19-000023:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.
  (was, 2019-05-08, similarity 0.9417):
[0001262039-19-000014:note_history:9]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

- changed (2019-08-01):
[0001262039-19-000023:note_history:10]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to waive reassessing the lease classification for any expired or existing leases, the initial direct costs for any existing leases and whether any expired or existing contracts contained leases.
  (was, 2019-05-08, similarity 0.8043):
[0001262039-19-000014:note_history:10]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to not reassess whether arrangements contain leases, not reassess lease classification and not reassess initial direct costs.

- changed (2019-08-01):
[0001262039-19-000023:note_history:11]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.
  (was, 2019-05-08, similarity 0.9683):
[0001262039-19-000014:note_history:11]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less and does not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

- changed (2019-08-01):
[0001262039-19-000023:note_history:12]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.
  (was, 2019-05-08, similarity 0.7608):
[0001262039-19-000014:note_history:12]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred

- changed (2019-08-01):
[0001262039-19-000023:note_history:13]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019. ASU 2018-07 did not have a material impact on our condensed consolidated financial statements.
  (was, 2019-05-08, similarity 0.9974):
[0001262039-19-000014:note_history:13]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019, ASU 2018-07 did not have a material impact to our condensed consolidated financial statements.

- changed (2019-08-01):
[0001262039-19-000023:note_history:14]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. Companies can choose to adopt the ASU 2018-15 prospectively or retrospectively. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our condensed consolidated financial statements.
  (was, 2019-05-08, similarity 0.7127):
[0001262039-19-000014:note_history:14]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 to our condensed consolidated financial statements.

- changed (2019-08-01):
[0001262039-19-000023:note_history:15]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 that relate to changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.
  (was, 2019-05-08, similarity 0.9929):
[0001262039-19-000014:note_history:15]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 on changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements, and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

- added (2019-08-01):
[0001262039-19-000023:note_history:16]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). In April 2019, the FASB issued ASU 2019-04—Codification Improvements to Topic 326: Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, and in May 2019, the FASB issued ASU 2019-05—Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief. Topic 326 requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We are in the process of determining the changes needed to our valuation model for trade receivables, and we are reviewing our process to identify credit-related losses on available-for-sale investments. We also expect the new guidance to expand our related financial statement disclosures. The new guidance is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of the new guidance on our condensed consolidated financial statements.

- removed (2019-08-01):
[0001262039-19-000014:note_history:17]
rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.

- removed (2019-08-01):
[0001262039-19-000014:note_history:18]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). Topic 326 requires a financial asset (or a group of financial assets) to be measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) applies to most financial assets measured at amortized cost and certain other instruments, including trade and other receivables, loans and held-to-maturity debt securities. Topic 326 is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of Topic 326 on our condensed consolidated financial statements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0001262039-19-000023:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 183.1 |  |  | 147.1 |  |  | 352.7 |  |  | 283.8 |  |
| Technical support and other | 148.7 |  |  | 127.9 |  |  | 289.0 |  |  | 247.4 |  |
| Total service revenue | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |
  (was, 2019-05-08, similarity 0.6849):
[0001262039-19-000014:note_history:19]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service: |  |  |  |
| Security subscription | 169.6 |  |  | 136.6 |  |
| Technical support and other | 140.3 |  |  | 119.6 |  |
| Total service revenue | 309.9 |  |  | 256.2 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0001262039-19-000023:note_history:20]
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

- changed (2019-08-01):
[0001262039-19-000023:note_history:21]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 183.1 |  |  | 147.1 |  |  | 352.7 |  |  | 283.8 |  |
| Technical support and other | 148.7 |  |  | 127.9 |  |  | 289.0 |  |  | 247.4 |  |
| Total service revenue | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |
  (was, 2019-05-08, similarity 0.6849):
[0001262039-19-000014:note_history:21]
|  | Three Months Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Product | $ | 162.7 |  |  | $ | 142.8 |  |
| Service: |  |  |  |
| Security subscription | 169.6 |  |  | 136.6 |  |
| Technical support and other | 140.3 |  |  | 119.6 |  |
| Total service revenue | 309.9 |  |  | 256.2 |  |
| Total revenue | $ | 472.6 |  |  | $ | 399.0 |  |

- changed (2019-08-01):
[0001262039-19-000023:note_history:22]
During the three months ended June 30, 2019 and June 30, 2018, we recognized $252.0 million and $203.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the six months ended June 30, 2019 and June 30, 2018, we recognized $540.6 million and $442.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.
  (was, 2019-05-08, similarity 0.605):
[0001262039-19-000014:note_history:22]
During the three months ended March 31, 2019 and March 31, 2018, we recognized $288.6 million and $239.1 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31,2017, respectively.

- changed (2019-08-01):
[0001262039-19-000023:note_history:23]
As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.87 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.03 billion into revenue over the next 12 months and the remainder thereafter.
  (was, 2019-05-08, similarity 0.6967):
[0001262039-19-000014:note_history:23]
As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.77 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next one to two years, with the remaining balance to be recognized in three to five years.

- changed (2019-08-01):
[0001262039-19-000023:note_history:24]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of June 30, 2019 and December 31, 2018, respectively.
  (was, 2019-05-08, similarity 0.9867):
[0001262039-19-000014:note_history:24]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of March 31, 2019 and December 31, 2018, respectively.

- changed (2019-08-01):
[0001262039-19-000023:note_history:25]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2019 and June 30, 2018 were $25.9 million and $22.4 million, respectively.  Amortization of deferred contract costs during the six months ended June 30, 2019 and June 30, 2018 were $51.0 million and $43.2 million, respectively.
  (was, 2019-05-08, similarity 0.7809):
[0001262039-19-000014:note_history:25]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended March 31, 2019 and March 31, 2018 were $25.1 million and $20.8 million, respectively. No impairment loss was recognized during the three months ended March 31, 2019 or March 31, 2018.

- removed (2019-08-01):
[0001262039-19-000014:note_history:26]
Our revenue consists of product and service revenue. Product revenue primarily consists of sales from our FortiGate products. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.
