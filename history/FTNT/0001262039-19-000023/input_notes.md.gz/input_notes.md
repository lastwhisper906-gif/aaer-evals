# FTNT notes — 0001262039-19-000023


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-19-000023:notes:1]
[same as prior period, unchanged from 0001262039-19-000014:notes:1]

[0001262039-19-000023:notes:2]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2018, contained in our Annual Report on Form 10-K filed with the SEC on February 27, 2019. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2019 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2018 is derived from the audited consolidated financial statements for the year ended December 31, 2018.

[0001262039-19-000023:notes:3]
[same as prior period, unchanged from 0001262039-19-000014:notes:3]

[0001262039-19-000023:notes:4]
There have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2019, except for the accounting policies for leases that were updated as a result of adopting Accounting Standards Update (“ASU”) 2016-02—Leases (Topic 842) (“Topic 842”). For more information, refer to the “Recently Adopted Accounting Standards” and Note 10.

[0001262039-19-000023:notes:5]
Recently Adopted Accounting Standards

[0001262039-19-000023:notes:6]
[same as prior period, unchanged from 0001262039-19-000014:notes:6]

[0001262039-19-000023:notes:7]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Topic 842, which requires the recognition of right-of-use (“ROU”) assets and lease liabilities for operating leases on the condensed consolidated balance sheet. We adopted Topic 842 and its related amendments as of January 1, 2019 using a modified retrospective transition approach by applying the new standard to all leases existing at the date of initial application and not restating comparative periods. We elected the package of practical expedients permitted under the transition guidance, which allowed us to waive reassessing the lease classification for any expired or existing leases, the initial direct costs for any existing leases and whether any expired or existing contracts contained leases.

[0001262039-19-000023:notes:8]
Under the new guidance, we determine if an arrangement contains a lease and the classification of that lease, if applicable, at inception or upon modification of a contract. We have elected to not recognize a lease liability or ROU asset for short-term leases (leases that, at the commencement date, have a lease term of twelve months or less and do not include an option to purchase the underlying asset that the Company is reasonably certain to exercise). We have elected to not allocate the contract consideration for operating lease contracts with lease and non-lease components, and account for the lease and non-lease components as a single lease component. ROU assets represent our right to use an underlying asset for the lease term. Lease liabilities represent our obligation to make lease payments under the lease. Operating lease ROU assets and liabilities are recognized at the lease commencement date based on the present value of lease payments over the lease term. The implicit rate within our operating leases is generally not determinable and therefore we use our incremental borrowing rate at the lease commencement date to determine the present value of lease payments. The determination of our incremental borrowing rate requires judgment. We determine our incremental borrowing rate for each lease using indicative bank borrowing rates, adjusted for various factors including level of collateralization, term and currency to align with the terms of a lease. The operating lease ROU asset also includes any lease prepayments, net of lease incentives. Certain of our leases include options to extend or terminate the lease. An option to extend the lease is considered in connection with determining the ROU asset and lease liability when it is reasonably certain we will exercise that option. An option to terminate is considered unless it is reasonably certain we will not exercise the option.

[0001262039-19-000023:notes:9]
The primary impact of adopting Topic 842 was the recognition of ROU assets and lease liabilities for operating leases of $39.1 million and $40.6 million, respectively, on January 1, 2019, which included reclassifying prepaid rent and deferred rent as a component of the ROU asset. Topic 842 did not have a material impact on our condensed consolidated statements of income and cash flows.

[0001262039-19-000023:notes:10]
[same as prior period, unchanged from 0001262039-19-000014:notes:11]

[0001262039-19-000023:notes:11]
[same as prior period, unchanged from 0001262039-19-000014:notes:12]

[0001262039-19-000023:notes:12]
[same as prior period, unchanged from 0001262039-19-000014:notes:13]

[0001262039-19-000023:notes:13]
In February 2018, the FASB issued ASU 2018-02—Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Cuts and Jobs Act (the “2017 Tax Act”) from accumulated other comprehensive income to retained earnings. We adopted ASU 2018-02 on January 1, 2019 and elected to reclassify $0.1 million of stranded tax effects as of that date.

[0001262039-19-000023:notes:14]
[same as prior period, unchanged from 0001262039-19-000014:notes:15]

[0001262039-19-000023:notes:15]
In June 2018, the FASB issued ASU 2018-07—Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, which simplifies the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees subject to certain exceptions. ASU 2018-07 expands the scope of Accounting Standards Codification (“ASC”) Topic 718, Compensation—Stock Compensation (“ASC 718”), to include share-based payments granted to nonemployees in exchange for goods or services used or consumed in an entity’s own operations and supersedes the guidance in ASC 505, Equity, by moving it to ASC 718. We adopted ASU 2018-07 on January 1, 2019. ASU 2018-07 did not have a material impact on our condensed consolidated financial statements.

[0001262039-19-000023:notes:16]
[same as prior period, unchanged from 0001262039-19-000014:notes:17]

[0001262039-19-000023:notes:17]
[same as prior period, unchanged from 0001262039-19-000014:notes:18]

[0001262039-19-000023:notes:18]
In August 2018, the FASB issued ASU 2018-15—Intangibles-Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, which requires a customer in a cloud computing arrangement that is a service contract to follow the internal-use software guidance in ASC Topic 350, Intangibles—Goodwill and Other, to determine which implementation costs to capitalize as assets or expense as incurred. Companies can choose to adopt the ASU 2018-15 prospectively or retrospectively. ASU 2018-15 is effective for us beginning January 1, 2020, and early adoption is permitted. We are currently evaluating the impact of ASU 2018-15 on our condensed consolidated financial statements.

[0001262039-19-000023:notes:19]
[same as prior period, unchanged from 0001262039-19-000014:notes:20]

[0001262039-19-000023:notes:20]
In August 2018, the FASB issued ASU 2018-13—Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds and modifies certain disclosure requirements for fair value measurements in ASC 820, Fair Value Measurement, as part of its disclosure framework project. ASU 2018-13 is effective for us beginning January 1, 2020. The amendments in ASU 2018-13 that relate to changes in unrealized gains and losses, the range and weighted average of significant unobservable inputs used to develop Level 3 fair value measurements and the narrative description of measurement uncertainty should be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. All other amendments in ASU 2018-13 should be applied retrospectively to all periods presented upon their effective date. Early adoption is permitted upon issuance of ASU 2018-13. An entity is permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until their effective date. We are currently assessing the impact the new guidance will have on our disclosures.

[0001262039-19-000023:notes:21]
[same as prior period, unchanged from 0001262039-19-000014:notes:22]

[0001262039-19-000023:notes:22]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and in November 2018, the FASB issued ASU 2018-19—Codification Improvements to Topic 326, Financial Instruments—Credit Losses, as a subsequent amendment to the initial guidance (collectively, Topic 326). In April 2019, the FASB issued ASU 2019-04—Codification Improvements to Topic 326: Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, and in May 2019, the FASB issued ASU 2019-05—Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief. Topic 326 requires a financial asset (or a group of financial assets) measured at an amortized cost basis to be presented at the net amount expected to be collected. The new approach to estimating credit losses (referred to as the current expected credit losses model) generally accelerates recognition of credit losses. We are in the process of determining the changes needed to our valuation model for trade receivables, and we are reviewing our process to identify credit-related losses on available-for-sale investments. We also expect the new guidance to expand our related financial statement disclosures. The new guidance is effective for us beginning on January 1, 2020, and early adoption is permitted. We are currently assessing the impact of the new guidance on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-19-000023:notes:23]
[same as prior period, unchanged from 0001262039-19-000014:notes:24]

[0001262039-19-000023:notes:24]
Our revenue consists of product and service revenue. Product revenue is generated by sales of our FortiGate products and other hardware and software solutions. Service revenue relates to sales of our FortiGuard security subscription, FortiCare technical support services and other services.

[0001262039-19-000023:notes:25]
[same as prior period, unchanged from 0001262039-19-000014:notes:26]

[0001262039-19-000023:notes:26]
[same as prior period, unchanged from 0001262039-19-000014:notes:27]

[0001262039-19-000023:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 183.1 |  |  | 147.1 |  |  | 352.7 |  |  | 283.8 |  |
| Technical support and other | 148.7 |  |  | 127.9 |  |  | 289.0 |  |  | 247.4 |  |
| Total service revenue | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |

[0001262039-19-000023:notes:28]
[same as prior period, unchanged from 0001262039-19-000014:notes:35]

[0001262039-19-000023:notes:29]
During the three months ended June 30, 2019 and June 30, 2018, we recognized $252.0 million and $203.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively. During the six months ended June 30, 2019 and June 30, 2018, we recognized $540.6 million and $442.3 million in revenue that was included in the deferred revenue balance as of December 31, 2018 and December 31, 2017, respectively.

[0001262039-19-000023:notes:30]
[same as prior period, unchanged from 0001262039-19-000014:notes:29]

[0001262039-19-000023:notes:31]
As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was $1.87 billion, which was substantially comprised of deferred security subscription and technical support services. We expect to recognize approximately $1.03 billion into revenue over the next 12 months and the remainder thereafter.

[0001262039-19-000023:notes:32]
[same as prior period, unchanged from 0001262039-19-000014:notes:31]

[0001262039-19-000023:notes:33]
Trade accounts receivable are recorded at the invoiced amount. Trade accounts receivable is reduced by an allowance for doubtful accounts which is determined based on our assessment of the collectability of customer accounts. The allowance for doubtful accounts was $0.8 million and $0.9 million as of June 30, 2019 and December 31, 2018, respectively.

[0001262039-19-000023:notes:34]
[same as prior period, unchanged from 0001262039-19-000014:notes:33]

[0001262039-19-000023:notes:35]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. The amortization of deferred contract costs is included in sales and marketing expense in our condensed consolidated statements of income. Amortization of deferred contract costs during the three months ended June 30, 2019 and June 30, 2018 were $25.9 million and $22.4 million, respectively.  Amortization of deferred contract costs during the six months ended June 30, 2019 and June 30, 2018 were $51.0 million and $43.2 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-19-000023:notes:36]
[same as prior period, unchanged from 0001262039-19-000014:notes:37]

[0001262039-19-000023:notes:37]
[same as prior period, unchanged from 0001262039-19-000014:notes:38]

[0001262039-19-000023:notes:38]
|  | June 30, 2019 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 516.9 |  |  | $ | 1.0 |  |  | $ | (0.2 | ) |  | $ | 517.7 |  |
| Commercial paper | 204.2 |  |  | 0.1 |  |  | — |  |  | 204.3 |  |
| U.S. government and agency securities | 147.1 |  |  | 0.3 |  |  | — |  |  | 147.4 |  |
| Certificates of deposit and term deposits (1) | 88.2 |  |  | — |  |  | — |  |  | 88.2 |  |
| Total available-for-sale securities | $ | 956.4 |  |  | $ | 1.4 |  |  | $ | (0.2 | ) |  | $ | 957.6 |  |
|  | December 31, 2018 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 299.5 |  |  | $ | — |  |  | $ | (1.2 | ) |  | $ | 298.3 |  |
| Commercial paper | 102.5 |  |  | — |  |  | — |  |  | 102.5 |  |
| Certificates of deposit and term deposits (1) | 145.8 |  |  | — |  |  | — |  |  | 145.8 |  |
| U.S. government and agency securities | 57.7 |  |  | — |  |  | (0.1 | ) |  | 57.6 |  |
| Total available-for-sale securities | $ | 605.5 |  |  | $ | — |  |  | $ | (1.3 | ) |  | $ | 604.2 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-19-000023:notes:39]
[same as prior period, unchanged from 0001262039-19-000014:notes:40]

[0001262039-19-000023:notes:40]
|  | June 30, 2019 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 57.0 |  |  | $ | — |  |  | $ | 61.3 |  |  | $ | (0.2 | ) |  | $ | 118.3 |  |  | $ | (0.2 | ) |

[0001262039-19-000023:notes:41]
[same as prior period, unchanged from 0001262039-19-000014:notes:42]

[0001262039-19-000023:notes:42]
[same as prior period, unchanged from 0001262039-19-000014:notes:43]

[0001262039-19-000023:notes:43]
|  | June 30, 2019 |  | December 31, 2018 |
| Due within one year | $ | 808.1 |  |  | $ | 537.2 |  |
| Due within one to three years | 149.5 |  |  | 67.0 |  |
| Total | $ | 957.6 |  |  | $ | 604.2 |  |

[0001262039-19-000023:notes:44]
[same as prior period, unchanged from 0001262039-19-000014:notes:45]

[0001262039-19-000023:notes:45]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of June 30, 2019.

[0001262039-19-000023:notes:46]
[same as prior period, unchanged from 0001262039-19-000014:notes:47]

[0001262039-19-000023:notes:47]
[same as prior period, unchanged from 0001262039-19-000014:notes:48]

[0001262039-19-000023:notes:48]
[same as prior period, unchanged from 0001262039-19-000014:notes:49]

[0001262039-19-000023:notes:49]
[same as prior period, unchanged from 0001262039-19-000014:notes:50]

[0001262039-19-000023:notes:50]
[same as prior period, unchanged from 0001262039-19-000014:notes:51]

[0001262039-19-000023:notes:51]
[same as prior period, unchanged from 0001262039-19-000014:notes:52]

[0001262039-19-000023:notes:52]
[same as prior period, unchanged from 0001262039-19-000014:notes:53]

[0001262039-19-000023:notes:53]
[same as prior period, unchanged from 0001262039-19-000014:notes:54]

[0001262039-19-000023:notes:54]
[same as prior period, unchanged from 0001262039-19-000014:notes:55]

[0001262039-19-000023:notes:55]
The following tables present the fair value of our financial assets measured at fair value on a recurring basis as of June 30, 2019 and December 31, 2018 (in millions):

[0001262039-19-000023:notes:56]
|  | June 30, 2019 |  | December 31, 2018 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 520.6 |  |  | $ | — |  |  | $ | 520.6 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |  | $ | 299.3 |  |  | $ | — |  |
| Commercial paper | 221.3 |  |  | — |  |  | 221.3 |  |  | — |  |  | 184.7 |  |  | — |  |  | 184.7 |  |  | — |  |
| Certificates of deposit and term deposits | 89.7 |  |  | — |  |  | 89.7 |  |  | — |  |  | 217.4 |  |  | — |  |  | 217.4 |  |  | — |  |
| U.S. government and agency securities | 152.4 |  |  | 142.9 |  |  | 9.5 |  |  | — |  |  | 57.6 |  |  | 45.3 |  |  | 12.3 |  |  | — |  |
| Money market funds | 23.5 |  |  | 23.5 |  |  | — |  |  | — |  |  | 58.6 |  |  | 58.6 |  |  | — |  |  | — |  |
| Total | $ | 1,007.5 |  |  | $ | 166.4 |  |  | $ | 841.1 |  |  | $ | — |  |  | $ | 817.6 |  |  | $ | 103.9 |  |  | $ | 713.7 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 49.9 |  |  |  |  |  |  |  |  | $ | 213.4 |  |  |  |  |  |  |  |
| Short-term investments | 808.1 |  |  |  |  |  |  |  |  | 537.2 |  |  |  |  |  |  |  |
| Long-term investments | 149.5 |  |  |  |  |  |  |  |  | 67.0 |  |  |  |  |  |  |  |
| Total | $ | 1,007.5 |  |  |  |  |  |  |  |  | $ | 817.6 |  |  |  |  |  |  |  |

[0001262039-19-000023:notes:57]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2019 and year ended December 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-19-000023:notes:58]
[same as prior period, unchanged from 0001262039-19-000014:notes:59]

[0001262039-19-000023:notes:59]
[same as prior period, unchanged from 0001262039-19-000014:notes:60]

[0001262039-19-000023:notes:60]
|  | June 30, 2019 |  | December 31, 2018 |
| Raw materials | $ | 8.8 |  |  | $ | 13.3 |  |
| Finished goods | 76.9 |  |  | 76.7 |  |
| Inventory | $ | 85.7 |  |  | $ | 90.0 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-19-000023:notes:61]
[same as prior period, unchanged from 0001262039-19-000014:notes:62]

[0001262039-19-000023:notes:62]
[same as prior period, unchanged from 0001262039-19-000014:notes:63]

[0001262039-19-000023:notes:63]
|  | June 30, 2019 |  | December 31, 2018 |
| Land | $ | 75.7 |  |  | $ | 75.7 |  |
| Building and building improvements | 142.5 |  |  | 144.2 |  |
| Computer equipment and software | 103.6 |  |  | 95.9 |  |
| Leasehold improvements | 19.5 |  |  | 17.9 |  |
| Evaluation units | 19.9 |  |  | 20.5 |  |
| Furniture and fixtures | 16.3 |  |  | 15.7 |  |
| Construction-in-progress | 28.7 |  |  | 12.3 |  |
| Total property and equipment | 406.2 |  |  | 382.2 |  |
| Less: accumulated depreciation | (121.5 | ) |  | (110.8 | ) |
| Property and equipment—net | $ | 284.7 |  |  | $ | 271.4 |  |

[0001262039-19-000023:notes:64]
Depreciation expense was $12.3 million and $11.8 million during the three months ended June 30, 2019 and June 30, 2018, respectively. Depreciation expense was $25.0 million and $23.1 million during the six months ended June 30, 2019 and June 30, 2018, respectively.


## invest:InvestmentTextBlock

[0001262039-19-000023:notes:65]
[same as prior period, unchanged from 0001262039-19-000014:notes:66]

[0001262039-19-000023:notes:66]
Our investments in the equity securities of privately held companies totaled $9.1 million as of June 30, 2019 and December 31, 2018. These investments are accounted for at cost, adjusted for changes in observable prices minus impairment. We own less than 20% of the voting securities in each of these investments and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are recorded as other assets in our condensed consolidated balance sheets and would be measured at fair value if indicators of an increase in value or impairment existed. As of June 30, 2019, no events have occurred that would affect the carrying value of these investments.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-19-000023:notes:67]
[same as prior period, unchanged from 0001262039-19-000014:notes:68]

[0001262039-19-000023:notes:68]
[same as prior period, unchanged from 0001262039-19-000014:notes:69]

[0001262039-19-000023:notes:69]
On October 22, 2018, we acquired all outstanding shares of ZoneFox Holdings Limited (“ZoneFox”), a privately held cloud-based company providing insider threat detection and response. ZoneFox is headquartered in Edinburgh, Scotland.

[0001262039-19-000023:notes:70]
[same as prior period, unchanged from 0001262039-19-000014:notes:71]

[0001262039-19-000023:notes:71]
We may pay an additional $2.0 million in cash consideration as an earn-out that is subject in full to satisfaction of certain performance conditions. As of June 30, 2019, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the performance conditions.

[0001262039-19-000023:notes:72]
[same as prior period, unchanged from 0001262039-19-000014:notes:73]

[0001262039-19-000023:notes:73]
On June 4, 2018, we acquired all outstanding shares of Bradford Networks, Inc. (“Bradford”), a provider of network access control security products and services.

[0001262039-19-000023:notes:74]
[same as prior period, unchanged from 0001262039-19-000014:notes:75]

[0001262039-19-000023:notes:75]
The acquisition included a $2.0 million cash earn-out that was subject in full to satisfaction of certain performance conditions. The performance conditions were not met and the cash earn-out will not be paid.

[0001262039-19-000023:notes:76]
[same as prior period, unchanged from 0001262039-19-000014:notes:77]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-19-000023:notes:77]
[same as prior period, unchanged from 0001262039-19-000014:notes:78]

[0001262039-19-000023:notes:78]
[same as prior period, unchanged from 0001262039-19-000014:notes:79]

[0001262039-19-000023:notes:79]
As of June 30, 2019 and December 31, 2018, we had goodwill of $38.2 million. There were no impairments to goodwill during the six months ended June 30, 2019 or during prior periods.

[0001262039-19-000023:notes:80]
Other Intangible Assets—Net

[0001262039-19-000023:notes:81]
The following tables present other intangible assets—net as of June 30, 2019 and December 31, 2018 (in millions, except years):

[0001262039-19-000023:notes:82]
|  | June 30, 2019 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 34.4 |  |  | $ | 21.1 |  |  | $ | 13.3 |  |
| Customer relationships | 4.4 |  | 17.5 |  |  | 14.6 |  |  | 2.9 |  |
| Total other intangible assets—net |  |  | $ | 51.9 |  |  | $ | 35.7 |  |  | $ | 16.2 |  |

[0001262039-19-000023:notes:83]
[same as prior period, unchanged from 0001262039-19-000014:notes:84]

[0001262039-19-000023:notes:84]
Amortization expense was $2.9 million and $1.8 million during the three months ended June 30, 2019 and June 30, 2018, respectively. Amortization expense was $5.9 million and $3.6 million during the six months ended June 30, 2019 and June 30, 2018, respectively.

[0001262039-19-000023:notes:85]
[same as prior period, unchanged from 0001262039-19-000014:notes:86]

[0001262039-19-000023:notes:86]
|  | Amount |
| Years: |  |
| 2019 (the remainder of 2019) | $ | 4.4 |  |
| 2020 | 6.2 |  |
| 2021 | 3.5 |  |
| 2022 | 2.1 |  |
| Total | $ | 16.2 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-19-000023:notes:87]
[same as prior period, unchanged from 0001262039-19-000014:notes:88]

[0001262039-19-000023:notes:88]
[same as prior period, unchanged from 0001262039-19-000014:notes:89]

[0001262039-19-000023:notes:89]
[same as prior period, unchanged from 0001262039-19-000014:notes:90]

[0001262039-19-000023:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 72.7 |  |  | $ | 49.3 |  |  | $ | 131.5 |  |  | $ | 90.9 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.1 |  |  | 168.6 |  |  | 170.6 |  |  | 168.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 171.1 |  |  | 168.6 |  |  | 170.6 |  |  | 168.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.9 |  |  | 3.4 |  |  | 3.2 |  |  | 3.1 |  |
| Stock options | 1.1 |  |  | 1.4 |  |  | 1.2 |  |  | 1.3 |  |
| ESPP | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Weighted-average shares used to compute diluted net income per share | 175.1 |  |  | 173.5 |  |  | 175.0 |  |  | 172.6 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.42 |  |  | $ | 0.29 |  |  | $ | 0.77 |  |  | $ | 0.54 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.28 |  |  | $ | 0.75 |  |  | $ | 0.53 |  |

[0001262039-19-000023:notes:91]
[same as prior period, unchanged from 0001262039-19-000014:notes:92]

[0001262039-19-000023:notes:92]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| RSUs | 0.1 |  |  | 0.3 |  |  | 0.4 |  |  | 0.7 |  |
| Stock options | 0.7 |  |  | 0.7 |  |  | 0.5 |  |  | 0.6 |  |
| ESPP | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Total | 0.8 |  |  | 1.0 |  |  | 0.9 |  |  | 1.4 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-19-000023:notes:93]
[same as prior period, unchanged from 0001262039-19-000014:notes:94]

[0001262039-19-000023:notes:94]
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately seven years, some of which include one or more options to renew, with renewal terms of up to five years. We do not include any of our renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility and we are not reasonably certain we will exercise these renewal options at the time of the lease commencement. Our finance leases are not material to our financial statements.

[0001262039-19-000023:notes:95]
[same as prior period, unchanged from 0001262039-19-000014:notes:96]

[0001262039-19-000023:notes:96]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2019 |
| Operating lease expense | $ | 3.7 |  |  | $ | 7.3 |  |
| Variable lease expense (1) | 0.6 |  |  | 1.2 |  |
| Short-term lease expense | 0.7 |  |  | 1.4 |  |
| Total lease expense | $ | 5.0 |  |  | $ | 9.9 |  |

[0001262039-19-000023:notes:97]
(1) Variable lease expense for the three and six months ended June 30, 2019 predominantly included common area maintenance charges and parking expense.

[0001262039-19-000023:notes:98]
Rent expense was $4.6 million and $8.7 million during the three and six months ended June 30, 2018, respectively. Rent expense was recognized in accordance with ASC 840, Leases, using the straight-line method over the term of a lease.

[0001262039-19-000023:notes:99]
[same as prior period, unchanged from 0001262039-19-000014:notes:100]

[0001262039-19-000023:notes:100]
|  | Classification | June 30, 2019 |
| Operating lease ROU assets - non-current | Other assets | $ | 37.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 11.7 |  |
| Operating lease liabilities - non-current | Other liabilities | 25.8 |  |
| Total operating lease liabilities |  | $ | 37.5 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.9 |  |
| Weighted average discount rate - operating leases |  | 3.1 | % |

[0001262039-19-000023:notes:101]
[same as prior period, unchanged from 0001262039-19-000014:notes:102]

[0001262039-19-000023:notes:102]
|  | Six Months Ended |
|  | June 30, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows used for operating leases | $ | 8.5 |  |
| Lease liabilities arising from obtaining right-of-use assets |  |
| Operating leases | $ | 4.9 |  |

[0001262039-19-000023:notes:103]
Maturities of operating lease liabilities as of June 30, 2019 were as follows (in millions):

[0001262039-19-000023:notes:104]
| Year ending December 31, | Amount |
| 2019 (the remainder of 2019) | $ | 6.1 |  |
| 2020 | 12.2 |  |
| 2021 | 8.8 |  |
| 2022 | 5.3 |  |
| 2023 | 3.7 |  |
| Thereafter | 3.8 |  |
| Total lease payments | $ | 39.9 |  |
| Less imputed interest | (2.4 | ) |
| Total | $ | 37.5 |  |

[0001262039-19-000023:notes:105]
As of June 30, 2019, we had additional minimum lease payments of $2.4 million relating to operating leases that had been signed but had not yet commenced and therefore were excluded from the table above. These leases will commence during 2019 and will have lease terms of approximately two to five years.

[0001262039-19-000023:notes:106]
[same as prior period, unchanged from 0001262039-19-000014:notes:107]

[0001262039-19-000023:notes:107]
[same as prior period, unchanged from 0001262039-19-000014:notes:108]

[0001262039-19-000023:notes:108]
Total future principal contractual obligations for operating lease commitments as of December 31, 2018 exceeded our undiscounted lease liability as of the Topic 842 adoption date, primarily because the lease liability excluded short-term lease payments due to the adoption of the short-term lease exemption and excluded minimum lease payments relating to an operating lease that had been signed but had not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-19-000023:notes:109]
COMMITMENTS AND CONTINGENCIES

[0001262039-19-000023:notes:110]
The following table summarizes our future principal contractual obligations as of June 30, 2019 (in millions):

[0001262039-19-000023:notes:111]
|  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Inventory purchase commitments | $ | 218.9 |  |  | $ | 208.1 |  |  | $ | 10.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-19-000023:notes:112]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of June 30, 2019, we had $218.9 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-19-000023:notes:113]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2019, we had $22.8 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-19-000023:notes:114]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss.

[0001262039-19-000023:notes:115]
Indemnification and other matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement, that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, there have been no material awards under such indemnification provisions.

[0001262039-19-000023:notes:116]
Periodically we, like other security companies and companies in other industries, may experience cybersecurity threats, threats to our information technology infrastructure and unauthorized attempts to gain access to our and our customers’ sensitive information and systems. For example, in the second quarter of 2019, we discovered that an unauthorized party illegally targeted us using sophisticated techniques, such as stealing technical data in order to both impersonate our firewall update servers and possibly attempt other attack methodologies, in an effort to try to gain access to certain of our customers’ systems. We are in the process of investigating and evaluating this matter, and, although at this time there can be no assurances as to the outcome and impact of this matter, which are currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings related to this matter, including any that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with these types of incidents and possible impacts associated with a cybersecurity attack or other events may include remediation costs related to lost, stolen or compromised

[0001262039-19-000023:notes:117]
data, repairs to data processing systems, increased cybersecurity protection costs, adverse effects on our compliance with laws and regulations, litigation and reputational damage.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-19-000023:notes:118]
[same as prior period, unchanged from 0001262039-19-000014:notes:118]

[0001262039-19-000023:notes:119]
[same as prior period, unchanged from 0001262039-19-000014:notes:119]

[0001262039-19-000023:notes:120]
We have stock-based compensation plans pursuant to which we have granted RSUs and stock options. We also previously had an ESPP for eligible employees, which was terminated in February 2019.

[0001262039-19-000023:notes:121]
On June 21, 2019, our stockholders approved the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”). Among other things, the Amended Plan provided for a net decrease in the number of shares of common stock that were authorized and available for issuance pursuant to future awards granted on or following the effective date of the Amended Plan. On June 28, 2019, we deregistered from various registration statements on Form S-8 an aggregate of 46.2 million shares of common stock that were originally registered for issuance under our 2009 Equity Incentive Plan.

[0001262039-19-000023:notes:122]
As of June 30, 2019, there was a total of 13.5 million shares of common stock available for grant under the Amended Plan.

[0001262039-19-000023:notes:123]
[same as prior period, unchanged from 0001262039-19-000014:notes:121]

[0001262039-19-000023:notes:124]
[same as prior period, unchanged from 0001262039-19-000014:notes:122]

[0001262039-19-000023:notes:125]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2018 | 7.8 |  |  | $ | 46.07 |  |
| Granted | 1.8 |  |  | 84.44 |  |
| Forfeited | (0.3 | ) |  | 51.38 |  |
| Vested | (2.1 | ) |  | 42.40 |  |
| Balance—June 30, 2019 | 7.2 |  |  | $ | 56.68 |  |

[0001262039-19-000023:notes:126]
As of June 30, 2019, total compensation expense related to unvested RSUs granted to employees and non-employees under the 2009 Plan, but not yet recognized, was $360.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.9 years.

[0001262039-19-000023:notes:127]
[same as prior period, unchanged from 0001262039-19-000014:notes:125]

[0001262039-19-000023:notes:128]
[same as prior period, unchanged from 0001262039-19-000014:notes:126]

[0001262039-19-000023:notes:129]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Shares withheld for taxes | 0.3 |  |  | 0.3 |  |  | 0.7 |  |  | 0.7 |  |
| Amount withheld for taxes | $ | 24.5 |  |  | $ | 13.3 |  |  | $ | 56.5 |  |  | $ | 32.5 |  |

[0001262039-19-000023:notes:130]
[same as prior period, unchanged from 0001262039-19-000014:notes:128]

[0001262039-19-000023:notes:131]
[same as prior period, unchanged from 0001262039-19-000014:notes:129]

[0001262039-19-000023:notes:132]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Expected term in years | 4.4 |  |  | 4.4 |  |  | 4.4 |  |  | 4.4 |  |
| Volatility | 34.4 | % |  | 31.1 | % |  | 34.2 | % |  | 31.7 | % |
| Risk-free interest rate | 2.2 | % |  | 2.9 | % |  | 2.5 | % |  | 2.6 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-19-000023:notes:133]
[same as prior period, unchanged from 0001262039-19-000014:notes:131]

[0001262039-19-000023:notes:134]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2018 | 3.0 |  |  | $ | 35.53 |  |  |  |  |  |  |
| Granted | 0.7 |  |  | 84.42 |  |  |  |  |  |
| Forfeited | (0.1 | ) |  | 57.20 |  |  |  |  |  |
| Exercised | (0.7 | ) |  | 28.89 |  |  |  |  |  |
| Balance—June 30, 2019 | 2.9 |  |  | $ | 47.94 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2019 | 2.9 |  |  | $ | 47.94 |  |  | 4.8 |  | $ | 89.9 |  |
| Options exercisable—June 30, 2019 | 1.4 |  |  | $ | 33.05 |  |  | 3.7 |  | $ | 59.5 |  |

[0001262039-19-000023:notes:135]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2019 for all in-the-money stock options. As of June 30, 2019, total compensation expense related to unvested stock options granted to employees but not yet recognized was $28.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.0 years.

[0001262039-19-000023:notes:136]
[same as prior period, unchanged from 0001262039-19-000014:notes:134]

[0001262039-19-000023:notes:137]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Weighted-average fair value per share granted | $ | 26.38 |  |  | $ | 17.86 |  |  | $ | 27.08 |  |  | $ | 15.21 |  |
| Intrinsic value of options exercised | 9.6 |  |  | 15.9 |  |  | 36.8 |  |  | 39.5 |  |
| Fair value of options vested | 2.0 |  |  | 1.5 |  |  | 6.2 |  |  | 4.2 |  |

[0001262039-19-000023:notes:138]
[same as prior period, unchanged from 0001262039-19-000014:notes:136]

[0001262039-19-000023:notes:139]
[same as prior period, unchanged from 0001262039-19-000014:notes:137]

[0001262039-19-000023:notes:140]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Cost of product revenue | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 0.8 |  |
| Cost of service revenue | 2.9 |  |  | 2.7 |  |  | 5.7 |  |  | 5.2 |  |
| Research and development | 10.0 |  |  | 9.2 |  |  | 19.4 |  |  | 17.6 |  |
| Sales and marketing | 26.3 |  |  | 23.6 |  |  | 51.7 |  |  | 44.5 |  |
| General and administrative | 5.4 |  |  | 4.7 |  |  | 10.4 |  |  | 9.0 |  |
| Total stock-based compensation expense | $ | 45.0 |  |  | $ | 40.6 |  |  | $ | 88.0 |  |  | $ | 77.1 |  |

[0001262039-19-000023:notes:141]
[same as prior period, unchanged from 0001262039-19-000014:notes:139]

[0001262039-19-000023:notes:142]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| RSUs | $ | 41.9 |  |  | $ | 35.9 |  |  | $ | 81.1 |  |  | $ | 67.9 |  |
| Stock options | 3.1 |  |  | 2.3 |  |  | 5.6 |  |  | 4.3 |  |
| ESPP | — |  |  | 2.4 |  |  | 1.3 |  |  | 4.9 |  |
| Total stock-based compensation expense | $ | 45.0 |  |  | $ | 40.6 |  |  | $ | 88.0 |  |  | $ | 77.1 |  |

[0001262039-19-000023:notes:143]
[same as prior period, unchanged from 0001262039-19-000014:notes:141]

[0001262039-19-000023:notes:144]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 10.4 |  |  | $ | 6.1 |  |  | $ | 20.4 |  |  | $ | 12.1 |  |

[0001262039-19-000023:notes:145]
[same as prior period, unchanged from 0001262039-19-000014:notes:143]

[0001262039-19-000023:notes:146]
[same as prior period, unchanged from 0001262039-19-000014:notes:144]

[0001262039-19-000023:notes:147]
During the three and six months ended June 30, 2019, we repurchased 0.5 million and 1.3 million shares of common stock, respectively, under the Repurchase Program in open market transactions at an average price of $73.48 per share and $72.68 per share, respectively, for an aggregate purchase price of $34.8 million and $91.1 million, respectively. As of June 30, 2019, $642.7 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-19-000023:notes:148]
[same as prior period, unchanged from 0001262039-19-000014:notes:146]

[0001262039-19-000023:notes:149]
Our effective tax rate was 15% for the three months ended June 30, 2019, compared to an effective tax rate of 4% for the same period last year. Our effective tax rate was 10% for the six months ended June 30, 2019, compared to an effective tax rate benefit of 3% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended June 30, 2019 and June 30, 2018 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $24.5 million and $17.2 million, respectively, which were offset by excess tax benefits

[0001262039-19-000023:notes:150]
from stock-based compensation expense of $11.7 million and $4.9 million, respectively. The tax rate for the three months ended June 30, 2019 was impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Court of Appeals for the Ninth Circuit’s opinion on Altera Corporation and Subsidiaries vs. Commissioner of Internal Revenue (“Altera”) described below regarding stock-based compensation expense in cost sharing arrangements. This expense was offset by release of reserves of $10.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax rate for the three months ended June 30, 2018 was also impacted by release of a reserve on uncertain tax position including interest of $10.1 million.

[0001262039-19-000023:notes:151]
The tax rates for the six months ended June 30, 2019 and June 30, 2018 were impacted by U.S. federal and state taxes, withholding taxes and foreign taxes of $42.0 million and $25.7 million, respectively, which were offset by excess tax benefits from stock-based compensation expense of $27.7 million and $10.5 million, respectively. The tax rate for the six months ended June 30, 2019 was impacted by an increase in tax expense of $10.3 million for an unrecognized tax benefit related to the Ninth Circuit’s Altera decision described below, regarding stock-based compensation expense in cost sharing arrangements. This expense was offset by release of reserves of $10.0 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax rate for the six months ended June 30, 2018 was also impacted by release of a reserve on uncertain tax position including interest of $18.0 million.

[0001262039-19-000023:notes:152]
As of June 30, 2019 and December 31, 2018, unrecognized tax benefits were $67.8 million and $63.5 million, respectively. If recognized, an amount of $62.9 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to uncertain tax benefits in income tax expense. As of June 30, 2019 and December 31, 2018, accrued interest and penalties were $12.8 million and $11.6 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $9.0 million in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-19-000023:notes:153]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-19-000023:notes:154]
On June 7, 2019, the Ninth Circuit overturned the U.S. Tax Court’s decision on Altera and ruled in favor of the Commissioner, validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement. Due to the uncertainty surrounding the status of the current regulations and questions related to the scope of potential benefits or obligations, we increased an unrecognized tax benefit of $10.3 million related to the Ninth Circuit’s Altera decision regarding stock-based compensation in cost sharing arrangements. We continue to monitor developments in this case and any impact it could have on our tax provision.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-19-000023:notes:155]
[same as prior period, unchanged from 0001262039-19-000014:notes:151]

[0001262039-19-000023:notes:156]
Our tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2019 and June 30, 2018 were $1.7 million and $1.5 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2019 and June 30, 2018 were $3.4 million and $3.0 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-19-000023:notes:157]
[same as prior period, unchanged from 0001262039-19-000014:notes:153]

[0001262039-19-000023:notes:158]
[same as prior period, unchanged from 0001262039-19-000014:notes:154]

[0001262039-19-000023:notes:159]
[same as prior period, unchanged from 0001262039-19-000014:notes:155]

[0001262039-19-000023:notes:160]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 173.5 |  |  | $ | 144.6 |  |  | $ | 323.8 |  |  | $ | 278.5 |  |
| Other Americas (1) | 52.0 |  |  | 44.7 |  |  | 102.2 |  |  | 86.6 |  |
| Total Americas | 225.5 |  |  | 189.3 |  |  | 426.0 |  |  | 365.1 |  |
| Europe, Middle East and Africa (“EMEA”) | 192.0 |  |  | 164.4 |  |  | 369.2 |  |  | 308.9 |  |
| Asia Pacific (“APAC”) | 104.2 |  |  | 87.6 |  |  | 199.1 |  |  | 166.3 |  |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |  | $ | 994.3 |  |  | $ | 840.3 |  |
| (1) In 2019, Canada and Latin America revenue were combined and presented as Other Americas. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000023:notes:161]
| Property and Equipment—net | June 30, 2019 |  | December 31, 2018 |
| Americas: |  |  |  |
| United States | $ | 148.3 |  |  | $ | 132.1 |  |
| Canada | 112.1 |  |  | 113.5 |  |
| Latin America | 0.2 |  |  | 0.4 |  |
| Total Americas | 260.6 |  |  | 246.0 |  |
| EMEA (1) | 15.4 |  |  | 16.2 |  |
| APAC | 8.7 |  |  | 9.2 |  |
| Total property and equipment—net | $ | 284.7 |  |  | $ | 271.4 |  |
| (1) In 2019, France and Other EMEA property and equipment were combined and presented as EMEA. Prior periods have been reclassified to conform with current period presentation. |

[0001262039-19-000023:notes:162]
[same as prior period, unchanged from 0001262039-19-000014:notes:158]

[0001262039-19-000023:notes:163]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Exclusive Networks Group | 31 | % |  | 29 | % |  | 31 | % |  | 29 | % |
| Ingram Micro | 11 | % |  | 10 | % |  | 11 | % |  | * |  |
| * Represents less than 10% |  |  |  |  |

[0001262039-19-000023:notes:164]
[same as prior period, unchanged from 0001262039-19-000014:notes:160]

[0001262039-19-000023:notes:165]
|  | June 30, 2019 |  | December 31, 2018 |
| Exclusive Networks Group | 35 | % |  | 38 | % |
| Ingram Micro | 11 | % |  | * |  |
| * Represents less than 10% |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-19-000023:notes:166]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001262039-19-000023:notes:167]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) (in millions):

[0001262039-19-000023:notes:168]
|  | Unrealized Gains (Losses) on Investments |  | Tax provision (benefit) related to unrealized gains or losses on investments |  | Total |
| Balance—December 31, 2018 | $ | (1.3 | ) |  | $ | (0.5 | ) |  | $ | (0.8 | ) |
| Other comprehensive income before reclassifications | 2.5 |  |  | 0.7 |  |  | 1.8 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 0.1 |  |  | (0.1 | ) |
| Net current-period other comprehensive income | 2.5 |  |  | 0.8 |  |  | 1.7 |  |
| Balance—June 30, 2019 | $ | 1.2 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |

[0001262039-19-000023:notes:169]
We adopted ASU 2018-02 on January 1, 2019, and elected to reclassify the income tax effects of the 2017 Tax Act to retained earnings at the beginning of the period. Other amounts reclassified from accumulated other comprehensive loss for unrealized losses on investments and tax provision related to unrealized gains or losses on investments are recorded in other expense—net and in provision for (benefit from) income taxes, respectively.
