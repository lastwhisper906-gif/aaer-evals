# FTNT 8-K — 0001262039-19-000021 filed 2019-08-01

## item codes, every 8-K on or before 2019-08-01

- 2019-08-01 0001262039-19-000021 — 2.02, 9.01
- 2019-06-26 0001262039-19-000018 — 5.07
- 2019-05-02 0001262039-19-000010 — 2.02, 9.01
- 2019-02-06 0001262039-19-000002 — 2.02, 9.01
- 2018-11-01 0001262039-18-000037 — 2.02, 9.01
- 2018-10-23 0001262039-18-000035 — 8.01
- 2018-08-01 0001262039-18-000025 — 2.02, 9.01
- 2018-06-28 0001262039-18-000023 — 5.03, 5.07, 9.01
- 2018-06-04 0001262039-18-000021 — 8.01
- 2018-05-03 0001262039-18-000017 — 2.02, 5.02, 9.01
- 2018-02-05 0001262039-18-000004 — 2.02, 5.02, 9.01
- 2017-10-26 0001262039-17-000031 — 2.02, 9.01
- 2017-10-19 0001262039-17-000029 — 5.02 — amendment, the index does not say of what
- 2017-07-26 0001262039-17-000025 — 2.02, 9.01
- 2017-06-27 0001262039-17-000023 — 5.07
- 2017-05-31 0001262039-17-000021 — 5.02 — amendment of 0001262039-17-000019
- 2017-05-30 0001262039-17-000019 — 5.02, 9.01
- 2017-04-27 0001262039-17-000013 — 2.02, 9.01
- 2017-02-02 0001262039-17-000003 — 2.02, 9.01
- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2019-08-01

- none on or before 2019-08-01

## item 2.02 — earnings release, exhibit 99.1

[0001262039-19-000021:8k_2_02:1]
EX-99.1
2
ftntq2-2019ex991.htm
PRESS RELEASE

[0001262039-19-000021:8k_2_02:2]
Exhibit

[0001262039-19-000021:8k_2_02:3]
Press Release

[0001262039-19-000021:8k_2_02:4]
Fortinet Reports Second Quarter 2019 Financial Results

[0001262039-19-000021:8k_2_02:5]
Second Quarter 2019 Highlights

[0001262039-19-000021:8k_2_02:6]
| • | Revenue of $521.7 million, up 18% year over year |

[0001262039-19-000021:8k_2_02:7]
| • | Billings of $622.4 million, up 21% year over year1 |

[0001262039-19-000021:8k_2_02:8]
| • | Deferred revenue of $1.87 billion, up 27% year over year |

[0001262039-19-000021:8k_2_02:9]
| • | GAAP operating margin of 14% |

[0001262039-19-000021:8k_2_02:10]
| • | Non-GAAP operating margin of 24%1 |

[0001262039-19-000021:8k_2_02:11]
| • | GAAP diluted net income per share of $0.42 |

[0001262039-19-000021:8k_2_02:12]
| • | Non-GAAP diluted net income per share of $0.581 |

[0001262039-19-000021:8k_2_02:13]
| • | Cash flow from operations of $195.1 million |

[0001262039-19-000021:8k_2_02:14]
| • | Free cash flow of $177.8 million1 |

[0001262039-19-000021:8k_2_02:15]
SUNNYVALE, Calif. - August 1, 2019 - Fortinet® (Nasdaq: FTNT), a global leader in broad, integrated and automated cybersecurity solutions, today announced financial results for the second quarter ended June 30, 2019.

[0001262039-19-000021:8k_2_02:16]
“Our strong performance in the United States contributed to second quarter billings growth that outpaced our competitors. Our Fortinet Security Fabric, SD-WAN and cloud offerings contributed to our 21% year-over-year billings growth,” said Ken Xie, Founder, Chairman and Chief Executive Officer. “We expect 2019 to be another year of better-than-industry growth, driven by our advanced security processing technology, new products and services offerings, and new market opportunities.”

[0001262039-19-000021:8k_2_02:17]
Financial Highlights for the Second Quarter of 2019

[0001262039-19-000021:8k_2_02:18]
| • | Revenue: Total revenue was $521.7 million for the second quarter of 2019, an increase of 18% compared to $441.3 million for the same quarter of 2018. |

[0001262039-19-000021:8k_2_02:19]
| • | Product revenue was $189.9 million for the second quarter of 2019, an increase of 14% compared to $166.3 million for the same quarter of 2018. |

[0001262039-19-000021:8k_2_02:20]
| • | Service revenue was $331.8 million for the second quarter of 2019, an increase of 21% compared to $275.0 million for the same quarter of 2018. |

[0001262039-19-000021:8k_2_02:21]
| • | Billings1: Total billings were $622.4 million for the second quarter of 2019, an increase of 21% compared to $513.4 million for the same quarter of 2018. |

[0001262039-19-000021:8k_2_02:22]
| • | Deferred Revenue: Total deferred revenue was $1.87 billion as of June 30, 2019, an increase of 27% compared to $1.47 billion as of June 30, 2018. |

[0001262039-19-000021:8k_2_02:23]
| • | GAAP Operating Income and Margin: GAAP operating income was $75.2 million for the second quarter of 2019, representing a GAAP operating margin of 14%. GAAP operating income was $50.7 million for the same quarter of 2018, representing a GAAP operating margin of 11%. |

[0001262039-19-000021:8k_2_02:24]
| • | Non-GAAP Operating Income and Margin1: Non-GAAP operating income was $123.1 million for the second quarter of 2019, representing a non-GAAP operating margin of 24%. Non-GAAP operating income was $93.1 million for the second quarter of 2018, representing a non-GAAP operating margin of 21%. |

[0001262039-19-000021:8k_2_02:25]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $72.7 million for the second quarter of 2019, compared to GAAP net income of $49.3 million for the same quarter of 2018. GAAP diluted net income per share was $0.42 for the second quarter of 2019, based on 175.1 million diluted weighted-average shares outstanding, compared to GAAP diluted net income per share of $0.28 for the same quarter of 2018, based on 173.5 million diluted weighted-average shares outstanding. |

[0001262039-19-000021:8k_2_02:26]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $101.6 million for the second quarter of 2019, compared to non-GAAP net income of $71.4 million for the same quarter of 2018. Non-GAAP diluted net income per share was $0.58 for the second quarter of 2019, based on 175.1 million diluted weighted-average shares outstanding, compared to $0.41 for the same quarter of 2018, based on 173.5 million diluted weighted-average shares outstanding. |

[0001262039-19-000021:8k_2_02:27]
| • | Cash Flow and Free Cash Flow1: In the second quarter of 2019, cash flow from operations was $195.1 million compared to $142.2 million in the same quarter of 2018. Free cash flow was $177.8 million during the second quarter of 2019, compared to $130.6 million for the same quarter of 2018. |

[0001262039-19-000021:8k_2_02:28]
Guidance

[0001262039-19-000021:8k_2_02:29]
For the third quarter of 2019, Fortinet currently expects:

[0001262039-19-000021:8k_2_02:30]
| • | Revenue in the range of $525 million to $540 million |

[0001262039-19-000021:8k_2_02:31]
| • | Billings in the range of $600 million to $615 million |

[0001262039-19-000021:8k_2_02:32]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000021:8k_2_02:33]
| • | Non-GAAP operating margin in the range of 23.0% to 23.5% |

[0001262039-19-000021:8k_2_02:34]
| • | Diluted non-GAAP net income per share in the range of $0.55 to $0.57, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 177 million to 179 million |

[0001262039-19-000021:8k_2_02:35]
For the fiscal year 2019, Fortinet currently expects:

[0001262039-19-000021:8k_2_02:36]
| • | Revenue in the range of $2.10 billion to $2.12 billion |

[0001262039-19-000021:8k_2_02:37]
| • | Service revenue in the range of $1.34 billion to $1.36 billion |

[0001262039-19-000021:8k_2_02:38]
| • | Billings in the range of $2.51 billion to $2.54 billion |

[0001262039-19-000021:8k_2_02:39]
| • | Non-GAAP gross margin in the range of 75.5% to 76.5% |

[0001262039-19-000021:8k_2_02:40]
| • | Non-GAAP operating margin in the range of 23.0% to 23.5% |

[0001262039-19-000021:8k_2_02:41]
| • | Diluted non-GAAP net income per share in the range of $2.23 to $2.26, assuming a non-GAAP effective tax rate of 24%. This assumes a diluted share count of 177 million to 179 million |

[0001262039-19-000021:8k_2_02:42]
Our guidance with respect to non-GAAP financial measures excludes stock-based compensation and amortization of acquired intangible assets. We have not reconciled our guidance with respect to non-GAAP financial measures to the corresponding GAAP measures because certain items that impact these measures are uncertain or out of our control, or cannot

[0001262039-19-000021:8k_2_02:43]
be reasonably predicted. Accordingly, a reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001262039-19-000021:8k_2_02:44]
1 A reconciliation of GAAP to non-GAAP measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-19-000021:8k_2_02:45]
Conference Call Details

[0001262039-19-000021:8k_2_02:46]
Fortinet will host a conference call today at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss the earnings results. The call can be accessed by dialing (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 8583905. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet’s website at https://investor.fortinet.com and a replay will be archived and accessible at https://investor.fortinet.com/events-and-presentations. A replay of this conference call can also be accessed through August 8, 2019, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID #8583905.

[0001262039-19-000021:8k_2_02:47]
Third Quarter 2019 Investor Conference Participation Schedule:

[0001262039-19-000021:8k_2_02:48]
| • | Oppenheimer 22nd Annual Technology, Internet & Communications Conference |

[0001262039-19-000021:8k_2_02:49]
August 7, 2019 - Boston, MA

[0001262039-19-000021:8k_2_02:50]
| • | Raymond James SMID Conference (Meetings Only) |

[0001262039-19-000021:8k_2_02:51]
August 21, 2019 - Chicago, IL

[0001262039-19-000021:8k_2_02:52]
| • | Dougherty Institutional Investors Conference (Meetings Only) |

[0001262039-19-000021:8k_2_02:53]
September 5, 2019 - Minneapolis, MN

[0001262039-19-000021:8k_2_02:54]
Members of Fortinet’s management team are expected to present at these conferences and discuss the latest company strategies and initiatives. Fortinet’s conference presentations are expected to be available via webcast on the company’s web site. To listen to these presentations and access the most updated information and listen to the webcast of each event, please visit the Investor Relations page of Fortinet’s website at http://investor.fortinet.com. The schedule is subject to change.

[0001262039-19-000021:8k_2_02:55]
About Fortinet (www.fortinet.com)

[0001262039-19-000021:8k_2_02:56]
Fortinet (Nasdaq: FTNT) secures the largest enterprise, service provider and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. The Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. Learn more at http://www.fortinet.com, the Fortinet Blog or FortiGuard Labs.

[0001262039-19-000021:8k_2_02:57]
#          #          #

[0001262039-19-000021:8k_2_02:58]
Copyright © 2019 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet’s trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiOS, FortiGuard, FortiCare, FortiAnalyzer, FortiManager, FortiASIC, FortiClient, FortiCloud, FortiCore, FortiMail, FortiSandbox, ABACAS, APSecure, FortiADC, FortiAI, FortiAntenna, FortiAP, FortiAppEngine, FortiAppMonitor, FortiAuthenticator, FortiBalancer, FortiBIOS, FortiBridge, FortiCache, FortiCam, FortiCamera, FortiCarrier, FortiCASB, FortiCenter, FortiCentral, FortiConnect, FortiController, FortiConverter, FortiDB, FortiDDoS, FortiDeceptor, FortiDirector, FortiDNS, FortiExplorer, FortiExtender, FortiFone, FortiHypervisor, FortiInsight, FortiIsolator, FortiLocator, FortiLog, FortiMalwareEngine, FortiMeter, FortiMoM, FortiMonitor, FortiNAC, FortiPartner, FortiPlanner, FortiPortal, FortiPresence , FortiProtect, FortiProxy, FortiRecorder, FortiReporter, FortiRescue, FortiScan, FortiSDNConnector, FortiSIEM, FortiSMS, FortiSwitch, FortiTester, FortiToken, FortiTrust, FortiVault, FortiVoice, FortiVoIP, FortiVS, FortiWAN, FortiWeb, FortiWiFi, FortiWLC, FortiWLCOS and FortiWLM. Other trademarks belong to their respective owners. Fortinet has not independently verified statements or certifications herein attributed to third parties and Fortinet does not independently endorse such statements. Notwithstanding anything to the contrary herein, nothing herein constitutes a warranty, guarantee, contract, binding specification or other binding commitment by Fortinet or any indication of intent related to a binding commitment, and performance and other specification information herein may be unique to certain environments.

[0001262039-19-000021:8k_2_02:59]
FTNT-F

[0001262039-19-000021:8k_2_02:60]
Forward-looking Statements

[0001262039-19-000021:8k_2_02:61]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding demand for our products and services, our expectations of growth in 2019, statements regarding the momentum in our business and all guidance and future financial results. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based such that actual results are materially different from our forward-looking statements in this release. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, country-specific economic conditions, and foreign currency risks; competitiveness in the security market; the dynamic nature of the security market and its products and services; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding demand and increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; actual or perceived vulnerabilities in our products or services, and any actual or perceived breach of our network or our customers’ networks; longer sales cycles, particularly for larger enterprise, service providers, government and other large organization customers; the effectiveness of our salesforce and failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; risks associated with integrating acquisitions and changes in circumstances and plans associated therewith; sales and marketing execution risks; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby or by other factors; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive; risks associated with the adoption of, and demand for, our products and services in general and by specific customer segments; competition and pricing pressure; tariffs and other trade barriers; any political and

[0001262039-19-000021:8k_2_02:62]
Non-GAAP Financial Measures

[0001262039-19-000021:8k_2_02:63]
We have provided in this release financial information that has not been prepared in accordance with U.S. Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-19-000021:8k_2_02:64]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-19-000021:8k_2_02:65]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period and adjustments to the deferred revenue balance due to adoption of the new revenue recognition standard less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-19-000021:8k_2_02:66]
Free cash flow (non-GAAP). We define free cash flow as net cash provided by operating activities minus purchases of property and equipment. We believe free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after capital expenditures, can be used for strategic opportunities, including repurchasing outstanding common stock, investing in our business, making strategic acquisitions and strengthening the balance sheet. A limitation of using free cash flow rather than the GAAP measures of cash provided by or used in operating activities, investing activities, and financing activities is that free cash flow does not represent the total increase or decrease in the cash and cash equivalents balance for the period because it excludes cash flows from investing activities other than capital expenditures and cash flows from financing activities. Management accounts for this limitation by providing information about our capital expenditures and other investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition

[0001262039-19-000021:8k_2_02:67]
and Results of Operations—Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K and by presenting cash flows from investing and financing activities in our reconciliation of free cash flow. In addition, it is important to note that other companies, including companies in our industry, may not use free cash flow, may calculate free cash flow in a different manner than we do or may use other financial measures to evaluate their performance, all of which could reduce the usefulness of free cash flow as a comparative measure.

[0001262039-19-000021:8k_2_02:68]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, litigation settlement expenses and, when applicable, other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Second, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income calculated in accordance with GAAP.

[0001262039-19-000021:8k_2_02:69]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income or loss plus the items noted above under non-GAAP operating income and operating margin. In addition, we adjust non-GAAP net income and diluted net income per share for gains or losses on sale of investments in privately held companies as well as impairment, and a tax adjustment required for an effective tax rate on a non-GAAP basis, which differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the non-GAAP effective tax rates we use are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income or loss and diluted net income per share calculated in accordance with GAAP.

[0001262039-19-000021:8k_2_02:70]
FORTINET, INC.

[0001262039-19-000021:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-19-000021:8k_2_02:72]
(Unaudited, in millions)

[0001262039-19-000021:8k_2_02:73]
|  | June 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 1,022.1 |  |  | $ | 1,112.4 |  |
| Short-term investments | 808.1 |  |  | 537.2 |  |
| Accounts receivable—net | 403.1 |  |  | 444.5 |  |
| Inventory | 85.7 |  |  | 90.0 |  |
| Prepaid expenses and other current assets | 41.7 |  |  | 36.8 |  |
| Total current assets | 2,360.7 |  |  | 2,220.9 |  |
| LONG-TERM INVESTMENTS | 149.5 |  |  | 67.0 |  |
| PROPERTY AND EQUIPMENT—NET | 284.7 |  |  | 271.4 |  |
| DEFERRED CONTRACT COSTS | 204.1 |  |  | 182.6 |  |
| DEFERRED TAX ASSETS | 258.8 |  |  | 255.0 |  |
| GOODWILL | 38.2 |  |  | 38.2 |  |
| OTHER INTANGIBLE ASSETS—NET | 16.2 |  |  | 22.1 |  |
| OTHER ASSETS | 57.2 |  |  | 20.8 |  |
| TOTAL ASSETS | $ | 3,369.4 |  |  | $ | 3,078.0 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 72.4 |  |  | $ | 86.4 |  |
| Accrued liabilities | 83.2 |  |  | 77.5 |  |
| Accrued payroll and compensation | 91.6 |  |  | 98.4 |  |
| Income taxes payable | 15.0 |  |  | 28.2 |  |
| Deferred revenue | 1,031.5 |  |  | 965.9 |  |
| Total current liabilities | 1,293.7 |  |  | 1,256.4 |  |
| DEFERRED REVENUE | 835.0 |  |  | 720.9 |  |
| INCOME TAX LIABILITIES | 82.3 |  |  | 77.5 |  |
| OTHER LIABILITIES | 36.1 |  |  | 13.0 |  |
| Total liabilities | 2,247.1 |  |  | 2,067.8 |  |
| COMMITMENTS AND CONTINGENCIES |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 0.2 |  |  | 0.2 |  |
| Additional paid-in capital | 1,130.2 |  |  | 1,068.3 |  |
| Accumulated other comprehensive income (loss) | 0.9 |  |  | (0.8 | ) |
| Accumulated deficit | (9.0 | ) |  | (57.5 | ) |
| Total stockholders’ equity | 1,122.3 |  |  | 1,010.2 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 3,369.4 |  |  | $ | 3,078.0 |  |

[0001262039-19-000021:8k_2_02:74]
FORTINET, INC.

[0001262039-19-000021:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0001262039-19-000021:8k_2_02:76]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000021:8k_2_02:77]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 189.9 |  |  | $ | 166.3 |  |  | $ | 352.6 |  |  | $ | 309.1 |  |
| Service | 331.8 |  |  | 275.0 |  |  | 641.7 |  |  | 531.2 |  |
| Total revenue | 521.7 |  |  | 441.3 |  |  | 994.3 |  |  | 840.3 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product | 82.7 |  |  | 73.9 |  |  | 152.9 |  |  | 132.1 |  |
| Service | 45.6 |  |  | 39.2 |  |  | 88.4 |  |  | 78.2 |  |
| Total cost of revenue | 128.3 |  |  | 113.1 |  |  | 241.3 |  |  | 210.3 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 107.2 |  |  | 92.4 |  |  | 199.7 |  |  | 177.0 |  |
| Service | 286.2 |  |  | 235.8 |  |  | 553.3 |  |  | 453.0 |  |
| Total gross profit | 393.4 |  |  | 328.2 |  |  | 753.0 |  |  | 630.0 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development | 67.4 |  |  | 61.2 |  |  | 136.0 |  |  | 120.3 |  |
| Sales and marketing | 226.5 |  |  | 192.8 |  |  | 442.4 |  |  | 378.1 |  |
| General and administrative | 24.3 |  |  | 23.5 |  |  | 48.8 |  |  | 48.5 |  |
| Total operating expenses | 318.2 |  |  | 277.5 |  |  | 627.2 |  |  | 546.9 |  |
| OPERATING INCOME | 75.2 |  |  | 50.7 |  |  | 125.8 |  |  | 83.1 |  |
| INTEREST INCOME | 11.0 |  |  | 5.8 |  |  | 21.2 |  |  | 10.3 |  |
| OTHER EXPENSE—NET | (0.4 | ) |  | (5.0 | ) |  | (0.9 | ) |  | (5.2 | ) |
| INCOME BEFORE INCOME TAXES | 85.8 |  |  | 51.5 |  |  | 146.1 |  |  | 88.2 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 13.1 |  |  | 2.2 |  |  | 14.6 |  |  | (2.7 | ) |
| NET INCOME | $ | 72.7 |  |  | $ | 49.3 |  |  | $ | 131.5 |  |  | $ | 90.9 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.42 |  |  | $ | 0.29 |  |  | $ | 0.77 |  |  | $ | 0.54 |  |
| Diluted | $ | 0.42 |  |  | $ | 0.28 |  |  | $ | 0.75 |  |  | $ | 0.53 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 171.1 |  |  | 168.6 |  |  | 170.6 |  |  | 168.1 |  |
| Diluted | 175.1 |  |  | 173.5 |  |  | 175.0 |  |  | 172.6 |  |

[0001262039-19-000021:8k_2_02:78]
FORTINET, INC.

[0001262039-19-000021:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-19-000021:8k_2_02:80]
(Unaudited, in millions)

[0001262039-19-000021:8k_2_02:81]
|  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 131.5 |  |  | $ | 90.9 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Stock-based compensation | 88.0 |  |  | 77.1 |  |
| Amortization of deferred contract costs | 51.0 |  |  | 43.2 |  |
| Depreciation and amortization | 30.9 |  |  | 26.8 |  |
| Amortization of investment premiums, net of accretion of purchase discounts | (3.0 | ) |  | 0.2 |  |
| Other | 0.5 |  |  | 0.4 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 41.5 |  |  | 28.9 |  |
| Inventory | (5.5 | ) |  | (10.8 | ) |
| Prepaid expenses and other current assets | (5.4 | ) |  | 0.9 |  |
| Deferred contract costs | (72.4 | ) |  | (66.7 | ) |
| Deferred tax assets | (4.4 | ) |  | (13.3 | ) |
| Other assets | 2.4 |  |  | (0.7 | ) |
| Accounts payable | (14.6 | ) |  | (9.1 | ) |
| Accrued liabilities | (4.8 | ) |  | (4.7 | ) |
| Accrued payroll and compensation | (7.9 | ) |  | (2.0 | ) |
| Other liabilities | (2.8 | ) |  | (2.2 | ) |
| Deferred revenue | 179.7 |  |  | 136.3 |  |
| Income taxes payable | (8.3 | ) |  | (13.2 | ) |
| Net cash provided by operating activities | 396.4 |  |  | 282.0 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (748.1 | ) |  | (262.3 | ) |
| Sales of investments | 15.1 |  |  | 28.7 |  |
| Maturities of investments | 384.9 |  |  | 244.3 |  |
| Purchases of property and equipment | (27.5 | ) |  | (23.2 | ) |
| Payments made in connection with business combination, net of cash acquired | — |  |  | (6.0 | ) |
| Net cash used in investing activities | (375.6 | ) |  | (18.5 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Repurchase and retirement of common stock | (94.2 | ) |  | (117.1 | ) |
| Proceeds from issuance of common stock | 39.6 |  |  | 56.7 |  |
| Taxes paid related to net share settlement of equity awards | (56.5 | ) |  | (32.5 | ) |
| Payments of debt assumed in connection with business combination | — |  |  | (9.5 | ) |
| Net cash used in financing activities | (111.1 | ) |  | (102.4 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (90.3 | ) |  | 161.1 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 1,112.4 |  |  | 811.0 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 1,022.1 |  |  | $ | 972.1 |  |

[0001262039-19-000021:8k_2_02:82]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-19-000021:8k_2_02:83]
(Unaudited, in millions, except per share amounts)

[0001262039-19-000021:8k_2_02:84]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-19-000021:8k_2_02:85]
|  | Three Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
| Net cash provided by operating activities | $ | 195.1 |  |  | $ | 142.2 |  |
| Less: Purchases of property and equipment | (17.3 | ) |  | (11.6 | ) |
| Free cash flow | $ | 177.8 |  |  | $ | 130.6 |  |
| Net cash provided by (used in) investing activities | $ | (336.6 | ) |  | $ | 7.0 |  |
| Net cash used in financing activities | $ | (53.3 | ) |  | $ | (12.8 | ) |

[0001262039-19-000021:8k_2_02:86]
Reconciliation of GAAP operating income to non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-19-000021:8k_2_02:87]
|  | Three Months Ended June 30, 2019 |  | Three Months Ended June 30, 2018 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income | $ | 75.2 |  |  | $ | 47.9 |  | (a) | $ | 123.1 |  |  | $ | 50.7 |  |  | $ | 42.4 |  | (b) | $ | 93.1 |  |
| Operating margin | 14 | % |  |  |  | 24 | % |  | 11 | % |  |  |  | 21 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 45.0 |  |  |  |  |  |  | 40.6 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2.9 |  |  |  |  |  |  | 1.8 |  |  |  |
| Tax adjustment |  |  | (19.0 | ) | (c) |  |  |  |  | (20.3 | ) | (c) |  |
| Net income | $ | 72.7 |  |  | $ | 28.9 |  |  | $ | 101.6 |  |  | $ | 49.3 |  |  | $ | 22.1 |  |  | $ | 71.4 |  |
| Diluted net income per share | $ | 0.42 |  |  |  |  | $ | 0.58 |  |  | $ | 0.28 |  |  |  |  | $ | 0.41 |  |
| Shares used in diluted net income per share calculations | 175.1 |  |  |  |  | 175.1 |  |  | 173.5 |  |  |  |  | 173.5 |  |

[0001262039-19-000021:8k_2_02:88]
(a) To exclude $45.0 million of stock-based compensation and $2.9 million of amortization of acquired intangible assets in the three months ended June 30, 2019.

[0001262039-19-000021:8k_2_02:89]
(b) To exclude $40.6 million of stock-based compensation and $1.8 million of amortization of acquired intangible assets in the three months ended June 30, 2018.

[0001262039-19-000021:8k_2_02:90]
(c) Non-GAAP financial information is adjusted to an overall effective tax rate of 24% in 2019 and 2018, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-19-000021:8k_2_02:91]
Reconciliation of total revenue to total billings

[0001262039-19-000021:8k_2_02:92]
|  | Three Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |
| Total revenue | $ | 521.7 |  |  | $ | 441.3 |  |
| Add: Change in deferred revenue | 100.7 |  |  | 74.4 |  |
| Add: Deferred revenue balance acquired in business combination | — |  |  | (2.3 | ) |
| Total billings | $ | 622.4 |  |  | $ | 513.4 |  |

[0001262039-19-000021:8k_2_02:93]
| Investor Contact: |  | Media Contact: |
| Peter Salkowski |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-331-4595 |  | 408-391-9408 |
| psalkowski@fortinet.com |  | swheatley@fortinet.com |
