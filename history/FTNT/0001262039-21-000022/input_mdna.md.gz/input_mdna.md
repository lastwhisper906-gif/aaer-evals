# FTNT MD&A — 0001262039-21-000022


## mdna

[0001262039-21-000022:mdna:1]
[same as prior period, unchanged from 0001262039-21-000014:mdna:1]

[0001262039-21-000022:mdna:2]
•the duration and impact of the COVID-19 pandemic, including various COVID-19 variants, and the implementation of “return to office” plans;

[0001262039-21-000022:mdna:3]
[same as prior period, unchanged from 0001262039-21-000014:mdna:3]

[0001262039-21-000022:mdna:4]
[same as prior period, unchanged from 0001262039-21-000014:mdna:4]

[0001262039-21-000022:mdna:5]
[same as prior period, unchanged from 0001262039-21-000014:mdna:5]

[0001262039-21-000022:mdna:6]
[same as prior period, unchanged from 0001262039-21-000014:mdna:6]

[0001262039-21-000022:mdna:7]
[same as prior period, unchanged from 0001262039-21-000014:mdna:7]

[0001262039-21-000022:mdna:8]
[same as prior period, unchanged from 0001262039-21-000014:mdna:8]

[0001262039-21-000022:mdna:9]
[same as prior period, unchanged from 0001262039-21-000014:mdna:9]

[0001262039-21-000022:mdna:10]
•the effects of the global chip and component shortages and other factors affecting our manufacturing capacity and inventory management;

[0001262039-21-000022:mdna:11]
[same as prior period, unchanged from 0001262039-21-000014:mdna:11]

[0001262039-21-000022:mdna:12]
•growing our sales to businesses, service providers and government organizations, our ability to execute these sales and of the complexity of selling to all segments (including the increased competition and unpredictability of timing associated with sales to larger enterprises), the impact of sales to these organizations on our long-term growth, expansion and operating results, and the effectiveness of our sales organization;

[0001262039-21-000022:mdna:13]
[same as prior period, unchanged from 0001262039-21-000014:mdna:13]

[0001262039-21-000022:mdna:14]
[same as prior period, unchanged from 0001262039-21-000014:mdna:14]

[0001262039-21-000022:mdna:15]
[same as prior period, unchanged from 0001262039-21-000014:mdna:15]

[0001262039-21-000022:mdna:16]
•risks and expectations related to acquisitions and equity interests in private companies, including integration issues related to product plans and products, including the acquired technology, and risks of negative impact by such acquisitions and equity investments on our financial results;

[0001262039-21-000022:mdna:17]
[same as prior period, unchanged from 0001262039-21-000014:mdna:17]

[0001262039-21-000022:mdna:18]
[same as prior period, unchanged from 0001262039-21-000014:mdna:18]

[0001262039-21-000022:mdna:19]
[same as prior period, unchanged from 0001262039-21-000014:mdna:20]

[0001262039-21-000022:mdna:20]
[same as prior period, unchanged from 0001262039-21-000014:mdna:44]

[0001262039-21-000022:mdna:21]
[same as prior period, unchanged from 0001262039-21-000014:mdna:22]

[0001262039-21-000022:mdna:22]
•estimates of a range of 2021 spending on real estate and other expansion projects and of the anticipated completion timelines for such projects;

[0001262039-21-000022:mdna:23]
[same as prior period, unchanged from 0001262039-21-000014:mdna:23]

[0001262039-21-000022:mdna:24]
•statements regarding expected outcomes and liabilities in litigation;

[0001262039-21-000022:mdna:25]
[same as prior period, unchanged from 0001262039-21-000014:mdna:25]

[0001262039-21-000022:mdna:26]
[same as prior period, unchanged from 0001262039-21-000014:mdna:26]

[0001262039-21-000022:mdna:27]
[same as prior period, unchanged from 0001262039-21-000014:mdna:27]

[0001262039-21-000022:mdna:28]
[same as prior period, unchanged from 0001262039-21-000014:mdna:28]

[0001262039-21-000022:mdna:29]
Fortinet is a global leader in cybersecurity solutions provided to a wide variety of organizations, including enterprises, communication service providers and security service providers, government organizations and small businesses. Our cybersecurity solutions are designed to provide broad visibility and segmentation of the digital attack surface through our integrated Fortinet Security Fabric platform, which features automated protection, detection and response. The Fortinet Security Fabric platform leverages a common operating system or integration to this operating system across our product offerings and helps organizations secure their environments and reduce their security and network complexities. The Fortinet Security Fabric platform has an open architecture designed to connect Fortinet solutions and third-party solutions into a single ecosystem, enabling integration and automation.

[0001262039-21-000022:mdna:30]
[same as prior period, unchanged from 0001262039-21-000014:mdna:30]

[0001262039-21-000022:mdna:31]
[same as prior period, unchanged from 0001262039-21-000014:mdna:31]

[0001262039-21-000022:mdna:32]
[same as prior period, unchanged from 0001262039-21-000014:mdna:32]

[0001262039-21-000022:mdna:33]
FortiOS provides the foundation for the operation of all FortiGate network security appliances, whether physical, virtual, private- or public-cloud based, and is at the heart of the Fortinet Security Fabric platform. We make regular updates to FortiOS available through our FortiCare support services. The security and networking capabilities of the Fortinet Security

[0001262039-21-000022:mdna:34]
[same as prior period, unchanged from 0001262039-21-000014:mdna:60]

[0001262039-21-000022:mdna:35]
Fabric platform are controlled through FortiOS. FortiOS directs the operations of processors and SPUs and provides system management functions.

[0001262039-21-000022:mdna:36]
[same as prior period, unchanged from 0001262039-21-000014:mdna:34]

[0001262039-21-000022:mdna:37]
[same as prior period, unchanged from 0001262039-21-000014:mdna:35]

[0001262039-21-000022:mdna:38]
•Infrastructure Security—The Fortinet Security Fabric platform extends beyond the network to cover other attack vectors. This includes securing the LAN Edge (Wi-Fi and switch) and enabling and protecting customer cloud on-ramp needs through FortiSASE, our Secure Access Service Edge (SASE) solution that provides cloud-delivered security for remote users. Other infrastructure solutions covered include, Zero Trust Access solutions that enable customers to know and control who and what is on their network, and provide security for work from anywhere (WFA). Zero Trust Access solutions include FortiNAC, FortiAuthenticator, FortiClient and FortiToken.

[0001262039-21-000022:mdna:39]
[same as prior period, unchanged from 0001262039-21-000014:mdna:37]

[0001262039-21-000022:mdna:40]
[same as prior period, unchanged from 0001262039-21-000014:mdna:38]

[0001262039-21-000022:mdna:41]
[same as prior period, unchanged from 0001262039-21-000014:mdna:39]

[0001262039-21-000022:mdna:42]
[same as prior period, unchanged from 0001262039-21-000014:mdna:40]

[0001262039-21-000022:mdna:43]
[same as prior period, unchanged from 0001262039-21-000014:mdna:41]

[0001262039-21-000022:mdna:44]
As discussed in Note 2 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts, which resulted in an understatement of revenue during the three and six months ended June 30, 2020.

[0001262039-21-000022:mdna:45]
The correction of this error resulted in an increase to service revenue, gross profit and operating income of $2.1 million and $2.9 million for the three and six months ended June 30, 2020, respectively. Net income increased by $1.7 million and $2.3 million for the three months and six months ended June 30, 2020, respectively.

[0001262039-21-000022:mdna:46]
[same as prior period, unchanged from 0001262039-21-000014:mdna:45]

[0001262039-21-000022:mdna:47]
[same as prior period, unchanged from 0001262039-21-000014:mdna:46]

[0001262039-21-000022:mdna:48]
•Total revenue was $801.1 million and $1.51 billion during the three and six months ended June 30, 2021, an increase of 30% and 26%, respectively, compared to $617.6 million and $1.20 billion in the same periods last year. Product revenue was $298.3 million and $539.0 million during the three and six months ended June 30, 2021, an increase of 41% and 33%, respectively, compared to $211.9 million and $404.2 million in the same periods last year. Service revenue was $502.8 million and $972.4 million during the three and six months ended June 30, 2021, an increase of 24% and 23%, respectively, compared to $405.7 million and $791.1 million in the same periods last year.

[0001262039-21-000022:mdna:49]
•Total gross profit was $614.2 million and $1.17 billion during the three and six months ended June 30, 2021, an increase of 27% and 25%, respectively, compared to $482.5 million and $931.5 million in the same periods last year.

[0001262039-21-000022:mdna:50]
•We generated operating income of $147.5 million and $269.1 million during the three and six months ended June 30, 2021, an increase of 24% and 14%, respectively, compared to $118.8 million and $235.5 million in the same periods last year. Operating income during the three months ended June 30, 2021 and 2020 included gains on an intellectual property (“IP”) matter of $1.2 million and $1.1 million, respectively. Operating income during the six ended June 30, 2021 and 2020 included gains on an intellectual property (“IP”) matter of $2.3 million and $37.9 million, respectively.

[0001262039-21-000022:mdna:51]
•Cash, cash equivalents and investments were $3.36 billion as of June 30, 2021.

[0001262039-21-000022:mdna:52]
•During the six months ended June 30, 2021, we repurchased 0.5 million shares of common stock under our Share Repurchase Program (the “Repurchase Program”), for a total purchase price of $91.6 million.

[0001262039-21-000022:mdna:53]
•In March 2021, we issued $1.0 billion of Senior Notes. Long-term debt, net of unamortized discount and debt issuance costs, was $987.5 million as of June 30, 2021. There was no such debt outstanding at December 31, 2020.

[0001262039-21-000022:mdna:54]
•Deferred revenue was $2.91 billion as of June 30, 2021, an increase of $300.1 million, or 12%, from December 31, 2020. Short-term deferred revenue was $1.53 billion as of June 30, 2021, an increase of $140.2 million, or 10%, from December 31, 2020.

[0001262039-21-000022:mdna:55]
•We generated cash flows from operating activities of $734.1 million during the six months ended June 30, 2021, an increase of $167.7 million, or 30%, compared to the same period last year. We generated $50.0 million of proceeds from an IP matter in the first quarter of 2020.

[0001262039-21-000022:mdna:56]
Our revenue growth was driven by both product and service revenue. On a geographic basis, revenue continues to be diversified, which remains a key strength of our business. During the three months ended June 30, 2021, the Americas region, the Europe, Middle East and Africa (“EMEA”) region and the Asia Pacific (“APAC”) region contributed 42%, 38% and 20% of our total revenue, respectively, and increased by 29%, 34% and 24% compared to the same periods last year, respectively. During the six months ended June 30, 2021, the Americas region, the EMEA region and the APAC region contributed 41%, 39% and 20% of our total revenue, respectively, and increased by 25%, 29% and 25% compared to the same periods last year, respectively.

[0001262039-21-000022:mdna:57]
Product revenue grew 41% and 33% during the three and six months ended June 30, 2021, respectively, compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape. FortiGate products accounted for more than half of the product revenue growth during the three months ended June 30, 2021. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the FortiGate products. We experienced strong revenue growth across many of our security fabric platform products, including our OT solutions, secure access products and software licenses. Service revenue growth of 24% and 23% during the three and six months ended June 30, 2021, respectively, compared to the same periods last year, was driven by the strength of our FortiCare technical support and other service revenue which grew 26% and 24%, respectively, and of FortiGuard and other security subscription revenue, which grew 23% and 22%, respectively.

[0001262039-21-000022:mdna:58]
28

[0001262039-21-000022:mdna:59]
Our billings were diversified on a geographic basis. During the three months ended June 30, 2021, approximately 50% of our billings in the aggregate were from over 80 countries that individually contributed less than 3% of our billings.

[0001262039-21-000022:mdna:60]
During the three months ended June 30, 2021 and 2020, we recognized gains of $1.2 million and $1.1 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter in the second quarter of 2020 and 2021, operating expenses as a percentage of revenue stayed flat during the three months ended June 30, 2021 compared to the same period last year. During the six months ended June 30, 2021 and 2020, we recognized gains of $2.3 million and $37.9 million, respectively, on an IP matter in connection with a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry. Excluding the gains on the IP matter in the first and second quarter of 2020 and 2021, operating expenses as a percentage of revenue decreased by 0.8 percentage points during the six months ended June 30, 2021 compared to the same period last year. Headcount increased to 9,043 employees and contractors as of June 30, 2021, a 5% increase compared to 8,615 as of March 31, 2021 and a 10% increase compared to 8,238 as of December 31, 2020.

[0001262039-21-000022:mdna:61]
COVID-19 Pandemic Update

[0001262039-21-000022:mdna:62]
The United States and the global community we serve are facing unprecedented challenges posed by the COVID-19 pandemic, including the various COVID-19 variants. In response to the pandemic, we undertook a number of actions to protect our employees, including restricting travel and directing many of our employees to work from home. In certain geographies, we have started to transition back to an in-person working mode, allowing more employees to work from our offices. We intend to continue to monitor and abide by local employee health and safety protocols and other regulations as applicable to each local office.

[0001262039-21-000022:mdna:63]
While the broader implications of the COVID-19 pandemic on our employees and overall financial performance continue to evolve, we have seen certain impacts on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources as of and during the three and six months ended June 30, 2021. Conversely, some aspects of our business do not appear to have been significantly affected. During the three and six months ended June 30, 2021, we have observed the following:

[0001262039-21-000022:mdna:64]
•In most countries, our employees’ ability to travel has been reduced. In-person sales and marketing events or meetings that would normally have been held were canceled, postponed or converted into virtual events. However, as certain country’s restrictions start to ease, we have started to see an increase in expenses related to travel and marketing events. Although we cannot predict if or when such expenses will return to pre-pandemic levels, as of June 30, 2021 we have started to see an increase in such expenses as compared to the same period last year.

[0001262039-21-000022:mdna:65]
•The countries and geographic regions in which we experienced the fastest billings growth in the second quarter of 2021, as compared to the second quarter of 2020, were countries and geographic regions in which the COVID-19 pandemic is generally considered to currently have a comparatively shorter or less severe impact on the local population and economy.

[0001262039-21-000022:mdna:66]
•During the COVID-19 pandemic we noted that, for some of our customers, sales cycles appeared to lengthen. More recently, it may be that sales cycles for some customers have accelerated.

[0001262039-21-000022:mdna:67]
•Our average service contract duration increased by approximately two months in the second quarter of 2021 as compared to the second quarter of 2020.

[0001262039-21-000022:mdna:68]
•In order to mitigate supply chain risk and in anticipation of future demand, we worked to increase our on-hand stock of certain products.

[0001262039-21-000022:mdna:69]
•The yield on investment-grade debt has decreased, and while the risk of credit losses on our investments and cash equivalents has not changed significantly, as the debt securities in our portfolio have matured, they have been replaced by securities with lower effective interest rates. This has contributed to a decrease in our interest income during the three and six months ended June 30, 2021, compared to the same period last year.

[0001262039-21-000022:mdna:70]
[same as prior period, unchanged from 0001262039-21-000014:mdna:70]

[0001262039-21-000022:mdna:71]
Through the filing of this Quarterly Report on Form 10-Q, there have been no material changes to the trends described above. Going forward, however, the situation remains uncertain, rapidly changing and hard to predict, and the COVID-19

[0001262039-21-000022:mdna:72]
29

[0001262039-21-000022:mdna:73]
pandemic may have a material negative impact on our future periods. If we experience significant changes in our billings growth rates, it will impact product revenue in the current quarter and FortiGuard and FortiCare service revenues in subsequent quarters, as we sell annual and multi-year service contracts that are recognized ratably over the contractual service term. In addition, the broader implications of the pandemic on our business and operations and our financial results, including the extent to which the effects of the pandemic will impact future results and growth in the cybersecurity industry, remain uncertain. The extent of the impact of the COVID-19 pandemic on our operational and financial performance will depend on ongoing developments, including the duration and spread of the virus and its variants, the impact on our end-customers’ spending, the volume of sales and length of our sales cycles, the impact on our partners, suppliers, and employees, actions that may be taken by governmental authorities and other factors identified in Part II, Item 1A “Risk Factors” in this Form 10-Q. Given the dynamic nature of these circumstances, the full impact of the COVID-19 pandemic on our business and operations, results of operations, financial condition, cash flows, liquidity and capital and financial resources cannot be reasonably estimated at this time.

[0001262039-21-000022:mdna:74]
[same as prior period, unchanged from 0001262039-21-000014:mdna:73]

[0001262039-21-000022:mdna:75]
[same as prior period, unchanged from 0001262039-21-000014:mdna:74]

[0001262039-21-000022:mdna:76]
We also offer our products through major cloud providers, and have recognized revenue on a usage basis from Amazon Web Services, Microsoft Azure, Google Cloud, Alibaba Cloud, Oracle Cloud and IBM Cloud. We have also recognized revenue from customers who deploy our products in a bring-your-own-license (“BYOL”) arrangement in private clouds or at cloud providers. In a BYOL arrangement, a customer purchases a software license from us through our channel partners and deploys the software in a cloud provider’s environment. Similarly, customers may purchase such a license from us and deploy in third-party clouds or in their private cloud.

[0001262039-21-000022:mdna:77]
Our customers purchase our hardware products and software licenses, as well as our FortiGuard and other security subscription and FortiCare technical support services. We generally invoice at the time of our sale for the total price of the products and security and technical support services. Standard payment terms are generally no more than 60 days, though we continue to offer extended payment terms to certain distributor customers.

[0001262039-21-000022:mdna:78]
[same as prior period, unchanged from 0001262039-21-000014:mdna:77]

[0001262039-21-000022:mdna:79]
[same as prior period, unchanged from 0001262039-21-000014:mdna:78]

[0001262039-21-000022:mdna:80]
|  | Three Months Ended Or As Of |
|  | June 30, 2021 |  | June 30, 2020 |
|  | (in millions) |
| Revenue | $ | 801.1 |  |  | $ | 617.6 |  |
| Deferred revenue | $ | 2,905.4 |  |  | $ | 2,293.1 |  |
| Billings (non-GAAP) | $ | 960.9 |  |  | $ | 711.5 |  |
| Net cash provided by operating activities | $ | 418.2 |  |  | $ | 247.0 |  |
| Free cash flow (non-GAAP) | $ | 394.7 |  |  | $ | 216.1 |  |

[0001262039-21-000022:mdna:81]
Deferred revenue. Our deferred revenue consists of amounts that have been invoiced but that have not yet been recognized as revenue. The majority of our deferred revenue balance consists of the unrecognized portion of service revenue from FortiGuard and other security subscription and FortiCare technical support service contracts, which is recognized as revenue ratably over the contractual service period. We monitor our deferred revenue balance, deferred revenue growth and the

[0001262039-21-000022:mdna:82]
[same as prior period, unchanged from 0001262039-21-000014:mdna:100]

[0001262039-21-000022:mdna:83]
mix of short-term and long-term deferred revenue because deferred revenue represents a significant portion of free cash flow and of revenue to be recognized in future periods. Deferred revenue was $2.91 billion as of June 30, 2021, an increase of $300.1 million, or 12%, from December 31, 2020.

[0001262039-21-000022:mdna:84]
Billings (non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period, less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive current and future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue. Total billings were $960.9 million for the three months ended June 30, 2021, an increase of 35% compared to $711.5 million in the same period last year.

[0001262039-21-000022:mdna:85]
[same as prior period, unchanged from 0001262039-21-000014:mdna:83]

[0001262039-21-000022:mdna:86]
|  | Three Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |
|  | (in millions) |
| Billings: |  |  |  |
| Revenue | $ | 801.1 |  |  | $ | 617.6 |  |
| Add: Change in deferred revenue | 159.8 |  |  | 93.9 |  |
| Total billings (non-GAAP) | $ | 960.9 |  |  | $ | 711.5 |  |

[0001262039-21-000022:mdna:87]
[same as prior period, unchanged from 0001262039-21-000014:mdna:85]

[0001262039-21-000022:mdna:88]
|  | Three Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |
|  | (in millions) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 418.2 |  |  | $ | 247.0 |  |
| Less: Purchases of property and equipment | (23.5) |  |  | (30.9) |  |
| Free cash flow (non-GAAP) | $ | 394.7 |  |  | $ | 216.1 |  |
| Net cash provided by (used in) investing activities | $ | (278.2) |  |  | $ | 212.2 |  |
| Net cash used in financing activities | $ | (120.9) |  |  | $ | (168.9) |  |

[0001262039-21-000022:mdna:89]
[same as prior period, unchanged from 0001262039-21-000014:mdna:87]

[0001262039-21-000022:mdna:90]
Our discussion and analysis of our financial condition and results of operations are based upon our financial statements, which have been prepared in accordance with GAAP. These principles require us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, cost of revenue and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the

[0001262039-21-000022:mdna:91]
circumstances. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001262039-21-000022:mdna:92]
Except for the update to the range of useful lives for property and equipment discussed in Note 6 and our policy election for how we account for our share of financial results for a specific investment in privately held companies on a three-month lag basis as discussed in Note 7, there were no material changes to our critical accounting policies and estimates as of and for the three and six months ended June 30, 2021, as compared to the critical accounting policies and estimates described in our Annual Report on Form 10-K filed with the SEC on February 19, 2021 (the “Form 10-K”).

[0001262039-21-000022:mdna:93]
[same as prior period, unchanged from 0001262039-21-000014:mdna:90]

[0001262039-21-000022:mdna:94]
[same as prior period, unchanged from 0001262039-21-000014:mdna:91]

[0001262039-21-000022:mdna:95]
[same as prior period, unchanged from 0001262039-21-000014:mdna:92]

[0001262039-21-000022:mdna:96]
Three Months Ended June 30, 2021 and June 30, 2020

[0001262039-21-000022:mdna:97]
[same as prior period, unchanged from 0001262039-21-000014:mdna:94]

[0001262039-21-000022:mdna:98]
|  | Three Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 298.3 |  |  | 37 | % |  | $ | 211.9 |  |  | 34 | % |  | $ | 86.4 |  |  | 41 | % |
| Service | 502.8 |  |  | 63 |  |  | 405.7 |  |  | 66 |  |  | 97.1 |  |  | 24 |  |
| Total revenue | $ | 801.1 |  |  | 100 | % |  | $ | 617.6 |  |  | 100 | % |  | $ | 183.5 |  |  | 30 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 337.0 |  |  | 42 | % |  | $ | 261.0 |  |  | 42 | % |  | $ | 76.0 |  |  | 29 | % |
| EMEA | 306.2 |  |  | 38 |  |  | 229.2 |  |  | 37 |  |  | 77.0 |  |  | 34 |  |
| APAC | 157.9 |  |  | 20 |  |  | 127.4 |  |  | 21 |  |  | 30.5 |  |  | 24 |  |
| Total revenue | $ | 801.1 |  |  | 100 | % |  | $ | 617.6 |  |  | 100 | % |  | $ | 183.5 |  |  | 30 | % |

[0001262039-21-000022:mdna:99]
Total revenue increased by $183.5 million, or 30%, during the three months ended June 30, 2021 compared to the same period last year. We continued to experience largely organic revenue growth (i.e. revenue growth excluding attribution from recent acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-21-000022:mdna:100]
Product revenue increased by $86.4 million, or 41%, during the three months ended June 30, 2021 compared to the same period last year. Product revenue growth was consistent with an elevated cyber threat landscape. FortiGate products accounted for more than half of the product revenue growth in the three months ended June 30, 2021. While Secure SD-WAN contributed to product revenue growth, the main driver was the strong demand for the wide range of other operating system capabilities embedded in the FortiGate products. We also experienced strong revenue growth across many of our security fabric platform products, including OT solutions, secure access products and software licenses.

[0001262039-21-000022:mdna:101]
Service revenue increased by $97.1 million, or 24%, during the three months ended June 30, 2021 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $50.3 million, or 23%, and by $46.8 million, or 26%, respectively, during the three months ended June 30, 2021 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions delivered to on-premise and cloud based environment as well as FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000022:mdna:102]
32

[0001262039-21-000022:mdna:103]
Of the service revenue recognized during the three months ended June 30, 2021, 89% was included in the deferred revenue balance as of March 31, 2021.

[0001262039-21-000022:mdna:104]
[same as prior period, unchanged from 0001262039-21-000014:mdna:101]

[0001262039-21-000022:mdna:105]
|  | Three Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 115.6 |  |  | $ | 84.4 |  |  | $ | 31.2 |  |  | 37 | % |
| Service | 71.3 |  |  | 50.7 |  |  | 20.6 |  |  | 41 |  |
| Total cost of revenue | $ | 186.9 |  |  | $ | 135.1 |  |  | $ | 51.8 |  |  | 38 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.2 | % |  | 60.2 | % |  |  |  |  |
| Service | 85.8 |  |  | 87.5 |  |  |  |  |  |
| Total gross margin | 76.7 | % |  | 78.1 | % |  |  |  |  |

[0001262039-21-000022:mdna:106]
Total gross margin decreased by 1.4 percentage points during the three months ended June 30, 2021 compared to the same period last year, driven by change in revenue mix to lower margin product revenue from higher margin service revenue year over year.

[0001262039-21-000022:mdna:107]
Product gross margin increased by 1.0 percentage points during the three months ended June 30, 2021 compared to the same period last year. Product gross margin benefited from lower indirect costs of goods sold as a percentage of product revenue. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000022:mdna:108]
Service gross margin decreased by 1.7 percentage points during the three months ended June 30, 2021 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs and data center costs. The decrease in service gross margin was primarily due to foreign currency fluctuations and the increased costs associated with an expansion in our data centers.

[0001262039-21-000022:mdna:109]
[same as prior period, unchanged from 0001262039-21-000014:mdna:130]

[0001262039-21-000022:mdna:110]
[same as prior period, unchanged from 0001262039-21-000014:mdna:106]

[0001262039-21-000022:mdna:111]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2021 |  | June 30,2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 106.6 |  |  | 13 | % |  | $ | 82.1 |  |  | 13 | % |  | $ | 24.5 |  |  | 30 | % |
| Sales and marketing | 326.9 |  |  | 41 |  |  | 253.8 |  |  | 41 |  |  | 73.1 |  |  | 29 |  |
| General and administrative | 34.4 |  |  | 4 |  |  | 28.9 |  |  | 5 |  |  | 5.5 |  |  | 19 |  |
| Gain on IP matter | (1.2) |  |  | — |  |  | (1.1) |  |  | — |  |  | (0.1) |  |  | 9 |  |
| Total operating expenses | $ | 466.7 |  |  | 58 | % |  | $ | 363.7 |  |  | 59 | % |  | $ | 103.0 |  |  | 28 | % |

[0001262039-21-000022:mdna:112]
[same as prior period, unchanged from 0001262039-21-000014:mdna:108]

[0001262039-21-000022:mdna:113]
Research and development expense increased by $24.5 million, or 30%, during the three months ended June 30, 2021 compared to the same period last year, primarily due to an increase of $20.4 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development costs, such as third-party testing and prototypes, increased by $4.3 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:114]
[same as prior period, unchanged from 0001262039-21-000014:mdna:110]

[0001262039-21-000022:mdna:115]
Sales and marketing expense increased by $73.1 million, or 29%, during the three months ended June 30, 2021 compared to the same period last year, primarily due to an increase of $55.8 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases and foreign currency fluctuations. In addition, marketing-related expense increased by $10.9 million and travel expense increased by $2.4 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:116]
[same as prior period, unchanged from 0001262039-21-000014:mdna:112]

[0001262039-21-000022:mdna:117]
General and administrative expense increased by $5.5 million, or 19%, during the three months ended June 30, 2021 compared to the same period last year, primarily due to an increase in professional services costs of $3.0 million and an increase in personnel-related costs of $2.8 million. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:118]
Gain on IP matter

[0001262039-21-000022:mdna:119]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the three months ended June 30, 2021, we recorded $1.2 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. During the three months ended June 30, 2020, we recorded $1.1 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 13 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-21-000022:mdna:120]
[same as prior period, unchanged from 0001262039-21-000014:mdna:116]

[0001262039-21-000022:mdna:121]
We generated operating income of $147.5 million during the three months ended June 30, 2021, an increase of $28.7 million, or 24%, compared to $118.8 million in the same period last year. Operating income as a percentage of revenue decreased to 18% during the three months ended June 30, 2021 compared to 19% in the same period last year. The decrease in operating margin is primarily due to 1.4 percentage point decrease in gross margin, partially offset by 0.4 percentage point

[0001262039-21-000022:mdna:122]
[same as prior period, unchanged from 0001262039-21-000014:mdna:143]

[0001262039-21-000022:mdna:123]
decrease in general and administrative expense and 0.3 percentage point decrease in sales and marketing as percentage of revenue, respectively.

[0001262039-21-000022:mdna:124]
Interest income, interest expense and other income—net

[0001262039-21-000022:mdna:125]
|  | Three Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 1.2 |  |  | $ | 4.0 |  |  | $ | (2.8) |  |  | (70) | % |
| Interest expense | $ | (4.5) |  |  | $ | — |  |  | $ | (4.5) |  |  | (100) | % |
| Other income—net | $ | 0.8 |  |  | $ | 0.9 |  |  | $ | (0.1) |  |  | (11) | % |

[0001262039-21-000022:mdna:126]
Interest income decreased by $2.8 million during the three months ended June 30, 2021 compared to the same period last year, as a result of lower interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $4.5 million during the three months ended June 30, 2021 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. Other income—net during the three months ended June 30, 2021 was flat compared to the same period last year.

[0001262039-21-000022:mdna:127]
[same as prior period, unchanged from 0001262039-21-000014:mdna:121]

[0001262039-21-000022:mdna:128]
|  | Three Months Ended |  | Change |  | % Change |
| June 30,2021 |  | June 30,2020 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 7.5 |  |  | $ | 9.9 |  |  | $ | (2.4) |  |  | (24) | % |
| Effective tax rate (%) | 5 | % |  | 8 | % |  |  |  |  |

[0001262039-21-000022:mdna:129]
Our effective tax rate was 5% for the three months ended June 30, 2021 compared to an effective tax rate of 8% for the same period last year. The provision for income taxes for the three months ended June 30, 2021 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $38.0 million. This tax provision for income taxes was favorably affected by a tax benefit of $7.1 million from the foreign-derived intangible income deduction, excess tax benefits from stock-based compensation expense of $18.2 million and release of reserves of $5.2 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:mdna:130]
The provision for income taxes for the three months ended June 30, 2020 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $33.6 million, which were offset by a tax benefit of $5.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $10.0 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:mdna:131]
Results of Operations

[0001262039-21-000022:mdna:132]
Six Months Ended June 30, 2021 and June 30, 2020

[0001262039-21-000022:mdna:133]
Revenue

[0001262039-21-000022:mdna:134]
|  | Six Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in millions, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 539.0 |  |  | 36 | % |  | $ | 404.2 |  |  | 34 | % |  | $ | 134.8 |  |  | 33 | % |
| Service | 972.4 |  |  | 64 |  |  | 791.1 |  |  | 66 |  |  | 181.3 |  |  | 23 |  |
| Total revenue | $ | 1,511.4 |  |  | 100 | % |  | $ | 1,195.3 |  |  | 100 | % |  | $ | 316.1 |  |  | 26 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 627.9 |  |  | 41 | % |  | $ | 503.6 |  |  | 42 | % |  | $ | 124.3 |  |  | 25 | % |
| EMEA | 581.9 |  |  | 39 |  |  | 450.2 |  |  | 38 |  |  | 131.7 |  |  | 29 |  |
| APAC | 301.6 |  |  | 20 |  |  | 241.5 |  |  | 20 |  |  | 60.1 |  |  | 25 |  |
| Total revenue | $ | 1,511.4 |  |  | 100 | % |  | $ | 1,195.3 |  |  | 100 | % |  | $ | 316.1 |  |  | 26 | % |

[0001262039-21-000022:mdna:135]
Total revenue increased by $316.1 million, or 26%, during the six months ended June 30, 2021 compared to the same period last year. We continued to experience largely organic revenue growth (i.e. revenue growth excluding attribution from acquisitions) with diversification of revenue geographically, and across both customer and industry segments. Revenue from all regions grew, with EMEA contributing the largest portion of the increase on an absolute dollar basis and on a percentage basis.

[0001262039-21-000022:mdna:136]
Product revenue increased by $134.8 million, or 33%, during the six months ended June 30, 2021 compared to the same period last year. We experienced revenue growth across many of our products primarily due to an increase in product revenue from our security fabric platform products, including our SD-WAN solutions, and software licenses.

[0001262039-21-000022:mdna:137]
Service revenue increased by $181.3 million, or 23%, during the six months ended June 30, 2021 compared to the same period last year. FortiGuard security subscription and FortiCare technical support and other revenues increased by $94.2 million, or 22%, and by $87.1 million, or 24%, respectively, during the six months ended June 30, 2021 compared to the same period last year. The increases were primarily due to the recognition of revenue from our growing deferred revenue balance related to FortiGuard and other security subscriptions and FortiCare technical support, including our customers moving to higher-tier support offerings.

[0001262039-21-000022:mdna:138]
Of the service revenue recognized during the six months ended June 30, 2021, 81% was included in the deferred revenue balance as of December 31, 2020.

[0001262039-21-000022:mdna:139]
36

[0001262039-21-000022:mdna:140]
Cost of revenue and gross margin

[0001262039-21-000022:mdna:141]
|  | Six Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 206.9 |  |  | $ | 160.7 |  |  | $ | 46.2 |  |  | 29 | % |
| Service | 136.6 |  |  | 103.1 |  |  | 33.5 |  |  | 32 | % |
| Total cost of revenue | $ | 343.5 |  |  | $ | 263.8 |  |  | $ | 79.7 |  |  | 30 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 61.6 | % |  | 60.2 | % |  |  |  |  |
| Service | 86.0 |  |  | 87.0 |  |  |  |  |  |
| Total gross margin | 77.3 | % |  | 77.9 | % |  |  |  |  |

[0001262039-21-000022:mdna:142]
Total gross margin decreased by 0.6 percentage points during the six months ended June 30, 2021 compared to the same period last year, driven by change in revenue to lower margin product revenue from higher margin service revenue.

[0001262039-21-000022:mdna:143]
Product gross margin increased by 1.4 percentage points during the six months ended June 30, 2021 compared to the same period last year. Product gross margin benefited from lower direct and indirect product costs as a percentage of product revenue. Cost of product revenue was comprised primarily of third-party contract manufacturers’ costs and the costs of materials used in production.

[0001262039-21-000022:mdna:144]
Service gross margin decreased by 1.0 percentage points during the six months ended June 30, 2021 compared to the same period last year. Cost of service revenue was comprised primarily of personnel costs and data center costs. The decrease in service gross margin was primarily due to foreign currency fluctuations and increased costs associated with an expansion in our data centers.

[0001262039-21-000022:mdna:145]
Operating expenses

[0001262039-21-000022:mdna:146]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2021 |  | June 30,2020 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 203.8 |  |  | 14 | % |  | $ | 162.4 |  |  | 14 | % |  | $ | 41.4 |  |  | 25 | % |
| Sales and marketing | 630.9 |  |  | 42 |  |  | 513.8 |  |  | 43 |  |  | 117.1 |  |  | 23 |  |
| General and administrative | 66.4 |  |  | 4 |  |  | 57.7 |  |  | 5 |  |  | 8.7 |  |  | 15 |  |
| Gain on IP matter | (2.3) |  |  | — |  |  | (37.9) |  |  | (3) |  |  | 35.6 |  |  | (94) |  |
| Total operating expenses | $ | 898.8 |  |  | 60 | % |  | $ | 696.0 |  |  | 58 | % |  | $ | 202.8 |  |  | 29 | % |
| Percentages have been rounded for presentation purposes and may differ from unrounded results. |

[0001262039-21-000022:mdna:147]
Research and development

[0001262039-21-000022:mdna:148]
Research and development expense increased by $41.4 million, or 25%, during the six months ended June 30, 2021 compared to the same period last year, primarily due to an increase of $34.6 million in personnel-related costs as a result of increased headcount to support the development of new products and continued enhancements to our existing products. In addition, product development costs, such as third-party testing and prototypes, increased by $7.3 million. We currently intend to continue to invest in our research and development organization, and expect research and development expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:149]
37

[0001262039-21-000022:mdna:150]
Sales and marketing

[0001262039-21-000022:mdna:151]
Sales and marketing expense increased by $117.1 million, or 23%, during the six months ended June 30, 2021 compared to the same period last year, primarily due to an increase of $104.3 million in personnel-related costs as a result of increases to sales and marketing headcount in order to drive global market revenue increases and foreign currency fluctuations. Marketing-related expense increased by $11.2 million. We currently intend to continue to make investments in sales and marketing resources, which are critical to support our future growth, and expect sales and marketing expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:152]
General and administrative

[0001262039-21-000022:mdna:153]
General and administrative expense increased by $8.7 million, or 15%, during the six months ended June 30, 2021 compared to the same period last year, primarily due to an increase in personnel-related costs of $5.3 million and an increase in professional services fee of $3.4 million, partially offset by a decrease of $1.2 million in the provision for expected credit losses. We currently expect general and administrative expense to increase in absolute dollars during the remainder of 2021.

[0001262039-21-000022:mdna:154]
Gain on IP matter

[0001262039-21-000022:mdna:155]
In January 2020, we entered into an agreement with a competitor in the network security industry, whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a mutual covenant-not-to-sue for patent claims. During the six months ended June 30, 2021, we recorded $2.3 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. During the six months ended June 30, 2020, we recorded $36.0 million upfront and additional $1.9 million in amortization of the deferred component as a gain on IP matter in our condensed consolidated statements of income. See Note 13 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding the gain on IP matter.

[0001262039-21-000022:mdna:156]
Operating income and margin

[0001262039-21-000022:mdna:157]
We generated operating income of $269.1 million during the six months ended June 30, 2021, an increase of $33.6 million, or 14%, compared to $235.5 million in the same period last year. Operating income as a percentage of revenue decreased to 18% during the six months ended June 30, 2021 compared to 20% in the same period last year. During the six months ended June 30, 2020, we recorded $36.0 million upfront and additional $1.9 million in amortization of the deferred component as a gain on IP matter, which increased our operating margin by 3.2 percentage point. Excluding the impact of this gain, our operating margin increased 1.2 percentage point primarily due to 1.3 percentage point and 0.4 percentage point decrease in sales and marketing expense and general and administrative expense as percentage of revenue, respectively, partially offset by 0.6 percentage point decrease in gross margin.

[0001262039-21-000022:mdna:158]
Interest income, interest expense and other expense—net

[0001262039-21-000022:mdna:159]
|  | Six Months Ended |  |  |  |  |
| June 30,2021 |  | June 30,2020 |  | Change |  | % Change |
| (in millions, except percentages) |
| Interest income | $ | 2.3 |  |  | $ | 13.2 |  |  | $ | (10.9) |  |  | (83) | % |
| Interest expense | $ | (5.8) |  |  | $ | — |  |  | $ | (5.8) |  |  | (100) | % |
| Other expense—net | $ | (1.2) |  |  | $ | (7.1) |  |  | $ | 5.9 |  |  | (83) | % |

[0001262039-21-000022:mdna:160]
Interest income decreased by $10.9 million during the six months ended June 30, 2021 compared to the same period last year, primarily as a result of lower interest rates. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. Interest expense increased by $5.8 million during the six months ended June 30, 2021 compared to the same period last year, primarily due to the senior notes issued in the first quarter of 2021. The change in other expense—net during the six months ended June 30, 2021 compared to the same period last year was the result of a $4.3 million impairment charge on an investment in a privately held company during the first quarter of 2020. In addition, foreign currency exchange gain increased by $1.4 million compared to the same period last year.

[0001262039-21-000022:mdna:161]
38

[0001262039-21-000022:mdna:162]
Provision for income taxes

[0001262039-21-000022:mdna:163]
|  | Six Months Ended |  | Change |  | % Change |
| June 30,2021 |  | June 30,2020 |  |
| (in millions, except percentages) |
| Provision for income taxes | $ | 19.7 |  |  | $ | 23.2 |  |  | $ | (3.5) |  |  | (15) | % |
| Effective tax rate (%) | 7 | % |  | 10 | % |  |  |  |  |

[0001262039-21-000022:mdna:164]
Our effective tax rate was 7% for the six months ended June 30, 2021 compared to an effective tax rate of 10% for the same period last year. The provision for income taxes for the six months ended June 30, 2021 was primarily comprised of U.S. federal and state taxes, withholding taxes and foreign taxes that were $75.4 million. This tax provision for income taxes was favorably affected by a tax benefit of $15.2 million from the foreign-derived intangible income deduction, excess tax benefits from stock-based compensation expense of $35.3 million and release of reserves of $5.2 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:mdna:165]
The provision for income taxes for the six months ended June 30, 2020 was comprised of U.S. federal and state taxes, withholding taxes, and foreign taxes that were $66.7 million, which were offset by a tax benefit of $9.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $25.2 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:mdna:166]
[same as prior period, unchanged from 0001262039-21-000014:mdna:124]

[0001262039-21-000022:mdna:167]
|  | As of |
|  | June 30,2021 |  | December 31,2020 |
|  | (in millions) |
| Cash and cash equivalents | $ | 1,879.3 |  |  | $ | 1,061.8 |  |
| Investments | 1,480.5 |  |  | 893.8 |  |
| Total cash, cash equivalents and investments | $ | 3,359.8 |  |  | $ | 1,955.6 |  |
| Working capital | $ | 1,909.7 |  |  | $ | 910.9 |  |
|  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |
|  | (in millions) |
| Net cash provided by operating activities | $ | 734.1 |  |  | $ | 566.4 |  |
| Net cash provided by (used in) investing activities | (751.7) |  |  | 216.8 |  |
| Net cash provided by (used in) financing activities | 835.1 |  |  | (1,089.3) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 817.5 |  |  | $ | (306.1) |  |

[0001262039-21-000022:mdna:168]
Liquidity and capital resources may be impacted by our operating activities, as well as by our stock repurchases, proceeds from the issuance of common stock, investment grade debt issuance and payment of taxes in connection with the net settlement of equity awards, real estate and other capital expenditures and business acquisitions.

[0001262039-21-000022:mdna:169]
In recent years, we have received significant capital resources from our billings to customers, issuance of investment grade debt and, to some extent, from the exercise of stock options by our employees. Additional increases in billings may depend on a number of factors, including demand for our products and services, competition, market or industry changes, macroeconomic events such as the COVID-19 pandemic and our ability to execute. We expect proceeds from the exercise of stock options in future years to be impacted by the increased mix of restricted stock units versus stock options granted to our employees and to vary based on our share price.

[0001262039-21-000022:mdna:170]
In February 2020, we received a cash payment of $50.0 million pursuant to a mutual covenant-not-to-sue and release agreement with a competitor in the network security industry.

[0001262039-21-000022:mdna:171]
39

[0001262039-21-000022:mdna:172]
In July 2020, our board of directors approved a $500.0 million increase in the authorized stock repurchase amount under the Repurchase Program and extended the term of the Repurchase Program to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. During the six months ended June 30, 2021, we repurchased 0.5 million shares of common stock under the Repurchase Program. As of June 30, 2021, $921.1 million remained available for future share repurchases under the Repurchase Program.

[0001262039-21-000022:mdna:173]
[same as prior period, unchanged from 0001262039-21-000014:mdna:131]

[0001262039-21-000022:mdna:174]
We believe that our cash provided by operating activities, together with our existing cash, cash equivalents and investments will be sufficient to meet our anticipated cash needs and do not intend to retire these Notes early. Refer to Note 12. Debt in Part I, Item 1 of this Quarterly Report on Form 10-Q for information on the Notes. As of June 30, 2021, the long-term debt, net of unamortized discount and debt issuance costs, was $987.5 million.

[0001262039-21-000022:mdna:175]
Construction of a second building at our headquarters campus started in the fourth quarter of 2018 and was completed in the second quarter of 2021. We estimate the remaining cash payment on the second building of our headquarters campus project to be approximately $30.0 million in the second half of 2021. We estimate the full year capital expenditures to be between $175.0 and $200.0 million.

[0001262039-21-000022:mdna:176]
As of June 30, 2021, our cash, cash equivalents and investments of $3.36 billion were invested primarily in deposit accounts, money market funds, corporate debt securities, commercial paper, certificates of deposit and term deposits and U.S. government securities. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and generates return without significantly increasing risk. We do not enter into investments for trading or speculative purposes.

[0001262039-21-000022:mdna:177]
The amount of cash, cash equivalents and investments held by our international subsidiaries was $117.8 million as of June 30, 2021 and $119.8 million as of December 31, 2020.

[0001262039-21-000022:mdna:178]
[same as prior period, unchanged from 0001262039-21-000014:mdna:136]

[0001262039-21-000022:mdna:179]
[same as prior period, unchanged from 0001262039-21-000014:mdna:137]

[0001262039-21-000022:mdna:180]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, amortization of deferred contract costs and depreciation and amortization. Changes in operating assets and liabilities consist primarily of changes in deferred revenue, accounts receivable and deferred contract costs.

[0001262039-21-000022:mdna:181]
Our operating activities during the six months ended June 30, 2021 provided cash flows of $734.1 million as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard and other security subscription services and FortiCare technical support services to new and existing customers, as reflected by an increase in our deferred revenue. Our total deferred revenue balance grew $300.1 million, or 12%, during the six months ended June 30, 2021.

[0001262039-21-000022:mdna:182]
[same as prior period, unchanged from 0001262039-21-000014:mdna:140]

[0001262039-21-000022:mdna:183]
[same as prior period, unchanged from 0001262039-21-000014:mdna:141]

[0001262039-21-000022:mdna:184]
During the six months ended June 30, 2021, cash used in investing activities was $751.7 million, driven by $590.8 million spent for purchases of investments, net of maturities and sales of investments, $75.6 million of purchases of property and equipment, a large portion of which relates to our headquarters building construction, $75.0 million used for purchases of investment in a privately held company and $10.3 million used for the acquisition of ShieldX Networks, Inc. (“ShieldX”), net of cash acquisition.

[0001262039-21-000022:mdna:185]
[same as prior period, unchanged from 0001262039-21-000014:mdna:144]

[0001262039-21-000022:mdna:186]
The changes in cash flows from financing activities primarily relate to repurchase and retirement of common stock, taxes paid related to net share settlement of equity awards, net of proceeds from the issuance of common stock under the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan and the issuance of long-term notes, net of discount and underwriting.

[0001262039-21-000022:mdna:187]
During the six months ended June 30, 2021, cash provided by financing activities was $835.1 million, primarily driven by $989.4 million in cash proceeds from long-term investment grade debt, net of discount and underwriting fees, partially offset by $91.6 million used to repurchase shares of our common stock and $60.2 million used to pay tax withholding, net of proceeds from the issuance of common stock.

[0001262039-21-000022:mdna:188]
[same as prior period, unchanged from 0001262039-21-000014:mdna:147]

[0001262039-21-000022:mdna:189]
There were no material changes outside the ordinary course of business during the six months ended June 30, 2021 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 14 of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-21-000022:mdna:190]
[same as prior period, unchanged from 0001262039-21-000014:mdna:149]

[0001262039-21-000022:mdna:191]
As of June 30, 2021, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
