# FTNT notes — 0001262039-21-000022


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-21-000022:notes:1]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

[0001262039-21-000022:notes:2]
[same as prior period, unchanged from 0001262039-21-000014:notes:2]

[0001262039-21-000022:notes:3]
Except for the update to the range of useful lives for property and equipment discussed in Note 6 and our policy election for how we account for our share of financial results for a specific investment in privately held companies on a three-month lag basis as discussed in Note 7, there have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2021.

[0001262039-21-000022:notes:4]
Recently Adopted Accounting Standards

[0001262039-21-000022:notes:5]
[same as prior period, unchanged from 0001262039-21-000014:notes:5]

[0001262039-21-000022:notes:6]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2019-12—Income Taxes (“Topic 740”): Simplifying the Accounting for Income Taxes. The amendments in ASU 2019-12 simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application and simplification of GAAP for other areas of Topic 740 by clarifying and amending existing guidance. ASU 2019-12 was effective for us beginning on January 1, 2021. The adoption of this guidance did not have any impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001262039-21-000022:notes:7]
IMMATERIAL CORRECTION OF PRIOR PERIOD FINANCIAL STATEMENTS
Subsequent to the issuance of our condensed consolidated financial statements for the period ended June 30, 2020, we identified an immaterial error related to the commencement of revenue recognition for certain FortiCare support service contracts. Rather than commencing recognition upon end user registration, we should have commenced recognition when control had passed to the distributor, which we have determined is our customer. We assessed the effect of this correction, individually and in the aggregate, on prior periods’ financial statements in accordance with the SEC’s Staff Accounting Bulletin Nos. 99 and 108 and, based on an analysis of quantitative and qualitative factors, determined that the correction was not individually material to any of our prior interim or annual consolidated financial statements.

[0001262039-21-000022:notes:8]
All financial information contained in the accompanying notes to these condensed consolidated financial statements has been revised to reflect the correction of this error.

[0001262039-21-000022:notes:9]
The corrections to our condensed consolidated statement of income for the three and six months ended June 30, 2020 were as follows (in millions, except per share amounts):

[0001262039-21-000022:notes:10]
|  | Three Months Ended June 30, 2020 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |
| Service | $ | 403.6 |  |  | $ | 2.1 |  |  | $ | 405.7 |  |
| Total revenue | $ | 615.5 |  |  | $ | 2.1 |  |  | $ | 617.6 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Service | $ | 352.9 |  |  | $ | 2.1 |  |  | $ | 355.0 |  |
| Total gross profit | $ | 480.4 |  |  | $ | 2.1 |  |  | $ | 482.5 |  |
| OPERATING INCOME | $ | 116.7 |  |  | $ | 2.1 |  |  | $ | 118.8 |  |
| INCOME BEFORE INCOME TAXES | $ | 121.6 |  |  | $ | 2.1 |  |  | $ | 123.7 |  |
| PROVISION FOR INCOME TAXES | $ | 9.5 |  |  | $ | 0.4 |  |  | $ | 9.9 |  |
| NET INCOME | $ | 112.1 |  |  | $ | 1.7 |  |  | $ | 113.8 |  |
| Net income per share (Note 10): |  |  |  |  |  |
| Basic | $ | 0.69 |  |  | $ | 0.01 |  |  | $ | 0.70 |  |
| Diluted | $ | 0.68 |  |  | $ | 0.01 |  |  | $ | 0.69 |  |

[0001262039-21-000022:notes:11]
|  | Six Months Ended June 30, 2020 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| REVENUE: |  |  |  |  |  |
| Service | $ | 788.2 |  |  | $ | 2.9 |  |  | $ | 791.1 |  |
| Total revenue | $ | 1,192.4 |  |  | $ | 2.9 |  |  | $ | 1,195.3 |  |
| GROSS PROFIT: |  |  |  |  |  |
| Service | $ | 685.1 |  |  | $ | 2.9 |  |  | $ | 688.0 |  |
| Total gross profit | $ | 928.6 |  |  | $ | 2.9 |  |  | $ | 931.5 |  |
| OPERATING INCOME | $ | 232.6 |  |  | $ | 2.9 |  |  | $ | 235.5 |  |
| INCOME BEFORE INCOME TAXES | $ | 238.7 |  |  | $ | 2.9 |  |  | $ | 241.6 |  |
| PROVISION FOR INCOME TAXES | $ | 22.6 |  |  | $ | 0.6 |  |  | $ | 23.2 |  |
| NET INCOME | $ | 216.1 |  |  | $ | 2.3 |  |  | $ | 218.4 |  |
| Net income per share (Note 10): |  |  |  |  |  |
| Basic | $ | 1.30 |  |  | $ | 0.01 |  |  | $ | 1.31 |  |
| Diluted | $ | 1.27 |  |  | $ | 0.02 |  |  | $ | 1.29 |  |

[0001262039-21-000022:notes:12]
The corrections to our condensed consolidated statement of cash flows for the six months ended June 30, 2020 were as follows (in millions):

[0001262039-21-000022:notes:13]
|  | Six Months Ended June 30, 2020 |
|  | As Previously Reported |  | Corrections |  | As Corrected |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |
| Net income | $ | 216.1 |  |  | $ | 2.3 |  |  | $ | 218.4 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Deferred tax assets | 13.0 |  |  | 0.6 |  |  | 13.6 |  |
| Deferred revenue | 186.9 |  |  | (2.9) |  |  | 184.0 |  |

[0001262039-21-000022:notes:14]
For the period in which we corrected net income, we made corresponding corrections to net income and comprehensive income in our condensed consolidated statement of comprehensive income and to net income, retained earnings (accumulated deficit) and total stockholders’ equity in our condensed consolidated statements of stockholders’ equity.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001262039-21-000022:notes:15]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.

[0001262039-21-000022:notes:16]
Disaggregation of Revenue

[0001262039-21-000022:notes:17]
[same as prior period, unchanged from 0001262039-21-000014:notes:15]

[0001262039-21-000022:notes:18]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Product | $ | 298.3 |  |  | $ | 211.9 |  |  | $ | 539.0 |  |  | $ | 404.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 272.9 |  |  | 222.6 |  |  | 528.2 |  |  | 434.0 |  |
| Technical support and other | 229.9 |  |  | 183.1 |  |  | 444.2 |  |  | 357.1 |  |
| Total service revenue | 502.8 |  |  | 405.7 |  |  | 972.4 |  |  | 791.1 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |

[0001262039-21-000022:notes:19]
[same as prior period, unchanged from 0001262039-21-000014:notes:17]

[0001262039-21-000022:notes:20]
During the three months ended June 30, 2021 and June 30, 2020, we recognized $371.2 million and $302.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the six months ended June 30, 2021 and June 30, 2020, we recognized $789.1 million and $645.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

[0001262039-21-000022:notes:21]
[same as prior period, unchanged from 0001262039-21-000014:notes:19]

[0001262039-21-000022:notes:22]
As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.91 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.53 billion as revenue over the next 12 months and the remainder thereafter.

[0001262039-21-000022:notes:23]
[same as prior period, unchanged from 0001262039-21-000014:notes:21]

[0001262039-21-000022:notes:24]
[same as prior period, unchanged from 0001262039-21-000014:notes:22]

[0001262039-21-000022:notes:25]
The allowance for credit losses was $2.7 million and $2.5 million as of June 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2021 and 2020.

[0001262039-21-000022:notes:26]
Deferred Contract Costs

[0001262039-21-000022:notes:27]
Amortization of deferred contract costs during the three months ended June 30, 2021 and 2020 were $42.1 million and $33.2 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2021 and 2020 were $81.8 million and $64.5 million, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-21-000022:notes:28]
[same as prior period, unchanged from 0001262039-21-000014:notes:25]

[0001262039-21-000022:notes:29]
|  | June 30, 2021 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 658.4 |  |  | $ | 0.1 |  |  | $ | (0.3) |  |  | $ | 658.2 |  |
| Corporate debt securities | 485.6 |  |  | 0.3 |  |  | (0.2) |  |  | 485.7 |  |
| Certificates of deposit and term deposits (1) | 187.7 |  |  | 0.1 |  |  | — |  |  | 187.8 |  |
| U.S. government securities | 148.8 |  |  | — |  |  | — |  |  | 148.8 |  |
| Total available-for-sale securities | $ | 1,480.5 |  |  | $ | 0.5 |  |  | $ | (0.5) |  |  | $ | 1,480.5 |  |

[0001262039-21-000022:notes:30]
|  | December 31, 2020 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Commercial paper | $ | 185.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 185.4 |  |
| Corporate debt securities | 410.5 |  |  | 1.0 |  |  | — |  |  | 411.5 |  |
| Certificates of deposit and term deposits (1) | 112.0 |  |  | — |  |  | — |  |  | 112.0 |  |
| U.S. government securities | 184.9 |  |  | — |  |  | — |  |  | 184.9 |  |
| Total available-for-sale securities | $ | 892.8 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 893.8 |  |
| (1) The majority of our certificates of deposit and term deposits are foreign deposits. |

[0001262039-21-000022:notes:31]
[same as prior period, unchanged from 0001262039-21-000014:notes:28]

[0001262039-21-000022:notes:32]
|  | June 30, 2021 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 139.0 |  |  | $ | (0.3) |  |  | $ | — |  |  | $ | — |  |  | $ | 139.0 |  |  | $ | (0.3) |  |
| Corporate debt securities | 225.8 |  |  | (0.2) |  |  | — |  |  | — |  |  | 225.8 |  |  | (0.2) |  |
| Certificates of deposit and term deposits | 19.4 |  |  | — |  |  | 5.5 |  |  | — |  |  | 24.9 |  |  | — |  |
| U.S. government securities | 37.3 |  |  | — |  |  | — |  |  | — |  |  | 37.3 |  |  | — |  |
| Total available-for-sale securities | $ | 421.5 |  |  | $ | (0.5) |  |  | $ | 5.5 |  |  | $ | — |  |  | $ | 427.0 |  |  | $ | (0.5) |  |

[0001262039-21-000022:notes:33]
|  | December 31, 2020 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Commercial paper | $ | 61.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 61.5 |  |  | $ | — |  |
| Corporate debt securities | 111.3 |  |  | — |  |  | — |  |  | — |  |  | 111.3 |  |  | — |  |
| Certificates of deposit and term deposits | 29.5 |  |  | — |  |  | — |  |  | — |  |  | 29.5 |  |  | — |  |
| U.S. government securities | 38.1 |  |  | — |  |  | — |  |  | — |  |  | 38.1 |  |  | — |  |
| Total available-for-sale securities | $ | 240.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 240.4 |  |  | $ | — |  |

[0001262039-21-000022:notes:34]
[same as prior period, unchanged from 0001262039-21-000014:notes:31]

[0001262039-21-000022:notes:35]
|  | June 30,2021 |  | December 31,2020 |
| Due within one year | $ | 1,233.9 |  |  | $ | 775.5 |  |
| Due within one to three years | 246.6 |  |  | 118.3 |  |
| Total | $ | 1,480.5 |  |  | $ | 893.8 |  |

[0001262039-21-000022:notes:36]
Available-for-sale securities are reported at fair value, with unrealized gains and losses and the related tax impact included as a separate component of stockholders’ equity and in comprehensive income. Accrued interest receivable of $3.2 million as of June 30, 2021 was excluded from the fair value of our available-for-sale securities and was recorded in prepaid expenses and other current assets in our condensed consolidated balance sheet.

[0001262039-21-000022:notes:37]
[same as prior period, unchanged from 0001262039-21-000014:notes:34]

[0001262039-21-000022:notes:38]
[same as prior period, unchanged from 0001262039-21-000014:notes:35]

[0001262039-21-000022:notes:39]
[same as prior period, unchanged from 0001262039-21-000014:notes:36]

[0001262039-21-000022:notes:40]
[same as prior period, unchanged from 0001262039-21-000014:notes:37]

[0001262039-21-000022:notes:41]
[same as prior period, unchanged from 0001262039-21-000014:notes:38]

[0001262039-21-000022:notes:42]
[same as prior period, unchanged from 0001262039-21-000014:notes:39]

[0001262039-21-000022:notes:43]
[same as prior period, unchanged from 0001262039-21-000014:notes:40]

[0001262039-21-000022:notes:44]
[same as prior period, unchanged from 0001262039-21-000014:notes:41]

[0001262039-21-000022:notes:45]
[same as prior period, unchanged from 0001262039-21-000014:notes:42]

[0001262039-21-000022:notes:46]
[same as prior period, unchanged from 0001262039-21-000014:notes:43]

[0001262039-21-000022:notes:47]
[same as prior period, unchanged from 0001262039-21-000014:notes:44]

[0001262039-21-000022:notes:48]
|  | June 30, 2021 |  | December 31, 2020 |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 658.2 |  |  | $ | — |  |  | $ | 658.2 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |  | $ | 197.2 |  |  | $ | — |  |
| Corporate debt securities | 485.7 |  |  | — |  |  | 485.7 |  |  | — |  |  | 413.7 |  |  | — |  |  | 413.7 |  |  | — |  |
| Certificates of deposit and term deposits | 187.8 |  |  | — |  |  | 187.8 |  |  | — |  |  | 112.0 |  |  | — |  |  | 112.0 |  |  | — |  |
| U.S. government securities | 148.8 |  |  | 148.8 |  |  | — |  |  | — |  |  | 184.9 |  |  | 184.9 |  |  | — |  |  | — |  |
| Money market funds | 80.6 |  |  | 80.6 |  |  | — |  |  | — |  |  | 152.7 |  |  | 152.7 |  |  | — |  |  | — |  |
| Total | $ | 1,561.1 |  |  | $ | 229.4 |  |  | $ | 1,331.7 |  |  | $ | — |  |  | $ | 1,060.5 |  |  | $ | 337.6 |  |  | $ | 722.9 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 80.6 |  |  |  |  |  |  |  |  | $ | 166.7 |  |  |  |  |  |  |  |
| Short-term investments | 1,233.9 |  |  |  |  |  |  |  |  | 775.5 |  |  |  |  |  |  |  |
| Long-term investments | 246.6 |  |  |  |  |  |  |  |  | 118.3 |  |  |  |  |  |  |  |
| Total | $ | 1,561.1 |  |  |  |  |  |  |  |  | $ | 1,060.5 |  |  |  |  |  |  |  |

[0001262039-21-000022:notes:49]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the six months ended June 30, 2021 and year ended December 31, 2020.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-21-000022:notes:50]
[same as prior period, unchanged from 0001262039-21-000014:notes:47]

[0001262039-21-000022:notes:51]
|  | June 30,2021 |  | December 31,2020 |
| Raw materials | $ | 16.2 |  |  | $ | 13.8 |  |
| Finished goods | 133.6 |  |  | 126.0 |  |
| Inventory | $ | 149.8 |  |  | $ | 139.8 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-21-000022:notes:52]
[same as prior period, unchanged from 0001262039-21-000014:notes:49]

[0001262039-21-000022:notes:53]
|  | June 30,2021 |  | December 31,2020 |
| Land | $ | 106.8 |  |  | $ | 93.3 |  |
| Buildings and improvements | 345.1 |  |  | 150.6 |  |
| Computer equipment and software | 155.3 |  |  | 137.2 |  |
| Leasehold improvements | 35.3 |  |  | 31.9 |  |
| Evaluation units | 20.2 |  |  | 19.8 |  |
| Furniture and fixtures | 25.1 |  |  | 21.3 |  |
| Construction-in-progress | 10.6 |  |  | 166.4 |  |
| Total property and equipment | 698.4 |  |  | 620.5 |  |
| Less: accumulated depreciation | (191.9) |  |  | (172.5) |  |
| Property and equipment—net | $ | 506.5 |  |  | $ | 448.0 |  |

[0001262039-21-000022:notes:54]
We completed construction of a second building at our headquarters campus and it has been placed in service as of June 30, 2021. In conjunction with the completion of the building, we evaluated the range of useful lives of our property and equipment. The range of useful lives for buildings and improvements is now two to 40 years, an increase from two to 30 years, and for furniture and fixtures the range is now three to eight years, an increase from three to five years.

[0001262039-21-000022:notes:55]
Depreciation expense was $15.3 million and $14.1 million during the three months ended June 30, 2021 and 2020, respectively. Depreciation expense was $29.3 million and $27.7 million during the six months ended June 30, 2021 and 2020, respectively.


## us-gaap:InvestmentTextBlock

[0001262039-21-000022:notes:56]
[same as prior period, unchanged from 0001262039-21-000014:notes:52]

[0001262039-21-000022:notes:57]
On March 19, 2021, we invested $75.0 million in cash for shares of the Series A Preferred Stock of Linksys Holdings, Inc. (“Linksys”) for a 32.6% ownership interest. Linksys provides router connectivity solutions to the consumer and small business markets.

[0001262039-21-000022:notes:58]
We concluded that our investment is an in-substance common-stock investment, and, though we do not hold a controlling financial interest in Linksys, we have the ability to exercise significant influence over the operating and financial policies of Linksys. Therefore, we determined to account for this investment using the equity method of accounting. We record our share of Linksys’ financial results on a three-month lag basis. Our share of the earnings of Linksys’ financial results, which are accounted for under the three-month lag basis, were not material and therefore our investment in Linksys was not adjusted for the equity method impacts during the three months ended June 30, 2021.

[0001262039-21-000022:notes:59]
As of June 30, 2021, the investment was included in other assets on our condensed consolidated balance sheet. Transaction costs related to this investment were not material

[0001262039-21-000022:notes:60]
Our other investments in the equity securities of privately held companies without readily determinable fair values totaled $1.0 million as of June 30, 2021 and December 31, 2020.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-21-000022:notes:61]
BUSINESS COMBINATION
ShieldX Networks, Inc.

[0001262039-21-000022:notes:62]
On March 10, 2021, we closed an acquisition of certain assets and liabilities of ShieldX Networks Inc. (“ShieldX”) for $10.8 million in cash. This acquisition was accounted for as a business combination using the acquisition method of accounting. Of the purchase price, $6.2 million was allocated to goodwill, $4.1 million was allocated to developed technology intangible asset and $0.5 million was allocated to other net assets acquired. Goodwill recorded in connection with this acquisition 
represents the value we expect to be created through expansion into markets within our existing business and potential cost savings and synergies. All acquired goodwill is expected to be deductible for tax purposes. Acquisition-related costs related to this acquisition were not material and were recorded as general and administrative expense.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-21-000022:notes:63]
[same as prior period, unchanged from 0001262039-21-000014:notes:58]

[0001262039-21-000022:notes:64]
[same as prior period, unchanged from 0001262039-21-000014:notes:59]

[0001262039-21-000022:notes:65]
|  | Amount |
| Balance—December 31, 2020 | $ | 93.0 |  |
| Addition due to business combination | 6.2 |  |
| Balance—June 30, 2021 | $ | 99.2 |  |

[0001262039-21-000022:notes:66]
There were no impairments to goodwill during the six months ended June 30, 2021 or during prior periods.

[0001262039-21-000022:notes:67]
[same as prior period, unchanged from 0001262039-21-000014:notes:62]

[0001262039-21-000022:notes:68]
[same as prior period, unchanged from 0001262039-21-000014:notes:63]

[0001262039-21-000022:notes:69]
|  | June 30, 2021 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Developed technologies | 4.0 |  | $ | 63.4 |  |  | $ | 37.5 |  |  | $ | 25.9 |  |
| Customer relationships | 4.0 |  | 24.8 |  |  | 22.0 |  |  | 2.8 |  |
| Total other intangible assets—net |  |  | $ | 88.2 |  |  | $ | 59.5 |  |  | $ | 28.7 |  |

[0001262039-21-000022:notes:70]
[same as prior period, unchanged from 0001262039-21-000014:notes:65]

[0001262039-21-000022:notes:71]
Amortization expense was $3.5 million and $3.7 million during the three months ended June 30, 2021 and 2020, respectively. Amortization expense was $6.9 million and $7.7 million during the six months ended June 30, 2021 and 2020, respectively.

[0001262039-21-000022:notes:72]
[same as prior period, unchanged from 0001262039-21-000014:notes:67]

[0001262039-21-000022:notes:73]
|  | Amount |
| Years: |  |
| 2021 (the remainder of 2021) | $ | 6.9 |  |
| 2022 | 10.7 |  |
| 2023 | 7.6 |  |
| 2024 | 3.2 |  |
| 2025 | 0.3 |  |
| Total | $ | 28.7 |  |


## us-gaap:EarningsPerShareTextBlock

[0001262039-21-000022:notes:74]
[same as prior period, unchanged from 0001262039-21-000014:notes:69]

[0001262039-21-000022:notes:75]
[same as prior period, unchanged from 0001262039-21-000014:notes:70]

[0001262039-21-000022:notes:76]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 137.5 |  |  | $ | 113.8 |  |  | $ | 244.7 |  |  | $ | 218.4 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.3 |  |  | 161.6 |  |  | 163.2 |  |  | 166.1 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 163.3 |  |  | 161.6 |  |  | 163.2 |  |  | 166.1 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| RSUs | 2.2 |  |  | 2.6 |  |  | 2.1 |  |  | 2.5 |  |
| Stock options | 1.6 |  |  | 1.2 |  |  | 1.4 |  |  | 1.2 |  |
| Weighted-average shares used to compute diluted net income per share | 167.1 |  |  | 165.4 |  |  | 166.7 |  |  | 169.8 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.84 |  |  | $ | 0.70 |  |  | $ | 1.50 |  |  | $ | 1.31 |  |
| Diluted | $ | 0.82 |  |  | $ | 0.69 |  |  | $ | 1.47 |  |  | $ | 1.29 |  |

[0001262039-21-000022:notes:77]
[same as prior period, unchanged from 0001262039-21-000014:notes:72]

[0001262039-21-000022:notes:78]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| RSUs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.3 |  |
| Stock options | 0.5 |  |  | 0.6 |  |  | 0.4 |  |  | 0.5 |  |
| Total | 0.6 |  |  | 0.7 |  |  | 0.6 |  |  | 0.8 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001262039-21-000022:notes:79]
LEASES 
We have operating leases for offices, research and development facilities and data centers. Our leases have remaining terms that range from less than one year to approximately six years, some of which include one or more options to renew, with renewal terms of up to six years. Unless and until we are reasonably certain we will exercise these renewal options, we do not include renewal options in our lease terms for calculating our lease liability, as the renewal options allow us to maintain operational flexibility.

[0001262039-21-000022:notes:80]
During the year ended December 31, 2019, we entered into a finance lease with $3.6 million lease liabilities arising from obtaining right-of-use assets with a lease term of approximately two years. Our remaining finance leases were not material to our condensed consolidated financial statements. The related assumptions and further disclosures for finance leases are not material.

[0001262039-21-000022:notes:81]
The components of lease expense were as follows (in millions):

[0001262039-21-000022:notes:82]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Operating lease expense | $ | 6.2 |  |  | $ | 4.4 |  |  | $ | 12.1 |  |  | $ | 8.7 |  |
| Variable lease expense (1) | 0.7 |  |  | 0.4 |  |  | 1.5 |  |  | 1.0 |  |
| Short-term lease expense | 0.9 |  |  | 1.0 |  |  | 1.7 |  |  | 1.9 |  |
| Total lease expense | $ | 7.8 |  |  | $ | 5.8 |  |  | $ | 15.3 |  |  | $ | 11.6 |  |

[0001262039-21-000022:notes:83]
(1) Variable lease expense for the three and six months ended June 30, 2021 and 2020 predominantly included common area maintenance charges and parking expense.

[0001262039-21-000022:notes:84]
Supplemental balance sheet information related to our operating leases was as follows (in millions, except lease term and discount rate):

[0001262039-21-000022:notes:85]
|  | Classification | June 30,2021 |  | December 31,2020 |
| Operating lease ROU assets - non-current | Other assets | $ | 59.7 |  |  | $ | 49.3 |  |
| Operating lease liabilities - current | Accrued liabilities | $ | 22.9 |  |  | $ | 19.1 |  |
| Operating lease liabilities - non-current | Other liabilities | 39.4 |  |  | 34.0 |  |
| Total operating lease liabilities |  | $ | 62.3 |  |  | $ | 53.1 |  |
| Weighted average remaining lease term in years - operating leases |  | 3.2 |  | 3.5 |
| Weighted average discount rate - operating leases |  | 2.5 | % |  | 3.2 | % |

[0001262039-21-000022:notes:86]
Supplemental cash flow information related to leases was as follows (in millions):

[0001262039-21-000022:notes:87]
|  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows used for operating leases | $ | 12.4 |  |  | $ | 8.7 |  |

[0001262039-21-000022:notes:88]
Maturities of operating lease liabilities as of June 30, 2021 were as follows (in millions):

[0001262039-21-000022:notes:89]
| Year Ending December 31, | Amount |
| 2021 (the remainder of 2021) | $ | 12.3 |  |
| 2022 | 21.9 |  |
| 2023 | 15.7 |  |
| 2024 | 9.6 |  |
| 2025 | 3.9 |  |
| Thereafter | 1.4 |  |
| Total lease payments | 64.8 |  |
| Less imputed interest | (2.5) |  |
| Total | $ | 62.3 |  |

[0001262039-21-000022:notes:90]
As of June 30, 2021, we had additional minimum lease payments of $2.8 million relating to operating leases that had been signed but had not yet commenced. These leases will commence during 2021 and will have lease terms of approximately two to four years.


## us-gaap:DebtDisclosureTextBlock

[0001262039-21-000022:notes:91]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

[0001262039-21-000022:notes:92]
The total outstanding debt is summarized below (in millions, except percentages):

[0001262039-21-000022:notes:93]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (12.5) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.5 |  |

[0001262039-21-000022:notes:94]
As of June 30, 2021 we accrued interest payable of $5.2 million, and there are no financial covenants with which we must comply. During the three and six months ended June 30, 2021 we recorded $4.5 million and $5.8 million of total interest

[0001262039-21-000022:notes:95]
expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and six months ended June 30, 2021, as the costs that qualified for capitalization were not material.

[0001262039-21-000022:notes:96]
The total estimated fair value of the outstanding Senior Notes was approximately $999.9 million, including accrued and unpaid interest, as of June 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.


## ftnt:MutualCovenantNottoSueAgreementDisclosureTextBlock

[0001262039-21-000022:notes:97]
MUTUAL COVENANT-NOT-TO-SUE AND RELEASE AGREEMENT
In January 2020, we entered into an agreement with a competitor in the network security industry whereby, in February 2020, the competitor party paid us a lump sum of $50.0 million for a seven-year mutual covenant-not-to-sue for patent claims. Pursuant to this agreement, at the end of this first seven-year period, either party may extend the agreement for an additional seven-year mutual covenant-not-to-sue in return for this competitor paying us an additional $50.0 million. This agreement arose after expiration of previous agreements between the parties whereby the competitor had paid us sums for a limited term license to certain of our intellectual property (“IP”) and a limited term mutual covenant-not-to-sue.

[0001262039-21-000022:notes:98]
We concluded that the agreement was a 14-year contract with a total transaction price of $100.0 million, and that it contained two material distinct performance obligations: (1) the right to use our existing patents, and (2) the right to use any patents that we develop over the term of the contract. We allocated $36.0 million to the functional patents, which was recognized upon commencement of the contract; the remaining $64.0 million, representing the right to utilize future patents, will be recognized over the contract term. We further concluded that our existing patents represent functional IP that should be recognized upon granting our competitor access. We also concluded that the right to receive additional functional IP that we will develop in the future represents a stand ready obligation. Therefore, the transaction price allocated to this obligation is recognized ratably over the 14-year contract term. We estimated the stand-alone selling price of each distinct performance obligation and allocated the $100.0 million transaction price.

[0001262039-21-000022:notes:99]
During the three months ended June 30, 2021 and 2020, we recorded $1.2 million and $1.1 million gain on IP matter in our condensed consolidated statements of income, respectively. During the six months ended June 30, 2021 and 2020, we recorded $2.3 million and $37.9 million gain on IP matter in our condensed consolidated statements of income, respectively. We recorded $7.5 million and $9.8 million in accrued liabilities and other liabilities in our condensed consolidated balance sheets as of June 30, 2021 and December 31, 2020, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-21-000022:notes:100]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2021 (in millions):

[0001262039-21-000022:notes:101]
|  | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Inventory purchase commitments | $ | 628.7 |  |  | $ | 451.6 |  |  | $ | 177.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001262039-21-000022:notes:102]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2021, we had $628.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-21-000022:notes:103]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2021, we had $67.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

[0001262039-21-000022:notes:104]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated

[0001262039-21-000022:notes:105]
with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of June 30, 2021 and December 31, 2020.

[0001262039-21-000022:notes:106]
Indemnification and Other Matters—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain IP rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of IP infringement that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. Although from time to time there are indemnification claims asserted against us and currently there are pending indemnification claims, to date there have been no material awards under such indemnification provisions.

[0001262039-21-000022:notes:107]
Similar to other security companies and companies in other industries, we have in the past experienced, and we may in the future experience, cybersecurity threats, malicious activity directed against our information technology infrastructure or unauthorized attempts to gain access to our and our customers’ sensitive information and systems. We currently are unaware of any existing claims or proceedings related to these types of matters, including any that we believe are likely to have a material adverse effect on our financial position.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-21-000022:notes:108]
[same as prior period, unchanged from 0001262039-21-000014:notes:100]

[0001262039-21-000022:notes:109]
We maintain the Amended and Restated Fortinet, Inc. 2009 Equity Incentive Plan (the “Amended Plan”) pursuant to which we have granted RSUs and stock options. As of June 30, 2021, there were a total of 11.5 million shares of common stock available for grant under the Amended Plan.

[0001262039-21-000022:notes:110]
[same as prior period, unchanged from 0001262039-21-000014:notes:102]

[0001262039-21-000022:notes:111]
[same as prior period, unchanged from 0001262039-21-000014:notes:103]

[0001262039-21-000022:notes:112]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2020 | 4.7 |  |  | $ | 90.46 |  |
| Granted | 1.0 |  |  | 177.12 |  |
| Forfeited | (0.2) |  |  | 105.40 |  |
| Vested | (1.4) |  |  | 80.67 |  |
| Balance—June 30, 2021 | 4.1 |  |  | $ | 113.73 |  |

[0001262039-21-000022:notes:113]
Stock compensation expense is recognized on a straight-line basis over the vesting period of each RSU. As of June 30, 2021, total compensation expense related to unvested RSUs granted to employees and non-employees under the Amended Plan, but not yet recognized, was $416.5 million, with a weighted-average remaining vesting period of 2.8 years.

[0001262039-21-000022:notes:114]
[same as prior period, unchanged from 0001262039-21-000014:notes:106]

[0001262039-21-000022:notes:115]
[same as prior period, unchanged from 0001262039-21-000014:notes:107]

[0001262039-21-000022:notes:116]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Shares withheld for taxes | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.5 |  |
| Amount withheld for taxes | $ | 34.7 |  |  | $ | 21.1 |  |  | $ | 76.1 |  |  | $ | 58.9 |  |

[0001262039-21-000022:notes:117]
[same as prior period, unchanged from 0001262039-21-000014:notes:109]

[0001262039-21-000022:notes:118]
[same as prior period, unchanged from 0001262039-21-000014:notes:110]

[0001262039-21-000022:notes:119]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Expected term in years | 4.4 |  | 4.4 |  | 4.4 |  | 4.4 |
| Volatility | 36.6 | % |  | 39.0 | % |  | 39.4 | % |  | 34.4 | % |
| Risk-free interest rate | 0.7 | % |  | 0.3 | % |  | 0.5 | % |  | 1.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-21-000022:notes:120]
[same as prior period, unchanged from 0001262039-21-000014:notes:112]

[0001262039-21-000022:notes:121]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2020 | 2.7 |  |  | $ | 67.53 |  |  | 4.2 |  | $ | 220.4 |  |
| Granted | 0.5 |  |  | 173.23 |  |  |  |  |  |
| Forfeited | — |  |  | 103.27 |  |  |  |  |  |
| Exercised | (0.3) |  |  | 52.40 |  |  |  |  |  |
| Balance—June 30, 2021 | 2.9 |  |  | $ | 87.60 |  |  |  |  |  |
| Options vested and expected to vest—June 30, 2021 | 2.9 |  |  | $ | 87.60 |  |  | 4.4 |  | $ | 437.0 |  |
| Options exercisable—June 30, 2021 | 1.6 |  |  | $ | 54.39 |  |  | 3.2 |  | $ | 289.9 |  |

[0001262039-21-000022:notes:122]
The aggregate intrinsic value represents the difference between the exercise price of stock options and the quoted market price of our common stock on June 30, 2021 for all in-the-money stock options. Stock compensation expense is recognized on a straight-line basis over the vesting period of each stock option. As of June 30, 2021, total compensation expense related to unvested stock options granted to employees but not yet recognized was $50.3 million, with a weighted-average remaining vesting period of 3.0 years.

[0001262039-21-000022:notes:123]
[same as prior period, unchanged from 0001262039-21-000014:notes:115]

[0001262039-21-000022:notes:124]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Weighted-average fair value per share granted | $ | 61.40 |  |  | $ | 46.92 |  |  | $ | 56.73 |  |  | $ | 35.51 |  |
| Intrinsic value of options exercised | $ | 16.9 |  |  | $ | 17.3 |  |  | $ | 39.3 |  |  | $ | 30.4 |  |
| Fair value of options vested | $ | 3.7 |  |  | $ | 2.4 |  |  | $ | 10.7 |  |  | $ | 8.4 |  |

[0001262039-21-000022:notes:125]
[same as prior period, unchanged from 0001262039-21-000014:notes:117]

[0001262039-21-000022:notes:126]
[same as prior period, unchanged from 0001262039-21-000014:notes:118]

[0001262039-21-000022:notes:127]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Cost of product revenue | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |
| Cost of service revenue | 3.8 |  |  | 3.2 |  |  | 7.3 |  |  | 6.2 |  |
| Research and development | 14.5 |  |  | 12.0 |  |  | 27.5 |  |  | 22.9 |  |
| Sales and marketing | 27.7 |  |  | 27.9 |  |  | 54.5 |  |  | 53.6 |  |
| General and administrative | 7.0 |  |  | 6.1 |  |  | 13.3 |  |  | 11.4 |  |
| Total stock-based compensation expense | $ | 53.5 |  |  | $ | 49.6 |  |  | $ | 103.5 |  |  | $ | 94.9 |  |

[0001262039-21-000022:notes:128]
[same as prior period, unchanged from 0001262039-21-000014:notes:120]

[0001262039-21-000022:notes:129]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| RSUs | $ | 48.5 |  |  | $ | 45.9 |  |  | $ | 94.3 |  |  | $ | 88.1 |  |
| Stock options | 5.0 |  |  | 3.7 |  |  | 9.2 |  |  | 6.8 |  |
| Total stock-based compensation expense | $ | 53.5 |  |  | $ | 49.6 |  |  | $ | 103.5 |  |  | $ | 94.9 |  |

[0001262039-21-000022:notes:130]
[same as prior period, unchanged from 0001262039-21-000014:notes:122]

[0001262039-21-000022:notes:131]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Income tax benefit associated with stock-based compensation | $ | 11.8 |  |  | $ | 10.9 |  |  | $ | 22.8 |  |  | $ | 20.9 |  |

[0001262039-21-000022:notes:132]
[same as prior period, unchanged from 0001262039-21-000014:notes:124]

[0001262039-21-000022:notes:133]
In July 2020, under the Share Repurchase Program originally approved by our board of directors in January 2016 (the “Repurchase Program”), our board of directors approved a $500.0 million increase and extended the term to February 28, 2022, bringing the aggregate amount authorized to be repurchased to $3.0 billion. Share repurchases may be made by us from time to time in privately negotiated transactions or in open-market transactions. The Repurchase Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice.

[0001262039-21-000022:notes:134]
During the three and six months ended June 30, 2021, we repurchased 0.5 million shares of common stock under the Repurchase Program in open-market transactions at a weighted-average price of $201.38 per share per share, for an aggregate purchase price of $91.6 million. As of June 30, 2021, $921.1 million remained available for future share repurchases under the Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-21-000022:notes:135]
INCOME TAXESOur effective tax rate was 5% for the three months ended June 30, 2021, compared to an effective tax rate of 8% for the same period last year. Our effective tax rate was 7% for the six months ended June 30, 2021, compared to an effective tax rate of 10% for the same period last year. The effective tax rates for the periods presented are primarily comprised of U.S. federal and state taxes, withholding taxes, foreign taxes, the tax benefit from foreign-derived intangible income deduction (the “FDII deduction”) and excess tax benefits from stock-based compensation expense. The tax rates for the three months ended June 30, 2021 and 2020 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to 
$38.0 million and $33.6 million, respectively. The tax rate for the three months ended June 30, 2021 was impacted by a tax benefit of $7.1 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $18.2 million and release of reserves of $5.2 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax rate for the three months ended June 30, 2020 was impacted by a tax benefit of $5.0 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $10.0 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:notes:136]
The tax rates for the six months ended June 30, 2021 and 2020 were composed of U.S. federal and state taxes, withholding taxes and foreign taxes that amounted to $75.4 million and $66.7 million, respectively. The tax rate for the six months ended June 30, 2021 was impacted by a tax benefit of $15.2 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $35.3 million and release of reserves of $5.2 million on uncertain tax positions and the interest due to the expiration of the statute of limitations. The tax rate for the six months ended June 30, 2020 was impacted by a tax benefit of $9.6 million from the FDII deduction, excess tax benefits from stock-based compensation expense of $25.2 million and release of reserves of $8.7 million on uncertain tax positions and the interest due to the expiration of the statute of limitations.

[0001262039-21-000022:notes:137]
As of June 30, 2021 and December 31, 2020, unrecognized tax benefits were $79.9 million and $77.3 million, respectively. If recognized, $72.7 million of the unrecognized tax benefits would favorably affect our effective tax rate. It is our policy to include accrued interest and penalties related to unrecognized tax benefits in income tax expense. As of June 30, 2021 and December 31, 2020, accrued interest and penalties were $15.4 million and $14.5 million, respectively. It is reasonably possible that our gross unrecognized tax benefits will decrease by up to $12.1 million in the next 12 months, due to the lapse of the statute of limitations. This decrease, if recognized, would favorably impact our effective tax rate, and would be recognized as additional tax benefits.

[0001262039-21-000022:notes:138]
We file income tax returns in the U.S. federal jurisdiction and in various U.S. state and foreign jurisdictions. Generally, we are no longer subject to U.S. state and foreign income tax examinations by tax authorities for tax years prior to 2010. We are no longer subject to examination by U.S federal income tax authorities for tax years prior to 2015. We currently have ongoing tax audits in the United Kingdom, Canada, Germany and several other foreign jurisdictions. The focus of these audits is the inter-company profit allocation.

[0001262039-21-000022:notes:139]
The Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law on March 27, 2020. The CARES Act provides numerous tax provisions and other stimulus measures, including temporary changes regarding the prior and future utilization of net operating losses, temporary changes to the prior and future limitations on interest deductions, temporary suspension of certain payment requirements for the employer portion of Social Security taxes, technical corrections from prior tax legislation for tax depreciation of certain qualified improvement property and the creation of certain refundable employee retention credits. There is no material tax impact on our condensed consolidated financial statements.

[0001262039-21-000022:notes:140]
On July 9, 2020, the United States Department of the Treasury (the “U.S. Treasury”) and the Internal Revenue Service (the “IRS”) released final Section 250 regulations, providing guidance on the foreign-derived intangible income deduction and the global intangible low-taxed income. Generally, the final regulations are applicable for taxable years beginning on or after January 1, 2021. However, taxpayers may apply the final regulations for taxable years beginning on or after January 1, 2018. We have elected to apply the final regulations to the year ending December 31, 2020 and included the tax impact from the final regulations on our foreign-derived intangible income deduction calculation.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-21-000022:notes:141]
DEFINED CONTRIBUTION PLANSOur tax-deferred savings plan under our 401(k) Plan permits participating U.S. employees to contribute a portion of their pre-tax or after-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan Program (the “RRSP”), which permits participants to make tax-deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to our 401(k) Plan and the RRSP for the three months ended June 30, 2021 and 2020 were $2.7 million and $2.2 million, respectively. Our matching contributions to our 401(k) Plan and the RRSP for the six months ended June 30, 2021 and 2020 were $5.4 million and $4.4 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-21-000022:notes:142]
[same as prior period, unchanged from 0001262039-21-000014:notes:131]

[0001262039-21-000022:notes:143]
[same as prior period, unchanged from 0001262039-21-000014:notes:132]

[0001262039-21-000022:notes:144]
|  | Three Months Ended |  | Six Months Ended |
| Revenue | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 251.7 |  |  | $ | 201.2 |  |  | $ | 464.2 |  |  | $ | 383.1 |  |
| Other Americas | 85.3 |  |  | 59.8 |  |  | 163.7 |  |  | 120.5 |  |
| Total Americas | 337.0 |  |  | 261.0 |  |  | 627.9 |  |  | 503.6 |  |
| Europe, Middle East and Africa (“EMEA”) | 306.2 |  |  | 229.2 |  |  | 581.9 |  |  | 450.2 |  |
| Asia Pacific (“APAC”) | 157.9 |  |  | 127.4 |  |  | 301.6 |  |  | 241.5 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |

[0001262039-21-000022:notes:145]
| Property and Equipment—net | June 30,2021 |  | December 31,2020 |
| Americas: |  |  |  |
| United States | $ | 352.1 |  |  | $ | 296.3 |  |
| Canada | 121.4 |  |  | 121.3 |  |
| Latin America | 1.9 |  |  | 2.0 |  |
| Total Americas | 475.4 |  |  | 419.6 |  |
| EMEA | 23.5 |  |  | 20.6 |  |
| APAC | 7.6 |  |  | 7.8 |  |
| Total property and equipment—net | $ | 506.5 |  |  | $ | 448.0 |  |

[0001262039-21-000022:notes:146]
[same as prior period, unchanged from 0001262039-21-000014:notes:135]

[0001262039-21-000022:notes:147]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Exclusive Networks Group (“Exclusive”) | 31 | % |  | 31 | % |  | 32 | % |  | 31 | % |
| Ingram Micro, Inc. (“Ingram Micro”) | 12 | % |  | * |  | 12 | % |  | * |

[0001262039-21-000022:notes:148]
* Represents less than 10%

[0001262039-21-000022:notes:149]
[same as prior period, unchanged from 0001262039-21-000014:notes:137]

[0001262039-21-000022:notes:150]
|  | June 30,2021 |  | December 31,2020 |
| Exclusive | 32 | % |  | 34 | % |
| Ingram Micro | 13 | % |  | 11 | % |


## us-gaap:SubsequentEventsTextBlock

[0001262039-21-000022:notes:151]
SUBSEQUENT EVENTS
Investments in Linksys

[0001262039-21-000022:notes:152]
As discussed in Note 7, on March 19, 2021 we invested $75.0 million in Linksys. On August  2, 2021, we entered into a share purchase agreement with Linksys (the “Share Purchase Agreement”), whereby we would invest an additional $85.0 million in Linksys (the “Second Tranche Investment”), subject to certain closing conditions. Following the closing of the Second Tranche Investment, we are expected to own 50.8% of the issued and outstanding capital stock of Linksys. We are evaluating the future accounting impact of this additional investment on our condensed consolidated financial statements.
