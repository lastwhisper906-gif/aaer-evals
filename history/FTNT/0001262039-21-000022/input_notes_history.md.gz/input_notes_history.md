# FTNT note change history — 0001262039-21-000014 → 0001262039-21-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-02):
[0001262039-21-000022:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of June 30, 2021 (in millions):
  (was, 2021-05-03, similarity 0.9641):
[0001262039-21-000014:note_history:1]
COMMITMENTS AND CONTINGENCIES
The following table summarizes our inventory purchase commitments as of March 31, 2021 (in millions):

- changed (2021-08-02):
[0001262039-21-000022:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of June 30, 2021, we had $628.7 million of open purchase orders with our independent contract manufacturers that may not be cancelable.
  (was, 2021-05-03, similarity 0.9933):
[0001262039-21-000014:note_history:2]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers, which may not be cancelable. As of March 31, 2021, we had $298.8 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

- changed (2021-08-02):
[0001262039-21-000022:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of June 30, 2021, we had $67.9 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.
  (was, 2021-05-03, similarity 0.9885):
[0001262039-21-000014:note_history:3]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of March 31, 2021, we had $65.1 million in other contractual commitments having a remaining term in excess of one year that may not be cancelable.

- added (2021-08-02):
[0001262039-21-000022:note_history:4]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated

- changed (2021-08-02):
[0001262039-21-000022:note_history:5]
with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of June 30, 2021 and December 31, 2020.
  (was, 2021-05-03, similarity 0.7891):
[0001262039-21-000014:note_history:5]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of certain of these matters is currently not determinable and not predictable, we currently are unaware of any existing claims or proceedings that we believe are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any IP litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. Litigation is unpredictable and the actual liability in any such matters may be materially different from our current estimates, which could result in the need to adjust any accrued liability and record additional expenses. We accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. Litigation loss contingency accruals were not material as of March 31, 2021 and December 31, 2020.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-02):
[0001262039-21-000022:note_history:6]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and six months ended June 30, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.
  (was, 2021-05-03, similarity 0.9844):
[0001262039-21-000014:note_history:6]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2020, contained in our Annual Report on Form 10-K filed with the SEC on February 19, 2021. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three months ended March 31, 2021 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2020 is derived from the audited consolidated financial statements for the year ended December 31, 2020.

- added (2021-08-02):
[0001262039-21-000022:note_history:7]
Except for the update to the range of useful lives for property and equipment discussed in Note 6 and our policy election for how we account for our share of financial results for a specific investment in privately held companies on a three-month lag basis as discussed in Note 7, there have been no material changes to our significant accounting policies as of and for the three and six months ended June 30, 2021.

- removed (2021-08-02):
[0001262039-21-000014:note_history:8]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-02):
[0001262039-21-000022:note_history:9]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of June 30, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.
  (was, 2021-05-03, similarity 0.9962):
[0001262039-21-000014:note_history:9]
DEBT
On March 5, 2021, we issued $1.0 billion aggregate principal amount of senior notes (collectively, the “Senior Notes”), consisting of $500.0 million aggregate principal amount of 1.0% notes due March 15, 2026 (the “2026 Senior Notes”) and $500.0 million aggregate principal amount of 2.2% notes due March 15, 2031 (the “2031 Senior Notes”), in an underwritten registered public offering. The Senior Notes are senior unsecured obligations and rank equally with each other in right of payment and with our other outstanding obligations. We may redeem the Senior Notes at any time in whole or in part for cash, at specified redemption prices that include accrued and unpaid interest, if any, and a make-whole premium. However, no make-whole premium will be paid for redemptions of the 2026 Senior Notes on or after February 15, 2026, or the 2031 Senior Notes on or after December 15, 2030. Interest on the Senior Notes is payable on March 15 and September 15 of each year, beginning on September 15, 2021. As of March 31, 2021, the Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective contractual terms of these notes using the effective interest method.

- changed (2021-08-02):
[0001262039-21-000022:note_history:10]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (12.5) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.5 |  |
  (was, 2021-05-03, similarity 0.9878):
[0001262039-21-000014:note_history:10]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (13.0) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.0 |  |

- added (2021-08-02):
[0001262039-21-000022:note_history:11]
As of June 30, 2021 we accrued interest payable of $5.2 million, and there are no financial covenants with which we must comply. During the three and six months ended June 30, 2021 we recorded $4.5 million and $5.8 million of total interest

- added (2021-08-02):
[0001262039-21-000022:note_history:12]
expense in relation to these Senior Notes, respectively. No interest costs were capitalized for the three and six months ended June 30, 2021, as the costs that qualified for capitalization were not material.

- changed (2021-08-02):
[0001262039-21-000022:note_history:13]
The total estimated fair value of the outstanding Senior Notes was approximately $999.9 million, including accrued and unpaid interest, as of June 30, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.
  (was, 2021-05-03, similarity 0.9857):
[0001262039-21-000014:note_history:13]
The total estimated fair value of the outstanding Senior Notes was approximately $975.6 million, including accrued and unpaid interest, as of March 31, 2021. The fair value was determined based on observable market prices of identical instruments in less active markets. The estimated fair values are based on Level 2 inputs.

- removed (2021-08-02):
[0001262039-21-000014:note_history:14]
As of March 31, 2021 we accrued interest payable of $1.2 million, and there are no financial covenants with which we must comply. During the quarter ended March 31, 2021 we recorded $1.3 million of total interest expense in relation to these Senior Notes.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-02):
[0001262039-21-000022:note_history:15]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | June 30, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (12.5) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.5 |  |
  (was, 2021-05-03, similarity 0.9878):
[0001262039-21-000014:note_history:15]
|  | Maturity |  | Coupon Rate |  | Effective Interest Rate |  | March 31, 2021 |
| Debt |  |  |  |  |  |  |  |
| 2026 Senior Notes | March 2026 |  | 1.0 | % |  | 1.3 | % |  | $ | 500.0 |  |
| 2031 Senior Notes | March 2031 |  | 2.2 | % |  | 2.3 | % |  | 500.0 |  |
| Total debt |  |  |  |  |  |  | 1,000.0 |  |
| Less: Unamortized discount and debt issuance costs |  |  |  |  |  |  | (13.0) |  |
| Total long-term debt |  |  |  |  |  |  | $ | 987.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-08-02):
[0001262039-21-000022:note_history:16]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Product | $ | 298.3 |  |  | $ | 211.9 |  |  | $ | 539.0 |  |  | $ | 404.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 272.9 |  |  | 222.6 |  |  | 528.2 |  |  | 434.0 |  |
| Technical support and other | 229.9 |  |  | 183.1 |  |  | 444.2 |  |  | 357.1 |  |
| Total service revenue | 502.8 |  |  | 405.7 |  |  | 972.4 |  |  | 791.1 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |

- removed (2021-08-02):
[0001262039-21-000014:note_history:17]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 255.3 |  |  | 211.4 |  |  |  |  |  |
| Technical support and other | 214.3 |  |  | 174.0 |  |  |  |  |  |
| Total service revenue | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-02):
[0001262039-21-000022:note_history:18]
REVENUE RECOGNITION
We sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.
  (was, 2021-05-03, similarity 0.9779):
[0001262039-21-000014:note_history:18]
REVENUE RECOGNITIONWe sell cybersecurity solutions to a variety of organizations, such as enterprises, communication service providers, government organizations and small to medium-sized enterprises. Our revenue consists of product and service revenue. Product revenue is generated by our FortiGate network security products, our Fortinet Security Fabric platform products and other products. Service revenue relates to sales of our security subscription services, which mainly consists of our FortiGuard security solutions, as well as our FortiCare technical support services and other services.
Disaggregation of Revenue

- added (2021-08-02):
[0001262039-21-000022:note_history:19]
Disaggregation of Revenue

- added (2021-08-02):
[0001262039-21-000022:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30,2021 |  | June 30,2020 |  | June 30,2021 |  | June 30,2020 |
| Product | $ | 298.3 |  |  | $ | 211.9 |  |  | $ | 539.0 |  |  | $ | 404.2 |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 272.9 |  |  | 222.6 |  |  | 528.2 |  |  | 434.0 |  |
| Technical support and other | 229.9 |  |  | 183.1 |  |  | 444.2 |  |  | 357.1 |  |
| Total service revenue | 502.8 |  |  | 405.7 |  |  | 972.4 |  |  | 791.1 |  |
| Total revenue | $ | 801.1 |  |  | $ | 617.6 |  |  | $ | 1,511.4 |  |  | $ | 1,195.3 |  |

- changed (2021-08-02):
[0001262039-21-000022:note_history:21]
During the three months ended June 30, 2021 and June 30, 2020, we recognized $371.2 million and $302.0 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively. During the six months ended June 30, 2021 and June 30, 2020, we recognized $789.1 million and $645.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.
  (was, 2021-05-03, similarity 0.6117):
[0001262039-21-000014:note_history:21]
During the three months ended March 31, 2021 and March 31, 2020, we recognized $417.9 million and $343.3 million in service revenue that was included in the deferred revenue balance as of December 31, 2020 and December 31, 2019, respectively.

- changed (2021-08-02):
[0001262039-21-000022:note_history:22]
As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.91 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.53 billion as revenue over the next 12 months and the remainder thereafter.
  (was, 2021-05-03, similarity 0.9869):
[0001262039-21-000014:note_history:22]
As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was $2.75 billion, which was substantially comprised of deferred security subscription and technical support services revenue. We expect to recognize approximately $1.47 billion as revenue over the next 12 months and the remainder thereafter.

- changed (2021-08-02):
[0001262039-21-000022:note_history:23]
The allowance for credit losses was $2.7 million and $2.5 million as of June 30, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the six months ended June 30, 2021 and 2020.
  (was, 2021-05-03, similarity 0.8221):
[0001262039-21-000014:note_history:23]
The allowance for credit losses was $3.1 million and $2.5 million as of March 31, 2021 and December 31, 2020, respectively. Provisions, write-offs and recoveries were not material during the three months ended March 31, 2021 and 2020.

- added (2021-08-02):
[0001262039-21-000022:note_history:24]
Deferred Contract Costs

- changed (2021-08-02):
[0001262039-21-000022:note_history:25]
Amortization of deferred contract costs during the three months ended June 30, 2021 and 2020 were $42.1 million and $33.2 million, respectively. Amortization of deferred contract costs during the six months ended June 30, 2021 and 2020 were $81.8 million and $64.5 million, respectively.
  (was, 2021-05-03, similarity 0.6087):
[0001262039-21-000014:note_history:25]
Deferred Contract Costs
Amortization of deferred contract costs during the three months ended March 31, 2021 and 2020 were $39.7 million and $31.3 million, respectively.

- removed (2021-08-02):
[0001262039-21-000014:note_history:26]
|  | Three Months Ended |  |  |
|  | March 31,2021 |  | March 31,2020 |  |  |  |  |
| Product | $ | 240.7 |  |  | $ | 192.3 |  |  |  |  |  |
| Service: |  |  |  |  |  |  |  |
| Security subscription | 255.3 |  |  | 211.4 |  |  |  |  |  |
| Technical support and other | 214.3 |  |  | 174.0 |  |  |  |  |  |
| Total service revenue | 469.6 |  |  | 385.4 |  |  |  |  |  |
| Total revenue | $ | 710.3 |  |  | $ | 577.7 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-08-02):
[0001262039-21-000022:note_history:27]
SUBSEQUENT EVENTS
Investments in Linksys

- added (2021-08-02):
[0001262039-21-000022:note_history:28]
As discussed in Note 7, on March 19, 2021 we invested $75.0 million in Linksys. On August  2, 2021, we entered into a share purchase agreement with Linksys (the “Share Purchase Agreement”), whereby we would invest an additional $85.0 million in Linksys (the “Second Tranche Investment”), subject to certain closing conditions. Following the closing of the Second Tranche Investment, we are expected to own 50.8% of the issued and outstanding capital stock of Linksys. We are evaluating the future accounting impact of this additional investment on our condensed consolidated financial statements.
