# FTNT 8-K — 0001262039-16-000085 filed 2016-10-27

## item codes, every 8-K on or before 2016-11-08

- 2016-10-27 0001262039-16-000085 — 2.02, 9.01
- 2016-10-11 0001262039-16-000082 — 2.02, 9.01
- 2016-07-28 0001262039-16-000076 — 2.02, 9.01
- 2016-07-22 0001262039-16-000073 — 8.01, 9.01
- 2016-06-20 0001262039-16-000068 — 5.07
- 2016-06-07 0001193125-16-614788 — 8.01
- 2016-04-26 0001262039-16-000061 — 2.02, 9.01
- 2016-01-28 0001262039-16-000051 — 2.02, 9.01
- 2015-10-27 0001262039-15-000045 — 2.02
- 2015-10-22 0001262039-15-000042 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000041 — 5.02 — amendment, the index does not say of what
- 2015-10-22 0001262039-15-000039 — 2.02, 9.01
- 2015-09-28 0001262039-15-000034 — 5.02, 9.01
- 2015-09-22 0001262039-15-000031 — 9.01 — amendment of 0001193125-15-248065
- 2015-08-28 0001262039-15-000027 — 3.01, 5.02
- 2015-07-23 0001262039-15-000021 — 5.02
- 2015-07-22 0001262039-15-000019 — 2.02, 9.01
- 2015-07-08 0001193125-15-248065 — 2.01, 8.01, 9.01
- 2015-06-22 0001193125-15-229099 — 5.07
- 2015-06-19 0001193125-15-228428 — 5.02, 9.01
- 2015-04-20 0001262039-15-000014 — 2.02, 9.01
- 2015-01-28 0001262039-15-000005 — 2.02, 9.01
- 2014-10-22 0001262039-14-000036 — 2.02, 9.01
- 2014-07-23 0001262039-14-000030 — 2.02, 9.01
- 2014-06-24 0001262039-14-000027 — 5.07
- 2014-04-23 0001262039-14-000021 — 2.02, 9.01
- 2014-04-21 0001262039-14-000018 — 5.03, 9.01
- 2014-01-29 0001262039-14-000004 — 2.02, 9.01
- 2013-12-20 0001262039-13-000061 — 5.02, 9.01
- 2013-11-27 0001262039-13-000057 — 5.02, 7.01, 9.01
- 2013-11-12 0001445305-13-002993 — 5.02
- 2013-10-23 0001262039-13-000051 — 2.02, 9.01
- 2013-07-30 0001262039-13-000039 — 2.02, 9.01
- 2013-06-25 0001262039-13-000030 — 5.07
- 2013-04-30 0001262039-13-000023 — 2.02, 9.01
- 2013-04-19 0001262039-13-000020 — 5.02, 9.01
- 2013-04-19 0001262039-13-000018 — 5.02 — amendment of 0001262039-13-000020
- 2013-04-10 0001262039-13-000016 — 2.02, 9.01
- 2013-03-26 0001262039-13-000013 — 5.02
- 2013-01-30 0001262039-13-000005 — 2.02, 9.01
- 2013-01-24 0001262039-13-000002 — 5.02, 9.01
- 2012-10-16 0001262039-12-000048 — 2.02, 9.01
- 2012-10-01 0001262039-12-000045 — 5.02
- 2012-09-26 0001262039-12-000043 — 5.01
- 2012-07-25 0001262039-12-000038 — 2.02, 9.01
- 2012-07-19 0001262039-12-000034 — 5.02
- 2012-06-20 0001193125-12-275869 — 5.07
- 2012-04-27 0001262039-12-000029 — 5.02
- 2012-04-24 0001262039-12-000025 — 2.02, 9.01
- 2012-01-31 0001262039-12-000006 — 2.02, 9.01
- 2012-01-25 0001262039-12-000003 — 5.03
- 2011-10-24 0001262039-11-000036 — 2.02
- 2011-07-19 0001262039-11-000014 — 2.02, 9.01
- 2011-06-27 0001193125-11-174474 — 5.02, 5.07, 9.01
- 2011-04-27 0001193125-11-111938 — 2.02, 9.01
- 2011-01-25 0001193125-11-013914 — 2.02, 9.01
- 2010-10-21 0001193125-10-233676 — 2.02, 9.01
- 2010-09-02 0001193125-10-203099 — 8.01
- 2010-07-22 0001193125-10-163844 — 2.02, 9.01
- 2010-06-24 0001193125-10-146082 — 5.07
- 2010-04-28 0001193125-10-096698 — 2.02, 9.01
- 2010-02-09 0001193125-10-024614 — 8.01
- 2010-01-27 0001193125-10-014292 — 2.02, 9.01
- 2010-01-26 0001193125-10-013031 — 5.02, 9.01

## late-filing notifications on or before 2016-11-08

- none on or before 2016-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001262039-16-000085:8k_2_02:1]
EX-99.1
2
ftntq3-2016ex991.htm
EXHIBIT 99.1

[0001262039-16-000085:8k_2_02:2]
Exhibit

[0001262039-16-000085:8k_2_02:3]
Press Release

[0001262039-16-000085:8k_2_02:4]
| Investor Contact: |  | Media Contact: |
| Michelle Spolver |  | Sandra Wheatley |
| Fortinet, Inc. |  | Fortinet, Inc. |
| 408-486-7837 |  | 408-391-9408 |
| mspolver@fortinet.com |  | swheatley@fortinet.com |

[0001262039-16-000085:8k_2_02:5]
Fortinet Reports Third Quarter 2016 Financial Results

[0001262039-16-000085:8k_2_02:6]
•Revenue of $316.6 million, up 22% year over year

[0001262039-16-000085:8k_2_02:7]
•Billings of $347.5 million, up 16% year over year1

[0001262039-16-000085:8k_2_02:8]
•GAAP diluted net income per share $0.04

[0001262039-16-000085:8k_2_02:9]
•Non-GAAP diluted net income per share of $0.181

[0001262039-16-000085:8k_2_02:10]
•Cash flow from operations of $76.1 million

[0001262039-16-000085:8k_2_02:11]
•Free cash flow of $70.2 million1

[0001262039-16-000085:8k_2_02:12]
| • | Cash, cash equivalents and investments of $1.27 billion2 |

[0001262039-16-000085:8k_2_02:13]
| • | Deferred revenue of $934.8 million, up 32% year over year |

[0001262039-16-000085:8k_2_02:14]
SUNNYVALE, Calif. - October 27, 2016 - Fortinet® (NASDAQ: FTNT), a global leader in high performance cyber security solutions, today announced financial results for the third quarter ended September 30, 2016.

[0001262039-16-000085:8k_2_02:15]
“While our third quarter results were impacted by a moderated spending environment, extended sales cycles and sales execution challenges, we continued to outgrow the market, as well as add 9,000 new customers,” stated Ken Xie, founder, chairman and chief executive officer. “Fortinet remains in a position to benefit from key secular trends such as security vendor consolidation and next generation cloud architectures. We have a strong technology advantage and visionary roadmap in place to help us continue to grow our market position, address our large opportunity, and make progress towards achieving our long term margin targets.”

[0001262039-16-000085:8k_2_02:16]
Financial Highlights for the Third Quarter of 2016

[0001262039-16-000085:8k_2_02:17]
| • | Revenue: Total revenue was $316.6 million for the third quarter of 2016, an increase of 22% compared to $260.1 million in the same quarter of 2015. Within total revenue, product revenue was $128.0 million, an increase of 7% compared to $119.7 million in the same quarter of 2015. Service revenue was $188.7 million, an increase of 34% compared to $140.3 million in the same quarter of 2015. |

[0001262039-16-000085:8k_2_02:18]
| • | Billings1: Total billings were $347.5 million for the third quarter of 2016, an increase of 16% compared to $299.6 million in the same quarter of 2015. |

[0001262039-16-000085:8k_2_02:19]
| • | Deferred Revenue: Total deferred revenue was $934.8 million as of September 30, 2016, an increase of 32% compared to $706.9 million in the same quarter of 2015. Total |

[0001262039-16-000085:8k_2_02:20]
deferred revenue increased by $30.8 million compared to $904.0 million as of June 30, 2016.

[0001262039-16-000085:8k_2_02:21]
| • | Cash2 and Cash Flow: As of September 30, 2016, cash, cash equivalents and investments were $1.27 billion, compared to $1.22 billion as of June 30, 2016. In the third quarter of 2016, cash flow from operations was $76.1 million compared to $65.1 million in the same quarter of 2015. Free cash flow1 was $70.2 million during the third quarter of 2016 compared to $51.7 million in the same quarter of 2015. |

[0001262039-16-000085:8k_2_02:22]
| • | GAAP Operating Income or Loss: GAAP operating income was $5.5 million for the third quarter of 2016, representing a GAAP operating margin of 2%. GAAP operating loss was $1.8 million in the same quarter of 2015, representing a GAAP operating margin of -1%. |

[0001262039-16-000085:8k_2_02:23]
| • | Non-GAAP Operating Income1: Non-GAAP operating income was $45.9 million for the third quarter of 2016, representing a non-GAAP operating margin of 15%. Non-GAAP operating income was $36.4 million in the same quarter of 2015, representing a non-GAAP operating margin of 14%. |

[0001262039-16-000085:8k_2_02:24]
| • | GAAP Net Income and Diluted Net Income Per Share: GAAP net income was $6.3 million for the third quarter of 2016, compared to GAAP net income of $8.2 million for the same quarter of 2015. GAAP diluted net income per share was $0.04 for the third quarter of 2016. GAAP diluted net income per share was $0.05 in the third quarter of 2015. |

[0001262039-16-000085:8k_2_02:25]
| • | Non-GAAP Net Income and Diluted Net Income Per Share1: Non-GAAP net income was $32.2 million for the third quarter of 2016, compared to non-GAAP net income of $24.1 million for the same quarter of 2015. Non-GAAP diluted net income per share was $0.18 for the third quarter of 2016, compared to $0.14 in the same quarter of 2015. |

[0001262039-16-000085:8k_2_02:26]
1 A reconciliation of GAAP to non-GAAP financial and liquidity measures has been provided in the financial statement tables included in this press release. An explanation of these measures is also included below under the heading “Non-GAAP Financial Measures.”

[0001262039-16-000085:8k_2_02:27]
2 During the third quarter of 2016, we repurchased $25.0 million of our common stock under our share repurchase program. During the third quarter of 2015, there were no shares repurchased under our share repurchase program.

[0001262039-16-000085:8k_2_02:28]
Conference Call Details

[0001262039-16-000085:8k_2_02:29]
Fortinet will host a conference call today, October 27, 2016, at 1:30 p.m. Pacific Time (4:30 p.m. Eastern Time) to discuss its financial results. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID # 92898989. A live webcast of the conference call and supplemental slides will be accessible from the Investor Relations page of Fortinet's website at http://investor.fortinet.com and a replay will be archived and accessible at http://investor.fortinet.com/events.cfm.  A replay of this conference call can also be accessed through November 3, 2016, by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID# 92898989.

[0001262039-16-000085:8k_2_02:30]
Following Fortinet's financial results conference call, the Company will host an additional question-and-answer session at 3:30 p.m. Pacific Time (6:30 p.m. Eastern Time) to provide an opportunity for financial analysts and investors to ask more detailed questions. To access this call, dial (877) 303-6913 (domestic) or (224) 357-2188 (international) with conference ID #

[0001262039-16-000085:8k_2_02:31]
92905958. This follow-up call will be webcast live and accessible at http://investor.fortinet.com, and a replay will be archived and available after the call at http://investor.fortinet.com/events.cfm. A replay of this conference call will also be available through November 3, 2016 by dialing (855) 859-2056 (domestic) or (404) 537-3406 (international) with conference ID # 92905958.

[0001262039-16-000085:8k_2_02:32]
About Fortinet (www.fortinet.com)

[0001262039-16-000085:8k_2_02:33]
Fortinet (NASDAQ: FTNT) secures the largest enterprise, service provider, and government organizations around the world. Fortinet empowers its customers with intelligent, seamless protection across the expanding attack surface and the power to take on ever-increasing performance requirements of the borderless network -- today and into the future. Only the Fortinet Security Fabric architecture can deliver security without compromise to address the most critical security challenges, whether in networked, application, cloud or mobile environments. More than 290,000 customers worldwide trust Fortinet to protect their businesses. Learn more at http://www.fortinet.com, the Fortinet Blog, or FortiGuard Labs.

[0001262039-16-000085:8k_2_02:34]
#          #          #

[0001262039-16-000085:8k_2_02:35]
Copyright © 2016 Fortinet, Inc. All rights reserved. The symbols ® and ™ denote respectively federally registered trademarks and unregistered trademarks of Fortinet, Inc., its subsidiaries and affiliates. Fortinet's trademarks include, but are not limited to, the following: Fortinet, FortiGate, FortiGuard, FortiManager, FortiMail, FortiClient, FortiCloud, FortiCare, FortiAnalyzer, FortiReporter, FortiOS, FortiASIC, FortiWiFi, FortiSwitch, FortiVoIP, FortiBIOS, FortiLog, FortiResponse, FortiCarrier, FortiScan, FortiAP, FortiDB, FortiVoice and FortiWeb. Other trademarks belong to their respective owners.

[0001262039-16-000085:8k_2_02:36]
FTNT-F

[0001262039-16-000085:8k_2_02:37]
Forward-looking Statements

[0001262039-16-000085:8k_2_02:38]
This press release contains forward-looking statements that involve risks and uncertainties. These forward-looking statements include statements regarding our positions to benefit from market trends, to continue to grow our market position, address our market opportunity, and make progress towards achieving our long term margin targets. Although we attempt to be accurate in making forward-looking statements, it is possible that future circumstances might differ from the assumptions on which such statements are based. Important factors that could cause results to differ materially from the statements herein include the following: general economic risks; global economic conditions, including in Great Britain and Latin America, and foreign currency risks; increasing competitiveness in the security market; the dynamic nature of the security market; specific economic risks worldwide and in different geographies, and among different customer segments; uncertainty regarding increased business and renewals from existing customers; uncertainties around continued success in sales growth and market share gains; longer sales cycles, particularly for larger enterprise customers; failure to convert sales pipeline into final sales; risks associated with successful implementation of multiple integrated software products and other product functionality risks; sales and marketing execution risks, particularly in North America; execution risks around new product development and introductions and innovation; litigation and disputes and the potential cost, distraction and damage to sales and reputation caused thereby; market acceptance of new products and services; the ability to attract and retain personnel; changes in strategy; risks associated with management of growth; lengthy sales and implementation cycles, particularly in larger organizations; technological changes that make our products and services less competitive;

[0001262039-16-000085:8k_2_02:39]
Non-GAAP Financial Measures

[0001262039-16-000085:8k_2_02:40]
We have provided in this release financial information that has not been prepared in accordance with Generally Accepted Accounting Principles (GAAP). These non-GAAP financial and liquidity measures are not based on any standardized methodology prescribed by GAAP and are not necessarily comparable to similar measures presented by other companies. We use these non-GAAP financial measures internally in analyzing our financial results and believe they are useful to investors, as a supplement to GAAP measures, in evaluating our ongoing operational performance. We believe that the use of these non-GAAP financial measures provides an additional tool for investors to use in evaluating ongoing operating results and trends and in comparing our financial results with peer companies, many of which present similar non-GAAP financial measures to investors.

[0001262039-16-000085:8k_2_02:41]
Non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP. Investors are encouraged to review the reconciliation of these non-GAAP financial measures to their most directly comparable GAAP financial measures provided in the financial statement tables below.

[0001262039-16-000085:8k_2_02:42]
Billings (Non-GAAP). We define billings as revenue recognized in accordance with GAAP plus the change in deferred revenue from the beginning to the end of the period less any deferred revenue balances acquired from business combination(s) during the period. We consider billings to be a useful metric for management and investors because billings drive future revenue, which is an important indicator of the health and viability of our business. There are a number of limitations related to the use of billings instead of GAAP revenue. First, billings include amounts that have not yet been recognized as revenue and are impacted by the term of security and support agreements. Second, we may calculate billings in a manner that is different from peer companies that report similar financial measures. Management accounts for these limitations by providing specific information regarding GAAP revenue and evaluating billings together with GAAP revenue.

[0001262039-16-000085:8k_2_02:43]
Free cash flow (Non-GAAP). We define free cash flow as net cash provided by operating activities minus capital expenditures such as purchases of real estate and other property and equipment. We consider free cash flow to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business that, after the acquisition of property and equipment, can be used for strategic opportunities, including investing in our business, making strategic acquisitions, repurchasing outstanding common stock, and strengthening the balance sheet. Analysis of free cash flow facilitates management’s comparison of our operating results to those of our peer companies. A limitation of using free cash flow rather than the GAAP measure of net cash provided by operating activities as a means for evaluating liquidity is that free cash flow does not represent the total increase or decrease in the cash, cash equivalents and investments balance for the period because it excludes cash provided by or used for other investing and financing activities. Management accounts for this limitation by providing information about our capital expenditures and other

[0001262039-16-000085:8k_2_02:44]
investing and financing activities on the face of the cash flow statement and under the caption “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources” in our most recent Quarterly Report on Form 10-Q and Annual Report on Form 10-K.

[0001262039-16-000085:8k_2_02:45]
Non-GAAP operating income and operating margin. We define non-GAAP operating income as operating income or loss plus stock-based compensation, business acquisition-related charges, purchase accounting adjustments, impairment and amortization of acquired intangible assets, restructuring charges, expenses associated with the implementation of a new Enterprise Resource Planning (ERP) system, and, when applicable, any other significant non-recurring items in a given quarter. Non-GAAP operating margin is defined as non-GAAP operating income divided by GAAP revenue. We consider these non-GAAP financial measures to be useful metrics for management and investors because they exclude the items noted above so that our management and investors can compare our recurring core business operating results over multiple periods. There are a number of limitations related to the use of non-GAAP operating income instead of operating income or loss calculated in accordance with GAAP. First, non-GAAP operating income excludes the items noted above. Stock-based compensation has been and will continue to be, for the foreseeable future, a significant recurring expense in our business. Second, stock-based compensation is an important part of our employees’ compensation and may impact their performance. Third, the components of the costs that we exclude from our calculation of non-GAAP operating income may differ from the components that peer companies exclude when they report their non-GAAP results of operations. Management accounts for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP operating income and evaluating non-GAAP operating income together with operating income or loss calculated in accordance with GAAP.

[0001262039-16-000085:8k_2_02:46]
Non-GAAP net income and diluted net income per share. We define non-GAAP net income as net income plus the items noted above under non-GAAP operating income and operating margin, adjusted for the impact of the tax adjustment resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP effective tax rate. We define non-GAAP diluted net income per share as non-GAAP net income divided by the non-GAAP diluted weighted-average shares outstanding. We consider these non-GAAP financial measures to be useful metrics for management and investors for the same reasons that we use non-GAAP operating income and non-GAAP operating margin. However, in order to provide a more complete picture of our recurring core business operating results, we include in non-GAAP net income and non-GAAP diluted net income per share, the tax adjustment required resulting in an effective tax rate on a non-GAAP basis, which often differs from the GAAP tax rate. We believe the effective tax rates we used are reasonable estimates of normalized tax rates for our current and prior fiscal years under our global operating structure. The same limitations described above regarding our use of non-GAAP operating income and non-GAAP operating margin apply to our use of non-GAAP net income and non-GAAP diluted net income per share. We account for these limitations by providing specific information regarding the GAAP amounts excluded from non-GAAP net income and non-GAAP diluted net income per share and evaluating non-GAAP net income and non-GAAP diluted net income per share together with net income and diluted net income per share calculated in accordance with GAAP.

[0001262039-16-000085:8k_2_02:47]
FORTINET, INC.

[0001262039-16-000085:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001262039-16-000085:8k_2_02:49]
(Unaudited, in thousands)

[0001262039-16-000085:8k_2_02:50]
|  | September 30, 2016 |  | December 31, 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 647,513 |  |  | $ | 543,277 |  |
| Short-term investments | 382,909 |  |  | 348,074 |  |
| Accounts receivable—net | 238,988 |  |  | 259,563 |  |
| Inventory | 93,731 |  |  | 83,868 |  |
| Prepaid expenses and other current assets | 31,732 |  |  | 35,761 |  |
| Total current assets | 1,394,873 |  |  | 1,270,543 |  |
| LONG-TERM INVESTMENTS | 240,228 |  |  | 272,959 |  |
| DEFERRED TAX ASSETS | 189,434 |  |  | 119,216 |  |
| PROPERTY AND EQUIPMENT—net | 126,109 |  |  | 91,067 |  |
| OTHER INTANGIBLE ASSETS—net | 27,849 |  |  | 17,640 |  |
| GOODWILL | 14,553 |  |  | 4,692 |  |
| OTHER ASSETS | 17,114 |  |  | 14,393 |  |
| TOTAL ASSETS | $ | 2,010,160 |  |  | $ | 1,790,510 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 57,530 |  |  | $ | 61,500 |  |
| Accrued liabilities | 37,280 |  |  | 33,028 |  |
| Accrued payroll and compensation | 65,610 |  |  | 61,111 |  |
| Income taxes payable | 7,795 |  |  | 8,379 |  |
| Deferred revenue | 582,145 |  |  | 514,652 |  |
| Total current liabilities | 750,360 |  |  | 678,670 |  |
| DEFERRED REVENUE | 352,647 |  |  | 276,651 |  |
| INCOME TAX LIABILITIES | 67,996 |  |  | 60,624 |  |
| OTHER LIABILITIES | 16,069 |  |  | 19,188 |  |
| Total liabilities | 1,187,072 |  |  | 1,035,133 |  |
| STOCKHOLDERS' EQUITY: |  |  |  |
| Common stock | 173 |  |  | 171 |  |
| Additional paid-in capital | 779,669 |  |  | 687,658 |  |
| Accumulated other comprehensive income (loss) | 153 |  |  | (933 | ) |
| Retained earnings | 43,093 |  |  | 68,481 |  |
| Total stockholders’ equity | 823,088 |  |  | 755,377 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,010,160 |  |  | $ | 1,790,510 |  |

[0001262039-16-000085:8k_2_02:51]
FORTINET, INC.

[0001262039-16-000085:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001262039-16-000085:8k_2_02:53]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000085:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| REVENUE: |  |  |  |  |  |  |  |
| Product | $ | 127,972 |  |  | $ | 119,737 |  |  | $ | 389,185 |  |  | $ | 332,023 |  |
| Service | 188,674 |  |  | 140,331 |  |  | 523,428 |  |  | 380,716 |  |
| Total revenue | 316,646 |  |  | 260,068 |  |  | 912,613 |  |  | 712,739 |  |
| COST OF REVENUE: |  |  |  |  |  |  |  |
| Product 1 | 50,267 |  |  | 46,167 |  |  | 152,368 |  |  | 134,932 |  |
| Service 1 | 34,532 |  |  | 25,534 |  |  | 94,578 |  |  | 69,869 |  |
| Total cost of revenue | 84,799 |  |  | 71,701 |  |  | 246,946 |  |  | 204,801 |  |
| GROSS PROFIT: |  |  |  |  |  |  |  |
| Product | 77,705 |  |  | 73,570 |  |  | 236,817 |  |  | 197,091 |  |
| Service | 154,142 |  |  | 114,797 |  |  | 428,850 |  |  | 310,847 |  |
| Total gross profit | 231,847 |  |  | 188,367 |  |  | 665,667 |  |  | 507,938 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |
| Research and development 1 | 47,239 |  |  | 42,110 |  |  | 137,495 |  |  | 115,315 |  |
| Sales and marketing 1 | 154,831 |  |  | 120,994 |  |  | 463,628 |  |  | 333,531 |  |
| General and administrative 1 | 22,006 |  |  | 21,220 |  |  | 63,629 |  |  | 51,199 |  |
| Restructuring charges | 2,283 |  |  | 5,883 |  |  | 3,164 |  |  | 5,883 |  |
| Total operating expenses | 226,359 |  |  | 190,207 |  |  | 667,916 |  |  | 505,928 |  |
| OPERATING INCOME (LOSS) | 5,488 |  |  | (1,840 | ) |  | (2,249 | ) |  | 2,010 |  |
| INTEREST INCOME | 1,888 |  |  | 1,333 |  |  | 5,339 |  |  | 4,119 |  |
| OTHER EXPENSE—net | (787 | ) |  | (653 | ) |  | (3,449 | ) |  | (2,160 | ) |
| INCOME (LOSS) BEFORE INCOME TAXES | 6,589 |  |  | (1,160 | ) |  | (359 | ) |  | 3,969 |  |
| PROVISION FOR (BENEFIT FROM) INCOME TAXES | 298 |  |  | (9,329 | ) |  | (7,380 | ) |  | (6,552 | ) |
| NET INCOME | $ | 6,291 |  |  | $ | 8,169 |  |  | $ | 7,021 |  |  | $ | 10,521 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 173,335 |  |  | 171,648 |  |  | 172,212 |  |  | 169,898 |  |
| Diluted | 177,938 |  |  | 177,897 |  |  | 176,046 |  |  | 175,963 |  |
| 1 Includes stock-based compensation as follows: |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 309 |  |  | $ | 291 |  |  | $ | 887 |  |  | $ | 641 |  |
| Cost of service revenue | 2,238 |  |  | 1,849 |  |  | 6,495 |  |  | 5,141 |  |
| Research and development | 7,648 |  |  | 6,663 |  |  | 22,249 |  |  | 17,361 |  |
| Sales and marketing | 17,378 |  |  | 13,904 |  |  | 50,183 |  |  | 34,482 |  |
| General and administrative | 3,520 |  |  | 3,612 |  |  | 10,528 |  |  | 9,376 |  |
|  | $ | 31,093 |  |  | $ | 26,319 |  |  | $ | 90,342 |  |  | $ | 67,001 |  |

[0001262039-16-000085:8k_2_02:55]
FORTINET, INC.

[0001262039-16-000085:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001262039-16-000085:8k_2_02:57]
(Unaudited, in thousands)

[0001262039-16-000085:8k_2_02:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Net income | $ | 6,291 |  |  | $ | 8,169 |  |  | $ | 7,021 |  |  | $ | 10,521 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Unrealized gains (losses) on investments | (879 | ) |  | 337 |  |  | 1,670 |  |  | 400 |  |
| Tax provision (benefit) related to items of other comprehensive income | (308 | ) |  | 118 |  |  | 584 |  |  | 141 |  |
| Other comprehensive income (loss)—net of taxes | (571 | ) |  | 219 |  |  | 1,086 |  |  | 259 |  |
| Comprehensive income | $ | 5,720 |  |  | $ | 8,388 |  |  | $ | 8,107 |  |  | $ | 10,780 |  |

[0001262039-16-000085:8k_2_02:59]
FORTINET, INC.

[0001262039-16-000085:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001262039-16-000085:8k_2_02:61]
(Unaudited, in thousands)

[0001262039-16-000085:8k_2_02:62]
|  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 7,021 |  |  | $ | 10,521 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 34,896 |  |  | 22,206 |  |
| Amortization of investment premiums | 3,828 |  |  | 5,770 |  |
| Stock-based compensation | 90,342 |  |  | 67,001 |  |
| Other non-cash items—net | 4,846 |  |  | 2,681 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable—net | 12,788 |  |  | 20,923 |  |
| Inventory | (24,555 | ) |  | (12,427 | ) |
| Deferred tax assets | (35,005 | ) |  | (28,297 | ) |
| Prepaid expenses and other current assets | 4,301 |  |  | (7,806 | ) |
| Other assets | (2,595 | ) |  | (264 | ) |
| Accounts payable | (1,584 | ) |  | (9,842 | ) |
| Accrued liabilities | 598 |  |  | (3,296 | ) |
| Accrued payroll and compensation | 3,253 |  |  | (1,895 | ) |
| Other liabilities | (3,119 | ) |  | (1,232 | ) |
| Deferred revenue | 142,867 |  |  | 136,193 |  |
| Income taxes payable | 6,789 |  |  | 13,753 |  |
| Net cash provided by operating activities | 244,671 |  |  | 213,989 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of investments | (370,573 | ) |  | (329,687 | ) |
| Sales of investments | 21,805 |  |  | 35,384 |  |
| Maturities of investments | 344,959 |  |  | 364,256 |  |
| Purchases of property and equipment | (50,319 | ) |  | (29,013 | ) |
| Payments made in connection with business acquisition, net of cash acquired | (22,087 | ) |  | (38,025 | ) |
| Net cash provided by (used in) investing activities | (76,215 | ) |  | 2,915 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from issuance of common stock | 42,292 |  |  | 63,543 |  |
| Taxes paid related to net share settlement of equity awards | (29,886 | ) |  | (22,989 | ) |
| Repurchase and retirement of common stock | (75,000 | ) |  | — |  |
| Payments of debt assumed in connection with business acquisition | (1,626 | ) |  | — |  |
| Net cash provided by (used in) financing activities | (64,220 | ) |  | 40,554 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 104,236 |  |  | 257,458 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 543,277 |  |  | 283,254 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 647,513 |  |  | $ | 540,712 |  |

[0001262039-16-000085:8k_2_02:63]
Reconciliations of non-GAAP results of operations measures to the nearest comparable GAAP measures

[0001262039-16-000085:8k_2_02:64]
(Unaudited, in thousands, except per share amounts)

[0001262039-16-000085:8k_2_02:65]
Reconciliation of net cash provided by operating activities to free cash flow

[0001262039-16-000085:8k_2_02:66]
|  | Three Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| Net cash provided by operating activities | $ | 76,139 |  |  | $ | 65,065 |  |
| Less purchases of property and equipment | (5,920 | ) |  | (13,325 | ) |
| Free cash flow | $ | 70,219 |  |  | $ | 51,740 |  |

[0001262039-16-000085:8k_2_02:67]
Reconciliation of GAAP operating income or loss to Non-GAAP operating income, operating margin, net income and diluted net income per share

[0001262039-16-000085:8k_2_02:68]
|  | Three Months Ended September 30, 2016 |  | Three Months Ended September 30, 2015 |
|  | GAAP Results |  | Adjustments |  | Non-GAAP Results |  | GAAP Results |  | Adjustments |  | Non-GAAP Results |
| Operating income (loss) | $ | 5,488 |  |  | $ | 40,447 |  | (a) | $ | 45,935 |  |  | $ | (1,840 | ) |  | $ | 38,230 |  | (b) | $ | 36,390 |  |
| Operating margin | 2 | % |  |  |  | 15 | % |  | (1 | )% |  |  |  | 14 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | 31,093 |  |  |  |  |  |  | 26,319 |  |  |  |
| Amortization of acquired intangible assets |  |  | 2,839 |  |  |  |  |  |  | 1,319 |  |  |  |
| ERP-related expenses |  |  | 4,060 |  |  |  |  |  |  | 2,473 |  |  |  |
| Acquisition-related charges |  |  | — |  |  |  |  |  |  | 934 |  |  |  |
| Inventory fair value adjustment amortization |  |  | 172 |  |  |  |  |  |  | 1,302 |  |  |  |
| Restructuring charges |  |  | 2,283 |  |  |  |  |  |  | 5,883 |  |  |  |
| Tax adjustment |  |  | (14,555 | ) | (c) |  |  |  |  | (22,304 | ) | (c) |  |
| Net income | $ | 6,291 |  |  | $ | 25,892 |  |  | $ | 32,183 |  |  | $ | 8,169 |  |  | $ | 15,926 |  |  | $ | 24,095 |  |
| Diluted net income per share | $ | 0.04 |  |  |  |  | $ | 0.18 |  |  | $ | 0.05 |  |  |  |  | $ | 0.14 |  |
| Shares used in diluted net income per share calculations | 177,938 |  |  |  |  | 177,938 |  |  | 177,897 |  |  |  |  | 177,897 |  |

[0001262039-16-000085:8k_2_02:69]
(a) To exclude $31.1 million of stock-based compensation, $2.8 million of amortization of acquired intangible assets, $4.1 million of ERP-related expenses, $0.2 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition and $2.3 million of restructuring charges in the three months ended September 30, 2016.

[0001262039-16-000085:8k_2_02:70]
(b) To exclude $26.3 million of stock-based compensation, $1.3 million of amortization of acquired intangible assets, $2.5 million of ERP-related expenses, and $0.9 million in acquisition-related charges, $1.3 million of inventory fair value adjustment amortization recorded pursuant to our business acquisition, and $5.9 million of restructuring charges in the three months ended September 30, 2015.

[0001262039-16-000085:8k_2_02:71]
(c)  Non-GAAP financial information is adjusted to achieve an overall 33% and 35% effective tax rate in 2016 and 2015, respectively, on a non-GAAP basis, which differs from the GAAP effective tax rate.

[0001262039-16-000085:8k_2_02:72]
Billings Reconciliation

[0001262039-16-000085:8k_2_02:73]
|  | Three Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| Total revenue | $ | 316,646 |  |  | $ | 260,068 |  |
| Add increase in deferred revenue | 30,811 |  |  | 49,350 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | (9,800 | ) |
| Total billings | $ | 347,457 |  |  | $ | 299,618 |  |
