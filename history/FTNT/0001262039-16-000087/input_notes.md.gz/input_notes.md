# FTNT notes — 0001262039-16-000087


## ftnt:IncomeTaxBenefitFromStockOptionPlansTableTextBlock

[0001262039-16-000087:notes:1]
[same as prior period, unchanged from 0001262039-16-000079:notes:1]

[0001262039-16-000087:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Income tax benefit associated with stock-based compensation | $ | 8,223 |  |  | $ | 5,224 |  |  | $ | 22,961 |  |  | $ | 12,867 |  |


## ftnt:PresentationAndPreparationOfConsolidatedFinancialStatementsPolicyTextBlock

[0001262039-16-000087:notes:3]
Basis of Presentation and Preparation—The unaudited condensed consolidated financial statements of Fortinet, Inc. and its wholly-owned subsidiaries (collectively, “we,” “us” or “our”) have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information, as well as the instructions to Form 10-Q pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). Accordingly, they do not include all of the information and footnotes required by GAAP for complete financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the year ended December 31, 2015, contained in our Annual Report on Form 10-K (the “Form 10-K”) filed with the SEC on February 26, 2016. In the opinion of management, all adjustments, which includes normal recurring adjustments, considered necessary for a fair presentation have been included. All intercompany balances, transactions and cash flows have been eliminated. The results of operations for the three and nine months ended September 30, 2016 are not necessarily indicative of the results for the full year or for any future periods. The condensed consolidated balance sheet as of December 31, 2015 is derived from the audited consolidated financial statements for the year ended December 31, 2015.

[0001262039-16-000087:notes:4]
[same as prior period, unchanged from 0001262039-16-000079:notes:4]

[0001262039-16-000087:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended September 30, 2016, except for changes to our policy related to stock-based compensation expense. For more information, refer to the “Recently Adopted Accounting Standards.”


## ftnt:ScheduleOfAmortizedCostsUnrealizedGainsAndLossesAndFairValueOfAvailableForSaleSecuritiesTableTextBlock

[0001262039-16-000087:notes:6]
Our investments as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:7]
|  | September 30, 2016 |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | FairValue |
| Corporate debt securities | $ | 385,016 |  |  | $ | 425 |  |  | $ | (211 | ) |  | $ | 385,230 |  |
| Commercial paper | 127,059 |  |  | 18 |  |  | (43 | ) |  | 127,034 |  |
| Municipal bonds | 53,821 |  |  | 14 |  |  | (36 | ) |  | 53,799 |  |
| Certificates of deposit and term deposits (1) | 4,322 |  |  | — |  |  | — |  |  | 4,322 |  |
| U.S. government and agency securities | 52,686 |  |  | 72 |  |  | (6 | ) |  | 52,752 |  |
| Total available-for-sale securities | $ | 622,904 |  |  | $ | 529 |  |  | $ | (296 | ) |  | $ | 623,137 |  |

[0001262039-16-000087:notes:8]
[same as prior period, unchanged from 0001262039-16-000079:notes:8]

[0001262039-16-000087:notes:9]
[same as prior period, unchanged from 0001262039-16-000079:notes:9]


## ftnt:ScheduleofEmployeeServiceSharebasedCompensationAllocationofRecognizedPeriodCostsbyAwardTypeTableTextBlock

[0001262039-16-000087:notes:10]
[same as prior period, unchanged from 0001262039-16-000079:notes:12]

[0001262039-16-000087:notes:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| RSUs | $ | 27,342 |  |  | $ | 21,996 |  |  | $ | 79,244 |  |  | $ | 53,674 |  |
| Stock options | 1,516 |  |  | 2,669 |  |  | 5,062 |  |  | 9,141 |  |
| ESPP | 2,235 |  |  | 1,654 |  |  | 6,036 |  |  | 4,186 |  |
| Total stock-based compensation expense | $ | 31,093 |  |  | $ | 26,319 |  |  | $ | 90,342 |  |  | $ | 67,001 |  |


## ftnt:ScheduleofMajorCustomersbyAccountsReceivableTableTextBlock

[0001262039-16-000087:notes:12]
[same as prior period, unchanged from 0001262039-16-000079:notes:14]

[0001262039-16-000087:notes:13]
|  | September 30, 2016 |  | December 31, 2015 |
| Exclusive Networks Group | 20 | % |  | 23 | % |
| Fine Tec Computers | 12 | % |  | * |  |
| Ingram | 10 | % |  | * |  |

[0001262039-16-000087:notes:14]
[same as prior period, unchanged from 0001262039-16-000079:notes:16]


## ftnt:ScheduleofSharebasedCompensationSharesWithheldforTaxesTableTextBlock

[0001262039-16-000087:notes:15]
[same as prior period, unchanged from 0001262039-16-000079:notes:17]

[0001262039-16-000087:notes:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Shares withheld for taxes | 347 |  |  | 245 |  |  | 937 |  |  | 590 |  |
| Amount withheld for taxes | $ | 12,528 |  |  | $ | 11,628 |  |  | $ | 29,886 |  |  | $ | 22,989 |  |


## ftnt:ScheduleofSharebasedCompensationStockOptionsActivityAdditionalInformationTableTextBlock

[0001262039-16-000087:notes:17]
[same as prior period, unchanged from 0001262039-16-000079:notes:19]

[0001262039-16-000087:notes:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Weighted-average fair value per share granted | $ | 10.62 |  |  | $ | 15.89 |  |  | $ | 9.08 |  |  | $ | 13.60 |  |
| Intrinsic value of options exercised | $ | 9,340 |  |  | $ | 40,132 |  |  | $ | 35,593 |  |  | $ | 103,170 |  |
| Fair value of options vested | $ | 1,706 |  |  | $ | 2,491 |  |  | $ | 4,583 |  |  | $ | 9,001 |  |


## ftnt:ScheduleofSharebasedPaymentAwardEmployeeStockPurchasePlanAdditionalInformationTableTextBlock

[0001262039-16-000087:notes:19]
[same as prior period, unchanged from 0001262039-16-000079:notes:21]

[0001262039-16-000087:notes:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Weighted-average fair value per share granted | $ | 8.07 |  |  | $ | 11.42 |  |  | $ | 7.68 |  |  | $ | 8.23 |  |
| Shares issued under the ESPP | 537 |  |  | 337 |  |  | 1,151 |  |  | 764 |  |
| Weighted-average price per share issued | $ | 21.61 |  |  | $ | 28.05 |  |  | $ | 21.01 |  |  | $ | 24.30 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001262039-16-000087:notes:21]
[same as prior period, unchanged from 0001262039-16-000079:notes:23]

[0001262039-16-000087:notes:22]
[same as prior period, unchanged from 0001262039-16-000079:notes:24]

[0001262039-16-000087:notes:23]
On June 7, 2016, we completed our acquisition of AccelOps, Inc. (“AccelOps”), a provider of network security monitoring and analytics solutions for total cash consideration of $22.1 million, net of cash received. We believe this acquisition will extend the Fortinet Security Fabric (as defined below) by enhancing our network security visibility, security data analytics, and threat intelligence across multi-vendor solutions.

[0001262039-16-000087:notes:24]
The acquisition of AccelOps is accounted as a business combination in accordance with the Accounting Standards Codification Topic 805 “Business Combinations” (“ASC 805”) issued by the FASB. We use our best estimates and assumptions to assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date. We included acquisition-related costs of $0.3 million in general and administrative expenses. The total purchase price was allocated to AccelOps’ identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The acquisition also included a contingent obligation for up to $4.0 million in future earn out payments to certain former stockholders of AccelOps if specified future financial targets are met for the three and six months period ended June 30, 2016 and December 31, 2016, respectively. The financial target for the three months period ended June 30, 2016 was not met.  As of September 30, 2016, no fair value was assigned to the contingent consideration based on the estimated probability of attainment of the remaining target. We will remeasure the contingent consideration during the contingency period for the remaining target, with changes in fair value to be recorded in our consolidated statements of operations.

[0001262039-16-000087:notes:25]
Total allocation of the purchase price was (in thousands):

[0001262039-16-000087:notes:26]
| Cash and cash equivalents | $ | 171 |  |
| Accounts receivable | 1,126 |  |
| Prepaid expenses and other assets | 430 |  |
| Property and equipment | 203 |  |
| Deferred tax assets | 3,435 |  |
| Finite-lived intangible assets | 14,900 |  |
| Indefinite-lived intangible assets in process research and development | 1,600 |  |
| Goodwill | 9,861 |  |
| Total assets acquired | 31,726 |  |
| Deferred revenue | 4,400 |  |
| Accounts payable and accrued liabilities | 3,348 |  |
| Other liabilities | 1,694 |  |
| Total liabilities assumed | 9,442 |  |
| Total purchase price allocation | $ | 22,284 |  |

[0001262039-16-000087:notes:27]
Finite-lived intangible assets consist of developed technology, customer relationships, and other intangible assets. AccelOps’ technology provides a software solution to manage security, performance and compliance from a single platform. The acquired developed technologies include software patents, know-how, process and designs. The value of customer relationships is attributable to the generation of a consistent income source and the avoidance of costs associated with creating new customer relationships.

[0001262039-16-000087:notes:28]
[same as prior period, unchanged from 0001262039-16-000079:notes:31]

[0001262039-16-000087:notes:29]
|  | Estimated Useful Life (in years) |  | Fair Values |
| Developed technologies | 4 |  | $ | 12,400 |  |
| Customer relationships | 3 |  | 2,300 |  |
| Other | 2 |  | 200 |  |
| Total |  |  | $ | 14,900 |  |

[0001262039-16-000087:notes:30]
The developed technologies and other are amortized on a straight-line basis. The amortization expense of developed technologies and other intangibles are recorded in cost of service revenue. The amortization expense of customer relationships is amortized on an accelerated basis and is recorded in sales and marketing expenses.

[0001262039-16-000087:notes:31]
[same as prior period, unchanged from 0001262039-16-000079:notes:30]

[0001262039-16-000087:notes:32]
The goodwill of $9.9 million represents the amount of the purchase price in excess of the fair value of the net tangible liabilities assumed and intangible assets acquired, including AccelOps’ assembled workforce. The goodwill recorded as part of the AccelOps acquisition is not deductible for U.S. federal income tax purposes. The financial results of this acquisition are considered immaterial for purposes of pro forma financial disclosures.

[0001262039-16-000087:notes:33]
[same as prior period, unchanged from 0001262039-16-000079:notes:35]

[0001262039-16-000087:notes:34]
[same as prior period, unchanged from 0001262039-16-000079:notes:36]

[0001262039-16-000087:notes:35]
[same as prior period, unchanged from 0001262039-16-000079:notes:37]

[0001262039-16-000087:notes:36]
We accounted for this transaction as a business combination. During the three and nine months ended September 30, 2015, we included acquisition-related costs of $1.7 million in general and administrative expenses. The total purchase price was allocated to Meru’s identifiable tangible and intangible assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date.

[0001262039-16-000087:notes:37]
[same as prior period, unchanged from 0001262039-16-000079:notes:39]

[0001262039-16-000087:notes:38]
[same as prior period, unchanged from 0001262039-16-000079:notes:40]

[0001262039-16-000087:notes:39]
[same as prior period, unchanged from 0001262039-16-000079:notes:41]

[0001262039-16-000087:notes:40]
[same as prior period, unchanged from 0001262039-16-000079:notes:42]

[0001262039-16-000087:notes:41]
[same as prior period, unchanged from 0001262039-16-000079:notes:43]

[0001262039-16-000087:notes:42]
Customer relationships and trade name are amortized and the amortization expense is recorded in sales and marketing expenses in the condensed consolidated statement of operations. Developed technologies are amortized and the amortization expense is recorded in cost of product revenue in the condensed consolidated statement of operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001262039-16-000087:notes:43]
COMMITMENTS AND CONTINGENCIES

[0001262039-16-000087:notes:44]
Our future principal contractual obligations as of September 30, 2016 were (in thousands):

[0001262039-16-000087:notes:45]
|  | Total |  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |
| Operating lease commitments | $ | 74,107 |  |  | $ | 5,756 |  |  | $ | 17,678 |  |  | $ | 14,653 |  |  | $ | 12,359 |  |  | $ | 10,497 |  |  | $ | 13,164 |  |
| Inventory purchase commitments | 116,494 |  |  | 90,169 |  |  | 26,325 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments and open purchase orders | 48,864 |  |  | 33,805 |  |  | 11,466 |  |  | 2,451 |  |  | 855 |  |  | 287 |  |  | — |  |
| Total | $ | 239,465 |  |  | $ | 129,730 |  |  | $ | 55,469 |  |  | $ | 17,104 |  |  | $ | 13,214 |  |  | $ | 10,784 |  |  | $ | 13,164 |  |

[0001262039-16-000087:notes:46]
Operating Leases—We lease certain facilities under various non-cancelable operating leases, which expire through 2026. Certain leases require us to pay variable costs such as taxes, maintenance, and insurance. The terms of certain operating leases also provide for renewal options and escalation clauses. Rent expense was $6.1 million and $3.7 million during the three months ended September 30, 2016 and September 30, 2015, respectively. Rent expense was $14.7 million and $9.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively. Rent expense is recognized using the straight-line method over the term of the lease.

[0001262039-16-000087:notes:47]
Inventory Purchase Commitments—Our independent contract manufacturers procure components and build our products based on our forecasts. These forecasts are based on estimates of future demand for our products, which are in turn based on historical trends and an analysis from our sales and marketing organizations, adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to some of our independent contract manufacturers which may not be cancelable. As of September 30, 2016, we had $116.5 million of open purchase orders with our independent contract manufacturers that may not be cancelable.

[0001262039-16-000087:notes:48]
Other Contractual Commitments and Open Purchase Orders—In addition to commitments with contract manufacturers, we have open purchase orders and contractual obligations in the ordinary course of business for which we have not received goods or services. As of September 30, 2016, we had $48.9 million in other contractual commitments that may not be cancelable.

[0001262039-16-000087:notes:49]
Warranties—Accrued warranty activities are summarized as follows (in thousands):

[0001262039-16-000087:notes:50]
|  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
| Accrued warranty balance—beginning of the period | $ | 3,144 |  |  | $ | 4,269 |  |
| Warranty costs incurred | (2,260 | ) |  | (3,413 | ) |
| Provision for warranty for the period | 925 |  |  | 3,638 |  |
| Adjustment related to pre-existing warranties | (279 | ) |  | (94 | ) |
| Accrued warranty balance—end of the period | $ | 1,530 |  |  | $ | 4,400 |  |

[0001262039-16-000087:notes:51]
Litigation—We are involved in disputes, litigation, and other legal actions. For lawsuits where we are the defendant, we are in the process of defending these litigation matters, and while there can be no assurances and the outcome of these matters is currently not determinable, we currently believe that there are no existing claims or proceedings that are likely to have a material adverse effect on our financial position. There are many uncertainties associated with any litigation and these actions or other third-party claims against us may cause us to incur costly litigation fees, including contingent legal fees, costs and substantial settlement charges, and possibly subject us to damages and other penalties. In addition, the resolution of any intellectual property litigation may require us to make royalty payments, which could adversely affect our gross margins in future periods. If any of those events were to occur, our business, financial condition, results of operations, and cash flows could be adversely affected. The actual liability in any such matters may be materially different from our estimates, if any, which could result in the need to adjust the liability and record additional expenses. We have not recorded any significant accrual for loss contingencies associated with such legal proceedings; determined that a significant unfavorable outcome is probable or reasonably possible; or determined that the amount or range of any possible significant loss is reasonably estimable.

[0001262039-16-000087:notes:52]
Indemnification—Under the indemnification provisions of our standard sales contracts, we agree to defend our customers against third-party claims asserting various allegations such as product defects and infringement of certain intellectual property rights, which may include patents, copyrights, trademarks or trade secrets, and to pay judgments entered on such claims. In some contracts, our exposure under these indemnification provisions is limited by the terms of the contracts to certain defined limits, such as the total amount paid by our customer under the agreement. However, certain agreements include covenants, penalties and indemnification provisions including and beyond indemnification for third-party claims of intellectual property infringement and that could potentially expose us to losses in excess of the amount received under the agreement, and in some instances to potential liability that is not contractually limited. To date, there have been no material awards under such indemnification provisions.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001262039-16-000087:notes:53]
[same as prior period, unchanged from 0001262039-16-000079:notes:55]

[0001262039-16-000087:notes:54]
Our tax-deferred savings plan under our 401(k) Plan, permits participating employees to defer a portion of their pre-tax earnings. In Canada, we have a Group Registered Retirement Savings Plan program (the “RRSP”), which permits participants to make tax deductible contributions. Our board of directors approved 50% matching contributions on employee contributions up to 4% of each employee’s eligible earnings. Our matching contributions to the 401(k) Plan and RRSP for the three months ended September 30, 2016 and September 30, 2015 were $1.2 million and $0.9 million, respectively. Our matching contributions to the 401(k) Plan and RRSP during the nine months ended September 30, 2016 and September 30, 2015 were $3.4 million and $2.7 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001262039-16-000087:notes:55]
[same as prior period, unchanged from 0001262039-16-000079:notes:57]

[0001262039-16-000087:notes:56]
[same as prior period, unchanged from 0001262039-16-000079:notes:58]

[0001262039-16-000087:notes:57]
|  | September 30, 2016 |
|  | Unrealized Gains/Losses on Investments |  | Tax benefit (provision) related to items of other comprehensive income or loss |  | Total |
| Beginning balance at December 31, 2015 | $ | (1,437 | ) |  | $ | 504 |  |  | $ | (933 | ) |
| Other comprehensive income (loss) before reclassifications | 1,668 |  |  | (583 | ) |  | 1,085 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | 2 |  |  | (1 | ) |  | 1 |  |
| Net current-period other comprehensive income (loss) | 1,670 |  |  | (584 | ) |  | 1,086 |  |
| Ending balance at September 30, 2016 | $ | 233 |  |  | $ | (80 | ) |  | $ | 153 |  |

[0001262039-16-000087:notes:58]
[same as prior period, unchanged from 0001262039-16-000079:notes:60]

[0001262039-16-000087:notes:59]
| Nine Months Ended September 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  | Affected Line Item in the Statement Where Net Income is Presented |
| Unrealized losses on investments | $ | 2 |  |  | Other expense—net |
| Tax benefit related to items of other comprehensive loss | (1 | ) |  | Provision for income taxes |
| Total reclassification for the period | $ | 1 |  |  |  |


## us-gaap:CostMethodInvestmentsDescriptionTextBlock

[0001262039-16-000087:notes:60]
[same as prior period, unchanged from 0001262039-16-000079:notes:62]

[0001262039-16-000087:notes:61]
Our investments in the equity securities of three privately-held companies totaled $10.3 million as of September 30, 2016 and December 31, 2015. Each of these investments are accounted for as cost-basis investments, as we own less than 20% of the voting securities and do not have the ability to exercise significant influence over operating and financial policies of the respective entities. These investments are carried at historical cost and are recorded as Other assets on our condensed consolidated balance sheet and would be measured at fair value if indicators of impairment exist. As of September 30, 2016, no events have occurred that would adversely affect the carrying value of these investments.

[0001262039-16-000087:notes:62]
[same as prior period, unchanged from 0001262039-16-000079:notes:64]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001262039-16-000087:notes:63]
[same as prior period, unchanged from 0001262039-16-000079:notes:65]

[0001262039-16-000087:notes:64]
[same as prior period, unchanged from 0001262039-16-000079:notes:66]

[0001262039-16-000087:notes:65]
We have stock-based compensation plans pursuant to which we have granted stock options and RSUs and PSUs. We also have an ESPP for all eligible employees.  As of September 30, 2016, there were a total of 44,406,659 shares of common stock available for grant under our stock-based compensation plans.

[0001262039-16-000087:notes:66]
[same as prior period, unchanged from 0001262039-16-000079:notes:68]

[0001262039-16-000087:notes:67]
[same as prior period, unchanged from 0001262039-16-000079:notes:69]

[0001262039-16-000087:notes:68]
|  | Restricted Stock Units Outstanding |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance—December 31, 2015 | 9,257 |  |  | $ | 32.97 |  |
| Granted | 4,867 |  |  | 27.54 |  |
| Forfeited | (1,270 | ) |  | 32.12 |  |
| Vested | (2,864 | ) |  | 30.37 |  |
| Balance—September 30, 2016 | 9,990 |  |  | $ | 30.99 |  |

[0001262039-16-000087:notes:69]
As of September 30, 2016, total compensation expense related to unvested RSUs, including PSUs, that were granted to employees and non-employees, but not yet recognized, was $273.0 million. This expense is expected to be amortized on a straight-line basis over a weighted-average vesting period of 2.85 years. We did not grant any PSUs during the three and nine months ended September 30, 2016. The stock-based compensation expense related to PSU awards is not material.

[0001262039-16-000087:notes:70]
[same as prior period, unchanged from 0001262039-16-000079:notes:72]

[0001262039-16-000087:notes:71]
[same as prior period, unchanged from 0001262039-16-000079:notes:73]

[0001262039-16-000087:notes:72]
The weighted-average assumptions relating to our employee stock options were:

[0001262039-16-000087:notes:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Expected term in years | 4.3 |  |  | 4.3 |  |  | 4.3 |  |  | 4.3 |  |
| Volatility | 38 | % |  | 37 | % |  | 42 | % |  | 38 | % |
| Risk-free interest rate | 1.1 | % |  | 1.6 | % |  | 1.1 | % |  | 1.5 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-16-000087:notes:74]
[same as prior period, unchanged from 0001262039-16-000079:notes:74]

[0001262039-16-000087:notes:75]
|  | Options Outstanding |
|  | Numberof Shares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
| Balance—December 31, 2015 | 6,968 |  |  | $ | 20.03 |  |  |  |  |  |
| Granted | 1,405 |  |  | $ | 25.39 |  |  |  |  |  |
| Forfeited | (221 | ) |  | $ | 34.91 |  |  |  |  |  |
| Exercised | (1,750 | ) |  | $ | 10.37 |  |  |  |  |  |
| Balance—September 30, 2016 | 6,402 |  |  | $ | 23.33 |  |  | 3.22 |  | $ | 89,714 |  |
| Options exercisable—September 30, 2016 | 4,469 |  |  | $ | 21.26 |  |  | 1.99 |  | $ | 70,864 |  |

[0001262039-16-000087:notes:76]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our common stock on September 30, 2016, for all in-the-money options. As of September 30, 2016, total compensation expense related to unvested stock options granted to employees but not yet recognized was $16.8 million. This expense is expected to be amortized on a straight-line basis over a weighted-average period of 3.0 years.

[0001262039-16-000087:notes:77]
[same as prior period, unchanged from 0001262039-16-000079:notes:77]

[0001262039-16-000087:notes:78]
[same as prior period, unchanged from 0001262039-16-000079:notes:78]

[0001262039-16-000087:notes:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Expected term in years | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 34 | % |  | 32 | % |  | 39 | % |  | 31 | % |
| Risk-free interest rate | 0.5 | % |  | 0.2 | % |  | 0.4 | % |  | 0.1 | % |
| Dividend rate | — | % |  | — | % |  | — | % |  | — | % |

[0001262039-16-000087:notes:80]
[same as prior period, unchanged from 0001262039-16-000079:notes:81]

[0001262039-16-000087:notes:81]
[same as prior period, unchanged from 0001262039-16-000079:notes:82]

[0001262039-16-000087:notes:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Cost of product revenue | $ | 309 |  |  | $ | 291 |  |  | $ | 887 |  |  | $ | 641 |  |
| Cost of service revenue | 2,238 |  |  | 1,849 |  |  | 6,495 |  |  | 5,141 |  |
| Research and development | 7,648 |  |  | 6,663 |  |  | 22,249 |  |  | 17,361 |  |
| Sales and marketing | 17,378 |  |  | 13,904 |  |  | 50,183 |  |  | 34,482 |  |
| General and administrative | 3,520 |  |  | 3,612 |  |  | 10,528 |  |  | 9,376 |  |
| Total stock-based compensation expense | $ | 31,093 |  |  | $ | 26,319 |  |  | $ | 90,342 |  |  | $ | 67,001 |  |

[0001262039-16-000087:notes:83]
[same as prior period, unchanged from 0001262039-16-000079:notes:84]

[0001262039-16-000087:notes:84]
In January 2016, our board of directors approved a new Share Repurchase Program (the “Program”), which authorizes the repurchase of up to $200.0 million of our outstanding common stock through December 31, 2017. Under the Program, share repurchases may be made by us from time to time in privately negotiated transactions or in open market transactions. The Program does not require us to purchase a minimum number of shares, and may be suspended, modified or discontinued at any time without prior notice. During the three and nine months ended September 30, 2016, we repurchased 0.7 million and  2.7 million shares of common stock under the Program, respectively, in open market transactions at an average price of $36.04 and $27.82 per share, respectively, for an aggregate purchase price of $25.0 million and $75.0 million, respectively. As of September 30, 2016, $125.0 million remained available for future share repurchases under the Program.


## us-gaap:EarningsPerShareTextBlock

[0001262039-16-000087:notes:85]
NET INCOME PER SHARE

[0001262039-16-000087:notes:86]
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income  by the weighted-average number of shares of common stock outstanding, plus the dilutive effects of stock options, RSUs including performance stock units (“PSUs”), and our employee stock purchase plan (“ESPP”). Dilutive shares of common stock are determined by applying the treasury stock method.

[0001262039-16-000087:notes:87]
A reconciliation of the numerator and denominator used in the calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001262039-16-000087:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 6,291 |  |  | $ | 8,169 |  |  | $ | 7,021 |  |  | $ | 10,521 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 173,335 |  |  | 171,648 |  |  | 172,212 |  |  | 169,898 |  |
| Diluted shares: |  |  |  |  |  |  |  |
| Weighted-average common stock outstanding-basic | 173,335 |  |  | 171,648 |  |  | 172,212 |  |  | 169,898 |  |
| Effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 2,009 |  |  | 3,451 |  |  | 1,867 |  |  | 3,669 |  |
| RSUs (including PSUs) | 2,513 |  |  | 2,742 |  |  | 1,891 |  |  | 2,335 |  |
| ESPP | 81 |  |  | 56 |  |  | 76 |  |  | 61 |  |
| Weighted-average shares used to compute diluted net income per share | 177,938 |  |  | 177,897 |  |  | 176,046 |  |  | 175,963 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |
| Diluted | $ | 0.04 |  |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |

[0001262039-16-000087:notes:89]
The following potentially dilutive shares of common stock were excluded from the computation of diluted net income per share for the periods presented, as their effect would have been antidilutive (in thousands):

[0001262039-16-000087:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Stock options | 836 |  |  | 265 |  |  | 1,067 |  |  | 271 |  |
| RSUs (including PSUs) | 2,409 |  |  | 1,331 |  |  | 3,946 |  |  | 1,026 |  |
| ESPP | 353 |  |  | 209 |  |  | 211 |  |  | 126 |  |
|  | 3,598 |  |  | 1,805 |  |  | 5,224 |  |  | 1,423 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001262039-16-000087:notes:91]
[same as prior period, unchanged from 0001262039-16-000079:notes:92]

[0001262039-16-000087:notes:92]
The gross unrealized losses and the related fair values of our investments that have been in a continuous unrealized loss position as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:93]
|  | September 30, 2016 |
|  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
|  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |  | FairValue |  | UnrealizedLosses |
| Corporate debt securities | $ | 157,390 |  |  | $ | (188 | ) |  | $ | 37,548 |  |  | $ | (22 | ) |  | $ | 194,938 |  |  | $ | (210 | ) |
| Commercial paper | 19,320 |  |  | (43 | ) |  | — |  |  | — |  |  | 19,320 |  |  | (43 | ) |
| Municipal bonds | 36,163 |  |  | (37 | ) |  | — |  |  | — |  |  | 36,163 |  |  | (37 | ) |
| U.S. government and agency securities | 5,492 |  |  | (6 | ) |  | — |  |  | — |  |  | 5,492 |  |  | (6 | ) |
| Total available-for-sale securities | $ | 218,365 |  |  | $ | (274 | ) |  | $ | 37,548 |  |  | $ | (22 | ) |  | $ | 255,913 |  |  | $ | (296 | ) |

[0001262039-16-000087:notes:94]
[same as prior period, unchanged from 0001262039-16-000079:notes:95]

[0001262039-16-000087:notes:95]
The contractual maturities of our investments as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:96]
|  | September 30, 2016 |  | December 31, 2015 |
| Due within one year | $ | 382,909 |  |  | $ | 348,074 |  |
| Due within one to three years | 240,228 |  |  | 272,959 |  |
| Total | $ | 623,137 |  |  | $ | 621,033 |  |

[0001262039-16-000087:notes:97]
[same as prior period, unchanged from 0001262039-16-000079:notes:98]

[0001262039-16-000087:notes:98]
The unrealized losses on our available-for-sale securities were caused by fluctuations in market value and interest rates as a result of the economic environment. As the decline in market value are attributable to changes in market conditions and not credit quality, and because we have concluded currently that we neither intend to sell nor is it more likely than not that we will be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of September 30, 2016.

[0001262039-16-000087:notes:99]
[same as prior period, unchanged from 0001262039-16-000079:notes:100]

[0001262039-16-000087:notes:100]
[same as prior period, unchanged from 0001262039-16-000079:notes:101]

[0001262039-16-000087:notes:101]
[same as prior period, unchanged from 0001262039-16-000079:notes:102]

[0001262039-16-000087:notes:102]
[same as prior period, unchanged from 0001262039-16-000079:notes:103]

[0001262039-16-000087:notes:103]
[same as prior period, unchanged from 0001262039-16-000079:notes:104]

[0001262039-16-000087:notes:104]
[same as prior period, unchanged from 0001262039-16-000079:notes:105]

[0001262039-16-000087:notes:105]
[same as prior period, unchanged from 0001262039-16-000079:notes:106]

[0001262039-16-000087:notes:106]
[same as prior period, unchanged from 0001262039-16-000079:notes:107]

[0001262039-16-000087:notes:107]
[same as prior period, unchanged from 0001262039-16-000079:notes:108]

[0001262039-16-000087:notes:108]
The fair values of our financial assets measured at fair value on a recurring basis as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:109]
|  | September 30, 2016 |  |  |  | December 31, 2015 |  |  |
|  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |  | AggregateFairValue |  | QuotedPrices inActiveMarkets ForIdenticalAssets |  | SignificantOtherObservableRemainingInputs |  | SignificantOtherUnobservableRemainingInputs |
|  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  | (Level 1) |  | (Level 2) |  | (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 385,230 |  |  | $ | — |  |  | $ | 385,230 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |  | $ | 437,194 |  |  | $ | — |  |
| Commercial paper | 132,033 |  |  | — |  |  | 132,033 |  |  | — |  |  | 69,231 |  |  | — |  |  | 69,231 |  |  | — |  |
| Municipal bonds | 53,799 |  |  | — |  |  | 53,799 |  |  | — |  |  | 61,022 |  |  | — |  |  | 61,022 |  |  | — |  |
| Certificates of deposit and term deposits | 4,322 |  |  | — |  |  | 4,322 |  |  | — |  |  | 14,897 |  |  | — |  |  | 14,897 |  |  | — |  |
| Money market funds | 21,886 |  |  | 21,886 |  |  | — |  |  | — |  |  | 50,030 |  |  | 50,030 |  |  | — |  |  | — |  |
| U.S. government and agency securities | 52,752 |  |  | 42,243 |  |  | 10,509 |  |  | — |  |  | 41,688 |  |  | 25,693 |  |  | 15,995 |  |  | — |  |
| Total | $ | 650,022 |  |  | $ | 64,129 |  |  | $ | 585,893 |  |  | $ | — |  |  | $ | 674,062 |  |  | $ | 75,723 |  |  | $ | 598,339 |  |  | $ | — |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | 26,885 |  |  |  |  |  |  |  |  | $ | 53,029 |  |  |  |  |  |  |  |
| Short-term investments | 382,909 |  |  |  |  |  |  |  |  | 348,074 |  |  |  |  |  |  |  |
| Long-term investments | 240,228 |  |  |  |  |  |  |  |  | 272,959 |  |  |  |  |  |  |  |
| Total | $ | 650,022 |  |  |  |  |  |  |  |  | $ | 674,062 |  |  |  |  |  |  |  |

[0001262039-16-000087:notes:110]
There were no transfers between Level 1 and Level 2 of the fair value hierarchy during the nine months ended September 30, 2016.


## us-gaap:ForeignCurrencyDisclosureTextBlock

[0001262039-16-000087:notes:111]
[same as prior period, unchanged from 0001262039-16-000079:notes:112]

[0001262039-16-000087:notes:112]
Our sales contracts are primarily denominated in U.S. dollars and therefore substantially all of our revenue is not subject to foreign currency translation risk. However, a substantial portion of our operating expenses incurred outside the United States is denominated in foreign currencies and is subject to fluctuations due to changes in foreign currency exchange rates, particularly changes in the Canadian dollar (“CAD”), Euro (“EUR”), Great British pound (“GBP”), and Chinese yen (“CNY”). To help protect against significant fluctuations in value and the volatility of future cash flows caused by changes in currency exchange rates, we engage in foreign currency risk management activities to hedge balance sheet items denominated in CAD. We do not use these contracts for speculative or trading purposes. All of the derivative instruments are with high quality financial institutions and we monitor the creditworthiness of these parties. These contracts typically have maturities between one and three months. Changes in the fair value of forward exchange contracts related to balance sheet accounts are insignificant and are included in Other expense—net in the condensed consolidated statement of operations. As of September 30, 2016, the fair value of the forward exchange contracts was not material.

[0001262039-16-000087:notes:113]
[same as prior period, unchanged from 0001262039-16-000079:notes:114]

[0001262039-16-000087:notes:114]
The notional amount of forward exchange contracts to hedge balance sheet accounts as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:115]
|  | Buy/Sell |  | Notional |
| Balance Sheet Contracts: |  |  |  |
| Currency—As of September 30, 2016 |  |  |  |
| CAD | Sell |  | $ | 4,520 |  |
| Currency—As of December 31, 2015 |  |  |  |
| CAD | Sell |  | $ | 7,011 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001262039-16-000087:notes:116]
[same as prior period, unchanged from 0001262039-16-000079:notes:117]

[0001262039-16-000087:notes:117]
[same as prior period, unchanged from 0001262039-16-000079:notes:118]

[0001262039-16-000087:notes:118]
[same as prior period, unchanged from 0001262039-16-000079:notes:119]

[0001262039-16-000087:notes:119]
|  | Amount |
| Balance—December 31, 2015 | $ | 4,692 |  |
| Addition due to business acquisition | 9,861 |  |
| Balance—September 30, 2016 | $ | 14,553 |  |

[0001262039-16-000087:notes:120]
There were no impairments to goodwill during the three and nine months ended September 30, 2016.

[0001262039-16-000087:notes:121]
[same as prior period, unchanged from 0001262039-16-000079:notes:122]

[0001262039-16-000087:notes:122]
Other intangible assets—net as of September 30, 2016 and December 31, 2015 were (in thousands):

[0001262039-16-000087:notes:123]
|  | September 30, 2016 |
|  | Weighted-Average Useful Life (in Years) |  | Gross |  | Accumulated Amortization |  | Net |
| Other intangible assets—net: |  |  |  |  |  |  |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |
| Customer relationships | 4.7 |  | $ | 14,500 |  |  | $ | 4,735 |  |  | $ | 9,765 |  |
| Developed technologies and other | 3.8 |  | 23,984 |  |  | 7,500 |  |  | 16,484 |  |
|  |  |  | 38,484 |  |  | 12,235 |  |  | 26,249 |  |
| Indefinite-lived intangible assets: |  |  |  |  |  |  |  |
| In-process research and development |  |  | 1,600 |  |  | — |  |  | 1,600 |  |
| Total other intangible assets—net |  |  | $ | 40,084 |  |  | $ | 12,235 |  |  | $ | 27,849 |  |

[0001262039-16-000087:notes:124]
[same as prior period, unchanged from 0001262039-16-000079:notes:125]

[0001262039-16-000087:notes:125]
Amortization expense was $2.8 million and $1.3 million during the three months ended September 30, 2016 and September 30, 2015, respectively.  Amortization expense was $6.3 million and $1.9 million during the nine months ended September 30, 2016 and September 30, 2015, respectively. The following table summarizes estimated future amortization expense of Other intangible assets—net with finite lives (in thousands):

[0001262039-16-000087:notes:126]
|  | Amount |
| Years: |  |
| 2016 (remainder) | $ | 2,798 |  |
| 2017 | 8,450 |  |
| 2018 | 7,098 |  |
| 2019 | 5,540 |  |
| 2020 | 2,363 |  |
| Total | $ | 26,249 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001262039-16-000087:notes:127]
[same as prior period, unchanged from 0001262039-16-000079:notes:128]

[0001262039-16-000087:notes:128]
Our effective tax rate was 5% for the three months ended September 30, 2016, compared to an effective tax rate of 804% for the same period last year.  The effective tax rate was 2,053% for the nine months ended September 30, 2016, compared to an effective tax rate of -165% for the same period last year.  The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, foreign withholding taxes and foreign income taxes. The changes in the tax provision for the periods presented were primarily due to the tax benefit from the adoption of the new accounting guidance relating to stock-based compensation. The effective tax rate for the three months ended September 30, 2016 was an expense as compared to a benefit for the same period last year. The increase in effective tax rate for the nine months ended September 30, 2016 was primarily due to additional tax benefits from the adoption of the new accounting guidance relating to stock-based compensation.  As a result of the early adoption of the new guidance on stock-based compensation, we recorded income tax benefit of $2.5 million and $8.7 million during the three and nine months ended September 30, 2016, respectively.

[0001262039-16-000087:notes:129]
As of September 30, 2016 and December 31, 2015, unrecognized tax benefits were $64.9 million and $59.7 million, respectively. The total amount of $63.5 million in unrecognized tax benefits, if recognized, would favorably impact the effective tax rate. It is our policy to classify accrued interest and penalties related to unrecognized tax benefits in the provision for income taxes. As of September 30, 2016, we had accrued $8.8 million for estimated interest related to uncertain tax positions.

[0001262039-16-000087:notes:130]
We file income tax returns in the U.S. federal jurisdiction, and various U.S. state and foreign jurisdictions. The statute of limitations is open for years that generated state net operating loss carryforwards and after 2009 for state jurisdictions. Additionally, we have foreign net operating losses that have an indefinite life. Generally, we are no longer subject to non-U.S. income tax examinations by tax authorities for tax years prior to 2009. We are no longer subject to examination by U.S. federal tax authorities for tax years prior to 2012. We are currently under examination by U.S federal income tax authorities for the tax years 2012, 2013, and 2014. In addition, the tax authorities in France are examining the inter-company relationship between Fortinet, Inc., Fortinet France and Fortinet Singapore. We are in the early stages of this inquiry and as of yet no official audit has been opened. We are also under audit by the Japanese tax authorities for the years 2013, 2014 and 2015. We do not expect any material adjustments as a result of this audit.


## us-gaap:InventoryDisclosureTextBlock

[0001262039-16-000087:notes:131]
[same as prior period, unchanged from 0001262039-16-000079:notes:132]

[0001262039-16-000087:notes:132]
Our inventory as of September 30, 2016 and December 31, 2015 consisted of (in thousands):

[0001262039-16-000087:notes:133]
|  | September 30, 2016 |  | December 31, 2015 |
| Raw materials | $ | 19,690 |  |  | $ | 15,425 |  |
| Finished goods | 74,041 |  |  | 68,443 |  |
| Inventory | $ | 93,731 |  |  | $ | 83,868 |  |

[0001262039-16-000087:notes:134]
Inventory includes finished goods held by distributors where revenue is recognized on a sell-through basis of $1.4 million and $1.1 million as of September 30, 2016 and December 31, 2015, respectively. Inventory also includes materials at contract manufacturers of $6.3 million and $4.9 million as of September 30, 2016 and December 31, 2015, respectively.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001262039-16-000087:notes:135]
| Property and Equipment—net | September 30, 2016 |  | December 31, 2015 |
| Americas: |  |  |  |
| United States | $ | 92,096 |  |  | $ | 61,064 |  |
| Other Americas | 9,872 |  |  | 8,972 |  |
| Total Americas | 101,968 |  |  | 70,036 |  |
| EMEA: |  |  |  |
| France | 13,649 |  |  | 13,201 |  |
| Other EMEA | 6,199 |  |  | 3,977 |  |
| Total EMEA | 19,848 |  |  | 17,178 |  |
| APAC | 4,293 |  |  | 3,853 |  |
| Total property and equipment—net | $ | 126,109 |  |  | $ | 91,067 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001262039-16-000087:notes:136]
Recently Adopted Accounting Standards

[0001262039-16-000087:notes:137]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-09—Compensation—Stock Compensation—Improvements to Employee Share-Based Payment Accounting (“ASU 2016-09”). The new guidance changes the accounting for certain aspects of stock-based payments to employees and requires excess tax benefits and tax deficiencies to be recorded in the income statement when the awards vest or are settled. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows. The standard also allows us to repurchase more of an employee’s shares for tax withholding purposes without triggering liability accounting, clarifies that all cash payments made on an employee’s behalf for withheld shares should be presented as a financing activity on our cash flows statement, and provides an accounting policy election to account for forfeitures as they occur.

[0001262039-16-000087:notes:138]
We elected to early adopt the new guidance in the second quarter of 2016. The primary impact of the adoption was the recognition of excess tax benefits in our provision for income taxes rather than paid-in capital, as well as the adjustment in stock-based compensation expense as a result of our change in forfeiture policy. The new guidance eliminates the requirement to delay the recognition of excess tax benefits until it reduces current taxes payable. We adopted this change on a modified retrospective basis, and recorded unrecognized excess tax benefits of $32.4 million as a cumulative-effect adjustment, which increased retained earnings on January 1, 2016. The new guidance also requires us to record, subsequent to the adoption, excess tax benefits and tax deficiencies in the period these arise. As a result, our provision for income taxes decreased by $3.6 million during the first quarter of 2016.

[0001262039-16-000087:notes:139]
Under the new guidance, we have elected to change our policy and have started to recognize forfeitures of awards as they occur. The change in forfeiture policy was adopted using a modified retrospective transition method. We recorded a cumulative-effect adjustment to decrease retained earnings by $0.8 million upon transition on January 1, 2016 and a retrospective decrease of stock-based compensation of $2.0 million during the first quarter of 2016.

[0001262039-16-000087:notes:140]
The amendment to the minimum statutory withholding tax requirements was adopted on a modified retrospective basis. The adoption had no impact on the January 1, 2016 retained earnings. In addition, we adopted the presentation of taxes paid related to net share settlement of equity awards as a financing activity on the statement of cash flows on a retrospective basis.  Our adoption had no impact to any of the periods presented in our consolidated cash flows statements since such cash flows have historically been presented as a financing activity.

[0001262039-16-000087:notes:141]
The adoption of ASU 2016-09 impacted our previously reported quarterly results for the three months ended March 31, 2016, as well as our weighted average shares outstanding—diluted, as follows (in thousands, except for earnings per share):

[0001262039-16-000087:notes:142]
|  | Three Months Ended |
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Statements of Operations: |  |  |  |
| Stock-based compensation expense | $ | 30,881 |  |  | $ | 28,901 |  |
| Benefit from income taxes | $ | (1,809 | ) |  | $ | (5,376 | ) |
| Net income (loss) | $ | (3,429 | ) |  | $ | 2,118 |  |
| Net income (loss) per share—Basic | $ | (0.02 | ) |  | $ | 0.01 |  |
| Net income (loss) per share—Diluted | $ | (0.02 | ) |  | $ | 0.01 |  |
| Weighted-average shares outstanding—Diluted | 171,745 |  |  | 174,421 |  |

[0001262039-16-000087:notes:143]
|  | March 31, 2016 |
|  | As Reported |  | As Adjusted |
| Balance Sheets: |  |  |  |
| Deferred tax assets | $ | 131,696 |  |  | $ | 167,625 |  |
| Additional paid-in capital | $ | 718,849 |  |  | $ | 717,671 |  |
| Retained earnings | $ | 23,089 |  |  | $ | 60,196 |  |

[0001262039-16-000087:notes:144]
In September 2015, the FASB issued ASU 2015-16—Business Combinations—Simplifying the Accounting for Measurement-Period Adjustments, which eliminates the requirement for an acquirer in a business combination to account for measurement-period adjustments retrospectively. Instead, acquirers must recognize measurement-period adjustments during the period in which they determine the amounts, including the effect on earnings of any amounts they would have recorded in previous periods if the accounting had been completed at the acquisition date. We adopted ASU 2015-16 on January 1, 2016. The adoption of ASU 2015-16 has not had any impact on our consolidated financial statements.

[0001262039-16-000087:notes:145]
Recent Accounting Standards Not Yet Effective

[0001262039-16-000087:notes:146]
In October 2016, the FASB issued ASU 2016-16—Income Taxes —Intra-Entity Transfer of Assets Other Than Inventory, which requires the recognition of the income tax consequences of an intra-entity transfer of an asset, other than inventory, when the transfer occurs. ASU 2016-06 will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of adopting ASU 2016-16 on our consolidated financial statements.

[0001262039-16-000087:notes:147]
In August 2016, the FASB issued ASU 2016-15—Statement of Cash Flows—Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us beginning on January 1, 2018. Early adoption is permitted, including adoption in an interim period. We are currently evaluating the impact of adopting ASU 2016-15 on our consolidated financial statements.

[0001262039-16-000087:notes:148]
In June 2016, the FASB issued ASU 2016-13—Financial Instruments—Credit Losses—Measurement of Credit Losses on Financial Instruments, which requires measurement and recognition of expected credit losses for financial assets held. ASU 2016-13 is effective for us beginning on January 1, 2020, with the option to adopt early on January 1, 2019. We are currently evaluating the impact of ASU 2016-13 will have on our consolidated financial statements.

[0001262039-16-000087:notes:149]
In February 2016, the FASB issued ASU 2016-02—Leases, which amends lease accounting requirements to begin recording assets and liabilities arising from leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount, timing and uncertainty of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. We expect our assets and liabilities to increase as a result of the adoption of this standard. We are currently evaluating the impact of adopting ASU 2016-02 on our consolidated financial statements.

[0001262039-16-000087:notes:150]
In May 2014, the FASB issued ASU 2014-09—Revenue from Contracts with Customers, which creates a single, joint revenue standard that is consistent across all industries and markets for companies that prepare their financial statements in accordance with GAAP. Under ASU 2014-09, an entity is required to recognize revenue upon the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled to receive in exchange for those goods or services. In July 2015, the FASB decided to delay the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU 2016-08, which clarifies the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, which clarifies the implementation guidance on identifying performance obligations and licensing. In May 2016, the FASB issued ASU 2016-12—Revenue from Contracts with Customers—Narrow-scope Improvements and Practical Expedients, which amends the guidance on collectability, noncash consideration, presentation of sales tax and transition. These standards will be effective for us beginning on January 1, 2018. We are currently evaluating the impact of these new standards on our consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001262039-16-000087:notes:151]
[same as prior period, unchanged from 0001262039-16-000079:notes:151]

[0001262039-16-000087:notes:152]
Our property and equipment—net as of September 30, 2016 and December 31, 2015 consisted of (in thousands):

[0001262039-16-000087:notes:153]
|  | September 30, 2016 |  | December 31, 2015 |
| Land | $ | 31,251 |  |  | $ | 21,683 |  |
| Building and building improvements | 44,513 |  |  | 28,841 |  |
| Evaluation units | 17,633 |  |  | 15,784 |  |
| Computer equipment and software | 62,585 |  |  | 45,632 |  |
| Furniture and fixtures | 13,127 |  |  | 8,901 |  |
| Construction-in-progress | 4,365 |  |  | 8,106 |  |
| Leasehold improvements | 16,501 |  |  | 11,179 |  |
| Total property and equipment | 189,975 |  |  | 140,126 |  |
| Less: accumulated depreciation | (63,866 | ) |  | (49,059 | ) |
| Property and equipment—net | $ | 126,109 |  |  | $ | 91,067 |  |

[0001262039-16-000087:notes:154]
Depreciation expense was $10.2 million and $7.5 million during the three months ended September 30, 2016 and September 30, 2015, respectively.  Depreciation expense was $28.6 million and $20.3 million during the nine months ended September 30, 2016 and September 30, 2015, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001262039-16-000087:notes:155]
RELATED PARTY TRANSACTIONS

[0001262039-16-000087:notes:156]
The son of one member of our board of directors is a partner of an outside law firm that we utilize for certain complex litigation matters. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were not material during the three months ended September 30, 2016 and $0.9 million during the three months ended September 30, 2015.  No contingent fees were incurred during the three months ended September 30, 2016 and September 30, 2015. Expenses for legal services provided by the law firm related to matters that arose subsequent to the member joining our board of directors were $0.3 million and $3.7 million during the nine months ended September 30, 2016 and September 30, 2015, respectively.  Of such amounts, $0.5 million were incurred under contingent fee arrangements during the nine months ended September 30, 2015. No contingent fees were incurred during the nine months ended September 30, 2016. Amounts due and payable to the law firm were $0.1 million and $5.3 million as of September 30, 2016 and December 31, 2015, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001262039-16-000087:notes:157]
[same as prior period, unchanged from 0001262039-16-000079:notes:157]

[0001262039-16-000087:notes:158]
The following table provides a summary of restructuring activity for the nine months ended September 30, 2016 (in thousands):

[0001262039-16-000087:notes:159]
|  | Employee Severance and Other Benefits |  | Contract Terminations and Other Charges |  | Total |
| Balance as of December 31, 2015 | $ | 3,689 |  |  | $ | 229 |  |  | $ | 3,918 |  |
| Costs incurred | 3,120 |  |  | 44 |  |  | 3,164 |  |
| Less cash payments | (5,060 | ) |  | (273 | ) |  | (5,333 | ) |
| Less non-cash charges | (89 | ) |  | — |  |  | (89 | ) |
| Balance as of September 30, 2016 | $ | 1,660 |  |  | $ | — |  |  | $ | 1,660 |  |

[0001262039-16-000087:notes:160]
[same as prior period, unchanged from 0001262039-16-000079:notes:160]

[0001262039-16-000087:notes:161]
In connection with the acquisition of Meru, we initiated planned cost reduction and restructuring activities to improve our cost structure and operational efficiencies starting in the third quarter of 2015. To date, we have incurred $7.9 million of charges related to this restructuring. These charges are primarily related to severance payments to be paid in cash and are included in operating expense in the condensed consolidated statements of operations of the period when incurred. We incurred $0.1 million and $0.3 million of charges related to this restructuring during the three and nine months ended September 30, 2016, respectively, and these charges are included in operating expense in the condensed consolidated statements of operations. We do not anticipate incurring additional charges related to this restructuring.

[0001262039-16-000087:notes:162]
The remaining restructuring reserve of $1.1 million is included in accrued liabilities on the condensed consolidated balance sheet as of September 30, 2016 and is expected to be paid within one year.

[0001262039-16-000087:notes:163]
2016 Restructuring

[0001262039-16-000087:notes:164]
In the second and third quarter of 2016, we implemented a plan to restructure and further improve efficiencies in our operations due to the acquisition of AccelOps and certain other activities. We estimate that we will incur approximately $4.1 million of restructuring charges, primarily consisting of severance and other benefits, of which $2.2 million and $2.9 million were incurred during the three and nine months ended September 30, 2016, respectively, and are included in operating expense in the condensed consolidated statements of operations. We expect to incur the remaining charges in the fourth quarter of 2016.

[0001262039-16-000087:notes:165]
The remaining restructuring reserve of $0.6 million is included in accrued liabilities on the condensed consolidated balance sheet as of September 30, 2016 and is expected to be paid within one year.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001262039-16-000087:notes:166]
|  | Three Months Ended |  | Nine Months Ended |
| Revenue | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 83,049 |  |  | $ | 72,767 |  |  | $ | 239,417 |  |  | $ | 202,491 |  |
| Canada | 35,211 |  |  | 26,027 |  |  | 100,299 |  |  | 72,676 |  |
| Other Americas | 15,614 |  |  | 14,371 |  |  | 46,850 |  |  | 38,151 |  |
| Total Americas | 133,874 |  |  | 113,165 |  |  | 386,566 |  |  | 313,318 |  |
| Europe, Middle East, and Africa (“EMEA”) | 116,967 |  |  | 91,740 |  |  | 336,911 |  |  | 250,808 |  |
| Asia Pacific (“APAC”) | 65,805 |  |  | 55,163 |  |  | 189,136 |  |  | 148,613 |  |
| Total revenue | $ | 316,646 |  |  | $ | 260,068 |  |  | $ | 912,613 |  |  | $ | 712,739 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001262039-16-000087:notes:167]
[same as prior period, unchanged from 0001262039-16-000079:notes:167]

[0001262039-16-000087:notes:168]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Exclusive Networks Group | 19 | % |  | 17 | % |  | 19 | % |  | 17 | % |
| Ingram Micro | 10 | % |  | * |  |  | * |  |  | * |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001262039-16-000087:notes:169]
[same as prior period, unchanged from 0001262039-16-000079:notes:169]

[0001262039-16-000087:notes:170]
[same as prior period, unchanged from 0001262039-16-000079:notes:170]

[0001262039-16-000087:notes:171]
[same as prior period, unchanged from 0001262039-16-000079:notes:171]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001262039-16-000087:notes:172]
[same as prior period, unchanged from 0001262039-16-000079:notes:172]


## us-gaap:SubsequentEventsTextBlock

[0001262039-16-000087:notes:173]
SUBSEQUENT EVENT

[0001262039-16-000087:notes:174]
In October 2016, our board of directors authorized the repurchase of up to $100.0 million of shares of our common stock under the Program, increasing our current authorization to $300.0 million through December 2017.
