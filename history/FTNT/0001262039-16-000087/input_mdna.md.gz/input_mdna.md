# FTNT MD&A — 0001262039-16-000087


## mdna

[0001262039-16-000087:mdna:1]
[same as prior period, unchanged from 0001262039-16-000079:mdna:1]

[0001262039-16-000087:mdna:2]
[same as prior period, unchanged from 0001262039-16-000079:mdna:2]

[0001262039-16-000087:mdna:3]
[same as prior period, unchanged from 0001262039-16-000079:mdna:3]

[0001262039-16-000087:mdna:4]
[same as prior period, unchanged from 0001262039-16-000079:mdna:4]

[0001262039-16-000087:mdna:5]
| • | the impact of macro-economic and geopolitical factors on our international sales; |

[0001262039-16-000087:mdna:6]
| • | the proportion of our revenue that consists of our product and service revenue, and the mix of billings between products and services, and the duration of service contracts; |

[0001262039-16-000087:mdna:7]
[same as prior period, unchanged from 0001262039-16-000079:mdna:6]

[0001262039-16-000087:mdna:8]
[same as prior period, unchanged from 0001262039-16-000079:mdna:7]

[0001262039-16-000087:mdna:9]
| • | growing our sales to enterprise, service provider and government organizations, the impact of sales to these organizations on our long-term growth, expansion and operating results and the effectiveness of our internal sales organization; |

[0001262039-16-000087:mdna:10]
[same as prior period, unchanged from 0001262039-16-000079:mdna:9]

[0001262039-16-000087:mdna:11]
[same as prior period, unchanged from 0001262039-16-000079:mdna:10]

[0001262039-16-000087:mdna:12]
[same as prior period, unchanged from 0001262039-16-000079:mdna:11]

[0001262039-16-000087:mdna:13]
[same as prior period, unchanged from 0001262039-16-000079:mdna:12]

[0001262039-16-000087:mdna:14]
[same as prior period, unchanged from 0001262039-16-000079:mdna:13]

[0001262039-16-000087:mdna:15]
[same as prior period, unchanged from 0001262039-16-000079:mdna:14]

[0001262039-16-000087:mdna:16]
[same as prior period, unchanged from 0001262039-16-000079:mdna:15]

[0001262039-16-000087:mdna:17]
[same as prior period, unchanged from 0001262039-16-000079:mdna:16]

[0001262039-16-000087:mdna:18]
[same as prior period, unchanged from 0001262039-16-000079:mdna:17]

[0001262039-16-000087:mdna:19]
[same as prior period, unchanged from 0001262039-16-000079:mdna:18]

[0001262039-16-000087:mdna:20]
[same as prior period, unchanged from 0001262039-16-000079:mdna:19]

[0001262039-16-000087:mdna:21]
28

[0001262039-16-000087:mdna:22]
[same as prior period, unchanged from 0001262039-16-000079:mdna:20]

[0001262039-16-000087:mdna:23]
[same as prior period, unchanged from 0001262039-16-000079:mdna:21]

[0001262039-16-000087:mdna:24]
Our common operating system, centralized management and open application program interfaces allow many of the solutions in our portfolio to be combined to create an integrated security architecture (the “Fortinet Security Fabric”) designed to address sophisticated threats and next-generation environments. The Fortinet Security Fabric connects our products, services and ecosystem partner solutions to help provide seamless protection at all points in the network, from endpoint to data center to cloud, regardless of whether deployed in physical, virtual or hybrid environments. The Fortinet Security Fabric delivers integrated scalability, access, awareness, security and openness both from the cloud and for the cloud.  At the core of the Fortinet Security Fabric are our FortiGate physical and virtual appliances, which ship with a broad set of security services, including firewall, virtual private network, anti-malware, anti-spam, application control, intrusion prevention, web filtering and advanced threat protection. Many of these security services are enabled by our FortiGuard Labs team, which provides extensive threat research and a global cloud network to deliver subscription-based services to FortiGate appliances.

[0001262039-16-000087:mdna:25]
Enterprise customers select the form factor and deployment method that best meet their specific security requirements, such as a high-speed data center firewall at the network core, a next generation firewall at the edge, a distributed enterprise firewall at branch sites, or a virtual machine for virtual and cloud environments. Smaller businesses tend to deploy Unified Threat Management devices. We derive a substantial majority of product sales from our FortiGate appliances. End-customers may also purchase FortiManager and FortiAnalyzer products in conjunction with a FortiGate deployment to provide enterprise-class centralized management and analysis and reporting capabilities. We recently released our Security Information Event Management (“FortiSIEM”) offering to provide organizations with a broad, holistic and scalable solution for managing network security, performance and compliance standards across our and other vendor’s products. Finally, end-customers may purchase FortiCare technical support services for our products and FortiCare professional services to assist in the design, implementation and maintenance of their networks.

[0001262039-16-000087:mdna:26]
We complement our core FortiGate product line with other appliances and software licenses that offer additional protection from security threats to other critical areas of the enterprise, such as our secure wireless and access solution, advanced threat protection, secure email gateway, web application firewalls, application delivery controllers, database security, distributed denial of service protection, and endpoint security for employee computers and mobile devices. Sales of these complementary products have outpaced our overall growth in recent quarters.

[0001262039-16-000087:mdna:27]
[same as prior period, unchanged from 0001262039-16-000079:mdna:25]

[0001262039-16-000087:mdna:28]
| • | We recorded total revenue of $316.6 million and $912.6 million during the three and nine months ended September 30, 2016, respectively, an increase of 22% and 28%, respectively, compared to the same periods last year. Product revenue was $128.0 million and $389.2 million during the three and nine months ended September 30, 2016, respectively, an increase of 7% and 17%, respectively, compared to the same periods last year. Service revenue was $188.7 million and $523.4 million, respectively, during the three and nine months ended September 30, 2016, an increase of 34% and 37%, respectively, compared to the same periods last year. |

[0001262039-16-000087:mdna:29]
| • | Cash, cash equivalents and investments were $1.27 billion as of September 30, 2016, an increase of $106.3 million, or 9%, from December 31, 2015. |

[0001262039-16-000087:mdna:30]
| • | Deferred revenue was $934.8 million as of September 30, 2016, an increase of $143.5 million, or 18%, from December 31, 2015. |

[0001262039-16-000087:mdna:31]
| • | We generated cash flows from operating activities of $244.7 million during the nine months ended September 30, 2016, an increase of $30.7 million, or 14%, compared to the same period last year. |

[0001262039-16-000087:mdna:32]
Revenue grew during the three and nine months ended September 30, 2016 compared to the same periods last year, as our strategy to invest in sales and marketing has enabled us to continue to gain market share and customers. During the three months ended September 30, 2016, our revenue grew amidst a more moderate global spending environment as compared to last year. Our revenue growth was driven by greater sales of our FortiGate, FortiGuard and FortiCare offerings. Although we continued to see diversity of FortiGate product sales across all segments, the increase in product revenue was limited as we experienced North America sales execution issues, macro-economic challenges primarily related to Brexit in the United

[0001262039-16-000087:mdna:33]
Kingdom and geopolitical issues in Latin America. Our high-end FortiGate products (FortiGate-1000 to -7000 series) accounted for 37% of billings. Our mid-range products (FortiGate-200 to -900 series) accounted for 29% of billings, and our entry-level products (FortiGate-20 to -100 series) accounted for 34% of billings. Service revenue also increased as we continue to charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings. During the three months ended September 30, 2016, we continue to see the shift in the revenue mix trend, in which service revenue outpaced product revenue growth.

[0001262039-16-000087:mdna:34]
During the three and nine months ended September 30, 2016, operating expenses increased by 19% and 32%, respectively, as compared to the same period last year. The increase was primarily driven by our accelerated pace of hiring and investments made to expand our sales coverage, grow our marketing capabilities, develop new products and scale our customer support. We also continue to invest in research and development to strengthen our technology leadership position. We believe that continued product innovation has strengthened our technology and resulted in market share gains. In addition, we incurred expenses from business design and reengineering related to the implementation of a new ERP system. Headcount increased by 19% to 4,619 employees and contractors as of September 30, 2016, up from 3,889 as of September 30, 2015.

[0001262039-16-000087:mdna:35]
[same as prior period, unchanged from 0001262039-16-000079:mdna:33]

[0001262039-16-000087:mdna:36]
Our sales strategy is based on a distribution model whereby we primarily sell our products and services directly to distributors which sell to resellers and service providers, which, in turn, sell to our end-customers. In certain cases, we sell directly to government-focused resellers, large service providers and major systems integrators, which have significant purchasing power and unique customer deployment requirements. Typically, FortiGuard security subscription services and FortiCare technical support services are purchased along with our physical and virtual appliances, most frequently as part of a bundle offering that includes hardware and services. We invoice at the time of our sale for the total price of the products and subscription and technical support services, and the invoice is generally payable within 30 to 90 days. We generally recognize product revenue up-front and defer revenue for the sale of new, and renewal of existing, FortiGuard security subscription and FortiCare technical support services contracts. We recognize the related service revenue over the service period, which is typically one to three years, although it can be as long as five years. Sales of new and renewal services are a source of recurring revenue, as they increase our deferred revenue balance while also contributing positively to our gross margin and our cash flow from operations.

[0001262039-16-000087:mdna:37]
[same as prior period, unchanged from 0001262039-16-000079:mdna:35]

[0001262039-16-000087:mdna:38]
We monitor a number of financial and liquidity metrics, including the key financial metrics set forth below, in order to help us evaluate growth trends, establish budgets, measure the effectiveness of our sales and marketing efforts, and assess operational efficiencies. The following table summarizes revenue, deferred revenue, billings, cash, cash equivalents and investments, net cash provided by operating activities, and free cash flow. We discuss revenue below under “—Results of Operations,” and we discuss our cash, cash equivalents, and investments, and net cash provided by operating activities below under “—Liquidity and Capital Resources.” Deferred revenue, billings (non-GAAP) and free cash flow (non-GAAP) are discussed immediately below the following table.

[0001262039-16-000087:mdna:39]
|  | Three Months Ended Or As Of |
|  | September 30, 2016 |  | September 30, 2015 |
|  | (in thousands) |
| Revenue | $ | 316,646 |  |  | $ | 260,068 |  |
| Deferred revenue | $ | 934,792 |  |  | $ | 706,911 |  |
| Billings (Non-GAAP) | $ | 347,457 |  |  | $ | 299,618 |  |
| Cash, cash equivalents and investments | $ | 1,270,650 |  |  | $ | 1,169,664 |  |
| Net cash provided by operating activities | $ | 76,139 |  |  | $ | 65,065 |  |
| Free cash flow (Non-GAAP) | $ | 70,219 |  |  | $ | 51,740 |  |

[0001262039-16-000087:mdna:40]
[same as prior period, unchanged from 0001262039-16-000079:mdna:38]

[0001262039-16-000087:mdna:41]
[same as prior period, unchanged from 0001262039-16-000079:mdna:44]

[0001262039-16-000087:mdna:42]
[same as prior period, unchanged from 0001262039-16-000079:mdna:39]

[0001262039-16-000087:mdna:43]
[same as prior period, unchanged from 0001262039-16-000079:mdna:40]

[0001262039-16-000087:mdna:44]
|  | Three Months Ended |
| September 30, 2016 |  | September 30, 2015 |
| (in thousands) |
| Billings: |  |  |  |
| Revenue | $ | 316,646 |  |  | $ | 260,068 |  |
| Add increase in deferred revenue | 30,811 |  |  | 49,350 |  |
| Less deferred revenue balance acquired in business acquisition | — |  |  | (9,800 | ) |
| Total billings (Non-GAAP) | $ | 347,457 |  |  | $ | 299,618 |  |

[0001262039-16-000087:mdna:45]
[same as prior period, unchanged from 0001262039-16-000079:mdna:42]

[0001262039-16-000087:mdna:46]
|  | Three Months Ended |
| September 30, 2016 |  | September 30, 2015 |
| (in thousands) |
| Free Cash Flow: |  |  |  |
| Net cash provided by operating activities | $ | 76,139 |  |  | $ | 65,065 |  |
| Less purchases of property and equipment | (5,920 | ) |  | (13,325 | ) |
| Free cash flow (Non-GAAP) | $ | 70,219 |  |  | $ | 51,740 |  |

[0001262039-16-000087:mdna:47]
31

[0001262039-16-000087:mdna:48]
[same as prior period, unchanged from 0001262039-16-000079:mdna:45]

[0001262039-16-000087:mdna:49]
[same as prior period, unchanged from 0001262039-16-000079:mdna:46]

[0001262039-16-000087:mdna:50]
Except for the change in certain policies related to stock-based compensation as a result of the early adoption of ASU 2016-09, there have been no material changes to our critical accounting policies and estimates as of and for the three and nine months ended September 30, 2016, as compared to the critical accounting policies and estimates described in the Form 10-K. See Note 1 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for a discussion relating to our change in certain accounting policies related to stock-based compensation.

[0001262039-16-000087:mdna:51]
[same as prior period, unchanged from 0001262039-16-000079:mdna:48]

[0001262039-16-000087:mdna:52]
[same as prior period, unchanged from 0001262039-16-000079:mdna:49]

[0001262039-16-000087:mdna:53]
[same as prior period, unchanged from 0001262039-16-000079:mdna:58]

[0001262039-16-000087:mdna:54]
[same as prior period, unchanged from 0001262039-16-000079:mdna:50]

[0001262039-16-000087:mdna:55]
Three Months Ended September 30, 2016 and 2015

[0001262039-16-000087:mdna:56]
[same as prior period, unchanged from 0001262039-16-000079:mdna:52]

[0001262039-16-000087:mdna:57]
|  | Three Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 127,972 |  |  | 40 | % |  | $ | 119,737 |  |  | 46 | % |  | $ | 8,235 |  |  | 7 | % |
| Service | 188,674 |  |  | 60 |  |  | 140,331 |  |  | 54 |  |  | 48,343 |  |  | 34 |  |
| Total revenue | $ | 316,646 |  |  | 100 | % |  | $ | 260,068 |  |  | 100 | % |  | $ | 56,578 |  |  | 22 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 133,874 |  |  | 42 | % |  | $ | 113,165 |  |  | 44 | % |  | $ | 20,709 |  |  | 18 | % |
| EMEA | 116,967 |  |  | 37 |  |  | 91,740 |  |  | 35 |  |  | 25,227 |  |  | 27 |  |
| APAC | 65,805 |  |  | 21 |  |  | 55,163 |  |  | 21 |  |  | 10,642 |  |  | 19 |  |
| Total revenue | $ | 316,646 |  |  | 100 | % |  | $ | 260,068 |  |  | 100 | % |  | $ | 56,578 |  |  | 22 | % |

[0001262039-16-000087:mdna:58]
Total revenue increased by $56.6 million, or 22%, during the three months ended September 30, 2016 compared to the same period last year amidst a more moderate global macro spending environment than we saw last year. On a geographic basis, revenue continued to be diversified globally. All three regions experienced revenue growth compared to the same period last year, with EMEA contributing to the largest portion of our revenue growth on both an absolute dollar and a percentage basis. Product revenue increased by $8.2 million, or 7%, during the three months ended September 30, 2016 compared to the same period last year. The increase in product revenue was primarily driven by greater sales of our FortiGate product family, as well as growth in other product lines. The increase in product revenue was limited as we experienced North America sales execution issues, macro-economic challenges related to Brexit in the United Kingdom and geopolitical issues in Latin America. Service revenue increased by $48.3 million, or 34%, during the three months ended September 30, 2016 compared to the same period last year. The increase in service revenue was primarily due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. Service revenue also increased as we continue to charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000087:mdna:59]
[same as prior period, unchanged from 0001262039-16-000079:mdna:55]

[0001262039-16-000087:mdna:60]
|  | Three Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 50,267 |  |  | $ | 46,167 |  |  | $ | 4,100 |  |  | 9 | % |
| Service | 34,532 |  |  | 25,534 |  |  | 8,998 |  |  | 35 |  |
| Total cost of revenue | $ | 84,799 |  |  | $ | 71,701 |  |  | $ | 13,098 |  |  | 18 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.7 | % |  | 61.4 | % |  | (0.7 | )% |  |  |
| Service | 81.7 |  |  | 81.8 |  |  | (0.1 | ) |  |  |
| Total gross margin | 73.2 | % |  | 72.4 | % |  | 0.8 | % |  |  |

[0001262039-16-000087:mdna:61]
Total gross margin increased by 0.8 percentage points during the three months ended September 30, 2016 compared to the same period last year, as we continued to see a shift in the revenue mix, as service revenue outpaced product revenue

[0001262039-16-000087:mdna:62]
growth. This resulted in a higher overall gross margin. Product gross margin decreased by 0.7 percentage points during the three months ended September 30, 2016 compared to the same period last year, due to higher inventory reserves and overhead costs. The decrease was partially offset by higher sales of software products, such as certain of our virtualized security solutions, as well as lower warranty expense.

[0001262039-16-000087:mdna:63]
Service gross margin decreased by 0.1 percentage points during the three months ended September 30, 2016 as compared to the same period last year. Cost of service revenue increased by $9.0 million primarily due to a $4.2 million increase in personnel costs related to headcount increases.

[0001262039-16-000087:mdna:64]
[same as prior period, unchanged from 0001262039-16-000079:mdna:60]

[0001262039-16-000087:mdna:65]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2016 |  | September 30, 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 47,239 |  |  | 15 | % |  | $ | 42,110 |  |  | 16 | % |  | $ | 5,129 |  |  | 12 | % |
| Sales and marketing | 154,831 |  |  | 49 |  |  | 120,994 |  |  | 47 |  |  | 33,837 |  |  | 28 |  |
| General and administrative | 22,006 |  |  | 7 |  |  | 21,220 |  |  | 8 |  |  | 786 |  |  | 4 |  |
| Restructuring charges | 2,283 |  |  | 1 |  |  | 5,883 |  |  | 2 |  |  | (3,600 | ) |  | (61 | ) |
| Total operating expenses | $ | 226,359 |  |  | 71 | % |  | $ | 190,207 |  |  | 73 | % |  | $ | 36,152 |  |  | 19 | % |

[0001262039-16-000087:mdna:66]
[same as prior period, unchanged from 0001262039-16-000079:mdna:63]

[0001262039-16-000087:mdna:67]
Research and development expense increased by $5.1 million, or 12%, during the three months ended September 30, 2016 compared to the same period last year, primarily due to an increase of $3.4 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation and other occupancy-related costs increased by $1.7 million. We intend to continue to invest in our research and development organization, but expect research and development expense as a percentage of total revenue to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000087:mdna:68]
[same as prior period, unchanged from 0001262039-16-000079:mdna:65]

[0001262039-16-000087:mdna:69]
Sales and marketing expense increased by $33.8 million, or 28%, during the three months ended September 30, 2016 compared to the same period last year, primarily due to an increase of $27.0 million in personnel costs as we continued to increase our sales and marketing headcount. Marketing-related expenses increased by $0.7 million as we continued to invest in marketing programs to capture market share, particularly in the large enterprise market, including costs related to tradeshows and lead generation. In addition, we incurred increases in travel and entertainment expenses of $1.8 million and depreciation expense and occupancy-related costs of $4.5 million. We intend to continue to make investments in our sales resources and infrastructure and marketing strategy, which are critical to support growth, but at a slower pace. As such, we expect sales and marketing expense as a percentage of total revenue to slightly decrease during the remainder of 2016.

[0001262039-16-000087:mdna:70]
[same as prior period, unchanged from 0001262039-16-000079:mdna:67]

[0001262039-16-000087:mdna:71]
General and administrative expense increased by $0.8 million, or 4%, during the three months ended September 30, 2016 compared to the same period last year. During the three months ended September 30, 2016, we expensed an additional $1.5 million relating to the implementation and maintenance of a new ERP system compared to the same period last year. In addition, personnel costs increased by $1.5 million due to increase in headcount in order to support our expanding business. The increase in expense was partially offset by lower professional fees of $1.4 million and other costs of $0.9 million. As a percentage of total revenue, we expect general and administrative expense to remain at a relatively comparable level during the remainder of 2016.

[0001262039-16-000087:mdna:72]
[same as prior period, unchanged from 0001262039-16-000079:mdna:69]

[0001262039-16-000087:mdna:73]
34

[0001262039-16-000087:mdna:74]
Restructuring charges of $2.3 million during the three months ended September 30, 2016 primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. Restructuring charges of $5.9 million during the three months ended September 30, 2015 primarily relate to the restructuring activities in connection with the Meru acquisition to reduce our cost structure and improve operational efficiencies. The restructuring activities included reduction of workforce primarily and consolidation of excess facilities. See Note 9 to the condensed consolidated financial statements for additional details, including types of expenses incurred and the timing of future expenses and cash payments.

[0001262039-16-000087:mdna:75]
[same as prior period, unchanged from 0001262039-16-000079:mdna:72]

[0001262039-16-000087:mdna:76]
|  | Three Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 1,888 |  |  | $ | 1,333 |  |  | $ | 555 |  |  | 42 | % |
| Other expense—net | (787 | ) |  | (653 | ) |  | (134 | ) |  | 21 |  |

[0001262039-16-000087:mdna:77]
Interest income increased during the three months ended September 30, 2016 compared to the same period last year primarily due to interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in Other expense—net during the three months ended September 30, 2016 as compared to the same period last year was the result of higher foreign currency exchange losses. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000087:mdna:78]
[same as prior period, unchanged from 0001262039-16-000079:mdna:75]

[0001262039-16-000087:mdna:79]
|  | Three Months Ended |  | Change |  | % Change |
| September 30, 2016 |  | September 30, 2015 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | 298 |  |  | $ | (9,329 | ) |  | $ | 9,627 |  |  | (103 | )% |
| Effective tax rate (%) | 5 | % |  | 804 | % |  | (799 | )% |  | * |  |

[0001262039-16-000087:mdna:80]
[same as prior period, unchanged from 0001262039-16-000079:mdna:62]

[0001262039-16-000087:mdna:81]
Our effective tax rate was 5% for the three months ended September 30, 2016, as compared to an effective tax rate of 804% for the same period last year. The effective tax rate for the periods presented was comprised of U.S. federal and state taxes, and foreign withholding and income taxes. The changes in the tax provision for the three months ended September 30, 2016 was primarily due to the tax benefit from adoption of the new accounting guidance relating to stock-based compensation. The effective tax rate for the three months ended September 30, 2016 was an expense as compared to a benefit for the same period last year.

[0001262039-16-000087:mdna:82]
[same as prior period, unchanged from 0001262039-16-000079:mdna:79]

[0001262039-16-000087:mdna:83]
[same as prior period, unchanged from 0001262039-16-000079:mdna:88]

[0001262039-16-000087:mdna:84]
Nine Months Ended September 30, 2016 and September 30, 2015

[0001262039-16-000087:mdna:85]
[same as prior period, unchanged from 0001262039-16-000079:mdna:81]

[0001262039-16-000087:mdna:86]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  |  |  |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  | Change |  | % Change |
| (in thousands, except percentages) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 389,185 |  |  | 43 | % |  | $ | 332,023 |  |  | 47 | % |  | $ | 57,162 |  |  | 17 | % |
| Service | 523,428 |  |  | 57 |  |  | 380,716 |  |  | 53 |  |  | 142,712 |  |  | 37 |  |
| Total revenue | $ | 912,613 |  |  | 100 | % |  | $ | 712,739 |  |  | 100 | % |  | $ | 199,874 |  |  | 28 | % |
| Revenue by geography: |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 386,566 |  |  | 42 | % |  | $ | 313,318 |  |  | 44 | % |  | $ | 73,248 |  |  | 23 | % |
| EMEA | 336,911 |  |  | 37 |  |  | 250,808 |  |  | 35 |  |  | 86,103 |  |  | 34 |  |
| APAC | 189,136 |  |  | 21 |  |  | 148,613 |  |  | 21 |  |  | 40,523 |  |  | 27 |  |
| Total revenue | $ | 912,613 |  |  | 100 | % |  | $ | 712,739 |  |  | 100 | % |  | $ | 199,874 |  |  | 28 | % |

[0001262039-16-000087:mdna:87]
Total revenue increased by $199.9 million, or 28%, during the nine months ended September 30, 2016 compared to the same period last year.  All three regions experienced revenue growth compared to the same period last year, with EMEA contributing the largest portion of our revenue growth on both an absolute dollar and a percentage basis. We continued to see a limited increase in product revenue for Americas, as we experienced North America sales execution issues and geopolitical issues in Latin America. Product revenue increased by $57.2 million, or 17%, during the nine months ended September 30, 2016 compared to the same period last year. The increase in product revenue was primarily driven by greater sales in our FortiGate product family, as well as growth in other product lines.

[0001262039-16-000087:mdna:88]
Service revenue increased by $142.7 million, or 37%, during the nine months ended September 30, 2016 compared to the same period last year due to the recognition of revenue from our growing deferred revenue balance consisting of FortiGuard security subscription and FortiCare technical support contracts sold to a larger customer base, as well as the renewals of similar contracts sold in earlier periods. Service revenue also increased as we continue to charge more for functionality and value in our FortiGuard security subscription, FortiCare technical support and other offerings.

[0001262039-16-000087:mdna:89]
[same as prior period, unchanged from 0001262039-16-000079:mdna:85]

[0001262039-16-000087:mdna:90]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | $ | 152,368 |  |  | $ | 134,932 |  |  | $ | 17,436 |  |  | 13 | % |
| Service | 94,578 |  |  | 69,869 |  |  | 24,709 |  |  | 35 |  |
| Total cost of revenue | $ | 246,946 |  |  | $ | 204,801 |  |  | $ | 42,145 |  |  | 21 | % |
| Gross margin (%): |  |  |  |  |  |  |  |
| Product | 60.8 | % |  | 59.4 | % |  | 1.4 | % |  |  |
| Service | 81.9 |  |  | 81.6 |  |  | 0.3 |  |  |  |
| Total gross margin | 72.9 | % |  | 71.3 | % |  | 1.6 | % |  |  |

[0001262039-16-000087:mdna:91]
Total gross margin increased by 1.6 percentage points during the nine months ended September 30, 2016 compared to the same period last year, as both product and service gross margins increased. Product gross margin increased by 1.4 percentage points during the nine months ended September 30, 2016 compared to the same period last year. Product gross margin was positively impacted by higher sales of software products such as certain of our virtualized security solutions and lower warranty expense, partially offset by higher inventory reserves and overhead costs.

[0001262039-16-000087:mdna:92]
Service gross margin increased by 0.3 percentage points during the nine months ended September 30, 2016 as compared to the same period last year, resulting from our ability to charge more for functionality and value to our service offerings, which have translated into improved service margins. Cost of service revenue increased by $24.7 million primarily due to a $14.0 million increase in personnel costs as a result of increased headcount.

[0001262039-16-000087:mdna:93]
[same as prior period, unchanged from 0001262039-16-000079:mdna:90]

[0001262039-16-000087:mdna:94]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2016 |  | September 30, 2015 |  |
| Amount |  | % ofRevenue |  | Amount |  | % ofRevenue |  |
| (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 137,495 |  |  | 15 | % |  | $ | 115,315 |  |  | 16 | % |  | $ | 22,180 |  |  | 19 | % |
| Sales and marketing | 463,628 |  |  | 51 |  |  | 333,531 |  |  | 47 |  |  | 130,097 |  |  | 39 |  |
| General and administrative | 63,629 |  |  | 7 |  |  | 51,199 |  |  | 7 |  |  | 12,430 |  |  | 24 |  |
| Restructuring charges | 3,164 |  |  | — |  |  | 5,883 |  |  | 1 |  |  | (2,719 | ) |  | (46 | ) |
| Total operating expenses | $ | 667,916 |  |  | 73 | % |  | $ | 505,928 |  |  | 71 | % |  | $ | 161,988 |  |  | 32 | % |

[0001262039-16-000087:mdna:95]
[same as prior period, unchanged from 0001262039-16-000079:mdna:93]

[0001262039-16-000087:mdna:96]
Research and development expense increased by $22.2 million, or 19%, during the nine months ended September 30, 2016 compared to the same period last year primarily due to an increase of $16.2 million in personnel costs as a result of increased headcount to support the development of new products and continued enhancements of our existing products. Depreciation expense and other occupancy-related costs increased by $5.1 million and costs of test and prototype materials used in product development increased by $1.9 million.

[0001262039-16-000087:mdna:97]
[same as prior period, unchanged from 0001262039-16-000079:mdna:95]

[0001262039-16-000087:mdna:98]
Sales and marketing expense increased by $130.1 million, or 39%, during the nine months ended September 30, 2016 compared to the same period last year, primarily due to an increase of $101.0 million in personnel costs as we continued to increase our sales headcount in order to drive continued market share gains globally. Marketing-related expense increased by $8.5 million as we invested significantly in marketing programs to capture market share, particularly in the large enterprise market, including costs related to trade-shows and lead generation. In addition, depreciation expense and other occupancy-related expense increased by $10.1 million and travel and entertainment expense increased by $6.9 million.

[0001262039-16-000087:mdna:99]
[same as prior period, unchanged from 0001262039-16-000079:mdna:97]

[0001262039-16-000087:mdna:100]
General and administrative expense increased by $12.4 million, or 24%, during the nine months ended September 30, 2016 compared to the same period last year. During the nine months ended September 30, 2016, we expensed an additional $9.3 million of costs relating to the implementation and maintenance of the ERP system implementation compared to the same period last year. In addition, personnel costs increased by $8.2 million, as we continued to increase our headcount in order to support growth in our business. The increase was partially offset by lower professional fees of $3.9 million.

[0001262039-16-000087:mdna:101]
Restructuring charges

[0001262039-16-000087:mdna:102]
Restructuring charges of $3.2 million during the nine months ended September 30, 2016 primarily relate to our restructuring activities to improve operating efficiencies due to the acquisition of AccelOps and certain other activities. Restructuring charges of $5.9 million during the nine months ended September 30, 2015 relate to the restructuring activities in connection with the Meru acquisition. See Note 9 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional details, including types of expenses incurred and the timing of future expenses and cash payments.

[0001262039-16-000087:mdna:103]
[same as prior period, unchanged from 0001262039-16-000079:mdna:107]

[0001262039-16-000087:mdna:104]
[same as prior period, unchanged from 0001262039-16-000079:mdna:100]

[0001262039-16-000087:mdna:105]
|  | Nine Months Ended |  |  |  |  |
| September 30, 2016 |  | September 30, 2015 |  | Change |  | % Change |
| (in thousands, except percentages) |
| Interest income | $ | 5,339 |  |  | $ | 4,119 |  |  | $ | 1,220 |  |  | 30 | % |
| Other expense—net | (3,449 | ) |  | (2,160 | ) |  | (1,289 | ) |  | 60 |  |

[0001262039-16-000087:mdna:106]
Interest income increased during the nine months ended September 30, 2016 compared to the same period last year primarily due to interest earned on invested balances of cash, cash equivalents and investments. Interest income varies depending on our average investment balances during the period, types and mix of investments, and market interest rates. The increase in Other expense—net for the nine months ended September 30, 2016 when compared to the same period last year, was the result of higher foreign currency exchange losses. Other expense—net consisted primarily of foreign exchange and related hedging gains and losses.

[0001262039-16-000087:mdna:107]
[same as prior period, unchanged from 0001262039-16-000079:mdna:103]

[0001262039-16-000087:mdna:108]
|  | Nine Months Ended |  | Change |  | % Change |
| September 30, 2016 |  | September 30, 2015 |  |
| (in thousands, except percentages) |
| Provision for (benefit from) income taxes | $ | (7,380 | ) |  | $ | (6,552 | ) |  | $ | (828 | ) |  | 13 | % |
| Effective tax rate (%) | 2,053 | % |  | (165 | )% |  | * |  |  | * |  |

[0001262039-16-000087:mdna:109]
[same as prior period, unchanged from 0001262039-16-000079:mdna:77]

[0001262039-16-000087:mdna:110]
Our effective tax rate was 2,053% for the nine months ended September 30, 2016, compared with an effective tax rate of -165% for the same period last year. The benefit from income taxes for the nine months ended September 30, 2016 was comprised primarily of U.S. federal and state taxes, other foreign income taxes, foreign withholding taxes, and transfer pricing allocations which impact jurisdictional income taxed at various tax rates. The changes in benefit from income taxes and effective tax rate for the nine months ended September 30, 2016 was primarily due to the recognition of excess tax benefit from the adoption of the new accounting guidance related to the stock-based compensation.

[0001262039-16-000087:mdna:111]
.

[0001262039-16-000087:mdna:112]
[same as prior period, unchanged from 0001262039-16-000079:mdna:108]

[0001262039-16-000087:mdna:113]
|  | As of |
|  | September 30, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 647,513 |  |  | $ | 543,277 |  |
| Investments | 623,137 |  |  | 621,033 |  |
| Total cash, cash equivalents and investments | $ | 1,270,650 |  |  | $ | 1,164,310 |  |
| Working capital (1) | $ | 644,513 |  |  | $ | 591,873 |  |
|  | Nine Months Ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 244,671 |  |  | $ | 213,989 |  |
| Cash provided by (used in) investing activities | (76,215 | ) |  | 2,915 |  |
| Cash provided by (used in) financing activities | (64,220 | ) |  | 40,554 |  |
| Net increase in cash and cash equivalents | $ | 104,236 |  |  | $ | 257,458 |  |

[0001262039-16-000087:mdna:114]
[same as prior period, unchanged from 0001262039-16-000079:mdna:110]

[0001262039-16-000087:mdna:115]
Liquidity and capital resources may be impacted by our operating activities, as well as by our business acquisitions, capital expenditures, stock repurchases, proceeds associated with stock option exercises and issuances of common stock under the ESPP, payment of taxes in connection with the net settlement of equity awards, the timing of sales within an accounting period, and investments in strategic relationships that we have made or may make in the future. Our liquidity may be impacted by our customer-buying patterns and the efforts of our sales force and channel partners, which have historically resulted in our receiving a substantial portion of our billings during the last two weeks of the quarter. Billings during the last two weeks of the third quarter of 2016 were in excess of 40% compared to the historical eight-quarter average of 34%. As of September 30, 2016, $125.0 million remained available for future share repurchases under our share repurchase program. In October 2016, the board of directors authorized a $100 million increase to our existing share repurchase program, bringing the amount authorized under the current program to $300 million.  In recent years we have received significant capital as a result of the exercise of stock options. We expect proceeds in future years to decrease due to the increased mix of RSUs granted versus stock options and also to vary based on our share price. We expect to spend $15.0 million to $25.0 million in capital expenditures primarily related to expansion of our offices to support worldwide growth in the remainder of 2016.

[0001262039-16-000087:mdna:116]
As of September 30, 2016, our cash, cash equivalents, and investments of $1.27 billion were invested primarily in corporate debt securities, commercial paper, municipal bonds, U.S. government and agency securities, money market funds and certificates of deposit and term deposits. It is our investment policy to invest excess cash in a manner that preserves capital, provides liquidity and maximizes return without significantly increasing risk.

[0001262039-16-000087:mdna:117]
As of September 30, 2016, $501.4 million of our cash and investments were held by our international subsidiaries and are therefore not immediately available to fund domestic operations unless the cash is repatriated. We are considering repatriating some cash in December 2016. Should any amount be repatriated, it would be subject to U.S. federal income tax.  However, any cash repatriated is expected to be offset by foreign tax credits. We do not enter into investments for trading or speculative purposes.

[0001262039-16-000087:mdna:118]
We believe that our existing cash and cash equivalents will be sufficient to meet our anticipated cash needs for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced products and services offerings, the costs to ensure access to adequate manufacturing capacity, the continuing market acceptance of our products and our investments in real estate through purchases or long-term leases. Historically, we have required capital principally to fund our working capital needs, capital expenditures, share repurchases and acquisition activities. In the event that additional financing is required from outside sources, we may not be able to raise it on terms acceptable to us or at all. If we are unable to raise additional capital when desired, our business, operating results and financial condition would be adversely affected.

[0001262039-16-000087:mdna:119]
[same as prior period, unchanged from 0001262039-16-000079:mdna:129]

[0001262039-16-000087:mdna:120]
[same as prior period, unchanged from 0001262039-16-000079:mdna:115]

[0001262039-16-000087:mdna:121]
Cash generated by operating activities is our primary source of liquidity. It is primarily comprised of net income, as adjusted for non-cash items, and changes in operating assets and liabilities. Non-cash adjustments consist primarily of stock-based compensation, depreciation of property and equipment, amortization of intangible assets and amortization of investment premiums.

[0001262039-16-000087:mdna:122]
Our operating activities during the nine months ended September 30, 2016 provided $244.7 million in cash as a result of the continued growth of our business and our ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support contracts to new and existing customers, as reflected by an increase in our deferred revenue.

[0001262039-16-000087:mdna:123]
Our operating activities during the nine months ended September 30, 2015 provided $214.0 million in cash as a result of the continued growth in our business and the ability to successfully manage our working capital. Changes in operating assets and liabilities primarily resulted from an increase in sales of our FortiGuard security subscription and FortiCare technical support contracts to new and existing customers, as reflected by an increase in our deferred revenue.

[0001262039-16-000087:mdna:124]
[same as prior period, unchanged from 0001262039-16-000079:mdna:119]

[0001262039-16-000087:mdna:125]
[same as prior period, unchanged from 0001262039-16-000079:mdna:120]

[0001262039-16-000087:mdna:126]
During the nine months ended September 30, 2016, cash used for investing activities was primarily due to the $50.3 million we spent on capital expenditures, including our purchase of a warehouse in Union City, California for total cash of $18.5 million, and a $22.1 million payment for the acquisition of AccelOps. Cash outflows due to purchases of investments, net of sales and maturities, amounted to $3.8 million.

[0001262039-16-000087:mdna:127]
During the nine months ended September 30, 2015, cash provided by investing activities was a result of positive cash flow due to maturities, net of purchases, from our investments of $70.0 million, partially offset by capital expenditures of $29.0 million and $38.0 million used for the acquisition of Meru.

[0001262039-16-000087:mdna:128]
[same as prior period, unchanged from 0001262039-16-000079:mdna:123]

[0001262039-16-000087:mdna:129]
[same as prior period, unchanged from 0001262039-16-000079:mdna:124]

[0001262039-16-000087:mdna:130]
During the nine months ended September 30, 2016, cash used for financing activities was $64.2 million, primarily due to $75.0 million used to repurchase our common stock. This was partially offset by $12.4 million of proceeds from the issuance of common stock, net of taxes paid, related to withholding upon issuance of equity awards.

[0001262039-16-000087:mdna:131]
During the nine months ended September 30, 2015, cash provided by financing activities was $40.6 million as a result of proceeds of $63.5 million from the issuance of common stock under our stock-based compensation plans. This cash inflow was partially offset by $23.0 million of withholding tax payments upon issuance of equity awards.

[0001262039-16-000087:mdna:132]
[same as prior period, unchanged from 0001262039-16-000079:mdna:127]

[0001262039-16-000087:mdna:133]
There were no material changes outside the ordinary course of business during the nine months ended September 30, 2016 to the contractual obligations and commitments disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of the Form 10-K. See Note 10 to the notes to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information regarding contractual obligations and commitments.

[0001262039-16-000087:mdna:134]
[same as prior period, unchanged from 0001262039-16-000079:mdna:132]

[0001262039-16-000087:mdna:135]
[same as prior period, unchanged from 0001262039-16-000079:mdna:130]

[0001262039-16-000087:mdna:136]
As of September 30, 2016, we did not have any relationships with unconsolidated organizations or financial partnerships, such as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.
