# AVGO 8-K — 0001730168-23-000004 filed 2023-03-02

## item codes, every 8-K on or before 2023-03-08

- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2023-03-08

- none on or before 2023-03-08

## item 2.02 — earnings release, exhibit 99.1

[0001730168-23-000004:8k_2_02:1]
EX-99.1
2
avgo-01292023x8kxex99.htm
EX-99.1

[0001730168-23-000004:8k_2_02:2]
Document

[0001730168-23-000004:8k_2_02:3]
Exhibit 99.1

[0001730168-23-000004:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2023 Financial Results and Quarterly Dividend

[0001730168-23-000004:8k_2_02:5]
•Revenue of $8,915 million for the first quarter, up 16 percent from the prior year period

[0001730168-23-000004:8k_2_02:6]
•Adjusted EBITDA of $5,678 million for the first quarter

[0001730168-23-000004:8k_2_02:7]
•Non-GAAP diluted EPS of $10.33 for the first quarter; GAAP diluted EPS of $8.80 for the first quarter

[0001730168-23-000004:8k_2_02:8]
•Quarterly common stock dividend of $4.60 per share

[0001730168-23-000004:8k_2_02:9]
•Repurchased and eliminated 2.7 million shares for $1,521 million

[0001730168-23-000004:8k_2_02:10]
•Second quarter revenue guidance of approximately $8.7 billion, an increase of 8 percent from the prior year period

[0001730168-23-000004:8k_2_02:11]
•Second quarter Adjusted EBITDA guidance of approximately 64.5 percent of projected revenue(1)

[0001730168-23-000004:8k_2_02:12]
SAN JOSE, Calif. – March 2, 2023 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2023, ended January 29, 2023, provided guidance for the second quarter of its fiscal year 2023 and announced its quarterly dividend.

[0001730168-23-000004:8k_2_02:13]
“Broadcom’s first quarter performance reflects continued strength in infrastructure demand across all our end markets,” said Hock Tan, President and CEO of Broadcom Inc. “Looking ahead, we are confident our growth will be driven by sustained leadership in next generation technologies across all of our core markets, and strong partnerships with our customers.”

[0001730168-23-000004:8k_2_02:14]
“Consolidated revenue grew 16% year-over-year to $8.9 billion and adjusted EBITDA margin increased year-over-year to 64%,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $3.9 billion in free cash flow, representing a 16% increase year-over-year, and expect even stronger free cash flow in the second quarter.”

[0001730168-23-000004:8k_2_02:15]
First Quarter Fiscal Year 2023 Financial Highlights

[0001730168-23-000004:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 23 |  | Q1 22 |  | Change |  | Q1 23 |  | Q1 22 |  | Change |
| Net revenue |  | $ | 8,915 |  |  | $ | 7,706 |  |  | +16 | % |  | $ | 8,915 |  |  | $ | 7,706 |  |  | +16 | % |
| Net income |  | $ | 3,774 |  |  | $ | 2,472 |  |  | +$1,302 |  |  | $ | 4,483 |  |  | $ | 3,741 |  |  | +$742 |  |
| Earnings per common share - diluted |  | $ | 8.80 |  |  | $ | 5.59 |  |  | +$3.21 |  |  | $ | 10.33 |  |  | $ | 8.39 |  |  | +$1.94 |  |

[0001730168-23-000004:8k_2_02:17]
________________________________

[0001730168-23-000004:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-23-000004:8k_2_02:19]
1

[0001730168-23-000004:8k_2_02:20]
| (Dollars in millions) |  | Q1 23 |  | Q1 22 |  | Change |  |
| Cash flow from operations |  | $ | 4,036 |  |  | $ | 3,486 |  |  | +$550 |  |
| Adjusted EBITDA |  | $ | 5,678 |  |  | $ | 4,818 |  |  | +$860 |  |
| Free cash flow |  | $ | 3,933 |  |  | $ | 3,385 |  |  | +$548 |  |

[0001730168-23-000004:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 23 |  |  |  | Q1 22 |  | Change |  |
| Semiconductor solutions |  | $ | 7,107 |  |  | 80 | % |  |  |  |  |  |  | $ | 5,873 |  |  | 76 | % |  | +21 | % |  |
| Infrastructure software |  | 1,808 |  |  | 20 |  |  |  |  |  |  |  | 1,833 |  |  | 24 |  |  | -1 | % |  |
| Total net revenue |  | $ | 8,915 |  |  | 100 | % |  |  |  |  |  |  | $ | 7,706 |  |  | 100 | % |  |  |  |  |

[0001730168-23-000004:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $12,647 million, compared to $12,416 million at the end of the prior quarter.

[0001730168-23-000004:8k_2_02:23]
During the first fiscal quarter, the Company generated $4,036 million in cash from operations and spent $103 million on capital expenditures. The Company spent $1,521 million on share repurchases and eliminations, consisting of $1,188 million in repurchases of 2.1 million shares and $333 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 0.6 million shares withheld).

[0001730168-23-000004:8k_2_02:24]
On December 30, 2022, the Company paid a cash dividend of $4.60 per share, totaling $1,926 million.

[0001730168-23-000004:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-23-000004:8k_2_02:26]
Second Quarter Fiscal Year 2023 Business Outlook

[0001730168-23-000004:8k_2_02:27]
Based on current business trends and conditions, the outlook for the second quarter of fiscal year 2023, ending April 30, 2023, is expected to be as follows:

[0001730168-23-000004:8k_2_02:28]
•Second quarter revenue guidance of approximately $8.7 billion; and

[0001730168-23-000004:8k_2_02:29]
•Second quarter Adjusted EBITDA guidance of approximately 64.5 percent of projected revenue.

[0001730168-23-000004:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000004:8k_2_02:31]
Quarterly Dividends

[0001730168-23-000004:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend of $4.60 per share. The dividend is payable on March 31, 2023 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 22, 2023.

[0001730168-23-000004:8k_2_02:33]
Financial Results Conference Call

[0001730168-23-000004:8k_2_02:34]
2

[0001730168-23-000004:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the first quarter fiscal year 2023 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-23-000004:8k_2_02:36]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-23-000004:8k_2_02:37]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BI8c37496b52db4705a80eea80b94ccb9b. Upon registering, you will be emailed a link to the dial-in number and unique PIN.

[0001730168-23-000004:8k_2_02:38]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom's website at https://investors.broadcom.com/.

[0001730168-23-000004:8k_2_02:39]
Non-GAAP Financial Measures

[0001730168-23-000004:8k_2_02:40]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-23-000004:8k_2_02:41]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-23-000004:8k_2_02:42]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-23-000004:8k_2_02:43]
About Broadcom Inc.

[0001730168-23-000004:8k_2_02:44]
3

[0001730168-23-000004:8k_2_02:45]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-23-000004:8k_2_02:46]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-23-000004:8k_2_02:47]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase programs; the COVID-19 pandemic; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; failing to complete or realize the expected benefits of our acquisition of VMware, Inc.; any acquisitions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to protect against cyber security threats and a breach of security systems; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used

[0001730168-23-000004:8k_2_02:48]
4

[0001730168-23-000004:8k_2_02:49]
in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-23-000004:8k_2_02:50]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000004:8k_2_02:51]
Contact:

[0001730168-23-000004:8k_2_02:52]
Ji Yoo

[0001730168-23-000004:8k_2_02:53]
Broadcom Inc.

[0001730168-23-000004:8k_2_02:54]
Investor Relations

[0001730168-23-000004:8k_2_02:55]
408-433-8000

[0001730168-23-000004:8k_2_02:56]
investor.relations@broadcom.com

[0001730168-23-000004:8k_2_02:57]
(AVGO-Q)

[0001730168-23-000004:8k_2_02:58]
5

[0001730168-23-000004:8k_2_02:59]
BROADCOM INC.

[0001730168-23-000004:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-23-000004:8k_2_02:61]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-23-000004:8k_2_02:62]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 29,2023 |  | October 30,2022 |  | January 30,2022 |  |  |  |  |
| Net revenue |  | $ | 8,915 |  |  | $ | 8,930 |  |  | $ | 7,706 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 2,374 |  |  | 2,298 |  |  | 1,925 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 535 |  |  | 705 |  |  | 730 |  |  |  |  |  |
| Restructuring charges |  | 2 |  |  | 1 |  |  | 2 |  |  |  |  |  |
| Total cost of revenue |  | 2,911 |  |  | 3,004 |  |  | 2,657 |  |  |  |  |  |
| Gross margin |  | 6,004 |  |  | 5,926 |  |  | 5,049 |  |  |  |  |  |
| Research and development |  | 1,195 |  |  | 1,197 |  |  | 1,206 |  |  |  |  |  |
| Selling, general and administrative |  | 348 |  |  | 370 |  |  | 321 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 358 |  |  | 397 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 10 |  |  | 15 |  |  | 17 |  |  |  |  |  |
| Total operating expenses |  | 1,901 |  |  | 1,940 |  |  | 1,941 |  |  |  |  |  |
| Operating income |  | 4,103 |  |  | 3,986 |  |  | 3,108 |  |  |  |  |  |
| Interest expense |  | (406) |  |  | (406) |  |  | (407) |  |  |  |  |  |
| Other income (expense), net |  | 143 |  |  | 40 |  |  | (14) |  |  |  |  |  |
| Income before income taxes |  | 3,840 |  |  | 3,620 |  |  | 2,687 |  |  |  |  |  |
| Provision for income taxes |  | 66 |  |  | 261 |  |  | 215 |  |  |  |  |  |
| Net income |  | 3,774 |  |  | 3,359 |  |  | 2,472 |  |  |  |  |  |
| Dividends on preferred stock |  | — |  |  | (48) |  |  | (74) |  |  |  |  |  |
| Net income attributable to common stock |  | $ | 3,774 |  |  | $ | 3,311 |  |  | $ | 2,398 |  |  |  |  |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 9.03 |  |  | $ | 8.06 |  |  | $ | 5.82 |  |  |  |  |  |
| Diluted (1) |  | $ | 8.80 |  |  | $ | 7.83 |  |  | $ | 5.59 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 418 |  |  | 411 |  |  | 412 |  |  |  |  |  |
| Diluted (1) |  | 429 |  |  | 429 |  |  | 429 |  |  |  |  |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 37 |  |  | $ | 38 |  |  | $ | 36 |  |  |  |  |  |
| Research and development |  | 267 |  |  | 260 |  |  | 268 |  |  |  |  |  |
| Selling, general and administrative |  | 87 |  |  | 89 |  |  | 83 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 391 |  |  | $ | 387 |  |  | $ | 387 |  |  |  |  |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock for the fiscal quarter ended January 30, 2022 as the impact was antidilutive. All outstanding shares of Mandatory Convertible Preferred Stock were converted into our common stock during the fiscal quarter ended October 30, 2022. |

[0001730168-23-000004:8k_2_02:63]
BROADCOM INC.

[0001730168-23-000004:8k_2_02:64]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-23-000004:8k_2_02:65]
(IN MILLIONS)

[0001730168-23-000004:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 29,2023 |  | October 30,2022 |  | January 30,2022 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 6,004 |  |  | $ | 5,926 |  |  | $ | 5,049 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 535 |  |  | 705 |  |  | 730 |  |  |  |  |  |
| Stock-based compensation expense |  | 37 |  |  | 38 |  |  | 36 |  |  |  |  |  |
| Restructuring charges |  | 2 |  |  | 1 |  |  | 2 |  |  |  |  |  |
| Acquisition-related costs |  | — |  |  | 3 |  |  | 4 |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 6,578 |  |  | $ | 6,673 |  |  | $ | 5,821 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 1,195 |  |  | $ | 1,197 |  |  | $ | 1,206 |  |  |  |  |  |
| Stock-based compensation expense |  | 267 |  |  | 260 |  |  | 268 |  |  |  |  |  |
| Acquisition-related costs |  | (1) |  |  | — |  |  | — |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 929 |  |  | $ | 937 |  |  | $ | 938 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 348 |  |  | $ | 370 |  |  | $ | 321 |  |  |  |  |  |
| Stock-based compensation expense |  | 87 |  |  | 89 |  |  | 83 |  |  |  |  |  |
| Acquisition-related costs |  | 42 |  |  | 45 |  |  | 11 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 219 |  |  | $ | 236 |  |  | $ | 227 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 1,901 |  |  | $ | 1,940 |  |  | $ | 1,941 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 358 |  |  | 397 |  |  |  |  |  |
| Stock-based compensation expense |  | 354 |  |  | 349 |  |  | 351 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 10 |  |  | 15 |  |  | 17 |  |  |  |  |  |
| Acquisition-related costs |  | 41 |  |  | 45 |  |  | 11 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,148 |  |  | $ | 1,173 |  |  | $ | 1,165 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 4,103 |  |  | $ | 3,986 |  |  | $ | 3,108 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 883 |  |  | 1,063 |  |  | 1,127 |  |  |  |  |  |
| Stock-based compensation expense |  | 391 |  |  | 387 |  |  | 387 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 12 |  |  | 16 |  |  | 19 |  |  |  |  |  |
| Acquisition-related costs |  | 41 |  |  | 48 |  |  | 15 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 5,430 |  |  | $ | 5,500 |  |  | $ | 4,656 |  |  |  |  |  |
| Other income (expense), net on GAAP basis |  | $ | 143 |  |  | $ | 40 |  |  | $ | (14) |  |  |  |  |  |
| (Gains) losses on investments |  | (44) |  |  | 29 |  |  | 16 |  |  |  |  |  |
| Other income, net on non-GAAP basis |  | $ | 99 |  |  | $ | 69 |  |  | $ | 2 |  |  |  |  |  |
| Provision for income taxes on GAAP basis |  | $ | 66 |  |  | $ | 261 |  |  | $ | 215 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | 574 |  |  | 358 |  |  | 295 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 640 |  |  | $ | 619 |  |  | $ | 510 |  |  |  |  |  |

[0001730168-23-000004:8k_2_02:67]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 29,2023 |  | October 30,2022 |  | January 30,2022 |  |  |  |  |
| Net income on GAAP basis |  | $ | 3,774 |  |  | $ | 3,359 |  |  | $ | 2,472 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 883 |  |  | 1,063 |  |  | 1,127 |  |  |  |  |  |
| Stock-based compensation expense |  | 391 |  |  | 387 |  |  | 387 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 12 |  |  | 16 |  |  | 19 |  |  |  |  |  |
| Acquisition-related costs |  | 41 |  |  | 48 |  |  | 15 |  |  |  |  |  |
| (Gains) losses on investments |  | (44) |  |  | 29 |  |  | 16 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (574) |  |  | (358) |  |  | (295) |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 4,483 |  |  | $ | 4,544 |  |  | $ | 3,741 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 429 |  |  | 429 |  |  | 429 |  |  |  |  |  |
| Non-GAAP adjustment (1) |  | 5 |  |  | 6 |  |  | 17 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 434 |  |  | 435 |  |  | 446 |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 4,483 |  |  | $ | 4,544 |  |  | $ | 3,741 |  |  |  |  |  |
| Interest expense |  | 406 |  |  | 406 |  |  | 407 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 640 |  |  | 619 |  |  | 510 |  |  |  |  |  |
| Depreciation |  | 127 |  |  | 129 |  |  | 136 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 22 |  |  | 24 |  |  | 24 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 5,678 |  |  | $ | 5,722 |  |  | $ | 4,818 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 4,036 |  |  | $ | 4,583 |  |  | $ | 3,486 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (103) |  |  | (122) |  |  | (101) |  |  |  |  |  |
| Free cash flow |  | $ | 3,933 |  |  | $ | 4,461 |  |  | $ | 3,385 |  |  |  |  |  |

[0001730168-23-000004:8k_2_02:68]
|  |  | Fiscal Quarter Ending |
|  |  | April 30, |
| Expected average diluted share count (2): |  | 2023 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 429 |  |
| Non-GAAP adjustment (1) |  | 9 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 438 |  |

[0001730168-23-000004:8k_2_02:69]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis for the fiscal quarter ended January 30, 2022. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-23-000004:8k_2_02:70]
BROADCOM INC.

[0001730168-23-000004:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-23-000004:8k_2_02:72]
(IN MILLIONS)

[0001730168-23-000004:8k_2_02:73]
|  |  | January 29,2023 |  | October 30,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 12,647 |  |  | $ | 12,416 |  |
| Trade accounts receivable, net |  | 3,234 |  |  | 2,958 |  |
| Inventory |  | 1,899 |  |  | 1,925 |  |
| Other current assets |  | 1,056 |  |  | 1,205 |  |
| Total current assets |  | 18,836 |  |  | 18,504 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,201 |  |  | 2,223 |  |
| Goodwill |  | 43,614 |  |  | 43,614 |  |
| Intangible assets, net |  | 6,225 |  |  | 7,111 |  |
| Other long-term assets |  | 2,100 |  |  | 1,797 |  |
| Total assets |  | $ | 72,976 |  |  | $ | 73,249 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 923 |  |  | $ | 998 |  |
| Employee compensation and benefits |  | 536 |  |  | 1,202 |  |
| Current portion of long-term debt |  | 1,115 |  |  | 440 |  |
| Other current liabilities |  | 4,909 |  |  | 4,412 |  |
| Total current liabilities |  | 7,483 |  |  | 7,052 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 38,167 |  |  | 39,075 |  |
| Other long-term liabilities |  | 4,016 |  |  | 4,413 |  |
| Total liabilities |  | 49,666 |  |  | 50,540 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 21,119 |  |  | 21,159 |  |
| Retained earnings |  | 2,371 |  |  | 1,604 |  |
| Accumulated other comprehensive loss |  | (180) |  |  | (54) |  |
| Total stockholders' equity |  | 23,310 |  |  | 22,709 |  |
| Total liabilities and equity |  | $ | 72,976 |  |  | $ | 73,249 |  |

[0001730168-23-000004:8k_2_02:74]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 29,2023 |  | October 30,2022 |  | January 30,2022 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,774 |  |  | $ | 3,359 |  |  | $ | 2,472 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 905 |  |  | 1,087 |  |  | 1,151 |  |  |  |  |  |
| Depreciation |  | 127 |  |  | 129 |  |  | 136 |  |  |  |  |  |
| Stock-based compensation |  | 391 |  |  | 387 |  |  | 387 |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | (573) |  |  | (89) |  |  | 70 |  |  |  |  |  |
| Non-cash interest expense |  | 32 |  |  | 32 |  |  | 32 |  |  |  |  |  |
| Other |  | (39) |  |  | 31 |  |  | 15 |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (276) |  |  | (241) |  |  | (468) |  |  |  |  |  |
| Inventory |  | 26 |  |  | (87) |  |  | (223) |  |  |  |  |  |
| Accounts payable |  | (80) |  |  | 304 |  |  | — |  |  |  |  |  |
| Employee compensation and benefits |  | (657) |  |  | 128 |  |  | (528) |  |  |  |  |  |
| Other current assets and current liabilities |  | 570 |  |  | (388) |  |  | 521 |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | (164) |  |  | (69) |  |  | (79) |  |  |  |  |  |
| Net cash provided by operating activities |  | 4,036 |  |  | 4,583 |  |  | 3,486 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (103) |  |  | (122) |  |  | (101) |  |  |  |  |  |
| Purchases of investments |  | — |  |  | — |  |  | (200) |  |  |  |  |  |
| Other |  | — |  |  | (6) |  |  | (8) |  |  |  |  |  |
| Net cash used in investing activities |  | (103) |  |  | (128) |  |  | (309) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  | (260) |  |  | (9) |  |  | (255) |  |  |  |  |  |
| Payments of dividends |  | (1,926) |  |  | (1,782) |  |  | (1,764) |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  | (1,188) |  |  | — |  |  | (2,724) |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (333) |  |  | (274) |  |  | (375) |  |  |  |  |  |
| Issuance of common stock |  | — |  |  | 54 |  |  | 1 |  |  |  |  |  |
| Other |  | 5 |  |  | (5) |  |  | (4) |  |  |  |  |  |
| Net cash used in financing activities |  | (3,702) |  |  | (2,016) |  |  | (5,121) |  |  |  |  |  |
| Net change in cash and cash equivalents |  | 231 |  |  | 2,439 |  |  | (1,944) |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 12,416 |  |  | 9,977 |  |  | 12,163 |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 12,647 |  |  | $ | 12,416 |  |  | $ | 10,219 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 361 |  |  | $ | 397 |  |  | $ | 240 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 273 |  |  | $ | 251 |  |  | $ | 186 |  |  |  |  |  |
