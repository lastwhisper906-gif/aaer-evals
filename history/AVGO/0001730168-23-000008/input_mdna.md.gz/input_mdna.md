# AVGO MD&A — 0001730168-23-000008


## mdna

[0001730168-23-000008:mdna:1]
[same as prior period, unchanged from 0001730168-22-000094:mdna:1]

[0001730168-23-000008:mdna:2]
21

[0001730168-23-000008:mdna:3]
[same as prior period, unchanged from 0001730168-22-000094:mdna:2]

[0001730168-23-000008:mdna:4]
[same as prior period, unchanged from 0001730168-22-000094:mdna:3]

[0001730168-23-000008:mdna:5]
[same as prior period, unchanged from 0001730168-22-000094:mdna:4]

[0001730168-23-000008:mdna:6]
[same as prior period, unchanged from 0001730168-22-000094:mdna:5]

[0001730168-23-000008:mdna:7]
Highlights during the fiscal quarter ended January 29, 2023 include the following:

[0001730168-23-000008:mdna:8]
•We generated $4,036 million of cash from operations.

[0001730168-23-000008:mdna:9]
•We paid $1,926 million in cash dividends.

[0001730168-23-000008:mdna:10]
•We repurchased $1,188 million of common stock.

[0001730168-23-000008:mdna:11]
[same as prior period, unchanged from 0001730168-22-000094:mdna:11]

[0001730168-23-000008:mdna:12]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. We will also assume VMware’s closing date outstanding debt, net of expected cash.

[0001730168-23-000008:mdna:13]
[same as prior period, unchanged from 0001730168-22-000094:mdna:13]

[0001730168-23-000008:mdna:14]
We will assume all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-23-000008:mdna:15]
[same as prior period, unchanged from 0001730168-22-000094:mdna:15]

[0001730168-23-000008:mdna:16]
[same as prior period, unchanged from 0001730168-22-000094:mdna:16]

[0001730168-23-000008:mdna:17]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023 (“fiscal year 2023”), is subject to satisfaction or waiver of customary closing conditions, including the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 and clearance under the antitrust laws of the European Union and certain other jurisdictions. On October 3, 2022, we registered approximately 59 million shares of our common stock. On November 4, 2022, VMware stockholders adopted the VMware Merger Agreement. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-23-000008:mdna:18]
[same as prior period, unchanged from 0001730168-22-000094:mdna:24]

[0001730168-23-000008:mdna:19]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting estimates are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those estimates include revenue recognition, valuation of goodwill and long-lived assets, and income taxes.

[0001730168-23-000008:mdna:20]
There were no significant changes in our critical accounting estimates during the fiscal quarter ended January 29, 2023 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2022 Annual Report on Form 10-K.

[0001730168-23-000008:mdna:21]
23

[0001730168-23-000008:mdna:22]
[same as prior period, unchanged from 0001730168-22-000094:mdna:27]

[0001730168-23-000008:mdna:23]
Fiscal Quarter Ended January 29, 2023 Compared to Fiscal Quarter Ended January 30, 2022

[0001730168-23-000008:mdna:24]
The following table sets forth our results of operations for the periods presented:

[0001730168-23-000008:mdna:25]
|  |  | Fiscal Quarter Ended |
|  |  | January 29,2023 |  | January 30,2022 |  | January 29,2023 |  | January 30,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 7,082 |  |  | $ | 6,053 |  |  | 79 | % |  | 79 | % |
| Subscriptions and services |  | 1,833 |  |  | 1,653 |  |  | 21 |  |  | 21 |  |
| Total net revenue |  | 8,915 |  |  | 7,706 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,225 |  |  | 1,769 |  |  | 25 |  |  | 23 |  |
| Cost of subscriptions and services |  | 149 |  |  | 156 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 535 |  |  | 730 |  |  | 6 |  |  | 9 |  |
| Restructuring charges |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,911 |  |  | 2,657 |  |  | 33 |  |  | 34 |  |
| Gross margin |  | 6,004 |  |  | 5,049 |  |  | 67 |  |  | 66 |  |
| Research and development |  | 1,195 |  |  | 1,206 |  |  | 13 |  |  | 16 |  |
| Selling, general and administrative |  | 348 |  |  | 321 |  |  | 4 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 397 |  |  | 4 |  |  | 5 |  |
| Restructuring, impairment and disposal charges |  | 10 |  |  | 17 |  |  | — |  |  | — |  |
| Total operating expenses |  | 1,901 |  |  | 1,941 |  |  | 21 |  |  | 25 |  |
| Operating income |  | $ | 4,103 |  |  | $ | 3,108 |  |  | 46 | % |  | 41 | % |

[0001730168-23-000008:mdna:26]
[same as prior period, unchanged from 0001730168-22-000094:mdna:33]

[0001730168-23-000008:mdna:27]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 22% and 23% of our net revenue for the fiscal quarters ended January 29, 2023 and January 30, 2022, respectively.

[0001730168-23-000008:mdna:28]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarters ended January 29, 2023 and January 30, 2022. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% and 25% of our net revenue for the fiscal quarters ended January 29, 2023 and January 30, 2022, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-23-000008:mdna:29]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile devices. In addition, the macroeconomic environment remains uncertain and may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-23-000008:mdna:30]
[same as prior period, unchanged from 0001730168-22-000094:mdna:10]

[0001730168-23-000008:mdna:31]
[same as prior period, unchanged from 0001730168-22-000094:mdna:38]

[0001730168-23-000008:mdna:32]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Net Revenue by Segment |  | January 29, 2023 |  | January 30, 2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 7,107 |  |  | $ | 5,873 |  |  | $ | 1,234 |  |  | 21 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,808 |  |  | 1,833 |  |  | (25) |  |  | (1) | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 8,915 |  |  | $ | 7,706 |  |  | $ | 1,209 |  |  | 16 | % |  |  |  |  |  |  |  |  |

[0001730168-23-000008:mdna:33]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | January 29,2023 |  | January 30,2022 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 80 | % |  | 76 | % |  |  |  |  |
| Infrastructure software |  | 20 |  |  | 24 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-23-000008:mdna:34]
Net revenue from our semiconductor solutions segment increased due to strong product demand, primarily for server storage, networking and broadband products. Net revenue from our infrastructure software segment decreased primarily due to lower demand for our FC SAN products, partially offset by higher demand for our mainframe solutions products.

[0001730168-23-000008:mdna:35]
[same as prior period, unchanged from 0001730168-22-000094:mdna:42]

[0001730168-23-000008:mdna:36]
Gross margin was $6,004 million, or 67% of net revenue, for the fiscal quarter ended January 29, 2023 compared to $5,049 million, or 66% of net revenue, for the fiscal quarter ended January 30, 2022. The increase was primarily due to lower amortization of acquisition-related intangible assets, mainly from our 2016 acquisition of Broadcom Corporation, partially offset by less favorable margin within our semiconductor solutions segment driven by product mix.

[0001730168-23-000008:mdna:37]
[same as prior period, unchanged from 0001730168-22-000094:mdna:45]

[0001730168-23-000008:mdna:38]
Research and development expense decreased $11 million, or 1%, for the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period, primarily due to lower variable employee compensation expense, partially offset by an increase in headcount.

[0001730168-23-000008:mdna:39]
[same as prior period, unchanged from 0001730168-22-000094:mdna:47]

[0001730168-23-000008:mdna:40]
Selling, general and administrative expense increased $27 million, or 8%, for the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period, primarily due to higher costs incurred in connection with the pending VMware Merger, partially offset by lower variable employee compensation expense.

[0001730168-23-000008:mdna:41]
[same as prior period, unchanged from 0001730168-22-000094:mdna:49]

[0001730168-23-000008:mdna:42]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $49 million, or 12%, for the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period primarily due to lower amortization of customer-related intangible assets from our acquisition of LSI Corporation.

[0001730168-23-000008:mdna:43]
[same as prior period, unchanged from 0001730168-22-000094:mdna:51]

[0001730168-23-000008:mdna:44]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $7 million, or 41%, for the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period primarily due to lower lease-related charges following the completion of key restructuring activities from acquisitions.

[0001730168-23-000008:mdna:45]
[same as prior period, unchanged from 0001730168-22-000094:mdna:54]

[0001730168-23-000008:mdna:46]
Total stock-based compensation expense was $391 million and $387 million for the fiscal quarters ended January 29, 2023 and January 30, 2022, respectively.

[0001730168-23-000008:mdna:47]
[same as prior period, unchanged from 0001730168-22-000094:mdna:23]

[0001730168-23-000008:mdna:48]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of January 29, 2023. The remaining weighted-average service period was 2.8 years.

[0001730168-23-000008:mdna:49]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 935 |  |
| 2024 |  | 948 |  |
| 2025 |  | 604 |  |
| 2026 |  | 225 |  |
| 2027 |  | 51 |  |
| Total |  | $ | 2,763 |  |

[0001730168-23-000008:mdna:50]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-23-000008:mdna:51]
[same as prior period, unchanged from 0001730168-22-000094:mdna:59]

[0001730168-23-000008:mdna:52]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Operating Income by Segment |  | January 29,2023 |  | January 30,2022 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 4,123 |  |  | $ | 3,349 |  |  | $ | 774 |  |  | 23 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,307 |  |  | 1,307 |  |  | — |  |  | — | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (1,327) |  |  | (1,548) |  |  | 221 |  |  | (14) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 4,103 |  |  | $ | 3,108 |  |  | $ | 995 |  |  | 32 | % |  |  |  |  |  |  |  |  |

[0001730168-23-000008:mdna:53]
Operating income from our semiconductor solutions segment increased primarily due to higher net revenue from server storage, networking and broadband products. Operating income from our infrastructure software segment was flat.

[0001730168-23-000008:mdna:54]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 14% for the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period, primarily due to lower amortization of acquisition-related intangible assets.

[0001730168-23-000008:mdna:55]
[same as prior period, unchanged from 0001730168-22-000094:mdna:63]

[0001730168-23-000008:mdna:56]
Interest expense. Interest expense was $406 million and $407 million for the fiscal quarters ended January 29, 2023 and January 30, 2022, respectively. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the pending VMware Merger.

[0001730168-23-000008:mdna:57]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $143 million for the fiscal quarter ended January 29, 2023, compared to other expense, net, of $14 million for the fiscal quarter ended January 30, 2022. The change was primarily due to higher interest income as a result of higher interest rates and changes in investment gains or losses.

[0001730168-23-000008:mdna:58]
Provision for income taxes. The provision for income taxes was $66 million for the fiscal quarter ended January 29, 2023, compared to $215 million for the fiscal quarter ended January 30, 2022. The decrease was primarily due to the recognition of uncertain tax benefits as a result of lapses of statutes of limitations, partially offset by higher income before income taxes.

[0001730168-23-000008:mdna:59]
[same as prior period, unchanged from 0001730168-22-000094:mdna:67]

[0001730168-23-000008:mdna:60]
[same as prior period, unchanged from 0001730168-22-000094:mdna:68]

[0001730168-23-000008:mdna:61]
Our primary sources of liquidity as of January 29, 2023 consisted of: (i) $12,647 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-23-000008:mdna:62]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including the pending VMware Merger, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $40,958 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2023 as compared to fiscal year 2022. Our debt and liquidity needs will increase as a result of the pending VMware Merger, and we intend to fund the cash portion of the consideration with $32 billion in new, fully committed debt financing.

[0001730168-23-000008:mdna:63]
We believe that our cash and cash equivalents on hand, cash flows from operations, our revolving credit facility, as well as the committed debt funding related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-23-000008:mdna:64]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-23-000008:mdna:65]
[same as prior period, unchanged from 0001730168-22-000094:mdna:75]

[0001730168-23-000008:mdna:66]
[same as prior period, unchanged from 0001730168-22-000094:mdna:76]

[0001730168-23-000008:mdna:67]
Working capital decreased to $11,353 million at January 29, 2023 from $11,452 million at October 30, 2022. The decrease was primarily attributable to the following:

[0001730168-23-000008:mdna:68]
•Current portion of long-term debt increased to $1,115 million at January 29, 2023 from $440 million at October 30, 2022 due to certain debt instruments becoming due within the next twelve months, partially offset by a repayment.

[0001730168-23-000008:mdna:69]
•Other current liabilities increased to $4,909 million at January 29, 2023 from $4,412 million at October 30, 2022, primarily due to increases in income taxes payable, contract liabilities and derivative liabilities.

[0001730168-23-000008:mdna:70]
•Other current assets decreased to $1,056 million at January 29, 2023 from $1,205 million at October 30, 2022, primarily due to a decrease in prepaid income taxes.

[0001730168-23-000008:mdna:71]
[same as prior period, unchanged from 0001730168-22-000094:mdna:80]

[0001730168-23-000008:mdna:72]
•Employee compensation and benefits decreased to $536 million at January 29, 2023 from $1,202 million at October 30, 2022, primarily due to the timing of employee bonus plan payments.

[0001730168-23-000008:mdna:73]
•Accounts receivable increased to $3,234 million at January 29, 2023 from $2,958 million at October 30, 2022, primarily due to revenue linearity, offset by higher receivables sold through factoring arrangements.

[0001730168-23-000008:mdna:74]
•Cash and cash equivalents increased to $12,647 million at January 29, 2023 from $12,416 million at October 30, 2022, primarily due to $4,036 million in net cash provided by operating activities, substantially offset by $1,926

[0001730168-23-000008:mdna:75]
million of dividend payments, $1,188 million of common stock repurchases, $333 million of employee withholding tax payments related to net settled equity awards, and $260 million of a debt payment.

[0001730168-23-000008:mdna:76]
[same as prior period, unchanged from 0001730168-22-000094:mdna:84]

[0001730168-23-000008:mdna:77]
|  |  | Fiscal Quarter Ended |
| Cash Dividends Declared and Paid |  | January 29,2023 |  | January 30,2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 4.60 |  |  | $ | 4.10 |  |
| Dividends to common stockholders |  | $ | 1,926 |  |  | $ | 1,689 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 20.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 75 |  |

[0001730168-23-000008:mdna:78]
On September 30, 2019, we issued approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share. These shares were converted into shares of our common stock during fiscal year 2022.

[0001730168-23-000008:mdna:79]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2022, which was subsequently extended to December 31, 2023 (the “December 2021 Authorization”). In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023 (the “May 2022 Authorization”).

[0001730168-23-000008:mdna:80]
During the fiscal quarters ended January 29, 2023 and January 30, 2022, we repurchased and retired approximately 2 million and 4 million shares of our common stock for $1,188 million and $2,724 million, respectively, under these stock repurchase programs.

[0001730168-23-000008:mdna:81]
Repurchases under our stock repurchase programs may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-23-000008:mdna:82]
During the fiscal quarters ended January 29, 2023 and January 30, 2022, we paid approximately $333 million and $375 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 1 million shares of common stock from employees in connection with such net share settlements during each of the fiscal quarters ended January 29, 2023 and January 30, 2022.

[0001730168-23-000008:mdna:83]
[same as prior period, unchanged from 0001730168-22-000094:mdna:90]

[0001730168-23-000008:mdna:84]
|  |  | Fiscal Quarter Ended |
|  |  | January 29,2023 |  | January 30,2022 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 4,036 |  |  | $ | 3,486 |  |
| Net cash used in investing activities |  | (103) |  |  | (309) |  |
| Net cash used in financing activities |  | (3,702) |  |  | (5,121) |  |
| Net change in cash and cash equivalents |  | $ | 231 |  |  | $ | (1,944) |  |

[0001730168-23-000008:mdna:85]
[same as prior period, unchanged from 0001730168-22-000094:mdna:92]

[0001730168-23-000008:mdna:86]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $550 million increase in cash provided by operations during the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period was primarily due to $1,302 million higher net income and a $196 million increase resulting from changes in operating assets and liabilities, offset in part by $948 million lower non-cash adjustments including deferred taxes and other non-cash taxes, and amortization of intangible assets.

[0001730168-23-000008:mdna:87]
[same as prior period, unchanged from 0001730168-22-000094:mdna:94]

[0001730168-23-000008:mdna:88]
Cash flows from investing activities primarily consisted of capital expenditures and purchases of investments. The $206 million decrease in cash used in investing activities during the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period was primarily due to $200 million in investment purchases in the prior year fiscal period.

[0001730168-23-000008:mdna:89]
[same as prior period, unchanged from 0001730168-22-000094:mdna:96]

[0001730168-23-000008:mdna:90]
Cash flows from financing activities primarily consisted of our dividend payments, stock repurchases, employee withholding tax payments related to net settled equity awards, and payments related to long-term borrowings. The $1,419 million decrease in cash used in financing activities during the fiscal quarter ended January 29, 2023 compared to the prior year fiscal period was primarily due to a $1,536 million decrease in stock repurchases, offset in part by a $162 million increase in dividend payments.

[0001730168-23-000008:mdna:91]
[same as prior period, unchanged from 0001730168-22-000094:mdna:98]

[0001730168-23-000008:mdna:92]
[same as prior period, unchanged from 0001730168-22-000094:mdna:99]
