# AVGO notes — 0001730168-19-000036


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock

[0001730168-19-000036:notes:1]
The future scheduled principal payments for debt as of February 3, 2019 were as follows:

[0001730168-19-000036:notes:2]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | — |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 1,650 |  |
| 2022 |  | 13,909 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 16,213 |  |
| Total |  | $ | 37,859 |  |


## avgo:ScheduleofIntangibleAssetsbyMajorClassTableTextBlock

[0001730168-19-000036:notes:3]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of February 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,783 |  |  | $ | (7,643 | ) |  | $ | 13,140 |  |
| Customer contracts and related relationships |  | 5,982 |  |  | (1,107 | ) |  | 4,875 |  |
| Order backlog |  | 2,569 |  |  | (227 | ) |  | 2,342 |  |
| Trade names |  | 712 |  |  | (189 | ) |  | 523 |  |
| Other |  | 243 |  |  | (63 | ) |  | 180 |  |
| Intangible assets subject to amortization |  | 30,289 |  |  | (9,229 | ) |  | 21,060 |  |
| IPR&D |  | 433 |  |  | — |  |  | 433 |  |
| Total |  | $ | 30,722 |  |  | $ | (9,229 | ) |  | $ | 21,493 |  |
| As of November 4, 2018: |  |  |  |  |  |  |
| Purchased technology |  | $ | 15,806 |  |  | $ | (6,816 | ) |  | $ | 8,990 |  |
| Customer contracts and related relationships |  | 1,792 |  |  | (878 | ) |  | 914 |  |
| Trade names |  | 578 |  |  | (170 | ) |  | 408 |  |
| Other |  | 239 |  |  | (53 | ) |  | 186 |  |
| Intangible assets subject to amortization |  | 18,415 |  |  | (7,917 | ) |  | 10,498 |  |
| IPR&D |  | 264 |  |  | — |  |  | 264 |  |
| Total |  | $ | 18,679 |  |  | $ | (7,917 | ) |  | $ | 10,762 |  |


## srt:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0001730168-19-000036:notes:4]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 1,150 |  |  | — |  |  | 1,150 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 397 |  |  | — |  |  | (397 | ) |  | — |  |
| Total net revenue |  | — |  |  | — |  |  | 397 |  |  | 5,789 |  |  | (397 | ) |  | 5,789 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 31 |  |  | 1,523 |  |  | — |  |  | 1,554 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 3 |  |  | 135 |  |  | — |  |  | 138 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 23 |  |  | (23 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 833 |  |  | — |  |  | 833 |  |
| Restructuring charges |  | — |  |  | — |  |  | (7 | ) |  | 63 |  |  | — |  |  | 56 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 27 |  |  | 2,577 |  |  | (23 | ) |  | 2,581 |  |
| Gross margin |  | — |  |  | — |  |  | 370 |  |  | 3,212 |  |  | (374 | ) |  | 3,208 |  |
| Research and development |  | — |  |  | — |  |  | 447 |  |  | 686 |  |  | — |  |  | 1,133 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 374 |  |  | (374 | ) |  | — |  |
| Selling, general and administrative |  | 52 |  |  | — |  |  | 81 |  |  | 338 |  |  | — |  |  | 471 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 476 |  |  | — |  |  | 476 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 8 |  |  | 565 |  |  | — |  |  | 573 |  |
| Total operating expenses |  | 52 |  |  | — |  |  | 536 |  |  | 2,439 |  |  | (374 | ) |  | 2,653 |  |
| Operating income (loss) |  | (52 | ) |  | — |  |  | (166 | ) |  | 773 |  |  | — |  |  | 555 |  |
| Interest expense |  | (175 | ) |  | — |  |  | (148 | ) |  | (22 | ) |  | — |  |  | (345 | ) |
| Intercompany interest expense |  | (86 | ) |  | — |  |  | (41 | ) |  | (8 | ) |  | 135 |  |  | — |  |
| Other income (loss), net |  | (1 | ) |  | — |  |  | 9 |  |  | 60 |  |  | — |  |  | 68 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 79 |  |  | 56 |  |  | (135 | ) |  | — |  |
| Intercompany other income (expense), net |  | 77 |  |  | — |  |  | — |  |  | (77 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (237 | ) |  | — |  |  | (267 | ) |  | 782 |  |  | — |  |  | 278 |  |
| Provision for (benefit from) income taxes |  | (24 | ) |  | 24 |  |  | (177 | ) |  | (26 | ) |  | — |  |  | (203 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (213 | ) |  | (24 | ) |  | (90 | ) |  | 808 |  |  | — |  |  | 481 |  |
| Earnings in subsidiaries |  | 684 |  |  | 1,479 |  |  | 1,569 |  |  | — |  |  | (3,732 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 471 |  |  | 1,455 |  |  | 1,479 |  |  | 808 |  |  | (3,732 | ) |  | 481 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 1,479 |  |  | $ | 798 |  |  | $ | (3,732 | ) |  | $ | 471 |  |
| Comprehensive income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 1,479 |  |  | $ | 798 |  |  | $ | (3,732 | ) |  | $ | 471 |  |

[0001730168-19-000036:notes:5]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | February 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5,108 |  |  | $ | — |  |  | $ | 5,108 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 219 |  |  | — |  |  | 219 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 584 |  |  | — |  |  | (584 | ) |  | — |  |
| Total revenue |  | — |  |  | — |  |  | 584 |  |  | 5,327 |  |  | (584 | ) |  | 5,327 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 29 |  |  | 1,847 |  |  | — |  |  | 1,876 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 3 |  |  | 20 |  |  | — |  |  | 23 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 34 |  |  | (34 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 715 |  |  | — |  |  | 715 |  |
| Restructuring charges |  | — |  |  | — |  |  | 2 |  |  | 13 |  |  | — |  |  | 15 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 34 |  |  | 2,699 |  |  | (34 | ) |  | 2,699 |  |
| Gross margin |  | — |  |  | — |  |  | 550 |  |  | 2,628 |  |  | (550 | ) |  | 2,628 |  |
| Research and development |  | — |  |  | — |  |  | 406 |  |  | 519 |  |  | — |  |  | 925 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 550 |  |  | (550 | ) |  | — |  |
| Selling, general and administrative |  | — |  |  | — |  |  | 85 |  |  | 206 |  |  | — |  |  | 291 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 339 |  |  | — |  |  | 339 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 33 |  |  | 97 |  |  | — |  |  | 130 |  |
| Total operating expenses |  | — |  |  | — |  |  | 524 |  |  | 1,711 |  |  | (550 | ) |  | 1,685 |  |
| Operating income |  | — |  |  | — |  |  | 26 |  |  | 917 |  |  | — |  |  | 943 |  |
| Interest expense |  | — |  |  | — |  |  | (181 | ) |  | (2 | ) |  | — |  |  | (183 | ) |
| Intercompany interest expense |  | — |  |  | — |  |  | (59 | ) |  | (574 | ) |  | 633 |  |  | — |  |
| Other income, net |  | — |  |  | — |  |  | 19 |  |  | 16 |  |  | — |  |  | 35 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 574 |  |  | 59 |  |  | (633 | ) |  | — |  |
| Intercompany other income (expense), net |  | — |  |  | — |  |  | (57 | ) |  | 57 |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | — |  |  | — |  |  | 322 |  |  | 473 |  |  | — |  |  | 795 |  |
| Benefit from income taxes |  | — |  |  | — |  |  | (5,460 | ) |  | (326 | ) |  | — |  |  | (5,786 | ) |
| Income from continuing operations before earnings in subsidiaries |  | — |  |  | — |  |  | 5,782 |  |  | 799 |  |  | — |  |  | 6,581 |  |
| Earnings in subsidiaries |  | 6,230 |  |  | 6,566 |  |  | 638 |  |  | — |  |  | (13,434 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 6,230 |  |  | 6,566 |  |  | 6,420 |  |  | 799 |  |  | (13,434 | ) |  | 6,581 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Net income |  | 6,230 |  |  | 6,566 |  |  | 6,420 |  |  | 784 |  |  | (13,434 | ) |  | 6,566 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 336 |  |  | — |  |  | — |  |  | — |  |  | 336 |  |
| Net income attributable to common stock |  | $ | 6,230 |  |  | $ | 6,230 |  |  | $ | 6,420 |  |  | $ | 784 |  |  | $ | (13,434 | ) |  | $ | 6,230 |  |
| Net income |  | $ | 6,230 |  |  | $ | 6,566 |  |  | $ | 6,420 |  |  | $ | 784 |  |  | $ | (13,434 | ) |  | $ | 6,566 |  |
| Unrealized gain on available-for-sale investments |  | — |  |  | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Other comprehensive income |  | — |  |  | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Comprehensive income |  | 6,230 |  |  | 6,566 |  |  | 6,429 |  |  | 784 |  |  | (13,434 | ) |  | 6,575 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 336 |  |  | — |  |  | — |  |  | — |  |  | 336 |  |
| Comprehensive income attributable to common stock |  | $ | 6,230 |  |  | $ | 6,230 |  |  | $ | 6,429 |  |  | $ | 784 |  |  | $ | (13,434 | ) |  | $ | 6,239 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001730168-19-000036:notes:6]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | February 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | — |  |  | $ | 724 |  |  | $ | 4,369 |  |  | $ | — |  |  | $ | 5,093 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 3,677 |  |  | — |  |  | 3,677 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,074 |  |  | — |  |  | 1,074 |  |
| Intercompany receivable |  | 122 |  |  | — |  |  | 857 |  |  | 280 |  |  | (1,259 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | — |  |  | 10,372 |  |  | 9,045 |  |  | (19,417 | ) |  | — |  |
| Other current assets |  | 50 |  |  | — |  |  | 44 |  |  | 666 |  |  | — |  |  | 760 |  |
| Total current assets |  | 172 |  |  | — |  |  | 11,997 |  |  | 19,111 |  |  | (20,676 | ) |  | 10,604 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 772 |  |  | 1,912 |  |  | — |  |  | 2,684 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 35,287 |  |  | — |  |  | 36,647 |  |
| Intangible assets, net |  | — |  |  | — |  |  | 82 |  |  | 21,411 |  |  | — |  |  | 21,493 |  |
| Investment in subsidiaries |  | 54,829 |  |  | 37,121 |  |  | 48,516 |  |  | — |  |  | (140,466 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | — |  |  | 918 |  |  | (918 | ) |  | — |  |
| Other long-term assets |  | 31 |  |  | — |  |  | 47 |  |  | 604 |  |  | — |  |  | 682 |  |
| Total assets |  | $ | 55,032 |  |  | $ | 37,121 |  |  | $ | 62,774 |  |  | $ | 79,243 |  |  | $ | (162,060 | ) |  | $ | 72,110 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 17 |  |  | $ | — |  |  | $ | 69 |  |  | $ | 652 |  |  | $ | — |  |  | $ | 738 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 106 |  |  | 357 |  |  | — |  |  | 463 |  |
| Current portion of long-term debt |  | — |  |  | — |  |  | 2,750 |  |  | 787 |  |  | — |  |  | 3,537 |  |
| Intercompany payable |  | 255 |  |  | — |  |  | 95 |  |  | 909 |  |  | (1,259 | ) |  | — |  |
| Intercompany loan payable |  | 13,610 |  |  | — |  |  | 4,675 |  |  | 1,132 |  |  | (19,417 | ) |  | — |  |
| Other current liabilities |  | 62 |  |  | (72 | ) |  | 105 |  |  | 3,516 |  |  | — |  |  | 3,611 |  |
| Total current liabilities |  | 13,944 |  |  | (72 | ) |  | 7,800 |  |  | 7,353 |  |  | (20,676 | ) |  | 8,349 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 17,890 |  |  | — |  |  | 14,713 |  |  | 1,501 |  |  | — |  |  | 34,104 |  |
| Deferred tax liabilities |  | (1 | ) |  | — |  |  | (305 | ) |  | 2,382 |  |  | — |  |  | 2,076 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | 918 |  |  | — |  |  | (918 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 2,421 |  |  | 829 |  |  | — |  |  | 3,250 |  |
| Other long-term liabilities |  | (25 | ) |  | 96 |  |  | 103 |  |  | 933 |  |  | — |  |  | 1,107 |  |
| Total liabilities |  | 31,808 |  |  | 24 |  |  | 25,650 |  |  | 12,998 |  |  | (21,594 | ) |  | 48,886 |  |
| Total stockholders’ equity |  | 23,224 |  |  | 37,097 |  |  | 37,124 |  |  | 66,245 |  |  | (140,466 | ) |  | 23,224 |  |
| Total liabilities and stockholders' equity |  | $ | 55,032 |  |  | $ | 37,121 |  |  | $ | 62,774 |  |  | $ | 79,243 |  |  | $ | (162,060 | ) |  | $ | 72,110 |  |

[0001730168-19-000036:notes:7]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | — |  |  | $ | 2,461 |  |  | $ | 1,831 |  |  | $ | — |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 3,325 |  |  | — |  |  | 3,325 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,124 |  |  | — |  |  | 1,124 |  |
| Intercompany receivable |  | 56 |  |  | — |  |  | 182 |  |  | 67 |  |  | (305 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | — |  |  | 9,780 |  |  | 4,713 |  |  | (14,493 | ) |  | — |  |
| Other current assets |  | 52 |  |  | — |  |  | 37 |  |  | 277 |  |  | — |  |  | 366 |  |
| Total current assets |  | 108 |  |  | — |  |  | 12,460 |  |  | 11,337 |  |  | (14,798 | ) |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 772 |  |  | 1,863 |  |  | — |  |  | 2,635 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 25,553 |  |  | — |  |  | 26,913 |  |
| Intangible assets, net |  | — |  |  | — |  |  | 84 |  |  | 10,678 |  |  | — |  |  | 10,762 |  |
| Investment in subsidiaries |  | 35,268 |  |  | 35,268 |  |  | 46,745 |  |  | — |  |  | (117,281 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | — |  |  | 991 |  |  | (991 | ) |  | — |  |
| Other long-term assets |  | — |  |  | — |  |  | 250 |  |  | 457 |  |  | — |  |  | 707 |  |
| Total assets |  | $ | 35,376 |  |  | $ | 35,268 |  |  | $ | 61,671 |  |  | $ | 50,879 |  |  | $ | (133,070 | ) |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 19 |  |  | $ | — |  |  | $ | 44 |  |  | $ | 748 |  |  | $ | — |  |  | $ | 811 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 272 |  |  | 443 |  |  | — |  |  | 715 |  |
| Intercompany payable |  | 9 |  |  | — |  |  | 58 |  |  | 238 |  |  | (305 | ) |  | — |  |
| Intercompany loan payable |  | 8,691 |  |  | — |  |  | 4,713 |  |  | 1,089 |  |  | (14,493 | ) |  | — |  |
| Other current liabilities |  | — |  |  | — |  |  | 219 |  |  | 593 |  |  | — |  |  | 812 |  |
| Total current liabilities |  | 8,719 |  |  | — |  |  | 5,306 |  |  | 3,111 |  |  | (14,798 | ) |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | — |  |  | 17,456 |  |  | 37 |  |  | — |  |  | 17,493 |  |
| Deferred tax liabilities |  | — |  |  | — |  |  | (47 | ) |  | 216 |  |  | — |  |  | 169 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | 991 |  |  | — |  |  | (991 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 2,563 |  |  | 525 |  |  | — |  |  | 3,088 |  |
| Other long-term liabilities |  | — |  |  | — |  |  | 131 |  |  | 248 |  |  | — |  |  | 379 |  |
| Total liabilities |  | 8,719 |  |  | — |  |  | 26,400 |  |  | 4,137 |  |  | (15,789 | ) |  | 23,467 |  |
| Total stockholders’ equity |  | 26,657 |  |  | 35,268 |  |  | 35,271 |  |  | 46,742 |  |  | (117,281 | ) |  | 26,657 |  |
| Total liabilities and stockholders' equity |  | $ | 35,376 |  |  | $ | 35,268 |  |  | $ | 61,671 |  |  | $ | 50,879 |  |  | $ | (133,070 | ) |  | $ | 50,124 |  |


## srt:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001730168-19-000036:notes:8]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 1,479 |  |  | $ | 798 |  |  | $ | (3,732 | ) |  | $ | 471 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (561 | ) |  | (1,455 | ) |  | (2,475 | ) |  | 2,420 |  |  | 3,732 |  |  | 1,661 |  |
| Net cash provided by (used in) operating activities |  | (90 | ) |  | — |  |  | (996 | ) |  | 3,218 |  |  | — |  |  | 2,132 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | 800 |  |  | — |  |  | (592 | ) |  | (3,087 | ) |  | 2,879 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | (17,865 | ) |  | — |  |  | — |  |  | 1,838 |  |  | — |  |  | (16,027 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 957 |  |  | — |  |  | 957 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (36 | ) |  | (71 | ) |  | 8 |  |  | (99 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 8 |  |  | — |  |  | (8 | ) |  | — |  |
| Other |  | — |  |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | (24 | ) |
| Net cash provided by (used in) investing activities |  | (17,065 | ) |  | — |  |  | (620 | ) |  | (387 | ) |  | 2,879 |  |  | (15,193 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Dividend and distribution payments |  | (1,067 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,067 | ) |
| Net intercompany borrowings |  | 3,746 |  |  | — |  |  | (110 | ) |  | (757 | ) |  | (2,879 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 17,896 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17,896 |  |
| Other borrowings |  | — |  |  | — |  |  | — |  |  | 531 |  |  | — |  |  | 531 |  |
| Payment of debt issuance costs |  | (46 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (46 | ) |
| Repurchases of common stock - repurchase program |  | (3,436 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (3,436 | ) |
| Issuance of common stock |  | 62 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 62 |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | — |  |  | (11 | ) |  | (66 | ) |  | — |  |  | (77 | ) |
| Other |  | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net cash provided by (used in) financing activities |  | 17,155 |  |  | — |  |  | (121 | ) |  | (293 | ) |  | (2,879 | ) |  | 13,862 |  |
| Net change in cash and cash equivalents |  | — |  |  | — |  |  | (1,737 | ) |  | 2,538 |  |  | — |  |  | 801 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | — |  |  | 2,461 |  |  | 1,831 |  |  | — |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | — |  |  | $ | 724 |  |  | $ | 4,369 |  |  | $ | — |  |  | $ | 5,093 |  |

[0001730168-19-000036:notes:9]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Quarter Ended |
|  |  | February 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 6,230 |  |  | $ | 6,566 |  |  | $ | 6,420 |  |  | $ | 784 |  |  | $ | (13,434 | ) |  | $ | 6,566 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (6,230 | ) |  | (6,566 | ) |  | (6,763 | ) |  | 1,244 |  |  | 13,434 |  |  | (4,881 | ) |
| Net cash provided by (used in) operating activities |  | — |  |  | — |  |  | (343 | ) |  | 2,028 |  |  | — |  |  | 1,685 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | — |  |  | (9,099 | ) |  | (2,900 | ) |  | 11,999 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | — |  |  | — |  |  | 755 |  |  | (755 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | — |  |  | 93 |  |  | (4,241 | ) |  | 4,148 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (4,786 | ) |  | — |  |  | (4,786 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 782 |  |  | — |  |  | 782 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (65 | ) |  | (155 | ) |  | — |  |  | (220 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 2 |  |  | 235 |  |  | — |  |  | 237 |  |
| Purchases of investments |  | — |  |  | — |  |  | (50 | ) |  | (194 | ) |  | — |  |  | (244 | ) |
| Other |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net cash provided by (used in) investing activities |  | — |  |  | — |  |  | (9,119 | ) |  | (10,500 | ) |  | 15,392 |  |  | (4,227 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | — |  |  | 2,900 |  |  | 9,099 |  |  | (11,999 | ) |  | — |  |
| Net intercompany borrowings |  | — |  |  | — |  |  | 4,270 |  |  | (122 | ) |  | (4,148 | ) |  | — |  |
| Repayment of debt |  | — |  |  | — |  |  | — |  |  | (856 | ) |  | — |  |  | (856 | ) |
| Dividend and distribution payments |  | — |  |  | — |  |  | (755 | ) |  | (755 | ) |  | 755 |  |  | (755 | ) |
| Issuance of common stock |  | — |  |  | — |  |  | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Other |  | — |  |  | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net cash provided by (used in) financing activities |  | — |  |  | — |  |  | 6,415 |  |  | 7,391 |  |  | (15,392 | ) |  | (1,586 | ) |
| Net change in cash and cash equivalents |  | — |  |  | — |  |  | (3,047 | ) |  | (1,081 | ) |  | — |  |  | (4,128 | ) |
| Cash and cash equivalents at beginning of period |  | — |  |  | — |  |  | 7,555 |  |  | 3,649 |  |  | — |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | — |  |  | $ | 4,508 |  |  | $ | 2,568 |  |  | $ | — |  |  | $ | 7,076 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-19-000036:notes:10]
Supplemental Financial Information

[0001730168-19-000036:notes:11]
Cash Equivalents

[0001730168-19-000036:notes:12]
Cash equivalents included $1,111 million and $1,406 million of time deposits as of February 3, 2019 and November 4, 2018, respectively. As of February 3, 2019 and November 4, 2018, cash equivalents also included $318 million and $202 million of money-market funds, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-19-000036:notes:13]
Inventory

[0001730168-19-000036:notes:14]
|  |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Finished goods |  | $ | 445 |  |  | $ | 483 |  |
| Work-in-process |  | 511 |  |  | 505 |  |
| Raw materials |  | 118 |  |  | 136 |  |
| Total inventory |  | $ | 1,074 |  |  | $ | 1,124 |  |

[0001730168-19-000036:notes:15]
Other Current Assets

[0001730168-19-000036:notes:16]
|  |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 304 |  |  | $ | 243 |  |
| Other (miscellaneous) |  | 456 |  |  | 123 |  |
| Total other current assets |  | $ | 760 |  |  | $ | 366 |  |

[0001730168-19-000036:notes:17]
Other Current Liabilities

[0001730168-19-000036:notes:18]
|  |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 1,692 |  |  | $ | 164 |  |
| Notional pooling liabilities |  | 549 |  |  | — |  |
| Tax liabilities |  | 656 |  |  | 162 |  |
| Other (miscellaneous) |  | 714 |  |  | 486 |  |
| Total other current liabilities |  | $ | 3,611 |  |  | $ | 812 |  |

[0001730168-19-000036:notes:19]
We use a notional pooling arrangement with an international bank to assist us in the management of global liquidity. Under this arrangement, we maintain either a cash deposit or borrowing position through local currency accounts, so long as the aggregate global pooling position is a notionally calculated net cash deposit.

[0001730168-19-000036:notes:20]
Other Long-Term Liabilities

[0001730168-19-000036:notes:21]
|  |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Unrecognized tax benefits (a) (b) |  | $ | 3,250 |  |  | $ | 3,088 |  |
| Deferred tax liabilities (a) |  | 2,076 |  |  | 169 |  |
| Contract liabilities |  | 517 |  |  | 66 |  |
| Other (miscellaneous) |  | 590 |  |  | 313 |  |
| Total other long-term liabilities |  | $ | 6,433 |  |  | $ | 3,636 |  |

[0001730168-19-000036:notes:22]
________________________________

[0001730168-19-000036:notes:23]
(a) Refer to Note 9. “Income Taxes” for additional information regarding these balances.

[0001730168-19-000036:notes:24]
(b) Includes accrued interest and penalties.

[0001730168-19-000036:notes:25]
Supplemental Cash Flow Information

[0001730168-19-000036:notes:26]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 423 |  |  | $ | 232 |  |
| Cash paid for income taxes |  | $ | 95 |  |  | $ | 109 |  |

[0001730168-19-000036:notes:27]
As of February 3, 2019 and November 4, 2018, we had $44 million and $22 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001730168-19-000036:notes:28]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 3, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001730168-19-000036:notes:29]
|  |  | Fiscal Quarter Ended |
|  |  | February 4, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,447 |  |
| Pro forma net income attributable to common stock |  | $ | 6,333 |  |

[0001730168-19-000036:notes:30]
* Pro forma net revenue is presented under Topic 605 for the fiscal quarter ended February 4, 2018.

[0001730168-19-000036:notes:31]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,561 |  |  | $ | 6,166 |  |
| Pro forma net income attributable to common stock |  | $ | 795 |  |  | $ | 4,844 |  |

[0001730168-19-000036:notes:32]
* Pro forma net revenue is presented under Topic 606 for the fiscal quarter ended February 3, 2019 and under Topic 605 for the fiscal quarter ended February 4, 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-19-000036:notes:33]
[same as prior period, unchanged from 0001730168-18-000039:notes:17]

[0001730168-19-000036:notes:34]
Acquisition of CA, Inc.

[0001730168-19-000036:notes:35]
On November 5, 2018, we acquired CA, which was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities. We financed the CA Merger with the net proceeds from borrowings under the new term loans, as discussed in further detail in Note 7. “Borrowings,” as well as with cash on hand of the combined companies.

[0001730168-19-000036:notes:36]
[same as prior period, unchanged from 0001730168-18-000039:notes:20]

[0001730168-19-000036:notes:37]
|  |  | (In millions) |
| Cash paid for outstanding CA common stock |  | $ | 18,402 |  |
| Cash paid by Broadcom to retire CA’s term loan |  | 274 |  |
| Cash paid for vested CA equity awards |  | 101 |  |
| Fair value of partially vested assumed equity awards |  | 67 |  |
| Total purchase consideration |  | 18,844 |  |
| Less: cash acquired |  | 2,750 |  |
| Total purchase consideration, net of cash acquired |  | $ | 16,094 |  |

[0001730168-19-000036:notes:38]
All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon the completion of the CA Merger. We assumed all unvested CA equity awards held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of CA employees represents a component of the total consideration as presented above. Partially vested assumed equity awards were valued based on our share price as of the CA Acquisition Date.

[0001730168-19-000036:notes:39]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on their estimated fair values. The fair value of identified intangible assets acquired was based on estimates and assumptions made by management at the time of acquisition. As additional information becomes available, we may further revise our preliminary purchase price allocation during the remainder of the measurement period (which will not exceed 12 months from the CA Acquisition Date). Any such revisions or changes may be material.

[0001730168-19-000036:notes:40]
[same as prior period, unchanged from 0001730168-18-000039:notes:24]

[0001730168-19-000036:notes:41]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,692 |  |
| Goodwill |  | 9,734 |  |
| Intangible assets |  | 12,045 |  |
| Other long-term assets |  | 237 |  |
| Total assets acquired |  | 23,708 |  |
| Other current liabilities |  | (1,966 | ) |
| Long-term debt |  | (2,255 | ) |
| Other long-term liabilities |  | (3,393 | ) |
| Total liabilities assumed |  | (7,614 | ) |
| Fair value of net assets acquired |  | $ | 16,094 |  |

[0001730168-19-000036:notes:42]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the CA business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the CA Merger. Goodwill is not deductible for tax purposes.

[0001730168-19-000036:notes:43]
Current assets included assets held-for-sale related to CA’s Veracode business, which was not aligned with our strategic objectives. On December 31, 2018, we sold this business to Thoma Bravo, LLC, or Thoma Bravo, for cash consideration of $950 million, before working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Current assets also included $102 million of real properties held-for-sale.

[0001730168-19-000036:notes:44]
Revenue attributable to CA has been included in our infrastructure software segment. Transaction costs of $62 million related to the CA Merger were included in selling, general and administrative expense for the fiscal quarter ended February 3, 2019.

[0001730168-19-000036:notes:45]
Intangible Assets

[0001730168-19-000036:notes:46]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 4,957 |  |  | 6 |
| Customer contracts and related relationships |  | 4,190 |  |  | 6 |
| Order backlog |  | 2,569 |  |  | 3 |
| Trade name and other |  | 137 |  |  | 5 |
| Total identified finite-lived intangible assets |  | 11,853 |  |  |  |
| In-process research and development |  | 192 |  |  | N/A |
| Total identified intangible assets |  | $ | 12,045 |  |  |  |

[0001730168-19-000036:notes:47]
Developed technology relates to products used for mission critical business tools for processes and applications, as well as products used for cloud-based planning, development, management and security tools. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-19-000036:notes:48]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of CA. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-19-000036:notes:49]
Order backlog represents business under existing contractual obligations. The fair value of backlog was determined using the multi-period excess earnings method under the income approach based on expected operating cash flows from future contractual revenue. The economic useful life was determined based on the expected life of the backlog and the cash flows over the forecast period.

[0001730168-19-000036:notes:50]
Trade name relates to the “CA” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-19-000036:notes:51]
[same as prior period, unchanged from 0001730168-18-000039:notes:33]

[0001730168-19-000036:notes:52]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the CA Acquisition Date.

[0001730168-19-000036:notes:53]
[same as prior period, unchanged from 0001730168-18-000039:notes:35]

[0001730168-19-000036:notes:54]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Mainframe |  | $ | 178 |  |  | 67 | % |  | $ | 138 |  |  | 2019 |
| Enterprise Solutions |  | $ | 14 |  |  | 63 | % |  | $ | 12 |  |  | 2019 |

[0001730168-19-000036:notes:55]
[same as prior period, unchanged from 0001730168-18-000039:notes:38]

[0001730168-19-000036:notes:56]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if CA had been acquired as of the beginning of fiscal year 2018. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the fiscal quarter ended February 4, 2018, non-recurring pro forma adjustments directly attributable to the CA Merger included acquisition costs of $169 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-19-000036:notes:57]
Acquisition of Brocade Communications Systems, Inc.

[0001730168-19-000036:notes:58]
On November 17, 2017, we acquired Brocade Communications Systems, Inc., or Brocade. Brocade was a supplier of networking hardware, software and services, including Fibre Channel Storage Area Network solutions and Internet Protocol Networking solutions. We acquired Brocade to enhance our position as a provider of enterprise storage connectivity solutions, to broaden our portfolio for enterprise storage, and to increase our ability to address the evolving needs of our original equipment manufacturer, or OEM, customers.

[0001730168-19-000036:notes:59]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if Brocade had been acquired as of the beginning of our fiscal year ended October 29, 2017, or fiscal year 2017. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2017 or of the results of our future operations of the combined business.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-19-000036:notes:60]
Commitments and Contingencies

[0001730168-19-000036:notes:61]
Commitments

[0001730168-19-000036:notes:62]
The following table summarizes contractual obligations and commitments as of February 3, 2019 that materially changed from the end of fiscal year 2018:

[0001730168-19-000036:notes:63]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 (remainder) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 43,716 |  |  | $ | 861 |  |  | $ | 5,231 |  |  | $ | 2,810 |  |  | $ | 14,745 |  |  | $ | 2,854 |  |  | $ | 17,215 |  |
| Purchase commitments |  | 809 |  |  | 718 |  |  | 72 |  |  | 19 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 245 |  |  | 134 |  |  | 87 |  |  | 15 |  |  | 6 |  |  | 3 |  |  | — |  |
| Operating lease obligations |  | 919 |  |  | 101 |  |  | 119 |  |  | 100 |  |  | 71 |  |  | 63 |  |  | 465 |  |
| Total |  | $ | 45,689 |  |  | $ | 1,814 |  |  | $ | 5,509 |  |  | $ | 2,944 |  |  | $ | 14,822 |  |  | $ | 2,920 |  |  | $ | 17,680 |  |

[0001730168-19-000036:notes:64]
Debt Principal, Interest and Fees. Represents principal and estimated interest on borrowings under the 2019 Term Loans, Revolver Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our 2019 Term Loans, which are subject to a floating interest rate, the estimated interest was based on the interest rate in place during the last month of the fiscal quarter ended February 3, 2019.

[0001730168-19-000036:notes:65]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with internal fabrication facility expansion and construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-19-000036:notes:66]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-19-000036:notes:67]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $67 million and $71 million for the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively.

[0001730168-19-000036:notes:68]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 3, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,250 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 3, 2019 have been excluded from the contractual obligations table above.

[0001730168-19-000036:notes:69]
Standby Letters of Credit

[0001730168-19-000036:notes:70]
As of February 3, 2019 and November 4, 2018, we had outstanding obligations relating to standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees. The fair values of the letters of credit approximate the contract amounts.

[0001730168-19-000036:notes:71]
Contingencies

[0001730168-19-000036:notes:72]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-19-000036:notes:73]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-19-000036:notes:74]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation, or Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court. On January 4, 2019, the United States Supreme Court granted certiorari. On February 19, 2019, the Defendants-Appellees (as Petitioners in the United States Supreme Court) filed their opening brief. The Plaintiff-Appellant’s brief is to be filed by March 21, 2019 and oral arguments are scheduled for April 15, 2019. We believe these claims are all without merit and intend to vigorously defend these actions.

[0001730168-19-000036:notes:75]
Other Matters

[0001730168-19-000036:notes:76]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-19-000036:notes:77]
Contingency Assessment

[0001730168-19-000036:notes:78]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, taken individually or as a whole, will have a material adverse effect on our financial condition, results of operations or cash flows. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-19-000036:notes:79]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our results of operations, financial position or cash flows.

[0001730168-19-000036:notes:80]
Other Indemnifications

[0001730168-19-000036:notes:81]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-19-000036:notes:82]
[same as prior period, unchanged from 0001730168-18-000039:notes:83]

[0001730168-19-000036:notes:83]
The following information sets forth the condensed consolidating financial information as of February 3, 2019 and November 4, 2018 and for the fiscal quarters ended February 3, 2019 and February 4, 2018 for the Parent Guarantor, the Subsidiary Guarantor, the Subsidiary Issuers, and our other subsidiaries, collectively, the Non-Guarantor Subsidiaries. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor, the Subsidiary Guarantor, the Subsidiary Issuers and the Non-Guarantor Subsidiaries are reflected in the eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.

[0001730168-19-000036:notes:84]
See Note 7. “Borrowings” for more information regarding the 2017 Senior Notes and the change in guarantors that occurred in the first quarter of fiscal year 2019. We have applied the impacts of the change in guarantors retrospectively to all periods presented.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001730168-19-000036:notes:85]
Contract assets and contract liabilities balances for the periods indicated below were as follows:

[0001730168-19-000036:notes:86]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

[0001730168-19-000036:notes:87]
* We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.


## us-gaap:DebtDisclosureTextBlock

[0001730168-19-000036:notes:88]
Borrowings

[0001730168-19-000036:notes:89]
|  |  | Effective Interest Rate |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2021 |  | 3.853 | % |  | $ | 9,000 |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due September 2021 to November 2023 |  | 3.892 | % |  | 9,000 |  |  | — |  |
|  |  |  |  | 18,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount, premium and unamortized debt issuance costs |  |  |  | (218 | ) |  | (116 | ) |
| Total carrying value of debt |  |  |  | $ | 37,641 |  |  | $ | 17,493 |  |

[0001730168-19-000036:notes:90]
2019 Term Loans and Assumed CA Senior Notes

[0001730168-19-000036:notes:91]
In connection with the CA Merger, we entered into a credit agreement, or the 2019 Credit Agreement, which provides for a $9,000 million unsecured term A-3 facility and a $9,000 million unsecured term A-5 facility, collectively referred to as the 2019 Term Loans. Interest on our 2019 Term Loans is based on a floating rate and is payable monthly. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation, or BRCM, Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee being provided by Broadcom-Singapore until its pending voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019) is finalized.

[0001730168-19-000036:notes:92]
The 2019 Credit Agreement also provides for a five-year $5,000 million unsecured revolving credit facility, or the Revolving Facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit reduces the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we may borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on February 3, 2019.

[0001730168-19-000036:notes:93]
Additionally, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes, or the Assumed CA Senior Notes. CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

[0001730168-19-000036:notes:94]
2017 Senior Notes

[0001730168-19-000036:notes:95]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the Subsidiary Issuers, issued $17,550 million of senior unsecured notes, or the 2017 Senior Notes. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom, or Parent Guarantor, and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc., or Subsidiary Guarantor, a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes under each of their respective indentures in accordance with their terms.

[0001730168-19-000036:notes:96]
Fair Value of Debt

[0001730168-19-000036:notes:97]
As of February 3, 2019, the estimated aggregate fair value of debt was $37,021 million and was primarily classified as Level 2. The fair value of our 2019 Term Loans is determined using inputs based on discounted cash flow models with observable market inputs and takes into consideration variables such as interest rate changes, comparable instruments, and credit-rating changes. The fair values of the Assumed CA Senior Notes and 2017 Senior Notes are determined using quoted prices from less active markets.

[0001730168-19-000036:notes:98]
Future Principal Payments of Debt

[0001730168-19-000036:notes:99]
As of February 3, 2019 and November 4, 2018, we accrued interest payable of $104 million and $165 million, respectively and were in compliance with all debt covenants.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001730168-19-000036:notes:100]
The following table presents revenue disaggregated by type of revenue and by region.

[0001730168-19-000036:notes:101]
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services* |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

[0001730168-19-000036:notes:102]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.


## us-gaap:DividendsDeclaredTableTextBlock

[0001730168-19-000036:notes:103]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 2.65 |  |  | $ | 1.75 |  |
| Cash dividends paid to stockholders |  | $ | 1,067 |  |  | $ | 717 |  |
| Cash distributions paid to limited partners |  | $ | — |  |  | $ | 38 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001730168-19-000036:notes:104]
Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-19-000036:notes:105]
Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested restricted stock units, or RSUs, and employee stock purchase plan rights under the Broadcom Limited Second Amended and Restated Employee Share Purchase Plan, as amended, or ESPP (together referred to as equity awards).

[0001730168-19-000036:notes:106]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0001730168-19-000036:notes:107]
[same as prior period, unchanged from 0001730168-18-000039:notes:104]

[0001730168-19-000036:notes:108]
For the fiscal quarter ended February 4, 2018, diluted net income per share excluded the potentially dilutive effect of the exchange of the LP Units for 22 million common stock shares as their effect was antidilutive.

[0001730168-19-000036:notes:109]
[same as prior period, unchanged from 0001730168-18-000039:notes:106]

[0001730168-19-000036:notes:110]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
| Numerator: |  | (In millions, except per share data) |
| Income from continuing operations |  | $ | 481 |  |  | $ | 6,581 |  |
| Less: Income from continuing operations attributable to noncontrolling interest |  | — |  |  | 337 |  |
| Income from continuing operations attributable to common stock |  | 481 |  |  | 6,244 |  |
| Loss from discontinued operations, net of income taxes |  | (10 | ) |  | (15 | ) |
| Less: Loss from discontinued operations, net of income taxes, attributable to noncontrolling interest |  | — |  |  | (1 | ) |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (10 | ) |  | (14 | ) |
| Net income attributable to common stock |  | $ | 471 |  |  | $ | 6,230 |  |

[0001730168-19-000036:notes:111]
| Denominator: |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 401 |  |  | 410 |  |
| Dilutive effect of equity awards |  | 18 |  |  | 16 |  |
| Weighted-average shares outstanding - diluted |  | 419 |  |  | 426 |  |
| Basic income per share: |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.20 |  |  | $ | 15.23 |  |
| Loss per share from discontinued operations |  | (0.03 | ) |  | (0.03 | ) |
| Net income per share |  | $ | 1.17 |  |  | $ | 15.20 |  |
| Diluted income per share: |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.15 |  |  | $ | 14.66 |  |
| Loss per share from discontinued operations |  | (0.03 | ) |  | (0.04 | ) |
| Net income per share |  | $ | 1.12 |  |  | $ | 14.62 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-19-000036:notes:112]
[same as prior period, unchanged from 0001730168-18-000039:notes:109]

[0001730168-19-000036:notes:113]
[same as prior period, unchanged from 0001730168-18-000039:notes:110]

[0001730168-19-000036:notes:114]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 17,705 |  |  | $ | 5,945 |  |  | $ | 3,112 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26,913 |  |
| Reallocation due to change in segments |  | (17,705 | ) |  | (5,945 | ) |  | (3,112 | ) |  | (151 | ) |  | 25,924 |  |  | 980 |  |  | 9 |  |  | — |  |
| CA Merger |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9,734 |  |  | — |  |  | 9,734 |  |
| Balance as of February 3, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25,924 |  |  | $ | 10,714 |  |  | $ | 9 |  |  | $ | 36,647 |  |

[0001730168-19-000036:notes:115]
During the first quarter of fiscal year 2019, we changed our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. As a result, we have reassigned the goodwill balance to reflect our new segment structure using a relative fair value allocation approach. Under this approach, the fair value of each segment was determined using a combination of the income approach and the market approach, and was compared to the fair value of the total business immediately prior to the reorganization to arrive at the reassigned goodwill balance.

[0001730168-19-000036:notes:116]
Based on the amount of intangible assets subject to amortization at February 3, 2019, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-19-000036:notes:117]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 3,918 |  |
| 2020 |  | 5,024 |  |
| 2021 |  | 4,121 |  |
| 2022 |  | 3,153 |  |
| 2023 |  | 2,156 |  |
| Thereafter |  | 2,688 |  |
| Total |  | $ | 21,060 |  |

[0001730168-19-000036:notes:118]
The weighted-average remaining amortization periods by intangible asset category were as follows:

[0001730168-19-000036:notes:119]
| Amortizable intangible assets: |  | February 3, 2019 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 6 |
| Order backlog |  | 3 |
| Trade names |  | 10 |
| Other |  | 10 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-19-000036:notes:120]
[same as prior period, unchanged from 0001730168-18-000039:notes:116]

[0001730168-19-000036:notes:121]
For the fiscal quarter ended February 3, 2019, our benefit from income taxes was $203 million, compared to a benefit from income taxes of $5,786 million for the fiscal quarter ended February 4, 2018.

[0001730168-19-000036:notes:122]
The benefit for the fiscal quarter ended February 3, 2019 was primarily due to the recognition of $141 million of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, partial release of $56 million of our valuation allowance as a result of the CA Merger, and $35 million of excess tax benefits from stock-based awards that were vested or exercised during the period. The current period also includes the impact of several provisions of the U.S. Tax Cuts and Jobs Act, or the 2017 Tax Reform Act, that take effect for us for the first time in the fiscal year ending November 3, 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income, or GILTI, a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000036:notes:123]
The benefit from income taxes for the corresponding 2018 fiscal period was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act, signed into law on December 22, 2017. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations, or the Transition Tax, as of December 31, 2017.

[0001730168-19-000036:notes:124]
As a result of the 2017 Tax Reform Act, we recorded a total provisional benefit of $5,810 million during the fiscal quarter ended February 4, 2018. This provisional benefit included $88 million related to the remeasurement of certain deferred tax assets and liabilities, which was based on the tax rates at which they were expected to be reversed in the future as a result of the 2017 Tax Reform Act. The provisional benefit also included $5,722 million related to the Transition Tax, which was primarily due to a reduction of $10,392 million in our federal deferred income tax liabilities on accumulated non-U.S. earnings, partially offset by $2,547 million of federal provisional long-term Transition Tax payable and $2,179 million of unrecognized federal tax benefits related to the Transition Tax.

[0001730168-19-000036:notes:125]
On December 22, 2017, the SEC issued Staff Accounting Bulletin No. 118. This guidance allowed registrants a “measurement period,” not to exceed one year from the date of enactment, to complete their accounting for the tax effects of the 2017 Tax Reform Act. We relied on this guidance to refine our estimates of the impact of the 2017 Tax Reform Act during the measurement period. The measurement period ended during our period ended February 3, 2019, and no adjustments were recorded during this period. As a result, we consider our accounting for the tax effects of the 2017 Tax Reform Act to be complete based on our interpretation of the law and subsequently issued guidance. However, it is expected that the U.S. Treasury will continue to issue regulations and other guidance on the application of certain provisions of the 2017 Tax Reform Act that may impact our interpretation of the rules and our calculation of the tax impact of the Transition Tax or other provisions of the 2017 Tax Reform Act.

[0001730168-19-000036:notes:126]
Additionally, in connection with CA Merger, we established $2,369 million of net deferred tax liabilities on the excess of book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that had not been indefinitely reinvested, partially offset by acquired tax attributes. The net deferred tax liabilities are based upon certain assumptions underlying our preliminary purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes may be required, provided we are within the measurement period.

[0001730168-19-000036:notes:127]
[same as prior period, unchanged from 0001730168-18-000039:notes:127]

[0001730168-19-000036:notes:128]
The balance of gross unrecognized tax benefits was $4,005 million and $4,030 million as of February 3, 2019 and November 4, 2018, respectively. Gross unrecognized tax benefits decreased by $25 million compared to the balance as of November 4, 2018, primarily due to audit settlements and lapses of statutes of limitations offset by the recognition of uncertain tax positions related to the CA Merger, which were initially estimated as of the CA Acquisition Date. We continue to reevaluate these items with any adjustments to our preliminary estimates recognized, provided we are within the measurement period and we continue to collect information in order to determine their estimated values.

[0001730168-19-000036:notes:129]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of February 3, 2019 and November 4, 2018, the combined amount of cumulative accrued interest and penalties was approximately $284 million and $190 million, respectively.

[0001730168-19-000036:notes:130]
A portion of our unrecognized tax benefits will affect our effective tax rate if they are recognized upon favorable resolution of the uncertain tax positions. As of February 3, 2019 and November 4, 2018, approximately $4,289 million and $4,220 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-19-000036:notes:131]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $124 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001730168-19-000036:notes:132]
Recently Adopted Accounting Guidance

[0001730168-19-000036:notes:133]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board, or FASB, guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.

[0001730168-19-000036:notes:134]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at costs less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter ended February 3, 2019, we also recognized $27 million of unrealized gains on equity securities within other income, net in our condensed consolidated statement of operations.

[0001730168-19-000036:notes:135]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, or Topic 606. We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition, or Topic 605, while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. "Revenue from Contracts with Customers" for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

[0001730168-19-000036:notes:136]
Recent Accounting Guidance Not Yet Adopted

[0001730168-19-000036:notes:137]
In February 2016, the FASB issued guidance related to the accounting for leases, which among other things, requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. The new guidance is required to be applied using a modified retrospective approach. We are evaluating the impact this guidance will have on our condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-19-000036:notes:138]
[same as prior period, unchanged from 0001730168-18-000039:notes:140]

[0001730168-19-000036:notes:139]
[same as prior period, unchanged from 0001730168-18-000039:notes:141]

[0001730168-19-000036:notes:140]
Broadcom Inc., or Broadcom, a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company, or Broadcom-Singapore. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom Inc. common stock, or the Redomiciliation Transaction. As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom Inc. In addition, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, were mandatorily exchanged, or the Mandatory Exchange, for newly issued shares of Broadcom Inc. common stock and all limited partners of the Partnership became common stockholders of Broadcom Inc. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

[0001730168-19-000036:notes:141]
The Redomiciliation Transaction was accounted for as an exchange of equity interests among entities under common control and the historical basis of accounting was retained as if the entities had always been combined for financial reporting purposes.

[0001730168-19-000036:notes:142]
[same as prior period, unchanged from 0001730168-18-000039:notes:145]

[0001730168-19-000036:notes:143]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mobile, cloud, distributed and mainframe platforms.

[0001730168-19-000036:notes:144]
On November 5, 2018, we acquired CA, Inc., or CA, for $16.1 billion, net of cash acquired, or the CA Merger. CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018, or the CA Acquisition Date. See Note 3. “Acquisitions” for additional information.

[0001730168-19-000036:notes:145]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property, or IP, licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

[0001730168-19-000036:notes:146]
[same as prior period, unchanged from 0001730168-18-000039:notes:147]

[0001730168-19-000036:notes:147]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019, or fiscal year 2019, is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ends on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018, or fiscal year 2018, was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.

[0001730168-19-000036:notes:148]
[same as prior period, unchanged from 0001730168-18-000039:notes:149]

[0001730168-19-000036:notes:149]
[same as prior period, unchanged from 0001730168-18-000039:notes:150]

[0001730168-19-000036:notes:150]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of operations and statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001730168-19-000036:notes:151]
Restructuring, Impairment and Disposal Charges

[0001730168-19-000036:notes:152]
Restructuring Charges

[0001730168-19-000036:notes:153]
The following is a summary of significant restructuring expense recognized in continuing operations, primarily in operating expenses:

[0001730168-19-000036:notes:154]
| • | In connection with the CA Merger, we initiated cost reduction activities. As a result, we recognized $594 million of restructuring expense primarily related to employee termination and lease and other exit costs during the fiscal quarter ended February 3, 2019. |

[0001730168-19-000036:notes:155]
| • | During the first quarter of fiscal year 2018, we initiated cost reduction activities associated with the acquisition of Brocade. As a result, we recognized $2 million and $108 million of restructuring expense during the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively. These restructuring expenses primarily related to lease and other exit costs for the fiscal quarter ended February 3, 2019 and employee termination costs for the fiscal quarter ended February 4, 2018. |

[0001730168-19-000036:notes:156]
| • | During the second quarter of fiscal year 2016, we initiated cost reduction activities associated with the acquisition of BRCM. As a result, we recognized $3 million and $31 million of restructuring expense during the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively. These restructuring expenses primarily related to employee termination costs for the fiscal quarter ended February 3, 2019 and lease and other exit costs for the fiscal quarter ended February 4, 2018. As of February 3, 2019, we have completed the restructuring activities related to the acquisition of BRCM. |

[0001730168-19-000036:notes:157]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 16 |  |  | $ | 6 |  |  | $ | 22 |  |
| Liabilities assumed from CA |  | 29 |  |  | 38 |  |  | 67 |  |
| Restructuring charges |  | 502 |  |  | 97 |  |  | 599 |  |
| Utilization |  | (314 | ) |  | (17 | ) |  | (331 | ) |
| Balance as of February 3, 2019 (a) |  | $ | 233 |  |  | $ | 124 |  |  | $ | 357 |  |

[0001730168-19-000036:notes:158]
_________________________________

[0001730168-19-000036:notes:159]
(a) The majority of the employee termination costs balance is expected to be paid in fiscal year 2019. The leases and other exit costs balance is related to leases and is expected to be paid over the remaining lease terms through fiscal year 2028.

[0001730168-19-000036:notes:160]
Impairment and Disposal Charges

[0001730168-19-000036:notes:161]
During the fiscal quarters ended February 3, 2019 and February 4, 2018, impairment and disposal charges of $30 million and $6 million, respectively, were primarily related to impairment of property, plant and equipment.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001730168-19-000036:notes:162]
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-19-000036:notes:163]
Nature of products and services

[0001730168-19-000036:notes:164]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-19-000036:notes:165]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

[0001730168-19-000036:notes:166]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering, or NRE, arrangements.

[0001730168-19-000036:notes:167]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-19-000036:notes:168]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

[0001730168-19-000036:notes:169]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-19-000036:notes:170]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-19-000036:notes:171]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-19-000036:notes:172]
There are two main categories of NRE contracts which we enter into with our customers; (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (cost-to-cost) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-19-000036:notes:173]
Material rights. Contracts with customers may also include material rights which are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-19-000036:notes:174]
Arrangements with multiple performance obligations

[0001730168-19-000036:notes:175]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-19-000036:notes:176]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-19-000036:notes:177]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-19-000036:notes:178]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-19-000036:notes:179]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-19-000036:notes:180]
Warranty. We provide only assurance-type warranties on our products to our customers. As a result, we accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-19-000036:notes:181]
Other policies and judgments

[0001730168-19-000036:notes:182]
Significant financing component. Payment terms and conditions vary by contract, although terms generally include a requirement of payment within a specified period. In certain arrangements, we receive payment from a customer either before or after the performance obligation has been satisfied. The timing difference between the payment and satisfaction of performance obligations for the vast majority of our contracts is one year or less; therefore, for those contracts, we apply a practical expedient and do not consider the effects of the time value of money.

[0001730168-19-000036:notes:183]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-19-000036:notes:184]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-19-000036:notes:185]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-19-000036:notes:186]
Revenue from Contracts with Customers

[0001730168-19-000036:notes:187]
Disaggregation

[0001730168-19-000036:notes:188]
We have considered 1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker, or the CODM, as defined by the authoritative guidance on segment reporting, in evaluating financial performance and 2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. "Segment Information".

[0001730168-19-000036:notes:189]
Contract Balances

[0001730168-19-000036:notes:190]
The difference in the opening and closing balances of our contract assets and contract liabilities primarily results from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognized contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.

[0001730168-19-000036:notes:191]
Remaining Performance Obligations

[0001730168-19-000036:notes:192]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed where they are able to terminate for convenience without payment of a substantive penalty and this has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts which have an original duration of one year or less nor have we included contract with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

[0001730168-19-000036:notes:193]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 3, 2019 was not significant. Since our customers generally may not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

[0001730168-19-000036:notes:194]
Contract Costs

[0001730168-19-000036:notes:195]
We have applied the practical expedient to expense commission costs as incurred for costs to obtain a contract when the amortization period would have been one year or less. As a result, no commission costs are capitalized.

[0001730168-19-000036:notes:196]
We have a policy to recognize an asset from the costs incurred to fulfill a contract that are not within the scope of another accounting literature. We have not incurred any costs to fulfill a contract that fall within the guidance and, as a result, no costs to fulfill a contract have been capitalized.

[0001730168-19-000036:notes:197]
Changes in Accounting Policies

[0001730168-19-000036:notes:198]
Except for the changes below, we have consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements. We adopted Topic 606 with an initial application date of November 5, 2018. As a result, we have changed our accounting policy for revenue recognition as detailed above.

[0001730168-19-000036:notes:199]
We applied Topic 606 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, we reflected the aggregate effect of all modifications when identifying the performance obligations and allocating the transaction price at transition, which did not have a material effect on the adjustment to retained earnings as of November 5, 2018.

[0001730168-19-000036:notes:200]
Financial Statement Impact of Adopting Topic 606

[0001730168-19-000036:notes:201]
We adopted Topic 606 using the modified retrospective method. The cumulative effect of applying the new guidance to all contracts with customers that were not completed by November 4, 2018 was recorded as an adjustment to retained earnings as of adoption on November 5, 2018. We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:

[0001730168-19-000036:notes:202]
| Balance Sheet |  | November 4, 2018 |  | Adjustments Due to Topic 606 |  | November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

[0001730168-19-000036:notes:203]
Impact of New Revenue Guidance on Net Revenue

[0001730168-19-000036:notes:204]
The following table compares net revenue for the fiscal quarter ended February 3, 2019 to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statement of operations for the fiscal quarter ended February 3, 2019 or in the condensed consolidated balance sheet as of February 3, 2019 were significantly affected by the new revenue guidance.

[0001730168-19-000036:notes:205]
|  |  | Fiscal Quarter Ended February 3, 2019 |
| Statement of Operations |  | Proforma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |
| Subscriptions and services |  | 1,006 |  |  | 144 |  |  | 1,150 |  |
| Total net revenue |  | $ | 5,645 |  |  | $ | 144 |  |  | $ | 5,789 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001730168-19-000036:notes:206]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 26 |  |  | $ | 18 |  |
| Cost of subscriptions and services |  | 8 |  |  | 2 |  |
| Research and development |  | 311 |  |  | 203 |  |
| Selling, general and administrative |  | 120 |  |  | 76 |  |
| Total stock-based compensation expense |  | $ | 465 |  |  | $ | 299 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001730168-19-000036:notes:207]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |
| Semiconductor solutions |  | $ | 4,374 |  |  | $ | 4,955 |  |
| Infrastructure software |  | 1,403 |  |  | 328 |  |
| IP licensing |  | 12 |  |  | 44 |  |
| Total net revenue |  | $ | 5,789 |  |  | $ | 5,327 |  |
| Operating income (loss): |  |  |  |  |
| Semiconductor solutions |  | $ | 2,037 |  |  | $ | 2,325 |  |
| Infrastructure software |  | 1,020 |  |  | 216 |  |
| IP licensing |  | (5 | ) |  | 26 |  |
| Unallocated expenses |  | (2,497 | ) |  | (1,624 | ) |
| Total operating income |  | $ | 555 |  |  | $ | 943 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001730168-19-000036:notes:208]
[same as prior period, unchanged from 0001730168-18-000039:notes:176]

[0001730168-19-000036:notes:209]
|  |  | Number of OptionsOutstanding |  |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 4, 2018 |  | 8 |  |  |  | $ | 50.14 |  |  |  |  |  |
| Exercised |  | (2 | ) |  |  | $ | 49.94 |  |  |  |  | $ | 253 |  |
| Cancelled |  | — |  | * |  | $ | 98.85 |  |  |  |  |  |
| Balance as of February 3, 2019 |  | 6 |  |  |  | $ | 50.17 |  |  | 1.75 |  | $ | 1,403 |  |
| Fully vested as of February 3, 2019 |  | 6 |  |  |  | $ | 50.17 |  |  | 1.75 |  | $ | 1,403 |  |
| Fully vested and expected to vest as of February 3, 2019 |  | 6 |  |  |  | $ | 50.17 |  |  | 1.75 |  | $ | 1,403 |  |

[0001730168-19-000036:notes:210]
[same as prior period, unchanged from 0001730168-18-000039:notes:178]


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0001730168-19-000036:notes:211]
[same as prior period, unchanged from 0001730168-18-000039:notes:179]

[0001730168-19-000036:notes:212]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |
| Assumed in CA Merger |  | 1 |  |  | $ | 206.14 |  |
| Granted |  | 32 |  |  | $ | 177.07 |  |
| Vested |  | (1 | ) |  | $ | 207.90 |  |
| Forfeited |  | — |  | * | $ | 163.76 |  |
| Balance as of February 3, 2019 |  | 50 |  |  | $ | 184.07 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-19-000036:notes:213]
[same as prior period, unchanged from 0001730168-18-000039:notes:181]

[0001730168-19-000036:notes:214]
[same as prior period, unchanged from 0001730168-18-000039:notes:182]

[0001730168-19-000036:notes:215]
As a result of the CA Merger which closed on November 5, 2018, we updated our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. Each segment represents components for which separate financial information is available that is utilized on a regular basis by the Chief Executive Officer, who has been identified as the CODM, in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-19-000036:notes:216]
Semiconductor solutions. We provide semiconductor solutions for enabling the set-top box and broadband access markets, for managing the movement of data in data center, telecom, enterprise and embedded networking applications, for enabling secure movement of digital data to and from host machines such as servers, personal computers and storage systems to the underlying storage devices such as hard disk drives and solid state drives. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions and custom touch controllers for mobile applications. We also provide a broad variety of products for the general industrial and automotive markets.

[0001730168-19-000036:notes:217]
Infrastructure software. We provide a portfolio of mainframe, enterprise and storage area networking solutions, which enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments.

[0001730168-19-000036:notes:218]
Intellectual property licensing. We license a portion of our broad intellectual property portfolio.

[0001730168-19-000036:notes:219]
Our CODM assesses the performance of each segment and allocates resources to those segments based on net revenue and operating results and does not evaluate our segments using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, in addition to expenses associated with selling, general and administrative activities for the business, which are allocated primarily based on revenue, while facilities expenses are allocated primarily based on site-specific headcount.

[0001730168-19-000036:notes:220]
[same as prior period, unchanged from 0001730168-18-000039:notes:186]

[0001730168-19-000036:notes:221]
[same as prior period, unchanged from 0001730168-18-000039:notes:187]

[0001730168-19-000036:notes:222]
[same as prior period, unchanged from 0001730168-18-000039:notes:188]

[0001730168-19-000036:notes:223]
[same as prior period, unchanged from 0001730168-18-000039:notes:189]

[0001730168-19-000036:notes:224]
We sell our products through our direct sales force and a select network of distributors globally. Two customers, both of which are distributors, accounted for 15% and 11% of our net accounts receivable balance at February 3, 2019 compared with two customers, also distributors, which accounted for 20% and 14% of our net accounts receivable balance at November 4, 2018.

[0001730168-19-000036:notes:225]
One customer, a distributor, accounted for 15% of our net revenue for the fiscal quarter ended February 3, 2019. During the fiscal quarter ended February 4, 2018, one customer, a contract manufacturer, represented 18% of our net revenue. The majority of the revenue from these customers was included in our semiconductor solutions segment.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001730168-19-000036:notes:226]
[same as prior period, unchanged from 0001730168-18-000039:notes:192]

[0001730168-19-000036:notes:227]
Redomiciliation Transaction

[0001730168-19-000036:notes:228]
For the period prior to the Redomiciliation Transaction, our stockholders’ equity reflected Broadcom-Singapore’s outstanding ordinary shares. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom Inc. common stock and Broadcom-Singapore became a wholly-owned subsidiary of Broadcom Inc.

[0001730168-19-000036:notes:229]
In conjunction with the Redomiciliation Transaction and pursuant to the Mandatory Exchange, all outstanding LP Units held by the limited partners were mandatorily exchanged for approximately 22 million newly issued shares of Broadcom Inc. common stock on a one-for-one basis. As a result, all limited partners of the Partnership became common stockholders of Broadcom Inc. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange.

[0001730168-19-000036:notes:230]
[same as prior period, unchanged from 0001730168-18-000039:notes:196]

[0001730168-19-000036:notes:231]
Immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income attributable to our common stock in our condensed consolidated statement of operations excluded the noncontrolling interest’s proportionate share of the results for the fiscal quarter ended February 4, 2018. In addition, we presented the proportionate share of equity attributable to the noncontrolling interest as a separate component of total equity within our condensed consolidated statement of equity for the fiscal quarter ended February 4, 2018.

[0001730168-19-000036:notes:232]
[same as prior period, unchanged from 0001730168-18-000039:notes:198]

[0001730168-19-000036:notes:233]
[same as prior period, unchanged from 0001730168-18-000039:notes:199]

[0001730168-19-000036:notes:234]
In December 2018, our Board of Directors increased our previously authorized $12 billion stock repurchase program to a total of $18 billion. We may repurchase our common stock from time to time on or prior to November 3, 2019, the end of our fiscal year 2019. During the fiscal quarter ended February 3, 2019, we repurchased and retired approximately 14 million shares of our common stock for $3,436 million at a weighted average price of $246.64 under this stock repurchase program. As of February 3, 2019, $7,306 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000036:notes:235]
[same as prior period, unchanged from 0001730168-18-000039:notes:201]

[0001730168-19-000036:notes:236]
[same as prior period, unchanged from 0001730168-18-000039:notes:202]

[0001730168-19-000036:notes:237]
During the fiscal quarter ended February 3, 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs, or the Multi-Year Equity Awards, in lieu of our annual employee equity awards historically granted in the second quarter of our fiscal year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $107 million for the fiscal quarter ended February 3, 2019, including $17 million for Multi-Year Equity Awards granted to employees acquired in the CA Merger.

[0001730168-19-000036:notes:238]
For the fiscal quarter ended February 3, 2019, stock-based compensation expense included $37 million related to equity awards assumed in connection with the CA Merger. In addition to stock-based compensation expense presented above, we recognized $75 million in restructuring charges for accelerated vesting of assumed equity awards held by employees terminated in connection with the CA Merger.

[0001730168-19-000036:notes:239]
As of February 3, 2019, the total unrecognized compensation cost related to unvested stock-based awards was $6,704 million, which is expected to be recognized over the remaining weighted-average service period of 4.6 years.

[0001730168-19-000036:notes:240]
[same as prior period, unchanged from 0001730168-18-000039:notes:203]

[0001730168-19-000036:notes:241]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended February 3, 2019 was $235 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax withholding obligations due upon the vesting of RSUs.


## us-gaap:SubsequentEventsTextBlock

[0001730168-19-000036:notes:242]
Subsequent Event

[0001730168-19-000036:notes:243]
Cash Dividends Declared

[0001730168-19-000036:notes:244]
On March 13, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on March 29, 2019 to stockholders of record at the close of business on March 21, 2019.
