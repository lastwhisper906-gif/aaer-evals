# AVGO note change history — 0001730168-18-000039 → 0001730168-19-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-03-15):
[0001730168-19-000036:note_history:1]
The following table summarizes contractual obligations and commitments as of February 3, 2019 that materially changed from the end of fiscal year 2018:
  (was, 2018-09-13, similarity 0.958):
[0001730168-18-000039:note_history:1]
The following table summarizes contractual obligations and commitments as of August 5, 2018 that materially changed from the end of fiscal year 2017:

- added (2019-03-15):
[0001730168-19-000036:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 (remainder) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 43,716 |  |  | $ | 861 |  |  | $ | 5,231 |  |  | $ | 2,810 |  |  | $ | 14,745 |  |  | $ | 2,854 |  |  | $ | 17,215 |  |
| Purchase commitments |  | 809 |  |  | 718 |  |  | 72 |  |  | 19 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 245 |  |  | 134 |  |  | 87 |  |  | 15 |  |  | 6 |  |  | 3 |  |  | — |  |
| Operating lease obligations |  | 919 |  |  | 101 |  |  | 119 |  |  | 100 |  |  | 71 |  |  | 63 |  |  | 465 |  |
| Total |  | $ | 45,689 |  |  | $ | 1,814 |  |  | $ | 5,509 |  |  | $ | 2,944 |  |  | $ | 14,822 |  |  | $ | 2,920 |  |  | $ | 17,680 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:3]
Debt Principal, Interest and Fees. Represents principal and estimated interest on borrowings under the 2019 Term Loans, Revolver Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our 2019 Term Loans, which are subject to a floating interest rate, the estimated interest was based on the interest rate in place during the last month of the fiscal quarter ended February 3, 2019.

- added (2019-03-15):
[0001730168-19-000036:note_history:4]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

- added (2019-03-15):
[0001730168-19-000036:note_history:5]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $67 million and $71 million for the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively.

- changed (2019-03-15):
[0001730168-19-000036:note_history:6]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 3, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,250 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 3, 2019 have been excluded from the contractual obligations table above.
  (was, 2018-09-13, similarity 0.9716):
[0001730168-18-000039:note_history:6]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 5, 2018, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,769 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 5, 2018 have been excluded from the contractual obligations table above.

- added (2019-03-15):
[0001730168-19-000036:note_history:7]
Standby Letters of Credit

- added (2019-03-15):
[0001730168-19-000036:note_history:8]
As of February 3, 2019 and November 4, 2018, we had outstanding obligations relating to standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees. The fair values of the letters of credit approximate the contract amounts.

- changed (2019-03-15):
[0001730168-19-000036:note_history:9]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.
  (was, 2018-09-13, similarity 0.793):
[0001730168-18-000039:note_history:9]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other intellectual property rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. Intellectual property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing intellectual property. Claims that our products or processes infringe or misappropriate any third-party intellectual property rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time we pursue litigation to assert our intellectual property rights. Regardless of the merit or resolution of any such litigation, complex intellectual property litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- changed (2019-03-15):
[0001730168-19-000036:note_history:10]
Lawsuits Relating to the Acquisition of Emulex Corporation
  (was, 2018-09-13, similarity 0.8846):
[0001730168-18-000039:note_history:10]
Lawsuits Relating to the Acquisition of Emulex

- changed (2019-03-15):
[0001730168-19-000036:note_history:11]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation, or Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court. On January 4, 2019, the United States Supreme Court granted certiorari. On February 19, 2019, the Defendants-Appellees (as Petitioners in the United States Supreme Court) filed their opening brief. The Plaintiff-Appellant’s brief is to be filed by March 21, 2019 and oral arguments are scheduled for April 15, 2019. We believe these claims are all without merit and intend to vigorously defend these actions.
  (was, 2018-09-13, similarity 0.719):
[0001730168-18-000039:note_history:11]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleges, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral argument on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. We believe these claims are all entirely without merit and intend to vigorously defend these actions.

- changed (2019-03-15):
[0001730168-19-000036:note_history:12]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our results of operations, financial position or cash flows.
  (was, 2018-09-13, similarity 0.9879):
[0001730168-18-000039:note_history:12]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any legal proceedings, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our results of operations, financial position or cash flows.

- changed (2019-03-15):
[0001730168-19-000036:note_history:13]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.
  (was, 2018-09-13, similarity 0.9853):
[0001730168-18-000039:note_history:13]
As is customary in our industry and as provided for in local law in the United States and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for intellectual property claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.

- removed (2019-03-15):
[0001730168-18-000039:note_history:14]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2018(remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
|  |  | (In millions) |
| Debt principal and interest |  | $ | 21,059 |  |  | $ | 118 |  |  | $ | 566 |  |  | $ | 3,321 |  |  | $ | 1,242 |  |  | $ | 3,940 |  |  | $ | 11,872 |  |
| Purchase commitments |  | $ | 946 |  |  | $ | 823 |  |  | $ | 70 |  |  | $ | 52 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:15]
Debt Principal and Interest. Represents principal and interest on borrowings under the 2017 Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes.

- removed (2019-03-15):
[0001730168-18-000039:note_history:16]
Lawsuits Relating to the Acquisition of CA, Inc.

- removed (2019-03-15):
[0001730168-18-000039:note_history:17]
On August 3, 2018, a purported stockholder of CA commenced a putative class action lawsuit captioned Harvey v. CA, Inc., et al. against CA, the CA board of directors, Broadcom and Broadcom’s wholly owned subsidiary party to the merger agreement with CA in the United States District Court for the Southern District of New York. On August 9, 2018, another putative class action lawsuit captioned Vladimir Gusinsky Rev. Trust v. CA, Inc., et al. was filed against CA and the CA board of directors in the United States District Court for the District of Delaware, or Delaware District Court. On August 15, 2018, a third putative class action lawsuit captioned Jacob Scheiner Retirement Account v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court.  On August 22, 2018, a fourth putative class action lawsuit captioned Kenneth Gilley v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court. The Harvey and Vladimir Gusinsky Rev. Trust complaints allege violations of Sections 14(a) and 20(a) of the Exchange Act arising out of CA’s preliminary proxy statement relating to the CA Merger, filed with the SEC on July 24, 2018.  The Scheiner Retirement Account and Gilley complaints allege violations of Sections 14(a) and 20(a) of the Exchange Act and Rule 14a-9 promulgated thereunder arising out of CA’s definitive proxy statement relating to the CA Merger, filed with the SEC on August 10, 2018. The complaints assert that the preliminary proxy statement or definitive proxy statement, as applicable, contain incomplete and misleading information regarding CA’s financial projections and the financial analysis performed by Qatalyst Partners, CA’s financial advisor, as well as, for the Harvey, Scheiner Retirement Account and Gilley complaints, the sales process undertaken by CA in connection with its proposed merger with Broadcom. Plaintiffs seek to enjoin the defendants from consummating the CA Merger, or, if the CA Merger is consummated, rescission and/or damages. The plaintiffs also seek costs and fees. On September 4, 2018, the parties to each of the four lawsuits reached an agreement in principle providing for a dismissal of each of the lawsuits following the CA shareholder vote with respect to the CA Merger. In connection with this agreement, CA filed a supplement to the definitive proxy statement relating to the CA Merger.

- removed (2019-03-15):
[0001730168-18-000039:note_history:18]
Lawsuits Relating to the Acquisition of Brocade Communications Systems, Inc.

- removed (2019-03-15):
[0001730168-18-000039:note_history:19]
On December 13, 2016, December 15, 2016, December 21, 2016, January 5, 2017 and January 18, 2017, six putative class action complaints were filed in the United States District Court for the Northern District of California, or the U.S. Northern District Court, captioned Steinberg v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7081-EMC, Gross v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7173-EJD, Jha v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7270-HRL, Bragan v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7271-JSD, Chuakay v. Brocade Communications Systems, Inc., et al., No. 3:17-cv-0058-PJH, and Mathew v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7271-HSG, respectively. The Steinberg, Bragan and Mathew complaints named as defendants Brocade, the members of Brocade’s board of directors, Broadcom, BRCM and Bobcat Merger Sub, Inc. The Gross, Jha and Chuakay complaints named as defendants Brocade and the members of Brocade’s board of directors. All of the complaints asserted claims under Sections 14(a) and 20(a) of the Exchange Act and Rule 14a-9 promulgated thereunder. The complaints alleged, among other things, that the board of directors of Brocade failed to provide material information and/or omitted material information from the Preliminary Proxy Statement filed with the SEC on December 6, 2016 by Brocade. The complaints sought to enjoin the closing of the transaction between Brocade and Broadcom, as well as certain other equitable and declaratory relief and attorneys’ fees and costs. On January 10, 2017, January 27, 2017 and February 15, 2017, the U.S. Northern District Court granted motions to relate the cases, all of which were then related to the Steinberg action and before the Honorable Judge Edward Chen. On January 11, 2017, Plaintiff Jha filed a motion for a preliminary injunction, which was subsequently withdrawn on January 18, 2017. On February 6, 2017, Plaintiff Gross voluntarily dismissed the Gross action without prejudice, which was ordered by the U.S. Northern District Court on February 15, 2017. On April 14, 2017, the U.S. Northern District Court granted the Motion for Consolidation, Appointment as Lead Plaintiff and Approval of Lead Plaintiff’s Selection of Counsel filed by Plaintiff Giulio D. Cessario, a plaintiff in the Steinberg action, which consolidated these actions under the caption In re Brocade Communications Systems, Inc. Securities Litigation, Case No. 3:16-cv-07081-EMC. On December 29, 2017, Lead Plaintiff voluntarily dismissed the consolidated action without prejudice and withdrew as Lead Plaintiff. On February 16, 2018, Plaintiffs Gross, Chuakay and Jha filed a joint motion for an award of attorneys’ fees. On March 2, 2018, the defendants filed a joint opposition to the motion for attorneys’ fees. On May 3, 2018, Plaintiffs Gross, Chuakay and Jha withdrew their motion for an award of attorneys’ fees. As of May 6, 2018, all actions have been dismissed and motions withdrawn, thereby concluding all actions with respect to these lawsuits.

- removed (2019-03-15):
[0001730168-18-000039:note_history:20]
Lawsuits Relating to Tessera, Inc.

- removed (2019-03-15):
[0001730168-18-000039:note_history:21]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., or Tessera, and Invensas Corp., an affiliate of Tessera, or Invensas or collectively, the Complainants, filed a complaint to institute an investigation with the U.S. International Trade Commission, or the ITC. The Complainants alleged infringement by Broadcom and our subsidiaries, BRCM, Avago Technologies Limited, or Avago, and Avago Technologies U.S. Inc., or Avago U.S., or collectively, the Respondents, of three patents relating to semiconductor packaging and semiconductor manufacturing technology. The downstream respondents, which are customers of the Respondents, were Arista Networks, Inc., ARRIS International plc, ARRIS Group, Inc., ARRIS Technology, Inc., ARRIS Enterprises LLC, ARRIS Solutions, Inc., Pace Ltd., Pace Americas, LLC, Pace USA, LLC, ASUSteK Computer Inc., ASUS Computer International, Comcast Cable Communications, LLC, Comcast Cable Communications Management, LLC, Comcast Business Communications, LLC, HTC Corporation, HTC America, Inc., NETGEAR, Inc., Technicolor S.A., Technicolor USA, Inc., and Technicolor Connected Home USA LLC, or collectively, the Downstream Respondents. On July 20, 2016, the ITC instituted the investigation, or the ITC Investigation. Complainants sought the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of the Respondents' semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation and (2) a permanent cease and desist order prohibiting the Respondents and Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the Respondents' semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation.

- removed (2019-03-15):
[0001730168-18-000039:note_history:22]
On May 23, 2016, Tessera and Invensas filed a complaint against BRCM in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-00379, alleging infringement of the three patents subject to the ITC Investigation. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

- removed (2019-03-15):
[0001730168-18-000039:note_history:23]
On May 23, 2016, Tessera and Tessera Advanced Technologies, Inc. filed a complaint against BRCM in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-00380, alleging infringement of four patents relating to semiconductor packaging and circuit technologies. On June 19, 2016, the complaint was amended to add three more patents relating to semiconductor packaging technologies for a total of seven patents in this matter. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

- removed (2019-03-15):
[0001730168-18-000039:note_history:24]
On May 23, 2016, Invensas filed a Writ of Summons against Broadcom, BRCM, Broadcom Netherlands B.V. and Broadcom Communications Netherlands B.V. in the Hague District Court in the Netherlands, Case No. L1422381, alleging infringement of a single European patent that is a foreign counterpart to one of the patents subject to the ITC Investigation, or the European Patent. The named defendants also included distributors EBV Elektronik GmbH, Arrow Central Europe GmbH, and Mouser Electronics Netherlands B.V. The requested relief included a cease-and-desist order and damages in an unspecified amount.

- removed (2019-03-15):
[0001730168-18-000039:note_history:25]
On May 23, 2016, Invensas also filed a complaint against each of (i) Broadcom Germany GmbH and Broadcom‘s German distributors, Case No. 7 O 97/16, and (ii) Broadcom and BRCM, Case No. 7 O 98/16, in the Mannheim District Court in Germany, alleging infringement of the European Patent. The requested relief included damages in an unspecified amount and an injunction preventing the sale of the accused products.

- removed (2019-03-15):
[0001730168-18-000039:note_history:26]
On November 7, 2016, Invensas filed a complaint against Avago, Avago U.S., Emulex Corporation, or Emulex, LSI Corporation and PLX Technology, Inc., a subsidiary of Broadcom, or PLX, in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-01033, alleging infringement of two of the patents subject to the ITC Investigation. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

- removed (2019-03-15):
[0001730168-18-000039:note_history:27]
On November 7, 2016, Tessera and Invensas filed a complaint against Avago, Avago U.S., and Avago Technologies Wireless (U.S.A.) Manufacturing Inc. in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-01034, alleging infringement of two patents relating to semiconductor packaging technology. On January 31, 2017, Tessera and Invensas amended the complaint in this matter and added three additional patents related to semiconductor packaging technology, which were also at issue in case No. 1-16-cv-00379 pending in Delaware. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

- removed (2019-03-15):
[0001730168-18-000039:note_history:28]
On December 18, 2017, Broadcom and its subsidiaries entered into comprehensive settlement agreements and a patent license agreement with Tessera and its affiliates resolving all outstanding litigation. Pursuant to the agreements between the parties, the ITC investigation was terminated and all of the other litigations were dismissed, thereby concluding all actions with respect to these matters.

- removed (2019-03-15):
[0001730168-18-000039:note_history:29]
On March 3, 2015, two putative shareholder class action complaints were filed in the Court of Chancery of the State of Delaware, or the Delaware Court of Chancery, against Emulex, its directors, Avago Technologies Wireless (U.S.A.) Manufacturing Inc., or AT Wireless, and Emerald Merger Sub, Inc., or Emerald Merger Sub, captioned as follows: James Tullman v. Emulex Corporation, et al., Case No. 10743-VCL (Del. Ch.); Moshe Silver ACF/Yehudit Silver U/NY/UTMA v. Emulex Corporation, et al., Case No. 10744-VCL (Del. Ch.). On March 11, 2015, a third complaint was filed in the Delaware Court of Chancery, captioned Hoai Vu v. Emulex Corporation, et al., Case No. 10776-VCL (Del. Ch.). The complaints alleged, among other things, that Emulex’s directors breached their fiduciary duties by approving the Agreement and Plan of Merger, dated February 25, 2015, by and among AT Wireless, Emerald Merger Sub and Emulex and that AT Wireless and Emerald Merger Sub aided and abetted these alleged breaches of fiduciary duty. The complaints sought, among other things, either to enjoin the transaction or to rescind it following its completion, as well as damages, including attorneys’ and experts’ fees. The Delaware Court of Chancery has entered an order consolidating the three Delaware actions under the caption In re Emulex Corporation Stockholder Litigation, Consolidated C.A. No. 10743-VCL. On May 5, 2015, we completed our acquisition of Emulex. On June 5, 2015, the Court of Chancery dismissed the consolidated action without prejudice.

- removed (2019-03-15):
[0001730168-18-000039:note_history:30]
Lawsuits Relating to the Acquisition of PLX

- removed (2019-03-15):
[0001730168-18-000039:note_history:31]
In June and July 2014, four lawsuits were filed in the Superior Court for the State of California, County of Santa Clara, or the Superior Court, challenging our acquisition of PLX. On July 22, 2014, the Superior Court consolidated these California actions under the caption In re PLX Technology, Inc. S’holder Litig., Lead Case No. 1-14-CV-267079 (Cal. Super. Ct., Santa Clara) and appointed lead counsel. That same day, the Superior Court also stayed the consolidated action, pending resolution of related actions filed in the Delaware Court of Chancery, described below.

- removed (2019-03-15):
[0001730168-18-000039:note_history:32]
Also in June and July 2014, five similar lawsuits were filed in the Delaware Court of Chancery. On July 21, 2014, the Delaware Court of Chancery consolidated these Delaware actions under the caption In re PLX Technology, Inc. Stockholders Litigation, Consol. C.A. No. 9880-VCL (Del. Ch.), appointed lead plaintiffs and lead counsel, and designated an operative complaint for the consolidated action. On July 31, 2014, counsel for lead plaintiffs in Delaware informed the Delaware Court of Chancery that they would not seek a preliminary injunction, but intend to seek damages and pursue monetary remedies through post-closing litigation. Our acquisition of PLX closed on August 12, 2014.

- removed (2019-03-15):
[0001730168-18-000039:note_history:33]
On October 31, 2014, lead plaintiffs filed a consolidated amended complaint. This complaint alleges, among other things, that PLX’s directors breached their fiduciary duties to PLX’s stockholders by seeking to sell PLX for an inadequate price, pursuant to an unfair process, and by agreeing to preclusive deal protections in the merger agreement. Plaintiffs also allege that Potomac Capital Partners II, L.P., Deutsche Bank Securities, AT Wireless and Pluto Merger Sub, Inc., the acquisition subsidiary, aided and abetted the alleged fiduciary breaches. Plaintiffs also allege that PLX’s Solicitation/Recommendation statement on Schedule 14D-9, as filed with the SEC, contained false and misleading statements and/or omitted material information necessary to inform the shareholder vote. The plaintiffs seek, among other things, monetary damages and attorneys’ fees and costs. On September 3, 2015, the Delaware Court of Chancery granted motions to dismiss filed by AT Wireless, the acquisition subsidiary and two PLX directors, and denied motions to dismiss filed by several other PLX directors, Potomac Capital Partners II, L.P. and Deutsche Bank Securities.

- removed (2019-03-15):
[0001730168-18-000039:note_history:34]
On August 17, 2016, the five remaining PLX director-defendants and Deutsche Bank Securities entered into a stipulation of partial settlement to resolve claims against all of the former PLX directors and Deutsche Bank Securities asserted in the Delaware class action. The partial settlement also provides for a release of all potential claims against AT Wireless, Pluto Merger Sub, Inc., Avago and PLX. Defendant Potomac Capital Partners II, L.P. is not a party to the settlement. This partial settlement was approved by the Delaware Court of Chancery on December 20, 2016.

- removed (2019-03-15):
[0001730168-18-000039:note_history:35]
On November 9, 2016, the sole remaining defendant, Potomac Capital Partners II, L.P., filed cross-claims against the named individual director defendants and Deutsche Bank Securities for contribution. Under various contracts and statutes, PLX may owe indemnification to each of these parties. The cross-claims are now barred according to the terms of the approved partial settlement, although Potomac Capital Partners II, L.P. might be entitled to an offset (based on contributory fault) of any damages it might owe to the class. A bench trial was held in the Delaware class action on April 10, 2018 and a decision is expected later this year.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-03-15):
[0001730168-19-000036:note_history:36]
Broadcom Inc., or Broadcom, a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company, or Broadcom-Singapore. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom Inc. common stock, or the Redomiciliation Transaction. As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom Inc. In addition, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, were mandatorily exchanged, or the Mandatory Exchange, for newly issued shares of Broadcom Inc. common stock and all limited partners of the Partnership became common stockholders of Broadcom Inc. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

- added (2019-03-15):
[0001730168-19-000036:note_history:37]
The Redomiciliation Transaction was accounted for as an exchange of equity interests among entities under common control and the historical basis of accounting was retained as if the entities had always been combined for financial reporting purposes.

- added (2019-03-15):
[0001730168-19-000036:note_history:38]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mobile, cloud, distributed and mainframe platforms.

- added (2019-03-15):
[0001730168-19-000036:note_history:39]
On November 5, 2018, we acquired CA, Inc., or CA, for $16.1 billion, net of cash acquired, or the CA Merger. CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018, or the CA Acquisition Date. See Note 3. “Acquisitions” for additional information.

- added (2019-03-15):
[0001730168-19-000036:note_history:40]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property, or IP, licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

- changed (2019-03-15):
[0001730168-19-000036:note_history:41]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019, or fiscal year 2019, is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ends on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018, or fiscal year 2018, was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.
  (was, 2018-09-13, similarity 0.8835):
[0001730168-18-000039:note_history:41]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 4, 2018, or fiscal year 2018, is a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. The first quarter of our fiscal year 2018 ended on February 4, 2018, the second quarter ended on May 6, 2018 and the third quarter ended on August 5, 2018. Our fiscal year ended October 29, 2017, or fiscal year 2017, was a 52-week fiscal year.

- changed (2019-03-15):
[0001730168-19-000036:note_history:42]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 3, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.
  (was, 2018-09-13, similarity 0.811):
[0001730168-18-000039:note_history:42]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared by us in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2017 condensed consolidated balance sheet data were derived from Broadcom-Singapore’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2017 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 5, 2018 are not necessarily indicative of the results that may be expected for fiscal year 2018, or for any other future period.

- added (2019-03-15):
[0001730168-19-000036:note_history:43]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of operations and statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.

- added (2019-03-15):
[0001730168-19-000036:note_history:44]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board, or FASB, guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.

- added (2019-03-15):
[0001730168-19-000036:note_history:45]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at costs less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter ended February 3, 2019, we also recognized $27 million of unrealized gains on equity securities within other income, net in our condensed consolidated statement of operations.

- added (2019-03-15):
[0001730168-19-000036:note_history:46]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, or Topic 606. We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition, or Topic 605, while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. "Revenue from Contracts with Customers" for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

- removed (2019-03-15):
[0001730168-18-000039:note_history:47]
Broadcom Inc., a Delaware corporation, is the successor to Broadcom Limited, a company organized under the laws of the Republic of Singapore, or Broadcom-Singapore. As part of the plan to cause the publicly traded parent company of Broadcom to be a Delaware corporation, or the Redomiciliation Transaction, after the close of market trading on April 4, 2018, Broadcom Inc. and Broadcom-Singapore completed a statutory scheme of arrangement under Singapore law pursuant to which all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom Inc. common stock and Broadcom-Singapore became an indirect wholly-owned subsidiary of Broadcom Inc.

- removed (2019-03-15):
[0001730168-18-000039:note_history:48]
In conjunction with the Redomiciliation Transaction, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, were mandatorily exchanged, or the Mandatory Exchange, on a one-for-one basis for newly issued shares of Broadcom Inc. common stock. As a result, all limited partners of the Partnership became common stockholders of Broadcom Inc. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. Consequently, the limited partners no longer hold a noncontrolling interest in the Partnership and we subsequently deregistered the Partnership.

- removed (2019-03-15):
[0001730168-18-000039:note_history:49]
The scheme of arrangement was accounted for as an exchange of equity interests among entities under common control. All assets and liabilities of Broadcom-Singapore were assumed by Broadcom Inc., resulting in the retention of the historical basis of accounting as if they had always been combined for accounting and financial reporting purposes.

- removed (2019-03-15):
[0001730168-18-000039:note_history:50]
We are a leading designer, developer and global supplier of a broad range of semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. We have four reportable segments: wired infrastructure, wireless communications, enterprise storage and industrial & other, which align with our principal target markets.

- removed (2019-03-15):
[0001730168-18-000039:note_history:51]
On November 17, 2017, we acquired Brocade Communications Systems, Inc., or Brocade. The unaudited condensed consolidated financial statements include the results of operations of Brocade commencing as of the acquisition date. See Note 2. “Acquisitions” for additional information.

- removed (2019-03-15):
[0001730168-18-000039:note_history:52]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows. These reclassifications had no impact on the previously reported net cash activities.

- removed (2019-03-15):
[0001730168-18-000039:note_history:53]
In the first quarter of fiscal year 2018, we early adopted guidance issued by the Financial Accounting Standards Board, or FASB, in October 2016 related to the recognition of income tax consequences of an intra-entity transfer of an asset other than inventory. The standard requires a modified-retrospective transition method by means of a cumulative-effect adjustment as of the beginning of the period in which the guidance is adopted. The adoption of this guidance resulted in a decrease in current and long-term prepaid tax expense of $67 million and $199 million, respectively, an increase of $252 million to our accumulated deficit and a decrease of $14 million to our noncontrolling interest.

- removed (2019-03-15):
[0001730168-18-000039:note_history:54]
In the second quarter of fiscal year 2018, we early adopted guidance issued by the FASB in February 2018 that allows companies to reclassify stranded income tax effects resulting from the U.S. Tax Cuts and Jobs Act, or the 2017 Tax Reform Act, from accumulated other comprehensive loss to retained earnings. The stranded income tax effects resulted from the change in the federal tax rate for deferred taxes recorded in accumulated other comprehensive loss. The adoption of this guidance resulted in a cumulative-effect adjustment as of the beginning of the second quarter of fiscal year 2018, which consisted of an increase to our accumulated other comprehensive loss of $16 million, an increase to retained earnings of $15 million and a $1 million increase to noncontrolling interest.

- removed (2019-03-15):
[0001730168-18-000039:note_history:55]
In August 2016, the FASB issued guidance related to the classification of certain transactions on the statement of cash flows. This guidance will be effective for the first quarter of our fiscal year 2019 on a retrospective basis; and early adoption is permitted. We do not intend to adopt this guidance early and will present our statements of cash flows in accordance with this guidance upon adoption.

- removed (2019-03-15):
[0001730168-18-000039:note_history:56]
In May 2014, the FASB issued guidance that outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance. The new standard creates a single source of revenue guidance under GAAP, eliminating industry-specific guidance. The underlying principle of the standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. An entity should apply a five-step approach for recognizing revenue as follows: (i) identify the contract with a customer; (ii) identify the performance obligations in the contract; (iii) determine the transaction price; (iv) allocate the transaction price to the performance obligations in the contract; and (v) recognize revenue when, or as, the entity satisfies a performance obligation. The standard also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- removed (2019-03-15):
[0001730168-18-000039:note_history:57]
The standard allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”) or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). We plan to adopt the new standard using the modified retrospective method at the beginning of the first quarter of fiscal year 2019. We have established a cross-functional team to assess the potential impact of the new revenue standard and are on schedule in establishing new accounting policies, processes, and internal controls necessary to support the requirements of the new standard. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, the exact impact of the new standard will be dependent on facts and circumstances at adoption.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-03-15):
[0001730168-19-000036:note_history:58]
The future scheduled principal payments for debt as of February 3, 2019 were as follows:

- changed (2019-03-15):
[0001730168-19-000036:note_history:59]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | — |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 1,650 |  |
| 2022 |  | 13,909 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 16,213 |  |
| Total |  | $ | 37,859 |  |
  (was, 2018-09-13, similarity 0.933):
[0001730168-18-000039:note_history:59]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2018 (remainder) |  | $ | 117 |  |
| 2019 |  | — |  |
| 2020 |  | 2,788 |  |
| 2021 |  | 750 |  |
| 2022 |  | 3,509 |  |
| Thereafter |  | 10,563 |  |
| Total |  | $ | 17,727 |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:60]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of August 5, 2018 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-03-15):
[0001730168-19-000036:note_history:61]
|  |  | Effective Interest Rate |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2021 |  | 3.853 | % |  | $ | 9,000 |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due September 2021 to November 2023 |  | 3.892 | % |  | 9,000 |  |  | — |  |
|  |  |  |  | 18,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount, premium and unamortized debt issuance costs |  |  |  | (218 | ) |  | (116 | ) |
| Total carrying value of debt |  |  |  | $ | 37,641 |  |  | $ | 17,493 |  |

- changed (2019-03-15):
[0001730168-19-000036:note_history:62]
2019 Term Loans and Assumed CA Senior Notes
  (was, 2018-09-13, similarity 0.7619):
[0001730168-18-000039:note_history:62]
2017 Senior Notes and Assumed BRCM Senior Notes

- added (2019-03-15):
[0001730168-19-000036:note_history:63]
In connection with the CA Merger, we entered into a credit agreement, or the 2019 Credit Agreement, which provides for a $9,000 million unsecured term A-3 facility and a $9,000 million unsecured term A-5 facility, collectively referred to as the 2019 Term Loans. Interest on our 2019 Term Loans is based on a floating rate and is payable monthly. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation, or BRCM, Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee being provided by Broadcom-Singapore until its pending voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019) is finalized.

- added (2019-03-15):
[0001730168-19-000036:note_history:64]
The 2019 Credit Agreement also provides for a five-year $5,000 million unsecured revolving credit facility, or the Revolving Facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit reduces the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we may borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on February 3, 2019.

- added (2019-03-15):
[0001730168-19-000036:note_history:65]
Additionally, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes, or the Assumed CA Senior Notes. CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- added (2019-03-15):
[0001730168-19-000036:note_history:66]
2017 Senior Notes

- added (2019-03-15):
[0001730168-19-000036:note_history:67]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the Subsidiary Issuers, issued $17,550 million of senior unsecured notes, or the 2017 Senior Notes. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom, or Parent Guarantor, and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc., or Subsidiary Guarantor, a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes under each of their respective indentures in accordance with their terms.

- added (2019-03-15):
[0001730168-19-000036:note_history:68]
As of February 3, 2019, the estimated aggregate fair value of debt was $37,021 million and was primarily classified as Level 2. The fair value of our 2019 Term Loans is determined using inputs based on discounted cash flow models with observable market inputs and takes into consideration variables such as interest rate changes, comparable instruments, and credit-rating changes. The fair values of the Assumed CA Senior Notes and 2017 Senior Notes are determined using quoted prices from less active markets.

- added (2019-03-15):
[0001730168-19-000036:note_history:69]
The future scheduled principal payments for debt as of February 3, 2019 were as follows:

- changed (2019-03-15):
[0001730168-19-000036:note_history:70]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | — |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 1,650 |  |
| 2022 |  | 13,909 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 16,213 |  |
| Total |  | $ | 37,859 |  |
  (was, 2018-09-13, similarity 0.933):
[0001730168-18-000039:note_history:70]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2018 (remainder) |  | $ | 117 |  |
| 2019 |  | — |  |
| 2020 |  | 2,788 |  |
| 2021 |  | 750 |  |
| 2022 |  | 3,509 |  |
| Thereafter |  | 10,563 |  |
| Total |  | $ | 17,727 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:71]
As of February 3, 2019 and November 4, 2018, we accrued interest payable of $104 million and $165 million, respectively and were in compliance with all debt covenants.

- removed (2019-03-15):
[0001730168-18-000039:note_history:72]
|  |  | As of August 5, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (123 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,604 |  |  |  |  | $ | 17,548 |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:73]
In fiscal year 2017, Broadcom Corporation, or BRCM, and Broadcom Cayman Finance Limited, or together with BRCM referred to as the Subsidiary Issuers, completed the issuance and sale of senior unsecured notes, or the 2017 Senior Notes, in an aggregate principal amount of $17,550 million. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom-Singapore and the Partnership, subject to certain release conditions described in the indentures governing the 2017 Senior Notes, or the 2017 Indentures. On April 9, 2018, Broadcom Inc., or Parent Guarantor, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. At that time, Broadcom-Singapore, a guarantor at the issuance of the 2017 Senior Notes, became an indirect wholly-owned subsidiary of Broadcom Inc. and a subsidiary guarantor, or Subsidiary Guarantor. In addition, the Partnership was released from its guarantee of the 2017 Senior Notes under each of the 2017 Indentures in accordance with their terms. Each series of 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year. As of August 5, 2018 and October 29, 2017, we accrued interest payable of $25 million and $136 million, respectively.

- removed (2019-03-15):
[0001730168-18-000039:note_history:74]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount of such 2017 Senior Notes plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and our subsidiaries to incur certain secured debt and consummate certain sale and leaseback transactions, and the ability of the Parent Guarantor, the Subsidiary Issuers and the Subsidiary Guarantor to merge, consolidate or sell all or substantially all of their assets.

- removed (2019-03-15):
[0001730168-18-000039:note_history:75]
In connection with the issuance of the 2017 Senior Notes, we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the SEC, and cause to be declared effective, a registration statement with respect to an offer to exchange, or the Exchange Offer, each series of 2017 Senior Notes for notes that are registered with the SEC, or the Registered Notes, with substantially identical terms. On January 9, 2018, we launched the Exchange Offer and on February 21, 2018, substantially all of the 2017 Senior Notes were tendered and exchanged for Registered Notes in the Exchange Offer.

- removed (2019-03-15):
[0001730168-18-000039:note_history:76]
We were in compliance with all of the covenants related to the 2017 Senior Notes and senior unsecured notes assumed in connection with the acquisition of BRCM, or the Assumed BRCM Senior Notes, as of August 5, 2018.

- removed (2019-03-15):
[0001730168-18-000039:note_history:77]
Assumed Brocade Debt

- removed (2019-03-15):
[0001730168-18-000039:note_history:78]
As a result of the Brocade Merger, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes due 2020, or the Assumed Brocade Convertible Notes. The Brocade Merger was a “fundamental change” as well as a “make-whole fundamental change” as defined under the terms of the indenture governing the Assumed Brocade Convertible Notes. Accordingly, the holders of the Assumed Brocade Convertible Notes received the right to require us to repurchase their notes for cash. In the first quarter of fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. The remaining outstanding Assumed Brocade Convertible Notes are convertible into cash at a conversion rate of $812 for each $1,000 of principal. We were in compliance with all of the covenants related to the Assumed Brocade Convertible Notes as of August 5, 2018.

- removed (2019-03-15):
[0001730168-18-000039:note_history:79]
We also assumed $300 million in aggregate principal amount of Brocade’s 4.625% senior unsecured notes due 2023. On January 16, 2018, we called and redeemed all of these outstanding notes for a total payment of $308 million, including the redemption price.

- removed (2019-03-15):
[0001730168-18-000039:note_history:80]
As of August 5, 2018, the estimated aggregate fair value of the 2017 Senior Notes, the Assumed BRCM Senior Notes and the Assumed Brocade Convertible Notes was $16,953 million and was primarily classified as Level 2 as we used quoted prices from less active markets.

- removed (2019-03-15):
[0001730168-18-000039:note_history:81]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of August 5, 2018 were as follows:


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-03-15):
[0001730168-19-000036:note_history:82]
|  |  | Effective Interest Rate |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2021 |  | 3.853 | % |  | $ | 9,000 |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due September 2021 to November 2023 |  | 3.892 | % |  | 9,000 |  |  | — |  |
|  |  |  |  | 18,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount, premium and unamortized debt issuance costs |  |  |  | (218 | ) |  | (116 | ) |
| Total carrying value of debt |  |  |  | $ | 37,641 |  |  | $ | 17,493 |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:83]
|  |  | As of August 5, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (123 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,604 |  |  |  |  | $ | 17,548 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2019-03-15):
[0001730168-18-000039:note_history:84]
Related Party Transactions

- removed (2019-03-15):
[0001730168-18-000039:note_history:85]
During the fiscal quarter and three fiscal quarters ended August 5, 2018 and July 30, 2017, in the ordinary course of business, we purchased from, or sold to, entities of which one of our directors also serves or served as a director, or entities that are otherwise affiliated with one of our directors.

- removed (2019-03-15):
[0001730168-18-000039:note_history:86]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |  | July 30, 2017 |  | August 5, 2018 |  | July 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 282 |  |  | $ | 97 |  |  | $ | 664 |  |  | $ | 245 |  |
| Total costs and expenses, including inventory purchases |  | $ | 25 |  |  | $ | 28 |  |  | $ | 92 |  |  | $ | 93 |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:87]
|  |  | August 5, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 79 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2019-03-15):
[0001730168-18-000039:note_history:88]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |  | July 30, 2017 |  | August 5, 2018 |  | July 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 282 |  |  | $ | 97 |  |  | $ | 664 |  |  | $ | 245 |  |
| Total costs and expenses, including inventory purchases |  | $ | 25 |  |  | $ | 28 |  |  | $ | 92 |  |  | $ | 93 |  |

- removed (2019-03-15):
[0001730168-18-000039:note_history:89]
|  |  | August 5, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 79 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-03-15):
[0001730168-19-000036:note_history:90]
The following table presents revenue disaggregated by type of revenue and by region.

- added (2019-03-15):
[0001730168-19-000036:note_history:91]
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services* |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:92]
________________________________

- added (2019-03-15):
[0001730168-19-000036:note_history:93]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-03-15):
[0001730168-19-000036:note_history:94]
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

- added (2019-03-15):
[0001730168-19-000036:note_history:95]
Nature of products and services

- added (2019-03-15):
[0001730168-19-000036:note_history:96]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

- added (2019-03-15):
[0001730168-19-000036:note_history:97]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

- added (2019-03-15):
[0001730168-19-000036:note_history:98]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering, or NRE, arrangements.

- added (2019-03-15):
[0001730168-19-000036:note_history:99]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

- added (2019-03-15):
[0001730168-19-000036:note_history:100]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

- added (2019-03-15):
[0001730168-19-000036:note_history:101]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

- added (2019-03-15):
[0001730168-19-000036:note_history:102]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

- added (2019-03-15):
[0001730168-19-000036:note_history:103]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

- added (2019-03-15):
[0001730168-19-000036:note_history:104]
There are two main categories of NRE contracts which we enter into with our customers; (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (cost-to-cost) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- added (2019-03-15):
[0001730168-19-000036:note_history:105]
Material rights. Contracts with customers may also include material rights which are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- added (2019-03-15):
[0001730168-19-000036:note_history:106]
Arrangements with multiple performance obligations

- added (2019-03-15):
[0001730168-19-000036:note_history:107]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

- added (2019-03-15):
[0001730168-19-000036:note_history:108]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

- added (2019-03-15):
[0001730168-19-000036:note_history:109]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

- added (2019-03-15):
[0001730168-19-000036:note_history:110]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

- added (2019-03-15):
[0001730168-19-000036:note_history:111]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

- added (2019-03-15):
[0001730168-19-000036:note_history:112]
Warranty. We provide only assurance-type warranties on our products to our customers. As a result, we accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

- added (2019-03-15):
[0001730168-19-000036:note_history:113]
Other policies and judgments

- added (2019-03-15):
[0001730168-19-000036:note_history:114]
Significant financing component. Payment terms and conditions vary by contract, although terms generally include a requirement of payment within a specified period. In certain arrangements, we receive payment from a customer either before or after the performance obligation has been satisfied. The timing difference between the payment and satisfaction of performance obligations for the vast majority of our contracts is one year or less; therefore, for those contracts, we apply a practical expedient and do not consider the effects of the time value of money.

- added (2019-03-15):
[0001730168-19-000036:note_history:115]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

- added (2019-03-15):
[0001730168-19-000036:note_history:116]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

- added (2019-03-15):
[0001730168-19-000036:note_history:117]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-03-15):
[0001730168-19-000036:note_history:118]
Revenue from Contracts with Customers

- added (2019-03-15):
[0001730168-19-000036:note_history:119]
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

- added (2019-03-15):
[0001730168-19-000036:note_history:120]
Nature of products and services

- added (2019-03-15):
[0001730168-19-000036:note_history:121]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

- added (2019-03-15):
[0001730168-19-000036:note_history:122]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

- added (2019-03-15):
[0001730168-19-000036:note_history:123]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering, or NRE, arrangements.

- added (2019-03-15):
[0001730168-19-000036:note_history:124]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

- added (2019-03-15):
[0001730168-19-000036:note_history:125]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

- added (2019-03-15):
[0001730168-19-000036:note_history:126]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

- added (2019-03-15):
[0001730168-19-000036:note_history:127]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

- added (2019-03-15):
[0001730168-19-000036:note_history:128]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

- added (2019-03-15):
[0001730168-19-000036:note_history:129]
There are two main categories of NRE contracts which we enter into with our customers; (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (cost-to-cost) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- added (2019-03-15):
[0001730168-19-000036:note_history:130]
Material rights. Contracts with customers may also include material rights which are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- added (2019-03-15):
[0001730168-19-000036:note_history:131]
Arrangements with multiple performance obligations

- added (2019-03-15):
[0001730168-19-000036:note_history:132]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

- added (2019-03-15):
[0001730168-19-000036:note_history:133]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

- added (2019-03-15):
[0001730168-19-000036:note_history:134]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

- added (2019-03-15):
[0001730168-19-000036:note_history:135]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

- added (2019-03-15):
[0001730168-19-000036:note_history:136]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

- added (2019-03-15):
[0001730168-19-000036:note_history:137]
Warranty. We provide only assurance-type warranties on our products to our customers. As a result, we accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

- added (2019-03-15):
[0001730168-19-000036:note_history:138]
Other policies and judgments

- added (2019-03-15):
[0001730168-19-000036:note_history:139]
Significant financing component. Payment terms and conditions vary by contract, although terms generally include a requirement of payment within a specified period. In certain arrangements, we receive payment from a customer either before or after the performance obligation has been satisfied. The timing difference between the payment and satisfaction of performance obligations for the vast majority of our contracts is one year or less; therefore, for those contracts, we apply a practical expedient and do not consider the effects of the time value of money.

- added (2019-03-15):
[0001730168-19-000036:note_history:140]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

- added (2019-03-15):
[0001730168-19-000036:note_history:141]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

- added (2019-03-15):
[0001730168-19-000036:note_history:142]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

- added (2019-03-15):
[0001730168-19-000036:note_history:143]
Disaggregation

- added (2019-03-15):
[0001730168-19-000036:note_history:144]
We have considered 1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker, or the CODM, as defined by the authoritative guidance on segment reporting, in evaluating financial performance and 2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. "Segment Information".

- added (2019-03-15):
[0001730168-19-000036:note_history:145]
The following table presents revenue disaggregated by type of revenue and by region.

- added (2019-03-15):
[0001730168-19-000036:note_history:146]
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services* |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:147]
________________________________

- added (2019-03-15):
[0001730168-19-000036:note_history:148]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

- added (2019-03-15):
[0001730168-19-000036:note_history:149]
Contract Balances

- added (2019-03-15):
[0001730168-19-000036:note_history:150]
Contract assets and contract liabilities balances for the periods indicated below were as follows:

- added (2019-03-15):
[0001730168-19-000036:note_history:151]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:152]
________________________________

- added (2019-03-15):
[0001730168-19-000036:note_history:153]
* We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

- added (2019-03-15):
[0001730168-19-000036:note_history:154]
The difference in the opening and closing balances of our contract assets and contract liabilities primarily results from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognized contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.

- added (2019-03-15):
[0001730168-19-000036:note_history:155]
Remaining Performance Obligations

- added (2019-03-15):
[0001730168-19-000036:note_history:156]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed where they are able to terminate for convenience without payment of a substantive penalty and this has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts which have an original duration of one year or less nor have we included contract with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

- added (2019-03-15):
[0001730168-19-000036:note_history:157]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 3, 2019 was not significant. Since our customers generally may not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- added (2019-03-15):
[0001730168-19-000036:note_history:158]
Contract Costs

- added (2019-03-15):
[0001730168-19-000036:note_history:159]
We have applied the practical expedient to expense commission costs as incurred for costs to obtain a contract when the amortization period would have been one year or less. As a result, no commission costs are capitalized.

- added (2019-03-15):
[0001730168-19-000036:note_history:160]
We have a policy to recognize an asset from the costs incurred to fulfill a contract that are not within the scope of another accounting literature. We have not incurred any costs to fulfill a contract that fall within the guidance and, as a result, no costs to fulfill a contract have been capitalized.

- added (2019-03-15):
[0001730168-19-000036:note_history:161]
Changes in Accounting Policies

- added (2019-03-15):
[0001730168-19-000036:note_history:162]
Except for the changes below, we have consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements. We adopted Topic 606 with an initial application date of November 5, 2018. As a result, we have changed our accounting policy for revenue recognition as detailed above.

- added (2019-03-15):
[0001730168-19-000036:note_history:163]
We applied Topic 606 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, we reflected the aggregate effect of all modifications when identifying the performance obligations and allocating the transaction price at transition, which did not have a material effect on the adjustment to retained earnings as of November 5, 2018.

- added (2019-03-15):
[0001730168-19-000036:note_history:164]
Financial Statement Impact of Adopting Topic 606

- added (2019-03-15):
[0001730168-19-000036:note_history:165]
We adopted Topic 606 using the modified retrospective method. The cumulative effect of applying the new guidance to all contracts with customers that were not completed by November 4, 2018 was recorded as an adjustment to retained earnings as of adoption on November 5, 2018. We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:

- added (2019-03-15):
[0001730168-19-000036:note_history:166]
| Balance Sheet |  | November 4, 2018 |  | Adjustments Due to Topic 606 |  | November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

- added (2019-03-15):
[0001730168-19-000036:note_history:167]
Impact of New Revenue Guidance on Net Revenue

- added (2019-03-15):
[0001730168-19-000036:note_history:168]
The following table compares net revenue for the fiscal quarter ended February 3, 2019 to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statement of operations for the fiscal quarter ended February 3, 2019 or in the condensed consolidated balance sheet as of February 3, 2019 were significantly affected by the new revenue guidance.

- added (2019-03-15):
[0001730168-19-000036:note_history:169]
|  |  | Fiscal Quarter Ended February 3, 2019 |
| Statement of Operations |  | Proforma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |
| Subscriptions and services |  | 1,006 |  |  | 144 |  |  | 1,150 |  |
| Total net revenue |  | $ | 5,645 |  |  | $ | 144 |  |  | $ | 5,789 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-03-15):
[0001730168-19-000036:note_history:170]
On March 13, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on March 29, 2019 to stockholders of record at the close of business on March 21, 2019.
  (was, 2018-09-13, similarity 0.9107):
[0001730168-18-000039:note_history:170]
On September 5, 2018, our Board of Directors declared a cash dividend of $1.75 per share, payable on September 28, 2018 to stockholders of record at the close of business on September 19, 2018.
