# AVGO 8-K — 0001193125-19-074832 filed 2019-03-14

## item codes, every 8-K on or before 2019-03-15

- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2019-03-15

- none on or before 2019-03-15

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-074832:8k_2_02:1]
EX-99.1
2
d642515dex991.htm
EX-99.1

[0001193125-19-074832:8k_2_02:2]
EX-99.1

[0001193125-19-074832:8k_2_02:3]
Exhibit 99.1

[0001193125-19-074832:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2019 Financial Results and Quarterly Dividend

[0001193125-19-074832:8k_2_02:5]
|  | • |  | Revenue of $5,789 million for the quarter, up 9 percent from the prior year period |

[0001193125-19-074832:8k_2_02:6]
|  | • |  | GAAP diluted EPS of $1.12; Non-GAAP diluted EPS of $5.55 |

[0001193125-19-074832:8k_2_02:7]
|  | • |  | $2,033 million of free cash flow from operations, defined as cash from operations of $2,132 less capital expenditures of $99 million, up 39 percent from the prior year period |

[0001193125-19-074832:8k_2_02:8]
|  | • |  | Quarterly dividend of $2.65 per share |

[0001193125-19-074832:8k_2_02:9]
|  | • |  | Repurchased and eliminated 14.2 million shares for $3,513 million |

[0001193125-19-074832:8k_2_02:10]
|  | • |  | Maintaining fiscal year 2019 revenue outlook of $24.5 billion |

[0001193125-19-074832:8k_2_02:11]
SAN JOSE, Calif. – March 14, 2019 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and
supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2019, ended February 3, 2019, and announced a quarterly dividend.

[0001193125-19-074832:8k_2_02:12]
“We had a good start to 2019 as we continued to execute on our proven business model. Strong results in our networking business supported our
semiconductor solutions segment, despite the anticipated sharp decline in wireless. Additionally, our infrastructure software segment performed extremely well as we made good progress with the CA business integration into Broadcom.” said Hock
Tan, President and CEO of Broadcom Inc. “Similar to our peers, we see a slowdown in China impacting demand. However, much of this was factored into our original guidance and we are maintaining our full year fiscal 2019 business outlook.”

[0001193125-19-074832:8k_2_02:13]
“We generated over $2 billion in free cash flow in the quarter, which represented 39% growth on a year on year basis,” said Tom Krause,
CFO of Broadcom Inc. “Consistent with our capital return plan, we returned $4.6 billion to stockholders in the quarter including $1.1 billion of cash dividends and $3.5 billion of share repurchases and eliminations. We remain
focused on returning approximately $12 billion to stockholders in fiscal 2019 via a combination of cash dividends and stock buy backs and eliminations, while maintaining our investment grade credit rating.”

[0001193125-19-074832:8k_2_02:14]
First Quarter Fiscal Year 2019 GAAP Results from Continuing Operations

[0001193125-19-074832:8k_2_02:15]
Net revenue was $5,789 million, an increase of 6.3 percent from $5,444 million in the previous quarter and an increase of 8.7 percent from
$5,327 million in the same quarter last year.

[0001193125-19-074832:8k_2_02:16]
Gross margin was $3,208 million, or 55.4 percent of net revenue. This compares with gross
margin of $2,935 million, or 53.9 percent of net revenue, in the prior quarter, and gross margin of $2,628 million, or 49.3 percent of net revenue, in the same quarter last year.

[0001193125-19-074832:8k_2_02:17]
1

[0001193125-19-074832:8k_2_02:18]
Operating expenses were $2,653 million. This compares with $1,283 million in the prior quarter and
$1,685 million in the same quarter last year.

[0001193125-19-074832:8k_2_02:19]
Operating income was $555 million, or 9.6 percent of net revenue. This compares with
operating income of $1,652 million, or 30.3 percent of net revenue, in the prior quarter, and operating income of $943 million, or 17.7 percent of net revenue, in the same quarter last year.

[0001193125-19-074832:8k_2_02:20]
Net income, which includes the impact of discontinued operations, was $471 million, or $1.12 per diluted share. This compares with net income of
$1,115 million, or $2.64 per diluted share, in the prior quarter, and net income of $6,566 million, or $14.62 per diluted share, in the same quarter last year.

[0001193125-19-074832:8k_2_02:21]
Cash from operations was $2,132 million in the quarter, compared to $1,685 million in the same quarter last year.

[0001193125-19-074832:8k_2_02:22]
| First Quarter Fiscal Year 2019 GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q1 19 |  |  | Q4 18 |  |  | Q1 18 |  |  | Q/Q |  |  | Y/Y |  |
| Total net revenue |  | $ | 5,789 |  |  | $ | 5,444 |  |  | $ | 5,327 |  |  |  | +6.3 | % |  |  | +8.7 | % |
| Gross margin |  |  | 55.4 | % |  |  | 53.9 | % |  |  | 49.3 | % |  |  | +150bps |  |  |  | +610bps |  |
| Operating expenses |  | $ | 2,653 |  |  | $ | 1,283 |  |  | $ | 1,685 |  |  | +$ | 1,370 |  |  | +$ | 968 |  |
| Net income |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 6,566 |  |  | -$ | 644 |  |  | -$ | 6,095 |  |
| Net income attributable to noncontrolling interest |  | $ | — |  |  | $ | — |  |  | $ | 336 |  |  | $ | — |  |  | -$ | 336 |  |
| Net income attributable to common stock |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 6,230 |  |  | -$ | 644 |  |  | -$ | 5,759 |  |
| Earnings per share - diluted |  | $ | 1.12 |  |  | $ | 2.64 |  |  | $ | 14.62 |  |  | -$ | 1.52 |  |  | -$ | 13.50 |  |

[0001193125-19-074832:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the first fiscal quarter were $5,093 million, compared to
$4,292 million at the end of the prior quarter.

[0001193125-19-074832:8k_2_02:24]
During the first fiscal quarter the Company generated $2,132 million in cash from operations
and spent $3,513 million on share repurchases and eliminations, consisting of $3,436 million in repurchases of 13.9 million shares and $77 million on withholding tax payments related to net settled equity awards that vested in
the quarter (representing approximately 0.3 million shares withheld), as well as $99 million on capital expenditures.

[0001193125-19-074832:8k_2_02:25]
On December 28, 2018, the
Company paid a cash dividend of $2.65 per share of common stock, totaling $1,067 million.

[0001193125-19-074832:8k_2_02:26]
First Quarter Fiscal Year 2019 Non-GAAP Results From Continuing Operations

[0001193125-19-074832:8k_2_02:27]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this
release.

[0001193125-19-074832:8k_2_02:28]
2

[0001193125-19-074832:8k_2_02:29]
Gross margin from continuing operations was $4,133 million, or 71.4 percent of net revenue. This
compares with gross margin from continuing operations of $3,725 million, or 68.4 percent of net revenue, in the prior quarter, and $3,454 million, or 64.8 percent of net revenue, in the same quarter last year.

[0001193125-19-074832:8k_2_02:30]
Operating income from continuing operations was $3,052 million, or 52.7 percent of net revenue. This compares with operating income from continuing
operations of $2,862 million, or 52.5 percent of net revenue, in the prior quarter, and $2,571 million, or 48.2 percent of net revenue, in the same quarter last year.

[0001193125-19-074832:8k_2_02:31]
Net income from continuing operations was $2,446 million, or $5.55 per diluted share. This compares with net income of $2,546 million, or $5.85 per
diluted share, in the prior quarter, and net income of $2,345 million, or $5.12 per diluted share, in the same quarter last year.

[0001193125-19-074832:8k_2_02:32]
Free cash flow
from operations, defined as cash from operations less capital expenditures, was $2,033 million in the quarter, compared to $1,465 million in the same quarter last year.

[0001193125-19-074832:8k_2_02:33]
| First Quarter Fiscal Year 2019 Non-GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q1 19 |  |  | Q4 18 |  |  | Q1 18 |  |  | Q/Q |  |  | Y/Y |  |
| Gross margin |  |  | 71.4 | % |  |  | 68.4 | % |  |  | 64.8 | % |  |  | +300bps |  |  |  | +660bps |  |
| Operating expenses |  | $ | 1,081 |  |  | $ | 863 |  |  | $ | 883 |  |  | +$ | 218 |  |  | +$ | 198 |  |
| Net income |  | $ | 2,446 |  |  | $ | 2,546 |  |  | $ | 2,345 |  |  | -$ | 100 |  |  | +$ | 101 |  |
| Earnings per share - diluted |  | $ | 5.55 |  |  | $ | 5.85 |  |  | $ | 5.12 |  |  | -$ | 0.30 |  |  | +$ | 0.43 |  |

[0001193125-19-074832:8k_2_02:34]
Other Quarterly Data

[0001193125-19-074832:8k_2_02:35]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q1 19 |  |  | Q4 18 |  |  | Q1 18 |  |  | Q/Q |  |  | Y/Y |  |
| Semiconductor solutions |  | $ | 4,374 |  |  |  | 76 | % |  | $ | 4,874 |  |  |  | 90 | % |  | $ | 4,955 |  |  |  | 93 | % |  |  | -10 | % |  |  | -12 | % |
| Infrastructure software |  |  | 1,403 |  |  |  | 24 |  |  |  | 513 |  |  |  | 9 |  |  |  | 328 |  |  |  | 6 |  |  |  | 173 | % |  |  | 328 | % |
| Intellectual property licensing |  |  | 12 |  |  |  | — |  |  |  | 57 |  |  |  | 1 |  |  |  | 44 |  |  |  | 1 |  |  |  | -79 | % |  |  | -73 | % |
| Total net revenue |  | $ | 5,789 |  |  |  | 100 | % |  | $ | 5,444 |  |  |  | 100 | % |  | $ | 5,327 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-19-074832:8k_2_02:36]
3

[0001193125-19-074832:8k_2_02:37]
Fiscal Year 2019 Business Outlook

[0001193125-19-074832:8k_2_02:38]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2019, ending November 3, 2019, including
contributions from CA, is expected to be as follows:

[0001193125-19-074832:8k_2_02:39]
|  |  | GAAP |  |  | Reconciling Items |  |  | Non-GAAP |  |
| Net revenue |  | $ | 24,500M |  |  |  | — |  |  | $ | 24,500M |  |
| Operating margin |  |  | 17.6 | % |  | $ | 8,180M |  |  |  | 51.0 | % |
| Net interest expense and other |  | $ | 1,250M |  |  |  | — |  |  | $ | 1,250M |  |
| Provision for income taxes |  |  | 3 | % |  |  | 8 | % |  |  | 11 | % |

[0001193125-19-074832:8k_2_02:40]
|  | • |  | Non-GAAP operating margin excludes an expected $5,210 million of amortization of acquisition-related intangible assets, $2.0 billion of stock-based compensation expense, $750 million of restructuring charges, and $220 million of acquisition-related costs; and |

[0001193125-19-074832:8k_2_02:41]
|  | • |  | Non-GAAP tax provision is 8% higher than GAAP due to the tax effects of the projected reconciling items noted above. |

[0001193125-19-074832:8k_2_02:42]
Capital expenditures for the fiscal year are expected to be approximately
$550 million. For the fiscal year, depreciation is expected to be $600 million and total intangible amortization is expected to be approximately $5,235 million.

[0001193125-19-074832:8k_2_02:43]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. Among other things, this guidance
is based on an initial estimate of purchase accounting adjustments and allocations, all of which are subject to revision. The guidance excludes the impact of any mergers, acquisitions, divestiture and stock repurchase activity that may occur during
fiscal year 2019. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future
events or otherwise, except as required by law.

[0001193125-19-074832:8k_2_02:44]
Quarterly Dividend

[0001193125-19-074832:8k_2_02:45]
The Company’s Board of Directors has approved a quarterly cash dividend of $2.65 per share.

[0001193125-19-074832:8k_2_02:46]
The dividend is payable on March 29, 2019 to stockholders of record at the close of business (5:00 p.m.) Eastern Time on March 21, 2019.

[0001193125-19-074832:8k_2_02:47]
Financial Results Conference Call

[0001193125-19-074832:8k_2_02:48]
Broadcom Inc. will
host a conference call to review its financial results for the first quarter of fiscal year 2019, ended February 3, 2019, and discuss guidance for fiscal year 2019, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial
(866) 310-8712; International +1 (720) 634-2946.

[0001193125-19-074832:8k_2_02:49]
4

[0001193125-19-074832:8k_2_02:50]
The passcode is 5732459. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1
(404) 537-3406; and reference the passcode: 5732459. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001193125-19-074832:8k_2_02:51]
Basis of Presentation

[0001193125-19-074832:8k_2_02:52]
Broadcom Inc. is the successor to
Broadcom Limited for financial reporting purposes effective as of the close of trading on April 4, 2018. Information provided for fiscal periods beginning with the fiscal quarter ended May 6, 2018, relates to Broadcom Inc. and for prior
fiscal periods relates to Broadcom Limited. Unless the context otherwise requires, references in this press release to “Broadcom,” “the Company,” “we,” “our,” “us” and similar terms are to Broadcom
Inc. from and after the effective time of the redomiciliation and, prior to that time, are to our predecessor, Broadcom Limited.

[0001193125-19-074832:8k_2_02:53]
The Company’s
financial results include contributions from CA, Inc.’s continuing operations starting in the first fiscal quarter of 2019. The financial results from businesses that have been classified as discontinued operations in the Company’s
financial statements are not included in the results presented below, unless otherwise stated.

[0001193125-19-074832:8k_2_02:54]
Due to the Company’s 52/53 week reporting cycle,
fiscal year 2018 included an extra week in the first quarter, compared to fiscal year 2019.

[0001193125-19-074832:8k_2_02:55]
Non-GAAP Financial
Measures

[0001193125-19-074832:8k_2_02:56]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating
expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information includes the effect, where applicable, of purchase accounting on revenue, and excludes
amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation
settlements, impairment on investment, debt-related costs, gain (loss) on extinguishment of debt, unrealized gains on investments, income (loss) from discontinued operations and non-GAAP tax reconciling
adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for
purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted
business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The
exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring,
infrequent or unusual. Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not
consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-19-074832:8k_2_02:57]
5

[0001193125-19-074832:8k_2_02:58]
Broadcom believes this non-GAAP financial information provides
additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of
the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a
substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data
attached to this press release.

[0001193125-19-074832:8k_2_02:59]
About Broadcom Inc.

[0001193125-19-074832:8k_2_02:60]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad
range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our
solutions include data center networking and storage, enterprise and mainframe software focused on automation, monitoring and security, smartphone components, telecoms and factory automation.

[0001193125-19-074832:8k_2_02:61]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-19-074832:8k_2_02:62]
Particular uncertainties that could
materially affect future results include risks associated with: our acquisition of CA, including (1) potential difficulties in employee retention, (2) unexpected costs, charges or expenses, and (3) our ability to successfully
integrate CA’s business and achieve the anticipated benefits of the transaction; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and

[0001193125-19-074832:8k_2_02:63]
6

[0001193125-19-074832:8k_2_02:64]
outsourced supply chain; any other acquisitions we may make, including integrating acquired companies with our existing businesses and our ability to achieve the benefits, growth prospects and
synergies expected by such acquisitions; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our significant indebtedness and the need to generate sufficient cash flows to service and
repay such debt; our dependency on a limited number of suppliers; dependence on and risks associated with distributors of our products; dependence on senior management and our ability to attract and retain qualified personnel; global economic
conditions and concerns; quarterly and annual fluctuations in operating results; the amount and frequency of our stock repurchases; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to
continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities or other significant operations; our ability to improve our
manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our
intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license
agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and
indemnification claims; our ability to sell to new types of customers and to keep pace with technological advances; market acceptance of the end products into which our products are designed; our ability to protect against a breach of security
systems; changes in accounting standards; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in
certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001193125-19-074832:8k_2_02:65]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may
affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made
in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-074832:8k_2_02:66]
| Contact: Broadcom Inc. Beatrice F. Russotto Investor Relations 408-433-8000 investor.relations@broadcom.com |  |  |

[0001193125-19-074832:8k_2_02:67]
BROADCOM INC.

[0001193125-19-074832:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-19-074832:8k_2_02:69]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-19-074832:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 3,2019 |  |  | November 4,2018 |  |  | February 4,2018 |  |
| Net revenue |  | $ | 5,789 |  |  | $ | 5,444 |  |  | $ | 5,327 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,692 |  |  |  | 1,746 |  |  |  | 1,899 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 833 |  |  |  | 762 |  |  |  | 715 |  |
| Restructuring charges |  |  | 56 |  |  |  | 1 |  |  |  | 15 |  |
| Total cost of revenue |  |  | 2,581 |  |  |  | 2,509 |  |  |  | 2,699 |  |
| Gross margin |  |  | 3,208 |  |  |  | 2,935 |  |  |  | 2,628 |  |
| Research and development |  |  | 1,133 |  |  |  | 948 |  |  |  | 925 |  |
| Selling, general and administrative |  |  | 471 |  |  |  | 237 |  |  |  | 291 |  |
| Amortization of acquisition-related intangible assets |  |  | 476 |  |  |  | 67 |  |  |  | 339 |  |
| Restructuring, impairment and disposal charges |  |  | 573 |  |  |  | 17 |  |  |  | 130 |  |
| Litigation settlements |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Total operating expenses |  |  | 2,653 |  |  |  | 1,283 |  |  |  | 1,685 |  |
| Operating income |  |  | 555 |  |  |  | 1,652 |  |  |  | 943 |  |
| Interest expense |  |  | (345 | ) |  |  | (148 | ) |  |  | (183 | ) |
| Impairment on investment |  |  | — |  |  |  | (106 | ) |  |  | — |  |
| Other income, net |  |  | 68 |  |  |  | 24 |  |  |  | 35 |  |
| Income from continuing operations before income taxes |  |  | 278 |  |  |  | 1,422 |  |  |  | 795 |  |
| Provision for (benefit from) income taxes |  |  | (203 | ) |  |  | 307 |  |  |  | (5,786 | ) |
| Income from continuing operations |  |  | 481 |  |  |  | 1,115 |  |  |  | 6,581 |  |
| Loss from discontinued operations, net of income taxes |  |  | (10 | ) |  |  | — |  |  |  | (15 | ) |
| Net income |  |  | 471 |  |  |  | 1,115 |  |  |  | 6,566 |  |
| Net income attributable to noncontrolling interest (1) |  |  | — |  |  |  | — |  |  |  | 336 |  |
| Net income attributable to common stock |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 6,230 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.20 |  |  | $ | 2.71 |  |  | $ | 15.23 |  |
| Income (loss) per share from discontinued operations |  |  | (0.03 | ) |  |  | — |  |  |  | (0.03 | ) |
| Net income per share |  | $ | 1.17 |  |  | $ | 2.71 |  |  | $ | 15.20 |  |
| Diluted income per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.15 |  |  | $ | 2.64 |  |  | $ | 14.66 |  |
| Income (loss) per share from discontinued operations |  |  | (0.03 | ) |  |  | — |  |  |  | (0.04 | ) |
| Net income per share |  | $ | 1.12 |  |  | $ | 2.64 |  |  | $ | 14.62 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 401 |  |  |  | 412 |  |  |  | 410 |  |
| Diluted |  |  | 419 |  |  |  | 423 |  |  |  | 426 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 34 |  |  | $ | 23 |  |  | $ | 20 |  |
| Research and development |  |  | 311 |  |  |  | 225 |  |  |  | 203 |  |
| Selling, general and administrative |  |  | 120 |  |  |  | 69 |  |  |  | 76 |  |
| Total stock-based compensation expense |  | $ | 465 |  |  | $ | 317 |  |  | $ | 299 |  |

[0001193125-19-074832:8k_2_02:71]
| (1) | In connection with the redomiciliation to the United States on April 4, 2018, or the Redomiciliation, all outstanding exchangeable limited partnership units, or LP Units, in Broadcom Cayman L.P. were exchanged for common stock of Broadcom on a one-for-one basis and the noncontrolling interest, or NCI, was eliminated. Net income attributable to NCI prior to the Redomiciliation represents approximately 5% of net income attributable to LP Units. |

[0001193125-19-074832:8k_2_02:72]
| (2) | For the fiscal quarter ended February 4, 2018, diluted income per share excluded the potentially dilutive effect of the exchange of LP Units as their effect was antidilutive. There were no LP Units outstanding during the fiscal quarters ended February 3, 2019 or November 4, 2018 due to the Redomiciliation. |

[0001193125-19-074832:8k_2_02:73]
BROADCOM INC.

[0001193125-19-074832:8k_2_02:74]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-19-074832:8k_2_02:75]
(IN MILLIONS)

[0001193125-19-074832:8k_2_02:76]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 3,2019 |  |  | November 4,2018 |  |  | February 4,2018 |  |
| Net revenue on GAAP basis |  | $ | 5,789 |  |  | $ | 5,444 |  |  | $ | 5,327 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | 4 |  |  |  | 4 |  |
| Net revenue on non-GAAP basis |  | $ | 5,789 |  |  | $ | 5,448 |  |  | $ | 5,331 |  |
| Gross margin on GAAP basis |  | $ | 3,208 |  |  | $ | 2,935 |  |  | $ | 2,628 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | 4 |  |  |  | 4 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 833 |  |  |  | 762 |  |  |  | 715 |  |
| Stock-based compensation expense |  |  | 34 |  |  |  | 23 |  |  |  | 20 |  |
| Restructuring charges |  |  | 56 |  |  |  | 1 |  |  |  | 15 |  |
| Acquisition-related costs |  |  | 2 |  |  |  | — |  |  |  | 2 |  |
| Gross margin on non-GAAP basis |  | $ | 4,133 |  |  | $ | 3,725 |  |  | $ | 3,454 |  |
| Research and development on GAAP basis |  | $ | 1,133 |  |  | $ | 948 |  |  | $ | 925 |  |
| Stock-based compensation expense |  |  | 311 |  |  |  | 225 |  |  |  | 203 |  |
| Acquisition-related costs |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 820 |  |  | $ | 722 |  |  | $ | 719 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 471 |  |  | $ | 237 |  |  | $ | 291 |  |
| Stock-based compensation expense |  |  | 120 |  |  |  | 69 |  |  |  | 76 |  |
| Acquisition-related costs |  |  | 90 |  |  |  | 27 |  |  |  | 51 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 261 |  |  | $ | 141 |  |  | $ | 164 |  |
| Total operating expenses on GAAP basis |  | $ | 2,653 |  |  | $ | 1,283 |  |  | $ | 1,685 |  |
| Amortization of acquisition-related intangible assets |  |  | 476 |  |  |  | 67 |  |  |  | 339 |  |
| Stock-based compensation expense |  |  | 431 |  |  |  | 294 |  |  |  | 279 |  |
| Restructuring, impairment and disposal charges |  |  | 573 |  |  |  | 17 |  |  |  | 130 |  |
| Litigation settlements |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Acquisition-related costs |  |  | 92 |  |  |  | 28 |  |  |  | 54 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,081 |  |  | $ | 863 |  |  | $ | 883 |  |
| Operating income on GAAP basis |  | $ | 555 |  |  | $ | 1,652 |  |  | $ | 943 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | 4 |  |  |  | 4 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,309 |  |  |  | 829 |  |  |  | 1,054 |  |
| Stock-based compensation expense |  |  | 465 |  |  |  | 317 |  |  |  | 299 |  |
| Restructuring, impairment and disposal charges |  |  | 629 |  |  |  | 18 |  |  |  | 145 |  |
| Litigation settlements |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Acquisition-related costs |  |  | 94 |  |  |  | 28 |  |  |  | 56 |  |
| Operating income on non-GAAP basis |  | $ | 3,052 |  |  | $ | 2,862 |  |  | $ | 2,571 |  |
| Interest expense on GAAP basis |  | $ | (345 | ) |  | $ | (148 | ) |  | $ | (183) |  |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Interest expense on non-GAAP basis |  | $ | (345 | ) |  | $ | (148 | ) |  | $ | (151) |  |
| Other income, net on GAAP basis |  | $ | 68 |  |  | $ | 24 |  |  | $ | 35 |  |
| Unrealized gains on investments |  |  | (27 | ) |  |  | — |  |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 41 |  |  | $ | 24 |  |  | $ | 35 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 278 |  |  | $ | 1,422 |  |  | $ | 795 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | 4 |  |  |  | 4 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,309 |  |  |  | 829 |  |  |  | 1,054 |  |
| Stock-based compensation expense |  |  | 465 |  |  |  | 317 |  |  |  | 299 |  |
| Restructuring, impairment and disposal charges |  |  | 629 |  |  |  | 18 |  |  |  | 145 |  |
| Litigation settlements |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Acquisition-related costs |  |  | 94 |  |  |  | 28 |  |  |  | 56 |  |
| Impairment on investment |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Unrealized gains on investments |  |  | (27 | ) |  |  | — |  |  |  | — |  |
| Income before income taxes on non-GAAP basis |  | $ | 2,748 |  |  | $ | 2,738 |  |  | $ | 2,455 |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (203 | ) |  | $ | 307 |  |  | $ | (5,786 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 505 |  |  |  | (115 | ) |  |  | 5,896 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 302 |  |  | $ | 192 |  |  | $ | 110 |  |
| Net income on GAAP basis |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 6,566 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | 4 |  |  |  | 4 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,309 |  |  |  | 829 |  |  |  | 1,054 |  |
| Stock-based compensation expense |  |  | 465 |  |  |  | 317 |  |  |  | 299 |  |
| Restructuring, impairment and disposal charges |  |  | 629 |  |  |  | 18 |  |  |  | 145 |  |
| Litigation settlements |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Acquisition-related costs |  |  | 94 |  |  |  | 28 |  |  |  | 56 |  |
| Impairment on investment |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Unrealized gains on investments |  |  | (27 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP tax reconciling adjustments |  |  | (505 | ) |  |  | 115 |  |  |  | (5,896 | ) |
| Discontinued operations, net of income taxes |  |  | 10 |  |  |  | — |  |  |  | 15 |  |
| Net income on non-GAAP basis |  | $ | 2,446 |  |  | $ | 2,546 |  |  | $ | 2,345 |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 419 |  |  |  | 423 |  |  |  | 426 |  |
| Non-GAAP adjustment (2) |  |  | 22 |  |  |  | 12 |  |  |  | 32 |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 441 |  |  |  | 435 |  |  |  | 458 |  |
| Net income on non-GAAP basis |  | $ | 2,446 |  |  | $ | 2,546 |  |  | $ | 2,345 |  |
| Interest expense on non-GAAP basis |  |  | 345 |  |  |  | 148 |  |  |  | 151 |  |
| Provision for income taxes on non-GAAP basis |  |  | 302 |  |  |  | 192 |  |  |  | 110 |  |
| Depreciation |  |  | 143 |  |  |  | 132 |  |  |  | 126 |  |
| Adjusted EBITDA |  | $ | 3,236 |  |  | $ | 3,018 |  |  | $ | 2,732 |  |
| Net cash provided by operating activities |  | $ | 2,132 |  |  | $ | 2,635 |  |  | $ | 1,685 |  |
| Purchases of property, plant and equipment |  |  | (99 | ) |  |  | (106 | ) |  |  | (220 | ) |
| Free cash flow |  | $ | 2,033 |  |  | $ | 2,529 |  |  | $ | 1,465 |  |
|  |  | FiscalQuarterEnding |  |  |  |  |  |  |  |
| Expected fully diluted share count: |  | May 5,2019 |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 422 |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustment (2) |  |  | 28 |  |  |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 450 |  |  |  |  |  |  |  |  |  |

[0001193125-19-074832:8k_2_02:77]
| (1) | Amounts represent licensing revenue not included in GAAP net revenue as a result of the effect of purchase accounting for acquisitions. |

[0001193125-19-074832:8k_2_02:78]
| (2) | Non-GAAP adjustment for number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. Non-GAAP adjustment also includes the impact of LP Units that are anti-dilutive on a GAAP basis for the fiscal quarter ended February 4, 2018. |

[0001193125-19-074832:8k_2_02:79]
BROADCOM INC.

[0001193125-19-074832:8k_2_02:80]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-19-074832:8k_2_02:81]
(IN MILLIONS)

[0001193125-19-074832:8k_2_02:82]
|  |  | February 3,2019 |  |  | November 4,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,093 |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  |  | 3,677 |  |  |  | 3,325 |  |
| Inventory |  |  | 1,074 |  |  |  | 1,124 |  |
| Other current assets |  |  | 760 |  |  |  | 366 |  |
| Total current assets |  |  | 10,604 |  |  |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,684 |  |  |  | 2,635 |  |
| Goodwill |  |  | 36,647 |  |  |  | 26,913 |  |
| Intangible assets, net |  |  | 21,493 |  |  |  | 10,762 |  |
| Other long-term assets |  |  | 682 |  |  |  | 707 |  |
| Total assets |  | $ | 72,110 |  |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 738 |  |  | $ | 811 |  |
| Employee compensation and benefits |  |  | 463 |  |  |  | 715 |  |
| Current portion of long-term debt |  |  | 3,537 |  |  |  | — |  |
| Other current liabilities |  |  | 3,611 |  |  |  | 812 |  |
| Total current liabilities |  |  | 8,349 |  |  |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 34,104 |  |  |  | 17,493 |  |
| Other long-term liabilities |  |  | 6,433 |  |  |  | 3,636 |  |
| Total liabilities |  |  | 48,886 |  |  |  | 23,467 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital |  |  | 23,081 |  |  |  | 23,285 |  |
| Retained earnings |  |  | 259 |  |  |  | 3,487 |  |
| Accumulated other comprehensive loss |  |  | (116 | ) |  |  | (115 | ) |
| Total stockholders’ equity |  |  | 23,224 |  |  |  | 26,657 |  |
| Total liabilities and stockholders’ equity |  | $ | 72,110 |  |  | $ | 50,124 |  |

[0001193125-19-074832:8k_2_02:83]
BROADCOM INC.

[0001193125-19-074832:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-19-074832:8k_2_02:85]
(IN MILLIONS)

[0001193125-19-074832:8k_2_02:86]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 3,2019 |  |  | November 4,2018 |  |  | February 4,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 6,566 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 1,316 |  |  |  | 836 |  |  |  | 1,058 |  |
| Depreciation |  |  | 143 |  |  |  | 132 |  |  |  | 126 |  |
| Stock-based compensation |  |  | 465 |  |  |  | 317 |  |  |  | 299 |  |
| Deferred taxes and other non-cash taxes |  |  | (379 | ) |  |  | 242 |  |  |  | (5,832 | ) |
| Impairment on investment |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Non-cash restructuring, impairment and disposal charges |  |  | 92 |  |  |  | 8 |  |  |  | 5 |  |
| Non-cash interest expense |  |  | 13 |  |  |  | 6 |  |  |  | 6 |  |
| Other |  |  | (21 | ) |  |  | 15 |  |  |  | 3 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | 68 |  |  |  | (312 | ) |  |  | 199 |  |
| Inventory |  |  | 50 |  |  |  | 92 |  |  |  | 250 |  |
| Accounts payable |  |  | (169 | ) |  |  | 28 |  |  |  | (403 | ) |
| Employee compensation and benefits |  |  | (458 | ) |  |  | 93 |  |  |  | (376 | ) |
| Contributions to defined benefit pension plans |  |  | — |  |  |  | — |  |  |  | (129 | ) |
| Other current assets and current liabilities |  |  | 506 |  |  |  | 163 |  |  |  | 284 |  |
| Other long-term assets and long-term liabilities |  |  | 35 |  |  |  | (206 | ) |  |  | (371 | ) |
| Net cash provided by operating activities |  |  | 2,132 |  |  |  | 2,635 |  |  |  | 1,685 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (16,027 | ) |  |  | (7 | ) |  |  | (4,786 | ) |
| Business sale proceeds (repayments) |  |  | 957 |  |  |  | (9 | ) |  |  | 782 |  |
| Purchases of property, plant and equipment |  |  | (99 | ) |  |  | (106 | ) |  |  | (220 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 1 |  |  |  | 237 |  |
| Purchases of investments |  |  | — |  |  |  | — |  |  |  | (244 | ) |
| Other |  |  | (24 | ) |  |  | 3 |  |  |  | 4 |  |
| Net cash used in investing activities |  |  | (15,193 | ) |  |  | (118 | ) |  |  | (4,227 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | 17,896 |  |  |  | — |  |  |  | — |  |
| Repayment of debt |  |  | — |  |  |  | (117 | ) |  |  | (856 | ) |
| Payment of debt issuance costs |  |  | (46 | ) |  |  | — |  |  |  | — |  |
| Other borrowings |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Dividend and distribution payments |  |  | (1,067 | ) |  |  | (723 | ) |  |  | (755 | ) |
| Repurchases of common stock—repurchase program |  |  | (3,436 | ) |  |  | (1,533 | ) |  |  | — |  |
| Shares repurchased for tax witholdings on vesting of equity awards |  |  | (77 | ) |  |  | (21 | ) |  |  | — |  |
| Issuance of common stock |  |  | 62 |  |  |  | 59 |  |  |  | 34 |  |
| Other |  |  | (1 | ) |  |  | (26 | ) |  |  | (9 | ) |
| Net cash provided by (used in) financing activities |  |  | 13,862 |  |  |  | (2,361 | ) |  |  | (1,586 | ) |
| Net change in cash and cash equivalents |  |  | 801 |  |  |  | 156 |  |  |  | (4,128 | ) |
| Cash and cash equivalents at the beginning of period |  |  | 4,292 |  |  |  | 4,136 |  |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | 5,093 |  |  | $ | 4,292 |  |  | $ | 7,076 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 423 |  |  | $ | 2 |  |  | $ | 232 |  |
| Cash paid for income taxes |  | $ | 95 |  |  | $ | 189 |  |  | $ | 109 |  |
