# AVGO MD&A — 0001730168-19-000036


## mdna

[0001730168-19-000036:mdna:1]
[same as prior period, unchanged from 0001730168-18-000039:mdna:1]

[0001730168-19-000036:mdna:2]
[same as prior period, unchanged from 0001730168-18-000039:mdna:2]

[0001730168-19-000036:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mobile, cloud, distributed and mainframe platforms.

[0001730168-19-000036:mdna:4]
Our fiscal year ending November 3, 2019, or fiscal year 2019, is a 52-week fiscal year, with our first fiscal quarter containing 13 weeks compared to 14 weeks in the first fiscal quarter ended February 4, 2018.

[0001730168-19-000036:mdna:5]
[same as prior period, unchanged from 0001730168-18-000039:mdna:5]

[0001730168-19-000036:mdna:6]
Highlights during the fiscal quarter ended February 3, 2019 include the following:

[0001730168-19-000036:mdna:7]
| • | On November 5, 2018, we completed the acquisition of CA, Inc., or CA, for aggregate consideration of approximately $18.8 billion, or the CA Merger. |

[0001730168-19-000036:mdna:8]
| • | We financed the CA Merger with proceeds of $18 billion from two unsecured term loan facilities, or the 2019 Term Loans, as well as cash on hand of the combined companies. See Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q for more details. |

[0001730168-19-000036:mdna:9]
•We generated $2,132 million of cash from operations.

[0001730168-19-000036:mdna:10]
| • | We paid $3,436 million to repurchase shares of our common stock under our stock repurchase program, $1,067 million for cash dividends and $77 million in employee withholding taxes related to net settled equity awards. |

[0001730168-19-000036:mdna:11]
36

[0001730168-19-000036:mdna:12]
Subsequent to the CA Merger, we changed our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. Our semiconductor solutions segment includes all of our product lines, except for those related to our fibre channel storage area networking, or FC SAN, products. Our infrastructure software segment includes our FC SAN products and the CA mainframe and enterprise software solutions. The IP licensing segment includes the results of our IP licensing business. Prior period segment results have been recast to conform to the current presentation.

[0001730168-19-000036:mdna:13]
[same as prior period, unchanged from 0001730168-18-000039:mdna:15]

[0001730168-19-000036:mdna:14]
Acquisition of CA

[0001730168-19-000036:mdna:15]
On November 5, 2018, we acquired CA for approximately $18.8 billion in exchange for all shares of CA common stock issued and outstanding immediately prior to the CA Merger. In addition, we assumed all outstanding unvested CA equity awards held by continuing employees. All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon completion of the CA Merger.

[0001730168-19-000036:mdna:16]
Divestiture of Veracode, Inc.

[0001730168-19-000036:mdna:17]
On December 31, 2018, we sold Veracode, Inc., or Veracode, a wholly-owned subsidiary of CA and provider of application security testing solutions, to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments.

[0001730168-19-000036:mdna:18]
[same as prior period, unchanged from 0001730168-18-000039:mdna:27]

[0001730168-19-000036:mdna:19]
[same as prior period, unchanged from 0001730168-18-000039:mdna:28]

[0001730168-19-000036:mdna:20]
Refer to Note 2. “Revenue from Contracts with Customers” in Part I, Item 1 of this Form 10-Q for updates on critical accounting estimates related to revenue recognition. There were no other significant changes in our critical accounting policies during the fiscal quarter ended February 3, 2019 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2018 Annual Report on Form 10-K.

[0001730168-19-000036:mdna:21]
[same as prior period, unchanged from 0001730168-18-000039:mdna:31]

[0001730168-19-000036:mdna:22]
Fiscal Quarter Ended February 3, 2019 Compared to Fiscal Quarter Ended February 4, 2018

[0001730168-19-000036:mdna:23]
The following table sets forth our results of operations for the periods presented:

[0001730168-19-000036:mdna:24]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |  | (As a percentage of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,639 |  |  | $ | 5,108 |  |  | 80 | % |  | 96 | % |
| Subscriptions and services |  | 1,150 |  |  | 219 |  |  | 20 |  |  | 4 |  |
| Total net revenue |  | 5,789 |  |  | 5,327 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,554 |  |  | 1,876 |  |  | 27 |  |  | 36 |  |
| Cost of subscriptions and services |  | 138 |  |  | 23 |  |  | 2 |  |  | 1 |  |
| Purchase accounting effect on inventory |  | — |  |  | 70 |  |  | — |  |  | 1 |  |
| Amortization of acquisition-related intangible assets |  | 833 |  |  | 715 |  |  | 15 |  |  | 13 |  |
| Restructuring charges |  | 56 |  |  | 15 |  |  | 1 |  |  | — |  |
| Total cost of revenue |  | 2,581 |  |  | 2,699 |  |  | 45 |  |  | 51 |  |
| Gross margin |  | 3,208 |  |  | 2,628 |  |  | 55 |  |  | 49 |  |
| Research and development |  | 1,133 |  |  | 925 |  |  | 19 |  |  | 17 |  |
| Selling, general and administrative |  | 471 |  |  | 291 |  |  | 8 |  |  | 6 |  |
| Amortization of acquisition-related intangible assets |  | 476 |  |  | 339 |  |  | 8 |  |  | 6 |  |
| Restructuring, impairment and disposal charges |  | 573 |  |  | 130 |  |  | 10 |  |  | 2 |  |
| Total operating expenses |  | 2,653 |  |  | 1,685 |  |  | 45 |  |  | 31 |  |
| Operating income |  | $ | 555 |  |  | $ | 943 |  |  | 10 | % |  | 18 | % |

[0001730168-19-000036:mdna:25]
[same as prior period, unchanged from 0001730168-18-000039:mdna:36]

[0001730168-19-000036:mdna:26]
Our semiconductor solutions segment and infrastructure software segment represented 76% and 24% of our net revenue, respectively, for the fiscal quarter ended February 3, 2019, with our IP licensing segment representing less than 1% of our net revenue.

[0001730168-19-000036:mdna:27]
Historically, a relatively small number of customers has accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 15% of our net revenue for the fiscal quarter ended February 3, 2019. Foxconn Technology Group companies (including Hon Hai Precision Industries), contract manufacturers, accounted for 18% of our net revenue for the fiscal quarter ended February 4, 2018. We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% and 48% of our net revenue for the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for the fiscal quarter ended February 3, 2019 and more than 30% for the fiscal quarter ended February 4, 2018. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-19-000036:mdna:28]
From time to time, some key customers of our semiconductor products place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the launches of, and seasonal variations in sales of mobile handsets.

[0001730168-19-000036:mdna:29]
|  |  | Fiscal Quarter Ended |
| Net Revenue by Segment |  | February 3, 2019 |  | February 4, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,374 |  |  | $ | 4,955 |  |  | $ | (581 | ) |  | (12 | )% |
| Infrastructure software |  | 1,403 |  |  | 328 |  |  | 1,075 |  |  | 328 | % |
| IP licensing |  | 12 |  |  | 44 |  |  | (32 | ) |  | (73 | )% |
| Total net revenue |  | $ | 5,789 |  |  | $ | 5,327 |  |  | $ | 462 |  |  | 9 | % |

[0001730168-19-000036:mdna:30]
|  |  | Fiscal Quarter Ended |
| % of Net Revenue by Segment |  | February 3, 2019 |  | February 4, 2018 |
| Semiconductor solutions |  | 76 | % |  | 93 | % |
| Infrastructure software |  | 24 |  |  | 6 |  |
| IP licensing |  | — |  |  | 1 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-19-000036:mdna:31]
Fiscal quarter ended February 3, 2019 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to lower demand for our wireless content in mobile handsets, as well as lower demand for our server storage connectivity and set-top box products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. These decreases were offset by higher demand for our standard networking products. Net revenue from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products as well as higher demand for our FC SAN products. Net revenue from our IP licensing segment decreased primarily due to lower IP licensing volume.

[0001730168-19-000036:mdna:32]
[same as prior period, unchanged from 0001730168-18-000039:mdna:47]

[0001730168-19-000036:mdna:33]
Gross margin was $3,208 million for the fiscal quarter ended February 3, 2019 compared to $2,628 million for the fiscal quarter ended February 4, 2018. As a percentage of net revenue, gross margin was 55% and 49% for the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively. The increase in gross margin was primarily due to contributions from our CA mainframe and enterprise software products as well as favorable gross margin impact from our FC SAN products. The increase was partially offset by higher amortization of acquisition-related intangible assets and restructuring charges as a result of the CA Merger.

[0001730168-19-000036:mdna:34]
[same as prior period, unchanged from 0001730168-18-000039:mdna:50]

[0001730168-19-000036:mdna:35]
Research and development expense increased $208 million, or 22%, for the fiscal quarter ended February 3, 2019 compared to the prior year fiscal period primarily due to the acquisition of CA and an increase in stock-based compensation expense. The increase in stock-based compensation expense was primarily due to the issuance of multi-year equity grants of time- and market-based restricted stock units, or the Multi-Year Equity Awards. The Multi-Year Equity Awards were granted in our first fiscal quarter of 2019 in lieu of our annual employee equity awards historically granted in the second quarter of our fiscal year. Each Multi-Year Equity Award vests on the same basis as four annual grants made on March 15 of each year, beginning in 2019, with successive four-year vesting periods. The increase was also attributable to expense recognized in the first quarter of fiscal year 2019 related to annual employee equity awards granted in March 2018 at higher grant-date fair values.

[0001730168-19-000036:mdna:36]
[same as prior period, unchanged from 0001730168-18-000039:mdna:52]

[0001730168-19-000036:mdna:37]
Selling, general and administrative expense increased $180 million, or 62%, for the fiscal quarter ended February 3, 2019 compared to the prior year fiscal period primarily due to the acquisition of CA and acquisition-related costs. The increase was also due to an increase in stock-based compensation expense, primarily due to the issuance of Multi-Year Equity Awards, assumed CA equity awards and annual employee equity awards granted in March 2018 at higher grant-date fair values.

[0001730168-19-000036:mdna:38]
[same as prior period, unchanged from 0001730168-18-000039:mdna:54]

[0001730168-19-000036:mdna:39]
Amortization of acquisition-related intangible assets recognized in operating expenses was $476 million for the fiscal quarter ended February 3, 2019 compared to $339 million for the fiscal quarter ended February 4, 2018. The increase was primarily due to amortization of intangible assets acquired in the CA Merger.

[0001730168-19-000036:mdna:40]
[same as prior period, unchanged from 0001730168-18-000039:mdna:56]

[0001730168-19-000036:mdna:41]
Restructuring, impairment and disposal charges recognized in operating expenses were $573 million for the fiscal quarter ended February 3, 2019 compared to $130 million for the fiscal quarter ended February 4, 2018. The increase was primarily due to employee termination costs and other restructuring activities resulting from the CA Merger. We expect to incur additional restructuring charges in future periods as a result of the CA Merger. See Note 12. “Restructuring, Impairment and Disposal Charges” in Part I, Item 1 of this Form 10-Q for more details.

[0001730168-19-000036:mdna:42]
[same as prior period, unchanged from 0001730168-18-000039:mdna:58]

[0001730168-19-000036:mdna:43]
|  |  | Fiscal Quarter Ended |
| Operating Income (Loss) by Segment |  | February 3, 2019 |  | February 4, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 2,037 |  |  | $ | 2,325 |  |  | $ | (288 | ) |  | (12 | )% |
| Infrastructure software |  | 1,020 |  |  | 216 |  |  | 804 |  |  | 372 | % |
| IP licensing |  | (5 | ) |  | 26 |  |  | (31 | ) |  | (119 | )% |
| Unallocated expenses |  | (2,497 | ) |  | (1,624 | ) |  | (873 | ) |  | 54 | % |
| Total operating income |  | $ | 555 |  |  | $ | 943 |  |  | $ | (388 | ) |  | (41 | )% |

[0001730168-19-000036:mdna:44]
Fiscal quarter ended February 3, 2019 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand in our wireless content in mobile handsets, as well as lower demand for our server storage connectivity products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. These decreases were offset by higher demand for our standard networking products. Operating income from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as an increase in demand for our FC SAN products. Operating loss from our IP licensing segment was primarily due to lower IP licensing volume.

[0001730168-19-000036:mdna:45]
Unallocated expenses include amortization of acquisition-related intangible assets; restructuring, impairment and disposal charges; stock-based compensation expense; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 54% in the fiscal quarter ended February 3, 2019 compared with the corresponding prior year period primarily due to increases in restructuring, impairment and disposal charges, amortization of acquisition-related intangible assets, stock-based compensation expense and acquisition-related costs. These increases were primarily due to the CA Merger and the issuance of Multi-Year Equity Awards.

[0001730168-19-000036:mdna:46]
[same as prior period, unchanged from 0001730168-18-000039:mdna:64]

[0001730168-19-000036:mdna:47]
Interest expense. Interest expense was $345 million for the fiscal quarter ended February 3, 2019 compared to $183 million for the fiscal quarter ended February 4, 2018. The increase was primarily due to interest on the additional debt we incurred to finance the CA Merger.

[0001730168-19-000036:mdna:48]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $68 million for the fiscal quarter ended February 3, 2019 compared to $35 million for the fiscal quarter ended February 4, 2018. This increase was primarily due to an increase in unrealized gains on investments.

[0001730168-19-000036:mdna:49]
Benefit from income taxes. For the fiscal quarter ended February 3, 2019, our benefit from income taxes was $203 million, compared to a benefit from income taxes of $5,786 million for the fiscal quarter ended February 4, 2018. The benefit from income taxes decreased from the prior period because the prior period included the tax effects of a change in law, due to enactment of the U.S. Tax Cuts and Jobs Act, or the 2017 Tax Reform Act.

[0001730168-19-000036:mdna:50]
The benefit for the fiscal quarter ended February 3, 2019 was primarily due to the recognition of gross uncertain tax benefits as a result of audit settlements, lapses of statutes of limitations, valuation allowance releases resulting from the CA Merger, and excess tax benefits from stock-based awards that were vested or exercised during the period. The current period also includes the impact of several provisions of the 2017 Tax Reform Act that take effect for us for the first time in the fiscal year ending November 3, 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income, or GILTI, a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000036:mdna:51]
The benefit from income taxes for the corresponding 2018 fiscal period was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act, signed into law on December 22, 2017. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017.

[0001730168-19-000036:mdna:52]
[same as prior period, unchanged from 0001730168-18-000039:mdna:77]

[0001730168-19-000036:mdna:53]
[same as prior period, unchanged from 0001730168-18-000039:mdna:78]

[0001730168-19-000036:mdna:54]
Our primary sources of liquidity as of February 3, 2019 consisted of: (i) $5,093 million in cash and cash equivalents, (ii) cash we expect to generate from operations, and (iii) our outstanding revolving credit facility of up to $5,000 million aggregate principal amount, or the Revolving Facility. In addition, we may also generate cash from the sale of assets from time to time.

[0001730168-19-000036:mdna:55]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) stock repurchases, if any, (v) cash dividend payments (if and when declared by our Board of Directors), (vi) interest and principal payments related to outstanding indebtedness and (vii) payment of income taxes, including taxes resulting from the intercompany transfer of IP. Beginning in April 2018, we settle withholding tax amounts due upon vesting of compensatory equity awards using cash on hand, and withhold from the grant recipient that number of shares having a value equivalent to the withholding tax amount, referred to as the Tax Shares. This net settlement method reduces the dilutive effects of such awards as they vest. Previously, Tax Shares were issued and mandatorily sold into the market, and the cash proceeds were used to pay such withholding tax amounts. This change results in an increased use of our cash, particularly in the second quarter of each fiscal year when the majority of our outstanding equity awards vest. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-19-000036:mdna:56]
We expect our capital expenditures for fiscal year 2019 will be lower than fiscal year 2018. We believe that our cash and cash equivalents on hand and cash flows from operations, combined with current borrowing availability under the Revolving Facility, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-19-000036:mdna:57]
[same as prior period, unchanged from 0001730168-18-000039:mdna:84]

[0001730168-19-000036:mdna:58]
[same as prior period, unchanged from 0001730168-18-000039:mdna:85]

[0001730168-19-000036:mdna:59]
Working capital decreased to $2,255 million at February 3, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-19-000036:mdna:60]
| • | Current portion of long-term debt increased $3,537 million due to certain debt instruments becoming due within the next twelve months. |

[0001730168-19-000036:mdna:61]
| • | Other current liabilities increased to $3,611 million at February 3, 2019 from $812 million at November 4, 2018, primarily due to liabilities assumed in the CA Merger and increases in notional pooling liabilities and taxes payable. The increase was partially offset by interest payments for our long-term debt. |

[0001730168-19-000036:mdna:62]
[same as prior period, unchanged from 0001730168-18-000039:mdna:90]

[0001730168-19-000036:mdna:63]
| • | Cash and cash equivalents increased to $5,093 million at February 3, 2019 from $4,292 million at November 4, 2018, primarily due to $17,896 million in proceeds from the 2019 Term Loans, $2,132 million in net cash provided by operating activities and $957 million in proceeds from the sale of Veracode, partially offset by $16,027 million paid |

[0001730168-19-000036:mdna:64]
for the CA Merger, $3,436 million of common stock repurchases and $1,067 million of dividend payments.

[0001730168-19-000036:mdna:65]
| • | Other current assets increased to $760 million at February 3, 2019 from $366 million at November 4, 2018, primarily due to assets assumed in the CA Merger and an increase in taxes receivable. |

[0001730168-19-000036:mdna:66]
| • | Accounts receivable increased to $3,677 million at February 3, 2019 from $3,325 million at November 4, 2018 primarily due to revenue linearity and an increase due to the CA Merger. |

[0001730168-19-000036:mdna:67]
| • | Employee compensation and benefits decreased to $463 million at February 3, 2019 from $715 million at November 4, 2018 primarily due to timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger. |

[0001730168-19-000036:mdna:68]
| • | Accounts payable decreased to $738 million at February 3, 2019 from $811 million at November 4, 2018 primarily due to timing of vendor payments, partially offset by increases due to the CA Merger. |

[0001730168-19-000036:mdna:69]
Working capital decreased to $9,250 million at February 4, 2018 from $13,294 million at October 29, 2017. The decrease was attributable to the following:

[0001730168-19-000036:mdna:70]
| • | Our cash and cash equivalents decreased to $7,076 million at February 4, 2018 from $11,204 million at October 29, 2017, due to $4,786 million paid for the acquisition of Brocade Communications Systems, Inc. or Brocade, $856 million of debt repayment, $755 million of dividend and distribution payments, partially offset by $1,685 million in net cash provided by operating activities and $782 million in proceeds from sales of businesses. |

[0001730168-19-000036:mdna:71]
| • | Other current assets decreased to $394 million at February 4, 2018 from $724 million at October 29, 2017, primarily due to a utilization of prepaid taxes. |

[0001730168-19-000036:mdna:72]
| • | Inventory decreased to $1,291 million at February 4, 2018 from $1,447 million at October 29, 2017, primarily due to the timing of a major customer's new handset ramp. |

[0001730168-19-000036:mdna:73]
These decreases in working capital were offset in part by the following:

[0001730168-19-000036:mdna:74]
| • | Employee compensation and benefits decreased to $333 million at February 4, 2018 from $626 million at October 29, 2017 primarily due to timing of employee bonus plan payments, partially offset by increases due to the acquisition of Brocade. |

[0001730168-19-000036:mdna:75]
| • | Accounts payable decreased to $816 million at February 4, 2018 from $1,105 million at October 29, 2017 primarily due to timing of vendor payments, partially offset by increases due to the acquisition of Brocade. |

[0001730168-19-000036:mdna:76]
[same as prior period, unchanged from 0001730168-18-000039:mdna:101]

[0001730168-19-000036:mdna:77]
In April 2018, our Board of Directors authorized the repurchase of up to $12 billion of our common stock from time to time on or prior to November 3, 2019, the end of our fiscal year 2019. On December 5, 2018, our Board of Directors authorized an increase to the stock repurchase program to a total of $18 billion of our common stock on or prior to the end of our fiscal year 2019.

[0001730168-19-000036:mdna:78]
In the fiscal quarter ended February 3, 2019, we repurchased and retired approximately 14 million shares of our common stock at a weighted average price of $246.64 under this stock repurchase program. As of February 3, 2019, $7,306 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000036:mdna:79]
[same as prior period, unchanged from 0001730168-18-000039:mdna:103]

[0001730168-19-000036:mdna:80]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 2.65 |  |  | $ | 1.75 |  |
| Cash dividends and distributions paid |  | $ | 1,067 |  |  | $ | 755 |  |
| Stock repurchases |  | $ | 3,436 |  |  | $ | — |  |

[0001730168-19-000036:mdna:81]
In addition, during the fiscal quarter ended February 3, 2019, we paid $77 million in employee withholding taxes due upon the vesting of, and related to net settled equity awards. We withheld approximately 0.3 million shares from employees in connection with such net share settlement.

[0001730168-19-000036:mdna:82]
[same as prior period, unchanged from 0001730168-18-000039:mdna:105]

[0001730168-19-000036:mdna:83]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |  | February 4, 2018 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 2,132 |  |  | $ | 1,685 |  |
| Net cash used in investing activities |  | (15,193 | ) |  | (4,227 | ) |
| Net cash provided by (used in) financing activities |  | 13,862 |  |  | (1,586 | ) |
| Net change in cash and cash equivalents |  | $ | 801 |  |  | $ | (4,128 | ) |

[0001730168-19-000036:mdna:84]
[same as prior period, unchanged from 0001730168-18-000039:mdna:108]

[0001730168-19-000036:mdna:85]
Cash provided by operating activities primarily consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. The $447 million increase in cash provided by operations during the fiscal quarter ended February 3, 2019 compared to the fiscal quarter ended February 4, 2018 was due to the impact of net income and changes in assets and liabilities, partially offset by adjustments for non-cash items. Net income in each period reflects significant non-cash benefits from income taxes. For the fiscal quarter ended February 3, 2019, the non-cash income tax benefit of $379 million principally resulted from the recognition of uncertain tax benefits due to audit settlements and lapses of statutes of limitations as well as the release of a portion of our valuation allowance as a result of the CA Merger. The non-cash income tax benefit for the fiscal quarter ended February 4, 2018 principally resulted from the enactment of the 2017 Tax Reform Act. These non-cash benefits are included in the deferred taxes and other non-cash taxes line in the condensed consolidated statement of cash flows. Other non-cash adjustments to net income during the fiscal quarter ended February 3, 2019, as compared to the fiscal quarter ended February 4, 2018, primarily included increases in amortization of intangible assets, stock-based compensation and restructuring charges. In addition, cash provided by operating activities in each period was affected by changes in working capital, as discussed above.

[0001730168-19-000036:mdna:86]
[same as prior period, unchanged from 0001730168-18-000039:mdna:110]

[0001730168-19-000036:mdna:87]
Cash used in investing activities primarily consisted of cash used for acquisitions, capital expenditures and investments, partially offset by proceeds from sales of businesses and assets. The $10,966 million increase in cash used in investing activities during the fiscal quarter ended February 3, 2019 compared to the fiscal quarter ended February 4, 2018 was primarily related to $16,027 million paid for the CA Merger in the fiscal quarter ended February 3, 2019 compared to $4,786 million paid for the acquisition of Brocade in the fiscal quarter ended February 4, 2018, partially offset by an increase of $175 million in proceeds from sales of businesses and a $121 million decrease in capital expenditures.

[0001730168-19-000036:mdna:88]
[same as prior period, unchanged from 0001730168-18-000039:mdna:112]

[0001730168-19-000036:mdna:89]
Cash from financing activities primarily consisted of net proceeds and payments related to our long-term-debt, dividend and distribution payments, stock repurchases, and the issuance of common stock pursuant to our employee equity incentive award plans. Cash provided by financing activities for the fiscal quarter ended February 3, 2019 was $13,862 million, which primarily included $17,896 million of net proceeds from our 2019 Term Loan borrowings, partially offset by common stock repurchases of $3,436 million and dividend payments of $1,067 million. Cash used in financing activities for the fiscal quarter ended February 4, 2018 was $1,586 million primarily due to debt repayments of $856 million and $755 million in dividend and distribution payments.

[0001730168-19-000036:mdna:90]
[same as prior period, unchanged from 0001730168-18-000039:mdna:114]

[0001730168-19-000036:mdna:91]
2019 Term Loans and Assumed CA Senior Notes

[0001730168-19-000036:mdna:92]
In connection with the CA Merger, we entered into a credit agreement, or the 2019 Credit Agreement, which provides for a $9,000 million unsecured term A-3 facility and a $9,000 million unsecured term A-5 facility, collectively referred to as the 2019 Term Loans, under which Broadcom is the borrower. Interest on our 2019 Term Loans is based on a floating-rate and is payable monthly. Broadcom’s obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation, or BRCM, Broadcom Cayman Finance Limited and Broadcom Technologies Inc., or BTI, with a residual guarantee being provided by Broadcom-Singapore until its pending voluntary liquidation is finalized. In order to further simplify our internal corporate structure, during the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore, referred to as the Winding Up. As part of the Winding Up, Broadcom-Singapore transferred

[0001730168-19-000036:mdna:93]
substantially all of its assets (including all of the shares of BRCM and Broadcom Cayman Finance Limited) to BTI. Broadcom-Singapore’s remaining net assets as of the date hereof are de minimis, and its residual guarantee under the 2019 Credit Agreement will remain in effect as a technical matter until its statutory dissolution, which we expect to take place during our fiscal quarter ending August 4, 2019. In connection with the Winding Up, BTI became a guarantor under the 2019 Credit Agreement.

[0001730168-19-000036:mdna:94]
The 2019 Credit Agreement also provides for a five-year $5,000 million unsecured revolving credit facility, or the Revolving Facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit reduces the aggregate amount otherwise available under the Revolving Facility for the making of revolving loans. Subject to the terms of the 2019 Credit Agreement, we may borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023, or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on February 3, 2019.

[0001730168-19-000036:mdna:95]
Additionally, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes, or the Assumed CA Senior Notes. CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

[0001730168-19-000036:mdna:96]
2017 Senior Notes

[0001730168-19-000036:mdna:97]
During our fiscal year ended October 29, 2017, BRCM and Broadcom Cayman Finance Limited issued $17,550 million of senior unsecured notes, or the 2017 Senior Notes. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom and Broadcom-Singapore. In connection with the Winding Up, pursuant to the terms of the indentures governing the 2017 Senior Notes, we added BTI as a guarantor of the 2017 Senior Notes and Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes.

[0001730168-19-000036:mdna:98]
See Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q for additional information related to our indebtedness.

[0001730168-19-000036:mdna:99]
[same as prior period, unchanged from 0001730168-18-000039:mdna:116]

[0001730168-19-000036:mdna:100]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000036:mdna:101]
[same as prior period, unchanged from 0001730168-18-000039:mdna:118]

[0001730168-19-000036:mdna:102]
We had no material off-balance sheet arrangements at February 3, 2019 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-19-000036:mdna:103]
[same as prior period, unchanged from 0001730168-18-000039:mdna:120]

[0001730168-19-000036:mdna:104]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000036:mdna:105]
[same as prior period, unchanged from 0001730168-18-000039:mdna:122]

[0001730168-19-000036:mdna:106]
[same as prior period, unchanged from 0001730168-18-000039:mdna:123]
