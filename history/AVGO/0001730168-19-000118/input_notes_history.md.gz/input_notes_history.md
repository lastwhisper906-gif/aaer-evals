# AVGO note change history — 0001730168-19-000101 → 0001730168-19-000118


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:1]
The following table summarizes contractual obligations and commitments as of August 4, 2019 that materially changed from the end of fiscal year 2018:
  (was, 2019-06-14, similarity 0.9751):
[0001730168-19-000101:note_history:1]
The following table summarizes contractual obligations and commitments as of May 5, 2019 that materially changed from the end of fiscal year 2018:

- added (2019-09-13):
[0001730168-19-000118:note_history:2]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 4, 2019.

- changed (2019-09-13):
[0001730168-19-000118:note_history:3]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.
  (was, 2019-06-14, similarity 0.6916):
[0001730168-19-000101:note_history:3]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including

- added (2019-09-13):
[0001730168-19-000118:note_history:4]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $61 million and $187 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Rent expense was $51 million and $178 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively.

- changed (2019-09-13):
[0001730168-19-000118:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 4, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,361 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 4, 2019 have been excluded from the contractual obligations table above.
  (was, 2019-06-14, similarity 0.9816):
[0001730168-19-000101:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 5, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 5, 2019 have been excluded from the contractual obligations table above.

- added (2019-09-13):
[0001730168-19-000118:note_history:6]
As of August 4, 2019 and November 4, 2018, we had standby letters of credit of $65 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- changed (2019-09-13):
[0001730168-19-000118:note_history:7]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On August 6, 2019, the U.S. Central District Court issued an order setting the briefing schedule for defendants’ motion to dismiss. We believe these claims are all without merit and intend to vigorously defend these actions.
  (was, 2019-06-14, similarity 0.9494):
[0001730168-19-000101:note_history:7]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth

- removed (2019-09-13):
[0001730168-19-000101:note_history:8]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on borrowings under the 2019 Senior Notes, Commercial Paper, term A-5 facility, Revolving Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our term A-5 facility, which was subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 5, 2019.

- removed (2019-09-13):
[0001730168-19-000101:note_history:9]
fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

- removed (2019-09-13):
[0001730168-19-000101:note_history:10]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $59 million and $126 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Rent expense was $56 million and $127 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively.

- removed (2019-09-13):
[0001730168-19-000101:note_history:11]
As of May 5, 2019 and November 4, 2018, we had standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- removed (2019-09-13):
[0001730168-19-000101:note_history:12]
Circuit Court remanded the case back to the U.S. Central District Court. We believe these claims are all without merit and intend to vigorously defend these actions.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:13]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Pte. Ltd. (formerly Broadcom Limited), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom eliminating their noncontrolling interest. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. We deregistered the Partnership and liquidated Broadcom-Singapore.
  (was, 2019-06-14, similarity 0.8916):
[0001730168-19-000101:note_history:13]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

- changed (2019-09-13):
[0001730168-19-000118:note_history:14]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ended on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.
  (was, 2019-06-14, similarity 0.997):
[0001730168-19-000101:note_history:14]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.

- changed (2019-09-13):
[0001730168-19-000118:note_history:15]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 4, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.
  (was, 2019-06-14, similarity 0.9928):
[0001730168-19-000101:note_history:15]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 5, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.

- changed (2019-09-13):
[0001730168-19-000118:note_history:16]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statements of operations and condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.
  (was, 2019-06-14, similarity 0.9049):
[0001730168-19-000101:note_history:16]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of operations and statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.

- changed (2019-09-13):
[0001730168-19-000118:note_history:17]
In the first quarter of fiscal year 2019, we adopted the FASB guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and three fiscal quarters ended August 4, 2019, we also recognized $28 million and $95 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.
  (was, 2019-06-14, similarity 0.992):
[0001730168-19-000101:note_history:17]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and two fiscal quarters ended May 5, 2019, we also recognized $40 million and $67 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.

- added (2019-09-13):
[0001730168-19-000118:note_history:18]
In February 2016, the FASB issued guidance related to the accounting for leases, which principally requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. We will adopt this guidance using the optional transition method and will not restate comparative prior periods. We are finalizing the implementation of related systems, policies, processes and internal controls to comply with this guidance. Based on our lease portfolio as of August 4, 2019, we expect the adoption of the new leasing guidance to result in recognition of right-of-use assets and corresponding liabilities on our condensed consolidated balance sheet within a range of $500 million to $600 million, primarily related to real estate. However, the actual impact will depend on our lease portfolio as of the adoption date.

- removed (2019-09-13):
[0001730168-19-000101:note_history:19]
In February 2016, the FASB issued guidance related to the accounting for leases, which among other things, requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. The new guidance is required to be applied using a modified retrospective approach. We are evaluating the impact this guidance will have on our condensed consolidated financial statements.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:20]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:
  (was, 2019-06-14, similarity 0.956):
[0001730168-19-000101:note_history:20]
The future scheduled principal payments of debt as of May 5, 2019 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:21]
|  |  | Effective Interest Rate |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due May 2022 |  | 3.683 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.729 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.820 | % |  | 2,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.855 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (294 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 37,565 |  |  | $ | 17,493 |  |
  (was, 2019-06-14, similarity 0.6636):
[0001730168-19-000101:note_history:21]
|  |  | Effective Interest Rate |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through November 2023 |  | 3.852 | % |  | 6,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 0.289 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (311 | ) |  | (116 | ) |
| Total Debt |  |  |  | $ | 37,548 |  |  | $ | 17,493 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:22]
(a) Represents the weighted average interest rate on outstanding commercial paper as of August 4, 2019.
  (was, 2019-06-14, similarity 0.9637):
[0001730168-19-000101:note_history:22]
(a) Represents the weighted average interest rate on outstanding commercial paper as of May 5, 2019.

- changed (2019-09-13):
[0001730168-19-000118:note_history:23]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.
  (was, 2019-06-14, similarity 0.693):
[0001730168-19-000101:note_history:23]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and Broadcom Technologies Inc. Each series of our 2019 Senior Notes pay interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase.

- added (2019-09-13):
[0001730168-19-000118:note_history:24]
2019 Term Loans

- added (2019-09-13):
[0001730168-19-000118:note_history:25]
In November 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- added (2019-09-13):
[0001730168-19-000118:note_history:26]
On May 7, 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- added (2019-09-13):
[0001730168-19-000118:note_history:27]
Revolving Facility

- added (2019-09-13):
[0001730168-19-000118:note_history:28]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on August 4, 2019.

- added (2019-09-13):
[0001730168-19-000118:note_history:29]
Commercial Paper

- changed (2019-09-13):
[0001730168-19-000118:note_history:30]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of August 4, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.
  (was, 2019-06-14, similarity 0.8756):
[0001730168-19-000101:note_history:30]
In February 2019, we also established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available for general corporate purposes under the Revolving Facility. As of May 5, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they were supported by the Revolving Facility. These borrowings are now supported by our new revolving credit facility discussed below. As such, we have recorded Commercial Paper, net of discount, as long-term debt.

- changed (2019-09-13):
[0001730168-19-000118:note_history:31]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.
  (was, 2019-06-14, similarity 0.9612):
[0001730168-19-000101:note_history:31]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- changed (2019-09-13):
[0001730168-19-000118:note_history:32]
As of August 4, 2019, the estimated aggregate fair value of debt was $37,934 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2019-06-14, similarity 0.9674):
[0001730168-19-000101:note_history:32]
As of May 5, 2019, the estimated aggregate fair value of debt was $37,331 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our term A-5 facility approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2019-09-13):
[0001730168-19-000118:note_history:33]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:
  (was, 2019-06-14, similarity 0.956):
[0001730168-19-000101:note_history:33]
The future scheduled principal payments of debt as of May 5, 2019 were as follows:

- changed (2019-09-13):
[0001730168-19-000118:note_history:34]
As of August 4, 2019 and November 4, 2018, we accrued interest payable of $208 million and $165 million, respectively and were in compliance with all debt covenants.
  (was, 2019-06-14, similarity 0.9767):
[0001730168-19-000101:note_history:34]
As of May 5, 2019 and November 4, 2018, we accrued interest payable of $244 million and $165 million, respectively and were in compliance with all debt covenants.

- added (2019-09-13):
[0001730168-19-000118:note_history:35]
Pending Financing Arrangement
In connection with the Symantec Purchase Agreement, we entered into a commitment letter, with certain financial institutions to provide (i) up to $12 billion in term loans to fund the Symantec Asset Purchase and (ii) $3.5 billion in term loans to refinance certain existing senior notes maturing in the first quarter of our fiscal year 2020 (which begins on November 4, 2019).

- removed (2019-09-13):
[0001730168-19-000101:note_history:36]
Fiscal Year 2019 Financing Arrangements

- removed (2019-09-13):
[0001730168-19-000101:note_history:37]
In connection with the CA Merger, we entered into a credit agreement (the “2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “2019 Term Loans”. Interest on our 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the 2019 Credit Agreement were guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”), Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee having been provided by Broadcom-Singapore  pending its voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019).

- removed (2019-09-13):
[0001730168-19-000101:note_history:38]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we were permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on May 5, 2019.

- removed (2019-09-13):
[0001730168-19-000101:note_history:39]
We used the net proceeds from the 2019 Senior Notes and Commercial Paper to repay $12 billion of our 2019 Term Loans, including all of our term A-3 facility. As a result of our repayment of the 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense on the condensed consolidated statements of operations. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes and Commercial Paper is amortized to interest expense over the respective terms of these borrowings. The unamortized discount and debt issuance costs balance on the 2019 Term Loans as of the modification date will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- removed (2019-09-13):
[0001730168-19-000101:note_history:40]
On May 7, 2019, we entered into a new credit agreement, which provides for a $5 billion unsecured revolving credit facility, a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility. This new credit agreement has substantially the same terms and conditions as the 2019 Credit Agreement, other than with respect to the maturity date of the facilities. The proceeds of the term A-3, A-5 and A-7 facilities were used to refinance the $6 billion of existing term loans outstanding under the 2019 Credit Agreement, which was terminated in connection with, and as a condition to, entering into the May 7, 2019 credit agreement. Our obligations under this new credit agreement are guaranteed on an unsecured basis by BRCM and Broadcom Technologies Inc.

- removed (2019-09-13):
[0001730168-19-000101:note_history:41]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the “Subsidiary Issuers,” issued $17,550 million of senior unsecured notes (the “2017 Senior Notes”). The 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom (“Parent Guarantor”) and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc. (“Subsidiary Guarantor”), a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes

- removed (2019-09-13):
[0001730168-19-000101:note_history:42]
under each of their respective indentures in accordance with their terms. On May 15, 2019, Broadcom Cayman Finance Limited was merged into the Subsidiary Guarantor, with the Subsidiary Guarantor as the surviving entity.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:43]
|  |  | Effective Interest Rate |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due May 2022 |  | 3.683 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.729 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.820 | % |  | 2,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.855 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (294 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 37,565 |  |  | $ | 17,493 |  |
  (was, 2019-06-14, similarity 0.6636):
[0001730168-19-000101:note_history:43]
|  |  | Effective Interest Rate |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through November 2023 |  | 3.852 | % |  | 6,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 0.289 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (311 | ) |  | (116 | ) |
| Total Debt |  |  |  | $ | 37,548 |  |  | $ | 17,493 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:44]
(a) Represents the weighted average interest rate on outstanding commercial paper as of August 4, 2019.
  (was, 2019-06-14, similarity 0.9637):
[0001730168-19-000101:note_history:44]
(a) Represents the weighted average interest rate on outstanding commercial paper as of May 5, 2019.

- added (2019-09-13):
[0001730168-19-000118:note_history:45]
2019 Senior Notes

- added (2019-09-13):
[0001730168-19-000118:note_history:46]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.

- added (2019-09-13):
[0001730168-19-000118:note_history:47]
2019 Term Loans

- added (2019-09-13):
[0001730168-19-000118:note_history:48]
In November 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- added (2019-09-13):
[0001730168-19-000118:note_history:49]
On May 7, 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- added (2019-09-13):
[0001730168-19-000118:note_history:50]
Revolving Facility

- added (2019-09-13):
[0001730168-19-000118:note_history:51]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on August 4, 2019.

- added (2019-09-13):
[0001730168-19-000118:note_history:52]
Commercial Paper

- added (2019-09-13):
[0001730168-19-000118:note_history:53]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of August 4, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.

- added (2019-09-13):
[0001730168-19-000118:note_history:54]
Assumed CA Senior Notes

- added (2019-09-13):
[0001730168-19-000118:note_history:55]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- added (2019-09-13):
[0001730168-19-000118:note_history:56]
Fair Value of Debt

- added (2019-09-13):
[0001730168-19-000118:note_history:57]
As of August 4, 2019, the estimated aggregate fair value of debt was $37,934 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- added (2019-09-13):
[0001730168-19-000118:note_history:58]
Future Principal Payments of Debt

- added (2019-09-13):
[0001730168-19-000118:note_history:59]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:60]
|  |  | Fiscal Quarter Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |
  (was, 2019-06-14, similarity 0.6972):
[0001730168-19-000101:note_history:60]
|  |  | Fiscal Quarter Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services* |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:61]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |
  (was, 2019-06-14, similarity 0.6937):
[0001730168-19-000101:note_history:61]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services* |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:62]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.
  (was, 2019-06-14, similarity 0.9821):
[0001730168-19-000101:note_history:62]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:63]
|  |  | Fiscal Quarter Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |
  (was, 2019-06-14, similarity 0.6972):
[0001730168-19-000101:note_history:63]
|  |  | Fiscal Quarter Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services* |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:64]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |
  (was, 2019-06-14, similarity 0.6937):
[0001730168-19-000101:note_history:64]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services* |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:65]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.
  (was, 2019-06-14, similarity 0.9821):
[0001730168-19-000101:note_history:65]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

- changed (2019-09-13):
[0001730168-19-000118:note_history:66]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |
  (was, 2019-06-14, similarity 0.9669):
[0001730168-19-000101:note_history:66]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |

- changed (2019-09-13):
[0001730168-19-000118:note_history:67]
(a) We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.
  (was, 2019-06-14, similarity 0.988):
[0001730168-19-000101:note_history:67]
* We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

- changed (2019-09-13):
[0001730168-19-000118:note_history:68]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.
  (was, 2019-06-14, similarity 0.9933):
[0001730168-19-000101:note_history:68]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $144 million.

- changed (2019-09-13):
[0001730168-19-000118:note_history:69]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 4, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.
  (was, 2019-06-14, similarity 0.9924):
[0001730168-19-000101:note_history:69]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 5, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- added (2019-09-13):
[0001730168-19-000118:note_history:70]
We recognize an asset for costs incurred to fulfill a contract that are not within the scope of other accounting literature. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

- changed (2019-09-13):
[0001730168-19-000118:note_history:71]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and three fiscal quarters ended August 4, 2019 or in the condensed consolidated balance sheet as of August 4, 2019 were significantly affected by the new revenue guidance.
  (was, 2019-06-14, similarity 0.9691):
[0001730168-19-000101:note_history:71]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and two fiscal quarters ended May 5, 2019 or in the condensed consolidated balance sheet as of May 5, 2019 were significantly affected by the new revenue guidance.

- added (2019-09-13):
[0001730168-19-000118:note_history:72]
|  |  | Fiscal Quarter Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,413 |  |  | $ | — |  |  | $ | 4,413 |  |
| Subscriptions and services |  | 1,078 |  |  | 24 |  |  | 1,102 |  |
| Total net revenue |  | $ | 5,491 |  |  | $ | 24 |  |  | $ | 5,515 |  |

- added (2019-09-13):
[0001730168-19-000118:note_history:73]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 13,470 |  |  | $ | — |  |  | $ | 13,470 |  |
| Subscriptions and services |  | 3,124 |  |  | 227 |  |  | 3,351 |  |
| Total net revenue |  | $ | 16,594 |  |  | $ | 227 |  |  | $ | 16,821 |  |

- removed (2019-09-13):
[0001730168-19-000101:note_history:74]
When costs are incurred to fulfill a contract that are not within the scope of another accounting literature, we recognize an asset. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

- removed (2019-09-13):
[0001730168-19-000101:note_history:75]
|  |  | Fiscal Quarter Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,418 |  |  | $ | — |  |  | $ | 4,418 |  |
| Subscriptions and services |  | 1,040 |  |  | 59 |  |  | 1,099 |  |
| Total net revenue |  | $ | 5,458 |  |  | $ | 59 |  |  | $ | 5,517 |  |

- removed (2019-09-13):
[0001730168-19-000101:note_history:76]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 9,057 |  |  | $ | — |  |  | $ | 9,057 |  |
| Subscriptions and services |  | 2,046 |  |  | 203 |  |  | 2,249 |  |
| Total net revenue |  | $ | 11,103 |  |  | $ | 203 |  |  | $ | 11,306 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-09-13):
[0001730168-19-000118:note_history:77]
On September 11, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on October 1, 2019 to stockholders of record at the close of business on September 23, 2019.
  (was, 2019-06-14, similarity 0.9003):
[0001730168-19-000101:note_history:77]
On June 12, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on July 2, 2019 to stockholders of record at the close of business on June 24, 2019.
