# AVGO 8-K — 0001193125-19-243919 filed 2019-09-12

## item codes, every 8-K on or before 2019-09-13

- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2019-09-13

- none on or before 2019-09-13

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-243919:8k_2_02:1]
EX-99.1
2
d800073dex991.htm
EX-99.1

[0001193125-19-243919:8k_2_02:2]
EX-99.1

[0001193125-19-243919:8k_2_02:3]
Exhibit 99.1

[0001193125-19-243919:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2019 Financial Results and Quarterly Dividend

[0001193125-19-243919:8k_2_02:5]
|  | • |  | Revenue of $5,515 million for the quarter, up 9 percent from the prior year period |

[0001193125-19-243919:8k_2_02:6]
|  | • |  | GAAP diluted EPS of $1.71; Non-GAAP diluted EPS of $5.16 |

[0001193125-19-243919:8k_2_02:7]
|  | • |  | GAAP operating profit margin of 16 percent; Non-GAAP operating profit margin of 53 percent |

[0001193125-19-243919:8k_2_02:8]
|  | • |  | $2,307 million of free cash flow, defined as cash from operations of $2,419 million less capital expenditures of $112 million, up 8 percent from the prior year period |

[0001193125-19-243919:8k_2_02:9]
|  | • |  | Quarterly dividend of $2.65 per share |

[0001193125-19-243919:8k_2_02:10]
|  | • |  | Repurchased and eliminated 3.5 million shares for $977 million |

[0001193125-19-243919:8k_2_02:11]
|  | • |  | Maintaining fiscal year 2019 guidance, including revenue outlook of $22.5 billion; $17.5 billion from semiconductor solutions and $5 billion from infrastructure software |

[0001193125-19-243919:8k_2_02:12]
SAN
JOSE, Calif. – September 12, 2019 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results
for its third quarter of fiscal year 2019, ended August 4, 2019, and announced a quarterly dividend.

[0001193125-19-243919:8k_2_02:13]
“Our broad portfolio of mission critical
semiconductor and infrastructure software solutions, utilized by the world’s largest enterprises, continued to drive sustained revenues and robust cash flow despite a challenging market backdrop,” said Hock Tan, President and CEO of
Broadcom Inc. “Looking at the semiconductor solutions segment, we believe demand has bottomed out but will continue to remain at these levels due to the current uncertain environment.”

[0001193125-19-243919:8k_2_02:14]
“During the quarter, we generated over $2.3 billion in free cash flow representing over 8% growth on a year on year basis,” said Tom Krause,
CFO of Broadcom Inc. “We returned over $2 billion to stockholders in the quarter including $1.1 billion in cash dividends and approximately $1 billion in share repurchases and eliminations. We remain fully committed to
maintaining our investment grade credit rating and, looking forward, we intend to focus on deleveraging our balance sheet.”

[0001193125-19-243919:8k_2_02:15]
Third Quarter Fiscal
Year 2019 GAAP Results from Continuing Operations

[0001193125-19-243919:8k_2_02:16]
Net revenue was $5,515 million, substantially consistent with $5,517 million in the
previous quarter and 8.9 percent higher than $5,063 million in the same quarter last year.

[0001193125-19-243919:8k_2_02:17]
Gross margin was $3,034 million, or
55.0 percent of net revenue. This compares with gross margin of $3,089 million, or 56.0 percent of net revenue, in the prior quarter, and gross margin of $2,619 million, or 51.7 percent of net revenue, in the same quarter
last year.

[0001193125-19-243919:8k_2_02:18]
1

[0001193125-19-243919:8k_2_02:19]
Operating expenses were $2,169 million. This compares with $2,119 million in the prior quarter and
$1,280 million in the same quarter last year.

[0001193125-19-243919:8k_2_02:20]
Operating income was $865 million, or 15.7 percent of net revenue. This compares with
operating income of $970 million, or 17.6 percent of net revenue, in the prior quarter, and operating income of $1,339 million, or 26.4 percent of net revenue, in the same quarter last year.

[0001193125-19-243919:8k_2_02:21]
Net income, which includes the impact of discontinued operations, was $715 million, or $1.71 per diluted share. This compares with net income of
$691 million, or $1.64 per diluted share, in the prior quarter, and net income of $1,196 million, or $2.71 per diluted share, in the same quarter last year.

[0001193125-19-243919:8k_2_02:22]
Cash from operations was $2,419 million in the quarter, compared to $2,247 million in the same quarter last year.

[0001193125-19-243919:8k_2_02:23]
| Third Quarter Fiscal Year 2019 GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q3 19 |  |  | Q2 19 |  |  | Q3 18 |  |  | Q/Q |  |  | Y/Y |  |
| Net revenue |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,063 |  |  |  | - | % |  |  | +9 | % |
| Gross margin |  |  | 55.0 | % |  |  | 56.0 | % |  |  | 51.7 | % |  |  | -100bps |  |  |  | +330bps |  |
| Operating expenses |  | $ | 2,169 |  |  | $ | 2,119 |  |  | $ | 1,280 |  |  | +$ | 50 |  |  | +$ | 889 |  |
| Net income |  | $ | 715 |  |  | $ | 691 |  |  | $ | 1,196 |  |  | +$ | 24 |  |  | -$ | 481 |  |
| Earnings per share - diluted |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 2.71 |  |  | +$ | 0.07 |  |  | -$ | 1.00 |  |

[0001193125-19-243919:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the third fiscal quarter were $5,462 million, compared to
$5,328 million at the end of the prior quarter.

[0001193125-19-243919:8k_2_02:25]
During the third fiscal quarter, the Company generated $2,419 million in cash from operations
and spent $977 million on share repurchases and eliminations, consisting of $736 million in repurchases of 2.6 million shares and $241 million of withholding tax payments related to net settled equity awards that vested in the
quarter (representing approximately 0.9 million shares withheld), as well as $112 million on capital expenditures.

[0001193125-19-243919:8k_2_02:26]
On July 2, 2019, the
Company paid a cash dividend of $2.65 per share of common stock, totaling $1,057 million.

[0001193125-19-243919:8k_2_02:27]
Third Quarter Fiscal Year 2019 Non-GAAP Results From Continuing Operations

[0001193125-19-243919:8k_2_02:28]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this
release.

[0001193125-19-243919:8k_2_02:29]
Gross margin from continuing operations was $3,916 million, or 71.0 percent of net revenue. This compares with gross margin from
continuing operations of $3,971 million, or 72.0 percent of net revenue, in the prior quarter, and $3,410 million, or 67.3 percent of net revenue, in the same quarter last year.

[0001193125-19-243919:8k_2_02:30]
2

[0001193125-19-243919:8k_2_02:31]
Operating income from continuing operations was $2,910 million, or 52.8 percent of net revenue.
This compares with operating income from continuing operations of $2,949 million, or 53.5 percent of net revenue, in the prior quarter, and $2,536 million, or 50.1 percent of net revenue, in the same quarter last year.

[0001193125-19-243919:8k_2_02:32]
Net income from continuing operations was $2,281 million, or $5.16 per diluted share. This compares with net income of $2,334 million, or $5.21 per
diluted share, in the prior quarter, and net income of $2,257 million, or $4.98 per diluted share, in the same quarter last year.

[0001193125-19-243919:8k_2_02:33]
Free cash flow
from operations, defined as cash from operations less capital expenditures, was $2,307 million in the quarter, compared to $2,127 million in the same quarter last year.

[0001193125-19-243919:8k_2_02:34]
| Third Quarter Fiscal Year 2019 Non-GAAP Results |  | Q3 19 |  |  | Q2 19 |  |  | Q3 18 |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q/Q |  |  | Y/Y |  |
| Gross margin |  |  | 71.0 | % |  |  | 72.0 | % |  |  | 67.3 | % |  |  | -100bps |  |  |  | +370bps |  |
| Operating expenses |  | $ | 1,006 |  |  | $ | 1,022 |  |  | $ | 874 |  |  | -$ | 16 |  |  | +$ | 132 |  |
| Net income |  | $ | 2,281 |  |  | $ | 2,334 |  |  | $ | 2,257 |  |  | -$ | 53 |  |  | +$ | 24 |  |
| Earnings per share - diluted |  | $ | 5.16 |  |  | $ | 5.21 |  |  | $ | 4.98 |  |  | -$ | 0.05 |  |  | +$ | 0.18 |  |

[0001193125-19-243919:8k_2_02:35]
Other Quarterly Data

[0001193125-19-243919:8k_2_02:36]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q3 19 |  |  | Q2 19 |  |  | Q3 18 |  |  | Q/Q |  |  | Y/Y |  |
| Semiconductor solutions |  | $ | 4,353 |  |  |  | 79 | % |  | $ | 4,088 |  |  |  | 74 | % |  | $ | 4,568 |  |  |  | 90 | % |  |  | 6 | % |  |  | -5 | % |
| Infrastructure software |  |  | 1,140 |  |  |  | 21 |  |  |  | 1,413 |  |  |  | 26 |  |  |  | 492 |  |  |  | 10 |  |  |  | -19 | % |  |  | 132 | % |
| Intellectual property licensing |  |  | 22 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 38 | % |  |  | 633 | % |
| Total net revenue |  | $ | 5,515 |  |  |  | 100 | % |  | $ | 5,517 |  |  |  | 100 | % |  | $ | 5,063 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-19-243919:8k_2_02:37]
Fiscal Year 2019 Business Outlook

[0001193125-19-243919:8k_2_02:38]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2019, ending November 3, 2019, including
contributions from CA, is expected to be as follows:

[0001193125-19-243919:8k_2_02:39]
|  |  | GAAP |  |  | Reconciling Items |  |  | Non-GAAP |  |
| Net revenue |  | $ | 22,500M |  |  |  | — |  |  | $ | 22,500M |  |
| Operating margin |  |  | 14.75 | % |  | $ | 8,470M |  |  |  | 52.50 | % |
| Net interest expense and other |  | $ | 1,300M |  |  |  | — |  |  | $ | 1,300M |  |
| Provision for (benefit from) income taxes |  |  | -17.75 | % |  |  | 28.75 | % |  |  | 11.00 | % |

[0001193125-19-243919:8k_2_02:40]
|  | • |  | Non-GAAP operating margin excludes $5,210 million of amortization of acquisition-related intangible assets, $2.2 billion of stock-based compensation expense, $800 million of restructuring charges, and $260 million of acquisition-related costs; and |

[0001193125-19-243919:8k_2_02:41]
3

[0001193125-19-243919:8k_2_02:42]
|  | • |  | Non-GAAP tax provision is 28.75% higher than GAAP due to the tax effects of the projected reconciling items noted above. |

[0001193125-19-243919:8k_2_02:43]
Capital expenditures for the fiscal year are expected to be approximately
$500 million. For the fiscal year, depreciation is expected to be $600 million and total intangible amortization is expected to be approximately $5,235 million.

[0001193125-19-243919:8k_2_02:44]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. Among other things, this guidance
is based on an initial estimate of purchase accounting adjustments and allocations for CA, Inc., all of which may be revised during the remainder of the measurement period (which will not exceed 12 months from the CA acquisition). The guidance
excludes the impact of any future mergers, acquisitions, divestiture and stock repurchase activity that may occur during fiscal year 2019. Actual results will vary from the guidance and the variations may be material. The Company undertakes no
intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-243919:8k_2_02:45]
Quarterly Dividend

[0001193125-19-243919:8k_2_02:46]
The Company’s Board of Directors
has approved a quarterly cash dividend of $2.65 per share.

[0001193125-19-243919:8k_2_02:47]
The dividend is payable on October 1, 2019 to stockholders of record at the close of
business (5:00 p.m. Eastern Time) on September 23, 2019.

[0001193125-19-243919:8k_2_02:48]
Financial Results Conference Call

[0001193125-19-243919:8k_2_02:49]
Broadcom Inc. will host a conference call to review its financial results for the third quarter of fiscal year 2019, ended August 4, 2019, and discuss
guidance for fiscal year 2019, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The
passcode is 8385364. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and
reference the passcode: 8385364. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001193125-19-243919:8k_2_02:50]
Basis of Presentation

[0001193125-19-243919:8k_2_02:51]
Broadcom Inc. is the successor to
Broadcom Limited for financial reporting purposes effective as of the close of trading on April 4, 2018. Information provided for fiscal periods beginning with the fiscal quarter ended May 6, 2018, relates to Broadcom Inc. and for prior
fiscal periods relates to Broadcom Limited. Unless the context otherwise requires, references in this press release to “Broadcom,” “the Company,” “we,” “our,” “us” and similar terms are to Broadcom
Inc. and, prior to that time, are to our predecessor, Broadcom Limited.

[0001193125-19-243919:8k_2_02:52]
4

[0001193125-19-243919:8k_2_02:53]
The Company’s financial results include contributions from CA, Inc.’s continuing operations
starting in the first quarter of fiscal year 2019. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented above, unless
otherwise stated.

[0001193125-19-243919:8k_2_02:54]
Due to the Company’s 52/53 week reporting cycle, fiscal year 2018 included an extra week in the first quarter, compared to fiscal
year 2019.

[0001193125-19-243919:8k_2_02:55]
Non-GAAP Financial Measures

[0001193125-19-243919:8k_2_02:56]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash
flow and other data on a non-GAAP basis. This non-GAAP information includes the effect, where applicable, of purchase accounting on revenue, and excludes amortization of
acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements,
impairment on investment, debt-related costs, gain (loss) on extinguishment of debt, gains (losses) on investments, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments.
Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of
evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models,
strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and
other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual. Free
cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash
flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-19-243919:8k_2_02:57]
Broadcom believes this non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s
on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a substitute for, or
superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press
release.

[0001193125-19-243919:8k_2_02:58]
5

[0001193125-19-243919:8k_2_02:59]
About Broadcom Inc.

[0001193125-19-243919:8k_2_02:60]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad
range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our
solutions include data center networking and storage, enterprise and mainframe software focused on automation, monitoring and security, smartphone components, telecoms and factory automation.

[0001193125-19-243919:8k_2_02:61]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-19-243919:8k_2_02:62]
Particular uncertainties that could
materially affect future results include risks associated with: any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain;
global economic conditions and concerns; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired
businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions, including our pending Symantec Corporation transaction; government regulations and trade restrictions; our
ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks
associated with distributors of our products; dependence on senior management and our ability to attract and retain qualified personnel; international political and economic conditions; involvement in legal or administrative proceedings; our
dependency on a limited number of suppliers; quarterly and annual fluctuations in operating results; cyclicality in the semiconductor industry or in our

[0001193125-19-243919:8k_2_02:63]
6

[0001193125-19-243919:8k_2_02:64]
target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our
contract manufacturers’ manufacturing facilities or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their
ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with
operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code
sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; our ability to sell to new types of customers and to keep pace with technological advances; market
acceptance of the end products into which our products are designed; our ability to protect against a breach of security systems; changes in accounting standards; fluctuations in foreign exchange rates; the amount and frequency of our stock
repurchases; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional
and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001193125-19-243919:8k_2_02:65]
Our filings with the SEC, which you may obtain
for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no
intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-243919:8k_2_02:66]
Contact:

[0001193125-19-243919:8k_2_02:67]
Broadcom Inc.

[0001193125-19-243919:8k_2_02:68]
Beatrice F. Russotto

[0001193125-19-243919:8k_2_02:69]
Investor Relations

[0001193125-19-243919:8k_2_02:70]
408-433-8000

[0001193125-19-243919:8k_2_02:71]
investor.relations@broadcom.com

[0001193125-19-243919:8k_2_02:72]
BROADCOM INC.

[0001193125-19-243919:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-19-243919:8k_2_02:74]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-19-243919:8k_2_02:75]
|  |  | Fiscal Quarter Ended |  |  | Three Fiscal Quarters Ended |  |
|  |  | August 4, |  |  | May 5, |  |  | August 5, |  |  | August 4, |  |  | August 5, |  |
|  |  | 2019 |  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net revenue |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,063 |  |  | $ | 16,821 |  |  | $ | 15,404 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,651 |  |  |  | 1,592 |  |  |  | 1,680 |  |  |  | 4,935 |  |  |  | 5,275 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 828 |  |  |  | 826 |  |  |  | 762 |  |  |  | 2,487 |  |  |  | 2,242 |  |
| Restructuring charges |  |  | 2 |  |  |  | 10 |  |  |  | 2 |  |  |  | 68 |  |  |  | 19 |  |
| Total cost of revenue |  |  | 2,481 |  |  |  | 2,428 |  |  |  | 2,444 |  |  |  | 7,490 |  |  |  | 7,606 |  |
| Gross margin |  |  | 3,034 |  |  |  | 3,089 |  |  |  | 2,619 |  |  |  | 9,331 |  |  |  | 7,798 |  |
| Research and development |  |  | 1,235 |  |  |  | 1,151 |  |  |  | 959 |  |  |  | 3,519 |  |  |  | 2,820 |  |
| Selling, general and administrative |  |  | 410 |  |  |  | 419 |  |  |  | 234 |  |  |  | 1,300 |  |  |  | 819 |  |
| Amortization of acquisition-related intangible assets |  |  | 475 |  |  |  | 473 |  |  |  | 68 |  |  |  | 1,424 |  |  |  | 474 |  |
| Restructuring, impairment and disposal charges |  |  | 49 |  |  |  | 76 |  |  |  | 19 |  |  |  | 698 |  |  |  | 202 |  |
| Total operating expenses |  |  | 2,169 |  |  |  | 2,119 |  |  |  | 1,280 |  |  |  | 6,941 |  |  |  | 4,315 |  |
| Operating income |  |  | 865 |  |  |  | 970 |  |  |  | 1,339 |  |  |  | 2,390 |  |  |  | 3,483 |  |
| Interest expense |  |  | (362 | ) |  |  | (376 | ) |  |  | (149 | ) |  |  | (1,083 | ) |  |  | (480 | ) |
| Other income, net |  |  | 41 |  |  |  | 63 |  |  |  | 39 |  |  |  | 172 |  |  |  | 120 |  |
| Income from continuing operations before income taxes |  |  | 544 |  |  |  | 657 |  |  |  | 1,229 |  |  |  | 1,479 |  |  |  | 3,123 |  |
| Provision for (benefit from) income taxes |  |  | (171 | ) |  |  | (36 | ) |  |  | 32 |  |  |  | (410 | ) |  |  | (8,391 | ) |
| Income from continuing operations |  |  | 715 |  |  |  | 693 |  |  |  | 1,197 |  |  |  | 1,889 |  |  |  | 11,514 |  |
| Loss from discontinued operations, net of income taxes |  |  | — |  |  |  | (2 | ) |  |  | (1 | ) |  |  | (12 | ) |  |  | (19 | ) |
| Net income |  |  | 715 |  |  |  | 691 |  |  |  | 1,196 |  |  |  | 1,877 |  |  |  | 11,495 |  |
| Net income attributable to noncontrolling interest (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 715 |  |  | $ | 691 |  |  | $ | 1,196 |  |  | $ | 1,877 |  |  | $ | 11,144 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.80 |  |  | $ | 1.75 |  |  | $ | 2.78 |  |  | $ | 4.73 |  |  | $ | 26.58 |  |
| Loss per share from discontinued operations |  |  | — |  |  |  | (0.01 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | (0.05 | ) |
| Net income per share |  | $ | 1.80 |  |  | $ | 1.74 |  |  | $ | 2.78 |  |  | $ | 4.70 |  |  | $ | 26.53 |  |
| Diluted income per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 2.71 |  |  | $ | 4.50 |  |  | $ | 25.78 |  |
| Loss per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |  |  | (0.04 | ) |
| Net income per share |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 2.71 |  |  | $ | 4.47 |  |  | $ | 25.74 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 398 |  |  |  | 397 |  |  |  | 430 |  |  |  | 399 |  |  |  | 420 |  |
| Diluted |  |  | 418 |  |  |  | 422 |  |  |  | 441 |  |  |  | 420 |  |  |  | 433 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 47 |  |  | $ | 41 |  |  | $ | 22 |  |  | $ | 122 |  |  | $ | 63 |  |
| Research and development |  |  | 456 |  |  |  | 371 |  |  |  | 222 |  |  |  | 1,138 |  |  |  | 630 |  |
| Selling, general and administrative |  |  | 129 |  |  |  | 132 |  |  |  | 71 |  |  |  | 381 |  |  |  | 217 |  |
| Total stock-based compensation expense |  | $ | 632 |  |  | $ | 544 |  |  | $ | 315 |  |  | $ | 1,641 |  |  | $ | 910 |  |

[0001193125-19-243919:8k_2_02:76]
| (1) | In connection with the redomiciliation to the United States on April 4, 2018, or the Redomiciliation, all outstanding exchangeable limited partnership units, or LP Units, in Broadcom Cayman L.P. were exchanged for common stock of Broadcom on a one-for-one basis and the noncontrolling interest, or NCI, was eliminated. Net income attributable to NCI prior to the Redomiciliation represents approximately 5% of net income attributable to LP Units. |

[0001193125-19-243919:8k_2_02:77]
| (2) | There were no LP Units outstanding during the fiscal quarters ended August 4, 2019, May 5, 2019, August 5, 2018 or three fiscal quarters ended August 4, 2019 due to the Redomiciliation. The diluted income per share calculations excluded the LP Units for the three fiscal quarters ended August 5, 2018 as the impact was antidilutive. |

[0001193125-19-243919:8k_2_02:78]
BROADCOM INC.

[0001193125-19-243919:8k_2_02:79]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-19-243919:8k_2_02:80]
(IN MILLIONS)

[0001193125-19-243919:8k_2_02:81]
|  |  | Fiscal Quarter Ended |  |  | Three Fiscal Quarters Ended |  |
|  |  | August 4,2019 |  |  | May 5,2019 |  |  | August 5,2018 |  |  | August 4,2019 |  |  | August 5,2018 |  |
| Net revenue on GAAP basis |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,063 |  |  | $ | 16,821 |  |  | $ | 15,404 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |
| Net revenue on non-GAAP basis |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,066 |  |  | $ | 16,821 |  |  | $ | 15,414 |  |
| Gross margin on GAAP basis |  | $ | 3,034 |  |  | $ | 3,089 |  |  | $ | 2,619 |  |  | $ | 9,331 |  |  | $ | 7,798 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 828 |  |  |  | 826 |  |  |  | 762 |  |  |  | 2,487 |  |  |  | 2,242 |  |
| Stock-based compensation expense |  |  | 47 |  |  |  | 41 |  |  |  | 22 |  |  |  | 122 |  |  |  | 63 |  |
| Restructuring charges |  |  | 2 |  |  |  | 10 |  |  |  | 2 |  |  |  | 68 |  |  |  | 19 |  |
| Acquisition-related costs |  |  | 5 |  |  |  | 5 |  |  |  | 2 |  |  |  | 12 |  |  |  | 4 |  |
| Gross margin on non-GAAP basis |  | $ | 3,916 |  |  | $ | 3,971 |  |  | $ | 3,410 |  |  | $ | 12,020 |  |  | $ | 10,206 |  |
| Research and development on GAAP basis |  | $ | 1,235 |  |  | $ | 1,151 |  |  | $ | 959 |  |  | $ | 3,519 |  |  | $ | 2,820 |  |
| Stock-based compensation expense |  |  | 456 |  |  |  | 371 |  |  |  | 222 |  |  |  | 1,138 |  |  |  | 630 |  |
| Acquisition-related costs |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |  | 4 |  |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 778 |  |  | $ | 779 |  |  | $ | 737 |  |  | $ | 2,377 |  |  | $ | 2,187 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 410 |  |  | $ | 419 |  |  | $ | 234 |  |  | $ | 1,300 |  |  | $ | 819 |  |
| Stock-based compensation expense |  |  | 129 |  |  |  | 132 |  |  |  | 71 |  |  |  | 381 |  |  |  | 217 |  |
| Acquisition-related costs |  |  | 53 |  |  |  | 44 |  |  |  | 26 |  |  |  | 187 |  |  |  | 145 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 228 |  |  | $ | 243 |  |  | $ | 137 |  |  | $ | 732 |  |  | $ | 457 |  |
| Total operating expenses on GAAP basis |  | $ | 2,169 |  |  | $ | 2,119 |  |  | $ | 1,280 |  |  | $ | 6,941 |  |  | $ | 4,315 |  |
| Amortization of acquisition-related intangible assets |  |  | 475 |  |  |  | 473 |  |  |  | 68 |  |  |  | 1,424 |  |  |  | 474 |  |
| Stock-based compensation expense |  |  | 585 |  |  |  | 503 |  |  |  | 293 |  |  |  | 1,519 |  |  |  | 847 |  |
| Restructuring, impairment and disposal charges |  |  | 49 |  |  |  | 76 |  |  |  | 19 |  |  |  | 698 |  |  |  | 202 |  |
| Acquisition-related costs |  |  | 54 |  |  |  | 45 |  |  |  | 26 |  |  |  | 191 |  |  |  | 148 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,006 |  |  | $ | 1,022 |  |  | $ | 874 |  |  | $ | 3,109 |  |  | $ | 2,644 |  |
| Operating income on GAAP basis |  | $ | 865 |  |  | $ | 970 |  |  | $ | 1,339 |  |  | $ | 2,390 |  |  | $ | 3,483 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,303 |  |  |  | 1,299 |  |  |  | 830 |  |  |  | 3,911 |  |  |  | 2,716 |  |
| Stock-based compensation expense |  |  | 632 |  |  |  | 544 |  |  |  | 315 |  |  |  | 1,641 |  |  |  | 910 |  |
| Restructuring, impairment and disposal charges |  |  | 51 |  |  |  | 86 |  |  |  | 21 |  |  |  | 766 |  |  |  | 221 |  |
| Acquisition-related costs |  |  | 59 |  |  |  | 50 |  |  |  | 28 |  |  |  | 203 |  |  |  | 152 |  |
| Operating income on non-GAAP basis |  | $ | 2,910 |  |  | $ | 2,949 |  |  | $ | 2,536 |  |  | $ | 8,911 |  |  | $ | 7,562 |  |
| Interest expense on GAAP basis |  | $ | (362 | ) |  | $ | (376 | ) |  | $ | (149 | ) |  | $ | (1,083 | ) |  | $ | (480 | ) |
| Debt-related costs |  |  | 2 |  |  |  | 26 |  |  |  | — |  |  |  | 28 |  |  |  | 32 |  |
| Interest expense on non-GAAP basis |  | $ | (360 | ) |  | $ | (350 | ) |  | $ | (149 | ) |  | $ | (1,055 | ) |  | $ | (448 | ) |
| Other income, net on GAAP basis |  | $ | 41 |  |  | $ | 63 |  |  | $ | 39 |  |  | $ | 172 |  |  | $ | 120 |  |
| (Gains) losses on investments |  |  | (28 | ) |  |  | (40 | ) |  |  | 1 |  |  |  | (95 | ) |  |  | (3 | ) |
| Other income, net on non-GAAP basis |  | $ | 13 |  |  | $ | 23 |  |  | $ | 40 |  |  | $ | 77 |  |  | $ | 117 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 544 |  |  | $ | 657 |  |  | $ | 1,229 |  |  | $ | 1,479 |  |  | $ | 3,123 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,303 |  |  |  | 1,299 |  |  |  | 830 |  |  |  | 3,911 |  |  |  | 2,716 |  |
| Stock-based compensation expense |  |  | 632 |  |  |  | 544 |  |  |  | 315 |  |  |  | 1,641 |  |  |  | 910 |  |
| Restructuring, impairment and disposal charges |  |  | 51 |  |  |  | 86 |  |  |  | 21 |  |  |  | 766 |  |  |  | 221 |  |
| Acquisition-related costs |  |  | 59 |  |  |  | 50 |  |  |  | 28 |  |  |  | 203 |  |  |  | 152 |  |
| Debt-related costs |  |  | 2 |  |  |  | 26 |  |  |  | — |  |  |  | 28 |  |  |  | 32 |  |
| (Gains) losses on investments |  |  | (28 | ) |  |  | (40 | ) |  |  | 1 |  |  |  | (95 | ) |  |  | (3 | ) |
| Income before income taxes on non-GAAP basis |  | $ | 2,563 |  |  | $ | 2,622 |  |  | $ | 2,427 |  |  | $ | 7,933 |  |  | $ | 7,231 |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (171 | ) |  | $ | (36 | ) |  | $ | 32 |  |  | $ | (410 | ) |  | $ | (8,391 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 453 |  |  |  | 324 |  |  |  | 138 |  |  |  | 1,282 |  |  |  | 8,777 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 282 |  |  | $ | 288 |  |  | $ | 170 |  |  | $ | 872 |  |  | $ | 386 |  |
| Net income on GAAP basis |  | $ | 715 |  |  | $ | 691 |  |  | $ | 1,196 |  |  | $ | 1,877 |  |  | $ | 11,495 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,303 |  |  |  | 1,299 |  |  |  | 830 |  |  |  | 3,911 |  |  |  | 2,716 |  |
| Stock-based compensation expense |  |  | 632 |  |  |  | 544 |  |  |  | 315 |  |  |  | 1,641 |  |  |  | 910 |  |
| Restructuring, impairment and disposal charges |  |  | 51 |  |  |  | 86 |  |  |  | 21 |  |  |  | 766 |  |  |  | 221 |  |
| Acquisition-related costs |  |  | 59 |  |  |  | 50 |  |  |  | 28 |  |  |  | 203 |  |  |  | 152 |  |
| Debt-related costs |  |  | 2 |  |  |  | 26 |  |  |  | — |  |  |  | 28 |  |  |  | 32 |  |
| (Gains) losses on investments |  |  | (28 | ) |  |  | (40 | ) |  |  | 1 |  |  |  | (95 | ) |  |  | (3 | ) |
| Non-GAAP tax reconciling adjustments |  |  | (453 | ) |  |  | (324 | ) |  |  | (138 | ) |  |  | (1,282 | ) |  |  | (8,777 | ) |
| Discontinued operations, net of income taxes |  |  | — |  |  |  | 2 |  |  |  | 1 |  |  |  | 12 |  |  |  | 19 |  |
| Net income on non-GAAP basis |  | $ | 2,281 |  |  | $ | 2,334 |  |  | $ | 2,257 |  |  | $ | 7,061 |  |  | $ | 6,845 |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 418 |  |  |  | 422 |  |  |  | 441 |  |  |  | 420 |  |  |  | 433 |  |
| Non-GAAP adjustment (2) |  |  | 24 |  |  |  | 26 |  |  |  | 12 |  |  |  | 24 |  |  |  | 24 |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 442 |  |  |  | 448 |  |  |  | 453 |  |  |  | 444 |  |  |  | 457 |  |
| Net income on non-GAAP basis |  | $ | 2,281 |  |  | $ | 2,334 |  |  | $ | 2,257 |  |  | $ | 7,061 |  |  | $ | 6,845 |  |
| Interest expense on non-GAAP basis |  |  | 360 |  |  |  | 350 |  |  |  | 149 |  |  |  | 1,055 |  |  |  | 448 |  |
| Provision for income taxes on non-GAAP basis |  |  | 282 |  |  |  | 288 |  |  |  | 170 |  |  |  | 872 |  |  |  | 386 |  |
| Depreciation |  |  | 141 |  |  |  | 142 |  |  |  | 129 |  |  |  | 426 |  |  |  | 383 |  |
| Adjusted EBITDA |  | $ | 3,064 |  |  | $ | 3,114 |  |  | $ | 2,705 |  |  | $ | 9,414 |  |  | $ | 8,062 |  |
| Net cash provided by operating activities |  | $ | 2,419 |  |  | $ | 2,667 |  |  | $ | 2,247 |  |  | $ | 7,218 |  |  | $ | 6,245 |  |
| Purchases of property, plant and equipment |  |  | (112 | ) |  |  | (125 | ) |  |  | (120 | ) |  |  | (336 | ) |  |  | (529 | ) |
| Free cash flow |  | $ | 2,307 |  |  | $ | 2,542 |  |  | $ | 2,127 |  |  | $ | 6,882 |  |  | $ | 5,716 |  |
|  |  | FiscalQuarterEnding |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected average diluted share count: |  | November 3,2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 417 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustment (2) |  |  | 23 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 440 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001193125-19-243919:8k_2_02:82]
| (1) | Amounts represent licensing revenue not included in GAAP net revenue as a result of the effect of purchase accounting for acquisitions. |

[0001193125-19-243919:8k_2_02:83]
| (2) | Non-GAAP adjustment for number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |

[0001193125-19-243919:8k_2_02:84]
BROADCOM INC.

[0001193125-19-243919:8k_2_02:85]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-19-243919:8k_2_02:86]
(IN MILLIONS)

[0001193125-19-243919:8k_2_02:87]
|  |  | August 4,2019 |  |  | November 4,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,462 |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  |  | 3,539 |  |  |  | 3,325 |  |
| Inventory |  |  | 1,091 |  |  |  | 1,124 |  |
| Other current assets |  |  | 806 |  |  |  | 366 |  |
| Total current assets |  |  | 10,898 |  |  |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,611 |  |  |  | 2,635 |  |
| Goodwill |  |  | 36,686 |  |  |  | 26,913 |  |
| Intangible assets, net |  |  | 18,879 |  |  |  | 10,762 |  |
| Other long-term assets |  |  | 693 |  |  |  | 707 |  |
| Total assets |  | $ | 69,767 |  |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 996 |  |  | $ | 811 |  |
| Employee compensation and benefits |  |  | 575 |  |  |  | 715 |  |
| Current portion of long-term debt |  |  | 3,537 |  |  |  | — |  |
| Other current liabilities |  |  | 3,174 |  |  |  | 812 |  |
| Total current liabilities |  |  | 8,282 |  |  |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 34,028 |  |  |  | 17,493 |  |
| Other long-term liabilities |  |  | 5,954 |  |  |  | 3,636 |  |
| Total liabilities |  |  | 48,264 |  |  |  | 23,467 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital |  |  | 21,619 |  |  |  | 23,285 |  |
| Retained earnings |  |  | — |  |  |  | 3,487 |  |
| Accumulated other comprehensive loss |  |  | (116 | ) |  |  | (115 | ) |
| Total stockholders’ equity |  |  | 21,503 |  |  |  | 26,657 |  |
| Total liabilities and stockholders’ equity |  | $ | 69,767 |  |  | $ | 50,124 |  |

[0001193125-19-243919:8k_2_02:88]
BROADCOM INC.

[0001193125-19-243919:8k_2_02:89]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-19-243919:8k_2_02:90]
(IN MILLIONS)

[0001193125-19-243919:8k_2_02:91]
|  |  | Fiscal Quarter Ended |  |  | Three Fiscal Quarters Ended |  |
|  |  | August 4,2019 |  |  | May 5,2019 |  |  | August 5,2018 |  |  | August 4,2019 |  |  | August 5,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 715 |  |  | $ | 691 |  |  | $ | 1,196 |  |  | $ | 1,877 |  |  | $ | 11,495 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 1,309 |  |  |  | 1,305 |  |  |  | 836 |  |  |  | 3,930 |  |  |  | 2,730 |  |
| Depreciation |  |  | 141 |  |  |  | 142 |  |  |  | 129 |  |  |  | 426 |  |  |  | 383 |  |
| Stock-based compensation |  |  | 632 |  |  |  | 544 |  |  |  | 315 |  |  |  | 1,641 |  |  |  | 910 |  |
| Deferred taxes and other non-cash taxes |  |  | (235 | ) |  |  | (94 | ) |  |  | 22 |  |  |  | (708 | ) |  |  | (8,512 | ) |
| Non-cash restructuring, impairment and disposal charges |  |  | 15 |  |  |  | 6 |  |  |  | 3 |  |  |  | 113 |  |  |  | 13 |  |
| Non-cash interest expense |  |  | 23 |  |  |  | 14 |  |  |  | 6 |  |  |  | 50 |  |  |  | 18 |  |
| Other |  |  | (21 | ) |  |  | (39 | ) |  |  | 5 |  |  |  | (81 | ) |  |  | 22 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | (60 | ) |  |  | 193 |  |  |  | (262 | ) |  |  | 201 |  |  |  | (340 | ) |
| Inventory |  |  | (57 | ) |  |  | 40 |  |  |  | 19 |  |  |  | 33 |  |  |  | 325 |  |
| Accounts payable |  |  | 244 |  |  |  | 30 |  |  |  | (41 | ) |  |  | 105 |  |  |  | (353 | ) |
| Employee compensation and benefits |  |  | 104 |  |  |  | (6 | ) |  |  | 205 |  |  |  | (360 | ) |  |  | (87 | ) |
| Contributions to defined benefit pension plans |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (130 | ) |
| Other current assets and current liabilities |  |  | (354 | ) |  |  | (37 | ) |  |  | (148 | ) |  |  | 115 |  |  |  | 206 |  |
| Other long-term assets and long-term liabilities |  |  | (37 | ) |  |  | (122 | ) |  |  | (37 | ) |  |  | (124 | ) |  |  | (435 | ) |
| Net cash provided by operating activities |  |  | 2,419 |  |  |  | 2,667 |  |  |  | 2,247 |  |  |  | 7,218 |  |  |  | 6,245 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (6 | ) |  |  | — |  |  |  | (7 | ) |  |  | (16,033 | ) |  |  | (4,793 | ) |
| Proceeds from sales of businesses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 957 |  |  |  | 782 |  |
| Purchases of property, plant and equipment |  |  | (112 | ) |  |  | (125 | ) |  |  | (120 | ) |  |  | (336 | ) |  |  | (529 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 82 |  |  |  | — |  |  |  | — |  |  |  | 82 |  |  |  | 238 |  |
| Purchases of investments |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | (5 | ) |  |  | (249 | ) |
| Proceeds from sales of investments |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 5 |  |  |  | 54 |  |
| Other |  |  | (1 | ) |  |  | 21 |  |  |  | (47 | ) |  |  | (4 | ) |  |  | (59 | ) |
| Net cash used in investing activities |  |  | (35 | ) |  |  | (106 | ) |  |  | (174 | ) |  |  | (15,334 | ) |  |  | (4,556 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | — |  |  |  | 10,897 |  |  |  | — |  |  |  | 28,793 |  |  |  | — |  |
| Repayment of debt |  |  | — |  |  |  | (12,000 | ) |  |  | — |  |  |  | (12,000 | ) |  |  | (856 | ) |
| Payment of debt issuance costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (46 | ) |  |  | — |  |
| Other borrowings |  |  | (230 | ) |  |  | 1,044 |  |  |  | — |  |  |  | 1,345 |  |  |  | — |  |
| Dividend and distribution payments |  |  | (1,057 | ) |  |  | (1,057 | ) |  |  | (754 | ) |  |  | (3,181 | ) |  |  | (2,275 | ) |
| Repurchases of common stock - repurchase program |  |  | (736 | ) |  |  | (830 | ) |  |  | (5,378 | ) |  |  | (5,002 | ) |  |  | (5,725 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  |  | (241 | ) |  |  | (500 | ) |  |  | (33 | ) |  |  | (818 | ) |  |  | (35 | ) |
| Issuance of common stock |  |  | 11 |  |  |  | 121 |  |  |  | 39 |  |  |  | 194 |  |  |  | 153 |  |
| Other |  |  | 3 |  |  |  | (1 | ) |  |  | 2 |  |  |  | 1 |  |  |  | (19 | ) |
| Net cash provided by (used in) financing activities |  |  | (2,250 | ) |  |  | (2,326 | ) |  |  | (6,124 | ) |  |  | 9,286 |  |  |  | (8,757 | ) |
| Net change in cash and cash equivalents |  |  | 134 |  |  |  | 235 |  |  |  | (4,051 | ) |  |  | 1,170 |  |  |  | (7,068 | ) |
| Cash and cash equivalents at the beginning of period |  |  | 5,328 |  |  |  | 5,093 |  |  |  | 8,187 |  |  |  | 4,292 |  |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | 5,462 |  |  | $ | 5,328 |  |  | $ | 4,136 |  |  | $ | 5,462 |  |  | $ | 4,136 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 368 |  |  | $ | 189 |  |  | $ | 312 |  |  | $ | 980 |  |  | $ | 545 |  |
| Cash paid for income taxes |  | $ | 98 |  |  | $ | 425 |  |  | $ | 127 |  |  | $ | 618 |  |  | $ | 323 |  |
