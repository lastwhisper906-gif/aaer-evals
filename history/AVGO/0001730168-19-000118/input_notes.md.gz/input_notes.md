# AVGO notes — 0001730168-19-000118


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-19-000118:notes:1]
[same as prior period, unchanged from 0001730168-19-000101:notes:1]

[0001730168-19-000118:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Pte. Ltd. (formerly Broadcom Limited), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom eliminating their noncontrolling interest. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. We deregistered the Partnership and liquidated Broadcom-Singapore.

[0001730168-19-000118:notes:3]
[same as prior period, unchanged from 0001730168-19-000101:notes:3]

[0001730168-19-000118:notes:4]
[same as prior period, unchanged from 0001730168-19-000101:notes:4]

[0001730168-19-000118:notes:5]
[same as prior period, unchanged from 0001730168-19-000101:notes:5]

[0001730168-19-000118:notes:6]
[same as prior period, unchanged from 0001730168-19-000101:notes:6]

[0001730168-19-000118:notes:7]
[same as prior period, unchanged from 0001730168-19-000101:notes:7]

[0001730168-19-000118:notes:8]
[same as prior period, unchanged from 0001730168-19-000101:notes:8]

[0001730168-19-000118:notes:9]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ended on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.

[0001730168-19-000118:notes:10]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 4, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.

[0001730168-19-000118:notes:11]
[same as prior period, unchanged from 0001730168-19-000101:notes:11]

[0001730168-19-000118:notes:12]
[same as prior period, unchanged from 0001730168-19-000101:notes:12]

[0001730168-19-000118:notes:13]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statements of operations and condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.

[0001730168-19-000118:notes:14]
Recently Adopted Accounting Guidance

[0001730168-19-000118:notes:15]
[same as prior period, unchanged from 0001730168-19-000101:notes:15]

[0001730168-19-000118:notes:16]
In the first quarter of fiscal year 2019, we adopted the FASB guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and three fiscal quarters ended August 4, 2019, we also recognized $28 million and $95 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.

[0001730168-19-000118:notes:17]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (“Topic 606”). We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. “Revenue from Contracts with Customers” for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

[0001730168-19-000118:notes:18]
[same as prior period, unchanged from 0001730168-19-000101:notes:18]

[0001730168-19-000118:notes:19]
In February 2016, the FASB issued guidance related to the accounting for leases, which principally requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. We will adopt this guidance using the optional transition method and will not restate comparative prior periods. We are finalizing the implementation of related systems, policies, processes and internal controls to comply with this guidance. Based on our lease portfolio as of August 4, 2019, we expect the adoption of the new leasing guidance to result in recognition of right-of-use assets and corresponding liabilities on our condensed consolidated balance sheet within a range of $500 million to $600 million, primarily related to real estate. However, the actual impact will depend on our lease portfolio as of the adoption date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-19-000118:notes:20]
[same as prior period, unchanged from 0001730168-19-000101:notes:20]

[0001730168-19-000118:notes:21]
[same as prior period, unchanged from 0001730168-19-000101:notes:21]

[0001730168-19-000118:notes:22]
[same as prior period, unchanged from 0001730168-19-000101:notes:22]

[0001730168-19-000118:notes:23]
[same as prior period, unchanged from 0001730168-19-000101:notes:23]

[0001730168-19-000118:notes:24]
[same as prior period, unchanged from 0001730168-19-000101:notes:24]

[0001730168-19-000118:notes:25]
[same as prior period, unchanged from 0001730168-19-000101:notes:25]

[0001730168-19-000118:notes:26]
[same as prior period, unchanged from 0001730168-19-000101:notes:26]

[0001730168-19-000118:notes:27]
[same as prior period, unchanged from 0001730168-19-000101:notes:27]

[0001730168-19-000118:notes:28]
[same as prior period, unchanged from 0001730168-19-000101:notes:28]

[0001730168-19-000118:notes:29]
[same as prior period, unchanged from 0001730168-19-000101:notes:29]

[0001730168-19-000118:notes:30]
[same as prior period, unchanged from 0001730168-19-000101:notes:30]

[0001730168-19-000118:notes:31]
[same as prior period, unchanged from 0001730168-19-000101:notes:31]

[0001730168-19-000118:notes:32]
[same as prior period, unchanged from 0001730168-19-000101:notes:32]

[0001730168-19-000118:notes:33]
[same as prior period, unchanged from 0001730168-19-000101:notes:33]

[0001730168-19-000118:notes:34]
[same as prior period, unchanged from 0001730168-19-000101:notes:34]

[0001730168-19-000118:notes:35]
[same as prior period, unchanged from 0001730168-19-000101:notes:35]

[0001730168-19-000118:notes:36]
[same as prior period, unchanged from 0001730168-19-000101:notes:36]

[0001730168-19-000118:notes:37]
[same as prior period, unchanged from 0001730168-19-000101:notes:37]

[0001730168-19-000118:notes:38]
[same as prior period, unchanged from 0001730168-19-000101:notes:38]

[0001730168-19-000118:notes:39]
[same as prior period, unchanged from 0001730168-19-000101:notes:39]

[0001730168-19-000118:notes:40]
[same as prior period, unchanged from 0001730168-19-000101:notes:40]

[0001730168-19-000118:notes:41]
[same as prior period, unchanged from 0001730168-19-000101:notes:41]

[0001730168-19-000118:notes:42]
[same as prior period, unchanged from 0001730168-19-000101:notes:42]

[0001730168-19-000118:notes:43]
[same as prior period, unchanged from 0001730168-19-000101:notes:43]

[0001730168-19-000118:notes:44]
[same as prior period, unchanged from 0001730168-19-000101:notes:44]

[0001730168-19-000118:notes:45]
|  |  | Fiscal Quarter Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

[0001730168-19-000118:notes:46]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |

[0001730168-19-000118:notes:47]
[same as prior period, unchanged from 0001730168-19-000101:notes:47]

[0001730168-19-000118:notes:48]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

[0001730168-19-000118:notes:49]
[same as prior period, unchanged from 0001730168-19-000101:notes:49]

[0001730168-19-000118:notes:50]
[same as prior period, unchanged from 0001730168-19-000101:notes:50]

[0001730168-19-000118:notes:51]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |

[0001730168-19-000118:notes:52]
(a) We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

[0001730168-19-000118:notes:53]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.

[0001730168-19-000118:notes:54]
[same as prior period, unchanged from 0001730168-19-000101:notes:54]

[0001730168-19-000118:notes:55]
[same as prior period, unchanged from 0001730168-19-000101:notes:55]

[0001730168-19-000118:notes:56]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 4, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

[0001730168-19-000118:notes:57]
[same as prior period, unchanged from 0001730168-19-000101:notes:57]

[0001730168-19-000118:notes:58]
[same as prior period, unchanged from 0001730168-19-000101:notes:58]

[0001730168-19-000118:notes:59]
We recognize an asset for costs incurred to fulfill a contract that are not within the scope of other accounting literature. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

[0001730168-19-000118:notes:60]
[same as prior period, unchanged from 0001730168-19-000101:notes:60]

[0001730168-19-000118:notes:61]
[same as prior period, unchanged from 0001730168-19-000101:notes:61]

[0001730168-19-000118:notes:62]
[same as prior period, unchanged from 0001730168-19-000101:notes:62]

[0001730168-19-000118:notes:63]
[same as prior period, unchanged from 0001730168-19-000101:notes:63]

[0001730168-19-000118:notes:64]
[same as prior period, unchanged from 0001730168-19-000101:notes:64]

[0001730168-19-000118:notes:65]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and three fiscal quarters ended August 4, 2019 or in the condensed consolidated balance sheet as of August 4, 2019 were significantly affected by the new revenue guidance.

[0001730168-19-000118:notes:66]
|  |  | Fiscal Quarter Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,413 |  |  | $ | — |  |  | $ | 4,413 |  |
| Subscriptions and services |  | 1,078 |  |  | 24 |  |  | 1,102 |  |
| Total net revenue |  | $ | 5,491 |  |  | $ | 24 |  |  | $ | 5,515 |  |

[0001730168-19-000118:notes:67]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 13,470 |  |  | $ | — |  |  | $ | 13,470 |  |
| Subscriptions and services |  | 3,124 |  |  | 227 |  |  | 3,351 |  |
| Total net revenue |  | $ | 16,594 |  |  | $ | 227 |  |  | $ | 16,821 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-19-000118:notes:68]
[same as prior period, unchanged from 0001730168-19-000101:notes:68]

[0001730168-19-000118:notes:69]
On November 5, 2018, we acquired CA, which was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities. We financed the CA Merger with the net proceeds from borrowings under the Original 2019 Term Loans, as defined in Note 7. “Borrowings,” as well as with cash on hand of the combined companies.

[0001730168-19-000118:notes:70]
[same as prior period, unchanged from 0001730168-19-000101:notes:70]

[0001730168-19-000118:notes:71]
[same as prior period, unchanged from 0001730168-19-000101:notes:71]

[0001730168-19-000118:notes:72]
[same as prior period, unchanged from 0001730168-19-000101:notes:72]

[0001730168-19-000118:notes:73]
[same as prior period, unchanged from 0001730168-19-000101:notes:73]

[0001730168-19-000118:notes:74]
[same as prior period, unchanged from 0001730168-19-000101:notes:74]

[0001730168-19-000118:notes:75]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,663 |  |
| Goodwill |  | 9,768 |  |
| Intangible assets |  | 12,045 |  |
| Other long-term assets |  | 245 |  |
| Total assets acquired |  | 23,721 |  |
| Current liabilities |  | (1,966 | ) |
| Long-term debt |  | (2,255 | ) |
| Other long-term liabilities |  | (3,406 | ) |
| Total liabilities assumed |  | (7,627 | ) |
| Fair value of net assets acquired |  | $ | 16,094 |  |

[0001730168-19-000118:notes:76]
[same as prior period, unchanged from 0001730168-19-000101:notes:76]

[0001730168-19-000118:notes:77]
Current assets included assets held-for-sale related to CA’s Veracode business, which was not aligned with our strategic objectives. On December 31, 2018, we sold this business to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Current assets also included $80 million of real properties held-for-sale. During the fiscal quarter ended August 4, 2019, we sold a portion of these real properties for $56 million and recognized a loss of $8 million.

[0001730168-19-000118:notes:78]
Revenue attributable to CA has been included in our infrastructure software segment. Transaction costs related to the CA Merger of $73 million were included in selling, general and administrative expense for the three fiscal quarters ended August 4, 2019.

[0001730168-19-000118:notes:79]
[same as prior period, unchanged from 0001730168-19-000101:notes:79]

[0001730168-19-000118:notes:80]
[same as prior period, unchanged from 0001730168-19-000101:notes:80]

[0001730168-19-000118:notes:81]
[same as prior period, unchanged from 0001730168-19-000101:notes:81]

[0001730168-19-000118:notes:82]
[same as prior period, unchanged from 0001730168-19-000101:notes:82]

[0001730168-19-000118:notes:83]
[same as prior period, unchanged from 0001730168-19-000101:notes:83]

[0001730168-19-000118:notes:84]
[same as prior period, unchanged from 0001730168-19-000101:notes:84]

[0001730168-19-000118:notes:85]
[same as prior period, unchanged from 0001730168-19-000101:notes:85]

[0001730168-19-000118:notes:86]
[same as prior period, unchanged from 0001730168-19-000101:notes:86]

[0001730168-19-000118:notes:87]
[same as prior period, unchanged from 0001730168-19-000101:notes:87]

[0001730168-19-000118:notes:88]
[same as prior period, unchanged from 0001730168-19-000101:notes:88]

[0001730168-19-000118:notes:89]
As of August 4, 2019, IPR&D is expected to be fully released by the end of fiscal year 2020.

[0001730168-19-000118:notes:90]
[same as prior period, unchanged from 0001730168-19-000101:notes:89]

[0001730168-19-000118:notes:91]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if CA had been acquired as of the beginning of fiscal year 2018. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the three fiscal quarters ended August 5, 2018, non-recurring pro forma adjustments directly attributable to the CA Merger included transaction costs of $180 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-19-000118:notes:92]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,287 |  |  | $ | 5,983 |  |  | $ | 16,137 |  |  | $ | 18,066 |  |
| Pro forma net income attributable to common stock |  | $ | 542 |  |  | $ | 894 |  |  | $ | 1,895 |  |  | $ | 8,956 |  |

[0001730168-19-000118:notes:93]
[same as prior period, unchanged from 0001730168-19-000101:notes:92]

[0001730168-19-000118:notes:94]
[same as prior period, unchanged from 0001730168-19-000101:notes:93]

[0001730168-19-000118:notes:95]
[same as prior period, unchanged from 0001730168-19-000101:notes:94]

[0001730168-19-000118:notes:96]
[same as prior period, unchanged from 0001730168-19-000101:notes:95]

[0001730168-19-000118:notes:97]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |  | August 5, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,066 |  |  | $ | 15,530 |  |
| Pro forma net income attributable to common stock |  | $ | 1,207 |  |  | $ | 11,284 |  |

[0001730168-19-000118:notes:98]
[same as prior period, unchanged from 0001730168-19-000101:notes:97]

[0001730168-19-000118:notes:99]
Pending Acquisition of Symantec Corporation’s Enterprise Security Business

[0001730168-19-000118:notes:100]
On August 8, 2019, we entered into an asset purchase agreement (the “Symantec Purchase Agreement”) with Symantec Corporation (“Symantec”) to purchase certain assets and assume certain liabilities of Symantec’s Enterprise Security business for approximately $10.7 billion in cash, on a cash-free, debt-free basis (the “Symantec Asset Purchase”). We intend to fund the Symantec Asset Purchase and related working capital needs with new, fully committed debt financing of up to $12 billion in term loans. The Symantec Purchase Agreement provides that, following the closing of the Symantec Asset Purchase, each party will have certain indemnification obligations, including with respect to breaches of covenants and for losses arising from certain assumed or retained liabilities, as applicable. We and Symantec may terminate the Symantec Purchase Agreement if the closing of the Symantec Asset Purchase has not occurred on or before February 8, 2020, subject to a three-month extension in certain circumstances.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-19-000118:notes:101]
[same as prior period, unchanged from 0001730168-19-000101:notes:98]

[0001730168-19-000118:notes:102]
Cash equivalents included $603 million and $1,406 million of time deposits as of August 4, 2019 and November 4, 2018, respectively. As of August 4, 2019 and November 4, 2018, cash equivalents also included $945 million and $202 million of money-market funds, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-19-000118:notes:103]
[same as prior period, unchanged from 0001730168-19-000101:notes:100]

[0001730168-19-000118:notes:104]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring agreements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring agreements were $375 million and $465 million during the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, and $305 million and $362 million during the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any period presented.

[0001730168-19-000118:notes:105]
[same as prior period, unchanged from 0001730168-19-000101:notes:102]

[0001730168-19-000118:notes:106]
|  |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Finished goods |  | $ | 329 |  |  | $ | 483 |  |
| Work-in-process |  | 567 |  |  | 505 |  |
| Raw materials |  | 195 |  |  | 136 |  |
| Total inventory |  | $ | 1,091 |  |  | $ | 1,124 |  |

[0001730168-19-000118:notes:107]
[same as prior period, unchanged from 0001730168-19-000101:notes:104]

[0001730168-19-000118:notes:108]
|  |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 402 |  |  | $ | 243 |  |
| Other (miscellaneous) |  | 404 |  |  | 123 |  |
| Total other current assets |  | $ | 806 |  |  | $ | 366 |  |

[0001730168-19-000118:notes:109]
[same as prior period, unchanged from 0001730168-19-000101:notes:106]

[0001730168-19-000118:notes:110]
|  |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 1,872 |  |  | $ | 164 |  |
| Notional pooling liabilities |  | 372 |  |  | — |  |
| Tax liabilities |  | 264 |  |  | 162 |  |
| Other (miscellaneous) |  | 666 |  |  | 486 |  |
| Total other current liabilities |  | $ | 3,174 |  |  | $ | 812 |  |

[0001730168-19-000118:notes:111]
We use a notional pooling arrangement with an international bank to assist us in the management of global liquidity. Under this arrangement, we maintain either a cash deposit or borrowing position in our accounts, so long as the aggregate global pooling position is a notionally calculated net cash deposit.

[0001730168-19-000118:notes:112]
[same as prior period, unchanged from 0001730168-19-000101:notes:109]

[0001730168-19-000118:notes:113]
|  |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Unrecognized tax benefits (a) (b) |  | $ | 3,361 |  |  | $ | 3,088 |  |
| Deferred tax liabilities (a) |  | 1,660 |  |  | 169 |  |
| Contract liabilities |  | 397 |  |  | 66 |  |
| Other (miscellaneous) |  | 536 |  |  | 313 |  |
| Total other long-term liabilities |  | $ | 5,954 |  |  | $ | 3,636 |  |

[0001730168-19-000118:notes:114]
[same as prior period, unchanged from 0001730168-19-000101:notes:111]

[0001730168-19-000118:notes:115]
[same as prior period, unchanged from 0001730168-19-000101:notes:112]

[0001730168-19-000118:notes:116]
[same as prior period, unchanged from 0001730168-19-000101:notes:113]

[0001730168-19-000118:notes:117]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 368 |  |  | $ | 312 |  |  | $ | 980 |  |  | $ | 545 |  |
| Cash paid for income taxes |  | $ | 98 |  |  | $ | 127 |  |  | $ | 618 |  |  | $ | 323 |  |

[0001730168-19-000118:notes:118]
As of August 4, 2019 and November 4, 2018, we had $30 million and $22 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-19-000118:notes:119]
[same as prior period, unchanged from 0001730168-19-000101:notes:116]

[0001730168-19-000118:notes:120]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 17,705 |  |  | $ | 5,945 |  |  | $ | 3,112 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26,913 |  |
| Reallocation due to change in segments |  | (17,705 | ) |  | (5,945 | ) |  | (3,112 | ) |  | (151 | ) |  | 25,924 |  |  | 980 |  |  | 9 |  |  | — |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | 9,768 |  |  | — |  |  | 9,773 |  |
| Balance as of August 4, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25,929 |  |  | $ | 10,748 |  |  | $ | 9 |  |  | $ | 36,686 |  |

[0001730168-19-000118:notes:121]
[same as prior period, unchanged from 0001730168-19-000101:notes:118]

[0001730168-19-000118:notes:122]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of August 4, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,888 |  |  | $ | (9,288 | ) |  | $ | 11,600 |  |
| Customer contracts and related relationships |  | 5,982 |  |  | (1,563 | ) |  | 4,419 |  |
| Order backlog |  | 2,569 |  |  | (681 | ) |  | 1,888 |  |
| Trade names |  | 712 |  |  | (228 | ) |  | 484 |  |
| Other |  | 243 |  |  | (81 | ) |  | 162 |  |
| Intangible assets subject to amortization |  | 30,394 |  |  | (11,841 | ) |  | 18,553 |  |
| IPR&D |  | 326 |  |  | — |  |  | 326 |  |
| Total |  | $ | 30,720 |  |  | $ | (11,841 | ) |  | $ | 18,879 |  |
| As of November 4, 2018: |  |  |  |  |  |  |
| Purchased technology |  | $ | 15,806 |  |  | $ | (6,816 | ) |  | $ | 8,990 |  |
| Customer contracts and related relationships |  | 1,792 |  |  | (878 | ) |  | 914 |  |
| Trade names |  | 578 |  |  | (170 | ) |  | 408 |  |
| Other |  | 239 |  |  | (53 | ) |  | 186 |  |
| Intangible assets subject to amortization |  | 18,415 |  |  | (7,917 | ) |  | 10,498 |  |
| IPR&D |  | 264 |  |  | — |  |  | 264 |  |
| Total |  | $ | 18,679 |  |  | $ | (7,917 | ) |  | $ | 10,762 |  |

[0001730168-19-000118:notes:123]
Based on the amount of intangible assets subject to amortization at August 4, 2019, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-19-000118:notes:124]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 1,309 |  |
| 2020 |  | 5,045 |  |
| 2021 |  | 4,142 |  |
| 2022 |  | 3,171 |  |
| 2023 |  | 2,166 |  |
| Thereafter |  | 2,720 |  |
| Total |  | $ | 18,553 |  |

[0001730168-19-000118:notes:125]
[same as prior period, unchanged from 0001730168-19-000101:notes:122]

[0001730168-19-000118:notes:126]
| Amortizable intangible assets: |  | August 4, 2019 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 5 |
| Order backlog |  | 3 |
| Trade names |  | 10 |
| Other |  | 10 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-19-000118:notes:127]
Net Income Per Share
Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-19-000118:notes:128]
Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested restricted stock units (“RSUs”), and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), collectively referred to as “equity awards”.

[0001730168-19-000118:notes:129]
[same as prior period, unchanged from 0001730168-19-000101:notes:126]

[0001730168-19-000118:notes:130]
For the three fiscal quarters ended August 5, 2018, diluted net income per share excluded the potentially dilutive effect of the exchange of LP Units for 12 million shares of common stock prior to the effective time of Mandatory Exchange as their effect was antidilutive.

[0001730168-19-000118:notes:131]
[same as prior period, unchanged from 0001730168-19-000101:notes:128]

[0001730168-19-000118:notes:132]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 715 |  |  | $ | 1,197 |  |  | $ | 1,889 |  |  | $ | 11,514 |  |
| Less: Income from continuing operations attributable to noncontrolling interest |  | — |  |  | — |  |  | — |  |  | 352 |  |
| Income from continuing operations attributable to common stock |  | 715 |  |  | 1,197 |  |  | 1,889 |  |  | 11,162 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (1 | ) |  | (12 | ) |  | (19 | ) |
| Less: Loss from discontinued operations, net of income taxes, attributable to noncontrolling interest |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | — |  |  | (1 | ) |  | (12 | ) |  | (18 | ) |
| Net income attributable to common stock |  | $ | 715 |  |  | $ | 1,196 |  |  | $ | 1,877 |  |  | $ | 11,144 |  |

[0001730168-19-000118:notes:133]
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 398 |  |  | 430 |  |  | 399 |  |  | 420 |  |
| Dilutive effect of equity awards |  | 20 |  |  | 11 |  |  | 21 |  |  | 13 |  |
| Weighted-average shares outstanding - diluted |  | 418 |  |  | 441 |  |  | 420 |  |  | 433 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.80 |  |  | $ | 2.78 |  |  | $ | 4.73 |  |  | $ | 26.58 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.03 | ) |  | (0.05 | ) |
| Net income per share |  | $ | 1.80 |  |  | $ | 2.78 |  |  | $ | 4.70 |  |  | $ | 26.53 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.71 |  |  | $ | 2.71 |  |  | $ | 4.50 |  |  | $ | 25.78 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.03 | ) |  | (0.04 | ) |
| Net income per share |  | $ | 1.71 |  |  | $ | 2.71 |  |  | $ | 4.47 |  |  | $ | 25.74 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-19-000118:notes:134]
Borrowings

[0001730168-19-000118:notes:135]
|  |  | Effective Interest Rate |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due May 2022 |  | 3.683 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.729 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.820 | % |  | 2,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.855 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (294 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 37,565 |  |  | $ | 17,493 |  |

[0001730168-19-000118:notes:136]
(a) Represents the weighted average interest rate on outstanding commercial paper as of August 4, 2019.

[0001730168-19-000118:notes:137]
2019 Senior Notes

[0001730168-19-000118:notes:138]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.

[0001730168-19-000118:notes:139]
2019 Term Loans

[0001730168-19-000118:notes:140]
In November 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

[0001730168-19-000118:notes:141]
On May 7, 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

[0001730168-19-000118:notes:142]
Revolving Facility

[0001730168-19-000118:notes:143]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on August 4, 2019.

[0001730168-19-000118:notes:144]
Commercial Paper

[0001730168-19-000118:notes:145]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of August 4, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.

[0001730168-19-000118:notes:146]
Assumed CA Senior Notes

[0001730168-19-000118:notes:147]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

[0001730168-19-000118:notes:148]
Fair Value of Debt

[0001730168-19-000118:notes:149]
As of August 4, 2019, the estimated aggregate fair value of debt was $37,934 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-19-000118:notes:150]
Future Principal Payments of Debt

[0001730168-19-000118:notes:151]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:

[0001730168-19-000118:notes:152]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 1,000 |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 2,950 |  |
| 2022 |  | 7,909 |  |
| 2023 |  | 1,650 |  |
| Thereafter |  | 20,413 |  |
| Total |  | $ | 37,859 |  |

[0001730168-19-000118:notes:153]
As of August 4, 2019 and November 4, 2018, we accrued interest payable of $208 million and $165 million, respectively and were in compliance with all debt covenants.

[0001730168-19-000118:notes:154]
Pending Financing Arrangement
In connection with the Symantec Purchase Agreement, we entered into a commitment letter, with certain financial institutions to provide (i) up to $12 billion in term loans to fund the Symantec Asset Purchase and (ii) $3.5 billion in term loans to refinance certain existing senior notes maturing in the first quarter of our fiscal year 2020 (which begins on November 4, 2019).


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001730168-19-000118:notes:155]
[same as prior period, unchanged from 0001730168-19-000101:notes:152]

[0001730168-19-000118:notes:156]
[same as prior period, unchanged from 0001730168-19-000101:notes:153]

[0001730168-19-000118:notes:157]
[same as prior period, unchanged from 0001730168-19-000101:notes:154]

[0001730168-19-000118:notes:158]
[same as prior period, unchanged from 0001730168-19-000101:notes:155]

[0001730168-19-000118:notes:159]
Immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income attributable to our common stock in our condensed consolidated statements of operations excluded the noncontrolling interest’s proportionate share of our results prior to the Redomiciliation Transaction. In addition, we presented the proportionate share of equity attributable

[0001730168-19-000118:notes:160]
to the noncontrolling interest as a separate component of total equity within our condensed consolidated statements of equity for the periods prior to the Redomiciliation Transaction.

[0001730168-19-000118:notes:161]
[same as prior period, unchanged from 0001730168-19-000101:notes:157]

[0001730168-19-000118:notes:162]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 2.65 |  |  | $ | 1.75 |  |  | $ | 7.95 |  |  | $ | 5.25 |  |
| Cash dividends paid to stockholders |  | $ | 1,057 |  |  | $ | 754 |  |  | $ | 3,181 |  |  | $ | 2,198 |  |
| Cash distributions paid to limited partners |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 77 |  |

[0001730168-19-000118:notes:163]
[same as prior period, unchanged from 0001730168-19-000101:notes:159]

[0001730168-19-000118:notes:164]
In December 2018, our Board of Directors increased our previously authorized $12 billion stock repurchase program to a total of $18 billion. This authorization covers repurchases through fiscal year 2019. During the fiscal quarter and three fiscal quarters ended August 4, 2019, we repurchased and retired approximately 2 million and 19 million shares of our common stock for $736 million and $5,002 million, respectively, under this stock repurchase program. During the fiscal quarter and three fiscal quarters ended August 5, 2018, we repurchased and retired approximately 24 million and 26 million shares of our common stock for $5,378 million and $5,725 million, respectively, under this stock repurchase program. As of August 4, 2019, $5,740 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000118:notes:165]
[same as prior period, unchanged from 0001730168-19-000101:notes:161]

[0001730168-19-000118:notes:166]
[same as prior period, unchanged from 0001730168-19-000101:notes:162]

[0001730168-19-000118:notes:167]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 34 |  |  | $ | 20 |  |  | $ | 89 |  |  | $ | 57 |  |
| Cost of subscriptions and services |  | 13 |  |  | 2 |  |  | 33 |  |  | 6 |  |
| Research and development |  | 456 |  |  | 222 |  |  | 1,138 |  |  | 630 |  |
| Selling, general and administrative |  | 129 |  |  | 71 |  |  | 381 |  |  | 217 |  |
| Total stock-based compensation expense |  | $ | 632 |  |  | $ | 315 |  |  | $ | 1,641 |  |  | $ | 910 |  |

[0001730168-19-000118:notes:168]
During the fiscal quarter ended February 3, 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $314 million and $639 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, including $47 million and $96 million of Multi-Year Equity Awards granted to employees acquired in the CA Merger, respectively.

[0001730168-19-000118:notes:169]
During the fiscal quarter ended August 4, 2019, our Compensation Committee approved an amendment to the vesting of time-based RSUs that met certain criteria from an annual vesting cycle to a quarterly vesting cycle. We recognized approximately $128 million of additional stock-based compensation expense related to a one-time true up of expense for shares vested during the fiscal quarter ended August 4, 2019 and expected to vest as of August 4, 2019, including the Multi-Year Equity Awards, due to the acceleration of vesting dates, as well as incremental fair value resulting from the change in the vesting condition.

[0001730168-19-000118:notes:170]
For the fiscal quarter and three fiscal quarters ended August 4, 2019, stock-based compensation expense included $13 million and $73 million, respectively, related to equity awards assumed in connection with the CA Merger. In addition to stock-based compensation expense presented above, for the three fiscal quarters ended August 4, 2019, we recognized $75 million

[0001730168-19-000118:notes:171]
in restructuring charges for accelerated vesting of assumed equity awards held by employees terminated in connection with the CA Merger.

[0001730168-19-000118:notes:172]
As of August 4, 2019, the total unrecognized compensation cost related to unvested stock-based awards was $6,108 million, which is expected to be recognized over the remaining weighted-average service period of 4.2 years.

[0001730168-19-000118:notes:173]
[same as prior period, unchanged from 0001730168-19-000101:notes:167]

[0001730168-19-000118:notes:174]
[same as prior period, unchanged from 0001730168-19-000101:notes:168]

[0001730168-19-000118:notes:175]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |
| Assumed in CA Merger |  | 1 |  |  | $ | 206.14 |  |
| Granted |  | 32 |  |  | $ | 178.14 |  |
| Vested |  | (9 | ) |  | $ | 189.91 |  |
| Forfeited |  | (1 | ) |  | $ | 180.86 |  |
| Balance as of August 4, 2019 |  | 41 |  |  | $ | 188.86 |  |

[0001730168-19-000118:notes:176]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended August 4, 2019 was $2,494 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-19-000118:notes:177]
[same as prior period, unchanged from 0001730168-19-000101:notes:171]

[0001730168-19-000118:notes:178]
|  |  | Number of OptionsOutstanding |  |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 4, 2018 |  | 8 |  |  |  | $ | 50.14 |  |  |  |  |  |
| Exercised |  | (3 | ) |  |  | $ | 47.99 |  |  |  |  | $ | 706 |  |
| Cancelled |  | — |  | * |  | $ | 44.84 |  |  |  |  |  |
| Balance as of August 4, 2019 |  | 5 |  |  |  | $ | 51.56 |  |  | 1.36 |  | $ | 1,052 |  |
| Fully vested as of August 4, 2019 |  | 5 |  |  |  | $ | 51.56 |  |  | 1.36 |  | $ | 1,052 |  |

[0001730168-19-000118:notes:179]
[same as prior period, unchanged from 0001730168-19-000101:notes:173]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-19-000118:notes:180]
Income Taxes
For the fiscal quarter and three fiscal quarters ended August 4, 2019, our benefit from income taxes was $171 million and $410 million, respectively, compared to a provision for income taxes of $32 million and a benefit from income taxes of $8,391 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively.

[0001730168-19-000118:notes:181]
The benefit for the fiscal quarter ended August 4, 2019 was primarily due to $75 million of benefit from deferred tax remeasurement in a foreign jurisdiction, $47 million of benefit related to internal reorganizations, and $34 million of excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-19-000118:notes:182]
The provision for income taxes for the corresponding 2018 fiscal quarter was primarily due to profits from continuing operations, partially offset by a net discrete benefit of $14 million, including $25 million of excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-19-000118:notes:183]
The benefit for the three fiscal quarters ended August 4, 2019 was primarily due to $206 million of excess tax benefits from stock-based awards that vested or were exercised during the period, $121 million from the recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, $75 million of benefit from deferred tax remeasurement in a foreign jurisdiction, $66 million of benefit related to internal reorganizations, and the partial release of $54 million of our valuation allowance as a result of the CA Merger, partially offset by $113 million of expense from a change

[0001730168-19-000118:notes:184]
in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”).

[0001730168-19-000118:notes:185]
On December 22, 2017, the SEC issued Staff Accounting Bulletin No. 118. This guidance allowed registrants a “measurement period,” not to exceed one year from the date of enactment, to complete their accounting for the tax effects of the 2017 Tax Reform Act. We relied on this guidance to refine our estimates of the impact of the 2017 Tax Reform Act during the measurement period. The measurement period ended during our fiscal quarter ended February 3, 2019, and no adjustments were recorded. As a result, we consider our accounting for the tax effects of the 2017 Tax Reform Act to be complete based on our interpretation of the law and subsequently issued guidance. However, it is expected that the U.S. Treasury will continue to issue regulations and other guidance on the application of certain provisions of the 2017 Tax Reform Act that may impact our interpretation of the rules and our calculation of the tax impact of the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017 (the “Transition Tax”) or other provisions of the 2017 Tax Reform Act. We recorded income tax expense of $113 million during the fiscal quarter ended May 5, 2019 as a result of the issuance of such regulations.

[0001730168-19-000118:notes:186]
The three fiscal quarters ended August 4, 2019 also included the impact of several provisions of the 2017 Tax Reform Act that became effective for us for the first time in fiscal year 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000118:notes:187]
In connection with CA Merger in November 2018, we established $2,378 million of net deferred tax liabilities on the excess of the book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that had not been indefinitely reinvested, partially offset by acquired tax attributes. The net deferred tax liabilities are based upon certain assumptions underlying our preliminary purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes may be required, provided we are within the measurement period.

[0001730168-19-000118:notes:188]
The benefit from income taxes for the corresponding 2018 fiscal period was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act and the Redomiciliation Transaction. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the Transition Tax.

[0001730168-19-000118:notes:189]
As a result of the 2017 Tax Reform Act, we recorded a total provisional benefit of $7,303 million during the three fiscal quarters ended August 5, 2018. The provisional benefit included $7,212 million related to the Transition Tax, which was primarily due to a reduction of $10,392 million in our federal deferred income tax liabilities on accumulated non-U.S. earnings, partially offset by $2,116 million of federal provisional long-term Transition Tax payable and $1,116 million of unrecognized federal tax benefits related to the Transition Tax. This provisional benefit also included $92 million related to the remeasurement of certain deferred tax assets and liabilities, which was based on the tax rates at which they were expected to be reversed in the future as a result of the 2017 Tax Reform Act.

[0001730168-19-000118:notes:190]
The impact of the Redomiciliation Transaction and related internal reorganizations included tax benefits of $1,162 million from the remeasurement of withholding taxes on undistributed earnings, partially offset by an $84 million tax provision on foreign earnings and profit subject to U.S. tax.

[0001730168-19-000118:notes:191]
We also recognized income tax benefits of $25 million and $180 million for excess tax benefits from stock-based awards that vested or were exercised during the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively.

[0001730168-19-000118:notes:192]
During the fiscal quarter ended August 4, 2019, we re-evaluated our indefinite reinvestment assertion with regards to certain accumulated foreign earnings and concluded that we intend to indefinitely reinvest $2,677 million of such earnings as a result of interpretive guidance issued by the IRS. The amount of unrecognized deferred income tax liability indefinitely related to these earnings is estimated to be $281 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-19-000118:notes:193]
[same as prior period, unchanged from 0001730168-19-000101:notes:184]

[0001730168-19-000118:notes:194]
The balance of gross unrecognized tax benefits was $4,254 million and $4,030 million as of August 4, 2019 and November 4, 2018, respectively. This increase was primarily due to the recognition of uncertain tax positions related to the CA Merger, which were initially estimated as of the CA Acquisition Date, offset by audit settlements and lapses of statutes of limitations. We continue to reevaluate these items with any adjustments to our preliminary estimates recognized, provided we are within the measurement period and we continue to collect information in order to determine their estimated values.

[0001730168-19-000118:notes:195]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of August 4, 2019 and November 4, 2018, the combined amount of cumulative accrued interest and penalties was approximately $328 million and $190 million, respectively.

[0001730168-19-000118:notes:196]
As of August 4, 2019 and November 4, 2018, approximately $4,582 million and $4,220 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-19-000118:notes:197]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $126 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-19-000118:notes:198]
[same as prior period, unchanged from 0001730168-19-000101:notes:189]

[0001730168-19-000118:notes:199]
[same as prior period, unchanged from 0001730168-19-000101:notes:190]

[0001730168-19-000118:notes:200]
[same as prior period, unchanged from 0001730168-19-000101:notes:191]

[0001730168-19-000118:notes:201]
[same as prior period, unchanged from 0001730168-19-000101:notes:192]

[0001730168-19-000118:notes:202]
[same as prior period, unchanged from 0001730168-19-000101:notes:193]

[0001730168-19-000118:notes:203]
[same as prior period, unchanged from 0001730168-19-000101:notes:194]

[0001730168-19-000118:notes:204]
[same as prior period, unchanged from 0001730168-19-000101:notes:195]

[0001730168-19-000118:notes:205]
[same as prior period, unchanged from 0001730168-19-000101:notes:196]

[0001730168-19-000118:notes:206]
[same as prior period, unchanged from 0001730168-19-000101:notes:197]

[0001730168-19-000118:notes:207]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,353 |  |  | $ | 4,568 |  |  | $ | 12,815 |  |  | $ | 14,060 |  |
| Infrastructure software |  | 1,140 |  |  | 492 |  |  | 3,956 |  |  | 1,267 |  |
| IP licensing |  | 22 |  |  | 3 |  |  | 50 |  |  | 77 |  |
| Total net revenue |  | $ | 5,515 |  |  | $ | 5,063 |  |  | $ | 16,821 |  |  | $ | 15,404 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,081 |  |  | $ | 2,192 |  |  | $ | 6,018 |  |  | $ | 6,644 |  |
| Infrastructure software |  | 829 |  |  | 352 |  |  | 2,899 |  |  | 878 |  |
| IP licensing |  | — |  |  | (11 | ) |  | (6 | ) |  | 30 |  |
| Unallocated expenses |  | (2,045 | ) |  | (1,194 | ) |  | (6,521 | ) |  | (4,069 | ) |
| Total operating income |  | $ | 865 |  |  | $ | 1,339 |  |  | $ | 2,390 |  |  | $ | 3,483 |  |

[0001730168-19-000118:notes:208]
[same as prior period, unchanged from 0001730168-19-000101:notes:199]

[0001730168-19-000118:notes:209]
We sell our products through our direct sales force and a select network of distributors globally. One customer accounted for 21% of our net accounts receivable balance at August 4, 2019, compared with two customers who accounted for 20% and 14% of our net accounts receivable balance at November 4, 2018.

[0001730168-19-000118:notes:210]
One customer accounted for 16% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Net revenue from this customer was included in our semiconductor solutions segment.

[0001730168-19-000118:notes:211]
No customer accounted for 10% or more of our net revenue for the fiscal quarter ended August 5, 2018. One customer accounted for 11% of our net revenue during the three fiscal quarters ended August 5, 2018. The majority of the revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-19-000118:notes:212]
Commitments and Contingencies
Commitments

[0001730168-19-000118:notes:213]
The following table summarizes contractual obligations and commitments as of August 4, 2019 that materially changed from the end of fiscal year 2018:

[0001730168-19-000118:notes:214]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 (remainder) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 44,728 |  |  | $ | 1,306 |  |  | $ | 5,207 |  |  | $ | 4,112 |  |  | $ | 8,930 |  |  | $ | 2,490 |  |  | $ | 22,683 |  |
| Purchase commitments |  | 802 |  |  | 697 |  |  | 60 |  |  | 45 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 187 |  |  | 55 |  |  | 92 |  |  | 23 |  |  | 10 |  |  | 7 |  |  | — |  |
| Operating lease obligations |  | 769 |  |  | 31 |  |  | 105 |  |  | 89 |  |  | 59 |  |  | 51 |  |  | 434 |  |
| Total |  | $ | 46,486 |  |  | $ | 2,089 |  |  | $ | 5,464 |  |  | $ | 4,269 |  |  | $ | 8,999 |  |  | $ | 2,548 |  |  | $ | 23,117 |  |

[0001730168-19-000118:notes:215]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 4, 2019.

[0001730168-19-000118:notes:216]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

[0001730168-19-000118:notes:217]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-19-000118:notes:218]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $61 million and $187 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Rent expense was $51 million and $178 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively.

[0001730168-19-000118:notes:219]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 4, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,361 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 4, 2019 have been excluded from the contractual obligations table above.

[0001730168-19-000118:notes:220]
Standby Letters of Credit

[0001730168-19-000118:notes:221]
As of August 4, 2019 and November 4, 2018, we had standby letters of credit of $65 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-19-000118:notes:222]
Contingencies

[0001730168-19-000118:notes:223]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-19-000118:notes:224]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-19-000118:notes:225]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On August 6, 2019, the U.S. Central District Court issued an order setting the briefing schedule for defendants’ motion to dismiss. We believe these claims are all without merit and intend to vigorously defend these actions.

[0001730168-19-000118:notes:226]
Other Matters

[0001730168-19-000118:notes:227]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-19-000118:notes:228]
Contingency Assessment

[0001730168-19-000118:notes:229]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-19-000118:notes:230]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-19-000118:notes:231]
Other Indemnifications

[0001730168-19-000118:notes:232]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001730168-19-000118:notes:233]
[same as prior period, unchanged from 0001730168-19-000101:notes:226]

[0001730168-19-000118:notes:234]
[same as prior period, unchanged from 0001730168-19-000101:notes:227]

[0001730168-19-000118:notes:235]
| • | During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $35 million and $710 million of restructuring expense primarily related to employee termination and lease and other exit costs during the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020. |

[0001730168-19-000118:notes:236]
| • | During the first quarter of fiscal year 2018, we initiated cost reduction activities associated with the acquisition of Brocade. As a result, we recognized $2 million of restructuring expense during the three fiscal quarters ended August 4, 2019 and $16 million and $159 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. These charges primarily related to employee termination costs. We have substantially completed the restructuring activities related to the acquisition of Brocade. |

[0001730168-19-000118:notes:237]
| • | In connection with cost reduction activities associated with the acquisition of BRCM, we recognized $4 million of restructuring expense during the three fiscal quarters ended August 4, 2019 and $4 million and $49 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. These restructuring expenses primarily related to lease and other exit costs. We have substantially completed the restructuring activities related to the acquisition of BRCM. |

[0001730168-19-000118:notes:238]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended August 4, 2019.

[0001730168-19-000118:notes:239]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 16 |  |  | $ | 6 |  |  | $ | 22 |  |
| Liabilities assumed from CA |  | 29 |  |  | 38 |  |  | 67 |  |
| Restructuring charges |  | 575 |  |  | 141 |  |  | 716 |  |
| Utilization |  | (500 | ) |  | (140 | ) |  | (640 | ) |
| Balance as of August 4, 2019 (a) |  | $ | 120 |  |  | $ | 45 |  |  | $ | 165 |  |

[0001730168-19-000118:notes:240]
[same as prior period, unchanged from 0001730168-19-000101:notes:232]

[0001730168-19-000118:notes:241]
(a) The majority of the employee termination costs balance is expected to be paid within the next 12 months. The majority of the leases and other exit costs balance is expected to be paid through fiscal year 2025.

[0001730168-19-000118:notes:242]
Impairment and Disposal Charges
During the fiscal quarter and three fiscal quarters ended August 4, 2019, we incurred impairment and disposal charges of $15 million and $50 million, respectively. During the fiscal quarter and three fiscal quarters ended August 5, 2018, we incurred impairment and disposal charges of $1 million and $13 million, respectively. These charges were primarily related to impairment and disposal of property, plant and equipment.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-19-000118:notes:243]
Condensed Consolidating Financial Information
As of November 4, 2018, certain debt obligations of Broadcom, consisting of $17,550 million in senior unsecured notes issued by BRCM and Cayman Finance in fiscal year 2017 (the “2017 Senior Notes”), were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom and Broadcom-Singapore. Substantially all of the 2017 Senior Notes have been registered with the SEC. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. BTI, a 100%-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with BRCM and Cayman Finance and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes under each of their respective indentures in accordance with their terms. On May 15, 2019, Cayman Finance was merged into BTI, with BTI remaining as the surviving entity. In connection with this merger, BTI remains a guarantor and became co-issuer of the 2017 Senior Notes.

[0001730168-19-000118:notes:244]
Accordingly, we updated the guarantor structure as of August 4, 2019, which resulted in the following revised column headings:

[0001730168-19-000118:notes:245]
| • | Parent Guarantor (Broadcom) |

[0001730168-19-000118:notes:246]
| • | Subsidiary Issuers (BTI and BRCM) |

[0001730168-19-000118:notes:247]
| • | Non-Guarantor Subsidiaries (our other subsidiaries) |

[0001730168-19-000118:notes:248]
We have applied the impacts of the change in guarantors and issuers retrospectively to all periods presented.

[0001730168-19-000118:notes:249]
The following information sets forth the condensed consolidating financial information for the Parent Guarantor, the Subsidiary Issuers, and our Non-Guarantor Subsidiaries for the periods presented in these condensed consolidated financial statements. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor, the Subsidiary Issuers and the Non-Guarantor Subsidiaries are reflected in the Eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.

[0001730168-19-000118:notes:250]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | August 4, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 203 |  |  | $ | 595 |  |  | $ | 4,664 |  |  | $ | — |  |  | $ | 5,462 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,539 |  |  | — |  |  | 3,539 |  |
| Inventory |  | — |  |  | — |  |  | 1,091 |  |  | — |  |  | 1,091 |  |
| Intercompany receivable |  | 92 |  |  | 750 |  |  | 462 |  |  | (1,304 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 10,319 |  |  | 8,605 |  |  | (18,924 | ) |  | — |  |
| Other current assets |  | 144 |  |  | 59 |  |  | 603 |  |  | — |  |  | 806 |  |
| Total current assets |  | 439 |  |  | 11,723 |  |  | 18,964 |  |  | (20,228 | ) |  | 10,898 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 761 |  |  | 1,850 |  |  | — |  |  | 2,611 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 35,326 |  |  | — |  |  | 36,686 |  |
| Intangible assets, net |  | — |  |  | 79 |  |  | 18,800 |  |  | — |  |  | 18,879 |  |
| Investment in subsidiaries |  | 52,248 |  |  | 46,526 |  |  | — |  |  | (98,774 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 932 |  |  | (932 | ) |  | — |  |
| Other long-term assets |  | 27 |  |  | 64 |  |  | 602 |  |  | — |  |  | 693 |  |
| Total assets |  | $ | 52,714 |  |  | $ | 60,513 |  |  | $ | 76,474 |  |  | $ | (119,934 | ) |  | $ | 69,767 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 35 |  |  | $ | 47 |  |  | $ | 914 |  |  | $ | — |  |  | $ | 996 |  |
| Employee compensation and benefits |  | — |  |  | 162 |  |  | 413 |  |  | — |  |  | 575 |  |
| Current portion of long-term debt |  | — |  |  | 2,750 |  |  | 787 |  |  | — |  |  | 3,537 |  |
| Intercompany payable |  | 492 |  |  | 38 |  |  | 774 |  |  | (1,304 | ) |  | — |  |
| Intercompany loan payable |  | 12,858 |  |  | 4,908 |  |  | 1,158 |  |  | (18,924 | ) |  | — |  |
| Other current liabilities |  | 157 |  |  | 45 |  |  | 2,972 |  |  | — |  |  | 3,174 |  |
| Total current liabilities |  | 13,542 |  |  | 7,950 |  |  | 7,018 |  |  | (20,228 | ) |  | 8,282 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 17,807 |  |  | 14,725 |  |  | 1,496 |  |  | — |  |  | 34,028 |  |
| Deferred tax liabilities |  | (65 | ) | (a) | (279 | ) | (a) | 2,004 |  |  | — |  |  | 1,660 |  |
| Intercompany loan payable, long-term |  | — |  |  | 932 |  |  | — |  |  | (932 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | 2,282 |  |  | 1,079 |  |  | — |  |  | 3,361 |  |
| Other long-term liabilities |  | (73 | ) | (b) | 236 |  |  | 770 |  |  | — |  |  | 933 |  |
| Total liabilities |  | 31,211 |  |  | 25,846 |  |  | 12,367 |  |  | (21,160 | ) |  | 48,264 |  |
| Total stockholders’ equity |  | 21,503 |  |  | 34,667 |  |  | 64,107 |  |  | (98,774 | ) |  | 21,503 |  |
| Total liabilities and stockholders’ equity |  | $ | 52,714 |  |  | $ | 60,513 |  |  | $ | 76,474 |  |  | $ | (119,934 | ) |  | $ | 69,767 |  |

[0001730168-19-000118:notes:251]
(a) Amount represents net deferred tax assets that are offset by net deferred tax liabilities on a consolidated basis.

[0001730168-19-000118:notes:252]
(b) Amount represents tax attribute assets that are offset by tax payables on a consolidated basis.

[0001730168-19-000118:notes:253]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | 2,461 |  |  | $ | 1,831 |  |  | $ | — |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,325 |  |  | — |  |  | 3,325 |  |
| Inventory |  | — |  |  | — |  |  | 1,124 |  |  | — |  |  | 1,124 |  |
| Intercompany receivable |  | 56 |  |  | 182 |  |  | 67 |  |  | (305 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 9,780 |  |  | 4,713 |  |  | (14,493 | ) |  | — |  |
| Other current assets |  | 52 |  |  | 37 |  |  | 277 |  |  | — |  |  | 366 |  |
| Total current assets |  | 108 |  |  | 12,460 |  |  | 11,337 |  |  | (14,798 | ) |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 772 |  |  | 1,863 |  |  | — |  |  | 2,635 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 25,553 |  |  | — |  |  | 26,913 |  |
| Intangible assets, net |  | — |  |  | 84 |  |  | 10,678 |  |  | — |  |  | 10,762 |  |
| Investment in subsidiaries |  | 35,268 |  |  | 46,742 |  |  | — |  |  | (82,010 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 991 |  |  | (991 | ) |  | — |  |
| Other long-term assets |  | — |  |  | 250 |  |  | 457 |  |  | — |  |  | 707 |  |
| Total assets |  | $ | 35,376 |  |  | $ | 61,668 |  |  | $ | 50,879 |  |  | $ | (97,799 | ) |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 19 |  |  | $ | 44 |  |  | $ | 748 |  |  | $ | — |  |  | $ | 811 |  |
| Employee compensation and benefits |  | — |  |  | 272 |  |  | 443 |  |  | — |  |  | 715 |  |
| Intercompany payable |  | 9 |  |  | 58 |  |  | 238 |  |  | (305 | ) |  | — |  |
| Intercompany loan payable |  | 8,691 |  |  | 4,713 |  |  | 1,089 |  |  | (14,493 | ) |  | — |  |
| Other current liabilities |  | — |  |  | 219 |  |  | 593 |  |  | — |  |  | 812 |  |
| Total current liabilities |  | 8,719 |  |  | 5,306 |  |  | 3,111 |  |  | (14,798 | ) |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | 17,456 |  |  | 37 |  |  | — |  |  | 17,493 |  |
| Deferred tax liabilities |  | — |  |  | (47 | ) | (a) | 216 |  |  | — |  |  | 169 |  |
| Intercompany loan payable, long-term |  | — |  |  | 991 |  |  | — |  |  | (991 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | 2,563 |  |  | 525 |  |  | — |  |  | 3,088 |  |
| Other long-term liabilities |  | — |  |  | 131 |  |  | 248 |  |  | — |  |  | 379 |  |
| Total liabilities |  | 8,719 |  |  | 26,400 |  |  | 4,137 |  |  | (15,789 | ) |  | 23,467 |  |
| Total stockholders’ equity |  | 26,657 |  |  | 35,268 |  |  | 46,742 |  |  | (82,010 | ) |  | 26,657 |  |
| Total liabilities and stockholders’ equity |  | $ | 35,376 |  |  | $ | 61,668 |  |  | $ | 50,879 |  |  | $ | (97,799 | ) |  | $ | 50,124 |  |

[0001730168-19-000118:notes:254]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | August 4, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 4,413 |  |  | $ | — |  |  | $ | 4,413 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 1,102 |  |  | — |  |  | 1,102 |  |
| Intercompany revenue |  | — |  |  | 403 |  |  | — |  |  | (403 | ) |  | — |  |
| Total net revenue |  | — |  |  | 403 |  |  | 5,515 |  |  | (403 | ) |  | 5,515 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 37 |  |  | 1,482 |  |  | — |  |  | 1,519 |  |
| Cost of subscriptions and services |  | — |  |  | 5 |  |  | 127 |  |  | — |  |  | 132 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 32 |  |  | (32 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 828 |  |  | — |  |  | 828 |  |
| Restructuring charges |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total cost of revenue |  | — |  |  | 42 |  |  | 2,471 |  |  | (32 | ) |  | 2,481 |  |
| Gross margin |  | — |  |  | 361 |  |  | 3,044 |  |  | (371 | ) |  | 3,034 |  |
| Research and development |  | — |  |  | 498 |  |  | 737 |  |  | — |  |  | 1,235 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 371 |  |  | (371 | ) |  | — |  |
| Selling, general and administrative |  | 11 |  |  | 93 |  |  | 306 |  |  | — |  |  | 410 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 475 |  |  | — |  |  | 475 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 3 |  |  | 46 |  |  | — |  |  | 49 |  |
| Total operating expenses |  | 11 |  |  | 594 |  |  | 1,935 |  |  | (371 | ) |  | 2,169 |  |
| Operating income (loss) |  | (11 | ) |  | (233 | ) |  | 1,109 |  |  | — |  |  | 865 |  |
| Interest expense |  | (187 | ) |  | (148 | ) |  | (27 | ) |  | — |  |  | (362 | ) |
| Intercompany interest expense |  | (89 | ) |  | (40 | ) |  | (9 | ) |  | 138 |  |  | — |  |
| Other income, net |  | 2 |  |  | 5 |  |  | 34 |  |  | — |  |  | 41 |  |
| Intercompany interest income |  | — |  |  | 74 |  |  | 64 |  |  | (138 | ) |  | — |  |
| Intercompany other income (expense), net |  | 161 |  |  | — |  |  | (161 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (124 | ) |  | (342 | ) |  | 1,010 |  |  | — |  |  | 544 |  |
| Benefit from income taxes |  | (84 | ) |  | (8 | ) |  | (79 | ) |  | — |  |  | (171 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (40 | ) |  | (334 | ) |  | 1,089 |  |  | — |  |  | 715 |  |
| Earnings in subsidiaries |  | 755 |  |  | 1,191 |  |  | — |  |  | (1,946 | ) |  | — |  |
| Net income |  | $ | 715 |  |  | $ | 857 |  |  | $ | 1,089 |  |  | $ | (1,946 | ) |  | $ | 715 |  |
| Comprehensive income |  | $ | 715 |  |  | $ | 857 |  |  | $ | 1,089 |  |  | $ | (1,946 | ) |  | $ | 715 |  |

[0001730168-19-000118:notes:255]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | August 5, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 4,783 |  |  | $ | — |  |  | $ | 4,783 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 280 |  |  | — |  |  | 280 |  |
| Intercompany revenue |  | — |  |  | 526 |  |  | — |  |  | (526 | ) |  | — |  |
| Total net revenue |  | — |  |  | 526 |  |  | 5,063 |  |  | (526 | ) |  | 5,063 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 28 |  |  | 1,628 |  |  | — |  |  | 1,656 |  |
| Cost of subscriptions and services |  | — |  |  | 3 |  |  | 21 |  |  | — |  |  | 24 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 31 |  |  | (31 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 762 |  |  | — |  |  | 762 |  |
| Restructuring charges |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total cost of revenue |  | — |  |  | 31 |  |  | 2,444 |  |  | (31 | ) |  | 2,444 |  |
| Gross margin |  | — |  |  | 495 |  |  | 2,619 |  |  | (495 | ) |  | 2,619 |  |
| Research and development |  | — |  |  | 394 |  |  | 565 |  |  | — |  |  | 959 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 495 |  |  | (495 | ) |  | — |  |
| Selling, general and administrative |  | 8 |  |  | 64 |  |  | 162 |  |  | — |  |  | 234 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 68 |  |  | — |  |  | 68 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 5 |  |  | 14 |  |  | — |  |  | 19 |  |
| Total operating expenses |  | 8 |  |  | 463 |  |  | 1,304 |  |  | (495 | ) |  | 1,280 |  |
| Operating income (loss) |  | (8 | ) |  | 32 |  |  | 1,315 |  |  | — |  |  | 1,339 |  |
| Interest expense |  | — |  |  | (149 | ) |  | — |  |  | — |  |  | (149 | ) |
| Intercompany interest expense |  | (15 | ) |  | (27 | ) |  | (296 | ) |  | 338 |  |  | — |  |
| Other income, net |  | — |  |  | 26 |  |  | 13 |  |  | — |  |  | 39 |  |
| Intercompany interest income |  | — |  |  | 311 |  |  | 27 |  |  | (338 | ) |  | — |  |
| Intercompany other income (expense), net |  | 67 |  |  | — |  |  | (67 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | 44 |  |  | 193 |  |  | 992 |  |  | — |  |  | 1,229 |  |
| Provision for (benefit from) income taxes |  | (28 | ) |  | 87 |  |  | (27 | ) |  | — |  |  | 32 |  |
| Income from continuing operations before earnings in subsidiaries |  | 72 |  |  | 106 |  |  | 1,019 |  |  | — |  |  | 1,197 |  |
| Earnings in subsidiaries |  | 1,124 |  |  | 1,018 |  |  | — |  |  | (2,142 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 1,196 |  |  | 1,124 |  |  | 1,019 |  |  | (2,142 | ) |  | 1,197 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income |  | $ | 1,196 |  |  | $ | 1,124 |  |  | $ | 1,018 |  |  | $ | (2,142 | ) |  | $ | 1,196 |  |
| Comprehensive income |  | $ | 1,196 |  |  | $ | 1,124 |  |  | $ | 1,018 |  |  | $ | (2,142 | ) |  | $ | 1,196 |  |

[0001730168-19-000118:notes:256]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 13,470 |  |  | $ | — |  |  | $ | 13,470 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 3,351 |  |  | — |  |  | 3,351 |  |
| Intercompany revenue |  | — |  |  | 1,220 |  |  | — |  |  | (1,220 | ) |  | — |  |
| Total net revenue |  | — |  |  | 1,220 |  |  | 16,821 |  |  | (1,220 | ) |  | 16,821 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 103 |  |  | 4,427 |  |  | — |  |  | 4,530 |  |
| Cost of subscriptions and services |  | — |  |  | 12 |  |  | 393 |  |  | — |  |  | 405 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 90 |  |  | (90 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 2,487 |  |  | — |  |  | 2,487 |  |
| Restructuring charges |  | — |  |  | (7 | ) |  | 75 |  |  | — |  |  | 68 |  |
| Total cost of revenue |  | — |  |  | 108 |  |  | 7,472 |  |  | (90 | ) |  | 7,490 |  |
| Gross margin |  | — |  |  | 1,112 |  |  | 9,349 |  |  | (1,130 | ) |  | 9,331 |  |
| Research and development |  | — |  |  | 1,408 |  |  | 2,111 |  |  | — |  |  | 3,519 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 1,130 |  |  | (1,130 | ) |  | — |  |
| Selling, general and administrative |  | 82 |  |  | 256 |  |  | 962 |  |  | — |  |  | 1,300 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 1,424 |  |  | — |  |  | 1,424 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 12 |  |  | 686 |  |  | — |  |  | 698 |  |
| Total operating expenses |  | 82 |  |  | 1,676 |  |  | 6,313 |  |  | (1,130 | ) |  | 6,941 |  |
| Operating income (loss) |  | (82 | ) |  | (564 | ) |  | 3,036 |  |  | — |  |  | 2,390 |  |
| Interest expense |  | (563 | ) |  | (443 | ) |  | (77 | ) |  | — |  |  | (1,083 | ) |
| Intercompany interest expense |  | (281 | ) |  | (123 | ) |  | (26 | ) |  | 430 |  |  | — |  |
| Other income, net |  | 2 |  |  | 21 |  |  | 149 |  |  | — |  |  | 172 |  |
| Intercompany interest income |  | — |  |  | 234 |  |  | 196 |  |  | (430 | ) |  | — |  |
| Intercompany other income (expense), net |  | 765 |  |  | — |  |  | (765 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (159 | ) |  | (875 | ) |  | 2,513 |  |  | — |  |  | 1,479 |  |
| Benefit from income taxes |  | (167 | ) |  | (195 | ) |  | (48 | ) |  | — |  |  | (410 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | 8 |  |  | (680 | ) |  | 2,561 |  |  | — |  |  | 1,889 |  |
| Earnings in subsidiaries |  | 1,869 |  |  | 3,542 |  |  | — |  |  | (5,411 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 1,877 |  |  | 2,862 |  |  | 2,561 |  |  | (5,411 | ) |  | 1,889 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Net income |  | $ | 1,877 |  |  | $ | 2,862 |  |  | $ | 2,549 |  |  | $ | (5,411 | ) |  | $ | 1,877 |  |
| Comprehensive income |  | $ | 1,877 |  |  | $ | 2,862 |  |  | $ | 2,549 |  |  | $ | (5,411 | ) |  | $ | 1,877 |  |

[0001730168-19-000118:notes:257]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 14,640 |  |  | $ | — |  |  | $ | 14,640 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 764 |  |  | — |  |  | 764 |  |
| Intercompany revenue |  | — |  |  | 1,676 |  |  | — |  |  | (1,676 | ) |  | — |  |
| Total net revenue |  | — |  |  | 1,676 |  |  | 15,404 |  |  | (1,676 | ) |  | 15,404 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 89 |  |  | 5,115 |  |  | — |  |  | 5,204 |  |
| Cost of subscriptions and services |  | — |  |  | 9 |  |  | 62 |  |  | — |  |  | 71 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 102 |  |  | (102 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 2,242 |  |  | — |  |  | 2,242 |  |
| Restructuring charges |  | — |  |  | 2 |  |  | 17 |  |  | — |  |  | 19 |  |
| Total cost of revenue |  | — |  |  | 100 |  |  | 7,608 |  |  | (102 | ) |  | 7,606 |  |
| Gross margin |  | — |  |  | 1,576 |  |  | 7,796 |  |  | (1,574 | ) |  | 7,798 |  |
| Research and development |  | — |  |  | 1,207 |  |  | 1,613 |  |  | — |  |  | 2,820 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 1,574 |  |  | (1,574 | ) |  | — |  |
| Selling, general and administrative |  | 10 |  |  | 221 |  |  | 588 |  |  | — |  |  | 819 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 474 |  |  | — |  |  | 474 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 49 |  |  | 153 |  |  | — |  |  | 202 |  |
| Total operating expenses |  | 10 |  |  | 1,477 |  |  | 4,402 |  |  | (1,574 | ) |  | 4,315 |  |
| Operating income (loss) |  | (10 | ) |  | 99 |  |  | 3,394 |  |  | — |  |  | 3,483 |  |
| Interest expense |  | — |  |  | (478 | ) |  | (2 | ) |  | — |  |  | (480 | ) |
| Intercompany interest expense |  | (15 | ) |  | (167 | ) |  | (1,389 | ) |  | 1,571 |  |  | — |  |
| Other income, net |  | — |  |  | 73 |  |  | 47 |  |  | — |  |  | 120 |  |
| Intercompany interest income |  | — |  |  | 1,404 |  |  | 167 |  |  | (1,571 | ) |  | — |  |
| Intercompany other income (expense), net |  | 67 |  |  | (57 | ) |  | (10 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | 42 |  |  | 874 |  |  | 2,207 |  |  | — |  |  | 3,123 |  |
| Benefit from income taxes |  | (28 | ) |  | (7,894 | ) |  | (469 | ) |  | — |  |  | (8,391 | ) |
| Income from continuing operations before earnings in subsidiaries |  | 70 |  |  | 8,768 |  |  | 2,676 |  |  | — |  |  | 11,514 |  |
| Earnings in subsidiaries |  | 11,074 |  |  | 2,659 |  |  | — |  |  | (13,733 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 11,144 |  |  | 11,427 |  |  | 2,676 |  |  | (13,733 | ) |  | 11,514 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (2 | ) |  | (17 | ) |  | — |  |  | (19 | ) |
| Net income |  | 11,144 |  |  | 11,425 |  |  | 2,659 |  |  | (13,733 | ) |  | 11,495 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 11,144 |  |  | $ | 11,074 |  |  | $ | 2,659 |  |  | $ | (13,733 | ) |  | $ | 11,144 |  |
| Net income |  | $ | 11,144 |  |  | $ | 11,425 |  |  | $ | 2,659 |  |  | $ | (13,733 | ) |  | $ | 11,495 |  |
| Other comprehensive income |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Comprehensive income |  | 11,144 |  |  | 11,425 |  |  | 2,660 |  |  | (13,733 | ) |  | 11,496 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Comprehensive income attributable to common stock |  | $ | 11,144 |  |  | $ | 11,074 |  |  | $ | 2,660 |  |  | $ | (13,733 | ) |  | $ | 11,145 |  |

[0001730168-19-000118:notes:258]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,877 |  |  | $ | 2,862 |  |  | $ | 2,549 |  |  | $ | (5,411 | ) |  | $ | 1,877 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (1,521 | ) |  | (3,842 | ) |  | 5,293 |  |  | 5,411 |  |  | 5,341 |  |
| Net cash provided by (used in) operating activities |  | 356 |  |  | (980 | ) |  | 7,842 |  |  | — |  |  | 7,218 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | 800 |  |  | (539 | ) |  | (6,827 | ) |  | 6,566 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | (17,865 | ) |  | — |  |  | 1,832 |  |  | — |  |  | (16,033 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 957 |  |  | — |  |  | 957 |  |
| Purchases of property, plant and equipment |  | — |  |  | (121 | ) |  | (228 | ) |  | 13 |  |  | (336 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 13 |  |  | 82 |  |  | (13 | ) |  | 82 |  |
| Purchases of investments |  | (5 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Proceeds from sales of investments |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Other |  | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net cash used in investing activities |  | (17,070 | ) |  | (647 | ) |  | (4,183 | ) |  | 6,566 |  |  | (15,334 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Net intercompany borrowings |  | 7,167 |  |  | 130 |  |  | (731 | ) |  | (6,566 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 28,793 |  |  | — |  |  | — |  |  | — |  |  | 28,793 |  |
| Repayment of debt |  | (12,000 | ) |  | — |  |  | — |  |  | — |  |  | (12,000 | ) |
| Payment of debt issuance costs |  | (46 | ) |  | — |  |  | — |  |  | — |  |  | (46 | ) |
| Other borrowings |  | 992 |  |  | — |  |  | 353 |  |  | — |  |  | 1,345 |  |
| Dividend and distribution payments |  | (3,181 | ) |  | — |  |  | — |  |  | — |  |  | (3,181 | ) |
| Repurchases of common stock - repurchase program |  | (5,002 | ) |  | — |  |  | — |  |  | — |  |  | (5,002 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (369 | ) |  | (449 | ) |  | — |  |  | (818 | ) |
| Issuance of common stock |  | 194 |  |  | — |  |  | — |  |  | — |  |  | 194 |  |
| Other |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net cash provided by (used in) financing activities |  | 16,917 |  |  | (239 | ) |  | (826 | ) |  | (6,566 | ) |  | 9,286 |  |
| Net change in cash and cash equivalents |  | 203 |  |  | (1,866 | ) |  | 2,833 |  |  | — |  |  | 1,170 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | 2,461 |  |  | 1,831 |  |  | — |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 203 |  |  | $ | 595 |  |  | $ | 4,664 |  |  | $ | — |  |  | $ | 5,462 |  |

[0001730168-19-000118:notes:259]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 11,144 |  |  | $ | 11,425 |  |  | $ | 2,659 |  |  | $ | (13,733 | ) |  | $ | 11,495 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (11,112 | ) |  | (11,672 | ) |  | 3,572 |  |  | 13,962 |  |  | (5,250 | ) |
| Net cash provided by (used in) operating activities |  | 32 |  |  | (247 | ) |  | 6,231 |  |  | 229 |  |  | 6,245 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | (9,099 | ) |  | (3,002 | ) |  | 12,101 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | — |  |  | 1,521 |  |  | (1,521 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | 4,140 |  |  | 1,169 |  |  | (5,309 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (4,793 | ) |  | — |  |  | (4,793 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 782 |  |  | — |  |  | 782 |  |
| Purchases of property, plant and equipment |  | — |  |  | (168 | ) |  | (396 | ) |  | 35 |  |  | (529 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 31 |  |  | 242 |  |  | (35 | ) |  | 238 |  |
| Purchases of investments |  | — |  |  | (50 | ) |  | (199 | ) |  | — |  |  | (249 | ) |
| Proceeds from sales of investments |  | — |  |  | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Other |  | — |  |  | (50 | ) |  | (9 | ) |  | — |  |  | (59 | ) |
| Net cash used in investing activities |  | — |  |  | (5,142 | ) |  | (4,685 | ) |  | 5,271 |  |  | (4,556 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | 3,231 |  |  | 9,099 |  |  | (12,330 | ) |  | — |  |
| Net intercompany borrowings |  | 6,397 |  |  | (1,141 | ) |  | (10,565 | ) |  | 5,309 |  |  | — |  |
| Repayment of debt |  | — |  |  | — |  |  | (856 | ) |  | — |  |  | (856 | ) |
| Dividend and distribution payments |  | (754 | ) |  | (1,521 | ) |  | (1,521 | ) |  | 1,521 |  |  | (2,275 | ) |
| Repurchases of common stock - repurchase program |  | (5,725 | ) |  | — |  |  | — |  |  | — |  |  | (5,725 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (12 | ) |  | (23 | ) |  | — |  |  | (35 | ) |
| Issuance of common stock |  | 50 |  |  | — |  |  | 103 |  |  | — |  |  | 153 |  |
| Other |  | — |  |  | — |  |  | (19 | ) |  | — |  |  | (19 | ) |
| Net cash provided by (used in) financing activities |  | (32 | ) |  | 557 |  |  | (3,782 | ) |  | (5,500 | ) |  | (8,757 | ) |
| Net change in cash and cash equivalents |  | — |  |  | (4,832 | ) |  | (2,236 | ) |  | — |  |  | (7,068 | ) |
| Cash and cash equivalents at beginning of period |  | — |  |  | 7,555 |  |  | 3,649 |  |  | — |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 2,723 |  |  | $ | 1,413 |  |  | $ | — |  |  | $ | 4,136 |  |


## us-gaap:SubsequentEventsTextBlock

[0001730168-19-000118:notes:260]
Subsequent Event
Cash Dividends Declared

[0001730168-19-000118:notes:261]
On September 11, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on October 1, 2019 to stockholders of record at the close of business on September 23, 2019.
