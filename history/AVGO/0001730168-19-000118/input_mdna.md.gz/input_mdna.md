# AVGO MD&A — 0001730168-19-000118


## mdna

[0001730168-19-000118:mdna:1]
[same as prior period, unchanged from 0001730168-19-000101:mdna:1]

[0001730168-19-000118:mdna:2]
[same as prior period, unchanged from 0001730168-19-000101:mdna:2]

[0001730168-19-000118:mdna:3]
[same as prior period, unchanged from 0001730168-19-000101:mdna:3]

[0001730168-19-000118:mdna:4]
[same as prior period, unchanged from 0001730168-19-000101:mdna:4]

[0001730168-19-000118:mdna:5]
[same as prior period, unchanged from 0001730168-19-000101:mdna:5]

[0001730168-19-000118:mdna:6]
Quarterly Highlights

[0001730168-19-000118:mdna:7]
Highlights during the third fiscal quarter ended August 4, 2019 include the following:

[0001730168-19-000118:mdna:8]
| • | we generated $2,419 million of cash from operations; and |

[0001730168-19-000118:mdna:9]
| • | we paid $1,057 million for cash dividends, $736 million to repurchase shares of our common stock under our stock repurchase program and $241 million in employee withholding taxes related to net share settled equity awards. |

[0001730168-19-000118:mdna:10]
Recent Developments

[0001730168-19-000118:mdna:11]
On August 8, 2019, we entered into an asset purchase agreement (the “Symantec Purchase Agreement”) with Symantec Corporation (“Symantec”) to purchase certain assets and assume certain liabilities of Symantec’s Enterprise Security business (the “Symantec Business”) for approximately $10.7 billion in cash, on a cash-free, debt-free basis (the “Symantec Asset Purchase”). The Symantec Purchase Agreement provides that, following the closing of the Symantec Asset Purchase, each party will have certain indemnification obligations, including with respect to breaches of covenants and for losses arising from certain assumed or retained liabilities, as applicable. We and Symantec may terminate the agreement if the closing of the Symantec Asset Purchase has not occurred on or before February 8, 2020, subject to a three-month extension in certain circumstances.

[0001730168-19-000118:mdna:12]
In connection with the Symantec Purchase Agreement, we entered into a commitment letter, with certain financial institutions to provide (i) up to $12 billion in term loans to fund the Symantec Asset Purchase and related working capital needs and (ii) $3.5 billion in term loans to refinance certain existing senior notes maturing in the first quarter of our fiscal year 2020 (which begins on November 4, 2019).

[0001730168-19-000118:mdna:13]
[same as prior period, unchanged from 0001730168-19-000101:mdna:12]

[0001730168-19-000118:mdna:14]
[same as prior period, unchanged from 0001730168-19-000101:mdna:13]

[0001730168-19-000118:mdna:15]
On November 5, 2018, we completed the acquisition of CA for aggregate consideration of approximately $18.8 billion (the “CA Merger”) in exchange for all shares of CA common stock issued and outstanding immediately prior to the CA Merger. In addition, we assumed all outstanding unvested CA equity awards held by continuing employees. All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon completion of the CA Merger. We financed the CA Merger with proceeds of $18 billion from unsecured term loan facilities, as well as cash on hand of the combined companies.

[0001730168-19-000118:mdna:16]
[same as prior period, unchanged from 0001730168-19-000101:mdna:15]

[0001730168-19-000118:mdna:17]
[same as prior period, unchanged from 0001730168-19-000101:mdna:16]

[0001730168-19-000118:mdna:18]
[same as prior period, unchanged from 0001730168-19-000101:mdna:17]

[0001730168-19-000118:mdna:19]
[same as prior period, unchanged from 0001730168-19-000101:mdna:18]

[0001730168-19-000118:mdna:20]
Refer to Note 2. “Revenue from Contracts with Customers” in Part I, Item 1 of this Form 10-Q for updates on critical accounting estimates related to revenue recognition. There were no other significant changes in our critical accounting policies during the three fiscal quarters ended August 4, 2019 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2018 Annual Report on Form 10-K.

[0001730168-19-000118:mdna:21]
[same as prior period, unchanged from 0001730168-19-000101:mdna:21]

[0001730168-19-000118:mdna:22]
Fiscal Quarter and Three Fiscal Quarters Ended August 4, 2019 Compared to Fiscal Quarter and Three Fiscal Quarters Ended August 5, 2018

[0001730168-19-000118:mdna:23]
[same as prior period, unchanged from 0001730168-19-000101:mdna:23]

[0001730168-19-000118:mdna:24]
|  |  | Fiscal Quarter Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |  | (As a percentage of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,413 |  |  | $ | 4,783 |  |  | 80 | % |  | 94 | % |
| Subscriptions and services |  | 1,102 |  |  | 280 |  |  | 20 |  |  | 6 |  |
| Total net revenue |  | 5,515 |  |  | 5,063 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,519 |  |  | 1,656 |  |  | 28 |  |  | 33 |  |
| Cost of subscriptions and services |  | 132 |  |  | 24 |  |  | 2 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 828 |  |  | 762 |  |  | 15 |  |  | 15 |  |
| Restructuring charges |  | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,481 |  |  | 2,444 |  |  | 45 |  |  | 48 |  |
| Gross margin |  | 3,034 |  |  | 2,619 |  |  | 55 |  |  | 52 |  |
| Research and development |  | 1,235 |  |  | 959 |  |  | 22 |  |  | 19 |  |
| Selling, general and administrative |  | 410 |  |  | 234 |  |  | 7 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 475 |  |  | 68 |  |  | 9 |  |  | 2 |  |
| Restructuring, impairment and disposal charges |  | 49 |  |  | 19 |  |  | 1 |  |  | — |  |
| Total operating expenses |  | 2,169 |  |  | 1,280 |  |  | 39 |  |  | 26 |  |
| Operating income |  | $ | 865 |  |  | $ | 1,339 |  |  | 16 | % |  | 26 | % |

[0001730168-19-000118:mdna:25]
[same as prior period, unchanged from 0001730168-19-000101:mdna:31]

[0001730168-19-000118:mdna:26]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |  | (As a percentage of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 13,470 |  |  | $ | 14,640 |  |  | 80 | % |  | 95 | % |
| Subscriptions and services |  | 3,351 |  |  | 764 |  |  | 20 |  |  | 5 |  |
| Total net revenue |  | 16,821 |  |  | 15,404 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,530 |  |  | 5,204 |  |  | 27 |  |  | 34 |  |
| Cost of subscriptions and services |  | 405 |  |  | 71 |  |  | 2 |  |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | 70 |  |  | — |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 2,487 |  |  | 2,242 |  |  | 15 |  |  | 15 |  |
| Restructuring charges |  | 68 |  |  | 19 |  |  | 1 |  |  | — |  |
| Total cost of revenue |  | 7,490 |  |  | 7,606 |  |  | 45 |  |  | 49 |  |
| Gross margin |  | 9,331 |  |  | 7,798 |  |  | 55 |  |  | 51 |  |
| Research and development |  | 3,519 |  |  | 2,820 |  |  | 21 |  |  | 19 |  |
| Selling, general and administrative |  | 1,300 |  |  | 819 |  |  | 8 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,424 |  |  | 474 |  |  | 8 |  |  | 3 |  |
| Restructuring, impairment and disposal charges |  | 698 |  |  | 202 |  |  | 4 |  |  | 1 |  |
| Total operating expenses |  | 6,941 |  |  | 4,315 |  |  | 41 |  |  | 28 |  |
| Operating income |  | $ | 2,390 |  |  | $ | 3,483 |  |  | 14 | % |  | 23 | % |

[0001730168-19-000118:mdna:27]
[same as prior period, unchanged from 0001730168-19-000101:mdna:27]

[0001730168-19-000118:mdna:28]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 16% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. No customer accounted for 10% or more of our net revenue for the fiscal quarter ended August 5, 2018. Foxconn Technology Group companies (including Hon Hai Precision Industries), contract manufacturers, accounted for 11% of our net revenue for the three fiscal quarters ended August 5, 2018. We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 33% and 34% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, and approximately 38% and 42% of our net revenue for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 4, 2019 and for the fiscal quarter ended August 5, 2018, and more than 20% for the three fiscal quarters ended August 5, 2018. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-19-000118:mdna:29]
[same as prior period, unchanged from 0001730168-19-000101:mdna:29]

[0001730168-19-000118:mdna:30]
45

[0001730168-19-000118:mdna:31]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-19-000118:mdna:32]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | August 4, 2019 |  | August 5, 2018 |  | $ Change |  | % Change |  | August 4, 2019 |  | August 5, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,353 |  |  | $ | 4,568 |  |  | $ | (215 | ) |  | (5 | )% |  | $ | 12,815 |  |  | $ | 14,060 |  |  | $ | (1,245 | ) |  | (9 | )% |
| Infrastructure software |  | 1,140 |  |  | 492 |  |  | 648 |  |  | 132 | % |  | 3,956 |  |  | 1,267 |  |  | 2,689 |  |  | 212 | % |
| IP licensing |  | 22 |  |  | 3 |  |  | 19 |  |  | 633 | % |  | 50 |  |  | 77 |  |  | (27 | ) |  | (35 | )% |
| Total net revenue |  | $ | 5,515 |  |  | $ | 5,063 |  |  | $ | 452 |  |  | 9 | % |  | $ | 16,821 |  |  | $ | 15,404 |  |  | $ | 1,417 |  |  | 9 | % |

[0001730168-19-000118:mdna:33]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| % of Net Revenue by Segment |  | August 4, 2019 |  | August 5, 2018 |  | August 4, 2019 |  | August 5, 2018 |
| Semiconductor solutions |  | 79 | % |  | 90 | % |  | 76 | % |  | 92 | % |
| Infrastructure software |  | 21 |  |  | 10 |  |  | 24 |  |  | 8 |  |
| IP licensing |  | — |  |  | — |  |  | — |  |  | — |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-19-000118:mdna:34]
Fiscal quarter ended August 4, 2019 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment has been negatively impacted by a broad-based slowdown in demand for semiconductor products worldwide and has decreased primarily due to lower demand for our set-top box, broadband, optocoupler and solid-state drive controller products, as well as lower demand for wireless content in mobile handsets. These decreases were partially offset by higher demand for our networking products. Net revenue from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, offset by lower demand for our FC SAN products.

[0001730168-19-000118:mdna:35]
Three fiscal quarters ended August 4, 2019 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to lower demand for our wireless content in mobile handsets, as well as lower demand for our broadband, server storage connectivity, optocoupler and set-top box products. These decreases were partially offset by higher demand for our networking products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. We expect the effects of export restrictions on one of our largest customers to continue to adversely impact our revenue in the last quarter of fiscal year 2019. Net revenue from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as higher demand for our FC SAN products.

[0001730168-19-000118:mdna:36]
[same as prior period, unchanged from 0001730168-19-000101:mdna:35]

[0001730168-19-000118:mdna:37]
Gross margin was $3,034 million for the fiscal quarter ended August 4, 2019 compared to $2,619 million for the fiscal quarter ended August 5, 2018. Gross margin was $9,331 million for the three fiscal quarters ended August 4, 2019 compared to $7,798 million for the three fiscal quarters ended August 5, 2018. As a percentage of net revenue, gross margin was 55% and 52% for the fiscal quarters ended August 4, 2019 and August 5, 2018, respectively, and 55% and 51% for the three fiscal quarters ended August 4, 2019 and August 5, 2018, respectively.

[0001730168-19-000118:mdna:38]
The increase in gross margin for the fiscal quarter and three fiscal quarters ended August 4, 2019, was primarily due to contributions from our CA mainframe and enterprise software products and favorable product mix within our semiconductor solutions segment. The increase in gross margin for the three fiscal quarters ended August 4, 2019 was also due to favorable gross margin impact from our FC SAN products. These increases were partially offset by higher amortization of acquisition-related intangible assets as a result of the CA Merger and higher stock-based compensation expense. The increase in gross margin for the three fiscal quarters ended August 4, 2019 was partially offset by higher restructuring charges as a result of the CA Merger.

[0001730168-19-000118:mdna:39]
[same as prior period, unchanged from 0001730168-19-000101:mdna:38]

[0001730168-19-000118:mdna:40]
Research and development expense increased $276 million, or 29%, and $699 million, or 25%, for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to the prior year fiscal periods. These increases were primarily due to the acquisition of CA and higher stock-based compensation expense. The increases in stock-based compensation expense primarily resulted from the issuance of multi-year equity grants of time- and market-based restricted

[0001730168-19-000118:mdna:41]
stock units (the “Multi-Year Equity Awards”) in the first quarter of fiscal year 2019, the impact of the change from annual to quarterly vesting of equity awards and assumed CA equity awards. Our stock-based compensation expense for the fiscal year 2019 periods included employee equity awards with higher grant-date fair values than those in the corresponding fiscal year 2018 periods, which also contributed to the increase.

[0001730168-19-000118:mdna:42]
[same as prior period, unchanged from 0001730168-19-000101:mdna:40]

[0001730168-19-000118:mdna:43]
Selling, general and administrative expense increased $176 million, or 75%, and $481 million, or 59%, for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to the prior year fiscal periods. These increases were primarily due to the acquisition of CA and stock-based compensation expense. The increases in stock-based compensation expense primarily resulted from the issuance of the Multi-Year Equity Awards, the impact of the change from annual to quarterly vesting of equity awards and assumed CA equity awards. Our stock-based compensation expense for the fiscal year 2019 periods included employee equity awards with higher grant-date fair values than those in the corresponding fiscal year 2018 periods, which also contributed to the increase.

[0001730168-19-000118:mdna:44]
[same as prior period, unchanged from 0001730168-19-000101:mdna:42]

[0001730168-19-000118:mdna:45]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $407 million and $950 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to amortization of intangible assets acquired in the CA Merger.

[0001730168-19-000118:mdna:46]
[same as prior period, unchanged from 0001730168-19-000101:mdna:44]

[0001730168-19-000118:mdna:47]
Restructuring, impairment and disposal charges recognized in operating expenses increased $30 million and $496 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to employee termination costs, as well as lease and other exit costs resulting from the CA Merger. We expect to incur additional restructuring charges in future periods as a result of the CA Merger and any future acquisitions we may make. See Note 12. “Restructuring, Impairment and Disposal Charges” in Part I, Item 1 of this Form 10-Q for more details.

[0001730168-19-000118:mdna:48]
[same as prior period, unchanged from 0001730168-19-000101:mdna:46]

[0001730168-19-000118:mdna:49]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Operating Income (Loss) by Segment |  | August 4, 2019 |  | August 5, 2018 |  | $ Change |  | % Change |  | August 4, 2019 |  | August 5, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 2,081 |  |  | $ | 2,192 |  |  | $ | (111 | ) |  | (5 | )% |  | $ | 6,018 |  |  | $ | 6,644 |  |  | $ | (626 | ) |  | (9 | )% |
| Infrastructure software |  | 829 |  |  | 352 |  |  | 477 |  |  | 136 | % |  | 2,899 |  |  | 878 |  |  | 2,021 |  |  | 230 | % |
| IP licensing |  | — |  |  | (11 | ) |  | 11 |  |  | (100 | )% |  | (6 | ) |  | 30 |  |  | (36 | ) |  | (120 | )% |
| Unallocated expenses |  | (2,045 | ) |  | (1,194 | ) |  | (851 | ) |  | 71 | % |  | (6,521 | ) |  | (4,069 | ) |  | (2,452 | ) |  | 60 | % |
| Total operating income |  | $ | 865 |  |  | $ | 1,339 |  |  | $ | (474 | ) |  | (35 | )% |  | $ | 2,390 |  |  | $ | 3,483 |  |  | $ | (1,093 | ) |  | (31 | )% |

[0001730168-19-000118:mdna:50]
Fiscal quarter ended August 4, 2019 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand in our set-top box, optocoupler, broadband, and solid-state controller products, as well as lower wireless content in mobile handsets. These decreases were partially offset by higher demand for our networking products. Operating income from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, offset by a decrease in demand for our FC SAN products.

[0001730168-19-000118:mdna:51]
Three fiscal quarters ended August 4, 2019 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand in our wireless content in mobile handsets, as well as lower demand for our optocoupler, broadband, and server storage connectivity products. These decreases were partially offset by higher demand for our networking products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. Operating income from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as an increase in demand for our FC SAN products.

[0001730168-19-000118:mdna:52]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 71% and 60% for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher amortization of acquisition-related intangible assets, acquisition-related costs and restructuring,

[0001730168-19-000118:mdna:53]
impairment and disposal charges. These increases were primarily due to the CA Merger. Unallocated expenses also increased due to stock-based compensation expense primarily due to the issuance of the Multi-Year Equity Awards and the impact of the change from annual to quarterly vesting of certain time-based equity awards.

[0001730168-19-000118:mdna:54]
[same as prior period, unchanged from 0001730168-19-000101:mdna:51]

[0001730168-19-000118:mdna:55]
Interest expense. Interest expense was $362 million and $1,083 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, compared to $149 million and $480 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. These increases were primarily due to interest on the debt we incurred to finance the CA Merger in the first quarter of fiscal year 2019. We expect to incur additional interest expense in future periods as a result of term loan indebtedness associated with any future acquisitions, including the pending acquisition of the Symantec Business.

[0001730168-19-000118:mdna:56]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $41 million and $172 million for the fiscal quarter and three fiscal quarters ended August 4, 2019 compared to $39 million and $120 million for the fiscal quarter and three fiscal quarters ended August 5, 2018. These increases were primarily due to increases in unrealized gains on investments.

[0001730168-19-000118:mdna:57]
Provision for (benefit from) income taxes. For the fiscal quarter and three fiscal quarters ended August 4, 2019, our benefit from income taxes was $171 million and $410 million, respectively, compared to a provision for income taxes of $32 million and a benefit from income taxes of $8,391 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively. The decrease in tax benefit for the three fiscal quarters ended August 4, 2019 was primarily due to tax effects of a change in law, resulting from the enactment of the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”) in the prior year fiscal period.

[0001730168-19-000118:mdna:58]
The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 4, 2019, was primarily due to a benefit from deferred tax remeasurement in a foreign jurisdiction, a tax benefit related to internal reorganizations, and excess tax benefits from stock-based awards that vested or were exercised during the period. The current year fiscal periods also include the impact of several provisions of the 2017 Tax Reform Act that take effect for us for the first time in fiscal year 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000118:mdna:59]
Additionally, for the three fiscal quarters ended August 4, 2019, our benefit from income taxes was due to recognition of gross uncertain tax benefits as a result of audit settlements, lapses of statutes of limitations and a partial release of our valuation allowance resulting from the CA Merger, partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the 2017 Tax Reform Act.

[0001730168-19-000118:mdna:60]
The provision for income taxes for the fiscal quarter ended August 5, 2018 was primarily due to profits from continuing operations, partially offset by a net discrete benefit which included excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-19-000118:mdna:61]
The benefit from income taxes for the three fiscal quarters ended August 5, 2018 was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act, signed into law on December 22, 2017 and the Redomiciliation Transaction. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017.

[0001730168-19-000118:mdna:62]
[same as prior period, unchanged from 0001730168-19-000101:mdna:59]

[0001730168-19-000118:mdna:63]
[same as prior period, unchanged from 0001730168-19-000101:mdna:60]

[0001730168-19-000118:mdna:64]
Our primary sources of liquidity as of August 4, 2019 consisted of: (i) $5,462 million in cash and cash equivalents, (ii) cash we expect to generate from operations, (iii) available capacity under our $5 billion revolving credit facility (the “Revolving Facility”), and (iv) available capacity under our $2 billion commercial paper program. In addition, we may also generate cash from the sale of assets from time to time.

[0001730168-19-000118:mdna:65]
48

[0001730168-19-000118:mdna:66]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including our pending acquisition of the Symantec Business, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to outstanding indebtedness, (vi) payment of income taxes, including taxes resulting from the intercompany transfer of IP, and (vii) stock repurchases, if any. In April 2018, we began settling withholding tax amounts due upon vesting of compensatory equity awards using cash on hand, and withholding from the grant recipient that number of shares having a value equivalent to the withholding tax amount (“Tax Shares”). This net settlement method reduces the dilutive effects of such awards as they vest. Previously, Tax Shares were issued and mandatorily sold into the market, and the cash proceeds were used to pay such withholding tax amounts. This change results in an increased use of our cash as our outstanding equity awards vest. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-19-000118:mdna:67]
Our debt and liquidity needs will also increase as a result of the pending acquisition of the Symantec Business. We intend to fund the estimated $10.7 billion of cash consideration needed for that transaction with new debt financing. However, we expect our capital expenditures for fiscal year 2019 will be lower than fiscal year 2018.

[0001730168-19-000118:mdna:68]
We believe that our cash and cash equivalents on hand and cash flows from operations, combined with current borrowing availability under the Revolving Facility and our commercial paper program, as well as our committed debt funding related to the pending acquisition of the Symantec Business, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-19-000118:mdna:69]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may also seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-19-000118:mdna:70]
[same as prior period, unchanged from 0001730168-19-000101:mdna:67]

[0001730168-19-000118:mdna:71]
Working capital decreased to $2,616 million at August 4, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-19-000118:mdna:72]
| • | Current portion of long-term debt increased to $3,537 million at August 4, 2019 due to certain debt instruments becoming due within the next twelve months. |

[0001730168-19-000118:mdna:73]
| • | Other current liabilities increased to $3,174 million at August 4, 2019 from $812 million at November 4, 2018, primarily due to the CA Merger and increases in contract liabilities from adoption of Accounting Standard Codification Topic 606 (“Topic 606”), notional pooling liabilities, restructuring reserves, taxes payable and interest payable. |

[0001730168-19-000118:mdna:74]
| • | Accounts payable increased to $996 million at August 4, 2019 from $811 million at November 4, 2018, primarily due to timing of vendor payments and increases due to the CA Merger. |

[0001730168-19-000118:mdna:75]
| • | Inventory decreased to $1,091 million at August 4, 2019 from $1,124 million at November 4, 2018 primarily due to consumption to support customer shipments. |

[0001730168-19-000118:mdna:76]
[same as prior period, unchanged from 0001730168-19-000101:mdna:72]

[0001730168-19-000118:mdna:77]
| • | Cash and cash equivalents increased to $5,462 million at August 4, 2019 from $4,292 million at November 4, 2018, primarily due to $30,138 million in proceeds from borrowings, $7,218 million in net cash provided by operating activities and $957 million in proceeds from the sale of Veracode, partially offset by $16,027 million paid for the CA Merger, $12 billion of debt repayments, $5,002 million of common stock repurchases and $3,181 million of dividend payments. |

[0001730168-19-000118:mdna:78]
| • | Other current assets increased to $806 million at August 4, 2019 from $366 million at November 4, 2018, primarily due to assets acquired in the CA Merger and increases in contract assets from adoption of Topic 606 and prepaid taxes. |

[0001730168-19-000118:mdna:79]
| • | Accounts receivable increased to $3,539 million at August 4, 2019 from $3,325 million at November 4, 2018 primarily due to revenue linearity and an increase due to the CA Merger, partially offset by $375 million of receivables sold through factoring arrangements. |

[0001730168-19-000118:mdna:80]
[same as prior period, unchanged from 0001730168-19-000101:mdna:97]

[0001730168-19-000118:mdna:81]
| • | Employee compensation and benefits liabilities decreased to $575 million at August 4, 2019 from $715 million at November 4, 2018 primarily due to the timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger. |

[0001730168-19-000118:mdna:82]
Working capital decreased to $6,508 million at August 5, 2018 from $13,294 million at October 29, 2017. The decrease was attributable to the following:

[0001730168-19-000118:mdna:83]
| • | Our cash and cash equivalents decreased to $4,136 million at August 5, 2018 from $11,204 million at October 29, 2017, primarily due to $5,725 million of common stock repurchases, $4,780 million paid for Brocade Communications Systems, Inc. (“Brocade”), and $2,275 million of dividend and distribution payments, partially offset by $6,245 million in net cash provided by operating activities. |

[0001730168-19-000118:mdna:84]
| • | Other current assets decreased to $333 million at August 5, 2018 from $724 million at October 29, 2017, primarily due to lower prepaid expenses and prepaid taxes as a result of the 2017 Tax Reform Act. |

[0001730168-19-000118:mdna:85]
| • | Inventory decreased to $1,216 million at August 5, 2018 from $1,447 million at October 29, 2017, primarily due to the timing of a major customer's new handset ramp. |

[0001730168-19-000118:mdna:86]
[same as prior period, unchanged from 0001730168-19-000101:mdna:81]

[0001730168-19-000118:mdna:87]
| • | Accounts receivable increased to $3,010 million at August 5, 2018 from $2,448 million at October 29, 2017, primarily due to Brocade FC SAN revenue. Days sales outstanding increased to 54 days at August 5, 2018 compared to 46 days at October 29, 2017, driven by higher revenue in the last month of the fiscal quarter ended August 5, 2018 and a temporary extension of payment terms to support the Brocade FC SAN distributor consolidation. This increase was partially offset by $305 million of receivables sold through factoring arrangements. |

[0001730168-19-000118:mdna:88]
| • | Accounts payable decreased to $785 million at August 5, 2018 from $1,105 million at October 29, 2017, primarily due to timing of vendor payments. |

[0001730168-19-000118:mdna:89]
[same as prior period, unchanged from 0001730168-19-000101:mdna:85]

[0001730168-19-000118:mdna:90]
[same as prior period, unchanged from 0001730168-19-000101:mdna:86]

[0001730168-19-000118:mdna:91]
During the three fiscal quarters ended August 4, 2019, we repurchased and retired approximately 19 million shares of our common stock at a weighted average price of $256.79 under this stock repurchase program. As of August 4, 2019, $5,740 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000118:mdna:92]
[same as prior period, unchanged from 0001730168-19-000101:mdna:88]

[0001730168-19-000118:mdna:93]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 7.95 |  |  | $ | 5.25 |  |
| Cash dividends and distributions paid |  | $ | 3,181 |  |  | $ | 2,275 |  |
| Stock repurchases |  | $ | 5,002 |  |  | $ | 5,725 |  |

[0001730168-19-000118:mdna:94]
In addition, during the three fiscal quarters ended August 4, 2019, we paid approximately $818 million in employee withholding taxes due upon the vesting of, and related to net settled equity awards. We withheld approximately 3 million shares of common stock from employees in connection with such net share settlements.

[0001730168-19-000118:mdna:95]
50

[0001730168-19-000118:mdna:96]
[same as prior period, unchanged from 0001730168-19-000101:mdna:91]

[0001730168-19-000118:mdna:97]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4, 2019 |  | August 5, 2018 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 7,218 |  |  | $ | 6,245 |  |
| Net cash used in investing activities |  | (15,334 | ) |  | (4,556 | ) |
| Net cash provided by (used in) financing activities |  | 9,286 |  |  | (8,757 | ) |
| Net change in cash and cash equivalents |  | $ | 1,170 |  |  | $ | (7,068 | ) |

[0001730168-19-000118:mdna:98]
[same as prior period, unchanged from 0001730168-19-000101:mdna:93]

[0001730168-19-000118:mdna:99]
Cash provided by operating activities primarily consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. The $973 million increase in cash provided by operations during the three fiscal quarters ended August 4, 2019 compared to the three fiscal quarters ended August 5, 2018 was due to the impact of net income and changes in assets and liabilities, partially offset by adjustments for non-cash items. Net income in each period reflects significant non-cash benefits from income taxes. For the three fiscal quarters ended August 4, 2019, the non-cash income tax benefit of $708 million principally resulted from the recognition of uncertain tax benefits due to audit settlements and lapses of statutes of limitations as well as the release of a portion of our valuation allowance as a result of the CA Merger. The non-cash income tax benefit for the three fiscal quarters ended August 5, 2018 principally resulted from the enactment of the 2017 Tax Reform Act. These non-cash benefits are included in the deferred taxes and other non-cash taxes line in the condensed consolidated statement of cash flows. Other non-cash adjustments to net income during the three fiscal quarters ended August 4, 2019, as compared to the three fiscal quarters ended August 5, 2018, primarily included increases in amortization of intangible assets, stock-based compensation and restructuring charges. In addition, cash provided by operating activities in each period was affected by changes in working capital, as discussed above.

[0001730168-19-000118:mdna:100]
[same as prior period, unchanged from 0001730168-19-000101:mdna:95]

[0001730168-19-000118:mdna:101]
Cash used in investing activities primarily consisted of cash used for acquisitions, capital expenditures and investments, partially offset by proceeds from sales of businesses and assets. The $10,778 million increase in cash used in investing activities during the three fiscal quarters ended August 4, 2019 compared to the three fiscal quarters ended August 5, 2018 was primarily related to $16,027 million paid for the CA Merger in the three fiscal quarters ended August 4, 2019 compared to $4,780 million paid for the acquisition of Brocade in the three fiscal quarters ended August 5, 2018, partially offset by decreases of $244 million in purchases of investments and $193 million in capital expenditures and an increase of $175 million in proceeds from sales of businesses.

[0001730168-19-000118:mdna:102]
[same as prior period, unchanged from 0001730168-19-000101:mdna:99]

[0001730168-19-000118:mdna:103]
Cash from financing activities primarily consisted of net proceeds and payments related to our long-term-debt, dividend and distribution payments, stock repurchases, and the issuance of common stock pursuant to our employee equity incentive award plans. The $18,043 million increase in cash provided by financing activities during the three fiscal quarters ended August 4, 2019 compared to the three fiscal quarters ended August 5, 2018 was primarily due to an increase of $18,994 million in net proceeds from borrowings, partially offset by an increase of $60 million in common stock repurchases and an increase of $906 million of dividend payments.

[0001730168-19-000118:mdna:104]
[same as prior period, unchanged from 0001730168-19-000101:mdna:101]

[0001730168-19-000118:mdna:105]
[same as prior period, unchanged from 0001730168-19-000101:mdna:102]

[0001730168-19-000118:mdna:106]
[same as prior period, unchanged from 0001730168-19-000101:mdna:103]

[0001730168-19-000118:mdna:107]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000118:mdna:108]
[same as prior period, unchanged from 0001730168-19-000101:mdna:105]

[0001730168-19-000118:mdna:109]
We had no material off-balance sheet arrangements at August 4, 2019 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-19-000118:mdna:110]
[same as prior period, unchanged from 0001730168-19-000101:mdna:107]

[0001730168-19-000118:mdna:111]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000118:mdna:112]
51

[0001730168-19-000118:mdna:113]
[same as prior period, unchanged from 0001730168-19-000101:mdna:109]

[0001730168-19-000118:mdna:114]
[same as prior period, unchanged from 0001730168-19-000101:mdna:110]
