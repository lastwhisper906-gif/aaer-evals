# AVGO MD&A — 0001730168-23-000096


## mdna

[0001730168-23-000096:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-23-000096:mdna:2]
The following section generally discusses our financial condition and results of operations for our fiscal year ended October 29, 2023 (“fiscal year 2023”) compared to our fiscal year ended October 30, 2022 (“fiscal year 2022”). A discussion regarding our financial condition and results of operations for fiscal year 2022 compared to our fiscal year ended October 31, 2021 (“fiscal year 2021”) can be found in Part II, Item 7 of our Annual Report on Form 10-K for fiscal year 2022, filed with the Securities and Exchange Commission (the “SEC”) on December 16, 2022.

[0001730168-23-000096:mdna:3]
Overview

[0001730168-23-000096:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-23-000096:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our mainframe, distributed and cyber security solutions, and our FC SAN business.

[0001730168-23-000096:mdna:6]
Our strategy is to combine best-of-breed technology leadership in semiconductor and infrastructure software solutions, with unmatched scale, on a common sales and administrative platform to deliver a comprehensive suite of infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through responsibly financed acquisitions of category-leading businesses and technologies, as well as investing extensively in research and development, to ensure our products retain their technology leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-23-000096:mdna:7]
The demand for our products has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-23-000096:mdna:8]
•gain or loss of significant customers;

[0001730168-23-000096:mdna:9]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-23-000096:mdna:10]
•our distributors’ product inventory and end customer demand;

[0001730168-23-000096:mdna:11]
•the rate at which our present and future customers and end-users adopt our products and technologies in our target markets, and the rate at which our customers' products that include our technology are accepted in their markets;

[0001730168-23-000096:mdna:12]
•the shift to cloud-based information technology solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our products for use in traditional enterprise data centers; and

[0001730168-23-000096:mdna:13]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-23-000096:mdna:14]
Fiscal Year Highlights

[0001730168-23-000096:mdna:15]
Highlights during fiscal year 2023 include the following:

[0001730168-23-000096:mdna:16]
•We generated $18,085 million of cash from operations.

[0001730168-23-000096:mdna:17]
•We paid $7,645 million in cash dividends.

[0001730168-23-000096:mdna:18]
•We repurchased $5,824 million of common stock.

[0001730168-23-000096:mdna:19]
Acquisition of VMware, Inc.

[0001730168-23-000096:mdna:20]
On November 22, 2023, we completed the acquisition of VMware in a cash-and-stock transaction (the “VMware Merger”). Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30.8 billion in cash and 54.4 million shares of Broadcom common stock in aggregate.

[0001730168-23-000096:mdna:21]
We assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into approximately 5 million Broadcom RSU awards. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-23-000096:mdna:22]
VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities.

[0001730168-23-000096:mdna:23]
The preliminary purchase consideration for the VMware Merger was approximately $86.3 billion. We funded the cash portion of the VMware Merger with net proceeds from the issuance of $30.4 billion in term loans under a credit agreement that we entered into on August 15, 2023 (the “2023 Credit Agreement”), as well as cash on hand. See Note 15. “Subsequent Events” included in Part II, Item 8 of this Annual Report on Form 10-K for additional information.

[0001730168-23-000096:mdna:24]
The discussions below related to our business and financial results for fiscal year 2023 and prior periods do not include any impact from or information relating to the VMware Merger.

[0001730168-23-000096:mdna:25]
Net Revenue

[0001730168-23-000096:mdna:26]
A majority of our net revenue is derived from sales of a broad range of semiconductor devices that are incorporated into electronic products, as well as from modules, switches and subsystems. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, automate, manage, and secure applications across mainframe, distributed, mobile, and cloud platforms.

[0001730168-23-000096:mdna:27]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, have varied from quarter to quarter, due largely to fluctuations in end-market demand, including the effects of seasonality, which are discussed in detail in Part I, Item 1. Business under “Seasonality” of this Annual Report on Form 10-K.

[0001730168-23-000096:mdna:28]
Distributors and original equipment manufacturers (“OEMs”), or their contract manufacturers, typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive IP portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon the delivery of our products to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-23-000096:mdna:29]
Our software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-23-000096:mdna:30]
Costs and Expenses

[0001730168-23-000096:mdna:31]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense, related occupancy, computer services, equipment costs, manufacturing quality, order fulfillment, warranty adjustments, inventory adjustments

[0001730168-23-000096:mdna:32]
including write-downs for inventory obsolescence, and acquisition costs, which include direct transaction costs and acquisition-related costs.

[0001730168-23-000096:mdna:33]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-23-000096:mdna:34]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-23-000096:mdna:35]
Total cost of revenue also includes amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-23-000096:mdna:36]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-23-000096:mdna:37]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs and other corporate expenses.

[0001730168-23-000096:mdna:38]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are being amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with the acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-23-000096:mdna:39]
Restructuring and other charges.  Restructuring and other charges consist primarily of non-recurring charges related to IP litigation, compensation costs associated with employee exit programs, alignment of our global manufacturing operations, rationalizing product development program costs, facility and lease abandonments, fixed asset impairment, IPR&D impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-23-000096:mdna:40]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-23-000096:mdna:41]
Other income (expense), net.  Other income (expense), net includes interest income, gains or losses on investments, foreign currency remeasurement, and other miscellaneous items.

[0001730168-23-000096:mdna:42]
Provision for income taxes.  We have structured our operations to maximize the benefit from tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are presently expected to expire in November 2025. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday from our qualifying income earned in Malaysia, which is scheduled to expire in 2028.

[0001730168-23-000096:mdna:43]
Each tax incentive and tax holiday is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday decreased the provision for income taxes by approximately $2,104 million and $1,821 million for fiscal years 2023 and 2022, respectively.

[0001730168-23-000096:mdna:44]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect or if these tax incentives are substantially modified or rescinded, we could suffer material adverse tax and other financial consequences, which would increase our expenses, reduce our profitability and

[0001730168-23-000096:mdna:45]
adversely affect our cash flows. In addition, taxable income in any jurisdiction is dependent upon acceptance of our operational practices and intercompany transfer pricing by local tax authorities as being on an arm’s length basis. Due to inconsistencies in application of the arm’s length standard among taxing authorities, as well as lack of adequate treaty-based protection, transfer pricing challenges by tax authorities could, if successful, substantially increase our income tax expense.

[0001730168-23-000096:mdna:46]
Critical Accounting Estimates

[0001730168-23-000096:mdna:47]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting periods. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, valuation of goodwill and long-lived assets, and income taxes. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-23-000096:mdna:48]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-23-000096:mdna:49]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-23-000096:mdna:50]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-23-000096:mdna:51]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance, including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting the financial multiples of comparable companies and applying a control premium. A reporting unit's

[0001730168-23-000096:mdna:52]
carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-23-000096:mdna:53]
We assess the impairment of long-lived assets, including purchased IPR&D, property, plant and equipment, right-of-use assets, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment, and intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business to which the long-lived assets relate. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived assets stated on our consolidated balance sheets to reflect their estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-23-000096:mdna:54]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition.

[0001730168-23-000096:mdna:55]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax laws and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-23-000096:mdna:56]
Fiscal Year Presentation

[0001730168-23-000096:mdna:57]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal years 2023, 2022 and 2021 each consisted of 52 weeks.

[0001730168-23-000096:mdna:58]
The financial statements included in Part II, Item 8. of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-23-000096:mdna:59]
Results of Operations

[0001730168-23-000096:mdna:60]
Fiscal Year 2023 Compared to Fiscal Year 2022

[0001730168-23-000096:mdna:61]
The following table sets forth our results of operations for the periods presented:

[0001730168-23-000096:mdna:62]
|  |  | Fiscal Year Ended |
|  |  | October 29,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 27,891 |  |  | $ | 26,277 |  |  | 78 | % |  | 79 | % |
| Subscriptions and services |  | 7,928 |  |  | 6,926 |  |  | 22 |  |  | 21 |  |
| Total net revenue |  | 35,819 |  |  | 33,203 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 8,636 |  |  | 7,629 |  |  | 24 |  |  | 23 |  |
| Cost of subscriptions and services |  | 636 |  |  | 627 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,853 |  |  | 2,847 |  |  | 5 |  |  | 8 |  |
| Restructuring charges |  | 4 |  |  | 5 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 11,129 |  |  | 11,108 |  |  | 31 |  |  | 33 |  |
| Gross margin |  | 24,690 |  |  | 22,095 |  |  | 69 |  |  | 67 |  |
| Research and development |  | 5,253 |  |  | 4,919 |  |  | 15 |  |  | 15 |  |
| Selling, general and administrative |  | 1,592 |  |  | 1,382 |  |  | 4 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 1,394 |  |  | 1,512 |  |  | 4 |  |  | 5 |  |
| Restructuring and other charges |  | 244 |  |  | 57 |  |  | 1 |  |  | — |  |
| Total operating expenses |  | 8,483 |  |  | 7,870 |  |  | 24 |  |  | 24 |  |
| Operating income |  | $ | 16,207 |  |  | $ | 14,225 |  |  | 45 | % |  | 43 | % |

[0001730168-23-000096:mdna:63]
Net Revenue

[0001730168-23-000096:mdna:64]
A relatively small number of customers account for a significant portion of our net revenue. Sales of products to distributors accounted for 57% and 56% of our net revenue for fiscal years 2023 and 2022, respectively. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 21% and 20% of our net revenue for fiscal years 2023 and 2022, respectively. We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of fiscal years 2023 and 2022. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of fiscal years 2023 and 2022. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-23-000096:mdna:65]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile devices. In addition, the macroeconomic environment remains uncertain and may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-23-000096:mdna:66]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based primarily on the geographic shipment or delivery location specified by our distributors, OEMs, contract manufacturers, channel partners, or software customers. In fiscal years 2023 and 2022, 32% and 35%, respectively, of our net revenue came from shipments or deliveries to China (including Hong Kong). However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-23-000096:mdna:67]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-23-000096:mdna:68]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | October 29,2023 |  | October 30,2022 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 28,182 |  |  | $ | 25,818 |  |  | $ | 2,364 |  |  | 9 | % |
| Infrastructure software |  | 7,637 |  |  | 7,385 |  |  | 252 |  |  | 3 | % |
| Total net revenue |  | $ | 35,819 |  |  | $ | 33,203 |  |  | $ | 2,616 |  |  | 8 | % |

[0001730168-23-000096:mdna:69]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | October 29, 2023 |  | October 30, 2022 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 79 | % |  | 78 | % |
| Infrastructure software |  | 21 |  |  | 22 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-23-000096:mdna:70]
Net revenue from our semiconductor solutions segment increased due to strong product demand, primarily for networking, server storage and broadband products. Net revenue from our infrastructure software segment increased primarily due to increases in sales from our mainframe solutions, partially offset by lower demand for our FC SAN products.

[0001730168-23-000096:mdna:71]
Gross Margin

[0001730168-23-000096:mdna:72]
Gross margin was $24,690 million, or 69% of net revenue, for fiscal year 2023, compared to $22,095 million, or 67% of net revenue, for fiscal year 2022. The increase was primarily due to lower amortization of acquisition-related intangible assets, mainly from our 2016 acquisition of Broadcom Corporation, partially offset by less favorable margin within our semiconductor solutions segment driven by product mix. We expect to incur additional amortization of acquisition-related intangible assets in future periods as a result of the VMware Merger and any further acquisitions we may make.

[0001730168-23-000096:mdna:73]
Research and Development Expense

[0001730168-23-000096:mdna:74]
Research and development expense increased $334 million, or 7%, in fiscal year 2023, compared to the prior fiscal year. The increase was primarily due to higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values in fiscal year 2023, partially offset by lower variable employee compensation expense. We expect to incur additional research and development expense in future periods as a result of the VMware Merger and any further acquisitions we may make.

[0001730168-23-000096:mdna:75]
Selling, General and Administrative Expense

[0001730168-23-000096:mdna:76]
Selling, general and administrative expense increased $210 million, or 15%, in fiscal year 2023, compared to the prior fiscal year. The increase was primarily due to higher costs incurred in connection with the VMware Merger and higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values in fiscal year 2023, partially offset by lower variable employee compensation expense.

[0001730168-23-000096:mdna:77]
Amortization of Acquisition-Related Intangible Assets

[0001730168-23-000096:mdna:78]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $118 million, or 8%, in fiscal year 2023, compared to the prior fiscal year. The decrease was primarily due to lower amortization of customer-related intangible assets from our acquisition of LSI Corporation. We expect to incur additional amortization of acquisition-related intangible assets in future periods as a result of the VMware Merger and any further acquisitions we may make.

[0001730168-23-000096:mdna:79]
Restructuring and Other Charges

[0001730168-23-000096:mdna:80]
Restructuring and other charges in fiscal year 2023 primarily included non-recurring charges related to IP litigation. We expect to incur additional restructuring and other charges in future periods as a result of the VMware Merger and any further acquisitions we may make.

[0001730168-23-000096:mdna:81]
Stock-Based Compensation Expense

[0001730168-23-000096:mdna:82]
Total stock-based compensation expense was $2,171 million and $1,533 million for fiscal years 2023 and 2022, respectively. The increase was primarily due to annual employee equity awards granted at higher grant-date fair values in fiscal year 2023. We expect to incur additional stock-based compensation expense in future periods as a result of the VMware Merger and any further acquisitions we may make.

[0001730168-23-000096:mdna:83]
43

[0001730168-23-000096:mdna:84]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of October 29, 2023. The remaining weighted-average service period was 3.4 years.

[0001730168-23-000096:mdna:85]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2024 |  | $ | 2,279 |  |
| 2025 |  | 1,845 |  |
| 2026 |  | 1,407 |  |
| 2027 |  | 715 |  |
| 2028 |  | 129 |  |
| Total |  | $ | 6,375 |  |

[0001730168-23-000096:mdna:86]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made on March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-23-000096:mdna:87]
Segment Operating Results

[0001730168-23-000096:mdna:88]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | October 29, 2023 |  | October 30, 2022 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 16,486 |  |  | $ | 15,075 |  |  | $ | 1,411 |  |  | 9 | % |
| Infrastructure software |  | 5,639 |  |  | 5,219 |  |  | 420 |  |  | 8 | % |
| Unallocated expenses |  | (5,918) |  |  | (6,069) |  |  | 151 |  |  | (2) | % |
| Total operating income |  | $ | 16,207 |  |  | $ | 14,225 |  |  | $ | 1,982 |  |  | 14 | % |

[0001730168-23-000096:mdna:89]
Operating income from our semiconductor solutions segment increased primarily due to higher net revenue from networking, server storage, and broadband products. Operating income from our infrastructure software segment increased primarily due to higher net revenue from our mainframe solutions, partially offset by lower net revenue from our FC SAN products.

[0001730168-23-000096:mdna:90]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 2% in fiscal year 2023, compared to the prior fiscal year, primarily due to lower amortization of acquisition-related intangible assets, substantially offset by higher stock-based compensation expense, non-recurring charges related to IP litigation, and acquisition-related costs.

[0001730168-23-000096:mdna:91]
Non-Operating Income and Expenses

[0001730168-23-000096:mdna:92]
Interest expense.  Interest expense was $1,622 million and $1,737 million for fiscal years 2023 and 2022, respectively. The decrease was due to losses on extinguishment of debt related to debt transactions incurred in fiscal year 2022. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the VMware Merger.

[0001730168-23-000096:mdna:93]
Other income (expense), net.  Other income (expense), net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $512 million for fiscal year 2023, compared to other expense, net, of $54 million for fiscal year 2022. The change was primarily due to higher interest income as a result of higher interest rates and changes in investment gains or losses.

[0001730168-23-000096:mdna:94]
Provision for income taxes.  The provision for income taxes was $1,015 million and $939 million for fiscal years 2023 and 2022, respectively. The increase was primarily due to higher income before income taxes, partially offset by an increase in the recognition of uncertain tax benefits as a result of lapses of statutes of limitations.

[0001730168-23-000096:mdna:95]
Liquidity and Capital Resources

[0001730168-23-000096:mdna:96]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-23-000096:mdna:97]
Our primary sources of liquidity as of October 29, 2023 consisted of: (i) $14,189 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-23-000096:mdna:98]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $40,815 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2024 as compared to fiscal year 2023. Our debt and liquidity needs increased as a result of completing the VMware Merger. We funded the cash portion of the consideration with net proceeds from the issuance of $30,390 million in term loans under the 2023 Credit Agreement, as well as cash on hand. We also assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-23-000096:mdna:99]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations, indebtedness and lease obligations, see Note 13. “Commitments and Contingencies”, Note 9. “Borrowings” and Note 5. “Leases” in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-23-000096:mdna:100]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, the term loans we issued to fund the VMware Merger, and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-23-000096:mdna:101]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0001730168-23-000096:mdna:102]
Working Capital

[0001730168-23-000096:mdna:103]
Working capital increased to $13,442 million at October 29, 2023 from $11,452 million at October 30, 2022. The increase was attributable to the following:

[0001730168-23-000096:mdna:104]
•Cash and cash equivalents increased to $14,189 million at October 29, 2023 from $12,416 million at October 30, 2022, primarily due to $18,085 million in net cash provided by operating activities, partially offset by $7,645 million of dividend payments, $5,824 million of common stock repurchases, and $1,861 million of employee withholding tax payments related to net settled equity awards.

[0001730168-23-000096:mdna:105]
•Other current liabilities decreased to $3,652 million at October 29, 2023 from $4,412 million at October 30, 2022, primarily due to decreases in contract liabilities and income taxes payable.

[0001730168-23-000096:mdna:106]
•Other current assets increased to $1,606 million at October 29, 2023 from $1,205 million at October 30, 2022, primarily due to an increase in contract assets, offset in part by a decrease in prepaid income taxes.

[0001730168-23-000096:mdna:107]
•Employee compensation and benefits decreased to $935 million at October 29, 2023 from $1,202 million at October 30, 2022, primarily due to lower variable compensation.

[0001730168-23-000096:mdna:108]
•Accounts receivable increased to $3,154 million at October 29, 2023 from $2,958 million at October 30, 2022, primarily due to revenue linearity, offset in part by additional receivables sold through factoring arrangements.

[0001730168-23-000096:mdna:109]
45

[0001730168-23-000096:mdna:110]
These increases in working capital were offset in part by the following:

[0001730168-23-000096:mdna:111]
•Current portion of long-term debt increased to $1,608 million at October 29, 2023 from $440 million at October 30, 2022, primarily due to certain debt instruments becoming due within the next twelve months, offset in part by repayments.

[0001730168-23-000096:mdna:112]
•Accounts payable increased to $1,210 million at October 29, 2023 from $998 million at October 30, 2022, primarily due to the timing of vendor payments.

[0001730168-23-000096:mdna:113]
Capital Returns

[0001730168-23-000096:mdna:114]
|  |  | Fiscal Year Ended |
| Cash Dividends Declared and Paid |  | October 29, 2023 |  | October 30, 2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 18.40 |  |  | $ | 16.40 |  |
| Dividends to common stockholders |  | $ | 7,645 |  |  | $ | 6,733 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 80.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 299 |  |

[0001730168-23-000096:mdna:115]
On September 30, 2019, we issued approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share. These shares were converted into shares of our common stock during fiscal year 2022.

[0001730168-23-000096:mdna:116]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022, which was subsequently extended through December 31, 2023. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023. As of October 29, 2023, $7,176 million of the authorized amount remained available for repurchases.

[0001730168-23-000096:mdna:117]
During fiscal years 2023 and 2022, we repurchased and retired approximately 9 million and 12 million shares of our common stock for $5,824 million and $7,000 million, respectively, under these stock repurchase programs.

[0001730168-23-000096:mdna:118]
Repurchases under our stock repurchase programs may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-23-000096:mdna:119]
During fiscal years 2023 and 2022, we paid approximately $1,861 million and $1,455 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 3 million shares of common stock from employees in connection with such net share settlements during each of fiscal years 2023 and 2022.

[0001730168-23-000096:mdna:120]
Cash Flows

[0001730168-23-000096:mdna:121]
|  |  | Fiscal Year Ended |
|  |  | October 29, 2023 |  | October 30, 2022 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 18,085 |  |  | $ | 16,736 |  |
| Net cash used in investing activities |  | (689) |  |  | (667) |  |
| Net cash used in financing activities |  | (15,623) |  |  | (15,816) |  |
| Net change in cash and cash equivalents |  | $ | 1,773 |  |  | $ | 253 |  |

[0001730168-23-000096:mdna:122]
Operating Activities

[0001730168-23-000096:mdna:123]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,349 million increase in cash provided by operations during fiscal year 2023 compared to fiscal year 2022 was due to $2,587 million higher net income, offset in part by $1,249 million lower non-cash adjustments primarily from lower amortization of intangible assets.

[0001730168-23-000096:mdna:124]
Investing Activities

[0001730168-23-000096:mdna:125]
Cash flows from investing activities primarily consisted of capital expenditures, sales and purchases of investments, and cash used for acquisitions. The $22 million increase in cash used in investing activities for fiscal year 2023 compared to fiscal year 2022 was primarily due to a $118 million increase in purchases of investments, net of proceeds from sales of investments, offset by a $193 million decrease in cash paid for acquisitions.

[0001730168-23-000096:mdna:126]
Financing Activities

[0001730168-23-000096:mdna:127]
Cash flows from financing activities primarily consisted of dividend payments, stock repurchases, proceeds and payments related to our long-term borrowings, and employee withholding tax payments related to net settled equity awards. The $193 million decrease in cash used in financing activities for fiscal year 2023 compared to fiscal year 2022 was primarily due to a $1,958 million decrease in payments on debt obligations and a $1,176 million decrease in stock repurchases, offset by a $1,935 million decrease in proceeds from long-term borrowings, a $613 million increase in dividend payments and a $406 million increase in employee withholding tax payments related to net settled equity awards.
