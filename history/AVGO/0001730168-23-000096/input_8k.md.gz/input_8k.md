# AVGO 8-K — 0001730168-23-000093 filed 2023-12-07

## item codes, every 8-K on or before 2023-12-14

- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2023-12-14

- none on or before 2023-12-14

## item 2.02 — earnings release, exhibit 99.1

[0001730168-23-000093:8k_2_02:1]
EX-99.1
2
avgo-10292023x8kxex99.htm
EX-99.1

[0001730168-23-000093:8k_2_02:2]
Document

[0001730168-23-000093:8k_2_02:3]
Exhibit 99.1

[0001730168-23-000093:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2023 Financial Results and Quarterly Dividend

[0001730168-23-000093:8k_2_02:5]
•Revenue of $9,295 million for the fourth quarter, up 4 percent from the prior year period

[0001730168-23-000093:8k_2_02:6]
•Cash from operations of $4,828 million for the fourth quarter, less capital expenditures of $105 million, resulted in $4,723 million of free cash flow, or 51 percent of revenue

[0001730168-23-000093:8k_2_02:7]
•Quarterly common stock dividend increased by 14 percent from the prior quarter to $5.25

[0001730168-23-000093:8k_2_02:8]
•Adjusted EBITDA of $6,048 million for the fourth quarter, or 65 percent of revenue

[0001730168-23-000093:8k_2_02:9]
•Non-GAAP diluted EPS of $11.06 for the fourth quarter; GAAP diluted EPS of $8.25 for the fourth quarter

[0001730168-23-000093:8k_2_02:10]
•Fiscal 2024 annual revenue guidance of approximately $50.0 billion including contribution from VMware, an increase of 40 percent from the prior year period

[0001730168-23-000093:8k_2_02:11]
•Fiscal 2024 annual Adjusted EBITDA guidance of approximately 60 percent of projected revenue (1)

[0001730168-23-000093:8k_2_02:12]
PALO ALTO, Calif. – December 7, 2023 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year ended October 29, 2023, provided guidance for its fiscal year 2024 and announced its quarterly dividend.

[0001730168-23-000093:8k_2_02:13]
“Broadcom’s fiscal year 2023 revenue grew 8% year-over-year to a record $35.8 billion, driven by investments in accelerators and network connectivity for AI by hyperscalers,” said Hock Tan, President and CEO of Broadcom Inc. “The acquisition of VMware is transformational. In fiscal year 2024 we expect semiconductor to sustain its mid to high single digit revenue growth rate, with the contribution of VMware driving consolidated revenue to $50 billion, and adjusted EBITDA to $30 billion.”

[0001730168-23-000093:8k_2_02:14]
“In fiscal year 2023 we achieved record adjusted EBITDA margin of 65%, generating $17.6 billion in free cash flow or 49% of revenue, demonstrating our stable and diversified business model,” said Kirsten Spears, CFO of Broadcom Inc. “With this transformational acquisition and expected increase in cash flows, we are increasing our quarterly common stock dividend by 14% to $5.25 per share for fiscal year 2024. The target fiscal 2024 annual common stock dividend of $21.00 per share is a record, and the thirteenth consecutive increase in annual dividends since we initiated dividends in fiscal 2011.”

[0001730168-23-000093:8k_2_02:15]
Fourth Quarter Fiscal Year 2023 Financial Highlights

[0001730168-23-000093:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 23 |  | Q4 22 |  | Change |  | Q4 23 |  | Q4 22 |  | Change |
| Net revenue |  | $ | 9,295 |  |  | $ | 8,930 |  |  | +4 | % |  | $ | 9,295 |  |  | $ | 8,930 |  |  | +4 | % |
| Net income |  | $ | 3,524 |  |  | $ | 3,359 |  |  | +$165 |  |  | $ | 4,810 |  |  | $ | 4,544 |  |  | +$266 |  |
| Earnings per common share - diluted |  | $ | 8.25 |  |  | $ | 7.83 |  |  | +$0.42 |  |  | $ | 11.06 |  |  | $ | 10.45 |  |  | +$0.61 |  |

[0001730168-23-000093:8k_2_02:17]
________________________________

[0001730168-23-000093:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-23-000093:8k_2_02:19]
1

[0001730168-23-000093:8k_2_02:20]
| (Dollars in millions) |  | Q4 23 |  | Q4 22 |  | Change |  |
| Cash flow from operations |  | $ | 4,828 |  |  | $ | 4,583 |  |  | +$245 |  |
| Adjusted EBITDA |  | $ | 6,048 |  |  | $ | 5,722 |  |  | +$326 |  |
| Free cash flow |  | $ | 4,723 |  |  | $ | 4,461 |  |  | +$262 |  |

[0001730168-23-000093:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 23 |  |  |  | Q4 22 |  | Change |  |
| Semiconductor solutions |  | $ | 7,326 |  |  | 79 | % |  |  |  |  |  |  | $ | 7,092 |  |  | 79 | % |  | +3 | % |  |
| Infrastructure software |  | 1,969 |  |  | 21 |  |  |  |  |  |  |  | 1,838 |  |  | 21 |  |  | +7 | % |  |
| Total net revenue |  | $ | 9,295 |  |  | 100 | % |  |  |  |  |  |  | $ | 8,930 |  |  | 100 | % |  |  |  |  |

[0001730168-23-000093:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $14,189 million, compared to $12,055 million at the end of the prior quarter.

[0001730168-23-000093:8k_2_02:23]
During the fourth fiscal quarter, the Company generated $4,828 million in cash from operations and spent $105 million on capital expenditures.

[0001730168-23-000093:8k_2_02:24]
On September 29, 2023, the Company paid a cash dividend of $4.60 per share, totaling $1,904 million.

[0001730168-23-000093:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-23-000093:8k_2_02:26]
Fiscal Year 2023 Financial Highlights

[0001730168-23-000093:8k_2_02:27]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | FY 23 |  | FY 22 |  | Change |  | FY 23 |  | FY 22 |  | Change |
| Net revenue |  | $ | 35,819 |  |  | $ | 33,203 |  |  | +8 | % |  | $ | 35,819 |  |  | $ | 33,203 |  |  | +8 | % |
| Net income |  | $ | 14,082 |  |  | $ | 11,495 |  |  | +$2,587 |  |  | $ | 18,378 |  |  | $ | 16,526 |  |  | +$1,852 |  |
| Earnings per common share - diluted |  | $ | 32.98 |  |  | $ | 26.53 |  |  | +$6.45 |  |  | $ | 42.25 |  |  | $ | 37.64 |  |  | +$4.61 |  |

[0001730168-23-000093:8k_2_02:28]
| (Dollars in millions) |  | FY 23 |  | FY 22 |  | Change |  |
| Cash flow from operations |  | $ | 18,085 |  |  | $ | 16,736 |  |  | +$1,349 |  |
| Adjusted EBITDA |  | $ | 23,213 |  |  | $ | 21,029 |  |  | +$2,184 |  |
| Free cash flow |  | $ | 17,633 |  |  | $ | 16,312 |  |  | +$1,321 |  |

[0001730168-23-000093:8k_2_02:29]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | FY 23 |  |  |  | FY 22 |  | Change |  |
| Semiconductor solutions |  | $ | 28,182 |  |  | 79 | % |  |  |  |  |  |  | $ | 25,818 |  |  | 78 | % |  | +9 | % |  |
| Infrastructure software |  | 7,637 |  |  | 21 |  |  |  |  |  |  |  | 7,385 |  |  | 22 |  |  | +3 | % |  |
| Total net revenue |  | $ | 35,819 |  |  | 100 | % |  |  |  |  |  |  | $ | 33,203 |  |  | 100 | % |  |  |  |  |

[0001730168-23-000093:8k_2_02:30]
Fiscal Year 2024 Business Outlook

[0001730168-23-000093:8k_2_02:31]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2024, ending November 3, 2024, including contributions from VMware, is expected to be as follows:

[0001730168-23-000093:8k_2_02:32]
•Fiscal year 2024 revenue guidance of approximately $50.0 billion; and

[0001730168-23-000093:8k_2_02:33]
•Fiscal year 2024 adjusted EBITDA guidance of approximately 60 percent of projected revenue.

[0001730168-23-000093:8k_2_02:34]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000093:8k_2_02:35]
Quarterly Dividends

[0001730168-23-000093:8k_2_02:36]
The Company’s Board of Directors has approved a quarterly cash dividend of $5.25 per share. The dividend is payable on December 29, 2023 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 20, 2023.

[0001730168-23-000093:8k_2_02:37]
Financial Results Conference Call

[0001730168-23-000093:8k_2_02:38]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter fiscal year 2023 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-23-000093:8k_2_02:39]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-23-000093:8k_2_02:40]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BIacd438722e7946a58b1c10d35c792d79. Upon registering, you will be emailed a link to the dial-in number and unique PIN.

[0001730168-23-000093:8k_2_02:41]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom's website at https://investors.broadcom.com/.

[0001730168-23-000093:8k_2_02:42]
Non-GAAP Financial Measures

[0001730168-23-000093:8k_2_02:43]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-23-000093:8k_2_02:44]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their

[0001730168-23-000093:8k_2_02:45]
3

[0001730168-23-000093:8k_2_02:46]
operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-23-000093:8k_2_02:47]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-23-000093:8k_2_02:48]
About Broadcom

[0001730168-23-000093:8k_2_02:49]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-23-000093:8k_2_02:50]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-23-000093:8k_2_02:51]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our acquisition of VMware, Inc., including employee retention, unexpected costs, charges or expenses, and our ability to successfully integrate VMware’s business and realize the expected benefits; any acquisitions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and resellers of our products; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of

[0001730168-23-000093:8k_2_02:52]
4

[0001730168-23-000093:8k_2_02:53]
security systems; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; involvement in legal proceedings; demand for our data center virtualization products; customer and market acceptance of our products and services; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third-party software used in our products; use of open source software in our products; ability of our software products to manage and secure IT infrastructures and environments; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; the amount and frequency of our share repurchase programs; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs, our ability to maintain tax concessions in certain jurisdictions and potential tax liabilities as a result of acquiring VMware; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-23-000093:8k_2_02:54]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000093:8k_2_02:55]
Contact:

[0001730168-23-000093:8k_2_02:56]
Ji Yoo

[0001730168-23-000093:8k_2_02:57]
Broadcom Inc.

[0001730168-23-000093:8k_2_02:58]
Investor Relations

[0001730168-23-000093:8k_2_02:59]
650-427-6000

[0001730168-23-000093:8k_2_02:60]
investor.relations@broadcom.com

[0001730168-23-000093:8k_2_02:61]
(AVGO-Q)

[0001730168-23-000093:8k_2_02:62]
5

[0001730168-23-000093:8k_2_02:63]
BROADCOM INC.

[0001730168-23-000093:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-23-000093:8k_2_02:65]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-23-000093:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 29,2023 |  | July 30,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
| Net revenue |  | $ | 9,295 |  |  | $ | 8,876 |  |  | $ | 8,930 |  |  | $ | 35,819 |  |  | $ | 33,203 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 2,449 |  |  | 2,272 |  |  | 2,298 |  |  | 9,272 |  |  | 8,256 |  |
| Amortization of acquisition-related intangible assets |  | 438 |  |  | 439 |  |  | 705 |  |  | 1,853 |  |  | 2,847 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 5 |  |
| Total cost of revenue |  | 2,888 |  |  | 2,712 |  |  | 3,004 |  |  | 11,129 |  |  | 11,108 |  |
| Gross margin |  | 6,407 |  |  | 6,164 |  |  | 5,926 |  |  | 24,690 |  |  | 22,095 |  |
| Research and development |  | 1,388 |  |  | 1,358 |  |  | 1,197 |  |  | 5,253 |  |  | 4,919 |  |
| Selling, general and administrative |  | 418 |  |  | 388 |  |  | 370 |  |  | 1,592 |  |  | 1,382 |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 350 |  |  | 358 |  |  | 1,394 |  |  | 1,512 |  |
| Restructuring and other charges |  | 13 |  |  | 212 |  |  | 15 |  |  | 244 |  |  | 57 |  |
| Total operating expenses |  | 2,167 |  |  | 2,308 |  |  | 1,940 |  |  | 8,483 |  |  | 7,870 |  |
| Operating income |  | 4,240 |  |  | 3,856 |  |  | 3,986 |  |  | 16,207 |  |  | 14,225 |  |
| Interest expense |  | (405) |  |  | (406) |  |  | (406) |  |  | (1,622) |  |  | (1,737) |  |
| Other income (expense), net |  | 132 |  |  | 124 |  |  | 40 |  |  | 512 |  |  | (54) |  |
| Income before income taxes |  | 3,967 |  |  | 3,574 |  |  | 3,620 |  |  | 15,097 |  |  | 12,434 |  |
| Provision for income taxes |  | 443 |  |  | 271 |  |  | 261 |  |  | 1,015 |  |  | 939 |  |
| Net income |  | 3,524 |  |  | 3,303 |  |  | 3,359 |  |  | 14,082 |  |  | 11,495 |  |
| Dividends on preferred stock |  | — |  |  | — |  |  | (48) |  |  | — |  |  | (272) |  |
| Net income attributable to common stock |  | $ | 3,524 |  |  | $ | 3,303 |  |  | $ | 3,311 |  |  | $ | 14,082 |  |  | $ | 11,223 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.53 |  |  | $ | 8.00 |  |  | $ | 8.06 |  |  | $ | 33.93 |  |  | $ | 27.44 |  |
| Diluted (1) |  | $ | 8.25 |  |  | $ | 7.74 |  |  | $ | 7.83 |  |  | $ | 32.98 |  |  | $ | 26.53 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 413 |  |  | 413 |  |  | 411 |  |  | 415 |  |  | 409 |  |
| Diluted (1) |  | 427 |  |  | 427 |  |  | 429 |  |  | 427 |  |  | 423 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 62 |  |  | $ | 61 |  |  | $ | 38 |  |  | $ | 210 |  |  | $ | 147 |  |
| Research and development |  | 448 |  |  | 444 |  |  | 260 |  |  | 1,513 |  |  | 1,048 |  |
| Selling, general and administrative |  | 128 |  |  | 124 |  |  | 89 |  |  | 448 |  |  | 338 |  |
| Total stock-based compensation expense |  | $ | 638 |  |  | $ | 629 |  |  | $ | 387 |  |  | $ | 2,171 |  |  | $ | 1,533 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive for the fiscal year ended October 30, 2022. All outstanding shares of Mandatory Convertible Preferred Stock were converted into our common stock during the fiscal quarter ended October 30, 2022. |

[0001730168-23-000093:8k_2_02:67]
BROADCOM INC.

[0001730168-23-000093:8k_2_02:68]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-23-000093:8k_2_02:69]
(IN MILLIONS)

[0001730168-23-000093:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 29,2023 |  | July 30,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
| Gross margin on GAAP basis |  | $ | 6,407 |  |  | $ | 6,164 |  |  | $ | 5,926 |  |  | $ | 24,690 |  |  | $ | 22,095 |  |
| Amortization of acquisition-related intangible assets |  | 438 |  |  | 439 |  |  | 705 |  |  | 1,853 |  |  | 2,847 |  |
| Stock-based compensation expense |  | 62 |  |  | 61 |  |  | 38 |  |  | 210 |  |  | 147 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 5 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 13 |  |
| Gross margin on non-GAAP basis |  | $ | 6,908 |  |  | $ | 6,665 |  |  | $ | 6,673 |  |  | $ | 26,757 |  |  | $ | 25,107 |  |
| Research and development on GAAP basis |  | $ | 1,388 |  |  | $ | 1,358 |  |  | $ | 1,197 |  |  | $ | 5,253 |  |  | $ | 4,919 |  |
| Stock-based compensation expense |  | 448 |  |  | 444 |  |  | 260 |  |  | 1,513 |  |  | 1,048 |  |
| Acquisition-related costs |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Research and development on non-GAAP basis |  | $ | 940 |  |  | $ | 913 |  |  | $ | 937 |  |  | $ | 3,740 |  |  | $ | 3,871 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 418 |  |  | $ | 388 |  |  | $ | 370 |  |  | $ | 1,592 |  |  | $ | 1,382 |  |
| Stock-based compensation expense |  | 128 |  |  | 124 |  |  | 89 |  |  | 448 |  |  | 338 |  |
| Acquisition-related costs |  | 69 |  |  | 48 |  |  | 45 |  |  | 252 |  |  | 102 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 221 |  |  | $ | 216 |  |  | $ | 236 |  |  | $ | 892 |  |  | $ | 942 |  |
| Total operating expenses on GAAP basis |  | $ | 2,167 |  |  | $ | 2,308 |  |  | $ | 1,940 |  |  | $ | 8,483 |  |  | $ | 7,870 |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 350 |  |  | 358 |  |  | 1,394 |  |  | 1,512 |  |
| Stock-based compensation expense |  | 576 |  |  | 568 |  |  | 349 |  |  | 1,961 |  |  | 1,386 |  |
| Restructuring and other charges |  | 13 |  |  | 212 |  |  | 15 |  |  | 244 |  |  | 57 |  |
| Acquisition-related costs |  | 69 |  |  | 49 |  |  | 45 |  |  | 252 |  |  | 102 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,161 |  |  | $ | 1,129 |  |  | $ | 1,173 |  |  | $ | 4,632 |  |  | $ | 4,813 |  |
| Operating income on GAAP basis |  | $ | 4,240 |  |  | $ | 3,856 |  |  | $ | 3,986 |  |  | $ | 16,207 |  |  | $ | 14,225 |  |
| Amortization of acquisition-related intangible assets |  | 786 |  |  | 789 |  |  | 1,063 |  |  | 3,247 |  |  | 4,359 |  |
| Stock-based compensation expense |  | 638 |  |  | 629 |  |  | 387 |  |  | 2,171 |  |  | 1,533 |  |
| Restructuring and other charges |  | 14 |  |  | 213 |  |  | 16 |  |  | 248 |  |  | 62 |  |
| Acquisition-related costs |  | 69 |  |  | 49 |  |  | 48 |  |  | 252 |  |  | 115 |  |
| Operating income on non-GAAP basis |  | $ | 5,747 |  |  | $ | 5,536 |  |  | $ | 5,500 |  |  | $ | 22,125 |  |  | $ | 20,294 |  |
| Interest expense on GAAP basis |  | $ | (405) |  |  | $ | (406) |  |  | $ | (406) |  |  | $ | (1,622) |  |  | $ | (1,737) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 112 |  |
| Interest expense on non-GAAP basis |  | $ | (405) |  |  | $ | (406) |  |  | $ | (406) |  |  | $ | (1,622) |  |  | $ | (1,625) |  |
| Other income (expense), net on GAAP basis |  | $ | 132 |  |  | $ | 124 |  |  | $ | 40 |  |  | $ | 512 |  |  | $ | (54) |  |
| (Gains) losses on investments |  | 24 |  |  | (2) |  |  | 29 |  |  | (11) |  |  | 169 |  |
| Other |  | (1) |  |  | — |  |  | — |  |  | (1) |  |  | (5) |  |
| Other income, net on non-GAAP basis |  | $ | 155 |  |  | $ | 122 |  |  | $ | 69 |  |  | $ | 500 |  |  | $ | 110 |  |
| Provision for income taxes on GAAP basis |  | $ | 443 |  |  | $ | 271 |  |  | $ | 261 |  |  | $ | 1,015 |  |  | $ | 939 |  |
| Non-GAAP tax reconciling adjustments |  | 244 |  |  | 385 |  |  | 358 |  |  | 1,610 |  |  | 1,314 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 687 |  |  | $ | 656 |  |  | $ | 619 |  |  | $ | 2,625 |  |  | $ | 2,253 |  |

[0001730168-23-000093:8k_2_02:71]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 29,2023 |  | July 30,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
| Net income on GAAP basis |  | $ | 3,524 |  |  | $ | 3,303 |  |  | $ | 3,359 |  |  | $ | 14,082 |  |  | $ | 11,495 |  |
| Amortization of acquisition-related intangible assets |  | 786 |  |  | 789 |  |  | 1,063 |  |  | 3,247 |  |  | 4,359 |  |
| Stock-based compensation expense |  | 638 |  |  | 629 |  |  | 387 |  |  | 2,171 |  |  | 1,533 |  |
| Restructuring and other charges |  | 14 |  |  | 213 |  |  | 16 |  |  | 248 |  |  | 62 |  |
| Acquisition-related costs |  | 69 |  |  | 49 |  |  | 48 |  |  | 252 |  |  | 115 |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 112 |  |
| (Gains) losses on investments |  | 24 |  |  | (2) |  |  | 29 |  |  | (11) |  |  | 169 |  |
| Other |  | (1) |  |  | — |  |  | — |  |  | (1) |  |  | (5) |  |
| Non-GAAP tax reconciling adjustments |  | (244) |  |  | (385) |  |  | (358) |  |  | (1,610) |  |  | (1,314) |  |
| Net income on non-GAAP basis |  | $ | 4,810 |  |  | $ | 4,596 |  |  | $ | 4,544 |  |  | $ | 18,378 |  |  | $ | 16,526 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 427 |  |  | 427 |  |  | 429 |  |  | 427 |  |  | 423 |  |
| Non-GAAP adjustment (1) |  | 8 |  |  | 9 |  |  | 6 |  |  | 8 |  |  | 16 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 435 |  |  | 436 |  |  | 435 |  |  | 435 |  |  | 439 |  |
| Net income on non-GAAP basis |  | $ | 4,810 |  |  | $ | 4,596 |  |  | $ | 4,544 |  |  | $ | 18,378 |  |  | $ | 16,526 |  |
| Interest expense |  | 405 |  |  | 406 |  |  | 406 |  |  | 1,622 |  |  | 1,625 |  |
| Provision for income taxes on non-GAAP basis |  | 687 |  |  | 656 |  |  | 619 |  |  | 2,625 |  |  | 2,253 |  |
| Depreciation |  | 124 |  |  | 122 |  |  | 129 |  |  | 502 |  |  | 529 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 22 |  |  | 21 |  |  | 24 |  |  | 86 |  |  | 96 |  |
| Adjusted EBITDA |  | $ | 6,048 |  |  | $ | 5,801 |  |  | $ | 5,722 |  |  | $ | 23,213 |  |  | $ | 21,029 |  |
| Net cash provided by operating activities |  | $ | 4,828 |  |  | $ | 4,719 |  |  | $ | 4,583 |  |  | $ | 18,085 |  |  | $ | 16,736 |  |
| Purchases of property, plant and equipment |  | (105) |  |  | (122) |  |  | (122) |  |  | (452) |  |  | (424) |  |
| Free cash flow |  | $ | 4,723 |  |  | $ | 4,597 |  |  | $ | 4,461 |  |  | $ | 17,633 |  |  | $ | 16,312 |  |

[0001730168-23-000093:8k_2_02:72]
|  |  | Fiscal Year Ending |
|  |  | November 3, |
| Expected average diluted share count (2): |  | 2024 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 480 |  |
| Non-GAAP adjustment (1) |  | 14 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 494 |  |

[0001730168-23-000093:8k_2_02:73]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis for the fiscal year ended October 30, 2022. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-23-000093:8k_2_02:74]
BROADCOM INC.

[0001730168-23-000093:8k_2_02:75]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-23-000093:8k_2_02:76]
(IN MILLIONS)

[0001730168-23-000093:8k_2_02:77]
|  |  | October 29,2023 |  | October 30,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 14,189 |  |  | $ | 12,416 |  |
| Trade accounts receivable, net |  | 3,154 |  |  | 2,958 |  |
| Inventory |  | 1,898 |  |  | 1,925 |  |
| Other current assets |  | 1,606 |  |  | 1,205 |  |
| Total current assets |  | 20,847 |  |  | 18,504 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,154 |  |  | 2,223 |  |
| Goodwill |  | 43,653 |  |  | 43,614 |  |
| Intangible assets, net |  | 3,867 |  |  | 7,111 |  |
| Other long-term assets |  | 2,340 |  |  | 1,797 |  |
| Total assets |  | $ | 72,861 |  |  | $ | 73,249 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,210 |  |  | $ | 998 |  |
| Employee compensation and benefits |  | 935 |  |  | 1,202 |  |
| Current portion of long-term debt |  | 1,608 |  |  | 440 |  |
| Other current liabilities |  | 3,652 |  |  | 4,412 |  |
| Total current liabilities |  | 7,405 |  |  | 7,052 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 37,621 |  |  | 39,075 |  |
| Other long-term liabilities |  | 3,847 |  |  | 4,413 |  |
| Total liabilities |  | 48,873 |  |  | 50,540 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 21,099 |  |  | 21,159 |  |
| Retained earnings |  | 2,682 |  |  | 1,604 |  |
| Accumulated other comprehensive income (loss) |  | 207 |  |  | (54) |  |
| Total stockholders' equity |  | 23,988 |  |  | 22,709 |  |
| Total liabilities and equity |  | $ | 72,861 |  |  | $ | 73,249 |  |

[0001730168-23-000093:8k_2_02:78]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 29,2023 |  | July 30,2023 |  | October 30,2022 |  | October 29,2023 |  | October 30,2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,524 |  |  | $ | 3,303 |  |  | $ | 3,359 |  |  | $ | 14,082 |  |  | $ | 11,495 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 808 |  |  | 810 |  |  | 1,087 |  |  | 3,333 |  |  | 4,455 |  |
| Depreciation |  | 124 |  |  | 122 |  |  | 129 |  |  | 502 |  |  | 529 |  |
| Stock-based compensation |  | 638 |  |  | 629 |  |  | 387 |  |  | 2,171 |  |  | 1,533 |  |
| Deferred taxes and other non-cash taxes |  | 639 |  |  | (251) |  |  | (89) |  |  | (501) |  |  | (34) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 100 |  |
| Non-cash interest expense |  | 34 |  |  | 33 |  |  | 32 |  |  | 132 |  |  | 129 |  |
| Other |  | 27 |  |  | — |  |  | 31 |  |  | 9 |  |  | 183 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (231) |  |  | 135 |  |  | (241) |  |  | (187) |  |  | (870) |  |
| Inventory |  | (56) |  |  | 44 |  |  | (87) |  |  | 27 |  |  | (627) |  |
| Accounts payable |  | 215 |  |  | 188 |  |  | 304 |  |  | 209 |  |  | (79) |  |
| Employee compensation and benefits |  | 103 |  |  | 184 |  |  | 128 |  |  | (279) |  |  | 136 |  |
| Other current assets and current liabilities |  | (694) |  |  | (339) |  |  | (388) |  |  | (628) |  |  | 222 |  |
| Other long-term assets and long-term liabilities |  | (303) |  |  | (139) |  |  | (69) |  |  | (785) |  |  | (436) |  |
| Net cash provided by operating activities |  | 4,828 |  |  | 4,719 |  |  | 4,583 |  |  | 18,085 |  |  | 16,736 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (36) |  |  | (17) |  |  | (7) |  |  | (53) |  |  | (246) |  |
| Purchases of property, plant and equipment |  | (105) |  |  | (122) |  |  | (122) |  |  | (452) |  |  | (424) |  |
| Purchases of investments |  | (58) |  |  | (91) |  |  | — |  |  | (346) |  |  | (200) |  |
| Sales of investments |  | 154 |  |  | 74 |  |  | — |  |  | 228 |  |  | 200 |  |
| Other |  | (79) |  |  | 12 |  |  | 1 |  |  | (66) |  |  | 3 |  |
| Net cash used in investing activities |  | (124) |  |  | (144) |  |  | (128) |  |  | (689) |  |  | (667) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,935 |  |
| Payments on debt obligations |  | (143) |  |  | — |  |  | (9) |  |  | (403) |  |  | (2,361) |  |
| Payments of dividends |  | (1,904) |  |  | (1,901) |  |  | (1,782) |  |  | (7,645) |  |  | (7,032) |  |
| Repurchases of common stock - repurchase program |  | (123) |  |  | (1,707) |  |  | — |  |  | (5,824) |  |  | (7,000) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (454) |  |  | (460) |  |  | (274) |  |  | (1,861) |  |  | (1,455) |  |
| Issuance of common stock |  | 59 |  |  | — |  |  | 54 |  |  | 122 |  |  | 114 |  |
| Other |  | (5) |  |  | (5) |  |  | (5) |  |  | (12) |  |  | (17) |  |
| Net cash used in financing activities |  | (2,570) |  |  | (4,073) |  |  | (2,016) |  |  | (15,623) |  |  | (15,816) |  |
| Net change in cash and cash equivalents |  | 2,134 |  |  | 502 |  |  | 2,439 |  |  | 1,773 |  |  | 253 |  |
| Cash and cash equivalents at beginning of period |  | 12,055 |  |  | 11,553 |  |  | 9,977 |  |  | 12,416 |  |  | 12,163 |  |
| Cash and cash equivalents at end of period |  | $ | 14,189 |  |  | $ | 12,055 |  |  | $ | 12,416 |  |  | $ | 14,189 |  |  | $ | 12,416 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 397 |  |  | $ | 348 |  |  | $ | 397 |  |  | $ | 1,503 |  |  | $ | 1,386 |  |
| Cash paid for income taxes |  | $ | 191 |  |  | $ | 427 |  |  | $ | 251 |  |  | $ | 1,782 |  |  | $ | 908 |  |
