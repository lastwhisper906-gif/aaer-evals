# AVGO 8-K — 0001730168-21-000110 filed 2021-06-03

## item codes, every 8-K on or before 2021-06-11

- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2021-06-11

- none on or before 2021-06-11

## item 2.02 — earnings release, exhibit 99.1

[0001730168-21-000110:8k_2_02:1]
EX-99.1
4
avgo-05022021x8kxex99.htm
EX-99.1

[0001730168-21-000110:8k_2_02:2]
Document

[0001730168-21-000110:8k_2_02:3]
Exhibit 99.1

[0001730168-21-000110:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2021 Financial Results and Quarterly Dividends

[0001730168-21-000110:8k_2_02:5]
•Revenue of $6,610 million for the second quarter, up 15 percent from the prior year period

[0001730168-21-000110:8k_2_02:6]
•GAAP net income of $1,493 million for the second quarter; Adjusted EBITDA of $3,960 million for the second quarter

[0001730168-21-000110:8k_2_02:7]
•GAAP diluted EPS of $3.30 for the second quarter; Non-GAAP diluted EPS of $6.62 for the second quarter

[0001730168-21-000110:8k_2_02:8]
•$3,443 million of free cash flow from operations for the second quarter, defined as cash from operations of $3,569 million less capital expenditures of $126 million

[0001730168-21-000110:8k_2_02:9]
•Quarterly common stock dividend of $3.60 per share

[0001730168-21-000110:8k_2_02:10]
•Third quarter revenue guidance of approximately $6.75 billion, an expected increase of 16 percent from the prior year period

[0001730168-21-000110:8k_2_02:11]
•Third quarter Adjusted EBITDA guidance of approximately 60 percent of projected revenue  (1)

[0001730168-21-000110:8k_2_02:12]
SAN JOSE, Calif. – June 3, 2021 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2021, ended May 2, 2021, provided guidance for the third quarter of its fiscal year 2021 and announced its quarterly dividends.

[0001730168-21-000110:8k_2_02:13]
“Due to the strength in demand for semiconductors across our multiple end markets, we delivered 20% year-over-year increase in semiconductor revenue,” said Hock Tan, President and CEO of Broadcom Inc. “Our third quarter outlook projects this year-over-year growth to sustain, as we continue to see strong demand from service providers and hypercloud.”

[0001730168-21-000110:8k_2_02:14]
“Consolidated revenue grew 15% year-over-year and operating profit increased 25%,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $3.4 billion in free cash flow or 52% of revenue in the quarter, and are expecting free cash flow to remain strong in the third quarter.”

[0001730168-21-000110:8k_2_02:15]
Second Quarter Fiscal Year 2021 Financial Highlights

[0001730168-21-000110:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q2 21 |  | Q2 20 |  | Change |  | Q2 21 |  | Q2 20 |  | Change |
| Net revenue |  | $ | 6,610 |  |  | $ | 5,742 |  |  | +15 | % |  | $ | 6,610 |  |  | $ | 5,742 |  |  | +15 | % |
| Net income |  | $ | 1,493 |  |  | $ | 563 |  |  | +$930 |  |  | $ | 2,980 |  |  | $ | 2,323 |  |  | +$657 |  |
| Earnings per common share - diluted |  | $ | 3.30 |  |  | $ | 1.17 |  |  | +$2.13 |  |  | $ | 6.62 |  |  | $ | 5.14 |  |  | +$1.48 |  |

[0001730168-21-000110:8k_2_02:17]
________________________________

[0001730168-21-000110:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-21-000110:8k_2_02:19]
1

[0001730168-21-000110:8k_2_02:20]
| (Dollars in millions) |  | Q2 21 |  | Q2 20 |  | Change |  |
| Cash flow from operations |  | $ | 3,569 |  |  | $ | 3,213 |  |  | +$356 |  |
| Adjusted EBITDA |  | $ | 3,960 |  |  | $ | 3,209 |  |  | +$751 |  |
| Free cash flow |  | $ | 3,443 |  |  | $ | 3,065 |  |  | +$378 |  |

[0001730168-21-000110:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q2 21 |  |  |  | Q2 20 |  | Change |  |
| Semiconductor solutions |  | $ | 4,820 |  |  | 73 | % |  |  |  |  |  |  | $ | 4,027 |  |  | 70 | % |  | +20 | % |  |
| Infrastructure software |  | 1,790 |  |  | 27 |  |  |  |  |  |  |  | 1,715 |  |  | 30 |  |  | +4 | % |  |
| Total net revenue |  | $ | 6,610 |  |  | 100 | % |  |  |  |  |  |  | $ | 5,742 |  |  | 100 | % |  |  |  |  |

[0001730168-21-000110:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the second fiscal quarter were $9,518 million, compared to $9,552 million at the end of the prior quarter.

[0001730168-21-000110:8k_2_02:23]
During the second fiscal quarter, the Company generated $3,569 million in cash from operations and spent $126 million on capital expenditures.

[0001730168-21-000110:8k_2_02:24]
On March 31, 2021, the Company paid a cash dividend of $3.60 per share of common stock, totaling $1,477 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-21-000110:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-21-000110:8k_2_02:26]
Third Quarter Fiscal Year 2021 Business Outlook

[0001730168-21-000110:8k_2_02:27]
Based on current business trends and conditions, the outlook for the third quarter of fiscal year 2021, ending August 1, 2021, is expected to be as follows:

[0001730168-21-000110:8k_2_02:28]
a.Third quarter revenue guidance of approximately $6.75 billion; and

[0001730168-21-000110:8k_2_02:29]
b.Third quarter Adjusted EBITDA guidance of approximately 60 percent of projected revenue

[0001730168-21-000110:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000110:8k_2_02:31]
Quarterly Dividends

[0001730168-21-000110:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.60 per share. The common stock dividend is payable on June 30, 2021 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 22, 2021.

[0001730168-21-000110:8k_2_02:33]
2

[0001730168-21-000110:8k_2_02:34]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on June 30, 2021 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 15, 2021.

[0001730168-21-000110:8k_2_02:35]
Financial Results Conference Call

[0001730168-21-000110:8k_2_02:36]
Broadcom Inc. will host a conference call to review its financial results for the second quarter fiscal year 2021 and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 2374098. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 2374098. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001730168-21-000110:8k_2_02:37]
Non-GAAP Financial Measures

[0001730168-21-000110:8k_2_02:38]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-21-000110:8k_2_02:39]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-21-000110:8k_2_02:40]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-21-000110:8k_2_02:41]
3

[0001730168-21-000110:8k_2_02:42]
About Broadcom Inc.

[0001730168-21-000110:8k_2_02:43]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to www.broadcom.com.

[0001730168-21-000110:8k_2_02:44]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-21-000110:8k_2_02:45]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has disrupted, and will likely continue to disrupt, normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations, trade restrictions and trade tensions; global economic conditions and concerns; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software

[0001730168-21-000110:8k_2_02:46]
4

[0001730168-21-000110:8k_2_02:47]
products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-21-000110:8k_2_02:48]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000110:8k_2_02:49]
Contact:

[0001730168-21-000110:8k_2_02:50]
Ji Yoo

[0001730168-21-000110:8k_2_02:51]
Broadcom Inc.

[0001730168-21-000110:8k_2_02:52]
Investor Relations

[0001730168-21-000110:8k_2_02:53]
408-433-8000

[0001730168-21-000110:8k_2_02:54]
investor.relations@broadcom.com

[0001730168-21-000110:8k_2_02:55]
5

[0001730168-21-000110:8k_2_02:56]
BROADCOM INC.

[0001730168-21-000110:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-21-000110:8k_2_02:58]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-21-000110:8k_2_02:59]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | January 31,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
| Net revenue |  | $ | 6,610 |  |  | $ | 6,655 |  |  | $ | 5,742 |  |  | $ | 13,265 |  |  | $ | 11,600 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,699 |  |  | 1,814 |  |  | 1,592 |  |  | 3,513 |  |  | 3,228 |  |
| Amortization of acquisition-related intangible assets |  | 853 |  |  | 874 |  |  | 954 |  |  | 1,727 |  |  | 1,904 |  |
| Restructuring charges |  | 1 |  |  | 15 |  |  | 7 |  |  | 16 |  |  | 15 |  |
| Total cost of revenue |  | 2,553 |  |  | 2,703 |  |  | 2,553 |  |  | 5,256 |  |  | 5,147 |  |
| Gross margin |  | 4,057 |  |  | 3,952 |  |  | 3,189 |  |  | 8,009 |  |  | 6,453 |  |
| Research and development |  | 1,238 |  |  | 1,211 |  |  | 1,269 |  |  | 2,449 |  |  | 2,558 |  |
| Selling, general and administrative |  | 325 |  |  | 339 |  |  | 501 |  |  | 664 |  |  | 1,102 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 599 |  |  | 988 |  |  | 1,202 |  |
| Restructuring, impairment and disposal charges |  | 25 |  |  | 71 |  |  | 54 |  |  | 96 |  |  | 111 |  |
| Total operating expenses |  | 2,082 |  |  | 2,115 |  |  | 2,423 |  |  | 4,197 |  |  | 4,973 |  |
| Operating income |  | 1,975 |  |  | 1,837 |  |  | 766 |  |  | 3,812 |  |  | 1,480 |  |
| Interest expense |  | (466) |  |  | (570) |  |  | (487) |  |  | (1,036) |  |  | (893) |  |
| Other income (expense), net |  | (23) |  |  | 117 |  |  | 130 |  |  | 94 |  |  | 126 |  |
| Income from continuing operations before income taxes |  | 1,486 |  |  | 1,384 |  |  | 409 |  |  | 2,870 |  |  | 713 |  |
| Provision for (benefit from) income taxes |  | (7) |  |  | 6 |  |  | (159) |  |  | (1) |  |  | (235) |  |
| Income from continuing operations |  | 1,493 |  |  | 1,378 |  |  | 568 |  |  | 2,871 |  |  | 948 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (5) |  |  | — |  |  | — |  |
| Net income |  | 1,493 |  |  | 1,378 |  |  | 563 |  |  | 2,871 |  |  | 948 |  |
| Dividends on preferred stock |  | (76) |  |  | (74) |  |  | (75) |  |  | (150) |  |  | (149) |  |
| Net income attributable to common stock |  | $ | 1,417 |  |  | $ | 1,304 |  |  | $ | 488 |  |  | $ | 2,721 |  |  | $ | 799 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.46 |  |  | $ | 3.20 |  |  | $ | 1.23 |  |  | $ | 6.67 |  |  | $ | 2.00 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 3.46 |  |  | $ | 3.20 |  |  | $ | 1.22 |  |  | $ | 6.67 |  |  | $ | 2.00 |  |
| Diluted income per share attributable to common stock (1): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.30 |  |  | $ | 3.05 |  |  | $ | 1.18 |  |  | $ | 6.34 |  |  | $ | 1.91 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 3.30 |  |  | $ | 3.05 |  |  | $ | 1.17 |  |  | $ | 6.34 |  |  | $ | 1.91 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 409 |  |  | 407 |  |  | 401 |  |  | 408 |  |  | 400 |  |
| Diluted |  | 429 |  |  | 428 |  |  | 417 |  |  | 429 |  |  | 419 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 38 |  |  | $ | 32 |  |  | $ | 41 |  |  | $ | 70 |  |  | $ | 84 |  |
| Research and development |  | 307 |  |  | 328 |  |  | 373 |  |  | 635 |  |  | 764 |  |
| Selling, general and administrative |  | 80 |  |  | 84 |  |  | 103 |  |  | 164 |  |  | 214 |  |
| Total stock-based compensation expense |  | $ | 425 |  |  | $ | 444 |  |  | $ | 517 |  |  | $ | 869 |  |  | $ | 1,062 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-21-000110:8k_2_02:60]
BROADCOM INC.

[0001730168-21-000110:8k_2_02:61]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-21-000110:8k_2_02:62]
(IN MILLIONS)

[0001730168-21-000110:8k_2_02:63]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | January 31,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
| Gross margin on GAAP basis |  | $ | 4,057 |  |  | $ | 3,952 |  |  | $ | 3,189 |  |  | $ | 8,009 |  |  | $ | 6,453 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 853 |  |  | 874 |  |  | 954 |  |  | 1,727 |  |  | 1,904 |  |
| Stock-based compensation expense |  | 38 |  |  | 32 |  |  | 41 |  |  | 70 |  |  | 84 |  |
| Restructuring charges |  | 1 |  |  | 15 |  |  | 7 |  |  | 16 |  |  | 15 |  |
| Acquisition-related costs |  | 3 |  |  | 3 |  |  | 5 |  |  | 6 |  |  | 6 |  |
| Gross margin on non-GAAP basis |  | $ | 4,952 |  |  | $ | 4,876 |  |  | $ | 4,196 |  |  | $ | 9,828 |  |  | $ | 8,473 |  |
| Research and development on GAAP basis |  | $ | 1,238 |  |  | $ | 1,211 |  |  | $ | 1,269 |  |  | $ | 2,449 |  |  | $ | 2,558 |  |
| Stock-based compensation expense |  | 307 |  |  | 328 |  |  | 373 |  |  | 635 |  |  | 764 |  |
| Acquisition-related costs |  | 1 |  |  | 1 |  |  | 5 |  |  | 2 |  |  | 12 |  |
| Research and development on non-GAAP basis |  | $ | 930 |  |  | $ | 882 |  |  | $ | 891 |  |  | $ | 1,812 |  |  | $ | 1,782 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 325 |  |  | $ | 339 |  |  | $ | 501 |  |  | $ | 664 |  |  | $ | 1,102 |  |
| Stock-based compensation expense |  | 80 |  |  | 84 |  |  | 103 |  |  | 164 |  |  | 214 |  |
| Acquisition-related costs |  | 25 |  |  | 41 |  |  | 95 |  |  | 66 |  |  | 270 |  |
| Litigation settlements |  | — |  |  | — |  |  | 29 |  |  | — |  |  | 42 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 220 |  |  | $ | 214 |  |  | $ | 274 |  |  | $ | 434 |  |  | $ | 576 |  |
| Total operating expenses on GAAP basis |  | $ | 2,082 |  |  | $ | 2,115 |  |  | $ | 2,423 |  |  | $ | 4,197 |  |  | $ | 4,973 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 599 |  |  | 988 |  |  | 1,202 |  |
| Stock-based compensation expense |  | 387 |  |  | 412 |  |  | 476 |  |  | 799 |  |  | 978 |  |
| Restructuring, impairment and disposal charges |  | 25 |  |  | 71 |  |  | 54 |  |  | 96 |  |  | 111 |  |
| Litigation settlements |  | — |  |  | — |  |  | 29 |  |  | — |  |  | 42 |  |
| Acquisition-related costs |  | 26 |  |  | 42 |  |  | 100 |  |  | 68 |  |  | 282 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,150 |  |  | $ | 1,096 |  |  | $ | 1,165 |  |  | $ | 2,246 |  |  | $ | 2,358 |  |
| Operating income on GAAP basis |  | $ | 1,975 |  |  | $ | 1,837 |  |  | $ | 766 |  |  | $ | 3,812 |  |  | $ | 1,480 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,347 |  |  | 1,368 |  |  | 1,553 |  |  | 2,715 |  |  | 3,106 |  |
| Stock-based compensation expense |  | 425 |  |  | 444 |  |  | 517 |  |  | 869 |  |  | 1,062 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 86 |  |  | 61 |  |  | 112 |  |  | 126 |  |
| Litigation settlements |  | — |  |  | — |  |  | 29 |  |  | — |  |  | 42 |  |
| Acquisition-related costs |  | 29 |  |  | 45 |  |  | 105 |  |  | 74 |  |  | 288 |  |
| Operating income on non-GAAP basis |  | $ | 3,802 |  |  | $ | 3,780 |  |  | $ | 3,031 |  |  | $ | 7,582 |  |  | $ | 6,115 |  |
| Interest expense on GAAP basis |  | $ | (466) |  |  | $ | (570) |  |  | $ | (487) |  |  | $ | (1,036) |  |  | $ | (893) |  |
| Loss on debt extinguishment |  | 50 |  |  | 172 |  |  | 93 |  |  | 222 |  |  | 98 |  |
| Interest expense on non-GAAP basis |  | $ | (416) |  |  | $ | (398) |  |  | $ | (394) |  |  | $ | (814) |  |  | $ | (795) |  |
| Other income (expense), net on GAAP basis |  | $ | (23) |  |  | $ | 117 |  |  | $ | 130 |  |  | $ | 94 |  |  | $ | 126 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | (116) |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | 25 |  |  | (119) |  |  | (8) |  |  | (94) |  |  | 10 |  |
| Acquisition-related gain |  | (1) |  |  | (2) |  |  | (3) |  |  | (3) |  |  | (7) |  |
| Other income (expense), net on non-GAAP basis |  | $ | 1 |  |  | $ | (4) |  |  | $ | 3 |  |  | $ | (3) |  |  | $ | 13 |  |

[0001730168-21-000110:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | January 31,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (7) |  |  | $ | 6 |  |  | $ | (159) |  |  | $ | (1) |  |  | $ | (235) |  |
| Non-GAAP tax reconciling adjustments |  | 414 |  |  | 399 |  |  | 476 |  |  | 813 |  |  | 875 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 407 |  |  | $ | 405 |  |  | $ | 317 |  |  | $ | 812 |  |  | $ | 640 |  |
| Net income on GAAP basis |  | $ | 1,493 |  |  | $ | 1,378 |  |  | $ | 563 |  |  | $ | 2,871 |  |  | $ | 948 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,347 |  |  | 1,368 |  |  | 1,553 |  |  | 2,715 |  |  | 3,106 |  |
| Stock-based compensation expense |  | 425 |  |  | 444 |  |  | 517 |  |  | 869 |  |  | 1,062 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 86 |  |  | 61 |  |  | 112 |  |  | 126 |  |
| Litigation settlements |  | — |  |  | — |  |  | 29 |  |  | — |  |  | 42 |  |
| Acquisition-related costs |  | 28 |  |  | 43 |  |  | 102 |  |  | 71 |  |  | 281 |  |
| Loss on debt extinguishment |  | 50 |  |  | 172 |  |  | 93 |  |  | 222 |  |  | 98 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | (116) |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | 25 |  |  | (119) |  |  | (8) |  |  | (94) |  |  | 10 |  |
| Non-GAAP tax reconciling adjustments |  | (414) |  |  | (399) |  |  | (476) |  |  | (813) |  |  | (875) |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 5 |  |  | — |  |  | — |  |
| Net income on non-GAAP basis |  | $ | 2,980 |  |  | $ | 2,973 |  |  | $ | 2,323 |  |  | $ | 5,953 |  |  | $ | 4,693 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 429 |  |  | 428 |  |  | 417 |  |  | 429 |  |  | 419 |  |
| Non-GAAP adjustment (1) |  | 21 |  |  | 22 |  |  | 35 |  |  | 21 |  |  | 33 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 450 |  |  | 450 |  |  | 452 |  |  | 450 |  |  | 452 |  |
| Net income on non-GAAP basis |  | $ | 2,980 |  |  | $ | 2,973 |  |  | $ | 2,323 |  |  | $ | 5,953 |  |  | $ | 4,693 |  |
| Interest expense on non-GAAP basis |  | 416 |  |  | 398 |  |  | 394 |  |  | 814 |  |  | 795 |  |
| Provision for income taxes on non-GAAP basis |  | 407 |  |  | 405 |  |  | 317 |  |  | 812 |  |  | 640 |  |
| Depreciation |  | 133 |  |  | 138 |  |  | 147 |  |  | 271 |  |  | 293 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 27 |  |  | 28 |  |  | 51 |  |  | 53 |  |
| Adjusted EBITDA |  | $ | 3,960 |  |  | $ | 3,941 |  |  | $ | 3,209 |  |  | $ | 7,901 |  |  | $ | 6,474 |  |
| Net cash provided by operating activities |  | $ | 3,569 |  |  | $ | 3,113 |  |  | $ | 3,213 |  |  | $ | 6,682 |  |  | $ | 5,535 |  |
| Purchases of property, plant and equipment |  | (126) |  |  | (114) |  |  | (148) |  |  | (240) |  |  | (256) |  |
| Free cash flow |  | $ | 3,443 |  |  | $ | 2,999 |  |  | $ | 3,065 |  |  | $ | 6,442 |  |  | $ | 5,279 |  |

[0001730168-21-000110:8k_2_02:65]
|  |  | Fiscal Quarter Ending |
|  |  | August 1, |
| Expected average diluted share count: |  | 2021 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 429 |  |
| Non-GAAP adjustment (1) |  | 20 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 449 |  |

[0001730168-21-000110:8k_2_02:66]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. The non-GAAP adjustment also includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis. For the fiscal quarter ending August 1, 2021, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |

[0001730168-21-000110:8k_2_02:67]
BROADCOM INC.

[0001730168-21-000110:8k_2_02:68]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-21-000110:8k_2_02:69]
(IN MILLIONS)

[0001730168-21-000110:8k_2_02:70]
|  |  | May 2,2021 |  | November 1,2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,518 |  |  | $ | 7,618 |  |
| Trade accounts receivable, net |  | 2,425 |  |  | 2,297 |  |
| Inventory |  | 1,004 |  |  | 1,003 |  |
| Other current assets |  | 1,298 |  |  | 977 |  |
| Total current assets |  | 14,245 |  |  | 11,895 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,416 |  |  | 2,509 |  |
| Goodwill |  | 43,457 |  |  | 43,447 |  |
| Intangible assets, net |  | 14,068 |  |  | 16,782 |  |
| Other long-term assets |  | 1,338 |  |  | 1,300 |  |
| Total assets |  | $ | 75,524 |  |  | $ | 75,933 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 830 |  |  | $ | 836 |  |
| Employee compensation and benefits |  | 639 |  |  | 877 |  |
| Current portion of long-term debt |  | 278 |  |  | 827 |  |
| Other current liabilities |  | 4,689 |  |  | 3,831 |  |
| Total current liabilities |  | 6,436 |  |  | 6,371 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 40,160 |  |  | 40,235 |  |
| Other long-term liabilities |  | 4,962 |  |  | 5,426 |  |
| Total liabilities |  | 51,558 |  |  | 52,032 |  |
| Preferred stock dividend obligation |  | 27 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 24,045 |  |  | 23,982 |  |
| Retained earnings |  | — |  |  | — |  |
| Accumulated other comprehensive loss |  | (106) |  |  | (108) |  |
| Total stockholders' equity |  | 23,939 |  |  | 23,874 |  |
| Total liabilities and equity |  | $ | 75,524 |  |  | $ | 75,933 |  |

[0001730168-21-000110:8k_2_02:71]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | January 31,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,493 |  |  | $ | 1,378 |  |  | $ | 563 |  |  | $ | 2,871 |  |  | $ | 948 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,371 |  |  | 1,395 |  |  | 1,583 |  |  | 2,766 |  |  | 3,165 |  |
| Depreciation |  | 133 |  |  | 138 |  |  | 147 |  |  | 271 |  |  | 293 |  |
| Stock-based compensation |  | 425 |  |  | 444 |  |  | 517 |  |  | 869 |  |  | 1,062 |  |
| Deferred taxes and other non-cash taxes |  | (177) |  |  | (149) |  |  | (175) |  |  | (326) |  |  | (247) |  |
| Loss on debt extinguishment |  | 26 |  |  | 172 |  |  | 93 |  |  | 198 |  |  | 98 |  |
| Unrealized (gain) loss on investments |  | 25 |  |  | (119) |  |  | — |  |  | (94) |  |  | — |  |
| Non-cash restructuring, impairment and disposal charges |  | 12 |  |  | 15 |  |  | 6 |  |  | 27 |  |  | 17 |  |
| Non-cash interest expense |  | 21 |  |  | 22 |  |  | 31 |  |  | 43 |  |  | 61 |  |
| Other |  | (3) |  |  | (5) |  |  | (8) |  |  | (8) |  |  | 11 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 106 |  |  | (247) |  |  | 440 |  |  | (141) |  |  | 48 |  |
| Inventory |  | (52) |  |  | 51 |  |  | (10) |  |  | (1) |  |  | 30 |  |
| Accounts payable |  | (58) |  |  | 44 |  |  | 233 |  |  | (14) |  |  | 350 |  |
| Employee compensation and benefits |  | 135 |  |  | (375) |  |  | 61 |  |  | (240) |  |  | (156) |  |
| Other current assets and current liabilities |  | 182 |  |  | 408 |  |  | 118 |  |  | 590 |  |  | 464 |  |
| Other long-term assets and long-term liabilities |  | (70) |  |  | (59) |  |  | (386) |  |  | (129) |  |  | (609) |  |
| Net cash provided by operating activities |  | 3,569 |  |  | 3,113 |  |  | 3,213 |  |  | 6,682 |  |  | 5,535 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (8) |  |  | — |  |  | (8) |  |  | (10,870) |  |
| Proceeds from sale of business |  | — |  |  | — |  |  | 168 |  |  | — |  |  | 168 |  |
| Purchases of property, plant and equipment |  | (126) |  |  | (114) |  |  | (148) |  |  | (240) |  |  | (256) |  |
| Proceeds from disposals of property, plant and equipment |  | 3 |  |  | — |  |  | — |  |  | 3 |  |  | — |  |
| Other |  | (3) |  |  | — |  |  | 4 |  |  | (3) |  |  | (5) |  |
| Net cash provided by (used in) investing activities |  | (126) |  |  | (122) |  |  | 24 |  |  | (248) |  |  | (10,963) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | 9,904 |  |  | 4,468 |  |  | 9,904 |  |  | 19,849 |  |
| Payments on debt obligations |  | (1,533) |  |  | (9,200) |  |  | (4,452) |  |  | (10,733) |  |  | (8,989) |  |
| Other borrowings, net |  | — |  |  | — |  |  | 1,025 |  |  | — |  |  | 1,743 |  |
| Payments of dividends |  | (1,552) |  |  | (1,543) |  |  | (1,381) |  |  | (3,095) |  |  | (2,753) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (461) |  |  | (225) |  |  | (219) |  |  | (686) |  |  | (388) |  |
| Issuance of common stock |  | 71 |  |  | 35 |  |  | 91 |  |  | 106 |  |  | 128 |  |
| Other |  | (2) |  |  | (28) |  |  | (6) |  |  | (30) |  |  | (10) |  |
| Net cash provided by (used in) financing activities |  | (3,477) |  |  | (1,057) |  |  | (474) |  |  | (4,534) |  |  | 9,580 |  |
| Net change in cash and cash equivalents |  | (34) |  |  | 1,934 |  |  | 2,763 |  |  | 1,900 |  |  | 4,152 |  |
| Cash and cash equivalents at beginning of period |  | 9,552 |  |  | 7,618 |  |  | 6,444 |  |  | 7,618 |  |  | 5,055 |  |
| Cash and cash equivalents at end of period |  | $ | 9,518 |  |  | $ | 9,552 |  |  | $ | 9,207 |  |  | $ | 9,518 |  |  | $ | 9,207 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 369 |  |  | $ | 372 |  |  | $ | 375 |  |  | $ | 741 |  |  | $ | 756 |  |
| Cash paid for income taxes |  | $ | 293 |  |  | $ | 147 |  |  | $ | 124 |  |  | $ | 440 |  |  | $ | 255 |  |

## item 5.02 — body, verbatim

[0001730168-21-000110:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001730168-21-000110:8k_body:2]
On June 2, 2021, the Board of Directors of the Company (the “Board”) amended the Company’s Policy on Acceleration of Executive Staff Equity Awards in the Event of Permanent Disability (the “Acceleration Upon Permanent Disability Policy”) and Policy on Acceleration of Equity Awards in the Event of Death (the “Acceleration Upon Death Policy”). These policies were amended to provide that upon a permanent disability or death (as each is defined in such policies), for each outstanding and unvested performance-based equity award for which vesting has already commenced but the performance criteria has not yet been met, the performance criteria shall be deemed achieved at one hundred percent (100%) of target level.

[0001730168-21-000110:8k_body:3]
The foregoing summary of the material amendments to the Acceleration Upon Permanent Disability Policy and the Acceleration Upon Death Policy is qualified in its entirety by reference to the full text of such policies, which are attached hereto as Exhibits 10.1 and 10.2, respectively.
