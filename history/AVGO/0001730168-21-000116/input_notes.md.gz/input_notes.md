# AVGO notes — 0001730168-21-000116


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-21-000116:notes:1]
[same as prior period, unchanged from 0001730168-21-000045:notes:1]

[0001730168-21-000116:notes:2]
[same as prior period, unchanged from 0001730168-21-000045:notes:2]

[0001730168-21-000116:notes:3]
[same as prior period, unchanged from 0001730168-21-000045:notes:3]

[0001730168-21-000116:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

[0001730168-21-000116:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 2, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.

[0001730168-21-000116:notes:6]
[same as prior period, unchanged from 0001730168-21-000045:notes:6]

[0001730168-21-000116:notes:7]
[same as prior period, unchanged from 0001730168-21-000045:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-21-000116:notes:8]
[same as prior period, unchanged from 0001730168-21-000045:notes:9]

[0001730168-21-000116:notes:9]
[same as prior period, unchanged from 0001730168-21-000045:notes:10]

[0001730168-21-000116:notes:10]
[same as prior period, unchanged from 0001730168-21-000045:notes:11]

[0001730168-21-000116:notes:11]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

[0001730168-21-000116:notes:12]
|  |  | Fiscal Quarter Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

[0001730168-21-000116:notes:13]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

[0001730168-21-000116:notes:14]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

[0001730168-21-000116:notes:15]
[same as prior period, unchanged from 0001730168-21-000045:notes:14]

[0001730168-21-000116:notes:16]
[same as prior period, unchanged from 0001730168-21-000045:notes:15]

[0001730168-21-000116:notes:17]
[same as prior period, unchanged from 0001730168-21-000045:notes:16]

[0001730168-21-000116:notes:18]
[same as prior period, unchanged from 0001730168-21-000045:notes:17]

[0001730168-21-000116:notes:19]
[same as prior period, unchanged from 0001730168-21-000045:notes:18]

[0001730168-21-000116:notes:20]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of May 2, 2021 |  | $ | 128 |  |  | $ | 4,097 |  |

[0001730168-21-000116:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 2, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,853 million. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million.

[0001730168-21-000116:notes:22]
[same as prior period, unchanged from 0001730168-21-000045:notes:21]

[0001730168-21-000116:notes:23]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are not considered committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-21-000116:notes:24]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of May 2, 2021 were approximately $6.1 billion. We expect approximately 26% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-21-000116:notes:25]
[same as prior period, unchanged from 0001730168-21-000045:notes:25]

[0001730168-21-000116:notes:26]
[same as prior period, unchanged from 0001730168-21-000045:notes:26]

[0001730168-21-000116:notes:27]
[same as prior period, unchanged from 0001730168-21-000045:notes:27]

[0001730168-21-000116:notes:28]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if we had completed the Symantec Asset Purchase as of the beginning of our fiscal year ended November 3, 2019 (“fiscal year 2019”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-21-000116:notes:29]
|  |  |  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |
|  |  |  |  | May 3,2020 |  |  |  | May 3,2020 |
|  |  |  |  | (In millions) |
| Pro forma net revenue |  |  |  | $ | 5,568 |  |  |  |  | $ | 11,207 |  |
| Pro forma net income attributable to common stock |  |  |  | $ | 403 |  |  |  |  | $ | 632 |  |

[0001730168-21-000116:notes:30]
[same as prior period, unchanged from 0001730168-21-000045:notes:30]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-21-000116:notes:31]
[same as prior period, unchanged from 0001730168-21-000045:notes:31]

[0001730168-21-000116:notes:32]
Cash equivalents included $3,188 million and $2,471 million of time deposits and $1,385 million and $790 million of money-market funds as of May 2, 2021 and November 1, 2020, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-21-000116:notes:33]
[same as prior period, unchanged from 0001730168-21-000045:notes:33]

[0001730168-21-000116:notes:34]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $900 million and $1,827 million during the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and $926 million and $1,827 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-21-000116:notes:35]
[same as prior period, unchanged from 0001730168-21-000045:notes:36]

[0001730168-21-000116:notes:36]
|  |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Finished goods |  | $ | 321 |  |  | $ | 323 |  |
| Work-in-process |  | 559 |  |  | 558 |  |
| Raw materials |  | 124 |  |  | 122 |  |
| Total inventory |  | $ | 1,004 |  |  | $ | 1,003 |  |

[0001730168-21-000116:notes:37]
[same as prior period, unchanged from 0001730168-21-000045:notes:38]

[0001730168-21-000116:notes:38]
|  |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 604 |  |  | $ | 387 |  |
| Other (miscellaneous) |  | 694 |  |  | 590 |  |
| Total other current assets |  | $ | 1,298 |  |  | $ | 977 |  |

[0001730168-21-000116:notes:39]
[same as prior period, unchanged from 0001730168-21-000045:notes:40]

[0001730168-21-000116:notes:40]
|  |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,409 |  |  | $ | 2,620 |  |
| Tax liabilities |  | 506 |  |  | 440 |  |
| Interest payable |  | 335 |  |  | 304 |  |
| Other (miscellaneous) |  | 439 |  |  | 467 |  |
| Total other current liabilities |  | $ | 4,689 |  |  | $ | 3,831 |  |

[0001730168-21-000116:notes:41]
[same as prior period, unchanged from 0001730168-21-000045:notes:42]

[0001730168-21-000116:notes:42]
|  |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,188 |  |  | $ | 3,185 |  |
| Contract liabilities |  | 688 |  |  | 823 |  |
| Other (miscellaneous) |  | 1,086 |  |  | 1,418 |  |
| Total other long-term liabilities |  | $ | 4,962 |  |  | $ | 5,426 |  |

[0001730168-21-000116:notes:43]
[same as prior period, unchanged from 0001730168-21-000045:notes:44]

[0001730168-21-000116:notes:44]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 369 |  |  | $ | 375 |  |  | $ | 741 |  |  | $ | 756 |  |
| Cash paid for income taxes |  | $ | 293 |  |  | $ | 124 |  |  | $ | 440 |  |  | $ | 255 |  |

[0001730168-21-000116:notes:45]
As of May 2, 2021 and May 3, 2020, $38 million and $53 million, respectively, of unpaid purchases of property, plant and equipment were included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001730168-21-000116:notes:46]
[same as prior period, unchanged from 0001730168-21-000045:notes:47]

[0001730168-21-000116:notes:47]
|  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | 43,447 |  |
| Acquisition |  | — |  |  | 10 |  |  | 10 |  |
| Balance as of May 2, 2021 |  | $ | 25,959 |  |  | $ | 17,498 |  |  | $ | 43,457 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-21-000116:notes:48]
[same as prior period, unchanged from 0001730168-21-000045:notes:49]

[0001730168-21-000116:notes:49]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of May 2, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,126 |  |  | $ | (15,648) |  |  | $ | 8,478 |  |
| Customer contracts and related relationships |  | 8,392 |  |  | (3,871) |  |  | 4,521 |  |
| Order backlog |  | 2,579 |  |  | (2,094) |  |  | 485 |  |
| Trade names |  | 797 |  |  | (360) |  |  | 437 |  |
| Other |  | 248 |  |  | (126) |  |  | 122 |  |
| Intangible assets subject to amortization |  | 36,142 |  |  | (22,099) |  |  | 14,043 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,167 |  |  | $ | (22,099) |  |  | $ | 14,068 |  |
| As of November 1, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,119 |  |  | $ | (13,925) |  |  | $ | 10,194 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (3,179) |  |  | 5,210 |  |
| Order backlog |  | 2,579 |  |  | (1,836) |  |  | 743 |  |
| Trade names |  | 797 |  |  | (322) |  |  | 475 |  |
| Other |  | 252 |  |  | (117) |  |  | 135 |  |
| Intangible assets subject to amortization |  | 36,136 |  |  | (19,379) |  |  | 16,757 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,161 |  |  | $ | (19,379) |  |  | $ | 16,782 |  |

[0001730168-21-000116:notes:50]
Based on the amount of intangible assets subject to amortization at May 2, 2021, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-21-000116:notes:51]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 2,695 |  |
| 2022 |  | 4,367 |  |
| 2023 |  | 3,237 |  |
| 2024 |  | 2,367 |  |
| 2025 |  | 657 |  |
| Thereafter |  | 720 |  |
| Total |  | $ | 14,043 |  |

[0001730168-21-000116:notes:52]
[same as prior period, unchanged from 0001730168-21-000045:notes:53]

[0001730168-21-000116:notes:53]
| Amortizable intangible assets: |  | May 2,2021 |
|  |  | (In years) |
| Purchased technology |  | 4 |
| Customer contracts and related relationships |  | 4 |
| Order backlog |  | 2 |
| Trade names |  | 9 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-21-000116:notes:54]
[same as prior period, unchanged from 0001730168-21-000045:notes:55]

[0001730168-21-000116:notes:55]
[same as prior period, unchanged from 0001730168-21-000045:notes:56]

[0001730168-21-000116:notes:56]
[same as prior period, unchanged from 0001730168-21-000045:notes:57]

[0001730168-21-000116:notes:57]
For each of the fiscal quarter and two fiscal quarters ended May 2, 2021, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive. For each of the fiscal quarter and two fiscal quarters ended May 3, 2020, diluted net income per share excluded the potentially dilutive effect of 13 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-21-000116:notes:58]
[same as prior period, unchanged from 0001730168-21-000045:notes:59]

[0001730168-21-000116:notes:59]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1,493 |  |  | $ | 568 |  |  | $ | 2,871 |  |  | $ | 948 |  |
| Dividends on preferred stock |  | (76) |  |  | (75) |  |  | (150) |  |  | (149) |  |
| Income from continuing operations attributable to common stock |  | 1,417 |  |  | 493 |  |  | 2,721 |  |  | 799 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | — |  |  | (5) |  |  | — |  |  | — |  |
| Net income attributable to common stock |  | $ | 1,417 |  |  | $ | 488 |  |  | $ | 2,721 |  |  | $ | 799 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 409 |  |  | 401 |  |  | 408 |  |  | 400 |  |
| Dilutive effect of equity awards |  | 20 |  |  | 16 |  |  | 21 |  |  | 19 |  |
| Weighted-average shares outstanding - diluted |  | 429 |  |  | 417 |  |  | 429 |  |  | 419 |  |

[0001730168-21-000116:notes:60]
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.46 |  |  | $ | 1.23 |  |  | $ | 6.67 |  |  | $ | 2.00 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 3.46 |  |  | $ | 1.22 |  |  | $ | 6.67 |  |  | $ | 2.00 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.30 |  |  | $ | 1.18 |  |  | $ | 6.34 |  |  | $ | 1.91 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 3.30 |  |  | $ | 1.17 |  |  | $ | 6.34 |  |  | $ | 1.91 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-21-000116:notes:61]
Borrowings

[0001730168-21-000116:notes:62]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |

[0001730168-21-000116:notes:63]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,123) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,376 |  |  | $ | 40,994 |  |

[0001730168-21-000116:notes:64]
As of May 2, 2021 and November 1, 2020, short-term finance lease liabilities of $23 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $39 million and $48 million, respectively, were included in long-term debt.

[0001730168-21-000116:notes:65]
March 2021 Senior Notes

[0001730168-21-000116:notes:66]
In March 2021, we completed the settlement of our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-21-000116:notes:67]
In connection with the Exchange Offer, Broadcom Corporation and Broadcom Technologies Inc. were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes.

[0001730168-21-000116:notes:68]
January 2021 Senior Notes

[0001730168-21-000116:notes:69]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-21-000116:notes:70]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

[0001730168-21-000116:notes:71]
During the fiscal quarter ended May 2, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain outstanding notes maturing between 2021 and 2023. Using the remaining proceeds from the January 2021 Senior Notes, we repurchased $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022 and repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.

[0001730168-21-000116:notes:72]
January 2021 Credit Agreement

[0001730168-21-000116:notes:73]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of May 2, 2021, we had no borrowings outstanding under the Revolving Facility.

[0001730168-21-000116:notes:74]
Commercial Paper

[0001730168-21-000116:notes:75]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of May 2, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

[0001730168-21-000116:notes:76]
Fair Value of Debt

[0001730168-21-000116:notes:77]
As of May 2, 2021, the estimated aggregate fair value of debt was $43,868 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-21-000116:notes:78]
Future Principal Payments of Debt

[0001730168-21-000116:notes:79]
The future scheduled principal payments of debt as of May 2, 2021 were as follows:

[0001730168-21-000116:notes:80]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |

[0001730168-21-000116:notes:81]
As of May 2, 2021 and November 1, 2020, we accrued interest payable of $335 million and $304 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-21-000116:notes:82]
[same as prior period, unchanged from 0001730168-21-000045:notes:79]

[0001730168-21-000116:notes:83]
[same as prior period, unchanged from 0001730168-21-000045:notes:80]

[0001730168-21-000116:notes:84]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of May 2, 2021, the minimum conversion rate was 3.0700 and the maximum conversion rate was 3.5884.

[0001730168-21-000116:notes:85]
As of each May 2, 2021 and November 1, 2020, we recognized $27 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets.

[0001730168-21-000116:notes:86]
[same as prior period, unchanged from 0001730168-21-000045:notes:83]

[0001730168-21-000116:notes:87]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.60 |  |  | $ | 3.25 |  |  | $ | 7.20 |  |  | $ | 6.50 |  |
| Dividends to common stockholders |  | $ | 1,477 |  |  | $ | 1,306 |  |  | $ | 2,945 |  |  | $ | 2,603 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |  | $ | 40.00 |  |  | $ | 40.00 |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | 75 |  |  | $ | 150 |  |  | $ | 150 |  |

[0001730168-21-000116:notes:88]
[same as prior period, unchanged from 0001730168-21-000045:notes:85]

[0001730168-21-000116:notes:89]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 21 |  |  | $ | 27 |  |  | $ | 41 |  |  | $ | 58 |  |
| Cost of subscriptions and services |  | 17 |  |  | 14 |  |  | 29 |  |  | 26 |  |
| Research and development |  | 307 |  |  | 373 |  |  | 635 |  |  | 764 |  |
| Selling, general and administrative |  | 80 |  |  | 103 |  |  | 164 |  |  | 214 |  |
| Total stock-based compensation expense |  | $ | 425 |  |  | $ | 517 |  |  | $ | 869 |  |  | $ | 1,062 |  |

[0001730168-21-000116:notes:90]
As of May 2, 2021, the total unrecognized compensation cost related to unvested stock-based awards was $3,716 million, which is expected to be recognized over the remaining weighted-average service period of 3.2 years.

[0001730168-21-000116:notes:91]
[same as prior period, unchanged from 0001730168-21-000045:notes:88]

[0001730168-21-000116:notes:92]
During the fiscal quarter ended May 2, 2021, our stockholders approved the amendment and restatement of our 2012 stock incentive plan, now called Broadcom Inc. 2012 Stock Incentive Plan (the “Amended 2012 Plan”). Under the Amended 2012 Plan, we may grant to all employees stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, and time- and market-based RSUs. The Amended 2012 Plan reduced the number of shares available for new equity award grants to 20 million shares and removed the annual share replenishment provision. We will make no further equity award grants under our LSI Corporation 2003 Equity Incentive Plan.

[0001730168-21-000116:notes:93]
[same as prior period, unchanged from 0001730168-21-000045:notes:89]

[0001730168-21-000116:notes:94]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 1, 2020 |  | 32 |  |  | $ | 188.35 |  |  |  |  |  |
| Granted |  | 1 |  |  | $ | 403.13 |  |  |  |  |  |
| Vested |  | (4) |  |  | $ | 210.46 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 193.38 |  |  |  |  |  |
| Balance as of May 2, 2021 |  | 28 |  |  | $ | 198.05 |  |  |  |  |  |

[0001730168-21-000116:notes:95]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended May 2, 2021 was $1,909 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-21-000116:notes:96]
[same as prior period, unchanged from 0001730168-21-000045:notes:95]

[0001730168-21-000116:notes:97]
The benefit from income taxes was $7 million and $1 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to $159 million and $235 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively.

[0001730168-21-000116:notes:98]
The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 2, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, substantially offset by higher taxes on income from continuing operations.

[0001730168-21-000116:notes:99]
The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 3, 2020 resulted from significant discrete items related to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards. These discrete items, together with the impact of the jurisdictional mix of income and expense, more than offset taxes on income from continuing operations.

[0001730168-21-000116:notes:100]
[same as prior period, unchanged from 0001730168-21-000045:notes:99]

[0001730168-21-000116:notes:101]
The balance of gross unrecognized tax benefits was $4,856 million and $4,748 million as of May 2, 2021 and November 1, 2020, respectively.

[0001730168-21-000116:notes:102]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of May 2, 2021 and November 1, 2020, the combined amount of cumulative accrued interest and penalties was approximately $349 million and $340 million, respectively.

[0001730168-21-000116:notes:103]
As of May 2, 2021 and November 1, 2020, approximately $5,205 million and $5,088 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-21-000116:notes:104]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $277 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-21-000116:notes:105]
[same as prior period, unchanged from 0001730168-21-000045:notes:103]

[0001730168-21-000116:notes:106]
[same as prior period, unchanged from 0001730168-21-000045:notes:104]

[0001730168-21-000116:notes:107]
[same as prior period, unchanged from 0001730168-21-000045:notes:105]

[0001730168-21-000116:notes:108]
[same as prior period, unchanged from 0001730168-21-000045:notes:106]

[0001730168-21-000116:notes:109]
[same as prior period, unchanged from 0001730168-21-000045:notes:107]

[0001730168-21-000116:notes:110]
[same as prior period, unchanged from 0001730168-21-000045:notes:108]

[0001730168-21-000116:notes:111]
[same as prior period, unchanged from 0001730168-21-000045:notes:109]

[0001730168-21-000116:notes:112]
[same as prior period, unchanged from 0001730168-21-000045:notes:110]

[0001730168-21-000116:notes:113]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the “Summary of Significant Accounting Policies” included in the Annual Report on Form 10-K for fiscal year 2020.

[0001730168-21-000116:notes:114]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,820 |  |  | $ | 4,027 |  |  | $ | 9,728 |  |  | $ | 8,218 |  |
| Infrastructure software |  | 1,790 |  |  | 1,715 |  |  | 3,537 |  |  | 3,382 |  |
| Total net revenue |  | $ | 6,610 |  |  | $ | 5,742 |  |  | $ | 13,265 |  |  | $ | 11,600 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,547 |  |  | $ | 1,891 |  |  | $ | 5,108 |  |  | $ | 3,934 |  |
| Infrastructure software |  | 1,255 |  |  | 1,140 |  |  | 2,474 |  |  | 2,181 |  |
| Unallocated expenses |  | (1,827) |  |  | (2,265) |  |  | (3,770) |  |  | (4,635) |  |
| Total operating income |  | $ | 1,975 |  |  | $ | 766 |  |  | $ | 3,812 |  |  | $ | 1,480 |  |

[0001730168-21-000116:notes:115]
[same as prior period, unchanged from 0001730168-21-000045:notes:113]

[0001730168-21-000116:notes:116]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. No customer accounted for 10% or more of our net accounts receivable balance as of May 2, 2021 or November 1, 2020.
One customer accounted for 17% and 18% of our net revenue for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and 14% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020. Net revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-21-000116:notes:117]
Commitments and Contingencies
Commitments

[0001730168-21-000116:notes:118]
The following table summarizes contractual obligations and commitments as of May 2, 2021 that materially changed from the end of fiscal year 2020:

[0001730168-21-000116:notes:119]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |  |  |
|  |  | (In millions) |  |  |
| 2021 (remainder) |  | $ | 811 |  |  | $ | 1,106 |  |  | $ | 89 |  |  |  |
| 2022 |  | 1,819 |  |  | 76 |  |  | 231 |  |  |  |
| 2023 |  | 1,950 |  |  | 38 |  |  | 220 |  |  |  |
| 2024 |  | 3,084 |  |  | — |  |  | 166 |  |  |  |
| 2025 |  | 3,276 |  |  | — |  |  | 73 |  |  |  |
| Thereafter |  | 46,048 |  |  | — |  |  | 245 |  |  |  |
| Total |  | $ | 56,988 |  |  | $ | 1,220 |  |  | $ | 1,024 |  |  |  |

[0001730168-21-000116:notes:120]
Debt Principal, Interest and Fees. Represents principal, interest and fees on our borrowings.

[0001730168-21-000116:notes:121]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-21-000116:notes:122]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-21-000116:notes:123]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 2, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,188 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 2, 2021 have been excluded from the table above.

[0001730168-21-000116:notes:124]
Standby Letters of Credit

[0001730168-21-000116:notes:125]
As of May 2, 2021 and November 1, 2020, we had standby letters of credit of $59 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-21-000116:notes:126]
Contingencies

[0001730168-21-000116:notes:127]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-21-000116:notes:128]
Lawsuits Relating to California Institute of Technology

[0001730168-21-000116:notes:129]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit.

[0001730168-21-000116:notes:130]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the

[0001730168-21-000116:notes:131]
ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

[0001730168-21-000116:notes:132]
Other Matters

[0001730168-21-000116:notes:133]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-21-000116:notes:134]
Contingency Assessment

[0001730168-21-000116:notes:135]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-21-000116:notes:136]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-21-000116:notes:137]
Other Indemnifications

[0001730168-21-000116:notes:138]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-21-000116:notes:139]
[same as prior period, unchanged from 0001730168-21-000045:notes:137]

[0001730168-21-000116:notes:140]
•During the first quarter of fiscal year 2021, we initiated cost reduction activities associated with plans to align our workforce with strategic business activities and to improve efficiencies in our operations. As a result, we recognized $23 million and $98 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively.

[0001730168-21-000116:notes:141]
•We recognized $57 million and $109 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. The restructuring expense during the fiscal quarter ended May 3, 2020 was primarily related to cost reduction activities associated with the Symantec Asset Purchase. The restructuring expense during the two fiscal quarters ended May 3, 2020 was related to cost reduction activities related to the Symantec Asset Purchase of $90 million and cost reduction activities related to our acquisition of CA, Inc. of $19 million.

[0001730168-21-000116:notes:142]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the two fiscal quarters ended May 2, 2021:

[0001730168-21-000116:notes:143]
|  |  | Employee Termination Costs |  | Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |
| Restructuring charges |  | 72 |  |  | 9 |  |  | 81 |  |
| Utilization |  | (72) |  |  | (9) |  |  | (81) |  |
| Balance as of May 2, 2021 (a) |  | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |

[0001730168-21-000116:notes:144]
[same as prior period, unchanged from 0001730168-21-000045:notes:143]

[0001730168-21-000116:notes:145]
(a) We expect the majority of the employee termination costs balance to be paid within the next six months.

[0001730168-21-000116:notes:146]
Restructuring, impairment and disposal charges in our condensed consolidated statement of operations for the two fiscal quarters ended May 2, 2021 included $17 million for the write-down of certain lease-related right-of-use assets and other lease-related charges. As of May 2, 2021, short-term and long-term lease liabilities included $76 million of liabilities related to restructuring activities.


## us-gaap:SubsequentEventsTextBlock

[0001730168-21-000116:notes:147]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-21-000116:notes:148]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2021 to stockholders of record on June 15, 2021.

[0001730168-21-000116:notes:149]
Common Stock Cash Dividends Declared

[0001730168-21-000116:notes:150]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on June 30, 2021 to stockholders of record on June 22, 2021.
