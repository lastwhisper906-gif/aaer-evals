# AVGO note change history — 0001730168-21-000045 → 0001730168-21-000116


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-06-11):
[0001730168-21-000116:note_history:1]
The following table summarizes contractual obligations and commitments as of May 2, 2021 that materially changed from the end of fiscal year 2020:
  (was, 2021-03-12, similarity 0.9787):
[0001730168-21-000045:note_history:1]
The following table summarizes contractual obligations and commitments as of January 31, 2021 that materially changed from the end of fiscal year 2020:

- changed (2021-06-11):
[0001730168-21-000116:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 2, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,188 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 2, 2021 have been excluded from the table above.
  (was, 2021-03-12, similarity 0.9581):
[0001730168-21-000045:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 31, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,210 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of January 31, 2021 have been excluded from the contractual obligations table above.

- changed (2021-06-11):
[0001730168-21-000116:note_history:3]
As of May 2, 2021 and November 1, 2020, we had standby letters of credit of $59 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.
  (was, 2021-03-12, similarity 0.9877):
[0001730168-21-000045:note_history:3]
As of January 31, 2021 and November 1, 2020, we had standby letters of credit of $62 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- changed (2021-06-11):
[0001730168-21-000116:note_history:4]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the
  (was, 2021-03-12, similarity 0.8969):
[0001730168-21-000045:note_history:4]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

- added (2021-06-11):
[0001730168-21-000116:note_history:5]
ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

- changed (2021-06-11):
[0001730168-21-000116:note_history:6]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.
  (was, 2021-03-12, similarity 0.7094):
[0001730168-21-000045:note_history:6]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory

- removed (2021-06-11):
[0001730168-21-000045:note_history:7]
investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-06-11):
[0001730168-21-000116:note_history:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.
  (was, 2021-03-12, similarity 0.9967):
[0001730168-21-000045:note_history:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ends on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

- changed (2021-06-11):
[0001730168-21-000116:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 2, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.
  (was, 2021-03-12, similarity 0.9783):
[0001730168-21-000045:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 31, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.

- removed (2021-06-11):
[0001730168-21-000045:note_history:10]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to the current period presentation. These reclassifications had no impact on previously reported net cash activities.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-11):
[0001730168-21-000116:note_history:11]
The future scheduled principal payments of debt as of May 2, 2021 were as follows:
  (was, 2021-03-12, similarity 0.9625):
[0001730168-21-000045:note_history:11]
The future scheduled principal payments of debt as of January 31, 2021 were as follows:

- changed (2021-06-11):
[0001730168-21-000116:note_history:12]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |
  (was, 2021-03-12, similarity 0.9952):
[0001730168-21-000045:note_history:12]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 274 |  |
| 2022 |  | 910 |  |
| 2023 |  | 404 |  |
| 2024 |  | 2,515 |  |
| 2025 |  | 3,250 |  |
| Thereafter |  | 35,073 |  |
| Total |  | $ | 42,426 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-06-11):
[0001730168-21-000116:note_history:13]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:14]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,123) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,376 |  |  | $ | 40,994 |  |

- changed (2021-06-11):
[0001730168-21-000116:note_history:15]
As of May 2, 2021 and November 1, 2020, short-term finance lease liabilities of $23 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $39 million and $48 million, respectively, were included in long-term debt.
  (was, 2021-03-12, similarity 0.986):
[0001730168-21-000045:note_history:15]
As of January 31, 2021 and November 1, 2020, short-term finance lease liabilities of $21 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $43 million and $48 million, respectively, were included in long-term debt.

- added (2021-06-11):
[0001730168-21-000116:note_history:16]
March 2021 Senior Notes

- changed (2021-06-11):
[0001730168-21-000116:note_history:17]
In March 2021, we completed the settlement of our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.
  (was, 2021-03-12, similarity 0.6131):
[0001730168-21-000045:note_history:17]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). The January 2021 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation and Broadcom Technologies Inc. At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of January 31, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- added (2021-06-11):
[0001730168-21-000116:note_history:18]
In connection with the Exchange Offer, Broadcom Corporation and Broadcom Technologies Inc. were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes.

- added (2021-06-11):
[0001730168-21-000116:note_history:19]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- changed (2021-06-11):
[0001730168-21-000116:note_history:20]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.
  (was, 2021-03-12, similarity 0.9956):
[0001730168-21-000045:note_history:20]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain series of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

- added (2021-06-11):
[0001730168-21-000116:note_history:21]
During the fiscal quarter ended May 2, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain outstanding notes maturing between 2021 and 2023. Using the remaining proceeds from the January 2021 Senior Notes, we repurchased $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022 and repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.

- changed (2021-06-11):
[0001730168-21-000116:note_history:22]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of May 2, 2021, we had no borrowings outstanding under the Revolving Facility.
  (was, 2021-03-12, similarity 0.9957):
[0001730168-21-000045:note_history:22]
In January 2021, we entered into a credit agreement ( the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of January 31, 2021, we had no borrowings outstanding under the Revolving Facility.

- changed (2021-06-11):
[0001730168-21-000116:note_history:23]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of May 2, 2021 and November 1, 2020, we had no Commercial Paper outstanding.
  (was, 2021-03-12, similarity 0.9959):
[0001730168-21-000045:note_history:23]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of January 31, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

- changed (2021-06-11):
[0001730168-21-000116:note_history:24]
As of May 2, 2021, the estimated aggregate fair value of debt was $43,868 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2021-03-12, similarity 0.9832):
[0001730168-21-000045:note_history:24]
As of January 31, 2021, the estimated aggregate fair value of debt was $46,533 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2021-06-11):
[0001730168-21-000116:note_history:25]
The future scheduled principal payments of debt as of May 2, 2021 were as follows:
  (was, 2021-03-12, similarity 0.9625):
[0001730168-21-000045:note_history:25]
The future scheduled principal payments of debt as of January 31, 2021 were as follows:

- changed (2021-06-11):
[0001730168-21-000116:note_history:26]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |
  (was, 2021-03-12, similarity 0.9952):
[0001730168-21-000045:note_history:26]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 274 |  |
| 2022 |  | 910 |  |
| 2023 |  | 404 |  |
| 2024 |  | 2,515 |  |
| 2025 |  | 3,250 |  |
| Thereafter |  | 35,073 |  |
| Total |  | $ | 42,426 |  |

- changed (2021-06-11):
[0001730168-21-000116:note_history:27]
As of May 2, 2021 and November 1, 2020, we accrued interest payable of $335 million and $304 million, respectively, and were in compliance with all debt covenants.
  (was, 2021-03-12, similarity 0.9803):
[0001730168-21-000045:note_history:27]
As of January 31, 2021 and November 1, 2020, we accrued interest payable of $308 million and $304 million, respectively, and were in compliance with all debt covenants.

- removed (2021-06-11):
[0001730168-21-000045:note_history:28]
|  |  | Effective Interest Rate |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | $ | 750 |  |  | $ | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 112 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 274 |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 188 |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 569 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 261 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 144 |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 42,426 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (558) |  |  | (504) |  |
| Total debt |  |  |  | $ | 41,868 |  |  | $ | 40,994 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:29]
Subsequent to the fiscal quarter ended January 31, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain series of our outstanding notes maturing between 2021 and 2023. In February 2021, we used the remaining proceeds from the January 2021 Senior Notes to repurchase $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022. On March 5, 2021, we repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-06-11):
[0001730168-21-000116:note_history:30]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:31]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,123) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,376 |  |  | $ | 40,994 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:32]
|  |  | Effective Interest Rate |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | $ | 750 |  |  | $ | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 112 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 274 |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 188 |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 569 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 261 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 144 |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 42,426 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (558) |  |  | (504) |  |
| Total debt |  |  |  | $ | 41,868 |  |  | $ | 40,994 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-06-11):
[0001730168-21-000116:note_history:33]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:34]
|  |  | Fiscal Quarter Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:35]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:36]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:37]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:38]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-06-11):
[0001730168-21-000116:note_history:39]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:40]
|  |  | Fiscal Quarter Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:41]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- added (2021-06-11):
[0001730168-21-000116:note_history:42]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- changed (2021-06-11):
[0001730168-21-000116:note_history:43]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of May 2, 2021 |  | $ | 128 |  |  | $ | 4,097 |  |
  (was, 2021-03-12, similarity 0.9829):
[0001730168-21-000045:note_history:43]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of January 1, 2021 |  | $ | 160 |  |  | $ | 3,833 |  |

- changed (2021-06-11):
[0001730168-21-000116:note_history:44]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 2, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,853 million. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million.
  (was, 2021-03-12, similarity 0.9785):
[0001730168-21-000045:note_history:44]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million.

- added (2021-06-11):
[0001730168-21-000116:note_history:45]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are not considered committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- added (2021-06-11):
[0001730168-21-000116:note_history:46]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of May 2, 2021 were approximately $6.1 billion. We expect approximately 26% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2021-06-11):
[0001730168-21-000045:note_history:47]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:48]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- removed (2021-06-11):
[0001730168-21-000045:note_history:49]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and

- removed (2021-06-11):
[0001730168-21-000045:note_history:50]
recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- removed (2021-06-11):
[0001730168-21-000045:note_history:51]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of January 31, 2021 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-06-11):
[0001730168-21-000116:note_history:52]
Subsequent Events
Preferred Stock Cash Dividends Declared

- added (2021-06-11):
[0001730168-21-000116:note_history:53]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2021 to stockholders of record on June 15, 2021.

- added (2021-06-11):
[0001730168-21-000116:note_history:54]
Common Stock Cash Dividends Declared

- added (2021-06-11):
[0001730168-21-000116:note_history:55]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on June 30, 2021 to stockholders of record on June 22, 2021.
