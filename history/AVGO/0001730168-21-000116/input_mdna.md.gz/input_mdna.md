# AVGO MD&A — 0001730168-21-000116


## mdna

[0001730168-21-000116:mdna:1]
[same as prior period, unchanged from 0001730168-21-000045:mdna:1]

[0001730168-21-000116:mdna:2]
[same as prior period, unchanged from 0001730168-21-000045:mdna:18]

[0001730168-21-000116:mdna:3]
[same as prior period, unchanged from 0001730168-21-000045:mdna:2]

[0001730168-21-000116:mdna:4]
[same as prior period, unchanged from 0001730168-21-000045:mdna:3]

[0001730168-21-000116:mdna:5]
[same as prior period, unchanged from 0001730168-21-000045:mdna:4]

[0001730168-21-000116:mdna:6]
[same as prior period, unchanged from 0001730168-21-000045:mdna:5]

[0001730168-21-000116:mdna:7]
[same as prior period, unchanged from 0001730168-21-000045:mdna:6]

[0001730168-21-000116:mdna:8]
Highlights during the fiscal quarter ended May 2, 2021 include the following:

[0001730168-21-000116:mdna:9]
•We generated $3,569 million of cash from operations.

[0001730168-21-000116:mdna:10]
•We paid $1,552 million in cash dividends.

[0001730168-21-000116:mdna:11]
•We repurchased $929 million of certain of our outstanding notes.

[0001730168-21-000116:mdna:12]
[same as prior period, unchanged from 0001730168-21-000045:mdna:10]

[0001730168-21-000116:mdna:13]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in many of our employees working remotely for an extended period of time. While we have implemented a phased-in return of employees to many of our facilities, we may need to modify our business practices. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-21-000116:mdna:14]
The demand environment for our semiconductor products was consistent with our expectations for the second quarter of our fiscal year ending October 31, 2021 (“fiscal year 2021”), with continued demand for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this area, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, we continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. While supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet increased demand.

[0001730168-21-000116:mdna:15]
[same as prior period, unchanged from 0001730168-21-000045:mdna:13]

[0001730168-21-000116:mdna:16]
[same as prior period, unchanged from 0001730168-21-000045:mdna:14]

[0001730168-21-000116:mdna:17]
[same as prior period, unchanged from 0001730168-21-000045:mdna:27]

[0001730168-21-000116:mdna:18]
[same as prior period, unchanged from 0001730168-21-000045:mdna:15]

[0001730168-21-000116:mdna:19]
[same as prior period, unchanged from 0001730168-21-000045:mdna:16]

[0001730168-21-000116:mdna:20]
There were no significant changes in our critical accounting policies during the two fiscal quarters ended May 2, 2021 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2020 Annual Report on Form 10-K.

[0001730168-21-000116:mdna:21]
[same as prior period, unchanged from 0001730168-21-000045:mdna:19]

[0001730168-21-000116:mdna:22]
Fiscal Quarter and Two Fiscal Quarters Ended May 2, 2021 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 3, 2020

[0001730168-21-000116:mdna:23]
The following tables set forth our results of operations for the periods presented:

[0001730168-21-000116:mdna:24]
|  |  | Fiscal Quarter Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,983 |  |  | $ | 4,253 |  |  | 75 | % |  | 74 | % |
| Subscriptions and services |  | 1,627 |  |  | 1,489 |  |  | 25 |  |  | 26 |  |
| Total net revenue |  | 6,610 |  |  | 5,742 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,548 |  |  | 1,448 |  |  | 24 |  |  | 25 |  |
| Cost of subscriptions and services |  | 151 |  |  | 144 |  |  | 2 |  |  | 3 |  |
| Amortization of acquisition-related intangible assets |  | 853 |  |  | 954 |  |  | 13 |  |  | 17 |  |
| Restructuring charges |  | 1 |  |  | 7 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,553 |  |  | 2,553 |  |  | 39 |  |  | 45 |  |
| Gross margin |  | 4,057 |  |  | 3,189 |  |  | 61 |  |  | 55 |  |
| Research and development |  | 1,238 |  |  | 1,269 |  |  | 19 |  |  | 22 |  |
| Selling, general and administrative |  | 325 |  |  | 501 |  |  | 5 |  |  | 9 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 599 |  |  | 7 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 25 |  |  | 54 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 2,082 |  |  | 2,423 |  |  | 31 |  |  | 42 |  |
| Operating income |  | $ | 1,975 |  |  | $ | 766 |  |  | 30 | % |  | 13 | % |

[0001730168-21-000116:mdna:25]
[same as prior period, unchanged from 0001730168-21-000045:mdna:42]

[0001730168-21-000116:mdna:26]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 10,064 |  |  | $ | 8,457 |  |  | 76 | % |  | 73 | % |
| Subscriptions and services |  | 3,201 |  |  | 3,143 |  |  | 24 |  |  | 27 |  |
| Total net revenue |  | 13,265 |  |  | 11,600 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 3,220 |  |  | 2,907 |  |  | 25 |  |  | 25 |  |
| Cost of subscriptions and services |  | 293 |  |  | 321 |  |  | 2 |  |  | 3 |  |
| Amortization of acquisition-related intangible assets |  | 1,727 |  |  | 1,904 |  |  | 13 |  |  | 16 |  |
| Restructuring charges |  | 16 |  |  | 15 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,256 |  |  | 5,147 |  |  | 40 |  |  | 44 |  |
| Gross margin |  | 8,009 |  |  | 6,453 |  |  | 60 |  |  | 56 |  |
| Research and development |  | 2,449 |  |  | 2,558 |  |  | 18 |  |  | 22 |  |
| Selling, general and administrative |  | 664 |  |  | 1,102 |  |  | 5 |  |  | 10 |  |
| Amortization of acquisition-related intangible assets |  | 988 |  |  | 1,202 |  |  | 7 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 96 |  |  | 111 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 4,197 |  |  | 4,973 |  |  | 31 |  |  | 43 |  |
| Operating income |  | $ | 3,812 |  |  | $ | 1,480 |  |  | 29 | % |  | 13 | % |

[0001730168-21-000116:mdna:27]
[same as prior period, unchanged from 0001730168-21-000045:mdna:23]

[0001730168-21-000116:mdna:28]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 17% and 18% of our net revenue for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and 14% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020.

[0001730168-21-000116:mdna:29]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 2, 2021 and approximately 30% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020. We believe aggregate sales to Apple Inc., through all channels, accounted for less than 25% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 2, 2021 and less than 20% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-21-000116:mdna:30]
[same as prior period, unchanged from 0001730168-21-000045:mdna:26]

[0001730168-21-000116:mdna:31]
27

[0001730168-21-000116:mdna:32]
[same as prior period, unchanged from 0001730168-21-000045:mdna:28]

[0001730168-21-000116:mdna:33]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 2, 2021 |  | May 3, 2020 |  | $ Change |  | % Change |  | May 2, 2021 |  | May 3, 2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,820 |  |  | $ | 4,027 |  |  | $ | 793 |  |  | 20 | % |  | $ | 9,728 |  |  | $ | 8,218 |  |  | $ | 1,510 |  |  | 18 | % |
| Infrastructure software |  | 1,790 |  |  | 1,715 |  |  | 75 |  |  | 4 | % |  | 3,537 |  |  | 3,382 |  |  | 155 |  |  | 5 | % |
| Total net revenue |  | $ | 6,610 |  |  | $ | 5,742 |  |  | $ | 868 |  |  | 15 | % |  | $ | 13,265 |  |  | $ | 11,600 |  |  | $ | 1,665 |  |  | 14 | % |

[0001730168-21-000116:mdna:34]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 2,2021 |  | May 3,2020 |  | May 2,2021 |  | May 3,2020 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 73 | % |  | 70 | % |  | 73 | % |  | 71 | % |
| Infrastructure software |  | 27 |  |  | 30 |  |  | 27 |  |  | 29 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-21-000116:mdna:35]
Fiscal quarter ended May 2, 2021 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the quarter, compared to the prior year fiscal period. Net revenue from our semiconductor solutions segment also increased due to higher demand for our broadband and networking products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions, FC SAN products and cyber security solutions.

[0001730168-21-000116:mdna:36]
Two fiscal quarters ended May 2, 2021 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the current year period, compared to the prior year fiscal period. Net revenue from our semiconductor solutions segment also increased due to higher demand for our networking and broadband products, partially offset by lower demand for our server storage products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions, FC SAN products and cyber security solutions.

[0001730168-21-000116:mdna:37]
[same as prior period, unchanged from 0001730168-21-000045:mdna:32]

[0001730168-21-000116:mdna:38]
Gross margin was $4,057 million for the fiscal quarter ended May 2, 2021 compared to $3,189 million for the fiscal quarter ended May 3, 2020 and $8,009 million for the two fiscal quarters ended May 2, 2021 compared to $6,453 million for the two fiscal quarters ended May 3, 2020. As a percentage of net revenue, gross margin was 61% and 60% of net revenue for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and 55% and 56% of net revenue for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively.

[0001730168-21-000116:mdna:39]
The increases in gross margin were primarily due to lower amortization of acquisition-related intangible assets, as well as favorable product mix within our semiconductor solutions segment and improvements in our cost structure within our infrastructure software segment compared to the prior year fiscal periods.

[0001730168-21-000116:mdna:40]
[same as prior period, unchanged from 0001730168-21-000045:mdna:34]

[0001730168-21-000116:mdna:41]
Research and development expense decreased $31 million, or 2%, and $109 million, or 4%, for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures, partially offset by higher variable employee compensation expense.

[0001730168-21-000116:mdna:42]
[same as prior period, unchanged from 0001730168-21-000045:mdna:36]

[0001730168-21-000116:mdna:43]
Selling, general and administrative expense decreased $176 million, or 35%, and $438 million, or 40%, for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to higher acquisition-related costs incurred in the prior year fiscal periods as a result of our acquisition of the Symantec Corporation Enterprise Security business (the “Symantec Business”). The decreases were also due to lower compensation expense reflecting the full benefit of the completed Symantec Business integration, as well as lower stock-based compensation expense. In addition, fiscal year 2020 included non-recurring litigation settlements.

[0001730168-21-000116:mdna:44]
[same as prior period, unchanged from 0001730168-21-000045:mdna:38]

[0001730168-21-000116:mdna:45]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $105 million and $214 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-21-000116:mdna:46]
[same as prior period, unchanged from 0001730168-21-000045:mdna:40]

[0001730168-21-000116:mdna:47]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $29 million and $15 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to higher employee termination costs in the prior year fiscal periods from our acquisition of the Symantec Business.

[0001730168-21-000116:mdna:48]
[same as prior period, unchanged from 0001730168-21-000045:mdna:43]

[0001730168-21-000116:mdna:49]
Total stock-based compensation expense was $425 million and $869 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, compared to $517 million and $1,062 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. The decreases primarily reflect the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-21-000116:mdna:50]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of May 2, 2021.

[0001730168-21-000116:mdna:51]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeiture |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 837 |  |
| 2022 |  | 1,274 |  |
| 2023 |  | 887 |  |
| 2024 |  | 507 |  |
| 2025 |  | 188 |  |
| Thereafter |  | 23 |  |
| Total |  | $ | 3,716 |  |

[0001730168-21-000116:mdna:52]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based restricted stock units (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-21-000116:mdna:53]
[same as prior period, unchanged from 0001730168-21-000045:mdna:48]

[0001730168-21-000116:mdna:54]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Operating Income by Segment |  | May 2,2021 |  | May 3,2020 |  | $ Change |  | % Change |  | May 2, 2021 |  | May 3, 2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 2,547 |  |  | $ | 1,891 |  |  | $ | 656 |  |  | 35 | % |  | $ | 5,108 |  |  | $ | 3,934 |  |  | $ | 1,174 |  |  | 30 | % |
| Infrastructure software |  | 1,255 |  |  | 1,140 |  |  | 115 |  |  | 10 | % |  | 2,474 |  |  | 2,181 |  |  | 293 |  |  | 13 | % |
| Unallocated expenses |  | (1,827) |  |  | (2,265) |  |  | 438 |  |  | (19) | % |  | (3,770) |  |  | (4,635) |  |  | 865 |  |  | (19) | % |
| Total operating income |  | $ | 1,975 |  |  | $ | 766 |  |  | $ | 1,209 |  |  | 158 | % |  | $ | 3,812 |  |  | $ | 1,480 |  |  | $ | 2,332 |  |  | 158 | % |

[0001730168-21-000116:mdna:55]
29

[0001730168-21-000116:mdna:56]
Fiscal quarter ended May 2, 2021 compared to corresponding prior year period. Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the quarter, compared to the prior year fiscal period. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and broadband products. Operating income from our infrastructure software segment increased primarily due to higher demand for our cyber security and mainframe solutions, as well as higher demand for our FC SAN products.

[0001730168-21-000116:mdna:57]
Two fiscal quarters ended May 2, 2021 compared to corresponding prior year period. Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the current year period, compared to the prior year fiscal period. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and broadband products, partially offset by lower demand for our server storage products. Operating income from our infrastructure software segment increased primarily due to higher demand for our mainframe and cyber security solutions, as well as higher demand for our FC SAN products.

[0001730168-21-000116:mdna:58]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 19% for each of the fiscal quarter and two fiscal quarters ended May 2, 2021 compared to prior year fiscal periods. The decreases were primarily due to amortization of acquisition-related intangible assets, acquisition-related costs and stock-based compensation expense.

[0001730168-21-000116:mdna:59]
[same as prior period, unchanged from 0001730168-21-000045:mdna:52]

[0001730168-21-000116:mdna:60]
Interest expense. Interest expense was $466 million and $1,036 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and $487 million and $893 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. The decrease for the fiscal quarter ended May 2, 2021 was primarily due to lower losses on extinguishment of debt related to refinancing activities, offset by higher interest expense. The increase for the two fiscal quarters ended May 2, 2021 was primarily due to higher losses on extinguishment of debt related to refinancing activities and higher interest expense.

[0001730168-21-000116:mdna:61]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other expense, net, was $23 million for the fiscal quarter ended May 2, 2021 compared to other income, net, of $130 million for the fiscal quarter ended May 3, 2020. The change was primarily due to a $116 million non-recurring gain from the lapse of a tax indemnification arrangement for the fiscal quarter ended May 3, 2020 and changes in investment gains or losses.

[0001730168-21-000116:mdna:62]
Other income, net, was $94 million and $126 million for the two fiscal quarters ended May 2, 2021 and May 3, 2020, respectively. The change was primarily due to the tax indemnification gain mentioned above which was substantially offset by changes in investment gains or losses.

[0001730168-21-000116:mdna:63]
Benefit from income taxes. The benefit from income taxes was $7 million and $1 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively, and $159 million and $235 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 2, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, substantially offset by higher taxes on income from continuing operations. The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 3, 2020 resulted from significant discrete items related to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards. These discrete items, together with the impact of the jurisdictional mix of income and expense, more than offset taxes on income from continuing operations.

[0001730168-21-000116:mdna:64]
[same as prior period, unchanged from 0001730168-21-000045:mdna:56]

[0001730168-21-000116:mdna:65]
[same as prior period, unchanged from 0001730168-21-000045:mdna:57]

[0001730168-21-000116:mdna:66]
Our primary sources of liquidity as of May 2, 2021 consisted of: (i) $9,518 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-21-000116:mdna:67]
30

[0001730168-21-000116:mdna:68]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $41,499 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect our capital expenditures for fiscal year 2021 to be slightly higher than fiscal year 2020.

[0001730168-21-000116:mdna:69]
[same as prior period, unchanged from 0001730168-21-000045:mdna:60]

[0001730168-21-000116:mdna:70]
[same as prior period, unchanged from 0001730168-21-000045:mdna:61]

[0001730168-21-000116:mdna:71]
[same as prior period, unchanged from 0001730168-21-000045:mdna:62]

[0001730168-21-000116:mdna:72]
[same as prior period, unchanged from 0001730168-21-000045:mdna:63]

[0001730168-21-000116:mdna:73]
Working capital increased to $7,809 million at May 2, 2021 from $5,524 million at November 1, 2020. The increase was primarily attributable to the following:

[0001730168-21-000116:mdna:74]
•Cash and cash equivalents increased to $9,518 million at May 2, 2021 from $7,618 million at November 1, 2020, primarily due to $9,904 million in proceeds from long-term borrowings and $6,682 million in net cash provided by operating activities. These increases were partially offset by $10,733 million of debt payments and $3,095 million of dividend payments.

[0001730168-21-000116:mdna:75]
•Current portion of long-term debt decreased to $278 million at May 2, 2021 from $827 million at November 1, 2020 due to repayments of certain debt instruments.

[0001730168-21-000116:mdna:76]
•Other current assets increased to $1,298 million at May 2, 2021 from $977 million at November 1, 2020, primarily due to increases in prepaid taxes and short-term investments.

[0001730168-21-000116:mdna:77]
•Employee compensation and benefits decreased to $639 million at May 2, 2021 from $877 million at November 1, 2020, primarily due to the timing of employee bonus plan payments.

[0001730168-21-000116:mdna:78]
•Accounts receivable increased to $2,425 million at May 2, 2021 from $2,297 million at November 1, 2020, primarily due to revenue linearity.

[0001730168-21-000116:mdna:79]
[same as prior period, unchanged from 0001730168-21-000045:mdna:70]

[0001730168-21-000116:mdna:80]
•Other current liabilities increased to $4,689 million at May 2, 2021 from $3,831 million at November 1, 2020, primarily due to increases in contract liabilities and taxes payable.

[0001730168-21-000116:mdna:81]
Working capital increased to $7,621 million at May 3, 2020 from $3,018 million at November 3, 2019. The increase was attributable to the following:

[0001730168-21-000116:mdna:82]
•Cash and cash equivalents increased to $9,207 million at May 3, 2020 from $5,055 million at November 3, 2019, primarily due to $21,592 million in proceeds from borrowings and $5,535 million in net cash provided by operating activities. These increases were partially offset by our $10.7 billion acquisition of the Symantec Business (the “Symantec Asset Purchase”), $8,989 million of debt repayments, and $2,753 million of dividend payments.

[0001730168-21-000116:mdna:83]
•Other current assets increased to $851 million at May 3, 2020 from $729 million at November 3, 2019, primarily due to increases in prepaid taxes and other receivables.

[0001730168-21-000116:mdna:84]
[same as prior period, unchanged from 0001730168-21-000045:mdna:104]

[0001730168-21-000116:mdna:85]
•Employee compensation and benefits decreased to $494 million at May 3, 2020 from $641 million at November 3, 2019, primarily due to the timing of employee bonus plan payments.

[0001730168-21-000116:mdna:86]
•Current portion of long-term debt decreased to $819 million at May 3, 2020 from $2,787 million at November 3, 2019 due to repayment of certain debt instruments, partially offset by certain debt instruments becoming due within the next twelve months.

[0001730168-21-000116:mdna:87]
[same as prior period, unchanged from 0001730168-21-000045:mdna:78]

[0001730168-21-000116:mdna:88]
•Accounts payable increased to $1,230 million at May 3, 2020 from $855 million at November 3, 2019, primarily due to the timing of vendor payments.

[0001730168-21-000116:mdna:89]
•Other current liabilities increased to $4,058 million at May 3, 2020 from $2,616 million at November 3, 2019, primarily due to the Symantec Asset Purchase, increases in contract liabilities, increases in lease liabilities resulting from the adoption of the new lease standard, and higher taxes payable, partially offset by repayments of notional pooling liabilities.

[0001730168-21-000116:mdna:90]
[same as prior period, unchanged from 0001730168-21-000045:mdna:81]

[0001730168-21-000116:mdna:91]
|  |  | Two Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 7.20 |  |  | $ | 6.50 |  |
| Dividends to common stockholders |  | $ | 2,945 |  |  | $ | 2,603 |  |
| Dividends per share to preferred stockholders |  | $ | 40.00 |  |  | $ | 40.00 |  |
| Dividends to preferred stockholders |  | $ | 150 |  |  | $ | 150 |  |

[0001730168-21-000116:mdna:92]
During the two fiscal quarters ended May 2, 2021 and May 3, 2020, we paid approximately $686 million and $388 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the two fiscal quarters ended May 2, 2021 and May 3, 2020.

[0001730168-21-000116:mdna:93]
[same as prior period, unchanged from 0001730168-21-000045:mdna:84]

[0001730168-21-000116:mdna:94]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 2,2021 |  | May 3,2020 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 6,682 |  |  | $ | 5,535 |  |
| Net cash used in investing activities |  | (248) |  |  | (10,963) |  |
| Net cash provided by (used in) financing activities |  | (4,534) |  |  | 9,580 |  |
| Net change in cash and cash equivalents |  | $ | 1,900 |  |  | $ | 4,152 |  |

[0001730168-21-000116:mdna:95]
[same as prior period, unchanged from 0001730168-21-000045:mdna:86]

[0001730168-21-000116:mdna:96]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,147 million increase in cash provided by operations during the two fiscal quarters ended May 2, 2021 compared to the prior year fiscal period was due to higher net income adjusted for non-cash items.

[0001730168-21-000116:mdna:97]
[same as prior period, unchanged from 0001730168-21-000045:mdna:88]

[0001730168-21-000116:mdna:98]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures. The $10,715 million decrease in cash used in investing activities during the two fiscal quarters ended May 2, 2021 compared to the prior year fiscal period was primarily related to a $10,862 million decrease in cash paid for acquisitions.

[0001730168-21-000116:mdna:99]
[same as prior period, unchanged from 0001730168-21-000045:mdna:90]

[0001730168-21-000116:mdna:100]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, dividend payments and employee withholding tax payments related to net settled equity awards. The $14,114 million change in cash related to financing activities during the two fiscal quarters ended May 2, 2021 compared to the prior year fiscal period was primarily due to a $13,432 million change in net borrowing activities, a $342 million increase in dividend payments and a $298 million increase in employee withholding tax payments related to net settled equity awards.

[0001730168-21-000116:mdna:101]
[same as prior period, unchanged from 0001730168-21-000045:mdna:92]

[0001730168-21-000116:mdna:102]
[same as prior period, unchanged from 0001730168-21-000045:mdna:93]

[0001730168-21-000116:mdna:103]
[same as prior period, unchanged from 0001730168-21-000045:mdna:94]

[0001730168-21-000116:mdna:104]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), Broadcom Cayman Finance Limited (subsequently merged into Broadcom Technologies Inc. (“BTI”) during fiscal year 2019 with BTI remaining as the surviving entity) and Broadcom Corporation (“BRCM” and with BTI, collectively, the “2017 Senior Notes Co-Issuers”) issued $13,550 million and $4,000 million aggregate principal amount of notes, respectively (collectively, the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-21-000116:mdna:105]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom, BRCM and BTI (collectively, the “Obligor Group”) to merge, consolidate or sell all or substantially all of their assets.

[0001730168-21-000116:mdna:106]
[same as prior period, unchanged from 0001730168-21-000045:mdna:101]

[0001730168-21-000116:mdna:107]
In March 2021, we completed the settlement of our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034. In connection with the Exchange Offer, BRCM and BTI were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes.

[0001730168-21-000116:mdna:108]
[same as prior period, unchanged from 0001730168-21-000045:mdna:102]

[0001730168-21-000116:mdna:109]
| Summarized Balance Sheet Information |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 1,948 |  |  | $ | 1,889 |  |
| Other current assets |  | 6,178 |  |  | 4,091 |  |
| Total current assets |  | $ | 8,126 |  |  | $ | 5,980 |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 8,220 |  |  | $ | 8,220 |  |
| Goodwill |  | 1,360 |  |  | 1,360 |  |
| Other long-term assets |  | 1,295 |  |  | 1,318 |  |
| Total long-term assets |  | $ | 10,875 |  |  | $ | 10,898 |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 8,093 |  |  | $ | 7,147 |  |
| Current portion of long-term debt |  | 255 |  |  | 807 |  |
| Other current liabilities |  | 667 |  |  | 601 |  |
| Total current liabilities |  | $ | 9,015 |  |  | $ | 8,555 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | $ | 39,635 |  |  | $ | 39,311 |  |
| Other long-term liabilities |  | 2,273 |  |  | 2,477 |  |
| Total long-term liabilities |  | $ | 41,908 |  |  | $ | 41,788 |  |

[0001730168-21-000116:mdna:110]
|  |  | Two Fiscal Quarters Ended |
| Summarized Statement of Operations Information |  | May 2,2021 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 855 |  |
| Intercompany gross margin |  | $ | 774 |  |
| Net loss (a) |  | $ | (666) |  |

[0001730168-21-000116:mdna:111]
[same as prior period, unchanged from 0001730168-21-000045:mdna:106]

[0001730168-21-000116:mdna:112]
(a) In addition to intercompany gross margin, there were $519 million of intercompany transactions included in net loss.

[0001730168-21-000116:mdna:113]
[same as prior period, unchanged from 0001730168-21-000045:mdna:108]

[0001730168-21-000116:mdna:114]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000116:mdna:115]
[same as prior period, unchanged from 0001730168-21-000045:mdna:110]

[0001730168-21-000116:mdna:116]
We had no material off-balance sheet arrangements at May 2, 2021 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-21-000116:mdna:117]
[same as prior period, unchanged from 0001730168-21-000045:mdna:112]

[0001730168-21-000116:mdna:118]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000116:mdna:119]
[same as prior period, unchanged from 0001730168-21-000045:mdna:114]

[0001730168-21-000116:mdna:120]
[same as prior period, unchanged from 0001730168-21-000045:mdna:115]
