# AVGO MD&A — 0001730168-25-000021


## mdna

[0001730168-25-000021:mdna:1]
[same as prior period, unchanged from 0001730168-24-000099:mdna:1]

[0001730168-25-000021:mdna:2]
Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom Inc. and its consolidated subsidiaries.

[0001730168-25-000021:mdna:3]
21

[0001730168-25-000021:mdna:4]
[same as prior period, unchanged from 0001730168-24-000099:mdna:2]

[0001730168-25-000021:mdna:5]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-25-000021:mdna:6]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our private and hybrid cloud, application development and delivery, software-defined edge, application networking and security, mainframe, distributed and cybersecurity solutions, and our FC SAN business.

[0001730168-25-000021:mdna:7]
Our fiscal year ending November 2, 2025 (“fiscal year 2025”), is a 52-week fiscal year, with our first fiscal quarter ended February 2, 2025 containing 13 weeks compared to 14 weeks in the prior year fiscal period. The additional week resulted in higher net revenue, gross margin dollars, research and development expense, and selling, general and administrative expense in the first fiscal quarter of fiscal year 2024, compared to the corresponding current year fiscal period.

[0001730168-25-000021:mdna:8]
We acquired VMware, Inc. (“VMware”) on November 22, 2023, resulting in a partial quarter of operations from activities related to VMware in the first quarter of fiscal year 2024 compared to a full quarter of operations in the first quarter of fiscal year 2025.

[0001730168-25-000021:mdna:9]
[same as prior period, unchanged from 0001730168-24-000099:mdna:6]

[0001730168-25-000021:mdna:10]
Highlights during the fiscal quarter ended February 2, 2025 include the following:

[0001730168-25-000021:mdna:11]
•We generated $6,113 million of cash from operations.

[0001730168-25-000021:mdna:12]
•We paid $2,774 million in cash dividends.

[0001730168-25-000021:mdna:13]
•We issued $4.0 billion of commercial paper and $3.0 billion of senior unsecured notes and used the net proceeds, as well as cash on hand, to repay $7,595 million of our unsecured term loans.

[0001730168-25-000021:mdna:14]
[same as prior period, unchanged from 0001730168-24-000099:mdna:19]

[0001730168-25-000021:mdna:15]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of goodwill and long-lived assets, and income taxes.

[0001730168-25-000021:mdna:16]
There were no significant changes in our critical accounting estimates during the fiscal quarter ended February 2, 2025 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2024 Annual Report on Form 10-K.

[0001730168-25-000021:mdna:17]
Macroeconomic Factors

[0001730168-25-000021:mdna:18]
We are subject to risks and exposures from the evolving macroeconomic environment, including uncertainty and volatility in financial markets, efforts of governments to stimulate or stabilize the economy and other unfavorable changes in economic conditions, as well as an increase in trade tensions and related tariffs with U.S. trading partners. While difficult to isolate and quantify, these risks may cause our net revenue to fluctuate significantly and we continuously monitor the broader impacts of these circumstances on our business, our supply chain and our results of operations.

[0001730168-25-000021:mdna:19]
[same as prior period, unchanged from 0001730168-24-000099:mdna:22]

[0001730168-25-000021:mdna:20]
Fiscal Quarter Ended February 2, 2025 Compared to Fiscal Quarter Ended February 4, 2024

[0001730168-25-000021:mdna:21]
[same as prior period, unchanged from 0001730168-24-000099:mdna:24]

[0001730168-25-000021:mdna:22]
|  |  | Fiscal Quarter Ended |
|  |  | February 2,2025 |  | February 4,2024 |  | February 2,2025 |  | February 4,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 8,171 |  |  | $ | 7,412 |  |  | 55 | % |  | 62 | % |
| Subscriptions and services |  | 6,745 |  |  | 4,549 |  |  | 45 |  |  | 38 |  |
| Total net revenue |  | 14,916 |  |  | 11,961 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,693 |  |  | 2,160 |  |  | 18 |  |  | 18 |  |
| Cost of subscriptions and services |  | 580 |  |  | 954 |  |  | 4 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 1,484 |  |  | 1,380 |  |  | 10 |  |  | 11 |  |
| Restructuring charges |  | 14 |  |  | 92 |  |  | — |  |  | 1 |  |
| Total cost of revenue |  | 4,771 |  |  | 4,586 |  |  | 32 |  |  | 38 |  |
| Gross margin |  | 10,145 |  |  | 7,375 |  |  | 68 |  |  | 62 |  |
| Research and development |  | 2,253 |  |  | 2,308 |  |  | 15 |  |  | 19 |  |
| Selling, general and administrative |  | 949 |  |  | 1,572 |  |  | 7 |  |  | 13 |  |
| Amortization of acquisition-related intangible assets |  | 511 |  |  | 792 |  |  | 3 |  |  | 7 |  |
| Restructuring and other charges |  | 172 |  |  | 620 |  |  | 1 |  |  | 5 |  |
| Total operating expenses |  | 3,885 |  |  | 5,292 |  |  | 26 |  |  | 44 |  |
| Operating income |  | $ | 6,260 |  |  | $ | 2,083 |  |  | 42 | % |  | 18 | % |

[0001730168-25-000021:mdna:23]
[same as prior period, unchanged from 0001730168-24-000099:mdna:28]

[0001730168-25-000021:mdna:24]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one customer, which is a distributor, accounted for 29% and 27% of our net revenue for the fiscal quarters ended February 2, 2025, and February 4, 2024, respectively.

[0001730168-25-000021:mdna:25]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% of our net revenue for each of the fiscal quarters ended February 2, 2025 and February 4, 2024. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-25-000021:mdna:26]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our products used in AI and wireless applications as fluctuations may be magnified by the timing of customer deployments, as well as product launches and seasonal variations for wireless applications. For infrastructure software, the transition to subscription licenses, as well as whether or not a customer has the right to terminate, could cause variations in revenue recognized in each period.

[0001730168-25-000021:mdna:27]
[same as prior period, unchanged from 0001730168-24-000099:mdna:32]

[0001730168-25-000021:mdna:28]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Net Revenue by Segment |  | February 2, 2025 |  | February 4, 2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 8,212 |  |  | $ | 7,390 |  |  | $ | 822 |  |  | 11 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 6,704 |  |  | 4,571 |  |  | 2,133 |  |  | 47 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 14,916 |  |  | $ | 11,961 |  |  | $ | 2,955 |  |  | 25 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000021:mdna:29]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | February 2,2025 |  | February 4,2024 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 55 | % |  | 62 | % |  |  |  |  |
| Infrastructure software |  | 45 |  |  | 38 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-25-000021:mdna:30]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period due to strong demand for our networking products, primarily AI networking solutions, partially offset by lower demand for our non-AI solutions, primarily broadband products. Net revenue from our infrastructure software segment increased in the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period primarily due to strong demand for our VMware Cloud Foundation (“VCF”) product, additional license revenue recognized on contracts where customers do not have the right to terminate, and the transition to a subscription license model.

[0001730168-25-000021:mdna:31]
[same as prior period, unchanged from 0001730168-24-000099:mdna:36]

[0001730168-25-000021:mdna:32]
Gross margin was $10,145 million for the fiscal quarter ended February 2, 2025 compared to $7,375 million for the fiscal quarter ended February 4, 2024. The increase was primarily due to higher software revenue and strong product demand for our AI semiconductor solutions.

[0001730168-25-000021:mdna:33]
As a percentage of net revenue, gross margin was 68% and 62% of net revenue for the fiscal quarters ended February 2, 2025 and February 4, 2024, respectively. The increase was primarily due to higher software revenue and lower amortization of acquisition-related intangible assets as a percentage of revenue.

[0001730168-25-000021:mdna:34]
[same as prior period, unchanged from 0001730168-24-000099:mdna:39]

[0001730168-25-000021:mdna:35]
Research and development expense decreased $55 million, or 2% for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period. The decrease was primarily due to lower compensation resulting from a decrease in headcount and lower stock-based compensation.

[0001730168-25-000021:mdna:36]
[same as prior period, unchanged from 0001730168-24-000099:mdna:42]

[0001730168-25-000021:mdna:37]
Selling, general and administrative expense decreased $623 million, or 40% for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period. The decrease was primarily due to lower compensation resulting from a decrease in headcount and lower stock-based compensation. In addition, in the prior year fiscal period, we incurred higher VMware acquisition-related costs.

[0001730168-25-000021:mdna:38]
[same as prior period, unchanged from 0001730168-24-000099:mdna:44]

[0001730168-25-000021:mdna:39]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $281 million, or 35% for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period primarily due to full amortization of customer-related intangible assets from previous software acquisitions other than VMware.

[0001730168-25-000021:mdna:40]
[same as prior period, unchanged from 0001730168-24-000099:mdna:46]

[0001730168-25-000021:mdna:41]
Restructuring and other charges recognized in operating expenses decreased $448 million, or 72% for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period primarily due to lower employee termination costs associated with the integration of the VMware business.

[0001730168-25-000021:mdna:42]
[same as prior period, unchanged from 0001730168-24-000099:mdna:48]

[0001730168-25-000021:mdna:43]
Total stock-based compensation expense was $1,280 million and $1,572 million for the fiscal quarters ended February 2, 2025, and February 4, 2024, respectively. The decrease was primarily due to the full vesting and forfeitures of certain equity awards assumed in the VMware acquisition, partially offset by December 2023 VMware inducement grants and March 2024 annual employee equity grants at higher grant-date fair values.

[0001730168-25-000021:mdna:44]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of February 2, 2025. The remaining weighted-average service period was 2.9 years.

[0001730168-25-000021:mdna:45]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 3,324 |  |
| 2026 |  | 3,778 |  |
| 2027 |  | 2,826 |  |
| 2028 |  | 796 |  |
| 2029 |  | 21 |  |
| Total |  | $ | 10,745 |  |

[0001730168-25-000021:mdna:46]
[same as prior period, unchanged from 0001730168-24-000099:mdna:52]

[0001730168-25-000021:mdna:47]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Operating Income by Segment |  | February 2,2025 |  | February 4,2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,706 |  |  | $ | 4,116 |  |  | $ | 590 |  |  | 14 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 5,122 |  |  | 2,715 |  |  | 2,407 |  |  | 89 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (3,568) |  |  | (4,748) |  |  | 1,180 |  |  | (25) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 6,260 |  |  | $ | 2,083 |  |  | $ | 4,177 |  |  | 201 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000021:mdna:48]
Operating income from our semiconductor solutions segment increased for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period due to strong demand for our networking products, primarily AI networking solutions, partially offset by lower demand for our non-AI solutions, primarily broadband products. Higher operating income from our infrastructure software segment in the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period was primarily due to strong demand for our VCF product, additional license revenue recognized on contracts where customers do not have the right to terminate, and the transition to a subscription license model.

[0001730168-25-000021:mdna:49]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 25% for the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period due to lower restructuring and other charges, stock-based compensation expense, acquisition-related costs, and amortization of acquisition-related intangible assets.

[0001730168-25-000021:mdna:50]
[same as prior period, unchanged from 0001730168-24-000099:mdna:57]

[0001730168-25-000021:mdna:51]
Interest expense. Interest expense was $873 million and $926 million for the fiscal quarters ended February 2, 2025, and February 4, 2024, respectively. The decrease was primarily from an overall reduction in outstanding debt balances and debt refinancing activities that drove lower effective interest rates since the fiscal quarter ended February 4, 2024.

[0001730168-25-000021:mdna:52]
Other income, net. Other income, net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $103 million and $185 million for the fiscal quarters ended February 2, 2025 and February 4, 2024, respectively. The decrease was primarily due to lower interest income as a result of a lower invested balance.

[0001730168-25-000021:mdna:53]
25

[0001730168-25-000021:mdna:54]
Provision for (benefit from) income taxes. The benefit from income taxes was $13 million for the fiscal quarter ended February 2, 2025 and was primarily due to excess tax benefits from stock-based awards partially offset by income before income taxes and a shift in the jurisdictional mix of revenue and expenses. The provision for income taxes was $68 million for the fiscal quarter ended February 4, 2024 and was primarily due to income before income taxes partially offset by excess tax benefits from stock-based awards and a valuation allowance release.

[0001730168-25-000021:mdna:55]
[same as prior period, unchanged from 0001730168-24-000099:mdna:61]

[0001730168-25-000021:mdna:56]
[same as prior period, unchanged from 0001730168-24-000099:mdna:62]

[0001730168-25-000021:mdna:57]
Our primary sources of liquidity as of February 2, 2025 consisted of: (i) $9,307 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-25-000021:mdna:58]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $68,757 million of outstanding indebtedness with $5,650 million principal amounts payable within 12 months and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-25-000021:mdna:59]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-25-000021:mdna:60]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our outstanding indebtedness and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-25-000021:mdna:61]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. We may also make additional prepayments of our outstanding term loans. The amounts involved may be material.

[0001730168-25-000021:mdna:62]
[same as prior period, unchanged from 0001730168-24-000099:mdna:69]

[0001730168-25-000021:mdna:63]
Working capital decreased to $80 million at February 2, 2025 from $2,898 million at November 3, 2024. The decrease was primarily attributable to the following:

[0001730168-25-000021:mdna:64]
•Short-term debt increased to $5,653 million at February 2, 2025 from $1,271 million at November 3, 2024 primarily due to the issuance of $4,000 million of commercial paper and $900 million of senior notes becoming due within the next twelve months, offset in part by a $495 million repayment.

[0001730168-25-000021:mdna:65]
•Other current liabilities increased to $12,430 million at February 2, 2025 from $11,793 million at November 3, 2024 primarily from higher contract liabilities.

[0001730168-25-000021:mdna:66]
•Accounts payable increased to $1,905 million at February 2, 2025 from $1,662 million at November 3, 2024 primarily due to the timing of payments.

[0001730168-25-000021:mdna:67]
These decreases in working capital were offset in part by the following:

[0001730168-25-000021:mdna:68]
•Employee compensation and benefits decreased to $922 million at February 2, 2025 from $1,971 million at November 3, 2024 primarily due to annual employee bonus plan payments.

[0001730168-25-000021:mdna:69]
26

[0001730168-25-000021:mdna:70]
•Other current assets increased to $4,820 million at February 2, 2025 from $4,071 million at November 3, 2024 primarily from higher software contract assets, offset in part by lower prepaid taxes.

[0001730168-25-000021:mdna:71]
•Trade accounts receivable, net increased to $4,955 million at February 2, 2025 from $4,416 million at November 3, 2024 primarily due to higher software billings.

[0001730168-25-000021:mdna:72]
•Inventory increased to $1,908 million at February 2, 2025 from $1,760 million at November 3, 2024 primarily to support higher expected shipments.

[0001730168-25-000021:mdna:73]
[same as prior period, unchanged from 0001730168-24-000099:mdna:78]

[0001730168-25-000021:mdna:74]
|  |  | Fiscal Quarter Ended |
| Cash Dividends Declared and Paid |  | February 2,2025 |  | February 4,2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.590 |  |  | $ | 0.525 |  |
| Dividends to common stockholders |  | $ | 2,774 |  |  | $ | 2,435 |  |

[0001730168-25-000021:mdna:75]
During the fiscal quarters ended February 2, 2025 and February 4, 2024, we paid approximately $2,036 million and $1,114 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 8 million and 10 million shares of common stock from employees in connection with such net share settlements during the fiscal quarters ended February 2, 2025 and February 4, 2024, respectively.

[0001730168-25-000021:mdna:76]
[same as prior period, unchanged from 0001730168-24-000099:mdna:82]

[0001730168-25-000021:mdna:77]
|  |  | Fiscal Quarter Ended |
|  |  | February 2,2025 |  | February 4,2024 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 6,113 |  |  | $ | 4,815 |  |
| Net cash used in investing activities |  | (174) |  |  | (25,477) |  |
| Net cash provided by (used in) financing activities |  | (5,980) |  |  | 18,337 |  |
| Net change in cash and cash equivalents |  | $ | (41) |  |  | $ | (2,325) |  |

[0001730168-25-000021:mdna:78]
[same as prior period, unchanged from 0001730168-24-000099:mdna:84]

[0001730168-25-000021:mdna:79]
Cash flows from operating activities consist of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,298 million increase in cash provided by operations during the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period was primarily due to $4,178 million higher net income, offset in part by $2,068 million from changes in operating assets and liabilities. The lower net income in the prior year fiscal period was partially driven by higher non-cash adjustments including deferred taxes and other non-cash taxes, stock-based compensation, and amortization of intangible assets.

[0001730168-25-000021:mdna:80]
[same as prior period, unchanged from 0001730168-24-000099:mdna:86]

[0001730168-25-000021:mdna:81]
Cash flows from investing activities primarily consist of cash related to acquisitions and divestitures, capital expenditures and proceeds and payments related to investments. The $25,303 million decrease in cash used in investing activities during the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period was primarily due to $25,416 million cash paid in connection with the acquisition of VMware, net of cash acquired, in the prior year fiscal period.

[0001730168-25-000021:mdna:82]
[same as prior period, unchanged from 0001730168-24-000099:mdna:88]

[0001730168-25-000021:mdna:83]
Cash flows from financing activities primarily consist of proceeds and payments related to our borrowings, dividend payments, employee withholding tax payments related to net settled equity awards and authorized stock repurchases. The $24,317 million decrease in cash flows from financing activities during the fiscal quarter ended February 2, 2025 compared to the prior year fiscal period was primarily due to a $23,044 million decrease in net proceeds from borrowings, a $7,156 million increase in payments on debt obligations, a $922 million increase in employee withholding tax payments related to net settled equity awards, and a $339 million increase in dividend payments, offset in part by $7,176 million in stock repurchases in the prior year fiscal period.
