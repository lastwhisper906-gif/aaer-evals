# AVGO note change history — 0001730168-24-000099 → 0001730168-25-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0001730168-25-000021:note_history:1]
The following table summarizes contractual obligations and commitments as of February 2, 2025:
  (was, 2024-09-11, similarity 0.9326):
[0001730168-24-000099:note_history:1]
The following table summarizes contractual obligations and commitments as of August 4, 2024:

- changed (2025-03-12):
[0001730168-25-000021:note_history:2]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.
  (was, 2024-09-11, similarity 0.9248):
[0001730168-24-000099:note_history:2]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to information technology and other service agreements.

- changed (2025-03-12):
[0001730168-25-000021:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 2, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,621 million of unrecognized tax benefits and accrued interest and penalties as of February 2, 2025 have been excluded from the table above.
  (was, 2024-09-11, similarity 0.8914):
[0001730168-24-000099:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 4, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest and penalties as of August 4, 2024 have been excluded from the table above.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-03-12):
[0001730168-25-000021:note_history:4]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- changed (2025-03-12):
[0001730168-25-000021:note_history:5]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year ending November 2, 2025 (“fiscal year 2025”) is a 52-week fiscal year. Our fiscal year ended November 3, 2024 (“fiscal year 2024”) was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.
  (was, 2024-09-11, similarity 0.6584):
[0001730168-24-000099:note_history:5]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2024 (“fiscal year 2024”) is a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. Our fiscal year ended October 29, 2023 (“fiscal year 2023”) was a 52-week fiscal year.

- changed (2025-03-12):
[0001730168-25-000021:note_history:6]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 2, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.
  (was, 2024-09-11, similarity 0.895):
[0001730168-24-000099:note_history:6]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 4, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.

- changed (2025-03-12):
[0001730168-25-000021:note_history:7]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.
  (was, 2024-09-11, similarity 0.9982):
[0001730168-24-000099:note_history:7]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from those estimates, and such differences could affect the results of operations reported in future periods.

- removed (2025-03-12):
[0001730168-24-000099:note_history:8]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- removed (2025-03-12):
[0001730168-24-000099:note_history:9]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-03-12):
[0001730168-25-000021:note_history:10]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | $ | 1,100 |  |  | $ | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.70 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:11]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 64,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.62 | % | (b) | 4,000 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 68,757 |  |  | $ | 69,847 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:12]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,992 |  |  | — |  |
| Short-term finance lease liabilities |  | 11 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,653 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,107 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 11 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,192) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 60,926 |  |  | $ | 66,295 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:13]
______________________________

- added (2025-03-12):
[0001730168-25-000021:note_history:14]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

- added (2025-03-12):
[0001730168-25-000021:note_history:15]
(b) Represents the weighted average interest rate on commercial paper outstanding as of February 2, 2025.

- changed (2025-03-12):
[0001730168-25-000021:note_history:16]
Senior Notes
  (was, 2024-09-11, similarity 0.7742):
[0001730168-24-000099:note_history:16]
July 2024 Senior Notes

- added (2025-03-12):
[0001730168-25-000021:note_history:17]
In January 2025, we issued senior unsecured notes for an aggregate principal amount of $3,000 million. Using the net proceeds from the senior notes and commercial paper issued in January 2025, as well as cash on hand, we repaid the remaining $5,595 million of our unsecured term A-3 facility and $2,000 million of our unsecured term A-5 facility. As a result of these repayments, we wrote off unamortized discount and issuance costs of $65 million, which were included in interest expense in the condensed consolidated statement of operations.

- added (2025-03-12):
[0001730168-25-000021:note_history:18]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

- added (2025-03-12):
[0001730168-25-000021:note_history:19]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either February 2, 2025 or November 3, 2024.

- changed (2025-03-12):
[0001730168-25-000021:note_history:20]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of February 2, 2025, we had $4.0 billion of commercial paper outstanding with maturities generally less than sixty days.
  (was, 2024-09-11, similarity 0.7303):
[0001730168-24-000099:note_history:20]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either August 4, 2024 or October 29, 2023.

- added (2025-03-12):
[0001730168-25-000021:note_history:21]
As of February 2, 2025, the estimated aggregate fair value of our senior notes was $53,926 million, which was determined using quoted prices from less active markets. The carrying value of the unsecured term loans approximates their fair value as the unsecured term loans are carried at a market observable interest rate tied to the Secured Overnight Financing Rate (“SOFR”) that resets periodically. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

- changed (2025-03-12):
[0001730168-25-000021:note_history:22]
The future scheduled principal payments of senior notes and term loans as of February 2, 2025 were as follows:
  (was, 2024-09-11, similarity 0.7914):
[0001730168-24-000099:note_history:22]
The future scheduled principal payments of debt as of August 4, 2024 were as follows:

- changed (2025-03-12):
[0001730168-25-000021:note_history:23]
As of February 2, 2025 and November 3, 2024, we were in compliance with all debt covenants.
  (was, 2024-09-11, similarity 0.882):
[0001730168-24-000099:note_history:23]
As of August 4, 2024 and October 29, 2023, we were in compliance with all debt covenants.

- removed (2025-03-12):
[0001730168-24-000099:note_history:24]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | $ | 1,250 |  |  | $ | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.03 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.23 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 19,195 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:25]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 72,319 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,117 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 44 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 3,161 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 69,202 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 17 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,421) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,798 |  |  | $ | 37,621 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:26]
In July 2024, we issued $1,250 million of 5.050% senior unsecured notes due July 2027, $2,250 million of 5.050% senior unsecured notes due July 2029 and $1,500 million of 5.150% senior unsecured notes due November 2031 (collectively, the “July 2024 Senior Notes”).

- removed (2025-03-12):
[0001730168-24-000099:note_history:27]
We may redeem or purchase, in whole or in part, the July 2024 Senior Notes prior to their maturities, subject to a specified make-whole premium as set forth in the indenture. In the event of a change of control, note holders will have the right to require us to repurchase all or any part of the holders’ notes at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the July 2024 Senior Notes pays interest semi-annually.

- removed (2025-03-12):
[0001730168-24-000099:note_history:28]
2023 Term Loans

- removed (2025-03-12):
[0001730168-24-000099:note_history:29]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered an $11,195 million unsecured term A-2 facility (the "Term A-2 Loan”), an $11,195 million unsecured term A-3 facility (the “Term A-3 Loan”), and an $8,000 million unsecured term A-5 facility (the “Term A-5 Loan”, collectively, the “2023 Term Loans”).

- removed (2025-03-12):
[0001730168-24-000099:note_history:30]
During the fiscal quarter ended May 5, 2024, we repaid $2,000 million of our Term A-2 Loan. During the fiscal quarter ended August 4, 2024, using the net proceeds from the July 2024 Senior Notes and the sale of the EUC business, as well as cash on hand, we repaid the remaining $9,195 million of our Term A-2 Loan. As a result, we wrote off unamortized discount and issuance costs of $83 million and $105 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, which were included in interest expense in the condensed consolidated statements of operations.

- removed (2025-03-12):
[0001730168-24-000099:note_history:31]
The 2023 Term Loans bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The Term A-3 Loan and Term A-5 Loan will mature and be payable on the third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

- removed (2025-03-12):
[0001730168-24-000099:note_history:32]
Assumed VMware Senior Notes

- removed (2025-03-12):
[0001730168-24-000099:note_history:33]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, note holders will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.

- removed (2025-03-12):
[0001730168-24-000099:note_history:34]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either August 4, 2024 or October 29, 2023.

- removed (2025-03-12):
[0001730168-24-000099:note_history:35]
As of August 4, 2024, the estimated aggregate fair value of debt was $68,417 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-03-12):
[0001730168-25-000021:note_history:36]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | $ | 1,100 |  |  | $ | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.70 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:37]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 64,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.62 | % | (b) | 4,000 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 68,757 |  |  | $ | 69,847 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:38]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,992 |  |  | — |  |
| Short-term finance lease liabilities |  | 11 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,653 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,107 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 11 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,192) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 60,926 |  |  | $ | 66,295 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:39]
______________________________

- added (2025-03-12):
[0001730168-25-000021:note_history:40]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

- added (2025-03-12):
[0001730168-25-000021:note_history:41]
(b) Represents the weighted average interest rate on commercial paper outstanding as of February 2, 2025.

- removed (2025-03-12):
[0001730168-24-000099:note_history:42]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | $ | 1,250 |  |  | $ | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.03 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.23 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 19,195 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:43]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 72,319 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,117 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 44 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 3,161 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 69,202 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 17 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,421) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,798 |  |  | $ | 37,621 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0001730168-25-000021:note_history:44]
The future scheduled principal payments of senior notes and term loans as of February 2, 2025 were as follows:
  (was, 2024-09-11, similarity 0.7914):
[0001730168-24-000099:note_history:44]
The future scheduled principal payments of debt as of August 4, 2024 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-03-12):
[0001730168-25-000021:note_history:45]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 7,269 |  |  | $ | 412 |  |  | $ | 8,171 |  |
| Subscriptions and services |  | 4,142 |  |  | 763 |  |  | 1,840 |  |  | 6,745 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:46]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:47]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:48]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:49]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:50]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-03-12):
[0001730168-25-000021:note_history:51]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 7,269 |  |  | $ | 412 |  |  | $ | 8,171 |  |
| Subscriptions and services |  | 4,142 |  |  | 763 |  |  | 1,840 |  |  | 6,745 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

- added (2025-03-12):
[0001730168-25-000021:note_history:52]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

- changed (2025-03-12):
[0001730168-25-000021:note_history:53]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.
  (was, 2024-09-11, similarity 0.9944):
[0001730168-24-000099:note_history:53]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.

- changed (2025-03-12):
[0001730168-25-000021:note_history:54]
|  |  | February 2,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 5,548 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,536 |  |  | $ | 14,495 |  |
  (was, 2024-09-11, similarity 0.9343):
[0001730168-24-000099:note_history:54]
|  |  | August 4,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 3,658 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 15,548 |  |  | $ | 2,786 |  |

- changed (2025-03-12):
[0001730168-25-000021:note_history:55]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of February 2, 2025, approximately 59% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 2, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $3,583 million. The amount of revenue recognized during the fiscal quarter ended February 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,313 million.
  (was, 2024-09-11, similarity 0.8035):
[0001730168-24-000099:note_history:55]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of August 4, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of August 4, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million. The amount of revenue recognized during the three fiscal quarters ended July 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,677 million.

- changed (2025-03-12):
[0001730168-25-000021:note_history:56]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract
  (was, 2024-09-11, similarity 0.6837):
[0001730168-24-000099:note_history:56]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- added (2025-03-12):
[0001730168-25-000021:note_history:57]
permits termination for convenience. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- changed (2025-03-12):
[0001730168-25-000021:note_history:58]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of February 2, 2025 were approximately $22.4 billion. We expect approximately 40% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2024-09-11, similarity 0.8505):
[0001730168-24-000099:note_history:58]
Certain multi-year customer contracts in our semiconductor solutions and infrastructure software segments contain firmly committed amounts and the remaining performance obligations under these contracts as of August 4, 2024 were approximately $21.2 billion. We expect approximately 44% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2025-03-12):
[0001730168-24-000099:note_history:59]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:60]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:61]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |

- removed (2025-03-12):
[0001730168-24-000099:note_history:62]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0001730168-25-000021:note_history:63]
On March 5, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on March 31, 2025 to stockholders of record on March 20, 2025.
  (was, 2024-09-11, similarity 0.9133):
[0001730168-24-000099:note_history:63]
On September 4, 2024, our Board of Directors declared a quarterly cash dividend of $0.53 per share on our common stock, payable on September 30, 2024 to stockholders of record on September 19, 2024.
