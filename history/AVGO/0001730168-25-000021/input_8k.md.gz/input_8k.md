# AVGO 8-K — 0001730168-25-000009 filed 2025-03-06

## item codes, every 8-K on or before 2025-03-12

- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2025-03-12

- none on or before 2025-03-12

## item 2.02 — earnings release, exhibit 99.1

[0001730168-25-000009:8k_2_02:1]
EX-99.1
2
avgo-02022025x8kxex99.htm
EX-99.1

[0001730168-25-000009:8k_2_02:2]
Document

[0001730168-25-000009:8k_2_02:3]
Exhibit 99.1

[0001730168-25-000009:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2025 Financial Results and Quarterly Dividend

[0001730168-25-000009:8k_2_02:5]
•Revenue of $14,916 million for the first quarter, up 25 percent from the prior year period

[0001730168-25-000009:8k_2_02:6]
•GAAP net income of $5,503 million for the first quarter; Non-GAAP net income of $7,823 million for the first quarter

[0001730168-25-000009:8k_2_02:7]
•Adjusted EBITDA of $10,083 million for the first quarter, or 68 percent of revenue

[0001730168-25-000009:8k_2_02:8]
•GAAP diluted EPS of $1.14 for the first quarter; Non-GAAP diluted EPS of $1.60 for the first quarter

[0001730168-25-000009:8k_2_02:9]
•Cash from operations of $6,113 million for the first quarter, less capital expenditures of $100 million, resulted in $6,013 million of free cash flow, or 40 percent of revenue

[0001730168-25-000009:8k_2_02:10]
•Quarterly common stock dividend of $0.59 per share

[0001730168-25-000009:8k_2_02:11]
•Second quarter fiscal year 2025 revenue guidance of approximately $14.9 billion, an increase of 19 percent from the prior year period

[0001730168-25-000009:8k_2_02:12]
•Second quarter fiscal year 2025 Adjusted EBITDA guidance of approximately 66 percent of projected revenue (1)

[0001730168-25-000009:8k_2_02:13]
PALO ALTO, Calif. – March 6, 2025 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2025, ended February 2, 2025, provided guidance for its second quarter of fiscal year 2025 and announced its quarterly dividend.

[0001730168-25-000009:8k_2_02:14]
“Broadcom’s record first quarter revenue and adjusted EBITDA were driven by both AI semiconductor solutions and infrastructure software. Q1 AI revenue grew 77% year-over-year to $4.1 billion and infrastructure software revenue grew 47% year-over-year to $6.7 billion,” said Hock Tan, President and CEO of Broadcom Inc. “We expect continued strength in AI semiconductor revenue of $4.4 billion in Q2, as hyperscale partners continue to invest in AI XPUs and connectivity solutions for AI data centers.”

[0001730168-25-000009:8k_2_02:15]
“Consolidated revenue grew 25% year-over-year to a record $14.9 billion. Adjusted EBITDA increased 41% year-over-year to a record $10.1 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow was $6.0 billion, up 28% year-over-year.”

[0001730168-25-000009:8k_2_02:16]
________________________________

[0001730168-25-000009:8k_2_02:17]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-25-000009:8k_2_02:18]
1

[0001730168-25-000009:8k_2_02:19]
First Quarter Fiscal Year 2025 Financial Highlights

[0001730168-25-000009:8k_2_02:20]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 25 |  | Q1 24 |  | Change |  | Q1 25 |  | Q1 24 |  | Change |
| Net revenue |  | $ | 14,916 |  |  | $ | 11,961 |  |  | +25 | % |  | $ | 14,916 |  |  | $ | 11,961 |  |  | +25 | % |
| Net income |  | $ | 5,503 |  |  | $ | 1,325 |  |  | +$4,178 |  |  | $ | 7,823 |  |  | $ | 5,254 |  |  | +$2,569 |  |
| Earnings per common share - diluted |  | $ | 1.14 |  |  | $ | 0.28 |  |  | +$0.86 |  |  | $ | 1.60 |  |  | $ | 1.10 |  |  | +$0.50 |  |

[0001730168-25-000009:8k_2_02:21]
| (Dollars in millions) |  | Q1 25 |  | Q1 24 |  | Change |  |
| Cash flow from operations |  | $ | 6,113 |  |  | $ | 4,815 |  |  | +$1,298 |  |
| Adjusted EBITDA |  | $ | 10,083 |  |  | $ | 7,156 |  |  | +$2,927 |  |
| Free cash flow |  | $ | 6,013 |  |  | $ | 4,693 |  |  | +$1,320 |  |

[0001730168-25-000009:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 25 |  |  |  | Q1 24 |  | Change |  |
| Semiconductor solutions |  | $ | 8,212 |  |  | 55 | % |  |  |  |  |  |  | $ | 7,390 |  |  | 62 | % |  | +11 | % |  |
| Infrastructure software |  | 6,704 |  |  | 45 |  |  |  |  |  |  |  | 4,571 |  |  | 38 |  |  | +47 | % |  |
| Total net revenue |  | $ | 14,916 |  |  | 100 | % |  |  |  |  |  |  | $ | 11,961 |  |  | 100 | % |  |  |  |  |

[0001730168-25-000009:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,307 million, compared to $9,348 million at the end of the prior fiscal quarter.

[0001730168-25-000009:8k_2_02:24]
During the first fiscal quarter, the Company generated $6,113 million in cash from operations and spent $100 million on capital expenditures. The Company paid $2,036 million of withholding taxes related to net settled equity awards that vested in the quarter (resulting in the elimination of 8.7 million shares).

[0001730168-25-000009:8k_2_02:25]
On December 31, 2024, the Company paid a cash dividend of $0.59 per share, totaling $2,774 million.

[0001730168-25-000009:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-25-000009:8k_2_02:27]
Second Quarter Fiscal Year 2025 Business Outlook

[0001730168-25-000009:8k_2_02:28]
Based on current business trends and conditions, the outlook for the second quarter of fiscal year 2025, ending May 4, 2025, is expected to be as follows:

[0001730168-25-000009:8k_2_02:29]
•Second quarter revenue guidance of approximately $14.9 billion; and

[0001730168-25-000009:8k_2_02:30]
•Second quarter Adjusted EBITDA guidance of approximately 66 percent of projected revenue.

[0001730168-25-000009:8k_2_02:31]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000009:8k_2_02:32]
Quarterly Dividends

[0001730168-25-000009:8k_2_02:33]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.59 per share. The dividend is payable on March 31, 2025 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 20, 2025.

[0001730168-25-000009:8k_2_02:34]
Financial Results Conference Call

[0001730168-25-000009:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the first quarter of fiscal year 2025 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-25-000009:8k_2_02:36]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-25-000009:8k_2_02:37]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-25-000009:8k_2_02:38]
Non-GAAP Financial Measures

[0001730168-25-000009:8k_2_02:39]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-25-000009:8k_2_02:40]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-25-000009:8k_2_02:41]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-25-000009:8k_2_02:42]
About Broadcom

[0001730168-25-000009:8k_2_02:43]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-25-000009:8k_2_02:44]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-25-000009:8k_2_02:45]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; our acquisition of VMware, Inc., including our ability to realize the expected benefits; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and other channel partners of our products; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of security systems; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; cyclicality in the semiconductor industry or in our target markets; our ability to make successful investments in research and development; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to improve our manufacturing capacity and quality; involvement in legal proceedings; ability of our software products to manage and secure IT infrastructures and environments; demand for our data center virtualization products and customer acceptance of our products, services and business strategy; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance;

[0001730168-25-000009:8k_2_02:46]
4

[0001730168-25-000009:8k_2_02:47]
our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-25-000009:8k_2_02:48]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000009:8k_2_02:49]
Contact:

[0001730168-25-000009:8k_2_02:50]
Ji Yoo

[0001730168-25-000009:8k_2_02:51]
Broadcom Inc.

[0001730168-25-000009:8k_2_02:52]
Investor Relations

[0001730168-25-000009:8k_2_02:53]
650-427-6000

[0001730168-25-000009:8k_2_02:54]
investor.relations@broadcom.com

[0001730168-25-000009:8k_2_02:55]
(AVGO-Q)

[0001730168-25-000009:8k_2_02:56]
5

[0001730168-25-000009:8k_2_02:57]
BROADCOM INC.

[0001730168-25-000009:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-25-000009:8k_2_02:59]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-25-000009:8k_2_02:60]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | November 3,2024 |  | February 4,2024 |  |  |  |  |
| Net revenue |  | $ | 14,916 |  |  | $ | 14,054 |  |  | $ | 11,961 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,273 |  |  | 3,399 |  |  | 3,114 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,484 |  |  | 1,602 |  |  | 1,380 |  |  |  |  |  |
| Restructuring charges |  | 14 |  |  | 51 |  |  | 92 |  |  |  |  |  |
| Total cost of revenue |  | 4,771 |  |  | 5,052 |  |  | 4,586 |  |  |  |  |  |
| Gross margin |  | 10,145 |  |  | 9,002 |  |  | 7,375 |  |  |  |  |  |
| Research and development |  | 2,253 |  |  | 2,234 |  |  | 2,308 |  |  |  |  |  |
| Selling, general and administrative |  | 949 |  |  | 1,010 |  |  | 1,572 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 511 |  |  | 813 |  |  | 792 |  |  |  |  |  |
| Restructuring and other charges |  | 172 |  |  | 318 |  |  | 620 |  |  |  |  |  |
| Total operating expenses |  | 3,885 |  |  | 4,375 |  |  | 5,292 |  |  |  |  |  |
| Operating income |  | 6,260 |  |  | 4,627 |  |  | 2,083 |  |  |  |  |  |
| Interest expense |  | (873) |  |  | (916) |  |  | (926) |  |  |  |  |  |
| Other income, net |  | 103 |  |  | 52 |  |  | 185 |  |  |  |  |  |
| Income from continuing operations before income taxes |  | 5,490 |  |  | 3,763 |  |  | 1,342 |  |  |  |  |  |
| Provision for (benefit from) income taxes |  | (13) |  |  | (442) |  |  | 68 |  |  |  |  |  |
| Income from continuing operations |  | 5,503 |  |  | 4,205 |  |  | 1,274 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | 119 |  |  | 51 |  |  |  |  |  |
| Net income |  | $ | 5,503 |  |  | $ | 4,324 |  |  | $ | 1,325 |  |  |  |  |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.17 |  |  | $ | 0.89 |  |  | $ | 0.28 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.03 |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 1.17 |  |  | $ | 0.92 |  |  | $ | 0.29 |  |  |  |  |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.14 |  |  | $ | 0.87 |  |  | $ | 0.27 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.03 |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 1.14 |  |  | $ | 0.90 |  |  | $ | 0.28 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,695 |  |  | 4,679 |  |  | 4,517 |  |  |  |  |  |
| Diluted |  | 4,836 |  |  | 4,828 |  |  | 4,666 |  |  |  |  |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 153 |  |  | $ | 159 |  |  | $ | 161 |  |  |  |  |  |
| Research and development |  | 822 |  |  | 839 |  |  | 863 |  |  |  |  |  |
| Selling, general and administrative |  | 305 |  |  | 316 |  |  | 548 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 1,280 |  |  | $ | 1,314 |  |  | $ | 1,572 |  |  |  |  |  |

[0001730168-25-000009:8k_2_02:61]
BROADCOM INC.

[0001730168-25-000009:8k_2_02:62]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-25-000009:8k_2_02:63]
(IN MILLIONS)

[0001730168-25-000009:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | November 3,2024 |  | February 4,2024 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 10,145 |  |  | $ | 9,002 |  |  | $ | 7,375 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,484 |  |  | 1,602 |  |  | 1,380 |  |  |  |  |  |
| Stock-based compensation expense |  | 153 |  |  | 159 |  |  | 161 |  |  |  |  |  |
| Restructuring charges |  | 14 |  |  | 51 |  |  | 92 |  |  |  |  |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 6 |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 11,796 |  |  | $ | 10,814 |  |  | $ | 9,014 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 2,253 |  |  | $ | 2,234 |  |  | $ | 2,308 |  |  |  |  |  |
| Stock-based compensation expense |  | 822 |  |  | 839 |  |  | 863 |  |  |  |  |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 1 |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 1,431 |  |  | $ | 1,395 |  |  | $ | 1,444 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 949 |  |  | $ | 1,010 |  |  | $ | 1,572 |  |  |  |  |  |
| Stock-based compensation expense |  | 305 |  |  | 316 |  |  | 548 |  |  |  |  |  |
| Acquisition-related costs |  | 107 |  |  | 86 |  |  | 285 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 537 |  |  | $ | 608 |  |  | $ | 739 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 3,885 |  |  | $ | 4,375 |  |  | $ | 5,292 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 511 |  |  | 813 |  |  | 792 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,127 |  |  | 1,155 |  |  | 1,411 |  |  |  |  |  |
| Restructuring and other charges |  | 172 |  |  | 318 |  |  | 620 |  |  |  |  |  |
| Acquisition-related costs |  | 107 |  |  | 86 |  |  | 286 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,968 |  |  | $ | 2,003 |  |  | $ | 2,183 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 6,260 |  |  | $ | 4,627 |  |  | $ | 2,083 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,995 |  |  | 2,415 |  |  | 2,172 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,280 |  |  | 1,314 |  |  | 1,572 |  |  |  |  |  |
| Restructuring and other charges |  | 186 |  |  | 369 |  |  | 712 |  |  |  |  |  |
| Acquisition-related costs |  | 107 |  |  | 86 |  |  | 292 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 9,828 |  |  | $ | 8,811 |  |  | $ | 6,831 |  |  |  |  |  |
| Interest expense on GAAP basis |  | $ | (873) |  |  | $ | (916) |  |  | $ | (926) |  |  |  |  |  |
| Loss on debt extinguishment |  | 65 |  |  | 52 |  |  | — |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | $ | (808) |  |  | $ | (864) |  |  | $ | (926) |  |  |  |  |  |
| Other income, net on GAAP basis |  | $ | 103 |  |  | $ | 52 |  |  | $ | 185 |  |  |  |  |  |
| (Gains) losses on investments |  | 4 |  |  | 30 |  |  | (33) |  |  |  |  |  |
| Other |  | (31) |  |  | — |  |  | — |  |  |  |  |  |
| Other income, net on non-GAAP basis |  | $ | 76 |  |  | $ | 82 |  |  | $ | 152 |  |  |  |  |  |

[0001730168-25-000009:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | November 3,2024 |  | February 4,2024 |  |  |  |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (13) |  |  | $ | (442) |  |  | $ | 68 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | 1,286 |  |  | 1,506 |  |  | 735 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 1,273 |  |  | $ | 1,064 |  |  | $ | 803 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 5,503 |  |  | $ | 4,324 |  |  | $ | 1,325 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,995 |  |  | 2,415 |  |  | 2,172 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,280 |  |  | 1,314 |  |  | 1,572 |  |  |  |  |  |
| Restructuring and other charges |  | 186 |  |  | 369 |  |  | 712 |  |  |  |  |  |
| Acquisition-related costs |  | 107 |  |  | 86 |  |  | 292 |  |  |  |  |  |
| Loss on debt extinguishment |  | 65 |  |  | 52 |  |  | — |  |  |  |  |  |
| (Gains) losses on investments |  | 4 |  |  | 30 |  |  | (33) |  |  |  |  |  |
| Other |  | (31) |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (1,286) |  |  | (1,506) |  |  | (735) |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | (119) |  |  | (51) |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 7,823 |  |  | $ | 6,965 |  |  | $ | 5,254 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 5,503 |  |  | $ | 4,324 |  |  | $ | 1,325 |  |  |  |  |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,995 |  |  | 2,415 |  |  | 2,172 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,280 |  |  | 1,314 |  |  | 1,572 |  |  |  |  |  |
| Restructuring and other charges |  | 186 |  |  | 369 |  |  | 712 |  |  |  |  |  |
| Acquisition-related costs |  | 107 |  |  | 86 |  |  | 292 |  |  |  |  |  |
| Loss on debt extinguishment |  | 65 |  |  | 52 |  |  | — |  |  |  |  |  |
| (Gains) losses on investments |  | 4 |  |  | 30 |  |  | (33) |  |  |  |  |  |
| Other |  | (31) |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (1,286) |  |  | (1,506) |  |  | (735) |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | (119) |  |  | (51) |  |  |  |  |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 808 |  |  | 864 |  |  | 926 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 1,273 |  |  | 1,064 |  |  | 803 |  |  |  |  |  |
| Depreciation |  | 142 |  |  | 156 |  |  | 139 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 37 |  |  | 40 |  |  | 34 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 10,083 |  |  | $ | 9,089 |  |  | $ | 7,156 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,836 |  |  | 4,828 |  |  | 4,666 |  |  |  |  |  |
| Non-GAAP adjustment (1) |  | 59 |  |  | 77 |  |  | 113 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,895 |  |  | 4,905 |  |  | 4,779 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 6,113 |  |  | $ | 5,604 |  |  | $ | 4,815 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (100) |  |  | (122) |  |  | (122) |  |  |  |  |  |
| Free cash flow |  | $ | 6,013 |  |  | $ | 5,482 |  |  | $ | 4,693 |  |  |  |  |  |

[0001730168-25-000009:8k_2_02:66]
|  |  | Fiscal Quarter Ending |
|  |  | May 4, |
| Expected average diluted share count: |  | 2025 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,840 |  |
| Non-GAAP adjustment (1) |  | 107 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,947 |  |

[0001730168-25-000009:8k_2_02:67]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |

[0001730168-25-000009:8k_2_02:68]
BROADCOM INC.

[0001730168-25-000009:8k_2_02:69]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-25-000009:8k_2_02:70]
(IN MILLIONS)

[0001730168-25-000009:8k_2_02:71]
|  |  | February 2,2025 |  | November 3,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,307 |  |  | $ | 9,348 |  |
| Trade accounts receivable, net |  | 4,955 |  |  | 4,416 |  |
| Inventory |  | 1,908 |  |  | 1,760 |  |
| Other current assets |  | 4,820 |  |  | 4,071 |  |
| Total current assets |  | 20,990 |  |  | 19,595 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,465 |  |  | 2,521 |  |
| Goodwill |  | 97,871 |  |  | 97,873 |  |
| Intangible assets, net |  | 38,583 |  |  | 40,583 |  |
| Other long-term assets |  | 5,449 |  |  | 5,073 |  |
| Total assets |  | $ | 165,358 |  |  | $ | 165,645 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,905 |  |  | $ | 1,662 |  |
| Employee compensation and benefits |  | 922 |  |  | 1,971 |  |
| Short-term debt |  | 5,653 |  |  | 1,271 |  |
| Other current liabilities |  | 12,430 |  |  | 11,793 |  |
| Total current liabilities |  | 20,910 |  |  | 16,697 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 60,926 |  |  | 66,295 |  |
| Other long-term liabilities |  | 13,733 |  |  | 14,975 |  |
| Total liabilities |  | 95,569 |  |  | 97,967 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 66,848 |  |  | 67,466 |  |
| Retained earnings |  | 2,729 |  |  | — |  |
| Accumulated other comprehensive income |  | 207 |  |  | 207 |  |
| Total stockholders' equity |  | 69,789 |  |  | 67,678 |  |
| Total liabilities and equity |  | $ | 165,358 |  |  | $ | 165,645 |  |

[0001730168-25-000009:8k_2_02:72]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | November 3,2024 |  | February 4,2024 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,503 |  |  | $ | 4,324 |  |  | $ | 1,325 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,032 |  |  | 2,455 |  |  | 2,206 |  |  |  |  |  |
| Depreciation |  | 142 |  |  | 156 |  |  | 139 |  |  |  |  |  |
| Stock-based compensation |  | 1,280 |  |  | 1,314 |  |  | 1,582 |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | (696) |  |  | (868) |  |  | (294) |  |  |  |  |  |
| Loss on debt extinguishment |  | 65 |  |  | 52 |  |  | — |  |  |  |  |  |
| Non-cash interest expense |  | 97 |  |  | 91 |  |  | 102 |  |  |  |  |  |
| Other |  | 41 |  |  | 138 |  |  | 38 |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (539) |  |  | 249 |  |  | 1,756 |  |  |  |  |  |
| Inventory |  | (148) |  |  | 134 |  |  | (14) |  |  |  |  |  |
| Accounts payable |  | 241 |  |  | (85) |  |  | (74) |  |  |  |  |  |
| Employee compensation and benefits |  | (908) |  |  | 196 |  |  | (660) |  |  |  |  |  |
| Other current assets and current liabilities |  | 26 |  |  | (1,410) |  |  | (2,182) |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | (1,023) |  |  | (1,142) |  |  | 891 |  |  |  |  |  |
| Net cash provided by operating activities |  | 6,113 |  |  | 5,604 |  |  | 4,815 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  | — |  |  | — |  |  | (25,416) |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (100) |  |  | (122) |  |  | (122) |  |  |  |  |  |
| Purchases of investments |  | (105) |  |  | (30) |  |  | (13) |  |  |  |  |  |
| Sales of investments |  | 18 |  |  | 20 |  |  | 89 |  |  |  |  |  |
| Other |  | 13 |  |  | — |  |  | (15) |  |  |  |  |  |
| Net cash used in investing activities |  | (174) |  |  | (132) |  |  | (25,477) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 2,986 |  |  | 4,969 |  |  | 30,010 |  |  |  |  |  |
| Payments on debt obligations |  | (8,090) |  |  | (7,472) |  |  | (934) |  |  |  |  |  |
| Proceeds from commercial paper, net |  | 3,980 |  |  | — |  |  | — |  |  |  |  |  |
| Payments of dividends |  | (2,774) |  |  | (2,484) |  |  | (2,435) |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | (7,176) |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (2,036) |  |  | (1,204) |  |  | (1,114) |  |  |  |  |  |
| Issuance of common stock |  | — |  |  | 126 |  |  | — |  |  |  |  |  |
| Other |  | (46) |  |  | (11) |  |  | (14) |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  | (5,980) |  |  | (6,076) |  |  | 18,337 |  |  |  |  |  |
| Net change in cash and cash equivalents |  | (41) |  |  | (604) |  |  | (2,325) |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 9,348 |  |  | 9,952 |  |  | 14,189 |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 9,307 |  |  | $ | 9,348 |  |  | $ | 11,864 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 671 |  |  | $ | 738 |  |  | $ | 750 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 404 |  |  | $ | 832 |  |  | $ | 904 |  |  |  |  |  |
