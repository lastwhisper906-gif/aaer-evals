# AVGO notes — 0001730168-25-000021


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-25-000021:notes:1]
[same as prior period, unchanged from 0001730168-24-000099:notes:1]

[0001730168-25-000021:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-25-000021:notes:3]
[same as prior period, unchanged from 0001730168-24-000099:notes:4]

[0001730168-25-000021:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year ending November 2, 2025 (“fiscal year 2025”) is a 52-week fiscal year. Our fiscal year ended November 3, 2024 (“fiscal year 2024”) was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.

[0001730168-25-000021:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 2, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.

[0001730168-25-000021:notes:6]
[same as prior period, unchanged from 0001730168-24-000099:notes:7]

[0001730168-25-000021:notes:7]
[same as prior period, unchanged from 0001730168-24-000099:notes:8]

[0001730168-25-000021:notes:8]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-25-000021:notes:9]
[same as prior period, unchanged from 0001730168-24-000099:notes:10]

[0001730168-25-000021:notes:10]
[same as prior period, unchanged from 0001730168-24-000099:notes:11]

[0001730168-25-000021:notes:11]
[same as prior period, unchanged from 0001730168-24-000099:notes:12]

[0001730168-25-000021:notes:12]
[same as prior period, unchanged from 0001730168-24-000099:notes:13]

[0001730168-25-000021:notes:13]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 7,269 |  |  | $ | 412 |  |  | $ | 8,171 |  |
| Subscriptions and services |  | 4,142 |  |  | 763 |  |  | 1,840 |  |  | 6,745 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

[0001730168-25-000021:notes:14]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

[0001730168-25-000021:notes:15]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.

[0001730168-25-000021:notes:16]
[same as prior period, unchanged from 0001730168-24-000099:notes:19]

[0001730168-25-000021:notes:17]
[same as prior period, unchanged from 0001730168-24-000099:notes:20]

[0001730168-25-000021:notes:18]
|  |  | February 2,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 5,548 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,536 |  |  | $ | 14,495 |  |

[0001730168-25-000021:notes:19]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of February 2, 2025, approximately 59% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 2, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $3,583 million. The amount of revenue recognized during the fiscal quarter ended February 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,313 million.

[0001730168-25-000021:notes:20]
[same as prior period, unchanged from 0001730168-24-000099:notes:23]

[0001730168-25-000021:notes:21]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract

[0001730168-25-000021:notes:22]
permits termination for convenience. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-25-000021:notes:23]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of February 2, 2025 were approximately $22.4 billion. We expect approximately 40% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-25-000021:notes:24]
[same as prior period, unchanged from 0001730168-24-000099:notes:26]

[0001730168-25-000021:notes:25]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction. The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities.

[0001730168-25-000021:notes:26]
On July 1, 2024, we sold VMware’s end-user computing business for $3.5 billion, after working capital adjustments. In connection with the sale, we agreed to provide transitional services to the buyer on a short-term basis. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Net revenue and income from discontinued operations, net of income taxes were $350 million and $51 million, respectively, for the fiscal quarter ended February 4, 2024.

[0001730168-25-000021:notes:27]
[same as prior period, unchanged from 0001730168-24-000099:notes:49]

[0001730168-25-000021:notes:28]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if VMware had been acquired on October 31, 2022, the beginning of fiscal year 2023. The unaudited pro forma information includes adjustments to amortization for intangible assets acquired, stock-based compensation expense, interest expense for acquisition financing, amortization of deferred assets, and depreciation for property and equipment acquired. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred on October 31, 2022 or of the results of our future operations of the combined business.

[0001730168-25-000021:notes:29]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  |  |  |  |  |  |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 12,523 |  |  |  |  |  |  |  |
| Pro forma net income |  | $ | 1,615 |  |  |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-25-000021:notes:30]
[same as prior period, unchanged from 0001730168-24-000099:notes:59]

[0001730168-25-000021:notes:31]
Cash equivalents included $2,213 million and $1,716 million of time deposits and $711 million and $1,171 million of money-market funds as of February 2, 2025 and November 3, 2024, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-25-000021:notes:32]
[same as prior period, unchanged from 0001730168-24-000099:notes:61]

[0001730168-25-000021:notes:33]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $2,201 million and $1,250 million during the fiscal quarters ended February 2, 2025 and February 4, 2024, respectively.

[0001730168-25-000021:notes:34]
[same as prior period, unchanged from 0001730168-24-000099:notes:63]

[0001730168-25-000021:notes:35]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Finished goods |  | $ | 565 |  |  | $ | 504 |  |
| Work-in-process |  | 950 |  |  | 970 |  |
| Raw materials |  | 393 |  |  | 286 |  |
| Total inventory |  | $ | 1,908 |  |  | $ | 1,760 |  |

[0001730168-25-000021:notes:36]
[same as prior period, unchanged from 0001730168-24-000099:notes:69]

[0001730168-25-000021:notes:37]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 2,722 |  |  | $ | 1,916 |  |
| Prepaid expenses |  | 1,285 |  |  | 1,391 |  |
| Other |  | 813 |  |  | 764 |  |
| Total other current assets |  | $ | 4,820 |  |  | $ | 4,071 |  |

[0001730168-25-000021:notes:38]
[same as prior period, unchanged from 0001730168-24-000099:notes:71]

[0001730168-25-000021:notes:39]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,908 |  |  | $ | 9,395 |  |
| Tax liabilities |  | 823 |  |  | 720 |  |
| Interest payable |  | 575 |  |  | 535 |  |
| Other |  | 1,124 |  |  | 1,143 |  |
| Total other current liabilities |  | $ | 12,430 |  |  | $ | 11,793 |  |

[0001730168-25-000021:notes:40]
[same as prior period, unchanged from 0001730168-24-000099:notes:73]

[0001730168-25-000021:notes:41]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 4,628 |  |  | $ | 5,100 |  |
| Deferred tax liabilities |  | 4,017 |  |  | 4,703 |  |
| Unrecognized tax benefits |  | 3,621 |  |  | 3,669 |  |
| Other |  | 1,467 |  |  | 1,503 |  |
| Total other long-term liabilities |  | $ | 13,733 |  |  | $ | 14,975 |  |

[0001730168-25-000021:notes:42]
[same as prior period, unchanged from 0001730168-24-000099:notes:75]

[0001730168-25-000021:notes:43]
|  |  | Fiscal Quarter Ended |
|  |  | February 2,2025 |  | February 4,2024 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 671 |  |  | $ | 750 |  |
| Cash paid for income taxes |  | $ | 404 |  |  | $ | 904 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-25-000021:notes:44]
Intangible Assets

[0001730168-25-000021:notes:45]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of February 2, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (14,035) |  |  | $ | 21,432 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,782) |  |  | 13,404 |  |
| Trade names |  | 1,720 |  |  | (396) |  |  | 1,324 |  |
| Other |  | 191 |  |  | (108) |  |  | 83 |  |
| Intangible assets subject to amortization |  | 53,564 |  |  | (17,321) |  |  | 36,243 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,904 |  |  | $ | (17,321) |  |  | $ | 38,583 |  |
| As of November 3, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (12,551) |  |  | $ | 22,916 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,271) |  |  | 13,915 |  |
| Trade names |  | 1,720 |  |  | (369) |  |  | 1,351 |  |
| Other |  | 166 |  |  | (105) |  |  | 61 |  |
| Intangible assets subject to amortization |  | 53,539 |  |  | (15,296) |  |  | 38,243 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,879 |  |  | $ | (15,296) |  |  | $ | 40,583 |  |

[0001730168-25-000021:notes:46]
Based on the amount of intangible assets subject to amortization as of February 2, 2025, the expected amortization expense was as follows:

[0001730168-25-000021:notes:47]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 6,032 |  |
| 2026 |  | 7,572 |  |
| 2027 |  | 6,535 |  |
| 2028 |  | 5,444 |  |
| 2029 |  | 4,357 |  |
| Thereafter |  | 6,303 |  |
| Total |  | $ | 36,243 |  |

[0001730168-25-000021:notes:48]
[same as prior period, unchanged from 0001730168-24-000099:notes:82]

[0001730168-25-000021:notes:49]
| Amortizable intangible assets: |  | February 2,2025 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 7 |
| Trade names |  | 12 |
| Other |  | 11 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-25-000021:notes:50]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-25-000021:notes:51]
Potentially dilutive shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”) and employee stock purchase plan (“ESPP”) rights (collectively referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-25-000021:notes:52]
[same as prior period, unchanged from 0001730168-24-000099:notes:86]

[0001730168-25-000021:notes:53]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income per share computations for the periods presented:

[0001730168-25-000021:notes:54]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | February 4,2024 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 5,503 |  |  | $ | 1,274 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | 51 |  |  |  |  |  |
| Net income |  | $ | 5,503 |  |  | $ | 1,325 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,695 |  |  | 4,517 |  |  |  |  |  |
| Dilutive effect of equity awards |  | 141 |  |  | 149 |  |  |  |  |  |
| Weighted-average shares outstanding - diluted |  | 4,836 |  |  | 4,666 |  |  |  |  |  |

[0001730168-25-000021:notes:55]
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.17 |  |  | $ | 0.28 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 1.17 |  |  | $ | 0.29 |  |  |  |  |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.14 |  |  | $ | 0.27 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 1.14 |  |  | $ | 0.28 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-25-000021:notes:56]
Borrowings

[0001730168-25-000021:notes:57]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | $ | 1,100 |  |  | $ | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.70 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |

[0001730168-25-000021:notes:58]
|  |  | Effective Interest Rate |  | February 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 64,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.62 | % | (b) | 4,000 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 68,757 |  |  | $ | 69,847 |  |

[0001730168-25-000021:notes:59]
|  |  | February 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,992 |  |  | — |  |
| Short-term finance lease liabilities |  | 11 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,653 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,107 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 11 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,192) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 60,926 |  |  | $ | 66,295 |  |

[0001730168-25-000021:notes:60]
______________________________

[0001730168-25-000021:notes:61]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

[0001730168-25-000021:notes:62]
(b) Represents the weighted average interest rate on commercial paper outstanding as of February 2, 2025.

[0001730168-25-000021:notes:63]
Senior Notes

[0001730168-25-000021:notes:64]
In January 2025, we issued senior unsecured notes for an aggregate principal amount of $3,000 million. Using the net proceeds from the senior notes and commercial paper issued in January 2025, as well as cash on hand, we repaid the remaining $5,595 million of our unsecured term A-3 facility and $2,000 million of our unsecured term A-5 facility. As a result of these repayments, we wrote off unamortized discount and issuance costs of $65 million, which were included in interest expense in the condensed consolidated statement of operations.

[0001730168-25-000021:notes:65]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

[0001730168-25-000021:notes:66]
2025 Credit Agreement

[0001730168-25-000021:notes:67]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either February 2, 2025 or November 3, 2024.

[0001730168-25-000021:notes:68]
Commercial Paper

[0001730168-25-000021:notes:69]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of February 2, 2025, we had $4.0 billion of commercial paper outstanding with maturities generally less than sixty days.

[0001730168-25-000021:notes:70]
Fair Value of Debt

[0001730168-25-000021:notes:71]
As of February 2, 2025, the estimated aggregate fair value of our senior notes was $53,926 million, which was determined using quoted prices from less active markets. The carrying value of the unsecured term loans approximates their fair value as the unsecured term loans are carried at a market observable interest rate tied to the Secured Overnight Financing Rate (“SOFR”) that resets periodically. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-25-000021:notes:72]
Future Principal Payments of Debt

[0001730168-25-000021:notes:73]
The future scheduled principal payments of senior notes and term loans as of February 2, 2025 were as follows:

[0001730168-25-000021:notes:74]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 750 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 5,370 |  |
| 2029 |  | 10,655 |  |
| Thereafter |  | 38,693 |  |
| Total |  | $ | 64,757 |  |

[0001730168-25-000021:notes:75]
As of February 2, 2025 and November 3, 2024, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-25-000021:notes:76]
Stockholders’ Equity
Cash Dividends Declared and Paid

[0001730168-25-000021:notes:77]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | February 4,2024 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.590 |  |  | $ | 0.525 |  |  |  |  |  |
| Dividends to common stockholders |  | $ | 2,774 |  |  | $ | 2,435 |  |  |  |  |  |

[0001730168-25-000021:notes:78]
[same as prior period, unchanged from 0001730168-24-000099:notes:121]

[0001730168-25-000021:notes:79]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | February 4,2024 |  |  |  |  |
|  |  | (In millions) |
| Cost of products sold |  | $ | 33 |  |  | $ | 28 |  |  |  |  |  |
| Cost of subscriptions and services |  | 120 |  |  | 133 |  |  |  |  |  |
| Research and development |  | 822 |  |  | 863 |  |  |  |  |  |
| Selling, general and administrative |  | 305 |  |  | 548 |  |  |  |  |  |
| Total stock-based compensation expense (a) |  | $ | 1,280 |  |  | $ | 1,572 |  |  |  |  |  |

[0001730168-25-000021:notes:80]
[same as prior period, unchanged from 0001730168-24-000099:notes:123]

[0001730168-25-000021:notes:81]
(a) Does not include stock-based compensation expense related to discontinued operations recognized during the fiscal quarter ended February 4, 2024, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statement of operations.

[0001730168-25-000021:notes:82]
As of February 2, 2025, the total unrecognized compensation cost related to unvested stock-based awards was $10,745 million, which is expected to be recognized over the remaining weighted-average service period of 2.9 years.

[0001730168-25-000021:notes:83]
[same as prior period, unchanged from 0001730168-24-000099:notes:127]

[0001730168-25-000021:notes:84]
[same as prior period, unchanged from 0001730168-24-000099:notes:128]

[0001730168-25-000021:notes:85]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 3, 2024 |  | 213 |  |  | $ | 66.44 |  |  |  |  |  |
| Granted |  | 4 |  |  | $ | 218.97 |  |  |  |  |  |
| Vested |  | (24) |  |  | $ | 60.42 |  |  |  |  |  |
| Forfeited |  | (4) |  |  | $ | 83.31 |  |  |  |  |  |
| Balance as of February 2, 2025 |  | 189 |  |  | $ | 70.73 |  |  |  |  |  |

[0001730168-25-000021:notes:86]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended February 2, 2025 was $5,276 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-25-000021:notes:87]
Income Taxes
The benefit from income taxes was $13 million for the fiscal quarter ended February 2, 2025 and was primarily due to excess tax benefits from stock-based awards partially offset by income before income taxes and a shift in the jurisdictional mix of revenue and expenses.

[0001730168-25-000021:notes:88]
The provision for income taxes was $68 million for the fiscal quarter ended February 4, 2024 and was primarily due to income before income taxes partially offset by excess tax benefits from stock-based awards and a valuation allowance release. 
As of February 2, 2025, we had $6,589 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $3,474 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations, and changes in balances related to tax positions to be taken during the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-25-000021:notes:89]
[same as prior period, unchanged from 0001730168-24-000099:notes:132]

[0001730168-25-000021:notes:90]
[same as prior period, unchanged from 0001730168-24-000099:notes:133]

[0001730168-25-000021:notes:91]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, service provider, and enterprise networking applications, including AI networking and connectivity. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions, custom touch controllers, and inductive charging solutions for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-25-000021:notes:92]
Infrastructure software. We provide a portfolio of software solutions that help enterprises simplify their IT environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical FC SAN products and related software.

[0001730168-25-000021:notes:93]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as marketing, general and administrative activities, facilities and IT expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-25-000021:notes:94]
[same as prior period, unchanged from 0001730168-24-000099:notes:137]

[0001730168-25-000021:notes:95]
[same as prior period, unchanged from 0001730168-24-000099:notes:138]

[0001730168-25-000021:notes:96]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the “Summary of Significant Accounting Policies” included in the Annual Report on Form 10-K for fiscal year 2024.

[0001730168-25-000021:notes:97]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 2,2025 |  | February 4,2024 |  |  |  |  |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 8,212 |  |  | $ | 7,390 |  |  |  |  |  |
| Infrastructure software |  | 6,704 |  |  | 4,571 |  |  |  |  |  |
| Total net revenue |  | $ | 14,916 |  |  | $ | 11,961 |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,706 |  |  | $ | 4,116 |  |  |  |  |  |
| Infrastructure software |  | 5,122 |  |  | 2,715 |  |  |  |  |  |
| Unallocated expenses |  | (3,568) |  |  | (4,748) |  |  |  |  |  |
| Total operating income |  | $ | 6,260 |  |  | $ | 2,083 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-25-000021:notes:98]
Commitments and Contingencies
Commitments

[0001730168-25-000021:notes:99]
The following table summarizes contractual obligations and commitments as of February 2, 2025:

[0001730168-25-000021:notes:100]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 89 |  |  | $ | 498 |  |
| 2026 |  | 223 |  |  | 587 |  |
| 2027 |  | 10 |  |  | 566 |  |
| 2028 |  | 10 |  |  | 501 |  |
| 2029 |  | 3 |  |  | 689 |  |
| Thereafter |  | — |  |  | 1,003 |  |
| Total |  | $ | 335 |  |  | $ | 3,844 |  |

[0001730168-25-000021:notes:101]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-25-000021:notes:102]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-25-000021:notes:103]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 2, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,621 million of unrecognized tax benefits and accrued interest and penalties as of February 2, 2025 have been excluded from the table above.

[0001730168-25-000021:notes:104]
Contingencies

[0001730168-25-000021:notes:105]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-25-000021:notes:106]
Lawsuits Relating to VMware Backlog

[0001730168-25-000021:notes:107]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms pending approval by the California Court.

[0001730168-25-000021:notes:108]
Other Matters

[0001730168-25-000021:notes:109]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-25-000021:notes:110]
Contingency Assessment

[0001730168-25-000021:notes:111]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-25-000021:notes:112]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-25-000021:notes:113]
Other Indemnifications

[0001730168-25-000021:notes:114]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-25-000021:notes:115]
Restructuring and Other Charges
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the fiscal quarter ended February 2, 2025:

[0001730168-25-000021:notes:116]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2024 |  | $ | 119 |  |  | $ | — |  |  | $ | 119 |  |
| Restructuring charges |  | 105 |  |  | 81 |  |  | 186 |  |
| Utilization |  | (163) |  |  | (81) |  |  | (244) |  |
| Balance as of February 2, 2025 |  | $ | 61 |  |  | $ | — |  |  | $ | 61 |  |

[0001730168-25-000021:notes:117]
In connection with the acquisition of VMware, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized $105 million and $673 million of restructuring charges related to employee termination costs and $81 million and $39 million of impairment charges primarily related to lease assets and property, plant and equipment for the fiscal quarters ended February 2, 2025 and February 4, 2024, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses.


## us-gaap:SubsequentEventsTextBlock

[0001730168-25-000021:notes:118]
Subsequent Events
Cash Dividends Declared

[0001730168-25-000021:notes:119]
On March 5, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on March 31, 2025 to stockholders of record on March 20, 2025.
