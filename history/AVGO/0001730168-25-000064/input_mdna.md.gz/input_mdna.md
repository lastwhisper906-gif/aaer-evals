# AVGO MD&A — 0001730168-25-000064


## mdna

[0001730168-25-000064:mdna:1]
[same as prior period, unchanged from 0001730168-25-000021:mdna:1]

[0001730168-25-000064:mdna:2]
[same as prior period, unchanged from 0001730168-25-000021:mdna:2]

[0001730168-25-000064:mdna:3]
[same as prior period, unchanged from 0001730168-25-000021:mdna:4]

[0001730168-25-000064:mdna:4]
[same as prior period, unchanged from 0001730168-25-000021:mdna:5]

[0001730168-25-000064:mdna:5]
[same as prior period, unchanged from 0001730168-25-000021:mdna:6]

[0001730168-25-000064:mdna:6]
Our fiscal year ending November 2, 2025 (“fiscal year 2025”), is a 52-week fiscal year, with our first fiscal quarter containing 13 weeks compared to 14 weeks in the prior year fiscal period. The additional week resulted in higher net revenue, gross margin dollars, research and development expense, and selling, general and administrative expense in the first two fiscal quarters of fiscal year 2024, compared to the corresponding current year fiscal period.

[0001730168-25-000064:mdna:7]
[same as prior period, unchanged from 0001730168-25-000021:mdna:8]

[0001730168-25-000064:mdna:8]
[same as prior period, unchanged from 0001730168-25-000021:mdna:9]

[0001730168-25-000064:mdna:9]
Highlights during the fiscal quarter ended May 4, 2025 include the following:

[0001730168-25-000064:mdna:10]
•We generated $6,555 million of cash from operations.

[0001730168-25-000064:mdna:11]
•We paid $2,785 million in cash dividends.

[0001730168-25-000064:mdna:12]
•We repurchased $2,450 million of common stock.

[0001730168-25-000064:mdna:13]
[same as prior period, unchanged from 0001730168-25-000021:mdna:14]

[0001730168-25-000064:mdna:14]
[same as prior period, unchanged from 0001730168-25-000021:mdna:15]

[0001730168-25-000064:mdna:15]
There were no significant changes in our critical accounting estimates during the two fiscal quarters ended May 4, 2025 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2024 Annual Report on Form 10-K.

[0001730168-25-000064:mdna:16]
[same as prior period, unchanged from 0001730168-25-000021:mdna:17]

[0001730168-25-000064:mdna:17]
We are subject to risks and exposures from the evolving macroeconomic environment, including uncertainty and volatility in financial markets, efforts of governments to stimulate or stabilize the economy and other unfavorable changes in economic conditions, as well as an increase in trade tensions and related tariffs with U.S. trading partners. While difficult to isolate and quantify, these risks and exposures may cause our net revenue to fluctuate significantly and disrupt supply chain operations, and we continuously monitor the broader impacts of these circumstances on our business, our supply chain and our results of operations.

[0001730168-25-000064:mdna:18]
24

[0001730168-25-000064:mdna:19]
[same as prior period, unchanged from 0001730168-25-000021:mdna:19]

[0001730168-25-000064:mdna:20]
Fiscal Quarter and Two Fiscal Quarters Ended May 4, 2025 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 5, 2024

[0001730168-25-000064:mdna:21]
The following tables set forth our results of operations for the periods presented:

[0001730168-25-000064:mdna:22]
|  |  | Fiscal Quarter Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 8,506 |  |  | $ | 7,192 |  |  | 57 | % |  | 58 | % |
| Subscriptions and services |  | 6,498 |  |  | 5,295 |  |  | 43 |  |  | 42 |  |
| Total net revenue |  | 15,004 |  |  | 12,487 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,720 |  |  | 2,429 |  |  | 18 |  |  | 19 |  |
| Cost of subscriptions and services |  | 576 |  |  | 713 |  |  | 4 |  |  | 6 |  |
| Amortization of acquisition-related intangible assets |  | 1,483 |  |  | 1,516 |  |  | 10 |  |  | 13 |  |
| Restructuring charges |  | 28 |  |  | 53 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 4,807 |  |  | 4,711 |  |  | 32 |  |  | 38 |  |
| Gross margin |  | 10,197 |  |  | 7,776 |  |  | 68 |  |  | 62 |  |
| Research and development |  | 2,693 |  |  | 2,415 |  |  | 18 |  |  | 19 |  |
| Selling, general and administrative |  | 1,083 |  |  | 1,277 |  |  | 7 |  |  | 10 |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 827 |  |  | 3 |  |  | 7 |  |
| Restructuring and other charges |  | 86 |  |  | 292 |  |  | 1 |  |  | 2 |  |
| Total operating expenses |  | 4,368 |  |  | 4,811 |  |  | 29 |  |  | 38 |  |
| Operating income |  | $ | 5,829 |  |  | $ | 2,965 |  |  | 39 | % |  | 24 | % |

[0001730168-25-000064:mdna:23]
[same as prior period, unchanged from 0001730168-25-000021:mdna:53]

[0001730168-25-000064:mdna:24]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 16,677 |  |  | $ | 14,604 |  |  | 56 | % |  | 60 | % |
| Subscriptions and services |  | 13,243 |  |  | 9,844 |  |  | 44 |  |  | 40 |  |
| Total net revenue |  | 29,920 |  |  | 24,448 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 5,413 |  |  | 4,589 |  |  | 18 |  |  | 19 |  |
| Cost of subscriptions and services |  | 1,156 |  |  | 1,667 |  |  | 4 |  |  | 7 |  |
| Amortization of acquisition-related intangible assets |  | 2,967 |  |  | 2,896 |  |  | 10 |  |  | 11 |  |
| Restructuring charges |  | 42 |  |  | 145 |  |  | — |  |  | 1 |  |
| Total cost of revenue |  | 9,578 |  |  | 9,297 |  |  | 32 |  |  | 38 |  |
| Gross margin |  | 20,342 |  |  | 15,151 |  |  | 68 |  |  | 62 |  |
| Research and development |  | 4,946 |  |  | 4,723 |  |  | 17 |  |  | 19 |  |
| Selling, general and administrative |  | 2,032 |  |  | 2,849 |  |  | 7 |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,017 |  |  | 1,619 |  |  | 3 |  |  | 7 |  |
| Restructuring and other charges |  | 258 |  |  | 912 |  |  | 1 |  |  | 4 |  |
| Total operating expenses |  | 8,253 |  |  | 10,103 |  |  | 28 |  |  | 41 |  |
| Operating income |  | $ | 12,089 |  |  | $ | 5,048 |  |  | 40 | % |  | 21 | % |

[0001730168-25-000064:mdna:25]
[same as prior period, unchanged from 0001730168-25-000021:mdna:23]

[0001730168-25-000064:mdna:26]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one customer, which is a distributor, accounted for 29% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 4, 2025, and 29% and 28% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively.

[0001730168-25-000064:mdna:27]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% of our net revenue for each of the fiscal quarters and two fiscal quarters ended May 4, 2025 and May 5, 2024. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-25-000064:mdna:28]
[same as prior period, unchanged from 0001730168-25-000021:mdna:26]

[0001730168-25-000064:mdna:29]
[same as prior period, unchanged from 0001730168-25-000021:mdna:27]

[0001730168-25-000064:mdna:30]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |  |  |  |  |
| Net Revenue by Segment |  | May 4, 2025 |  | May 5, 2024 |  | $ Change |  | % Change |  | May 4, 2025 |  | May 5, 2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 8,408 |  |  | $ | 7,202 |  |  | $ | 1,206 |  |  | 17 | % |  | $ | 16,620 |  |  | $ | 14,592 |  |  | $ | 2,028 |  |  | 14 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 6,596 |  |  | 5,285 |  |  | 1,311 |  |  | 25 | % |  | 13,300 |  |  | 9,856 |  |  | 3,444 |  |  | 35 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 15,004 |  |  | $ | 12,487 |  |  | $ | 2,517 |  |  | 20 | % |  | $ | 29,920 |  |  | $ | 24,448 |  |  | $ | 5,472 |  |  | 22 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000064:mdna:31]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |  |  |
| Net Revenue by Segment |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 56 | % |  | 58 | % |  | 56 | % |  | 60 | % |  |  |  |  |
| Infrastructure software |  | 44 |  |  | 42 |  |  | 44 |  |  | 40 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-25-000064:mdna:32]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended May 4, 2025 compared to the prior year fiscal periods due to strong demand for our networking products, primarily AI networking solutions. The increase in the two fiscal quarters ended May 4, 2025 was partially offset by lower demand for our non-AI solutions, primarily broadband products.

[0001730168-25-000064:mdna:33]
Net revenue from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended May 4, 2025 compared to the prior year fiscal periods primarily due to strong demand for our VMware Cloud Foundation (“VCF”) product, including additional license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model.

[0001730168-25-000064:mdna:34]
[same as prior period, unchanged from 0001730168-25-000021:mdna:31]

[0001730168-25-000064:mdna:35]
Gross margin was $10,197 million for the fiscal quarter ended May 4, 2025 compared to $7,776 million for the fiscal quarter ended May 5, 2024, and $20,342 million for the two fiscal quarters ended May 4, 2025 compared to $15,151 million for the two fiscal quarters ended May 5, 2024. The increases were primarily due to higher software revenue and strong product demand for our AI-related semiconductor solutions.

[0001730168-25-000064:mdna:36]
As a percentage of net revenue, gross margin was 68% of net revenue for each of the fiscal quarter and two fiscal quarters ended May 4, 2025 and 62% for each of the fiscal quarter and two fiscal quarters ended May 5, 2024. The increases were primarily due to higher software revenue mix and lower amortization of acquisition-related intangible assets as a percentage of revenue.

[0001730168-25-000064:mdna:37]
[same as prior period, unchanged from 0001730168-25-000021:mdna:34]

[0001730168-25-000064:mdna:38]
Research and development expense increased $278 million, or 12%, and $223 million, or 5%, for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher stock-based compensation.

[0001730168-25-000064:mdna:39]
[same as prior period, unchanged from 0001730168-25-000021:mdna:36]

[0001730168-25-000064:mdna:40]
Selling, general and administrative expense decreased $194 million, or 15%, for the fiscal quarter ended May 4, 2025 compared to the prior year fiscal period. The decrease was primarily due to lower compensation resulting from a decrease in headcount, partially offset by higher stock-based compensation.

[0001730168-25-000064:mdna:41]
Selling, general and administrative expense decreased $817 million, or 29%, for the two fiscal quarters ended May 4, 2025 compared to the prior year fiscal period. The decrease was primarily due to lower compensation resulting from a decrease in headcount and lower stock-based compensation. In addition, in the two fiscal quarters ended May 5, 2024, we incurred higher VMware acquisition-related costs.

[0001730168-25-000064:mdna:42]
[same as prior period, unchanged from 0001730168-25-000021:mdna:38]

[0001730168-25-000064:mdna:43]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $321 million, or 39%, and $602 million, or 37%, for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, compared to the prior year fiscal periods primarily due to full amortization of customer-related intangible assets from previous software acquisitions other than VMware.

[0001730168-25-000064:mdna:44]
[same as prior period, unchanged from 0001730168-25-000021:mdna:40]

[0001730168-25-000064:mdna:45]
Restructuring and other charges recognized in operating expenses decreased $206 million, or 71%, and $654 million, or 72%, for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, compared to the prior year fiscal periods primarily due to lower employee termination costs associated with the integration of the VMware business.

[0001730168-25-000064:mdna:46]
[same as prior period, unchanged from 0001730168-25-000021:mdna:42]

[0001730168-25-000064:mdna:47]
During the fiscal quarter ended May 4, 2025, we granted two-year time- and market-based restricted stock unit awards (the “Two-Year Equity Awards”), in lieu of our annual employee equity awards historically granted in the second quarter of each fiscal year. Each Two-Year Equity Award vests on the same basis as two annual grants with staggered vesting start dates of March 15, 2025 and March 15, 2026 and successive four-year vesting periods. We recognize stock-based compensation expense related to these awards from the grant date through their respective vesting date, ranging from four to five years.

[0001730168-25-000064:mdna:48]
Total stock-based compensation expense was $1,771 million and $1,403 million for the fiscal quarters ended May 4, 2025 and May 5, 2024, respectively. The increase was due to the Two-Year Equity Awards granted at higher grant-date fair values and a full quarter of expense for the annual employee equity awards granted on March 15, 2024.

[0001730168-25-000064:mdna:49]
Total stock-based compensation expense was $3,051 million and $2,975 million for the two fiscal quarters ended May 4, 2025 and May 5, 2024, respectively. The increase was due to the Two-Year Equity Awards granted at higher grant-date fair values and a full quarter of expense for the annual employee equity awards granted on March 15, 2024. The increase was substantially offset by a one-time impact from aligning the vesting dates of certain equity awards assumed from the acquisition of VMware with our equity award vesting dates and the accelerated vesting of certain equity awards held by employees terminated in connection with the acquisition of VMware in the prior year fiscal periods.

[0001730168-25-000064:mdna:50]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of May 4, 2025. The remaining weighted-average service period was 3.8 years.

[0001730168-25-000064:mdna:51]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 4,299 |  |
| 2026 |  | 7,984 |  |
| 2027 |  | 6,889 |  |
| 2028 |  | 4,743 |  |
| 2029 |  | 2,488 |  |
| Thereafter |  | 617 |  |
| Total |  | $ | 27,020 |  |

[0001730168-25-000064:mdna:52]
[same as prior period, unchanged from 0001730168-25-000021:mdna:46]

[0001730168-25-000064:mdna:53]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |  |  |  |  |
| Operating Income by Segment |  | May 4,2025 |  | May 5,2024 |  | $ Change |  | % Change |  | May 4,2025 |  | May 5,2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,806 |  |  | $ | 3,978 |  |  | $ | 828 |  |  | 21 | % |  | $ | 9,512 |  |  | $ | 8,094 |  |  | $ | 1,418 |  |  | 18 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 4,987 |  |  | 3,168 |  |  | 1,819 |  |  | 57 | % |  | 10,109 |  |  | 5,883 |  |  | 4,226 |  |  | 72 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (3,964) |  |  | (4,181) |  |  | 217 |  |  | (5) | % |  | (7,532) |  |  | (8,929) |  |  | 1,397 |  |  | (16) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 5,829 |  |  | $ | 2,965 |  |  | $ | 2,864 |  |  | 97 | % |  | $ | 12,089 |  |  | $ | 5,048 |  |  | $ | 7,041 |  |  | 139 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000064:mdna:54]
28

[0001730168-25-000064:mdna:55]
Operating income from our semiconductor solutions segment increased for the fiscal quarter and two fiscal quarters ended May 4, 2025 compared to the prior year fiscal periods due to strong demand for our networking products, primarily AI networking solutions. The increase in the two fiscal quarters ended May 4, 2025 was partially offset by lower demand for our non-AI solutions, primarily broadband products.

[0001730168-25-000064:mdna:56]
Higher operating income from our infrastructure software segment in the fiscal quarter and two fiscal quarters ended May 4, 2025 compared to the prior year fiscal periods was primarily due to strong demand for our VCF product, including additional license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model.

[0001730168-25-000064:mdna:57]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 5% for the fiscal quarter ended May 4, 2025 compared to the prior year fiscal period due to lower amortization of acquisition-related intangible assets and restructuring and other charges, partially offset by higher stock-based compensation expense. Unallocated expenses decreased 16% for the two fiscal quarters ended May 4, 2025 compared to the prior year fiscal period due to lower restructuring and other charges, amortization of acquisition-related intangible assets, and acquisition-related costs.

[0001730168-25-000064:mdna:58]
[same as prior period, unchanged from 0001730168-25-000021:mdna:50]

[0001730168-25-000064:mdna:59]
Interest expense. Interest expense was $769 million and $1,642 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, and $1,047 million and $1,973 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The decreases were primarily from an overall reduction in outstanding debt balances and debt refinancing activities that drove lower effective interest rates compared to the prior year fiscal periods.

[0001730168-25-000064:mdna:60]
Other income, net. Other income, net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $25 million and $128 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, and $87 million and $272 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The decreases were primarily due to lower interest income as a result of lower interest rates on lower invested balances.

[0001730168-25-000064:mdna:61]
Provision for (benefit from) income taxes. The provision for income taxes was $120 million and $107 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. The provision for income taxes was primarily due to income before income taxes and the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards. The benefit from income taxes was $116 million and $48 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The benefit from income taxes was primarily due to excess tax benefits from stock-based awards and the jurisdictional mix of income, partially offset by income tax expense on operations.

[0001730168-25-000064:mdna:62]
[same as prior period, unchanged from 0001730168-25-000021:mdna:55]

[0001730168-25-000064:mdna:63]
[same as prior period, unchanged from 0001730168-25-000021:mdna:56]

[0001730168-25-000064:mdna:64]
Our primary sources of liquidity as of May 4, 2025 consisted of: (i) $9,472 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-25-000064:mdna:65]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $69,407 million of outstanding indebtedness with $5,550 million principal amounts payable within 12 months, (vi) discretionary share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-25-000064:mdna:66]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-25-000064:mdna:67]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do

[0001730168-25-000064:mdna:68]
29

[0001730168-25-000064:mdna:69]
not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our outstanding indebtedness and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-25-000064:mdna:70]
[same as prior period, unchanged from 0001730168-25-000021:mdna:61]

[0001730168-25-000064:mdna:71]
[same as prior period, unchanged from 0001730168-25-000021:mdna:62]

[0001730168-25-000064:mdna:72]
Working capital decreased to $1,584 million at May 4, 2025 from $2,898 million at November 3, 2024. The decrease was primarily attributable to the following:

[0001730168-25-000064:mdna:73]
•Short-term debt increased to $5,531 million at May 4, 2025 from $1,271 million at November 3, 2024 primarily due to the net issuance of $3,900 million of commercial paper and $900 million of senior notes becoming due within the next twelve months, offset in part by a $495 million repayment.

[0001730168-25-000064:mdna:74]
•Other current liabilities increased to $12,503 million at May 4, 2025 from $11,793 million at November 3, 2024 primarily from higher contract liabilities.

[0001730168-25-000064:mdna:75]
[same as prior period, unchanged from 0001730168-25-000021:mdna:67]

[0001730168-25-000064:mdna:76]
•Trade accounts receivable, net increased to $5,563 million at May 4, 2025 from $4,416 million at November 3, 2024 primarily due to higher software billings.

[0001730168-25-000064:mdna:77]
•Other current assets increased to $5,129 million at May 4, 2025 from $4,071 million at November 3, 2024 primarily from higher software contract assets, offset in part by lower prepaid taxes.

[0001730168-25-000064:mdna:78]
•Employee compensation and benefits decreased to $1,266 million at May 4, 2025 from $1,971 million at November 3, 2024 primarily due to the timing of annual employee bonus plan payments.

[0001730168-25-000064:mdna:79]
[same as prior period, unchanged from 0001730168-25-000021:mdna:73]

[0001730168-25-000064:mdna:80]
|  |  | Two Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 1.18 |  |  | $ | 1.05 |  |
| Dividends to common stockholders |  | $ | 5,559 |  |  | $ | 4,878 |  |

[0001730168-25-000064:mdna:81]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025. During the fiscal quarter ended May 4, 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million under this stock repurchase program. As of May 4, 2025, $7,550 million of the authorized amount remained available for repurchases.

[0001730168-25-000064:mdna:82]
Repurchases under this stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000064:mdna:83]
In December 2021 and May 2022, our Board of Directors authorized stock repurchase programs to repurchase up to an aggregate of $20 billion of our common stock from time to time prior to December 31, 2023. During the fiscal quarter ended February 4, 2024, we repurchased and retired 67 million shares of our common stock for $7,176 million, and all $20 billion of the aggregate authorized amount was utilized prior to expiration on December 31, 2023.

[0001730168-25-000064:mdna:84]
During the two fiscal quarters ended May 4, 2025 and May 5, 2024, we paid $3,802 million and $2,662 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld 17 million and 22 million shares of common stock from employees in connection with such net share settlements during the two fiscal quarters ended May 4, 2025 and May 5, 2024, respectively.

[0001730168-25-000064:mdna:85]
[same as prior period, unchanged from 0001730168-25-000021:mdna:76]

[0001730168-25-000064:mdna:86]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 12,668 |  |  | $ | 9,395 |  |
| Net cash used in investing activities |  | (307) |  |  | (26,183) |  |
| Net cash provided by (used in) financing activities |  | (12,237) |  |  | 12,408 |  |
| Net change in cash and cash equivalents |  | $ | 124 |  |  | $ | (4,380) |  |

[0001730168-25-000064:mdna:87]
[same as prior period, unchanged from 0001730168-25-000021:mdna:78]

[0001730168-25-000064:mdna:88]
Cash flows from operating activities consist of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $3,273 million increase in cash provided by operations during the two fiscal quarters ended May 4, 2025 compared to the prior year fiscal period was primarily due to $7,022 million higher net income, offset in part by $2,750 million from changes in operating assets and liabilities and $999 million lower non-cash adjustments including amortization of intangible assets and deferred taxes and other non-cash taxes.

[0001730168-25-000064:mdna:89]
[same as prior period, unchanged from 0001730168-25-000021:mdna:80]

[0001730168-25-000064:mdna:90]
Cash flows from investing activities primarily consist of cash related to acquisitions and divestitures, capital expenditures and proceeds and payments related to investments. The $25,876 million decrease in cash used in investing activities during the two fiscal quarters ended May 4, 2025 compared to the prior year fiscal period was primarily due to $25,416 million cash paid in connection with the acquisition of VMware, net of cash acquired, in the prior year fiscal period.

[0001730168-25-000064:mdna:91]
[same as prior period, unchanged from 0001730168-25-000021:mdna:82]

[0001730168-25-000064:mdna:92]
Cash flows from financing activities primarily consist of proceeds and payments related to our borrowings, dividend payments, employee withholding tax payments related to net settled equity awards and authorized stock repurchases. Cash flows from financing activities during the two fiscal quarters ended May 4, 2025 compared to the prior year fiscal period decreased $24,645 million. The decrease was primarily from the $30,010 million of net proceeds from term loans issued in connection with the acquisition of VMware in the prior year fiscal period, increases in the current year fiscal period in employee withholding tax payments related to net settled equity awards and dividend payments, offset in part by a decrease in stock repurchases.
