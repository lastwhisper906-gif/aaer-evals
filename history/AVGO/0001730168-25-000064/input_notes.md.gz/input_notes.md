# AVGO notes — 0001730168-25-000064


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-25-000064:notes:1]
[same as prior period, unchanged from 0001730168-25-000021:notes:1]

[0001730168-25-000064:notes:2]
[same as prior period, unchanged from 0001730168-25-000021:notes:2]

[0001730168-25-000064:notes:3]
[same as prior period, unchanged from 0001730168-25-000021:notes:3]

[0001730168-25-000064:notes:4]
[same as prior period, unchanged from 0001730168-25-000021:notes:4]

[0001730168-25-000064:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 4, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.

[0001730168-25-000064:notes:6]
[same as prior period, unchanged from 0001730168-25-000021:notes:6]

[0001730168-25-000064:notes:7]
[same as prior period, unchanged from 0001730168-25-000021:notes:7]

[0001730168-25-000064:notes:8]
[same as prior period, unchanged from 0001730168-25-000021:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-25-000064:notes:9]
[same as prior period, unchanged from 0001730168-25-000021:notes:9]

[0001730168-25-000064:notes:10]
[same as prior period, unchanged from 0001730168-25-000021:notes:10]

[0001730168-25-000064:notes:11]
[same as prior period, unchanged from 0001730168-25-000021:notes:11]

[0001730168-25-000064:notes:12]
[same as prior period, unchanged from 0001730168-25-000021:notes:12]

[0001730168-25-000064:notes:13]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 635 |  |  | $ | 7,454 |  |  | $ | 417 |  |  | $ | 8,506 |  |
| Subscriptions and services |  | 4,071 |  |  | 646 |  |  | 1,781 |  |  | 6,498 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

[0001730168-25-000064:notes:14]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

[0001730168-25-000064:notes:15]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,125 |  |  | $ | 14,723 |  |  | $ | 829 |  |  | $ | 16,677 |  |
| Subscriptions and services |  | 8,213 |  |  | 1,409 |  |  | 3,621 |  |  | 13,243 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

[0001730168-25-000064:notes:16]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

[0001730168-25-000064:notes:17]
[same as prior period, unchanged from 0001730168-25-000021:notes:15]

[0001730168-25-000064:notes:18]
[same as prior period, unchanged from 0001730168-25-000021:notes:16]

[0001730168-25-000064:notes:19]
[same as prior period, unchanged from 0001730168-25-000021:notes:17]

[0001730168-25-000064:notes:20]
|  |  | May 4,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 6,427 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,457 |  |  | $ | 14,495 |  |

[0001730168-25-000064:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of May 4, 2025, approximately 66% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 4, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $6,103 million. The amount of revenue recognized during the two fiscal quarters ended May 5, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,965 million.

[0001730168-25-000064:notes:22]
[same as prior period, unchanged from 0001730168-25-000021:notes:20]

[0001730168-25-000064:notes:23]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract permits termination for convenience. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-25-000064:notes:24]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of May 4, 2025 were approximately $24.7 billion. We expect approximately 36% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-25-000064:notes:25]
[same as prior period, unchanged from 0001730168-25-000021:notes:24]

[0001730168-25-000064:notes:26]
[same as prior period, unchanged from 0001730168-25-000021:notes:25]

[0001730168-25-000064:notes:27]
[same as prior period, unchanged from 0001730168-25-000021:notes:27]

[0001730168-25-000064:notes:28]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if VMware had been acquired on October 31, 2022, the beginning of fiscal year 2023. The unaudited pro forma information includes adjustments to amortization for intangible assets acquired, stock-based compensation expense, interest expense for acquisition financing, and depreciation for property and equipment acquired. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred on October 31, 2022 or of the results of our future operations of the combined business.

[0001730168-25-000064:notes:29]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |  |  |
|  |  | May 5,2024 |  | May 5,2024 |  |  |  |  |  |  |  |  |  |  |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 12,507 |  |  | $ | 25,030 |  |  |  |  |  |  |  |  |  |  |  |
| Pro forma net income |  | $ | 2,261 |  |  | $ | 3,876 |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-25-000064:notes:30]
[same as prior period, unchanged from 0001730168-25-000021:notes:30]

[0001730168-25-000064:notes:31]
Cash equivalents included $915 million and $1,716 million of time deposits and $1,041 million and $1,171 million of money-market funds as of May 4, 2025 and November 3, 2024, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-25-000064:notes:32]
[same as prior period, unchanged from 0001730168-25-000021:notes:32]

[0001730168-25-000064:notes:33]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,750 million and $3,951 million during the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, and $1,250 million and $2,500 million during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively.

[0001730168-25-000064:notes:34]
[same as prior period, unchanged from 0001730168-25-000021:notes:34]

[0001730168-25-000064:notes:35]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Finished goods |  | $ | 500 |  |  | $ | 504 |  |
| Work-in-process |  | 1,119 |  |  | 970 |  |
| Raw materials |  | 398 |  |  | 286 |  |
| Total inventory |  | $ | 2,017 |  |  | $ | 1,760 |  |

[0001730168-25-000064:notes:36]
[same as prior period, unchanged from 0001730168-25-000021:notes:36]

[0001730168-25-000064:notes:37]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 3,234 |  |  | $ | 1,916 |  |
| Prepaid expenses |  | 936 |  |  | 1,391 |  |
| Other |  | 959 |  |  | 764 |  |
| Total other current assets |  | $ | 5,129 |  |  | $ | 4,071 |  |

[0001730168-25-000064:notes:38]
[same as prior period, unchanged from 0001730168-25-000021:notes:38]

[0001730168-25-000064:notes:39]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 10,303 |  |  | $ | 9,395 |  |
| Tax liabilities |  | 646 |  |  | 720 |  |
| Interest payable |  | 562 |  |  | 535 |  |
| Other |  | 992 |  |  | 1,143 |  |
| Total other current liabilities |  | $ | 12,503 |  |  | $ | 11,793 |  |

[0001730168-25-000064:notes:40]
[same as prior period, unchanged from 0001730168-25-000021:notes:40]

[0001730168-25-000064:notes:41]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 4,154 |  |  | $ | 5,100 |  |
| Unrecognized tax benefits |  | 3,732 |  |  | 3,669 |  |
| Deferred tax liabilities |  | 3,365 |  |  | 4,703 |  |
| Other |  | 1,445 |  |  | 1,503 |  |
| Total other long-term liabilities |  | $ | 12,696 |  |  | $ | 14,975 |  |

[0001730168-25-000064:notes:42]
Discontinued Operations

[0001730168-25-000064:notes:43]
On July 1, 2024, we sold VMware’s end-user computing business for $3.5 billion, after working capital adjustments. In connection with the sale, we agreed to provide transitional services to the buyer on a short-term basis. We had no material continuing involvement with this business and presented its operating results in discontinued operations as follows:

[0001730168-25-000064:notes:44]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |  |  |
|  |  | May 5,2024 |  |  |  |  |  | May 5,2024 |  |  |  |  |  |  |
|  |  | (In millions) |
| Net revenue |  | $ | 329 |  |  |  |  |  |  | $ | 680 |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations before income taxes |  | $ | 11 |  |  |  |  |  |  | $ | 69 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | (11) |  |  |  |  |  |  | (18) |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | $ | — |  |  |  |  |  |  | $ | 51 |  |  |  |  |  |  |  |  |  |

[0001730168-25-000064:notes:45]
[same as prior period, unchanged from 0001730168-25-000021:notes:42]

[0001730168-25-000064:notes:46]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |  | (In millions) |
| Cash paid for interest |  | $ | 700 |  |  | $ | 946 |  |  | $ | 1,371 |  |  | $ | 1,696 |  |
| Cash paid for income taxes |  | $ | 608 |  |  | $ | 834 |  |  | $ | 1,012 |  |  | $ | 1,738 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-25-000064:notes:47]
[same as prior period, unchanged from 0001730168-25-000021:notes:44]

[0001730168-25-000064:notes:48]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of May 4, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,437 |  |  | $ | (15,515) |  |  | $ | 19,922 |  |
| Customer contracts and related relationships |  | 16,043 |  |  | (3,257) |  |  | 12,786 |  |
| Trade names |  | 1,685 |  |  | (419) |  |  | 1,266 |  |
| Other |  | 191 |  |  | (112) |  |  | 79 |  |
| Intangible assets subject to amortization |  | 53,356 |  |  | (19,303) |  |  | 34,053 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,696 |  |  | $ | (19,303) |  |  | $ | 36,393 |  |
| As of November 3, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (12,551) |  |  | $ | 22,916 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,271) |  |  | 13,915 |  |
| Trade names |  | 1,720 |  |  | (369) |  |  | 1,351 |  |
| Other |  | 166 |  |  | (105) |  |  | 61 |  |
| Intangible assets subject to amortization |  | 53,539 |  |  | (15,296) |  |  | 38,243 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,879 |  |  | $ | (15,296) |  |  | $ | 40,583 |  |

[0001730168-25-000064:notes:49]
Based on the amount of intangible assets subject to amortization as of May 4, 2025, the expected amortization expense was as follows:

[0001730168-25-000064:notes:50]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 3,997 |  |
| 2026 |  | 7,545 |  |
| 2027 |  | 6,507 |  |
| 2028 |  | 5,417 |  |
| 2029 |  | 4,337 |  |
| Thereafter |  | 6,250 |  |
| Total |  | $ | 34,053 |  |

[0001730168-25-000064:notes:51]
[same as prior period, unchanged from 0001730168-25-000021:notes:48]

[0001730168-25-000064:notes:52]
| Amortizable intangible assets: |  | May 4,2025 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 7 |
| Trade names |  | 12 |
| Other |  | 11 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-25-000064:notes:53]
[same as prior period, unchanged from 0001730168-25-000021:notes:50]

[0001730168-25-000064:notes:54]
[same as prior period, unchanged from 0001730168-25-000021:notes:51]

[0001730168-25-000064:notes:55]
[same as prior period, unchanged from 0001730168-25-000021:notes:52]

[0001730168-25-000064:notes:56]
[same as prior period, unchanged from 0001730168-25-000021:notes:53]

[0001730168-25-000064:notes:57]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 4,965 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,395 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | 51 |  |
| Net income |  | $ | 4,965 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,446 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,707 |  |  | 4,645 |  |  | 4,701 |  |  | 4,579 |  |
| Dilutive effect of equity awards |  | 119 |  |  | 154 |  |  | 130 |  |  | 151 |  |
| Weighted-average shares outstanding - diluted |  | 4,826 |  |  | 4,799 |  |  | 4,831 |  |  | 4,730 |  |

[0001730168-25-000064:notes:58]
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.05 |  |  | $ | 0.46 |  |  | $ | 2.23 |  |  | $ | 0.74 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Net income per share |  | $ | 1.05 |  |  | $ | 0.46 |  |  | $ | 2.23 |  |  | $ | 0.75 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.03 |  |  | $ | 0.44 |  |  | $ | 2.17 |  |  | $ | 0.72 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Net income per share |  | $ | 1.03 |  |  | $ | 0.44 |  |  | $ | 2.17 |  |  | $ | 0.73 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-25-000064:notes:59]
Borrowings

[0001730168-25-000064:notes:60]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| May 2025 Term Loan - fixed rate |  |  |  |  |  |  |
| 4.489% loan due May 2028 |  | 4.55 | % |  | $ | 750 |  |  | $ | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.45 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |

[0001730168-25-000064:notes:61]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,507 |  |  | 69,847 |  |
| Commercial paper |  | 4.69 | % | (b) | 3,900 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 69,407 |  |  | $ | 69,847 |  |

[0001730168-25-000064:notes:62]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,877 |  |  | — |  |
| Short-term finance lease liabilities |  | 4 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,531 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,113) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 61,751 |  |  | $ | 66,295 |  |

[0001730168-25-000064:notes:63]
______________________________

[0001730168-25-000064:notes:64]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

[0001730168-25-000064:notes:65]
(b) Represents the weighted average interest rate on commercial paper outstanding as of May 4, 2025.

[0001730168-25-000064:notes:66]
Fixed-Rate Term Loans

[0001730168-25-000064:notes:67]
On May 2, 2025, we entered into a $750 million three-year fixed-rate term loan (the “May 2025 Term Loan”).

[0001730168-25-000064:notes:68]
Subsequent to the fiscal quarter ended May 4, 2025, we entered into a $1.0 billion three-year term loan at a 4.540% fixed rate and used the proceeds as well as cash on hand to repay $1.9 billion of commercial paper. We also used the May 2025 Term Loan proceeds to repay the $750 million of senior notes that matured on May 15, 2025.

[0001730168-25-000064:notes:69]
Interest on the term loans is due quarterly. We are permitted to prepay the term loans at any time, subject to a specified make-whole premium determined in accordance with the credit agreements governing the respective term loans, plus accrued and unpaid interest.

[0001730168-25-000064:notes:70]
Senior Notes

[0001730168-25-000064:notes:71]
In January 2025, we issued senior unsecured notes for an aggregate principal amount of $3,000 million. Using the net proceeds from these senior notes and commercial paper issued in January 2025 and cash on hand, we repaid the remaining $5,595 million of our unsecured term facility due November 2026 and $2,000 million of our unsecured term facility due November 2028.

[0001730168-25-000064:notes:72]
As a result of these repayments, we wrote off unamortized discount and issuance costs of $65 million during the fiscal quarter ended February 2, 2025, which were included in interest expense in the condensed consolidated statement of operations.

[0001730168-25-000064:notes:73]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

[0001730168-25-000064:notes:74]
2025 Credit Agreement

[0001730168-25-000064:notes:75]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either May 4, 2025 or November 3, 2024.

[0001730168-25-000064:notes:76]
Commercial Paper

[0001730168-25-000064:notes:77]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of May 4, 2025, we had $3.9 billion of commercial paper outstanding with maturities ranging from 22 days to 187 days.

[0001730168-25-000064:notes:78]
Fair Value of Debt

[0001730168-25-000064:notes:79]
As of May 4, 2025, the estimated aggregate fair value of our fixed-rate borrowings was $55,001 million, which was determined using quoted prices from less active markets or other observable inputs. The carrying value of the floating-rate term loans approximates their fair value as they bear interest at the market observable interest rate tied to the Secured Overnight Financing Rate (“SOFR”) that resets periodically. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-25-000064:notes:80]
Future Principal Payments of Debt

[0001730168-25-000064:notes:81]
The future scheduled principal payments of senior notes and term loans as of May 4, 2025 were as follows:

[0001730168-25-000064:notes:82]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 750 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 6,120 |  |
| 2029 |  | 10,655 |  |
| Thereafter |  | 38,693 |  |
| Total |  | $ | 65,507 |  |

[0001730168-25-000064:notes:83]
As of May 4, 2025 and November 3, 2024, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-25-000064:notes:84]
[same as prior period, unchanged from 0001730168-25-000021:notes:76]

[0001730168-25-000064:notes:85]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.590 |  |  | $ | 0.525 |  |  | $ | 1.180 |  |  | $ | 1.050 |  |
| Dividends to common stockholders |  | $ | 2,785 |  |  | $ | 2,443 |  |  | $ | 5,559 |  |  | $ | 4,878 |  |

[0001730168-25-000064:notes:86]
Stock Repurchase Programs

[0001730168-25-000064:notes:87]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025. During the fiscal quarter ended May 4, 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million under this stock repurchase program. Repurchases under this stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000064:notes:88]
In December 2021 and May 2022, our Board of Directors authorized stock repurchase programs to repurchase up to an aggregate of $20 billion of our common stock from time to time prior to December 31, 2023. During the fiscal quarter ended February 4, 2024, we repurchased and retired 67 million shares of our common stock for $7,176 million, and all $20 billion of the aggregate authorized amount was utilized prior to expiration on December 31, 2023.

[0001730168-25-000064:notes:89]
[same as prior period, unchanged from 0001730168-25-000021:notes:78]

[0001730168-25-000064:notes:90]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 50 |  |  | $ | 28 |  |  | $ | 83 |  |  | $ | 56 |  |
| Cost of subscriptions and services |  | 153 |  |  | 142 |  |  | 273 |  |  | 275 |  |
| Research and development |  | 1,169 |  |  | 881 |  |  | 1,991 |  |  | 1,744 |  |
| Selling, general and administrative |  | 399 |  |  | 352 |  |  | 704 |  |  | 900 |  |
| Total stock-based compensation expense (a) |  | $ | 1,771 |  |  | $ | 1,403 |  |  | $ | 3,051 |  |  | $ | 2,975 |  |

[0001730168-25-000064:notes:91]
[same as prior period, unchanged from 0001730168-25-000021:notes:80]

[0001730168-25-000064:notes:92]
(a) Does not include stock-based compensation expense related to discontinued operations recognized during the fiscal quarter and two fiscal quarters ended May 5, 2024, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statements of operations.

[0001730168-25-000064:notes:93]
During the fiscal quarter ended May 4, 2025, we granted two-year time- and market-based RSU awards (the “Two-Year Equity Awards”), in lieu of our annual employee equity awards historically granted in the second quarter of each fiscal year. Each Two-Year Equity Award vests on the same basis as two annual grants with staggered vesting start dates of March 15, 2025 and March 15, 2026 and successive four-year vesting periods. We recognize stock-based compensation expense related to these awards from the grant date through their respective vesting date, ranging from four to five years.

[0001730168-25-000064:notes:94]
As of May 4, 2025, the total unrecognized compensation cost related to unvested stock-based awards was $27,020 million, which is expected to be recognized over the remaining weighted-average service period of 3.8 years.

[0001730168-25-000064:notes:95]
[same as prior period, unchanged from 0001730168-25-000021:notes:83]

[0001730168-25-000064:notes:96]
[same as prior period, unchanged from 0001730168-25-000021:notes:84]

[0001730168-25-000064:notes:97]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 3, 2024 |  | 213 |  |  | $ | 66.44 |  |  |  |  |  |
| Granted |  | 116 |  |  | $ | 187.54 |  |  |  |  |  |
| Vested |  | (50) |  |  | $ | 57.37 |  |  |  |  |  |
| Forfeited |  | (8) |  |  | $ | 85.77 |  |  |  |  |  |
| Balance as of May 4, 2025 |  | 271 |  |  | $ | 119.49 |  |  |  |  |  |

[0001730168-25-000064:notes:98]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended May 4, 2025 was $10,373 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-25-000064:notes:99]
Income Taxes
The provision for income taxes was $120 million and $107 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. The provision for income taxes was primarily due to income before income taxes and the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000064:notes:100]
The benefit from income taxes was $116 million and $48 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The benefit from income taxes was primarily due to excess tax benefits from stock-based awards and the jurisdictional mix of income, partially offset by income tax expense on operations. 
As of May 4, 2025, we had $6,764 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $3,466 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations, and changes in balances related to tax positions to be taken during the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-25-000064:notes:101]
[same as prior period, unchanged from 0001730168-25-000021:notes:89]

[0001730168-25-000064:notes:102]
[same as prior period, unchanged from 0001730168-25-000021:notes:90]

[0001730168-25-000064:notes:103]
[same as prior period, unchanged from 0001730168-25-000021:notes:91]

[0001730168-25-000064:notes:104]
[same as prior period, unchanged from 0001730168-25-000021:notes:92]

[0001730168-25-000064:notes:105]
[same as prior period, unchanged from 0001730168-25-000021:notes:93]

[0001730168-25-000064:notes:106]
[same as prior period, unchanged from 0001730168-25-000021:notes:94]

[0001730168-25-000064:notes:107]
[same as prior period, unchanged from 0001730168-25-000021:notes:95]

[0001730168-25-000064:notes:108]
[same as prior period, unchanged from 0001730168-25-000021:notes:96]

[0001730168-25-000064:notes:109]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 8,408 |  |  | $ | 7,202 |  |  | $ | 16,620 |  |  | $ | 14,592 |  |
| Infrastructure software |  | 6,596 |  |  | 5,285 |  |  | 13,300 |  |  | 9,856 |  |
| Total net revenue |  | $ | 15,004 |  |  | $ | 12,487 |  |  | $ | 29,920 |  |  | $ | 24,448 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,806 |  |  | $ | 3,978 |  |  | $ | 9,512 |  |  | $ | 8,094 |  |
| Infrastructure software |  | 4,987 |  |  | 3,168 |  |  | 10,109 |  |  | 5,883 |  |
| Unallocated expenses |  | (3,964) |  |  | (4,181) |  |  | (7,532) |  |  | (8,929) |  |
| Total operating income |  | $ | 5,829 |  |  | $ | 2,965 |  |  | $ | 12,089 |  |  | $ | 5,048 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-25-000064:notes:110]
Commitments and Contingencies
Commitments

[0001730168-25-000064:notes:111]
The following table summarizes contractual obligations and commitments as of May 4, 2025:

[0001730168-25-000064:notes:112]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 169 |  |  | $ | 359 |  |
| 2026 |  | 102 |  |  | 607 |  |
| 2027 |  | 12 |  |  | 576 |  |
| 2028 |  | 10 |  |  | 504 |  |
| 2029 |  | 3 |  |  | 691 |  |
| Thereafter |  | — |  |  | 1,003 |  |
| Total |  | $ | 296 |  |  | $ | 3,740 |  |

[0001730168-25-000064:notes:113]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-25-000064:notes:114]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-25-000064:notes:115]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 4, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,732 million of unrecognized tax benefits and accrued interest and penalties as of May 4, 2025 have been excluded from the table above.

[0001730168-25-000064:notes:116]
Contingencies

[0001730168-25-000064:notes:117]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-25-000064:notes:118]
Lawsuits Relating to VMware Backlog

[0001730168-25-000064:notes:119]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms and in March 2025 the California Court approved the settlement.

[0001730168-25-000064:notes:120]
Other Matters

[0001730168-25-000064:notes:121]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-25-000064:notes:122]
Contingency Assessment

[0001730168-25-000064:notes:123]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-25-000064:notes:124]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-25-000064:notes:125]
Other Indemnifications

[0001730168-25-000064:notes:126]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-25-000064:notes:127]
Restructuring and Other Charges
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the two fiscal quarters ended May 4, 2025:

[0001730168-25-000064:notes:128]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2024 |  | $ | 119 |  |  | $ | — |  |  | $ | 119 |  |
| Restructuring charges |  | 194 |  |  | 106 |  |  | 300 |  |
| Utilization |  | (272) |  |  | (106) |  |  | (378) |  |
| Balance as of May 4, 2025 |  | $ | 41 |  |  | $ | — |  |  | $ | 41 |  |

[0001730168-25-000064:notes:129]
In connection with the acquisition of VMware, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized restructuring charges related to employee termination costs of $89 million and $194 million during the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, and $303 million and $976 million during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively.
We also recognized impairment charges primarily related to lease assets and property, plant and equipment of $25 million and $106 million during the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively, and $42 million and $81 million during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses.


## us-gaap:SubsequentEventsTextBlock

[0001730168-25-000064:notes:130]
Subsequent Events
Cash Dividends Declared

[0001730168-25-000064:notes:131]
On June 4, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on June 30, 2025 to stockholders of record on June 20, 2025.
