# AVGO 8-K — 0001730168-25-000061 filed 2025-06-05

## item codes, every 8-K on or before 2025-06-11

- 2025-06-05 0001730168-25-000061 — 2.02, 8.01, 9.01
- 2025-04-22 0001730168-25-000037 — 5.07
- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2025-06-11

- none on or before 2025-06-11

## item 2.02 — earnings release, exhibit 99.1

[0001730168-25-000061:8k_2_02:1]
EX-99.1
2
avgo-05042025x8kxex99.htm
EX-99.1

[0001730168-25-000061:8k_2_02:2]
Document

[0001730168-25-000061:8k_2_02:3]
Exhibit 99.1

[0001730168-25-000061:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2025 Financial Results and Quarterly Dividend

[0001730168-25-000061:8k_2_02:5]
•Revenue of $15,004 million for the second quarter, up 20 percent from the prior year period

[0001730168-25-000061:8k_2_02:6]
•GAAP net income of $4,965 million for the second quarter; Non-GAAP net income of $7,787 million for the second quarter

[0001730168-25-000061:8k_2_02:7]
•Adjusted EBITDA of $10,001 million for the second quarter, or 67 percent of revenue

[0001730168-25-000061:8k_2_02:8]
•GAAP diluted EPS of $1.03 for the second quarter; Non-GAAP diluted EPS of $1.58 for the second quarter

[0001730168-25-000061:8k_2_02:9]
•Cash from operations of $6,555 million for the second quarter, less capital expenditures of $144 million, resulted in $6,411 million of free cash flow, or 43 percent of revenue

[0001730168-25-000061:8k_2_02:10]
•Quarterly common stock dividend of $0.59 per share

[0001730168-25-000061:8k_2_02:11]
•Repurchased and eliminated 25.3 million shares for $4,216 million

[0001730168-25-000061:8k_2_02:12]
•Third quarter fiscal year 2025 revenue guidance of approximately $15.8 billion, an increase of 21 percent from the prior year period

[0001730168-25-000061:8k_2_02:13]
•Third quarter fiscal year 2025 Adjusted EBITDA guidance of at least 66 percent of projected revenue (1)

[0001730168-25-000061:8k_2_02:14]
PALO ALTO, Calif. – June 5, 2025 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2025, ended May 4, 2025, provided guidance for its third quarter of fiscal year 2025 and announced its quarterly dividend.

[0001730168-25-000061:8k_2_02:15]
“Broadcom achieved record second quarter revenue on continued momentum in AI semiconductor solutions and VMware. Q2 AI revenue grew 46% year-over-year to over $4.4 billion driven by robust demand for AI networking,” said Hock Tan, President and CEO of Broadcom Inc. “We expect growth in AI semiconductor revenue to accelerate to $5.1 billion in Q3, delivering ten consecutive quarters of growth, as our hyperscale partners continue to invest.”

[0001730168-25-000061:8k_2_02:16]
“Consolidated revenue grew 20% year-over-year to a record $15.0 billion. Adjusted EBITDA increased 35% year-over-year to $10.0 billion reflecting our strong business model,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow was a record $6.4 billion, up 44% year-over-year. Consistent with our commitment to return excess cash to shareholders, we returned $7.0 billion to shareholders in the second quarter through $2.8 billion of cash dividends and $4.2 billion of stock repurchases.”

[0001730168-25-000061:8k_2_02:17]
________________________________

[0001730168-25-000061:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-25-000061:8k_2_02:19]
1

[0001730168-25-000061:8k_2_02:20]
Second Quarter Fiscal Year 2025 Financial Highlights

[0001730168-25-000061:8k_2_02:21]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q2 25 |  | Q2 24 |  | Change |  | Q2 25 |  | Q2 24 |  | Change |
| Net revenue |  | $ | 15,004 |  |  | $ | 12,487 |  |  | +20 | % |  | $ | 15,004 |  |  | $ | 12,487 |  |  | +20 | % |
| Net income |  | $ | 4,965 |  |  | $ | 2,121 |  |  | +134 | % |  | $ | 7,787 |  |  | $ | 5,394 |  |  | +44 | % |
| Earnings per common share - diluted |  | $ | 1.03 |  |  | $ | 0.44 |  |  | +$0.59 |  |  | $ | 1.58 |  |  | $ | 1.10 |  |  | +$0.48 |  |

[0001730168-25-000061:8k_2_02:22]
| (Dollars in millions) |  | Q2 25 |  | Q2 24 |  | Change |  |
| Cash flow from operations |  | $ | 6,555 |  |  | $ | 4,580 |  |  | +$1,975 |  |
| Adjusted EBITDA |  | $ | 10,001 |  |  | $ | 7,429 |  |  | +$2,572 |  |
| Free cash flow |  | $ | 6,411 |  |  | $ | 4,448 |  |  | +$1,963 |  |

[0001730168-25-000061:8k_2_02:23]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q2 25 |  |  |  | Q2 24 |  | Change |  |
| Semiconductor solutions |  | $ | 8,408 |  |  | 56 | % |  |  |  |  |  |  | $ | 7,202 |  |  | 58 | % |  | +17 | % |  |
| Infrastructure software |  | 6,596 |  |  | 44 |  |  |  |  |  |  |  | 5,285 |  |  | 42 |  |  | +25 | % |  |
| Total net revenue |  | $ | 15,004 |  |  | 100 | % |  |  |  |  |  |  | $ | 12,487 |  |  | 100 | % |  |  |  |  |

[0001730168-25-000061:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,472 million, compared to $9,307 million at the end of the prior fiscal quarter.

[0001730168-25-000061:8k_2_02:25]
During the second fiscal quarter, the Company generated $6,555 million in cash from operations and spent $144 million on capital expenditures. The Company spent $4,216 million on stock repurchases and eliminations, consisting of $2,450 million in repurchases of 16.0 million shares and $1,766 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 9.3 million shares withheld).

[0001730168-25-000061:8k_2_02:26]
On March 31, 2025, the Company paid a cash dividend of $0.59 per share, totaling $2,785 million.

[0001730168-25-000061:8k_2_02:27]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-25-000061:8k_2_02:28]
Third Quarter Fiscal Year 2025 Business Outlook

[0001730168-25-000061:8k_2_02:29]
Based on current business trends and conditions, the outlook for the third quarter of fiscal year 2025, ending August 3, 2025, is expected to be as follows:

[0001730168-25-000061:8k_2_02:30]
•Third quarter revenue guidance of approximately $15.8 billion; and

[0001730168-25-000061:8k_2_02:31]
•Third quarter Adjusted EBITDA guidance of at least 66 percent of projected revenue.

[0001730168-25-000061:8k_2_02:32]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000061:8k_2_02:33]
Quarterly Dividends

[0001730168-25-000061:8k_2_02:34]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.59 per share. The dividend is payable on June 30, 2025 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 20, 2025.

[0001730168-25-000061:8k_2_02:35]
Financial Results Conference Call

[0001730168-25-000061:8k_2_02:36]
Broadcom Inc. will host a conference call to review its financial results for the second quarter of fiscal year 2025 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-25-000061:8k_2_02:37]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-25-000061:8k_2_02:38]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-25-000061:8k_2_02:39]
Non-GAAP Financial Measures

[0001730168-25-000061:8k_2_02:40]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-25-000061:8k_2_02:41]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-25-000061:8k_2_02:42]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-25-000061:8k_2_02:43]
3

[0001730168-25-000061:8k_2_02:44]
About Broadcom

[0001730168-25-000061:8k_2_02:45]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-25-000061:8k_2_02:46]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-25-000061:8k_2_02:47]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; our acquisition of VMware, Inc., including our ability to realize the expected benefits; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and other channel partners of our products; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cybersecurity threats and a breach of security systems; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; cyclicality in the semiconductor industry or in our target markets; our ability to make successful investments in research and development; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to improve our manufacturing capacity and quality; involvement in legal proceedings; ability of our software products to manage and secure IT infrastructures and environments; demand for our data center virtualization products and customer acceptance of our products, services and business strategy; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our products; sales to government customers; our ability to manage products and

[0001730168-25-000061:8k_2_02:48]
4

[0001730168-25-000061:8k_2_02:49]
services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our stock repurchase program; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000061:8k_2_02:50]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000061:8k_2_02:51]
Contact:

[0001730168-25-000061:8k_2_02:52]
Ji Yoo

[0001730168-25-000061:8k_2_02:53]
Broadcom Inc.

[0001730168-25-000061:8k_2_02:54]
Investor Relations

[0001730168-25-000061:8k_2_02:55]
650-427-6000

[0001730168-25-000061:8k_2_02:56]
investor.relations@broadcom.com

[0001730168-25-000061:8k_2_02:57]
(AVGO-Q)

[0001730168-25-000061:8k_2_02:58]
5

[0001730168-25-000061:8k_2_02:59]
BROADCOM INC.

[0001730168-25-000061:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-25-000061:8k_2_02:61]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-25-000061:8k_2_02:62]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | February 2,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
| Net revenue |  | $ | 15,004 |  |  | $ | 14,916 |  |  | $ | 12,487 |  |  | $ | 29,920 |  |  | $ | 24,448 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,296 |  |  | 3,273 |  |  | 3,142 |  |  | 6,569 |  |  | 6,256 |  |
| Amortization of acquisition-related intangible assets |  | 1,483 |  |  | 1,484 |  |  | 1,516 |  |  | 2,967 |  |  | 2,896 |  |
| Restructuring charges |  | 28 |  |  | 14 |  |  | 53 |  |  | 42 |  |  | 145 |  |
| Total cost of revenue |  | 4,807 |  |  | 4,771 |  |  | 4,711 |  |  | 9,578 |  |  | 9,297 |  |
| Gross margin |  | 10,197 |  |  | 10,145 |  |  | 7,776 |  |  | 20,342 |  |  | 15,151 |  |
| Research and development |  | 2,693 |  |  | 2,253 |  |  | 2,415 |  |  | 4,946 |  |  | 4,723 |  |
| Selling, general and administrative |  | 1,083 |  |  | 949 |  |  | 1,277 |  |  | 2,032 |  |  | 2,849 |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 511 |  |  | 827 |  |  | 1,017 |  |  | 1,619 |  |
| Restructuring and other charges |  | 86 |  |  | 172 |  |  | 292 |  |  | 258 |  |  | 912 |  |
| Total operating expenses |  | 4,368 |  |  | 3,885 |  |  | 4,811 |  |  | 8,253 |  |  | 10,103 |  |
| Operating income |  | 5,829 |  |  | 6,260 |  |  | 2,965 |  |  | 12,089 |  |  | 5,048 |  |
| Interest expense |  | (769) |  |  | (873) |  |  | (1,047) |  |  | (1,642) |  |  | (1,973) |  |
| Other income, net |  | 25 |  |  | 103 |  |  | 87 |  |  | 128 |  |  | 272 |  |
| Income from continuing operations before income taxes |  | 5,085 |  |  | 5,490 |  |  | 2,005 |  |  | 10,575 |  |  | 3,347 |  |
| Provision for (benefit from) income taxes |  | 120 |  |  | (13) |  |  | (116) |  |  | 107 |  |  | (48) |  |
| Income from continuing operations |  | 4,965 |  |  | 5,503 |  |  | 2,121 |  |  | 10,468 |  |  | 3,395 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | 51 |  |
| Net income |  | $ | 4,965 |  |  | $ | 5,503 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,446 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.05 |  |  | $ | 1.17 |  |  | $ | 0.46 |  |  | $ | 2.23 |  |  | $ | 0.74 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Net income per share |  | $ | 1.05 |  |  | $ | 1.17 |  |  | $ | 0.46 |  |  | $ | 2.23 |  |  | $ | 0.75 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.03 |  |  | $ | 1.14 |  |  | $ | 0.44 |  |  | $ | 2.17 |  |  | $ | 0.72 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Net income per share |  | $ | 1.03 |  |  | $ | 1.14 |  |  | $ | 0.44 |  |  | $ | 2.17 |  |  | $ | 0.73 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,707 |  |  | 4,695 |  |  | 4,645 |  |  | 4,701 |  |  | 4,579 |  |
| Diluted |  | 4,826 |  |  | 4,836 |  |  | 4,799 |  |  | 4,831 |  |  | 4,730 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 203 |  |  | $ | 153 |  |  | $ | 170 |  |  | $ | 356 |  |  | $ | 331 |  |
| Research and development |  | 1,169 |  |  | 822 |  |  | 881 |  |  | 1,991 |  |  | 1,744 |  |
| Selling, general and administrative |  | 399 |  |  | 305 |  |  | 352 |  |  | 704 |  |  | 900 |  |
| Total stock-based compensation expense |  | $ | 1,771 |  |  | $ | 1,280 |  |  | $ | 1,403 |  |  | $ | 3,051 |  |  | $ | 2,975 |  |

[0001730168-25-000061:8k_2_02:63]
BROADCOM INC.

[0001730168-25-000061:8k_2_02:64]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-25-000061:8k_2_02:65]
(IN MILLIONS)

[0001730168-25-000061:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | February 2,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
| Gross margin on GAAP basis |  | $ | 10,197 |  |  | $ | 10,145 |  |  | $ | 7,776 |  |  | $ | 20,342 |  |  | $ | 15,151 |  |
| Amortization of acquisition-related intangible assets |  | 1,483 |  |  | 1,484 |  |  | 1,516 |  |  | 2,967 |  |  | 2,896 |  |
| Stock-based compensation expense |  | 203 |  |  | 153 |  |  | 170 |  |  | 356 |  |  | 331 |  |
| Restructuring charges |  | 28 |  |  | 14 |  |  | 53 |  |  | 42 |  |  | 145 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 9 |  |
| Gross margin on non-GAAP basis |  | $ | 11,911 |  |  | $ | 11,796 |  |  | $ | 9,518 |  |  | $ | 23,707 |  |  | $ | 18,532 |  |
| Research and development on GAAP basis |  | $ | 2,693 |  |  | $ | 2,253 |  |  | $ | 2,415 |  |  | $ | 4,946 |  |  | $ | 4,723 |  |
| Stock-based compensation expense |  | 1,169 |  |  | 822 |  |  | 881 |  |  | 1,991 |  |  | 1,744 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Research and development on non-GAAP basis |  | $ | 1,524 |  |  | $ | 1,431 |  |  | $ | 1,534 |  |  | $ | 2,955 |  |  | $ | 2,978 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,083 |  |  | $ | 949 |  |  | $ | 1,277 |  |  | $ | 2,032 |  |  | $ | 2,849 |  |
| Stock-based compensation expense |  | 399 |  |  | 305 |  |  | 352 |  |  | 704 |  |  | 900 |  |
| Acquisition-related costs |  | 90 |  |  | 107 |  |  | 87 |  |  | 197 |  |  | 372 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 594 |  |  | $ | 537 |  |  | $ | 838 |  |  | $ | 1,131 |  |  | $ | 1,577 |  |
| Total operating expenses on GAAP basis |  | $ | 4,368 |  |  | $ | 3,885 |  |  | $ | 4,811 |  |  | $ | 8,253 |  |  | $ | 10,103 |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 511 |  |  | 827 |  |  | 1,017 |  |  | 1,619 |  |
| Stock-based compensation expense |  | 1,568 |  |  | 1,127 |  |  | 1,233 |  |  | 2,695 |  |  | 2,644 |  |
| Restructuring and other charges |  | 86 |  |  | 172 |  |  | 292 |  |  | 258 |  |  | 912 |  |
| Acquisition-related costs |  | 90 |  |  | 107 |  |  | 87 |  |  | 197 |  |  | 373 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,118 |  |  | $ | 1,968 |  |  | $ | 2,372 |  |  | $ | 4,086 |  |  | $ | 4,555 |  |
| Operating income on GAAP basis |  | $ | 5,829 |  |  | $ | 6,260 |  |  | $ | 2,965 |  |  | $ | 12,089 |  |  | $ | 5,048 |  |
| Amortization of acquisition-related intangible assets |  | 1,989 |  |  | 1,995 |  |  | 2,343 |  |  | 3,984 |  |  | 4,515 |  |
| Stock-based compensation expense |  | 1,771 |  |  | 1,280 |  |  | 1,403 |  |  | 3,051 |  |  | 2,975 |  |
| Restructuring and other charges |  | 114 |  |  | 186 |  |  | 345 |  |  | 300 |  |  | 1,057 |  |
| Acquisition-related costs |  | 90 |  |  | 107 |  |  | 90 |  |  | 197 |  |  | 382 |  |
| Operating income on non-GAAP basis |  | $ | 9,793 |  |  | $ | 9,828 |  |  | $ | 7,146 |  |  | $ | 19,621 |  |  | $ | 13,977 |  |
| Interest expense on GAAP basis |  | $ | (769) |  |  | $ | (873) |  |  | $ | (1,047) |  |  | $ | (1,642) |  |  | $ | (1,973) |  |
| Loss on debt extinguishment |  | — |  |  | 65 |  |  | 22 |  |  | 65 |  |  | 22 |  |
| Interest expense on non-GAAP basis |  | $ | (769) |  |  | $ | (808) |  |  | $ | (1,025) |  |  | $ | (1,577) |  |  | $ | (1,951) |  |
| Other income, net on GAAP basis |  | $ | 25 |  |  | $ | 103 |  |  | $ | 87 |  |  | $ | 128 |  |  | $ | 272 |  |
| (Gains) losses on investments |  | 9 |  |  | 4 |  |  | 9 |  |  | 13 |  |  | (24) |  |
| Other |  | (3) |  |  | (31) |  |  | — |  |  | (34) |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 31 |  |  | $ | 76 |  |  | $ | 96 |  |  | $ | 107 |  |  | $ | 248 |  |

[0001730168-25-000061:8k_2_02:67]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 4,2025 |  | February 2,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 120 |  |  | $ | (13) |  |  | $ | (116) |  |  | $ | 107 |  |  | $ | (48) |  |
| Non-GAAP tax reconciling adjustments |  | 1,148 |  |  | 1,286 |  |  | 939 |  |  | 2,434 |  |  | 1,674 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 1,268 |  |  | $ | 1,273 |  |  | $ | 823 |  |  | $ | 2,541 |  |  | $ | 1,626 |  |
| Net income on GAAP basis |  | $ | 4,965 |  |  | $ | 5,503 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,446 |  |
| Amortization of acquisition-related intangible assets |  | 1,989 |  |  | 1,995 |  |  | 2,343 |  |  | 3,984 |  |  | 4,515 |  |
| Stock-based compensation expense |  | 1,771 |  |  | 1,280 |  |  | 1,403 |  |  | 3,051 |  |  | 2,975 |  |
| Restructuring and other charges |  | 114 |  |  | 186 |  |  | 345 |  |  | 300 |  |  | 1,057 |  |
| Acquisition-related costs |  | 90 |  |  | 107 |  |  | 90 |  |  | 197 |  |  | 382 |  |
| Loss on debt extinguishment |  | — |  |  | 65 |  |  | 22 |  |  | 65 |  |  | 22 |  |
| (Gains) losses on investments |  | 9 |  |  | 4 |  |  | 9 |  |  | 13 |  |  | (24) |  |
| Other |  | (3) |  |  | (31) |  |  | — |  |  | (34) |  |  | — |  |
| Non-GAAP tax reconciling adjustments |  | (1,148) |  |  | (1,286) |  |  | (939) |  |  | (2,434) |  |  | (1,674) |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | (51) |  |
| Net income on non-GAAP basis |  | $ | 7,787 |  |  | $ | 7,823 |  |  | $ | 5,394 |  |  | $ | 15,610 |  |  | $ | 10,648 |  |
| Net income on GAAP basis |  | $ | 4,965 |  |  | $ | 5,503 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,446 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,989 |  |  | 1,995 |  |  | 2,343 |  |  | 3,984 |  |  | 4,515 |  |
| Stock-based compensation expense |  | 1,771 |  |  | 1,280 |  |  | 1,403 |  |  | 3,051 |  |  | 2,975 |  |
| Restructuring and other charges |  | 114 |  |  | 186 |  |  | 345 |  |  | 300 |  |  | 1,057 |  |
| Acquisition-related costs |  | 90 |  |  | 107 |  |  | 90 |  |  | 197 |  |  | 382 |  |
| Loss on debt extinguishment |  | — |  |  | 65 |  |  | 22 |  |  | 65 |  |  | 22 |  |
| (Gains) losses on investments |  | 9 |  |  | 4 |  |  | 9 |  |  | 13 |  |  | (24) |  |
| Other |  | (3) |  |  | (31) |  |  | — |  |  | (34) |  |  | — |  |
| Non-GAAP tax reconciling adjustments |  | (1,148) |  |  | (1,286) |  |  | (939) |  |  | (2,434) |  |  | (1,674) |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | (51) |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 769 |  |  | 808 |  |  | 1,025 |  |  | 1,577 |  |  | 1,951 |  |
| Provision for income taxes on non-GAAP basis |  | 1,268 |  |  | 1,273 |  |  | 823 |  |  | 2,541 |  |  | 1,626 |  |
| Depreciation |  | 142 |  |  | 142 |  |  | 149 |  |  | 284 |  |  | 288 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 35 |  |  | 37 |  |  | 38 |  |  | 72 |  |  | 72 |  |
| Adjusted EBITDA |  | $ | 10,001 |  |  | $ | 10,083 |  |  | $ | 7,429 |  |  | $ | 20,084 |  |  | $ | 14,585 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,826 |  |  | 4,836 |  |  | 4,799 |  |  | 4,831 |  |  | 4,730 |  |
| Non-GAAP adjustment (1) |  | 111 |  |  | 59 |  |  | 117 |  |  | 85 |  |  | 115 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,937 |  |  | 4,895 |  |  | 4,916 |  |  | 4,916 |  |  | 4,845 |  |
| Net cash provided by operating activities |  | $ | 6,555 |  |  | $ | 6,113 |  |  | $ | 4,580 |  |  | $ | 12,668 |  |  | $ | 9,395 |  |
| Purchases of property, plant and equipment |  | (144) |  |  | (100) |  |  | (132) |  |  | (244) |  |  | (254) |  |
| Free cash flow |  | $ | 6,411 |  |  | $ | 6,013 |  |  | $ | 4,448 |  |  | $ | 12,424 |  |  | $ | 9,141 |  |

[0001730168-25-000061:8k_2_02:68]
|  |  | Fiscal Quarter Ending |
|  |  | August 3, |
| Expected average diluted share count (2): |  | 2025 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,842 |  |
| Non-GAAP adjustment (1) |  | 129 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,971 |  |

[0001730168-25-000061:8k_2_02:69]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-25-000061:8k_2_02:70]
BROADCOM INC.

[0001730168-25-000061:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-25-000061:8k_2_02:72]
(IN MILLIONS)

[0001730168-25-000061:8k_2_02:73]
|  |  | May 4,2025 |  | November 3,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,472 |  |  | $ | 9,348 |  |
| Trade accounts receivable, net |  | 5,563 |  |  | 4,416 |  |
| Inventory |  | 2,017 |  |  | 1,760 |  |
| Other current assets |  | 5,129 |  |  | 4,071 |  |
| Total current assets |  | 22,181 |  |  | 19,595 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,462 |  |  | 2,521 |  |
| Goodwill |  | 97,801 |  |  | 97,873 |  |
| Intangible assets, net |  | 36,393 |  |  | 40,583 |  |
| Other long-term assets |  | 5,793 |  |  | 5,073 |  |
| Total assets |  | $ | 164,630 |  |  | $ | 165,645 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,297 |  |  | $ | 1,662 |  |
| Employee compensation and benefits |  | 1,266 |  |  | 1,971 |  |
| Short-term debt |  | 5,531 |  |  | 1,271 |  |
| Other current liabilities |  | 12,503 |  |  | 11,793 |  |
| Total current liabilities |  | 20,597 |  |  | 16,697 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 61,751 |  |  | 66,295 |  |
| Other long-term liabilities |  | 12,696 |  |  | 14,975 |  |
| Total liabilities |  | 95,044 |  |  | 97,967 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 66,689 |  |  | 67,466 |  |
| Retained earnings |  | 2,686 |  |  | — |  |
| Accumulated other comprehensive income |  | 206 |  |  | 207 |  |
| Total stockholders' equity |  | 69,586 |  |  | 67,678 |  |
| Total liabilities and equity |  | $ | 164,630 |  |  | $ | 165,645 |  |

[0001730168-25-000061:8k_2_02:74]
| BROADCOM INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |
| (IN MILLIONS) |  |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |  |
|  |  | May 4,2025 |  | February 2,2025 |  | May 5,2024 |  | May 4,2025 |  | May 5,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,965 |  |  | $ | 5,503 |  |  | $ | 2,121 |  |  | $ | 10,468 |  |  | $ | 3,446 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,024 |  |  | 2,032 |  |  | 2,381 |  |  | 4,056 |  |  | 4,587 |  |  |
| Depreciation |  | 142 |  |  | 142 |  |  | 149 |  |  | 284 |  |  | 288 |  |  |
| Stock-based compensation |  | 1,771 |  |  | 1,280 |  |  | 1,457 |  |  | 3,051 |  |  | 3,039 |  |  |
| Deferred taxes and other non-cash taxes |  | (571) |  |  | (696) |  |  | (511) |  |  | (1,267) |  |  | (805) |  |  |
| Loss on debt extinguishment |  | — |  |  | 65 |  |  | — |  |  | 65 |  |  | — |  |  |
| Non-cash interest expense |  | 94 |  |  | 97 |  |  | 119 |  |  | 191 |  |  | 221 |  |  |
| Other |  | 40 |  |  | 41 |  |  | 92 |  |  | 81 |  |  | 130 |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (590) |  |  | (539) |  |  | (513) |  |  | (1,129) |  |  | 1,243 |  |  |
| Inventory |  | (109) |  |  | (148) |  |  | 82 |  |  | (257) |  |  | 68 |  |  |
| Accounts payable |  | (613) |  |  | 241 |  |  | (93) |  |  | (372) |  |  | (167) |  |  |
| Employee compensation and benefits |  | 287 |  |  | (908) |  |  | 251 |  |  | (621) |  |  | (409) |  |  |
| Other current assets and current liabilities |  | (55) |  |  | 26 |  |  | (386) |  |  | (29) |  |  | (2,568) |  |  |
| Other long-term assets and long-term liabilities |  | (830) |  |  | (1,023) |  |  | (569) |  |  | (1,853) |  |  | 322 |  |  |
| Net cash provided by operating activities |  | 6,555 |  |  | 6,113 |  |  | 4,580 |  |  | 12,668 |  |  | 9,395 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (560) |  |  | — |  |  | (25,976) |  |  |
| Purchases of property, plant and equipment |  | (144) |  |  | (100) |  |  | (132) |  |  | (244) |  |  | (254) |  |  |
| Purchases of investments |  | (57) |  |  | (105) |  |  | (59) |  |  | (162) |  |  | (72) |  |  |
| Sales of investments |  | 78 |  |  | 18 |  |  | 42 |  |  | 96 |  |  | 131 |  |  |
| Other |  | (10) |  |  | 13 |  |  | 3 |  |  | 3 |  |  | (12) |  |  |
| Net cash used in investing activities |  | (133) |  |  | (174) |  |  | (706) |  |  | (307) |  |  | (26,183) |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 749 |  |  | 2,986 |  |  | — |  |  | 3,735 |  |  | 30,010 |  |  |
| Payments on debt obligations |  | — |  |  | (8,090) |  |  | (2,000) |  |  | (8,090) |  |  | (2,934) |  |  |
| Proceeds from (repayments of) commercial paper, net |  | (119) |  |  | 3,980 |  |  | — |  |  | 3,861 |  |  | — |  |  |
| Payments of dividends |  | (2,785) |  |  | (2,774) |  |  | (2,443) |  |  | (5,559) |  |  | (4,878) |  |  |
| Repurchases of common stock - repurchase program |  | (2,450) |  |  | — |  |  | — |  |  | (2,450) |  |  | (7,176) |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (1,766) |  |  | (2,036) |  |  | (1,548) |  |  | (3,802) |  |  | (2,662) |  |  |
| Issuance of common stock |  | 118 |  |  | — |  |  | 64 |  |  | 118 |  |  | 64 |  |  |
| Other |  | (4) |  |  | (46) |  |  | (2) |  |  | (50) |  |  | (16) |  |  |
| Net cash provided by (used in) financing activities |  | (6,257) |  |  | (5,980) |  |  | (5,929) |  |  | (12,237) |  |  | 12,408 |  |  |
| Net change in cash and cash equivalents |  | 165 |  |  | (41) |  |  | (2,055) |  |  | 124 |  |  | (4,380) |  |  |
| Cash and cash equivalents at beginning of period |  | 9,307 |  |  | 9,348 |  |  | 11,864 |  |  | 9,348 |  |  | 14,189 |  |  |
| Cash and cash equivalents at end of period |  | $ | 9,472 |  |  | $ | 9,307 |  |  | $ | 9,809 |  |  | $ | 9,472 |  |  | $ | 9,809 |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 700 |  |  | $ | 671 |  |  | $ | 946 |  |  | $ | 1,371 |  |  | $ | 1,696 |  |  |
| Cash paid for income taxes |  | $ | 608 |  |  | $ | 404 |  |  | $ | 834 |  |  | $ | 1,012 |  |  | $ | 1,738 |  |  |
