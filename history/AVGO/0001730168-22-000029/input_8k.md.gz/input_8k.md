# AVGO 8-K — 0001730168-22-000015 filed 2022-03-03

## item codes, every 8-K on or before 2022-03-10

- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2022-03-10

- none on or before 2022-03-10

## item 2.02 — earnings release, exhibit 99.1

[0001730168-22-000015:8k_2_02:1]
EX-99.1
2
avgo-01302022x8kxex99.htm
EX-99.1

[0001730168-22-000015:8k_2_02:2]
Document

[0001730168-22-000015:8k_2_02:3]
Exhibit 99.1

[0001730168-22-000015:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2022 Financial Results and Quarterly Dividends

[0001730168-22-000015:8k_2_02:5]
•Revenue of $7,706 million for the first quarter, up 16 percent from the prior year period

[0001730168-22-000015:8k_2_02:6]
•GAAP net income of $2,472 million for the first quarter; Adjusted EBITDA of $4,818 million for the first quarter

[0001730168-22-000015:8k_2_02:7]
•GAAP diluted EPS of $5.59 for the first quarter; Non-GAAP diluted EPS of $8.39 for the first quarter

[0001730168-22-000015:8k_2_02:8]
•$3,385 million of free cash flow from operations for the first quarter, defined as cash from operations of $3,486 million less capital expenditures of $101 million

[0001730168-22-000015:8k_2_02:9]
•Quarterly common stock dividend of $4.10 per share

[0001730168-22-000015:8k_2_02:10]
•Repurchased and eliminated 5 million shares for $3,099 million

[0001730168-22-000015:8k_2_02:11]
•Second quarter revenue guidance of approximately $7.9 billion, an expected increase of 20 percent from the prior year period

[0001730168-22-000015:8k_2_02:12]
•Second quarter Adjusted EBITDA guidance of approximately 62.5 percent of projected revenue (1)

[0001730168-22-000015:8k_2_02:13]
SAN JOSE, Calif. – March 3, 2022 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2022, ended January 30, 2022, provided guidance for the second quarter of its fiscal year 2022 and announced its quarterly dividends.

[0001730168-22-000015:8k_2_02:14]
“Broadcom’s record first quarter results were driven by strong enterprise demand, and continued investments in next generation technology by hyperscale and service providers,” said Hock Tan, President and CEO of Broadcom Inc. “Our second quarter outlook projects year-over-year growth to accelerate.”

[0001730168-22-000015:8k_2_02:15]
“Consolidated revenue grew 16% year-over-year to a record $7.7 billion and operating profit increased 23%,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $3.4 billion in free cash flow and are expecting free cash flow to remain strong in the second quarter. Consistent with our commitment to return excess cash to shareholders, we returned $4.5 billion to shareholders in the quarter including $1.8 billion of cash dividends and $2.7 billion of share repurchases.”

[0001730168-22-000015:8k_2_02:16]
First Quarter Fiscal Year 2022 Financial Highlights

[0001730168-22-000015:8k_2_02:17]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 22 |  | Q1 21 |  | Change |  | Q1 22 |  | Q1 21 |  | Change |
| Net revenue |  | $ | 7,706 |  |  | $ | 6,655 |  |  | +16 | % |  | $ | 7,706 |  |  | $ | 6,655 |  |  | +16 | % |
| Net income |  | $ | 2,472 |  |  | $ | 1,378 |  |  | +$1,094 |  |  | $ | 3,741 |  |  | $ | 2,973 |  |  | +$768 |  |
| Earnings per common share - diluted |  | $ | 5.59 |  |  | $ | 3.05 |  |  | +$2.54 |  |  | $ | 8.39 |  |  | $ | 6.61 |  |  | +$1.78 |  |

[0001730168-22-000015:8k_2_02:18]
________________________________

[0001730168-22-000015:8k_2_02:19]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-22-000015:8k_2_02:20]
1

[0001730168-22-000015:8k_2_02:21]
| (Dollars in millions) |  | Q1 22 |  | Q1 21 |  | Change |  |
| Cash flow from operations |  | $ | 3,486 |  |  | $ | 3,113 |  |  | +$373 |  |
| Adjusted EBITDA |  | $ | 4,818 |  |  | $ | 3,941 |  |  | +$877 |  |
| Free cash flow |  | $ | 3,385 |  |  | $ | 2,999 |  |  | +$386 |  |

[0001730168-22-000015:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 22 |  |  |  | Q1 21 |  | Change |  |
| Semiconductor solutions |  | $ | 5,873 |  |  | 76 | % |  |  |  |  |  |  | $ | 4,908 |  |  | 74 | % |  | +20 | % |  |
| Infrastructure software |  | 1,833 |  |  | 24 |  |  |  |  |  |  |  | 1,747 |  |  | 26 |  |  | +5 | % |  |
| Total net revenue |  | $ | 7,706 |  |  | 100 | % |  |  |  |  |  |  | $ | 6,655 |  |  | 100 | % |  |  |  |  |

[0001730168-22-000015:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $10,219 million, compared to $12,163 million at the end of the prior quarter.

[0001730168-22-000015:8k_2_02:24]
During the first fiscal quarter, the Company generated $3,486 million in cash from operations and spent $101 million on capital expenditures. The Company spent $3,099 million on share repurchases and eliminations, consisting of $2,724 million in repurchases of 4.4 million shares and $375 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 0.6 million shares withheld).

[0001730168-22-000015:8k_2_02:25]
On December 31, 2021, the Company paid a cash dividend of $4.10 per share of common stock, totaling $1,689 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-22-000015:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-22-000015:8k_2_02:27]
Second Quarter Fiscal Year 2022 Business Outlook

[0001730168-22-000015:8k_2_02:28]
Based on current business trends and conditions, the outlook for the second quarter of fiscal year 2022, ending May 1, 2022, is expected to be as follows:

[0001730168-22-000015:8k_2_02:29]
•Second quarter revenue guidance of approximately $7.9 billion; and

[0001730168-22-000015:8k_2_02:30]
•Second quarter Adjusted EBITDA guidance of approximately 62.5 percent of projected revenue.

[0001730168-22-000015:8k_2_02:31]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000015:8k_2_02:32]
2

[0001730168-22-000015:8k_2_02:33]
Quarterly Dividends

[0001730168-22-000015:8k_2_02:34]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $4.10 per share. The common stock dividend is payable on March 31, 2022 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 22, 2022.

[0001730168-22-000015:8k_2_02:35]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on March 31, 2022 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 15, 2022.

[0001730168-22-000015:8k_2_02:36]
Financial Results Conference Call

[0001730168-22-000015:8k_2_02:37]
Broadcom Inc. will host a conference call to review its financial results for the first quarter fiscal year 2022 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-22-000015:8k_2_02:38]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-22-000015:8k_2_02:39]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at: http://www.directeventreg.com/registration/event/7657369. Upon registering, you will be emailed a dial-in number, direct passcode and unique PIN.

[0001730168-22-000015:8k_2_02:40]
Replay: A telephone playback of the conference call can be accessed for one week following the call by dialing: (855) 859-2056; International + 1 (404) 537-3406; Passcode: 7657369; or through the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-22-000015:8k_2_02:41]
Non-GAAP Financial Measures

[0001730168-22-000015:8k_2_02:42]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-22-000015:8k_2_02:43]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to

[0001730168-22-000015:8k_2_02:44]
3

[0001730168-22-000015:8k_2_02:45]
the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-22-000015:8k_2_02:46]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-22-000015:8k_2_02:47]
About Broadcom Inc.

[0001730168-22-000015:8k_2_02:48]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-22-000015:8k_2_02:49]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-22-000015:8k_2_02:50]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has disrupted, and will likely continue to disrupt, normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase program; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory

[0001730168-22-000015:8k_2_02:51]
4

[0001730168-22-000015:8k_2_02:52]
approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-22-000015:8k_2_02:53]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000015:8k_2_02:54]
Contact:

[0001730168-22-000015:8k_2_02:55]
Ji Yoo

[0001730168-22-000015:8k_2_02:56]
Broadcom Inc.

[0001730168-22-000015:8k_2_02:57]
Investor Relations

[0001730168-22-000015:8k_2_02:58]
408-433-8000

[0001730168-22-000015:8k_2_02:59]
investor.relations@broadcom.com

[0001730168-22-000015:8k_2_02:60]
(AVGO-Q)

[0001730168-22-000015:8k_2_02:61]
5

[0001730168-22-000015:8k_2_02:62]
BROADCOM INC.

[0001730168-22-000015:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-22-000015:8k_2_02:64]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-22-000015:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | October 31,2021 |  | January 31,2021 |  |  |  |  |
| Net revenue |  | $ | 7,706 |  |  | $ | 7,407 |  |  | $ | 6,655 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,925 |  |  | 1,920 |  |  | 1,814 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 730 |  |  | 849 |  |  | 874 |  |  |  |  |  |
| Restructuring charges |  | 2 |  |  | — |  |  | 15 |  |  |  |  |  |
| Total cost of revenue |  | 2,657 |  |  | 2,769 |  |  | 2,703 |  |  |  |  |  |
| Gross margin |  | 5,049 |  |  | 4,638 |  |  | 3,952 |  |  |  |  |  |
| Research and development |  | 1,206 |  |  | 1,200 |  |  | 1,211 |  |  |  |  |  |
| Selling, general and administrative |  | 321 |  |  | 337 |  |  | 339 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 397 |  |  | 494 |  |  | 494 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 17 |  |  | 26 |  |  | 71 |  |  |  |  |  |
| Total operating expenses |  | 1,941 |  |  | 2,057 |  |  | 2,115 |  |  |  |  |  |
| Operating income |  | 3,108 |  |  | 2,581 |  |  | 1,837 |  |  |  |  |  |
| Interest expense |  | (407) |  |  | (434) |  |  | (570) |  |  |  |  |  |
| Other income (expense), net |  | (14) |  |  | 22 |  |  | 117 |  |  |  |  |  |
| Income before income taxes |  | 2,687 |  |  | 2,169 |  |  | 1,384 |  |  |  |  |  |
| Provision for income taxes |  | 215 |  |  | 180 |  |  | 6 |  |  |  |  |  |
| Net income |  | 2,472 |  |  | 1,989 |  |  | 1,378 |  |  |  |  |  |
| Dividends on preferred stock |  | (74) |  |  | (75) |  |  | (74) |  |  |  |  |  |
| Net income attributable to common stock |  | $ | 2,398 |  |  | $ | 1,914 |  |  | $ | 1,304 |  |  |  |  |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.82 |  |  | $ | 4.65 |  |  | $ | 3.20 |  |  |  |  |  |
| Diluted (1) |  | $ | 5.59 |  |  | $ | 4.45 |  |  | $ | 3.05 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 412 |  |  | 412 |  |  | 407 |  |  |  |  |  |
| Diluted (1) |  | 429 |  |  | 430 |  |  | 428 |  |  |  |  |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 36 |  |  | $ | 37 |  |  | $ | 32 |  |  |  |  |  |
| Research and development |  | 268 |  |  | 279 |  |  | 328 |  |  |  |  |  |
| Selling, general and administrative |  | 83 |  |  | 98 |  |  | 84 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 387 |  |  | $ | 414 |  |  | $ | 444 |  |  |  |  |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-22-000015:8k_2_02:66]
BROADCOM INC.

[0001730168-22-000015:8k_2_02:67]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-22-000015:8k_2_02:68]
(IN MILLIONS)

[0001730168-22-000015:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | October 31,2021 |  | January 31,2021 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 5,049 |  |  | $ | 4,638 |  |  | $ | 3,952 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 730 |  |  | 849 |  |  | 874 |  |  |  |  |  |
| Stock-based compensation expense |  | 36 |  |  | 37 |  |  | 32 |  |  |  |  |  |
| Restructuring charges |  | 2 |  |  | — |  |  | 15 |  |  |  |  |  |
| Acquisition-related costs |  | 4 |  |  | 3 |  |  | 3 |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 5,821 |  |  | $ | 5,527 |  |  | $ | 4,876 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 1,206 |  |  | $ | 1,200 |  |  | $ | 1,211 |  |  |  |  |  |
| Stock-based compensation expense |  | 268 |  |  | 279 |  |  | 328 |  |  |  |  |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 1 |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 938 |  |  | $ | 921 |  |  | $ | 882 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 321 |  |  | $ | 337 |  |  | $ | 339 |  |  |  |  |  |
| Stock-based compensation expense |  | 83 |  |  | 98 |  |  | 84 |  |  |  |  |  |
| Acquisition-related costs |  | 11 |  |  | 17 |  |  | 41 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 227 |  |  | $ | 222 |  |  | $ | 214 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 1,941 |  |  | $ | 2,057 |  |  | $ | 2,115 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 397 |  |  | 494 |  |  | 494 |  |  |  |  |  |
| Stock-based compensation expense |  | 351 |  |  | 377 |  |  | 412 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 17 |  |  | 26 |  |  | 71 |  |  |  |  |  |
| Acquisition-related costs |  | 11 |  |  | 17 |  |  | 42 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,165 |  |  | $ | 1,143 |  |  | $ | 1,096 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 3,108 |  |  | $ | 2,581 |  |  | $ | 1,837 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,127 |  |  | 1,343 |  |  | 1,368 |  |  |  |  |  |
| Stock-based compensation expense |  | 387 |  |  | 414 |  |  | 444 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 19 |  |  | 26 |  |  | 86 |  |  |  |  |  |
| Acquisition-related costs |  | 15 |  |  | 20 |  |  | 45 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 4,656 |  |  | $ | 4,384 |  |  | $ | 3,780 |  |  |  |  |  |
| Interest expense on GAAP basis |  | $ | (407) |  |  | $ | (434) |  |  | $ | (570) |  |  |  |  |  |
| Loss on debt extinguishment |  | — |  |  | 23 |  |  | 172 |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | $ | (407) |  |  | $ | (411) |  |  | $ | (398) |  |  |  |  |  |
| Other income (expense), net on GAAP basis |  | $ | (14) |  |  | $ | 22 |  |  | $ | 117 |  |  |  |  |  |
| (Gains) losses on investments |  | 16 |  |  | (9) |  |  | (119) |  |  |  |  |  |
| Other |  | — |  |  | (8) |  |  | (2) |  |  |  |  |  |
| Other income (expense), net on non-GAAP basis |  | $ | 2 |  |  | $ | 5 |  |  | $ | (4) |  |  |  |  |  |

[0001730168-22-000015:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | October 31,2021 |  | January 31,2021 |  |  |  |  |
| Provision for income taxes on GAAP basis |  | $ | 215 |  |  | $ | 180 |  |  | $ | 6 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | 295 |  |  | 297 |  |  | 399 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 510 |  |  | $ | 477 |  |  | $ | 405 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 2,472 |  |  | $ | 1,989 |  |  | $ | 1,378 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,127 |  |  | 1,343 |  |  | 1,368 |  |  |  |  |  |
| Stock-based compensation expense |  | 387 |  |  | 414 |  |  | 444 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 19 |  |  | 26 |  |  | 86 |  |  |  |  |  |
| Acquisition-related costs |  | 15 |  |  | 20 |  |  | 43 |  |  |  |  |  |
| Loss on debt extinguishment |  | — |  |  | 23 |  |  | 172 |  |  |  |  |  |
| (Gains) losses on investments |  | 16 |  |  | (9) |  |  | (119) |  |  |  |  |  |
| Other |  | — |  |  | (8) |  |  | — |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (295) |  |  | (297) |  |  | (399) |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 3,741 |  |  | $ | 3,501 |  |  | $ | 2,973 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 429 |  |  | 430 |  |  | 428 |  |  |  |  |  |
| Non-GAAP adjustment (1) |  | 17 |  |  | 18 |  |  | 22 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 446 |  |  | 448 |  |  | 450 |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 3,741 |  |  | $ | 3,501 |  |  | $ | 2,973 |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | 407 |  |  | 411 |  |  | 398 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 510 |  |  | 477 |  |  | 405 |  |  |  |  |  |
| Depreciation |  | 136 |  |  | 134 |  |  | 138 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 24 |  |  | 27 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 4,818 |  |  | $ | 4,547 |  |  | $ | 3,941 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 3,486 |  |  | $ | 3,541 |  |  | $ | 3,113 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (101) |  |  | (88) |  |  | (114) |  |  |  |  |  |
| Free cash flow |  | $ | 3,385 |  |  | $ | 3,453 |  |  | $ | 2,999 |  |  |  |  |  |

[0001730168-22-000015:8k_2_02:71]
|  |  | Fiscal Quarter Ending |
|  |  | May 1, |
| Expected average diluted share count (2): |  | 2022 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 426 |  |
| Non-GAAP adjustment (1) |  | 16 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 442 |  |

[0001730168-22-000015:8k_2_02:72]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis. For the fiscal quarter ending May 1, 2022, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-22-000015:8k_2_02:73]
BROADCOM INC.

[0001730168-22-000015:8k_2_02:74]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-22-000015:8k_2_02:75]
(IN MILLIONS)

[0001730168-22-000015:8k_2_02:76]
|  |  | January 30,2022 |  | October 31,2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 10,219 |  |  | $ | 12,163 |  |
| Trade accounts receivable, net |  | 2,539 |  |  | 2,071 |  |
| Inventory |  | 1,520 |  |  | 1,297 |  |
| Other current assets |  | 1,063 |  |  | 1,055 |  |
| Total current assets |  | 15,341 |  |  | 16,586 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,303 |  |  | 2,348 |  |
| Goodwill |  | 43,450 |  |  | 43,450 |  |
| Intangible assets, net |  | 10,244 |  |  | 11,374 |  |
| Other long-term assets |  | 1,886 |  |  | 1,812 |  |
| Total assets |  | $ | 73,224 |  |  | $ | 75,570 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,078 |  |  | $ | 1,086 |  |
| Employee compensation and benefits |  | 531 |  |  | 1,066 |  |
| Current portion of long-term debt |  | 300 |  |  | 290 |  |
| Other current liabilities |  | 4,378 |  |  | 3,839 |  |
| Total current liabilities |  | 6,287 |  |  | 6,281 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 39,205 |  |  | 39,440 |  |
| Other long-term liabilities |  | 4,738 |  |  | 4,860 |  |
| Total liabilities |  | 50,230 |  |  | 50,581 |  |
| Preferred stock dividend obligation |  | 26 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 23,083 |  |  | 24,330 |  |
| Retained earnings |  | — |  |  | 748 |  |
| Accumulated other comprehensive loss |  | (115) |  |  | (116) |  |
| Total stockholders' equity |  | 22,968 |  |  | 24,962 |  |
| Total liabilities and equity |  | $ | 73,224 |  |  | $ | 75,570 |  |

[0001730168-22-000015:8k_2_02:77]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | October 31,2021 |  | January 31,2021 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,472 |  |  | $ | 1,989 |  |  | $ | 1,378 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,151 |  |  | 1,367 |  |  | 1,395 |  |  |  |  |  |
| Depreciation |  | 136 |  |  | 134 |  |  | 138 |  |  |  |  |  |
| Stock-based compensation |  | 387 |  |  | 414 |  |  | 444 |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | 70 |  |  | (47) |  |  | (149) |  |  |  |  |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | 172 |  |  |  |  |  |
| (Gains) losses on investments |  | 16 |  |  | (9) |  |  | (119) |  |  |  |  |  |
| Non-cash interest expense |  | 32 |  |  | 29 |  |  | 22 |  |  |  |  |  |
| Other |  | (1) |  |  | (3) |  |  | 10 |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (468) |  |  | 160 |  |  | (247) |  |  |  |  |  |
| Inventory |  | (223) |  |  | (137) |  |  | 51 |  |  |  |  |  |
| Accounts payable |  | — |  |  | 101 |  |  | 44 |  |  |  |  |  |
| Employee compensation and benefits |  | (528) |  |  | 172 |  |  | (375) |  |  |  |  |  |
| Other current assets and current liabilities |  | 521 |  |  | (540) |  |  | 408 |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | (79) |  |  | (89) |  |  | (59) |  |  |  |  |  |
| Net cash provided by operating activities |  | 3,486 |  |  | 3,541 |  |  | 3,113 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from sales of businesses |  | — |  |  | 45 |  |  | — |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (101) |  |  | (88) |  |  | (114) |  |  |  |  |  |
| Purchases of investments |  | (200) |  |  | — |  |  | — |  |  |  |  |  |
| Proceeds from sales of investments |  | — |  |  | 102 |  |  | — |  |  |  |  |  |
| Other |  | (8) |  |  | (9) |  |  | (8) |  |  |  |  |  |
| Net cash provided by (used in) investing activities |  | (309) |  |  | 50 |  |  | (122) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | 9,904 |  |  |  |  |  |
| Payments on debt obligations |  | (255) |  |  | (762) |  |  | (9,200) |  |  |  |  |  |
| Payments of dividends |  | (1,764) |  |  | (1,561) |  |  | (1,543) |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  | (2,724) |  |  | — |  |  | — |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (375) |  |  | (266) |  |  | (225) |  |  |  |  |  |
| Issuance of common stock |  | 1 |  |  | 57 |  |  | 35 |  |  |  |  |  |
| Other |  | (4) |  |  | (1) |  |  | (28) |  |  |  |  |  |
| Net cash used in financing activities |  | (5,121) |  |  | (2,533) |  |  | (1,057) |  |  |  |  |  |
| Net change in cash and cash equivalents |  | (1,944) |  |  | 1,058 |  |  | 1,934 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 12,163 |  |  | 11,105 |  |  | 7,618 |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 10,219 |  |  | $ | 12,163 |  |  | $ | 9,552 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 240 |  |  | $ | 571 |  |  | $ | 372 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 186 |  |  | $ | 168 |  |  | $ | 147 |  |  |  |  |  |
