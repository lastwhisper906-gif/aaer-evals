# AVGO MD&A — 0001730168-22-000029


## mdna

[0001730168-22-000029:mdna:1]
[same as prior period, unchanged from 0001730168-21-000123:mdna:1]

[0001730168-22-000029:mdna:2]
21

[0001730168-22-000029:mdna:3]
[same as prior period, unchanged from 0001730168-21-000123:mdna:2]

[0001730168-22-000029:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-22-000029:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and IP licensing. Our infrastructure software segment includes our mainframe, distributed and cyber security solutions, and our FC SAN business.

[0001730168-22-000029:mdna:6]
[same as prior period, unchanged from 0001730168-21-000123:mdna:6]

[0001730168-22-000029:mdna:7]
Highlights during the fiscal quarter ended January 30, 2022 include the following:

[0001730168-22-000029:mdna:8]
•We generated $3,486 million of cash from operations.

[0001730168-22-000029:mdna:9]
•We paid $1,764 million in cash dividends.

[0001730168-22-000029:mdna:10]
•We repurchased $2,724 million of common stock.

[0001730168-22-000029:mdna:11]
[same as prior period, unchanged from 0001730168-21-000123:mdna:11]

[0001730168-22-000029:mdna:12]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in some of our employees working remotely for an extended period of time and some of whom are still working remotely. While we have implemented personal safety measures at all of our facilities where our employees are working on site, we may need to modify our business practices and policies. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-22-000029:mdna:13]
The demand environment for our semiconductor products was consistent with our expectations for the first quarter of our fiscal year ending October 30, 2022 (“fiscal year 2022”), with continued demand for products and infrastructure as customers invest in technologies and cloud environments to support remote or hybrid tele-work and learning arising from COVID-19, as well as the transition to office re-openings. While we continue to see robust demand in this area and record profitability driven by the supply imbalance, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. We continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. While supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet increased demand. To date, the impact of COVID-19 on the demand environment for our software products has been limited.

[0001730168-22-000029:mdna:14]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty and strengthen our balance sheet, including closely managing working capital and our debt instruments.

[0001730168-22-000029:mdna:15]
[same as prior period, unchanged from 0001730168-21-000123:mdna:15]

[0001730168-22-000029:mdna:16]
[same as prior period, unchanged from 0001730168-21-000123:mdna:16]

[0001730168-22-000029:mdna:17]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting estimates are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those estimates include revenue recognition, business combinations, valuation of goodwill and long-lived assets, inventory valuation, income taxes, retirement and post-retirement benefit plan assumptions, stock-based compensation expense, and employee bonus programs.

[0001730168-22-000029:mdna:18]
There were no significant changes in our critical accounting estimates during the fiscal quarter ended January 30, 2022 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2021 Annual Report on Form 10-K.

[0001730168-22-000029:mdna:19]
[same as prior period, unchanged from 0001730168-21-000123:mdna:19]

[0001730168-22-000029:mdna:20]
Fiscal Quarter Ended January 30, 2022 Compared to Fiscal Quarter Ended January 31, 2021

[0001730168-22-000029:mdna:21]
The following table sets forth our results of operations for the periods presented:

[0001730168-22-000029:mdna:22]
|  |  | Fiscal Quarter Ended |
|  |  | January 30,2022 |  | January 31,2021 |  | January 30,2022 |  | January 31,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 6,053 |  |  | $ | 5,081 |  |  | 79 | % |  | 76 | % |
| Subscriptions and services |  | 1,653 |  |  | 1,574 |  |  | 21 |  |  | 24 |  |
| Total net revenue |  | 7,706 |  |  | 6,655 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,769 |  |  | 1,672 |  |  | 23 |  |  | 25 |  |
| Cost of subscriptions and services |  | 156 |  |  | 142 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 730 |  |  | 874 |  |  | 9 |  |  | 13 |  |
| Restructuring charges |  | 2 |  |  | 15 |  |  | — |  |  | 1 |  |
| Total cost of revenue |  | 2,657 |  |  | 2,703 |  |  | 34 |  |  | 41 |  |
| Gross margin |  | 5,049 |  |  | 3,952 |  |  | 66 |  |  | 59 |  |
| Research and development |  | 1,206 |  |  | 1,211 |  |  | 16 |  |  | 18 |  |
| Selling, general and administrative |  | 321 |  |  | 339 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 397 |  |  | 494 |  |  | 5 |  |  | 7 |  |
| Restructuring, impairment and disposal charges |  | 17 |  |  | 71 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 1,941 |  |  | 2,115 |  |  | 25 |  |  | 31 |  |
| Operating income |  | $ | 3,108 |  |  | $ | 1,837 |  |  | 41 | % |  | 28 | % |

[0001730168-22-000029:mdna:23]
[same as prior period, unchanged from 0001730168-21-000123:mdna:26]

[0001730168-22-000029:mdna:24]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 23% and 19% of our net revenue for the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively.

[0001730168-22-000029:mdna:25]
23

[0001730168-22-000029:mdna:26]
We believe aggregate sales to our top five end customers, through all channels, accounted for more than 35% of our net revenue for each of the fiscal quarters ended January 30, 2022 and January 31, 2021. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 25% of our net revenue for each of the fiscal quarters ended January 30, 2022 and January 31, 2021. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-22-000029:mdna:27]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile handsets. The ongoing COVID-19 pandemic and related uncertainties and supply imbalance have caused and may continue to cause our net revenue to fluctuate significantly and impact our results of operations, as discussed above.

[0001730168-22-000029:mdna:28]
[same as prior period, unchanged from 0001730168-21-000123:mdna:30]

[0001730168-22-000029:mdna:29]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |
| Net Revenue by Segment |  | January 30, 2022 |  | January 31, 2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 5,873 |  |  | $ | 4,908 |  |  | $ | 965 |  |  | 20 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,833 |  |  | 1,747 |  |  | 86 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 7,706 |  |  | $ | 6,655 |  |  | $ | 1,051 |  |  | 16 | % |  |  |  |  |  |  |  |  |

[0001730168-22-000029:mdna:30]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | January 30,2022 |  | January 31,2021 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 76 | % |  | 74 | % |  |  |  |  |
| Infrastructure software |  | 24 |  |  | 26 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-22-000029:mdna:31]
Net revenue from our semiconductor solutions segment increased due to on-going strong demand for our semiconductor products, primarily networking, server storage and broadband products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions.

[0001730168-22-000029:mdna:32]
[same as prior period, unchanged from 0001730168-21-000123:mdna:36]

[0001730168-22-000029:mdna:33]
Gross margin was $5,049 million, or 66% of net revenue, for the fiscal quarter ended January 30, 2022 compared to $3,952 million, or 59% of net revenue, for the fiscal quarter ended January 31, 2021. The increase was primarily due to lower amortization of acquisition-related intangible assets and higher profitability within our semiconductor solutions segment.

[0001730168-22-000029:mdna:34]
[same as prior period, unchanged from 0001730168-21-000123:mdna:39]

[0001730168-22-000029:mdna:35]
Research and development expense decreased $5 million for the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period. The decrease was primarily due to lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures, offset by higher variable employee compensation expense and higher engineering project and material costs.

[0001730168-22-000029:mdna:36]
[same as prior period, unchanged from 0001730168-21-000123:mdna:41]

[0001730168-22-000029:mdna:37]
Selling, general and administrative expense decreased $18 million, or 5%, for the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period. The decrease was primarily due to lower acquisition-related costs incurred in the current year fiscal period following the completion of key integration activities.

[0001730168-22-000029:mdna:38]
[same as prior period, unchanged from 0001730168-21-000123:mdna:43]

[0001730168-22-000029:mdna:39]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $97 million, or 20%, for the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-22-000029:mdna:40]
24

[0001730168-22-000029:mdna:41]
[same as prior period, unchanged from 0001730168-21-000123:mdna:45]

[0001730168-22-000029:mdna:42]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $54 million, or 76%, for the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period primarily due to lower employee termination costs in the current year fiscal period following the completion of key restructuring activities from acquisitions.

[0001730168-22-000029:mdna:43]
[same as prior period, unchanged from 0001730168-21-000123:mdna:47]

[0001730168-22-000029:mdna:44]
Total stock-based compensation expense was $387 million for the fiscal quarter ended January 30, 2022, compared to $444 million for the prior year fiscal period. The decrease primarily reflects the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-22-000029:mdna:45]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of January 30, 2022, which we expect to recognize over the remaining weighted-average service period of 2.8 years.

[0001730168-22-000029:mdna:46]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 963 |  |
| 2023 |  | 922 |  |
| 2024 |  | 552 |  |
| 2025 |  | 230 |  |
| 2026 |  | 25 |  |
| Total |  | $ | 2,692 |  |

[0001730168-22-000029:mdna:47]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based restricted stock units (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-22-000029:mdna:48]
[same as prior period, unchanged from 0001730168-21-000123:mdna:53]

[0001730168-22-000029:mdna:49]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |
| Operating Income by Segment |  | January 30,2022 |  | January 31,2021 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 3,349 |  |  | $ | 2,561 |  |  | $ | 788 |  |  | 31 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,307 |  |  | 1,219 |  |  | 88 |  |  | 7 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (1,548) |  |  | (1,943) |  |  | 395 |  |  | (20) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 3,108 |  |  | $ | 1,837 |  |  | $ | 1,271 |  |  | 69 | % |  |  |  |  |  |  |  |  |

[0001730168-22-000029:mdna:50]
Operating income from our semiconductor solutions segment increased primarily due to on-going strong demand for our semiconductor products, primarily networking, broadband and server storage products and higher profitability across the markets. Operating income from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions.

[0001730168-22-000029:mdna:51]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 20% for the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period primarily due to lower amortization of acquisition-related intangible assets.

[0001730168-22-000029:mdna:52]
[same as prior period, unchanged from 0001730168-21-000123:mdna:58]

[0001730168-22-000029:mdna:53]
Interest expense. Interest expense was $407 million and $570 million for the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively. The decrease was primarily due to losses on extinguishment of debt related to debt transactions in the prior year fiscal period.

[0001730168-22-000029:mdna:54]
[same as prior period, unchanged from 0001730168-21-000123:mdna:10]

[0001730168-22-000029:mdna:55]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other expense, net, was $14 million and other income, net was $117 million for the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively. The decrease was primarily due to changes in investment gains or losses.

[0001730168-22-000029:mdna:56]
Provision for income taxes. The provision for income taxes was $215 million and $6 million for the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively. The increase was primarily due to higher income before income taxes and a shift in the jurisdictional mix of income and expenses. The provision for income taxes for the fiscal quarter ended January 31, 2021 was substantially offset by excess tax benefits from stock-based awards and benefits from lapses of statutes of limitations and audit settlements.

[0001730168-22-000029:mdna:57]
[same as prior period, unchanged from 0001730168-21-000123:mdna:65]

[0001730168-22-000029:mdna:58]
[same as prior period, unchanged from 0001730168-21-000123:mdna:66]

[0001730168-22-000029:mdna:59]
Our primary sources of liquidity as of January 30, 2022 consisted of: (i) $10,219 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-22-000029:mdna:60]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $41,244 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect a slight increase in capital expenditures in fiscal year 2022 as compared to fiscal year 2021.

[0001730168-22-000029:mdna:61]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 10. “Commitments and Contingencies”and Note 6. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-22-000029:mdna:62]
[same as prior period, unchanged from 0001730168-21-000123:mdna:70]

[0001730168-22-000029:mdna:63]
[same as prior period, unchanged from 0001730168-21-000123:mdna:71]

[0001730168-22-000029:mdna:64]
[same as prior period, unchanged from 0001730168-21-000123:mdna:72]

[0001730168-22-000029:mdna:65]
Working capital decreased to $9,054 million at January 30, 2022 from $10,305 million at October 31, 2021. The decrease was primarily attributable to the following:

[0001730168-22-000029:mdna:66]
•Cash and cash equivalents decreased to $10,219 million at January 30, 2022 from $12,163 million at October 31, 2021, primarily due to $2,724 million of common stock repurchases, $1,764 million of dividend payments, $375 million of employee withholding tax payments related to net settled equity awards, and $255 million of debt payments. These decreases were partially offset by $3,486 million in net cash provided by operating activities.

[0001730168-22-000029:mdna:67]
•Other current liabilities increased to $4,378 million at January 30, 2022 from $3,839 million at October 31, 2021, primarily due to increases in contract liabilities and interest payable.

[0001730168-22-000029:mdna:68]
[same as prior period, unchanged from 0001730168-21-000123:mdna:21]

[0001730168-22-000029:mdna:69]
These decreases in working capital were offset in part by the following:

[0001730168-22-000029:mdna:70]
•Employee compensation and benefits decreased to $531 million at January 30, 2022 from $1,066 million at October 31, 2021, primarily due to the timing of employee bonus plan payments.

[0001730168-22-000029:mdna:71]
•Accounts receivable increased to $2,539 million at January 30, 2022 from $2,071 million at October 31, 2021, primarily due to revenue linearity.

[0001730168-22-000029:mdna:72]
•Inventory increased to $1,520 million at January 30, 2022 from $1,297 million at October 31, 2021, primarily due to higher material costs and to support customer demand.

[0001730168-22-000029:mdna:73]
[same as prior period, unchanged from 0001730168-21-000123:mdna:91]

[0001730168-22-000029:mdna:74]
|  |  | Fiscal Quarter Ended |
|  |  | January 30,2022 |  | January 31,2021 |
|  |  | (In millions, except per share data) |
| Cash dividends declared and paid per share to common stockholders |  | $ | 4.10 |  |  | $ | 3.60 |  |
| Cash dividends declared and paid to common stockholders |  | $ | 1,689 |  |  | $ | 1,468 |  |
| Cash dividends declared and paid per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |
| Cash dividends declared and paid to preferred stockholders |  | $ | 75 |  |  | $ | 75 |  |
| Stock repurchases |  | $ | 2,724 |  |  | $ | — |  |

[0001730168-22-000029:mdna:75]
Pursuant to a $10 billion stock repurchase program authorized by our Board of Directors in December 2021, we repurchased and retired approximately 4 million shares of our common stock at a weighted average price of $622.91 during the fiscal quarter ended January 30, 2022.

[0001730168-22-000029:mdna:76]
During the fiscal quarter ended January 30, 2022 and January 31, 2021, we paid approximately $375 million and $225 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 1 million shares of common stock from employees in connection with such net share settlements during each of the fiscal quarters ended January 30, 2022 and January 31, 2021.

[0001730168-22-000029:mdna:77]
[same as prior period, unchanged from 0001730168-21-000123:mdna:94]

[0001730168-22-000029:mdna:78]
|  |  | Fiscal Quarter Ended |
|  |  | January 30,2022 |  | January 31,2021 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 3,486 |  |  | $ | 3,113 |  |
| Net cash used in investing activities |  | (309) |  |  | (122) |  |
| Net cash used in financing activities |  | (5,121) |  |  | (1,057) |  |
| Net change in cash and cash equivalents |  | $ | (1,944) |  |  | $ | 1,934 |  |

[0001730168-22-000029:mdna:79]
[same as prior period, unchanged from 0001730168-21-000123:mdna:96]

[0001730168-22-000029:mdna:80]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $373 million increase in cash provided by operations during the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period was due to $1,094 million higher net income, offset by a $122 million decrease in amortization of intangible assets and stock-based compensation and other adjustments, as well as a $599 million decrease resulting from changes in operating assets and liabilities.

[0001730168-22-000029:mdna:81]
[same as prior period, unchanged from 0001730168-21-000123:mdna:98]

[0001730168-22-000029:mdna:82]
Cash flows from investing activities primarily consisted of cash used for investments and capital expenditures. The $187 million increase in cash used in investing activities during the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period was primarily related to investment purchases.

[0001730168-22-000029:mdna:83]
[same as prior period, unchanged from 0001730168-21-000123:mdna:100]

[0001730168-22-000029:mdna:84]
Cash flows from financing activities primarily consisted of proceeds and payments related to our stock repurchases, long-term borrowings, dividend payments and employee withholding tax payments related to net settled equity awards. The $4,064 million increase in cash used in financing activities during the fiscal quarter ended January 30, 2022 compared to the prior year fiscal period was primarily due to a $2,724 million increase in common stock repurchases, a $959 million change in net borrowing activities, a $221 million increase in dividend payments and a $150 million increase in employee withholding tax payments related to net settled equity awards.

[0001730168-22-000029:mdna:85]
[same as prior period, unchanged from 0001730168-21-000123:mdna:121]

[0001730168-22-000029:mdna:86]
[same as prior period, unchanged from 0001730168-21-000123:mdna:122]
