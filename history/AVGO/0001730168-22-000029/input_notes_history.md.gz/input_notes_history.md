# AVGO note change history — 0001730168-21-000123 → 0001730168-22-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:1]
The following table summarizes contractual obligations and commitments as of January 30, 2022 that materially changed from the end of fiscal year 2021:
  (was, 2021-09-09, similarity 0.9684):
[0001730168-21-000123:note_history:1]
The following table summarizes contractual obligations and commitments as of August 1, 2021 that materially changed from the end of fiscal year 2020:

- changed (2022-03-10):
[0001730168-22-000029:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 126 |  |  | $ | 698 |  |
| 2023 |  | 146 |  |  | 181 |  |
| 2024 |  | 80 |  |  | 122 |  |
| 2025 |  | 60 |  |  | 25 |  |
| 2026 |  | — |  |  | 49 |  |
| Thereafter |  | — |  |  | 2 |  |
| Total |  | $ | 412 |  |  | $ | 1,077 |  |
  (was, 2021-09-09, similarity 0.656):
[0001730168-21-000123:note_history:2]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 558 |  |  | $ | 1,305 |  |  | $ | 54 |  |
| 2022 |  | 1,819 |  |  | 78 |  |  | 239 |  |
| 2023 |  | 1,950 |  |  | 58 |  |  | 226 |  |
| 2024 |  | 3,084 |  |  | — |  |  | 162 |  |
| 2025 |  | 3,276 |  |  | — |  |  | 74 |  |
| Thereafter |  | 46,048 |  |  | — |  |  | 248 |  |
| Total |  | $ | 56,735 |  |  | $ | 1,441 |  |  | $ | 1,003 |  |

- added (2022-03-10):
[0001730168-22-000029:note_history:3]
Purchase Commitments. Represent unconditional purchase obligations that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. These commitments include agreements to purchase inventory and other goods or services. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

- changed (2022-03-10):
[0001730168-22-000029:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 30, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,366 million of unrecognized tax benefits and accrued interest and penalties classified within other long-term liabilities on our condensed consolidated balance sheet as of January 30, 2022 have been excluded from the table above.
  (was, 2021-09-09, similarity 0.9579):
[0001730168-21-000123:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 1, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,282 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 1, 2021 have been excluded from the table above.

- changed (2022-03-10):
[0001730168-22-000029:note_history:5]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District
  (was, 2021-09-09, similarity 0.6875):
[0001730168-21-000123:note_history:5]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint

- added (2022-03-10):
[0001730168-22-000029:note_history:6]
Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. The Federal Circuit Court issued its decision on February 4, 2022. While the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. Broadcom and Apple anticipate filing a petition for rehearing with the Federal Circuit Court by April 6, 2022.

- changed (2022-03-10):
[0001730168-22-000029:note_history:7]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We do not believe a material loss is probable or estimable at this time. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a possible rehearing by the Federal Circuit Court, retrial at the lower court and further appeals) could significantly change the assessment of damages.
  (was, 2021-09-09, similarity 0.6597):
[0001730168-21-000123:note_history:7]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

- changed (2022-03-10):
[0001730168-22-000029:note_history:8]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.
  (was, 2021-09-09, similarity 0.9877):
[0001730168-21-000123:note_history:8]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

- removed (2022-03-10):
[0001730168-21-000123:note_history:9]
Debt Principal, Interest and Fees. Represents principal, interest and fees on our borrowings.

- removed (2022-03-10):
[0001730168-21-000123:note_history:10]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

- removed (2022-03-10):
[0001730168-21-000123:note_history:11]
Standby Letters of Credit

- removed (2022-03-10):
[0001730168-21-000123:note_history:12]
As of August 1, 2021 and November 1, 2020, we had standby letters of credit of $52 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- removed (2022-03-10):
[0001730168-21-000123:note_history:13]
sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. We are unable to predict the date on which the Federal Circuit Court will issue its decision.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:14]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.
  (was, 2021-09-09, similarity 0.8471):
[0001730168-21-000123:note_history:14]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of mainframe and BizOps software solutions enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- changed (2022-03-10):
[0001730168-22-000029:note_history:15]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ends on May 1, 2022 and the third quarter ends on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.
  (was, 2021-09-09, similarity 0.9028):
[0001730168-21-000123:note_history:15]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ended on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

- changed (2022-03-10):
[0001730168-22-000029:note_history:16]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 30, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.
  (was, 2021-09-09, similarity 0.8771):
[0001730168-21-000123:note_history:16]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 1, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.

- added (2022-03-10):
[0001730168-22-000029:note_history:17]
Recently Adopted Accounting Guidance
In October 2021, the Financial Accounting Standards Boards issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not impact our condensed consolidated financial statements.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:18]
The future scheduled principal payments of debt as of January 30, 2022 were as follows:
  (was, 2021-09-09, similarity 0.9448):
[0001730168-21-000123:note_history:18]
The future scheduled principal payments of debt as of August 1, 2021 were as follows:

- changed (2022-03-10):
[0001730168-22-000029:note_history:19]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 9 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,515 |  |
| 2026 |  | 2,596 |  |
| Thereafter |  | 35,158 |  |
| Total |  | $ | 41,244 |  |
  (was, 2021-09-09, similarity 0.9952):
[0001730168-21-000123:note_history:19]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-03-10):
[0001730168-22-000029:note_history:20]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | $ | 3,250 |  |  | $ | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,965 |  |  | 1,965 |  |
|  |  |  |  | 2,717 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,679 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,684 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,020 |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 1,086 |  |  | 1,086 |  |
|  |  |  |  | 2,106 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 944 |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,958 |  |  | 1,958 |  |
|  |  |  |  | 3,524 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:21]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 265 |  |  | 265 |  |
|  |  |  |  | 408 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,244 |  |  | 41,499 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,803) |  |  | (1,834) |  |
| Total debt |  |  |  | $ | 39,441 |  |  | $ | 39,665 |  |
  (was, 2021-09-09, similarity 0.802):
[0001730168-21-000123:note_history:21]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 6,992 |  |  | 10,526 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
|  |  |  |  | 493 |  |  | 883 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,100) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,399 |  |  | $ | 40,994 |  |

- added (2022-03-10):
[0001730168-22-000029:note_history:22]
As of January 30, 2022 and October 31, 2021, short-term finance lease liabilities of $31 million and $26 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $33 million and $39 million, respectively, were included in long-term debt.

- changed (2022-03-10):
[0001730168-22-000029:note_history:23]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either January 30, 2022 or October 31, 2021.
  (was, 2021-09-09, similarity 0.7929):
[0001730168-21-000123:note_history:23]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of August 1, 2021, we had no borrowings outstanding under the Revolving Facility.

- changed (2022-03-10):
[0001730168-22-000029:note_history:24]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. We had no Commercial Paper outstanding at either January 30, 2022 or October 31, 2021.
  (was, 2021-09-09, similarity 0.9632):
[0001730168-21-000123:note_history:24]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of August 1, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

- changed (2022-03-10):
[0001730168-22-000029:note_history:25]
As of January 30, 2022, the estimated aggregate fair value of debt was $41,558 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2021-09-09, similarity 0.9729):
[0001730168-21-000123:note_history:25]
As of August 1, 2021, the estimated aggregate fair value of debt was $45,379 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2022-03-10):
[0001730168-22-000029:note_history:26]
The future scheduled principal payments of debt as of January 30, 2022 were as follows:
  (was, 2021-09-09, similarity 0.9448):
[0001730168-21-000123:note_history:26]
The future scheduled principal payments of debt as of August 1, 2021 were as follows:

- changed (2022-03-10):
[0001730168-22-000029:note_history:27]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 9 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,515 |  |
| 2026 |  | 2,596 |  |
| Thereafter |  | 35,158 |  |
| Total |  | $ | 41,244 |  |
  (was, 2021-09-09, similarity 0.9952):
[0001730168-21-000123:note_history:27]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:28]
As of January 30, 2022 and October 31, 2021, we accrued interest payable of $417 million and $282 million, respectively, and were in compliance with all debt covenants.
  (was, 2021-09-09, similarity 0.9477):
[0001730168-21-000123:note_history:28]
As of August 1, 2021 and November 1, 2020, we accrued interest payable of $471 million and $304 million, respectively, and were in compliance with all debt covenants.

- removed (2022-03-10):
[0001730168-21-000123:note_history:29]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
|  |  |  |  | 5,500 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 10,000 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
|  |  |  |  | 3,917 |  |  | 3,917 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 6,273 |  |  | 8,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
|  |  |  |  | 3,497 |  |  | 4,500 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
|  |  |  |  | — |  |  | 5,888 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
|  |  |  |  | 4,805 |  |  | 7,762 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |

- removed (2022-03-10):
[0001730168-21-000123:note_history:30]
As of August 1, 2021 and November 1, 2020, short-term finance lease liabilities of $24 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $34 million and $48 million, respectively, were included in long-term debt.

- removed (2022-03-10):
[0001730168-21-000123:note_history:31]
March 2021 Senior Notes

- removed (2022-03-10):
[0001730168-21-000123:note_history:32]
In March 2021, we completed our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- removed (2022-03-10):
[0001730168-21-000123:note_history:33]
In connection with the Exchange Offer, Broadcom Corporation and Broadcom Technologies Inc. were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes.

- removed (2022-03-10):
[0001730168-21-000123:note_history:34]
January 2021 Senior Notes

- removed (2022-03-10):
[0001730168-21-000123:note_history:35]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- removed (2022-03-10):
[0001730168-21-000123:note_history:36]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

- removed (2022-03-10):
[0001730168-21-000123:note_history:37]
During the fiscal quarter ended May 2, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain outstanding notes maturing between 2021 and 2023. Using the remaining proceeds from the January 2021 Senior Notes, we repurchased $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022 and repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-03-10):
[0001730168-22-000029:note_history:38]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | $ | 3,250 |  |  | $ | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,965 |  |  | 1,965 |  |
|  |  |  |  | 2,717 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,679 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,684 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,020 |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 1,086 |  |  | 1,086 |  |
|  |  |  |  | 2,106 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 944 |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,958 |  |  | 1,958 |  |
|  |  |  |  | 3,524 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:39]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 265 |  |  | 265 |  |
|  |  |  |  | 408 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,244 |  |  | 41,499 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,803) |  |  | (1,834) |  |
| Total debt |  |  |  | $ | 39,441 |  |  | $ | 39,665 |  |
  (was, 2021-09-09, similarity 0.802):
[0001730168-21-000123:note_history:39]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 6,992 |  |  | 10,526 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
|  |  |  |  | 493 |  |  | 883 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,100) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,399 |  |  | $ | 40,994 |  |

- removed (2022-03-10):
[0001730168-21-000123:note_history:40]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
|  |  |  |  | 5,500 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 10,000 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
|  |  |  |  | 3,917 |  |  | 3,917 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 6,273 |  |  | 8,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
|  |  |  |  | 3,497 |  |  | 4,500 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
|  |  |  |  | — |  |  | 5,888 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
|  |  |  |  | 4,805 |  |  | 7,762 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:41]
|  |  | Fiscal Quarter Ended January 30, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 548 |  |  | $ | 4,984 |  |  | $ | 521 |  |  | $ | 6,053 |  |
| Subscriptions and services (a) |  | 1,109 |  |  | 128 |  |  | 416 |  |  | 1,653 |  |
| Total |  | $ | 1,657 |  |  | $ | 5,112 |  |  | $ | 937 |  |  | $ | 7,706 |  |
  (was, 2021-09-09, similarity 0.9803):
[0001730168-21-000123:note_history:41]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:42]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |
  (was, 2021-09-09, similarity 0.9803):
[0001730168-21-000123:note_history:42]
|  |  | Fiscal Quarter Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:43]
_______________
  (was, 2021-09-09, similarity 0.6383):
[0001730168-21-000123:note_history:43]
________________________________

- removed (2022-03-10):
[0001730168-21-000123:note_history:44]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |

- removed (2022-03-10):
[0001730168-21-000123:note_history:45]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:46]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
  (was, 2021-09-09, similarity 0.9861):
[0001730168-21-000123:note_history:46]
Revenue from Contracts with Customers We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
Disaggregation

- added (2022-03-10):
[0001730168-22-000029:note_history:47]
Disaggregation

- changed (2022-03-10):
[0001730168-22-000029:note_history:48]
|  |  | Fiscal Quarter Ended January 30, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 548 |  |  | $ | 4,984 |  |  | $ | 521 |  |  | $ | 6,053 |  |
| Subscriptions and services (a) |  | 1,109 |  |  | 128 |  |  | 416 |  |  | 1,653 |  |
| Total |  | $ | 1,657 |  |  | $ | 5,112 |  |  | $ | 937 |  |  | $ | 7,706 |  |
  (was, 2021-09-09, similarity 0.9803):
[0001730168-21-000123:note_history:48]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:49]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |
  (was, 2021-09-09, similarity 0.9803):
[0001730168-21-000123:note_history:49]
|  |  | Fiscal Quarter Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:50]
_______________
  (was, 2021-09-09, similarity 0.6383):
[0001730168-21-000123:note_history:50]
________________________________

- added (2022-03-10):
[0001730168-22-000029:note_history:51]
|  |  | January 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 105 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,545 |  |  | $ | 3,185 |  |

- changed (2022-03-10):
[0001730168-22-000029:note_history:52]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 30, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,216 million. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million.
  (was, 2021-09-09, similarity 0.97):
[0001730168-21-000123:note_history:52]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 1, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,330 million. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million.

- changed (2022-03-10):
[0001730168-22-000029:note_history:53]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of January 30, 2022 were approximately $15.3 billion. We expect approximately 28% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2021-09-09, similarity 0.9909):
[0001730168-21-000123:note_history:53]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of August 1, 2021 were approximately $12.1 billion. We expect approximately 31% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2022-03-10):
[0001730168-21-000123:note_history:54]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |

- removed (2022-03-10):
[0001730168-21-000123:note_history:55]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |

- removed (2022-03-10):
[0001730168-21-000123:note_history:56]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of August 1, 2021 |  | $ | 142 |  |  | $ | 3,628 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-03-10):
[0001730168-22-000029:note_history:57]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2022 to stockholders of record on March 15, 2022.
  (was, 2021-09-09, similarity 0.8737):
[0001730168-21-000123:note_history:57]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2021 to stockholders of record on September 15, 2021.

- changed (2022-03-10):
[0001730168-22-000029:note_history:58]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on March 31, 2022 to stockholders of record on March 22, 2022.
  (was, 2021-09-09, similarity 0.9133):
[0001730168-21-000123:note_history:58]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on September 30, 2021 to stockholders of record on September 22, 2021.
