# AVGO 10-Q controls and the auditor's report


## item_4_controls

[0001730168-22-000029:item_4_controls:1]
Item 4. Controls and Procedures

[0001730168-22-000029:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures. Our management, with the participation of our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), evaluated the effectiveness of our disclosure controls and procedures as of January 30, 2022. We maintain disclosure controls and procedures that are designed to ensure that information required to be disclosed in our Exchange Act filings is properly and timely recorded, processed, summarized and reported. These disclosure controls and procedures are also intended to ensure that information is accumulated and communicated to our management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures. Based on this evaluation, our CEO and CFO concluded that, as of January 30, 2022, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001730168-22-000029:item_4_controls:3]
In designing and evaluating our disclosure controls and procedures, our management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives, and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001730168-22-000029:item_4_controls:4]
(b) Changes in Internal Control over Financial Reporting. There was no change in our internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15(d) and 15d-15(d) of the Exchange Act that occurred during the period covered by this report that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting. Although we have modified our workplace practices globally due to the COVID-19 pandemic, resulting in some of our employees working remotely for an extended period of time and some of whom are still working remotely, this has not meaningfully affected our internal controls over financial reporting. We are continually monitoring and assessing the COVID-19 situation on our internal controls to minimize the impact on their design and operating effectiveness.
