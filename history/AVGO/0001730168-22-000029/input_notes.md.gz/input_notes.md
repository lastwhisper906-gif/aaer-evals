# AVGO notes — 0001730168-22-000029


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-22-000029:notes:1]
[same as prior period, unchanged from 0001730168-21-000123:notes:1]

[0001730168-22-000029:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-22-000029:notes:3]
[same as prior period, unchanged from 0001730168-21-000123:notes:3]

[0001730168-22-000029:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ends on May 1, 2022 and the third quarter ends on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.

[0001730168-22-000029:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 30, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.

[0001730168-22-000029:notes:6]
[same as prior period, unchanged from 0001730168-21-000123:notes:6]

[0001730168-22-000029:notes:7]
[same as prior period, unchanged from 0001730168-21-000123:notes:7]

[0001730168-22-000029:notes:8]
Recently Adopted Accounting Guidance
In October 2021, the Financial Accounting Standards Boards issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not impact our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-22-000029:notes:9]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-22-000029:notes:10]
Disaggregation

[0001730168-22-000029:notes:11]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 9. “Segment Information”.

[0001730168-22-000029:notes:12]
[same as prior period, unchanged from 0001730168-21-000123:notes:10]

[0001730168-22-000029:notes:13]
|  |  | Fiscal Quarter Ended January 30, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 548 |  |  | $ | 4,984 |  |  | $ | 521 |  |  | $ | 6,053 |  |
| Subscriptions and services (a) |  | 1,109 |  |  | 128 |  |  | 416 |  |  | 1,653 |  |
| Total |  | $ | 1,657 |  |  | $ | 5,112 |  |  | $ | 937 |  |  | $ | 7,706 |  |

[0001730168-22-000029:notes:14]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |

[0001730168-22-000029:notes:15]
_______________

[0001730168-22-000029:notes:16]
[same as prior period, unchanged from 0001730168-21-000123:notes:16]

[0001730168-22-000029:notes:17]
[same as prior period, unchanged from 0001730168-21-000123:notes:17]

[0001730168-22-000029:notes:18]
[same as prior period, unchanged from 0001730168-21-000123:notes:18]

[0001730168-22-000029:notes:19]
[same as prior period, unchanged from 0001730168-21-000123:notes:19]

[0001730168-22-000029:notes:20]
|  |  | January 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 105 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,545 |  |  | $ | 3,185 |  |

[0001730168-22-000029:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 30, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,216 million. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million.

[0001730168-22-000029:notes:22]
[same as prior period, unchanged from 0001730168-21-000123:notes:22]

[0001730168-22-000029:notes:23]
[same as prior period, unchanged from 0001730168-21-000123:notes:23]

[0001730168-22-000029:notes:24]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of January 30, 2022 were approximately $15.3 billion. We expect approximately 28% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-22-000029:notes:25]
[same as prior period, unchanged from 0001730168-21-000123:notes:31]

[0001730168-22-000029:notes:26]
Cash equivalents included $3,315 million and $4,668 million of time deposits and $1,080 million and $1,607 million of money-market funds as of January 30, 2022 and October 31, 2021, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-22-000029:notes:27]
[same as prior period, unchanged from 0001730168-21-000123:notes:33]

[0001730168-22-000029:notes:28]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,200 million and $927 million during the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-22-000029:notes:29]
[same as prior period, unchanged from 0001730168-21-000123:notes:35]

[0001730168-22-000029:notes:30]
|  |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Finished goods |  | $ | 526 |  |  | $ | 423 |  |
| Work-in-process |  | 779 |  |  | 680 |  |
| Raw materials |  | 215 |  |  | 194 |  |
| Total inventory |  | $ | 1,520 |  |  | $ | 1,297 |  |

[0001730168-22-000029:notes:31]
[same as prior period, unchanged from 0001730168-21-000123:notes:37]

[0001730168-22-000029:notes:32]
|  |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 579 |  |  | $ | 539 |  |
| Other (miscellaneous) |  | 484 |  |  | 516 |  |
| Total other current assets |  | $ | 1,063 |  |  | $ | 1,055 |  |

[0001730168-22-000029:notes:33]
[same as prior period, unchanged from 0001730168-21-000123:notes:39]

[0001730168-22-000029:notes:34]
|  |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,027 |  |  | $ | 2,619 |  |
| Tax liabilities |  | 556 |  |  | 541 |  |
| Interest payable |  | 417 |  |  | 282 |  |
| Other (miscellaneous) |  | 378 |  |  | 397 |  |
| Total other current liabilities |  | $ | 4,378 |  |  | $ | 3,839 |  |

[0001730168-22-000029:notes:35]
[same as prior period, unchanged from 0001730168-21-000123:notes:41]

[0001730168-22-000029:notes:36]
|  |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,366 |  |  | $ | 3,407 |  |
| Other (miscellaneous) |  | 1,372 |  |  | 1,453 |  |
| Total other long-term liabilities |  | $ | 4,738 |  |  | $ | 4,860 |  |

[0001730168-22-000029:notes:37]
[same as prior period, unchanged from 0001730168-21-000123:notes:43]

[0001730168-22-000029:notes:38]
|  |  | Fiscal Quarter Ended |
|  |  | January 30,2022 |  | January 31,2021 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 240 |  |  | $ | 372 |  |
| Cash paid for income taxes |  | $ | 186 |  |  | $ | 147 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-22-000029:notes:39]
[same as prior period, unchanged from 0001730168-21-000123:notes:48]

[0001730168-22-000029:notes:40]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of January 30, 2022: |  |  |  |  |  |  |
| Purchased technology |  | $ | 23,597 |  |  | $ | (17,542) |  |  | $ | 6,055 |  |
| Customer contracts and related relationships |  | 8,335 |  |  | (4,857) |  |  | 3,478 |  |
| Order backlog |  | 1,279 |  |  | (1,085) |  |  | 194 |  |
| Trade names |  | 698 |  |  | (316) |  |  | 382 |  |
| Other |  | 183 |  |  | (75) |  |  | 108 |  |
| Intangible assets subject to amortization |  | 34,092 |  |  | (23,875) |  |  | 10,217 |  |
| In-process research and development |  | 27 |  |  | — |  |  | 27 |  |
| Total |  | $ | 34,119 |  |  | $ | (23,875) |  |  | $ | 10,244 |  |
| As of October 31, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 23,932 |  |  | $ | (17,148) |  |  | $ | 6,784 |  |
| Customer contracts and related relationships |  | 8,356 |  |  | (4,533) |  |  | 3,823 |  |
| Order backlog |  | 2,579 |  |  | (2,352) |  |  | 227 |  |
| Trade names |  | 787 |  |  | (386) |  |  | 401 |  |
| Other |  | 239 |  |  | (127) |  |  | 112 |  |
| Intangible assets subject to amortization |  | 35,893 |  |  | (24,546) |  |  | 11,347 |  |
| In-process research and development |  | 27 |  |  | — |  |  | 27 |  |
| Total |  | $ | 35,920 |  |  | $ | (24,546) |  |  | $ | 11,374 |  |

[0001730168-22-000029:notes:41]
Based on the amount of intangible assets subject to amortization at January 30, 2022, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-22-000029:notes:42]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 3,235 |  |
| 2023 |  | 3,237 |  |
| 2024 |  | 2,367 |  |
| 2025 |  | 659 |  |
| 2026 |  | 323 |  |
| Thereafter |  | 396 |  |
| Total |  | $ | 10,217 |  |

[0001730168-22-000029:notes:43]
[same as prior period, unchanged from 0001730168-21-000123:notes:52]

[0001730168-22-000029:notes:44]
| Amortizable intangible assets: |  | January 30,2022 |
|  |  | (In years) |
| Purchased technology |  | 4 |
| Customer contracts and related relationships |  | 3 |
| Order backlog |  | 1 |
| Trade names |  | 8 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-22-000029:notes:45]
[same as prior period, unchanged from 0001730168-21-000123:notes:54]

[0001730168-22-000029:notes:46]
Diluted shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”), in-the-money stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), (collectively referred to as “equity awards”), as well as Mandatory Convertible Preferred Stock, as defined in Note 7. “Stockholders’ Equity.” Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-22-000029:notes:47]
[same as prior period, unchanged from 0001730168-21-000123:notes:56]

[0001730168-22-000029:notes:48]
For each of the fiscal quarters ended January 30, 2022 and January 31, 2021, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-22-000029:notes:49]
[same as prior period, unchanged from 0001730168-21-000123:notes:58]

[0001730168-22-000029:notes:50]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | January 31,2021 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,472 |  |  | $ | 1,378 |  |  |  |  |  |
| Dividends on preferred stock |  | (74) |  |  | (74) |  |  |  |  |  |
| Net income attributable to common stock |  | $ | 2,398 |  |  | $ | 1,304 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 412 |  |  | 407 |  |  |  |  |  |
| Dilutive effect of equity awards |  | 17 |  |  | 21 |  |  |  |  |  |
| Weighted-average shares outstanding - diluted |  | 429 |  |  | 428 |  |  |  |  |  |

[0001730168-22-000029:notes:51]
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.82 |  |  | $ | 3.20 |  |  |  |  |  |
| Diluted |  | $ | 5.59 |  |  | $ | 3.05 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-22-000029:notes:52]
Borrowings

[0001730168-22-000029:notes:53]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | $ | 3,250 |  |  | $ | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,965 |  |  | 1,965 |  |
|  |  |  |  | 2,717 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,679 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,684 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,020 |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 1,086 |  |  | 1,086 |  |
|  |  |  |  | 2,106 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 944 |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,958 |  |  | 1,958 |  |
|  |  |  |  | 3,524 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |

[0001730168-22-000029:notes:54]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 265 |  |  | 265 |  |
|  |  |  |  | 408 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,244 |  |  | 41,499 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,803) |  |  | (1,834) |  |
| Total debt |  |  |  | $ | 39,441 |  |  | $ | 39,665 |  |

[0001730168-22-000029:notes:55]
As of January 30, 2022 and October 31, 2021, short-term finance lease liabilities of $31 million and $26 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $33 million and $39 million, respectively, were included in long-term debt.

[0001730168-22-000029:notes:56]
January 2021 Credit Agreement

[0001730168-22-000029:notes:57]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either January 30, 2022 or October 31, 2021.

[0001730168-22-000029:notes:58]
Commercial Paper

[0001730168-22-000029:notes:59]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. We had no Commercial Paper outstanding at either January 30, 2022 or October 31, 2021.

[0001730168-22-000029:notes:60]
Fair Value of Debt

[0001730168-22-000029:notes:61]
As of January 30, 2022, the estimated aggregate fair value of debt was $41,558 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-22-000029:notes:62]
Future Principal Payments of Debt

[0001730168-22-000029:notes:63]
The future scheduled principal payments of debt as of January 30, 2022 were as follows:

[0001730168-22-000029:notes:64]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 9 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,515 |  |
| 2026 |  | 2,596 |  |
| Thereafter |  | 35,158 |  |
| Total |  | $ | 41,244 |  |

[0001730168-22-000029:notes:65]
As of January 30, 2022 and October 31, 2021, we accrued interest payable of $417 million and $282 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-22-000029:notes:66]
[same as prior period, unchanged from 0001730168-21-000123:notes:82]

[0001730168-22-000029:notes:67]
[same as prior period, unchanged from 0001730168-21-000123:notes:83]

[0001730168-22-000029:notes:68]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of January 30, 2022, the minimum conversion rate was 3.0894 and the maximum conversion rate was 3.6109.

[0001730168-22-000029:notes:69]
We recognized $26 million and $27 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets as of January 30, 2022 and October 31, 2021, respectively.

[0001730168-22-000029:notes:70]
[same as prior period, unchanged from 0001730168-21-000123:notes:87]

[0001730168-22-000029:notes:71]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | January 31,2021 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 4.10 |  |  | $ | 3.60 |  |  |  |  |  |
| Dividends to common stockholders |  | $ | 1,689 |  |  | $ | 1,468 |  |  |  |  |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |  |  |  |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | 75 |  |  |  |  |  |

[0001730168-22-000029:notes:72]
Stock Repurchase Program

[0001730168-22-000029:notes:73]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. During the fiscal quarter ended January 30, 2022, we repurchased and retired approximately 4 million shares of our common stock for $2,724 million under this stock repurchase program.

[0001730168-22-000029:notes:74]
Repurchases under our stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-22-000029:notes:75]
[same as prior period, unchanged from 0001730168-21-000123:notes:89]

[0001730168-22-000029:notes:76]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | January 31,2021 |  |  |  |  |
|  |  | (In millions) |
| Cost of products sold |  | $ | 18 |  |  | $ | 20 |  |  |  |  |  |
| Cost of subscriptions and services |  | 18 |  |  | 12 |  |  |  |  |  |
| Research and development |  | 268 |  |  | 328 |  |  |  |  |  |
| Selling, general and administrative |  | 83 |  |  | 84 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 387 |  |  | $ | 444 |  |  |  |  |  |

[0001730168-22-000029:notes:77]
As of January 30, 2022, the total unrecognized compensation cost related to unvested stock-based awards was $2,692 million, which is expected to be recognized over the remaining weighted-average service period of 2.8 years.

[0001730168-22-000029:notes:78]
[same as prior period, unchanged from 0001730168-21-000123:notes:92]

[0001730168-22-000029:notes:79]
[same as prior period, unchanged from 0001730168-21-000123:notes:94]

[0001730168-22-000029:notes:80]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 31, 2021 |  | 23 |  |  | $ | 200.38 |  |  |  |  |  |
| Granted |  | 1 |  |  | $ | 453.96 |  |  |  |  |  |
| Vested |  | (2) |  |  | $ | 226.39 |  |  |  |  |  |
| Forfeited |  | — |  | * | $ | 234.59 |  |  |  |  |  |
| Balance as of January 30, 2022 |  | 22 |  |  | $ | 201.93 |  |  |  |  |  |

[0001730168-22-000029:notes:81]
* Represents fewer than 1 million shares.

[0001730168-22-000029:notes:82]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended January 30, 2022 was $1,076 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-22-000029:notes:83]
Income Taxes
The provision for income taxes was $215 million and $6 million for the fiscal quarters ended January 30, 2022 and January 31, 2021, respectively. The increase was primarily due to higher income before income taxes and a shift in jurisdictional mix of income and expenses. The provision for income taxes for the fiscal quarter ended January 31, 2021 was substantially offset by excess tax benefits from stock-based awards and benefits from lapses of statutes of limitations and audit settlements.

[0001730168-22-000029:notes:84]
As of January 30, 2022, we had $5,038 million of gross unrecognized tax benefits, of which all, if recognized, would favorably impact the effective tax rate. It is possible that our existing unrecognized tax benefits may change up to $271 million as a result of lapses of the statute of limitations for certain audit periods and/or anticipated closure of audit examinations within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-22-000029:notes:85]
[same as prior period, unchanged from 0001730168-21-000123:notes:107]

[0001730168-22-000029:notes:86]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment has separate financial information that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-22-000029:notes:87]
[same as prior period, unchanged from 0001730168-21-000123:notes:109]

[0001730168-22-000029:notes:88]
Infrastructure software. We provide a portfolio of software solutions that enables customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical FC SAN products and related software.

[0001730168-22-000029:notes:89]
[same as prior period, unchanged from 0001730168-21-000123:notes:111]

[0001730168-22-000029:notes:90]
[same as prior period, unchanged from 0001730168-21-000123:notes:113]

[0001730168-22-000029:notes:91]
[same as prior period, unchanged from 0001730168-21-000123:notes:114]

[0001730168-22-000029:notes:92]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue in either of the fiscal quarters ended January 30, 2022 or January 31, 2021. The accounting policies of the segments are the same as those described in the “Summary of Significant Accounting Policies” included in the Annual Report on Form 10-K for fiscal year 2021.

[0001730168-22-000029:notes:93]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 30,2022 |  | January 31,2021 |  |  |  |  |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 5,873 |  |  | $ | 4,908 |  |  |  |  |  |
| Infrastructure software |  | 1,833 |  |  | 1,747 |  |  |  |  |  |
| Total net revenue |  | $ | 7,706 |  |  | $ | 6,655 |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 3,349 |  |  | $ | 2,561 |  |  |  |  |  |
| Infrastructure software |  | 1,307 |  |  | 1,219 |  |  |  |  |  |
| Unallocated expenses |  | (1,548) |  |  | (1,943) |  |  |  |  |  |
| Total operating income |  | $ | 3,108 |  |  | $ | 1,837 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-22-000029:notes:94]
Commitments and Contingencies
Commitments

[0001730168-22-000029:notes:95]
The following table summarizes contractual obligations and commitments as of January 30, 2022 that materially changed from the end of fiscal year 2021:

[0001730168-22-000029:notes:96]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 126 |  |  | $ | 698 |  |
| 2023 |  | 146 |  |  | 181 |  |
| 2024 |  | 80 |  |  | 122 |  |
| 2025 |  | 60 |  |  | 25 |  |
| 2026 |  | — |  |  | 49 |  |
| Thereafter |  | — |  |  | 2 |  |
| Total |  | $ | 412 |  |  | $ | 1,077 |  |

[0001730168-22-000029:notes:97]
Purchase Commitments. Represent unconditional purchase obligations that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. These commitments include agreements to purchase inventory and other goods or services. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-22-000029:notes:98]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-22-000029:notes:99]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 30, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,366 million of unrecognized tax benefits and accrued interest and penalties classified within other long-term liabilities on our condensed consolidated balance sheet as of January 30, 2022 have been excluded from the table above.

[0001730168-22-000029:notes:100]
Contingencies

[0001730168-22-000029:notes:101]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-22-000029:notes:102]
Lawsuits Relating to California Institute of Technology

[0001730168-22-000029:notes:103]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District

[0001730168-22-000029:notes:104]
Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. The Federal Circuit Court issued its decision on February 4, 2022. While the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. Broadcom and Apple anticipate filing a petition for rehearing with the Federal Circuit Court by April 6, 2022.

[0001730168-22-000029:notes:105]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We do not believe a material loss is probable or estimable at this time. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a possible rehearing by the Federal Circuit Court, retrial at the lower court and further appeals) could significantly change the assessment of damages.

[0001730168-22-000029:notes:106]
Other Matters

[0001730168-22-000029:notes:107]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-22-000029:notes:108]
Contingency Assessment

[0001730168-22-000029:notes:109]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-22-000029:notes:110]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-22-000029:notes:111]
Other Indemnifications

[0001730168-22-000029:notes:112]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-22-000029:notes:113]
Restructuring Charges From time to time, we initiate cost reduction activities to integrate acquired businesses, to align our workforce with strategic business activities, or to improve efficiencies in our operations. In the first quarter of fiscal years 2022 and 2021, we recognized $19 million and $75 million of restructuring expense, respectively. These charges, which were primarily recognized in operating expenses, included employee termination and lease and other exit costs in fiscal year 2022 and primarily related to employee termination costs in fiscal year 2021.
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the fiscal quarter ended January 30, 2022:

[0001730168-22-000029:notes:114]
|  |  | Employee Termination Costs |  | Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 31, 2021 |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Restructuring charges |  | 10 |  |  | 1 |  |  | 11 |  |
| Utilization |  | (9) |  |  | (1) |  |  | (10) |  |
| Balance as of January 30, 2022 (a) |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |

[0001730168-22-000029:notes:115]
[same as prior period, unchanged from 0001730168-21-000123:notes:147]

[0001730168-22-000029:notes:116]
(a) We expect the majority of the employee termination costs balance to be paid within the next six months.

[0001730168-22-000029:notes:117]
Restructuring, impairment and disposal charges for the fiscal quarter ended January 30, 2022 included $8 million for the write-down of certain lease-related right-of-use assets and other lease-related charges. As of January 30, 2022, short-term and long-term lease liabilities included $43 million of liabilities related to restructuring activities.


## us-gaap:SubsequentEventsTextBlock

[0001730168-22-000029:notes:118]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-22-000029:notes:119]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2022 to stockholders of record on March 15, 2022.

[0001730168-22-000029:notes:120]
Common Stock Cash Dividends Declared

[0001730168-22-000029:notes:121]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on March 31, 2022 to stockholders of record on March 22, 2022.
