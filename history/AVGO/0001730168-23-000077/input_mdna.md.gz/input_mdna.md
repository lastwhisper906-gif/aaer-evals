# AVGO MD&A — 0001730168-23-000077


## mdna

[0001730168-23-000077:mdna:1]
[same as prior period, unchanged from 0001730168-23-000064:mdna:1]

[0001730168-23-000077:mdna:2]
[same as prior period, unchanged from 0001730168-23-000064:mdna:2]

[0001730168-23-000077:mdna:3]
[same as prior period, unchanged from 0001730168-23-000064:mdna:3]

[0001730168-23-000077:mdna:4]
[same as prior period, unchanged from 0001730168-23-000064:mdna:4]

[0001730168-23-000077:mdna:5]
[same as prior period, unchanged from 0001730168-23-000064:mdna:5]

[0001730168-23-000077:mdna:6]
Highlights during the fiscal quarter ended July 30, 2023 include the following:

[0001730168-23-000077:mdna:7]
•We generated $4,719 million of cash from operations.

[0001730168-23-000077:mdna:8]
•We paid $1,901 million in cash dividends.

[0001730168-23-000077:mdna:9]
•We repurchased $1,707 million of common stock.

[0001730168-23-000077:mdna:10]
[same as prior period, unchanged from 0001730168-23-000064:mdna:10]

[0001730168-23-000077:mdna:11]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. We will also assume VMware’s closing date outstanding debt.

[0001730168-23-000077:mdna:12]
[same as prior period, unchanged from 0001730168-23-000064:mdna:12]

[0001730168-23-000077:mdna:13]
[same as prior period, unchanged from 0001730168-23-000064:mdna:13]

[0001730168-23-000077:mdna:14]
[same as prior period, unchanged from 0001730168-23-000064:mdna:14]

[0001730168-23-000077:mdna:15]
[same as prior period, unchanged from 0001730168-23-000064:mdna:15]

[0001730168-23-000077:mdna:16]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion. On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provides us with the ability to borrow up to $28,390 million of term loan commitments and terminated the commitment letter entered into on May 26, 2022. The funding of the 2023 term loan commitments is dependent on the closing of the VMware Merger, and may be increased by up to $2,000 million.

[0001730168-23-000077:mdna:17]
The VMware Merger, which is expected to be completed on October 30, 2023, is subject to satisfaction or waiver of customary closing conditions, including clearance under the antitrust laws of certain jurisdictions. On October 3, 2022, we registered approximately 59 million shares of our common stock. On November 4, 2022, VMware stockholders adopted the VMware Merger Agreement. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-23-000077:mdna:18]
[same as prior period, unchanged from 0001730168-23-000064:mdna:18]

[0001730168-23-000077:mdna:19]
[same as prior period, unchanged from 0001730168-23-000064:mdna:19]

[0001730168-23-000077:mdna:20]
There were no significant changes in our critical accounting estimates during the three fiscal quarters ended July 30, 2023 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2022 Annual Report on Form 10-K.

[0001730168-23-000077:mdna:21]
[same as prior period, unchanged from 0001730168-23-000064:mdna:21]

[0001730168-23-000077:mdna:22]
Fiscal Quarter and Three Fiscal Quarters Ended July 30, 2023 Compared to Fiscal Quarter and Three Fiscal Quarters Ended July 31, 2022

[0001730168-23-000077:mdna:23]
[same as prior period, unchanged from 0001730168-23-000064:mdna:23]

[0001730168-23-000077:mdna:24]
[same as prior period, unchanged from 0001730168-23-000064:mdna:24]

[0001730168-23-000077:mdna:25]
|  |  | Fiscal Quarter Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 6,917 |  |  | $ | 6,627 |  |  | 78 | % |  | 78 | % |
| Subscriptions and services |  | 1,959 |  |  | 1,837 |  |  | 22 |  |  | 22 |  |
| Total net revenue |  | 8,876 |  |  | 8,464 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,107 |  |  | 1,921 |  |  | 24 |  |  | 23 |  |
| Cost of subscriptions and services |  | 165 |  |  | 156 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 439 |  |  | 705 |  |  | 5 |  |  | 8 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,712 |  |  | 2,783 |  |  | 31 |  |  | 33 |  |
| Gross margin |  | 6,164 |  |  | 5,681 |  |  | 69 |  |  | 67 |  |
| Research and development |  | 1,358 |  |  | 1,255 |  |  | 16 |  |  | 15 |  |
| Selling, general and administrative |  | 388 |  |  | 323 |  |  | 4 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 350 |  |  | 359 |  |  | 4 |  |  | 4 |  |
| Restructuring and other charges |  | 212 |  |  | 7 |  |  | 2 |  |  | — |  |
| Total operating expenses |  | 2,308 |  |  | 1,944 |  |  | 26 |  |  | 23 |  |
| Operating income |  | $ | 3,856 |  |  | $ | 3,737 |  |  | 43 | % |  | 44 | % |

[0001730168-23-000077:mdna:26]
|  |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 20,740 |  |  | $ | 19,097 |  |  | 78 | % |  | 79 | % |
| Subscriptions and services |  | 5,784 |  |  | 5,176 |  |  | 22 |  |  | 21 |  |
| Total net revenue |  | 26,524 |  |  | 24,273 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 6,351 |  |  | 5,488 |  |  | 24 |  |  | 22 |  |
| Cost of subscriptions and services |  | 472 |  |  | 470 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,415 |  |  | 2,142 |  |  | 5 |  |  | 9 |  |
| Restructuring charges |  | 3 |  |  | 4 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 8,241 |  |  | 8,104 |  |  | 31 |  |  | 33 |  |
| Gross margin |  | 18,283 |  |  | 16,169 |  |  | 69 |  |  | 67 |  |
| Research and development |  | 3,865 |  |  | 3,722 |  |  | 15 |  |  | 16 |  |
| Selling, general and administrative |  | 1,174 |  |  | 1,012 |  |  | 4 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 1,046 |  |  | 1,154 |  |  | 4 |  |  | 5 |  |
| Restructuring and other charges |  | 231 |  |  | 42 |  |  | 1 |  |  | — |  |
| Total operating expenses |  | 6,316 |  |  | 5,930 |  |  | 24 |  |  | 25 |  |
| Operating income |  | $ | 11,967 |  |  | $ | 10,239 |  |  | 45 | % |  | 42 | % |

[0001730168-23-000077:mdna:27]
[same as prior period, unchanged from 0001730168-23-000064:mdna:27]

[0001730168-23-000077:mdna:28]
[same as prior period, unchanged from 0001730168-23-000064:mdna:28]

[0001730168-23-000077:mdna:29]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 21% and 20% of our net revenue for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, and 18% and 19% of our net revenue for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively.

[0001730168-23-000077:mdna:30]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and three fiscal quarters ended July 30, 2023 and July 31, 2022. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 18% and 19% of our net revenue for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, and approximately 20% of our net revenue for each of the fiscal quarter and three fiscal quarters ended July 31, 2022. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-23-000077:mdna:31]
[same as prior period, unchanged from 0001730168-23-000064:mdna:31]

[0001730168-23-000077:mdna:32]
[same as prior period, unchanged from 0001730168-23-000064:mdna:32]

[0001730168-23-000077:mdna:33]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | July 30, 2023 |  | July 31, 2022 |  | $ Change |  | % Change |  | July 30, 2023 |  | July 31, 2022 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 6,941 |  |  | $ | 6,624 |  |  | $ | 317 |  |  | 5 | % |  | $ | 20,856 |  |  | $ | 18,726 |  |  | $ | 2,130 |  |  | 11 | % |
| Infrastructure software |  | 1,935 |  |  | 1,840 |  |  | 95 |  |  | 5 | % |  | 5,668 |  |  | 5,547 |  |  | 121 |  |  | 2 | % |
| Total net revenue |  | $ | 8,876 |  |  | $ | 8,464 |  |  | $ | 412 |  |  | 5 | % |  | $ | 26,524 |  |  | $ | 24,273 |  |  | $ | 2,251 |  |  | 9 | % |

[0001730168-23-000077:mdna:34]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 78 | % |  | 78 | % |  | 79 | % |  | 77 | % |
| Infrastructure software |  | 22 |  |  | 22 |  |  | 21 |  |  | 23 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-23-000077:mdna:35]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter ended July 30, 2023 compared to the prior year fiscal period due to strong product demand, primarily for networking products. The increase in the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was due to strong product demand, primarily for networking, server storage and broadband products. Net revenue from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended July 30, 2023 compared to the prior year fiscal periods primarily due to increases in sales from our mainframe solutions products, partially offset by lower demand for our FC SAN products.

[0001730168-23-000077:mdna:36]
[same as prior period, unchanged from 0001730168-23-000064:mdna:36]

[0001730168-23-000077:mdna:37]
Gross margin was $6,164 million, or 69% of net revenue, for the fiscal quarter ended July 30, 2023 compared to $5,681 million, or 67% of net revenue, for the fiscal quarter ended July 31, 2022, and $18,283 million, or 69% of net revenue, for the three fiscal quarters ended July 30, 2023 compared to $16,169 million, or 67% of net revenue, for the three fiscal quarters ended July 31, 2022.

[0001730168-23-000077:mdna:38]
The increases were primarily due to lower amortization of acquisition-related intangible assets, mainly from our 2016 acquisition of Broadcom Corporation, partially offset by less favorable margin within our semiconductor solutions segment driven primarily by product mix.

[0001730168-23-000077:mdna:39]
[same as prior period, unchanged from 0001730168-23-000064:mdna:39]

[0001730168-23-000077:mdna:40]
Research and development expense increased $103 million, or 8%, and $143 million, or 4%, for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to the prior year fiscal periods. The increases were primarily

[0001730168-23-000077:mdna:41]
[same as prior period, unchanged from 0001730168-23-000064:mdna:41]

[0001730168-23-000077:mdna:42]
due to higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values in our fiscal year ending October 29, 2023 (“fiscal year 2023”), partially offset by lower variable employee compensation expense.

[0001730168-23-000077:mdna:43]
[same as prior period, unchanged from 0001730168-23-000064:mdna:43]

[0001730168-23-000077:mdna:44]
Selling, general and administrative expense increased $65 million, or 20%, and $162 million, or 16%, for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher costs incurred in connection with the pending VMware Merger and higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values in fiscal year 2023, partially offset by lower variable employee compensation expense.

[0001730168-23-000077:mdna:45]
[same as prior period, unchanged from 0001730168-23-000064:mdna:45]

[0001730168-23-000077:mdna:46]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $108 million, or 9%, for the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period primarily due to lower amortization of customer-related intangible assets from our acquisition of LSI Corporation.

[0001730168-23-000077:mdna:47]
Restructuring and Other Charges

[0001730168-23-000077:mdna:48]
Restructuring and other charges in the fiscal quarter and three fiscal quarters ended July 30, 2023 primarily included non-recurring charges related to IP litigation.

[0001730168-23-000077:mdna:49]
[same as prior period, unchanged from 0001730168-23-000064:mdna:49]

[0001730168-23-000077:mdna:50]
Total stock-based compensation expense was $629 million and $1,533 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, and $373 million and $1,146 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. The increases were primarily due to annual employee equity awards granted at higher grant-date fair values in fiscal year 2023.

[0001730168-23-000077:mdna:51]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of July 30, 2023. The remaining weighted-average service period was 3.6 years.

[0001730168-23-000077:mdna:52]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 621 |  |
| 2024 |  | 2,245 |  |
| 2025 |  | 1,815 |  |
| 2026 |  | 1,379 |  |
| 2027 |  | 692 |  |
| Thereafter |  | 126 |  |
| Total |  | $ | 6,878 |  |

[0001730168-23-000077:mdna:53]
[same as prior period, unchanged from 0001730168-23-000064:mdna:53]

[0001730168-23-000077:mdna:54]
[same as prior period, unchanged from 0001730168-23-000064:mdna:54]

[0001730168-23-000077:mdna:55]
[same as prior period, unchanged from 0001730168-23-000064:mdna:55]

[0001730168-23-000077:mdna:56]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | July 30,2023 |  | July 31,2022 |  | $ Change |  | % Change |  | July 30, 2023 |  | July 31, 2022 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,092 |  |  | $ | 3,916 |  |  | $ | 176 |  |  | 4 | % |  | $ | 12,215 |  |  | $ | 10,891 |  |  | $ | 1,324 |  |  | 12 | % |
| Infrastructure software |  | 1,444 |  |  | 1,283 |  |  | 161 |  |  | 13 | % |  | 4,163 |  |  | 3,903 |  |  | 260 |  |  | 7 | % |
| Unallocated expenses |  | (1,680) |  |  | (1,462) |  |  | (218) |  |  | 15 | % |  | (4,411) |  |  | (4,555) |  |  | 144 |  |  | (3) | % |
| Total operating income |  | $ | 3,856 |  |  | $ | 3,737 |  |  | $ | 119 |  |  | 3 | % |  | $ | 11,967 |  |  | $ | 10,239 |  |  | $ | 1,728 |  |  | 17 | % |

[0001730168-23-000077:mdna:57]
Operating income from our semiconductor solutions segment increased in the fiscal quarter ended July 30, 2023 compared to the prior year fiscal period primarily due to higher net revenue from networking products, and increased in the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period primarily due to higher net revenue from networking, server storage, and broadband products. Operating income from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended July 30, 2023 compared to the prior year fiscal periods primarily due to higher net revenue from our mainframe solutions products, partially offset by lower net revenue from our FC SAN products.

[0001730168-23-000077:mdna:58]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 15% for the fiscal quarter ended July 30, 2023 compared to the prior year fiscal period primarily due to higher stock-based compensation expense and non-recurring charges related to IP litigation, partially offset by lower amortization of acquisition related intangible assets. Unallocated expenses decreased 3% for the three fiscal quarters ended July 30, 2023, compared to the prior year fiscal period, due to lower amortization of acquisition-related intangible assets, partially offset by higher stock-based compensation expense, non-recurring charges related to IP litigation, and acquisition-related costs.

[0001730168-23-000077:mdna:59]
[same as prior period, unchanged from 0001730168-23-000064:mdna:59]

[0001730168-23-000077:mdna:60]
Interest expense. Interest expense was $406 million and $1,217 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to $406 million and $1,331 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. The decrease for the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was primarily due to losses on extinguishment of debt related to debt transactions incurred in the prior year fiscal period. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the pending VMware Merger.

[0001730168-23-000077:mdna:61]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $124 million and $380 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to other income, net, of $6 million and other expense, net of $94 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. The changes were primarily due to higher interest income as a result of higher interest rates and changes in investment gains or losses.

[0001730168-23-000077:mdna:62]
Provision for income taxes. The provision for income taxes was $271 million and $572 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to $263 million and $678 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. The increase for the fiscal quarter ended July 30, 2023 compared to the prior year fiscal period was primarily due to higher income before income taxes, substantially offset by an increase in excess tax benefits from stock-based awards. The decrease for the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was primarily due to an increase in the recognition of uncertain tax benefits as a result of lapses of statutes of limitations and an increase in excess tax benefits from stock-based awards, partially offset by higher income before income taxes.

[0001730168-23-000077:mdna:63]
[same as prior period, unchanged from 0001730168-23-000064:mdna:63]

[0001730168-23-000077:mdna:64]
[same as prior period, unchanged from 0001730168-23-000064:mdna:64]

[0001730168-23-000077:mdna:65]
Our primary sources of liquidity as of July 30, 2023 consisted of: (i) $12,055 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-23-000077:mdna:66]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including the pending VMware Merger, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $40,958 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2023 as compared to fiscal year 2022. Our debt and liquidity needs will increase as a result of the pending VMware Merger, and we intend to fund the cash portion of the consideration with the committed term loan proceeds from the 2023 Credit Agreement.

[0001730168-23-000077:mdna:67]
We believe that our cash and cash equivalents on hand, cash flows from operations, our revolving credit facility, as well as the committed term loan proceeds from the 2023 Credit Agreement related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-23-000077:mdna:68]
[same as prior period, unchanged from 0001730168-23-000064:mdna:68]

[0001730168-23-000077:mdna:69]
[same as prior period, unchanged from 0001730168-23-000064:mdna:69]

[0001730168-23-000077:mdna:70]
[same as prior period, unchanged from 0001730168-23-000064:mdna:70]

[0001730168-23-000077:mdna:71]
Working capital decreased to $10,988 million at July 30, 2023 from $11,452 million at October 30, 2022. The decrease was primarily attributable to the following:

[0001730168-23-000077:mdna:72]
•Current portion of long-term debt increased to $1,119 million at July 30, 2023 from $440 million at October 30, 2022 due to certain debt instruments becoming due within the next twelve months, partially offset by a repayment.

[0001730168-23-000077:mdna:73]
•Cash and cash equivalents decreased to $12,055 million at July 30, 2023 from $12,416 million at October 30, 2022, primarily due to $5,741 million of dividend payments, $5,701 million of common stock repurchases, $1,407 million of employee withholding tax payments related to net settled equity awards, $347 million of capital expenditures, and a $260 million debt payment, substantially offset by $13,257 million in net cash provided by operating activities.

[0001730168-23-000077:mdna:74]
[same as prior period, unchanged from 0001730168-23-000064:mdna:75]

[0001730168-23-000077:mdna:75]
•Employee compensation and benefits decreased to $831 million at July 30, 2023 from $1,202 million at October 30, 2022, primarily due to the timing of employee bonus plan payments.

[0001730168-23-000077:mdna:76]
•Other current assets increased to $1,522 million at July 30, 2023 from $1,205 million at October 30, 2022, primarily due to an increase in contract assets, purchases of short-term investments and an increase in fair value of derivatives, offset in part by a decrease in prepaid income taxes.

[0001730168-23-000077:mdna:77]
[same as prior period, unchanged from 0001730168-23-000064:mdna:79]

[0001730168-23-000077:mdna:78]
|  |  | Three Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 13.80 |  |  | $ | 12.30 |  |
| Dividends to common stockholders |  | $ | 5,741 |  |  | $ | 5,026 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 60.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 224 |  |

[0001730168-23-000077:mdna:79]
[same as prior period, unchanged from 0001730168-23-000064:mdna:81]

[0001730168-23-000077:mdna:80]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2022, which was subsequently extended to December 31, 2023. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023 (the “May 2022 Authorization”). As of July 30, 2023, $7,299 million of the authorized amount remained available for repurchases.

[0001730168-23-000077:mdna:81]
During the three fiscal quarters ended July 30, 2023 and July 31, 2022, we repurchased and retired approximately 9 million and 12 million shares of our common stock for $5,701 million and $7,000 million, respectively, under these stock repurchase programs.

[0001730168-23-000077:mdna:82]
[same as prior period, unchanged from 0001730168-23-000064:mdna:84]

[0001730168-23-000077:mdna:83]
During the three fiscal quarters ended July 30, 2023 and July 31, 2022, we paid approximately $1,407 million and $1,181 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the three fiscal quarters ended July 30, 2023 and July 31, 2022.

[0001730168-23-000077:mdna:84]
[same as prior period, unchanged from 0001730168-23-000064:mdna:86]

[0001730168-23-000077:mdna:85]
|  |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 13,257 |  |  | $ | 12,153 |  |
| Net cash used in investing activities |  | (565) |  |  | (539) |  |
| Net cash used in financing activities |  | (13,053) |  |  | (13,800) |  |
| Net change in cash and cash equivalents |  | $ | (361) |  |  | $ | (2,186) |  |

[0001730168-23-000077:mdna:86]
[same as prior period, unchanged from 0001730168-23-000064:mdna:88]

[0001730168-23-000077:mdna:87]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,104 million increase in cash provided by operations during the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was primarily due to $2,422 million higher net income and a $624 million increase resulting from changes in operating assets and liabilities, offset in part by $1,942 million lower non-cash adjustments including deferred taxes and other non-cash taxes, and amortization of intangible assets.

[0001730168-23-000077:mdna:88]
[same as prior period, unchanged from 0001730168-23-000064:mdna:90]

[0001730168-23-000077:mdna:89]
Cash flows from investing activities primarily consisted of capital expenditures, proceeds and payments related to investments and cash used for acquisitions. The $26 million increase in cash used in investing activities during the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was primarily due to a $214 million increase in purchases of investments, net of proceeds from sales of investments, substantially offset by a $222 million decrease in cash paid for acquisitions.

[0001730168-23-000077:mdna:90]
[same as prior period, unchanged from 0001730168-23-000064:mdna:92]

[0001730168-23-000077:mdna:91]
Cash flows from financing activities primarily consisted of our stock repurchases, dividend payments, proceeds and payments related to our long-term borrowings, and employee withholding tax payments related to net settled equity awards. The $747 million decrease in cash used in financing activities during the three fiscal quarters ended July 30, 2023 compared to the prior year fiscal period was primarily due to a $2,092 million decrease in payments on debt obligations and a $1,299 million decrease in stock repurchases, offset in part by a $1,935 million decrease in proceeds from long-term borrowings and a $491 million increase in dividend payments.

[0001730168-23-000077:mdna:92]
[same as prior period, unchanged from 0001730168-23-000064:mdna:94]

[0001730168-23-000077:mdna:93]
[same as prior period, unchanged from 0001730168-23-000064:mdna:95]
