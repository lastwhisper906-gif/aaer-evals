# AVGO note change history — 0001730168-23-000064 → 0001730168-23-000077


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:1]
The following table summarizes contractual obligations and commitments as of July 30, 2023:
  (was, 2023-06-07, similarity 0.9595):
[0001730168-23-000064:note_history:1]
The following table summarizes contractual obligations and commitments as of April 30, 2023:

- changed (2023-09-06):
[0001730168-23-000077:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of July 30, 2023, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,885 million of unrecognized tax benefits and accrued interest and penalties as of July 30, 2023 have been excluded from the table above.
  (was, 2023-06-07, similarity 0.9054):
[0001730168-23-000064:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of April 30, 2023, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,841 million of unrecognized tax benefits and accrued interest and penalties as of April 30, 2023 have been excluded from the table above.

- changed (2023-09-06):
[0001730168-23-000077:note_history:3]
enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”). In February 2022, the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, but it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. In May 2022, the Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court. Subsequently, Caltech withdrew its infringement allegations as to the 7,916,781 patent. On July 7, 2023, the parties informed the U.S. Central District Court that they have entered into settlement discussions and requested that the U.S. Central District Court stay the case pending execution of a final settlement agreement.
  (was, 2023-06-07, similarity 0.8513):
[0001730168-23-000064:note_history:3]
enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”). In February 2022, the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, but it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. In May 2022, the Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court. Subsequently, Caltech withdrew its infringement allegations as to the 7,916,781 patent.

- added (2023-09-06):
[0001730168-23-000077:note_history:4]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. The ultimate outcome of the case has not yet been determined as the U.S. Central District Court has stayed the retrial pending a final settlement agreement and a number of factors could significantly change the assessment of damages. In the fiscal quarter ended July 30, 2023, we accrued our best estimate to restructuring and other charges in the condensed consolidated statements of operations.

- removed (2023-09-06):
[0001730168-23-000064:note_history:5]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a retrial at the lower court and further appeals) could significantly change the assessment of damages. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 29, 2023 (“fiscal year 2023”) is a 52-week fiscal year. The first quarter of our fiscal year 2023 ended on January 29, 2023, the second quarter ended on April 30, 2023 and the third quarter ended on July 30, 2023. Our fiscal year ended October 30, 2022 (“fiscal year 2022”) was also a 52-week fiscal year.
  (was, 2023-06-07, similarity 0.9967):
[0001730168-23-000064:note_history:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 29, 2023 (“fiscal year 2023”) is a 52-week fiscal year. The first quarter of our fiscal year 2023 ended on January 29, 2023, the second quarter ended on April 30, 2023 and the third quarter ends on July 30, 2023. Our fiscal year ended October 30, 2022 (“fiscal year 2022”) was also a 52-week fiscal year.

- changed (2023-09-06):
[0001730168-23-000077:note_history:7]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 30, 2022 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2022 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended July 30, 2023 are not necessarily indicative of the results that may be expected for fiscal year 2023, or for any other future period.
  (was, 2023-06-07, similarity 0.9016):
[0001730168-23-000064:note_history:7]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 30, 2022 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2022 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended April 30, 2023 are not necessarily indicative of the results that may be expected for fiscal year 2023, or for any other future period.

- changed (2023-09-06):
[0001730168-23-000077:note_history:8]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from those estimates, and such differences could affect the results of operations reported in future periods.
  (was, 2023-06-07, similarity 0.7513):
[0001730168-23-000064:note_history:8]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic, and many of these estimates could require increased judgment and carry a higher degree of variability and volatility. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:9]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
  (was, 2023-06-07, similarity 0.9983):
[0001730168-23-000064:note_history:9]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:10]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 42 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,119 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 8 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,667) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,222 |  |  | $ | 39,075 |  |
  (was, 2023-06-07, similarity 0.9958):
[0001730168-23-000064:note_history:10]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 40 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,117 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 12 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,699) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,194 |  |  | $ | 39,075 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:11]
2021 Credit Agreement
  (was, 2023-06-07, similarity 0.9412):
[0001730168-23-000064:note_history:11]
Credit Agreement

- changed (2023-09-06):
[0001730168-23-000077:note_history:12]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either July 30, 2023 or October 30, 2022.
  (was, 2023-06-07, similarity 0.9664):
[0001730168-23-000064:note_history:12]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either April 30, 2023 or October 30, 2022.

- changed (2023-09-06):
[0001730168-23-000077:note_history:13]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either July 30, 2023 or October 30, 2022.
  (was, 2023-06-07, similarity 0.9946):
[0001730168-23-000064:note_history:13]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either April 30, 2023 or October 30, 2022.

- changed (2023-09-06):
[0001730168-23-000077:note_history:14]
As of July 30, 2023, the estimated aggregate fair value of debt was $35,072 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2023-06-07, similarity 0.9811):
[0001730168-23-000064:note_history:14]
As of April 30, 2023, the estimated aggregate fair value of debt was $35,573 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2023-09-06):
[0001730168-23-000077:note_history:15]
The future scheduled principal payments of debt as of July 30, 2023 were as follows:
  (was, 2023-06-07, similarity 0.956):
[0001730168-23-000064:note_history:15]
The future scheduled principal payments of debt as of April 30, 2023 were as follows:

- changed (2023-09-06):
[0001730168-23-000077:note_history:16]
As of July 30, 2023 and October 30, 2022, we were in compliance with all debt covenants.
  (was, 2023-06-07, similarity 0.9548):
[0001730168-23-000064:note_history:16]
As of April 30, 2023 and October 30, 2022, we were in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:17]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
  (was, 2023-06-07, similarity 0.9983):
[0001730168-23-000064:note_history:17]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:18]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 42 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,119 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 8 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,667) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,222 |  |  | $ | 39,075 |  |
  (was, 2023-06-07, similarity 0.9958):
[0001730168-23-000064:note_history:18]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 40 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,117 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 12 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,699) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,194 |  |  | $ | 39,075 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:19]
The future scheduled principal payments of debt as of July 30, 2023 were as follows:
  (was, 2023-06-07, similarity 0.956):
[0001730168-23-000064:note_history:19]
The future scheduled principal payments of debt as of April 30, 2023 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:20]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services (a) |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |
  (was, 2023-06-07, similarity 0.9924):
[0001730168-23-000064:note_history:20]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:21]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |
  (was, 2023-06-07, similarity 0.9863):
[0001730168-23-000064:note_history:21]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services (a) |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:22]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services (a) |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |
  (was, 2023-06-07, similarity 0.9835):
[0001730168-23-000064:note_history:22]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:23]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |
  (was, 2023-06-07, similarity 0.9776):
[0001730168-23-000064:note_history:23]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services (a) |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:24]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable that we will collect substantially all of the consideration to which we are entitled. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
  (was, 2023-06-07, similarity 0.9864):
[0001730168-23-000064:note_history:24]
Revenue from Contracts with Customers We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable that we will collect substantially all of the consideration to which we are entitled. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
Disaggregation

- added (2023-09-06):
[0001730168-23-000077:note_history:25]
Disaggregation

- changed (2023-09-06):
[0001730168-23-000077:note_history:26]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services (a) |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |
  (was, 2023-06-07, similarity 0.9924):
[0001730168-23-000064:note_history:26]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:27]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |
  (was, 2023-06-07, similarity 0.9863):
[0001730168-23-000064:note_history:27]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services (a) |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:28]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services (a) |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |
  (was, 2023-06-07, similarity 0.9835):
[0001730168-23-000064:note_history:28]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:29]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |
  (was, 2023-06-07, similarity 0.9776):
[0001730168-23-000064:note_history:29]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services (a) |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:30]
|  |  | July 30,2023 |  | October 30,2022 |
|  | (In millions) |
| Contract Assets |  | $ | 652 |  |  | $ | 128 |  |
| Contract Liabilities |  | $ | 3,256 |  |  | $ | 3,341 |  |
  (was, 2023-06-07, similarity 0.9753):
[0001730168-23-000064:note_history:30]
|  |  | April 30,2023 |  | October 30,2022 |
|  | (In millions) |
| Contract Assets |  | $ | 401 |  |  | $ | 128 |  |
| Contract Liabilities |  | $ | 3,793 |  |  | $ | 3,341 |  |

- changed (2023-09-06):
[0001730168-23-000077:note_history:31]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended July 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,677 million. The amount of revenue recognized during the three fiscal quarters ended July 31, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $2,482 million.
  (was, 2023-06-07, similarity 0.9898):
[0001730168-23-000064:note_history:31]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended April 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,287 million. The amount of revenue recognized during the two fiscal quarters ended May 1, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,974 million.

- changed (2023-09-06):
[0001730168-23-000077:note_history:32]
Certain multi-year customer contracts, primarily in our semiconductor solutions segment, contain firmly committed amounts and the remaining performance obligations under these contracts as of July 30, 2023 were approximately $21.4 billion. We expect approximately 27% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2023-06-07, similarity 0.9248):
[0001730168-23-000064:note_history:32]
Certain multi-year customer contracts primarily in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of April 30, 2023 were approximately $21.4 billion. We expect approximately 27% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0001730168-23-000077:note_history:33]
On August 30, 2023, our Board of Directors declared a quarterly cash dividend of $4.60 per share on our common stock, payable on September 29, 2023 to stockholders of record on September 21, 2023.
  (was, 2023-06-07, similarity 0.9145):
[0001730168-23-000064:note_history:33]
On May 31, 2023, our Board of Directors declared a quarterly cash dividend of $4.60 per share on our common stock, payable on June 30, 2023 to stockholders of record on June 22, 2023.
