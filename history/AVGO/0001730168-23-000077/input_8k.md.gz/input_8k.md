# AVGO 8-K — 0001730168-23-000074 filed 2023-08-31

## item codes, every 8-K on or before 2023-09-06

- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2023-09-06

- none on or before 2023-09-06

## item 2.02 — earnings release, exhibit 99.1

[0001730168-23-000074:8k_2_02:1]
EX-99.1
2
avgo-07302023x8kxex99.htm
EX-99.1

[0001730168-23-000074:8k_2_02:2]
Document

[0001730168-23-000074:8k_2_02:3]
Exhibit 99.1

[0001730168-23-000074:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2023 Financial Results and Quarterly Dividend

[0001730168-23-000074:8k_2_02:5]
•Revenue of $8,876 million for the third quarter, up 5 percent from the prior year period

[0001730168-23-000074:8k_2_02:6]
•Adjusted EBITDA of $5,801 million for the third quarter

[0001730168-23-000074:8k_2_02:7]
•Non-GAAP diluted EPS of $10.54 for the third quarter; GAAP diluted EPS of $7.74 for the third quarter

[0001730168-23-000074:8k_2_02:8]
•Quarterly common stock dividend of $4.60 per share

[0001730168-23-000074:8k_2_02:9]
•Repurchased and eliminated 2.9 million shares for $2,167 million

[0001730168-23-000074:8k_2_02:10]
•Fourth quarter revenue guidance of approximately $9.27 billion, an increase of 4 percent from the prior year period

[0001730168-23-000074:8k_2_02:11]
•Fourth quarter Adjusted EBITDA guidance of approximately 65 percent of projected revenue (1)

[0001730168-23-000074:8k_2_02:12]
SAN JOSE, Calif. – August 31, 2023 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2023, ended July 30, 2023, provided guidance for the fourth quarter of its fiscal year 2023 and announced its quarterly dividend.

[0001730168-23-000074:8k_2_02:13]
“Broadcom’s third quarter results were driven by demand for next generation networking technologies as hyperscale customers scale out and network their AI clusters within data centers,” said Hock Tan, President and CEO of Broadcom Inc. “Our fourth quarter outlook projects year-over-year growth, reflecting continued leadership in networking for generative AI.”

[0001730168-23-000074:8k_2_02:14]
“Consolidated revenue for the third quarter grew 5% year-over-year to $8.9 billion and adjusted EBITDA increased 8% year-over-year to 65% of revenue,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $4.6 billion in free cash flow in the third quarter, and expect cash flows to remain solid for Q4.”

[0001730168-23-000074:8k_2_02:15]
Third Quarter Fiscal Year 2023 Financial Highlights

[0001730168-23-000074:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q3 23 |  | Q3 22 |  | Change |  | Q3 23 |  | Q3 22 |  | Change |
| Net revenue |  | $ | 8,876 |  |  | $ | 8,464 |  |  | +5 | % |  | $ | 8,876 |  |  | $ | 8,464 |  |  | +5 | % |
| Net income |  | $ | 3,303 |  |  | $ | 3,074 |  |  | +$229 |  |  | $ | 4,596 |  |  | $ | 4,241 |  |  | +$355 |  |
| Earnings per common share - diluted |  | $ | 7.74 |  |  | $ | 7.15 |  |  | +$0.59 |  |  | $ | 10.54 |  |  | $ | 9.73 |  |  | +$0.81 |  |

[0001730168-23-000074:8k_2_02:17]
________________________________

[0001730168-23-000074:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-23-000074:8k_2_02:19]
1

[0001730168-23-000074:8k_2_02:20]
| (Dollars in millions) |  | Q3 23 |  | Q3 22 |  | Change |  |
| Cash flow from operations |  | $ | 4,719 |  |  | $ | 4,424 |  |  | +$295 |  |
| Adjusted EBITDA |  | $ | 5,801 |  |  | $ | 5,378 |  |  | +$423 |  |
| Free cash flow |  | $ | 4,597 |  |  | $ | 4,308 |  |  | +$289 |  |

[0001730168-23-000074:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 23 |  |  |  | Q3 22 |  | Change |  |
| Semiconductor solutions |  | $ | 6,941 |  |  | 78 | % |  |  |  |  |  |  | $ | 6,624 |  |  | 78 | % |  | +5 | % |  |
| Infrastructure software |  | 1,935 |  |  | 22 |  |  |  |  |  |  |  | 1,840 |  |  | 22 |  |  | +5 | % |  |
| Total net revenue |  | $ | 8,876 |  |  | 100 | % |  |  |  |  |  |  | $ | 8,464 |  |  | 100 | % |  |  |  |  |

[0001730168-23-000074:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $12,055 million, compared to $11,553 million at the end of the prior quarter.

[0001730168-23-000074:8k_2_02:23]
During the third fiscal quarter, the Company generated $4,719 million in cash from operations and spent $122 million on capital expenditures. The Company spent $2,167 million on share repurchases and eliminations, consisting of $1,707 million in repurchases of 2.4 million shares and $460 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 0.5 million shares withheld).

[0001730168-23-000074:8k_2_02:24]
On June 30, 2023, the Company paid a cash dividend of $4.60 per share, totaling $1,901 million.

[0001730168-23-000074:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-23-000074:8k_2_02:26]
Fourth Quarter Fiscal Year 2023 Business Outlook

[0001730168-23-000074:8k_2_02:27]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2023, ending October 29, 2023, is expected to be as follows:

[0001730168-23-000074:8k_2_02:28]
•Fourth quarter revenue guidance of approximately $9.27 billion; and

[0001730168-23-000074:8k_2_02:29]
•Fourth quarter Adjusted EBITDA guidance of approximately 65 percent of projected revenue.

[0001730168-23-000074:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000074:8k_2_02:31]
Quarterly Dividends

[0001730168-23-000074:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend of $4.60 per share. The dividend is payable on September 29, 2023 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 21, 2023.

[0001730168-23-000074:8k_2_02:33]
Financial Results Conference Call

[0001730168-23-000074:8k_2_02:34]
2

[0001730168-23-000074:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the third quarter fiscal year 2023 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-23-000074:8k_2_02:36]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-23-000074:8k_2_02:37]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BIab1222c9ed364122895c0b8a81ef898b. Upon registering, you will be emailed a link to the dial-in number and unique PIN.

[0001730168-23-000074:8k_2_02:38]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom's website at https://investors.broadcom.com/.

[0001730168-23-000074:8k_2_02:39]
Non-GAAP Financial Measures

[0001730168-23-000074:8k_2_02:40]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-23-000074:8k_2_02:41]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-23-000074:8k_2_02:42]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-23-000074:8k_2_02:43]
About Broadcom Inc.

[0001730168-23-000074:8k_2_02:44]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure

[0001730168-23-000074:8k_2_02:45]
3

[0001730168-23-000074:8k_2_02:46]
software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-23-000074:8k_2_02:47]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-23-000074:8k_2_02:48]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; failing to complete or realize the expected benefits of our acquisition of VMware, Inc.; any acquisitions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase programs; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to protect against cyber security threats and a breach of security systems; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our

[0001730168-23-000074:8k_2_02:49]
4

[0001730168-23-000074:8k_2_02:50]
products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; the COVID-19 pandemic; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-23-000074:8k_2_02:51]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-23-000074:8k_2_02:52]
Contact:

[0001730168-23-000074:8k_2_02:53]
Ji Yoo

[0001730168-23-000074:8k_2_02:54]
Broadcom Inc.

[0001730168-23-000074:8k_2_02:55]
Investor Relations

[0001730168-23-000074:8k_2_02:56]
408-433-8000

[0001730168-23-000074:8k_2_02:57]
investor.relations@broadcom.com

[0001730168-23-000074:8k_2_02:58]
(AVGO-Q)

[0001730168-23-000074:8k_2_02:59]
BROADCOM INC.

[0001730168-23-000074:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-23-000074:8k_2_02:61]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-23-000074:8k_2_02:62]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | April 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
| Net revenue |  | $ | 8,876 |  |  | $ | 8,733 |  |  | $ | 8,464 |  |  | $ | 26,524 |  |  | $ | 24,273 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 2,272 |  |  | 2,177 |  |  | 2,077 |  |  | 6,823 |  |  | 5,958 |  |
| Amortization of acquisition-related intangible assets |  | 439 |  |  | 441 |  |  | 705 |  |  | 1,415 |  |  | 2,142 |  |
| Restructuring charges |  | 1 |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |
| Total cost of revenue |  | 2,712 |  |  | 2,618 |  |  | 2,783 |  |  | 8,241 |  |  | 8,104 |  |
| Gross margin |  | 6,164 |  |  | 6,115 |  |  | 5,681 |  |  | 18,283 |  |  | 16,169 |  |
| Research and development |  | 1,358 |  |  | 1,312 |  |  | 1,255 |  |  | 3,865 |  |  | 3,722 |  |
| Selling, general and administrative |  | 388 |  |  | 438 |  |  | 323 |  |  | 1,174 |  |  | 1,012 |  |
| Amortization of acquisition-related intangible assets |  | 350 |  |  | 348 |  |  | 359 |  |  | 1,046 |  |  | 1,154 |  |
| Restructuring and other charges |  | 212 |  |  | 9 |  |  | 7 |  |  | 231 |  |  | 42 |  |
| Total operating expenses |  | 2,308 |  |  | 2,107 |  |  | 1,944 |  |  | 6,316 |  |  | 5,930 |  |
| Operating income |  | 3,856 |  |  | 4,008 |  |  | 3,737 |  |  | 11,967 |  |  | 10,239 |  |
| Interest expense |  | (406) |  |  | (405) |  |  | (406) |  |  | (1,217) |  |  | (1,331) |  |
| Other income (expense), net |  | 124 |  |  | 113 |  |  | 6 |  |  | 380 |  |  | (94) |  |
| Income before income taxes |  | 3,574 |  |  | 3,716 |  |  | 3,337 |  |  | 11,130 |  |  | 8,814 |  |
| Provision for income taxes |  | 271 |  |  | 235 |  |  | 263 |  |  | 572 |  |  | 678 |  |
| Net income |  | 3,303 |  |  | 3,481 |  |  | 3,074 |  |  | 10,558 |  |  | 8,136 |  |
| Dividends on preferred stock |  | — |  |  | — |  |  | (75) |  |  | — |  |  | (224) |  |
| Net income attributable to common stock |  | $ | 3,303 |  |  | $ | 3,481 |  |  | $ | 2,999 |  |  | $ | 10,558 |  |  | $ | 7,912 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.00 |  |  | $ | 8.39 |  |  | $ | 7.40 |  |  | $ | 25.44 |  |  | $ | 19.39 |  |
| Diluted (1) |  | $ | 7.74 |  |  | $ | 8.15 |  |  | $ | 7.15 |  |  | $ | 24.73 |  |  | $ | 18.70 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 413 |  |  | 415 |  |  | 405 |  |  | 415 |  |  | 408 |  |
| Diluted (1) |  | 427 |  |  | 427 |  |  | 430 |  |  | 427 |  |  | 435 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 61 |  |  | $ | 50 |  |  | $ | 37 |  |  | $ | 148 |  |  | $ | 109 |  |
| Research and development |  | 444 |  |  | 354 |  |  | 259 |  |  | 1,065 |  |  | 788 |  |
| Selling, general and administrative |  | 124 |  |  | 109 |  |  | 77 |  |  | 320 |  |  | 249 |  |
| Total stock-based compensation expense |  | $ | 629 |  |  | $ | 513 |  |  | $ | 373 |  |  | $ | 1,533 |  |  | $ | 1,146 |  |
| (1) All outstanding shares of Mandatory Convertible Preferred Stock were converted into our common stock during the fiscal quarter ended October 30, 2022. |

[0001730168-23-000074:8k_2_02:63]
BROADCOM INC.

[0001730168-23-000074:8k_2_02:64]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-23-000074:8k_2_02:65]
(IN MILLIONS)

[0001730168-23-000074:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | April 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
| Gross margin on GAAP basis |  | $ | 6,164 |  |  | $ | 6,115 |  |  | $ | 5,681 |  |  | $ | 18,283 |  |  | $ | 16,169 |  |
| Amortization of acquisition-related intangible assets |  | 439 |  |  | 441 |  |  | 705 |  |  | 1,415 |  |  | 2,142 |  |
| Stock-based compensation expense |  | 61 |  |  | 50 |  |  | 37 |  |  | 148 |  |  | 109 |  |
| Restructuring charges |  | 1 |  |  | — |  |  | 1 |  |  | 3 |  |  | 4 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 10 |  |
| Gross margin on non-GAAP basis |  | $ | 6,665 |  |  | $ | 6,606 |  |  | $ | 6,427 |  |  | $ | 19,849 |  |  | $ | 18,434 |  |
| Research and development on GAAP basis |  | $ | 1,358 |  |  | $ | 1,312 |  |  | $ | 1,255 |  |  | $ | 3,865 |  |  | $ | 3,722 |  |
| Stock-based compensation expense |  | 444 |  |  | 354 |  |  | 259 |  |  | 1,065 |  |  | 788 |  |
| Acquisition-related costs |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Research and development on non-GAAP basis |  | $ | 913 |  |  | $ | 958 |  |  | $ | 996 |  |  | $ | 2,800 |  |  | $ | 2,934 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 388 |  |  | $ | 438 |  |  | $ | 323 |  |  | $ | 1,174 |  |  | $ | 1,012 |  |
| Stock-based compensation expense |  | 124 |  |  | 109 |  |  | 77 |  |  | 320 |  |  | 249 |  |
| Acquisition-related costs |  | 48 |  |  | 93 |  |  | 14 |  |  | 183 |  |  | 57 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 216 |  |  | $ | 236 |  |  | $ | 232 |  |  | $ | 671 |  |  | $ | 706 |  |
| Total operating expenses on GAAP basis |  | $ | 2,308 |  |  | $ | 2,107 |  |  | $ | 1,944 |  |  | $ | 6,316 |  |  | $ | 5,930 |  |
| Amortization of acquisition-related intangible assets |  | 350 |  |  | 348 |  |  | 359 |  |  | 1,046 |  |  | 1,154 |  |
| Stock-based compensation expense |  | 568 |  |  | 463 |  |  | 336 |  |  | 1,385 |  |  | 1,037 |  |
| Restructuring and other charges |  | 212 |  |  | 9 |  |  | 7 |  |  | 231 |  |  | 42 |  |
| Acquisition-related costs |  | 49 |  |  | 93 |  |  | 14 |  |  | 183 |  |  | 57 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,129 |  |  | $ | 1,194 |  |  | $ | 1,228 |  |  | $ | 3,471 |  |  | $ | 3,640 |  |
| Operating income on GAAP basis |  | $ | 3,856 |  |  | $ | 4,008 |  |  | $ | 3,737 |  |  | $ | 11,967 |  |  | $ | 10,239 |  |
| Amortization of acquisition-related intangible assets |  | 789 |  |  | 789 |  |  | 1,064 |  |  | 2,461 |  |  | 3,296 |  |
| Stock-based compensation expense |  | 629 |  |  | 513 |  |  | 373 |  |  | 1,533 |  |  | 1,146 |  |
| Restructuring and other charges |  | 213 |  |  | 9 |  |  | 8 |  |  | 234 |  |  | 46 |  |
| Acquisition-related costs |  | 49 |  |  | 93 |  |  | 17 |  |  | 183 |  |  | 67 |  |
| Operating income on non-GAAP basis |  | $ | 5,536 |  |  | $ | 5,412 |  |  | $ | 5,199 |  |  | $ | 16,378 |  |  | $ | 14,794 |  |
| Interest expense on GAAP basis |  | $ | (406) |  |  | $ | (405) |  |  | $ | (406) |  |  | $ | (1,217) |  |  | $ | (1,331) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 112 |  |
| Interest expense on non-GAAP basis |  | $ | (406) |  |  | $ | (405) |  |  | $ | (406) |  |  | $ | (1,217) |  |  | $ | (1,219) |  |
| Other income (expense), net on GAAP basis |  | $ | 124 |  |  | $ | 113 |  |  | $ | 6 |  |  | $ | 380 |  |  | $ | (94) |  |
| (Gains) losses on investments |  | (2) |  |  | 11 |  |  | 25 |  |  | (35) |  |  | 140 |  |
| Other |  | — |  |  | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Other income, net on non-GAAP basis |  | $ | 122 |  |  | $ | 124 |  |  | $ | 26 |  |  | $ | 345 |  |  | $ | 41 |  |
| Provision for income taxes on GAAP basis |  | $ | 271 |  |  | $ | 235 |  |  | $ | 263 |  |  | $ | 572 |  |  | $ | 678 |  |
| Non-GAAP tax reconciling adjustments |  | 385 |  |  | 407 |  |  | 315 |  |  | 1,366 |  |  | 956 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 656 |  |  | $ | 642 |  |  | $ | 578 |  |  | $ | 1,938 |  |  | $ | 1,634 |  |

[0001730168-23-000074:8k_2_02:67]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | April 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
| Net income on GAAP basis |  | $ | 3,303 |  |  | $ | 3,481 |  |  | $ | 3,074 |  |  | $ | 10,558 |  |  | $ | 8,136 |  |
| Amortization of acquisition-related intangible assets |  | 789 |  |  | 789 |  |  | 1,064 |  |  | 2,461 |  |  | 3,296 |  |
| Stock-based compensation expense |  | 629 |  |  | 513 |  |  | 373 |  |  | 1,533 |  |  | 1,146 |  |
| Restructuring and other charges |  | 213 |  |  | 9 |  |  | 8 |  |  | 234 |  |  | 46 |  |
| Acquisition-related costs |  | 49 |  |  | 93 |  |  | 17 |  |  | 183 |  |  | 67 |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 112 |  |
| (Gains) losses on investments |  | (2) |  |  | 11 |  |  | 25 |  |  | (35) |  |  | 140 |  |
| Other |  | — |  |  | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Non-GAAP tax reconciling adjustments |  | (385) |  |  | (407) |  |  | (315) |  |  | (1,366) |  |  | (956) |  |
| Net income on non-GAAP basis |  | $ | 4,596 |  |  | $ | 4,489 |  |  | $ | 4,241 |  |  | $ | 13,568 |  |  | $ | 11,982 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 427 |  |  | 427 |  |  | 430 |  |  | 427 |  |  | 435 |  |
| Non-GAAP adjustment (1) |  | 9 |  |  | 8 |  |  | 6 |  |  | 8 |  |  | 6 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 436 |  |  | 435 |  |  | 436 |  |  | 435 |  |  | 441 |  |
| Net income on non-GAAP basis |  | $ | 4,596 |  |  | $ | 4,489 |  |  | $ | 4,241 |  |  | $ | 13,568 |  |  | $ | 11,982 |  |
| Interest expense |  | 406 |  |  | 405 |  |  | 406 |  |  | 1,217 |  |  | 1,219 |  |
| Provision for income taxes on non-GAAP basis |  | 656 |  |  | 642 |  |  | 578 |  |  | 1,938 |  |  | 1,634 |  |
| Depreciation |  | 122 |  |  | 129 |  |  | 129 |  |  | 378 |  |  | 400 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 21 |  |  | 21 |  |  | 24 |  |  | 64 |  |  | 72 |  |
| Adjusted EBITDA |  | $ | 5,801 |  |  | $ | 5,686 |  |  | $ | 5,378 |  |  | $ | 17,165 |  |  | $ | 15,307 |  |
| Net cash provided by operating activities |  | $ | 4,719 |  |  | $ | 4,502 |  |  | $ | 4,424 |  |  | $ | 13,257 |  |  | $ | 12,153 |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (122) |  |  | (116) |  |  | (347) |  |  | (302) |  |
| Free cash flow |  | $ | 4,597 |  |  | $ | 4,380 |  |  | $ | 4,308 |  |  | $ | 12,910 |  |  | $ | 11,851 |  |

[0001730168-23-000074:8k_2_02:68]
|  |  | Fiscal Quarter Ending |
|  |  | October 29, |
| Expected average diluted share count (2): |  | 2023 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 427 |  |
| Non-GAAP adjustment (1) |  | 8 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 435 |  |

[0001730168-23-000074:8k_2_02:69]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-23-000074:8k_2_02:70]
BROADCOM INC.

[0001730168-23-000074:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-23-000074:8k_2_02:72]
(IN MILLIONS)

[0001730168-23-000074:8k_2_02:73]
|  |  | July 30,2023 |  | October 30,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 12,055 |  |  | $ | 12,416 |  |
| Trade accounts receivable, net |  | 2,914 |  |  | 2,958 |  |
| Inventory |  | 1,842 |  |  | 1,925 |  |
| Other current assets |  | 1,522 |  |  | 1,205 |  |
| Total current assets |  | 18,333 |  |  | 18,504 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,180 |  |  | 2,223 |  |
| Goodwill |  | 43,619 |  |  | 43,614 |  |
| Intangible assets, net |  | 4,654 |  |  | 7,111 |  |
| Other long-term assets |  | 2,809 |  |  | 1,797 |  |
| Total assets |  | $ | 71,595 |  |  | $ | 73,249 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 992 |  |  | $ | 998 |  |
| Employee compensation and benefits |  | 831 |  |  | 1,202 |  |
| Current portion of long-term debt |  | 1,119 |  |  | 440 |  |
| Other current liabilities |  | 4,403 |  |  | 4,412 |  |
| Total current liabilities |  | 7,345 |  |  | 7,052 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 38,222 |  |  | 39,075 |  |
| Other long-term liabilities |  | 3,949 |  |  | 4,413 |  |
| Total liabilities |  | 49,516 |  |  | 50,540 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 20,855 |  |  | 21,159 |  |
| Retained earnings |  | 1,178 |  |  | 1,604 |  |
| Accumulated other comprehensive income (loss) |  | 46 |  |  | (54) |  |
| Total stockholders' equity |  | 22,079 |  |  | 22,709 |  |
| Total liabilities and equity |  | $ | 71,595 |  |  | $ | 73,249 |  |

[0001730168-23-000074:8k_2_02:74]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | April 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,303 |  |  | $ | 3,481 |  |  | $ | 3,074 |  |  | $ | 10,558 |  |  | $ | 8,136 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 810 |  |  | 810 |  |  | 1,088 |  |  | 2,525 |  |  | 3,368 |  |
| Depreciation |  | 122 |  |  | 129 |  |  | 129 |  |  | 378 |  |  | 400 |  |
| Stock-based compensation |  | 629 |  |  | 513 |  |  | 373 |  |  | 1,533 |  |  | 1,146 |  |
| Deferred taxes and other non-cash taxes |  | (251) |  |  | (316) |  |  | (15) |  |  | (1,140) |  |  | 55 |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | — |  |  | 100 |  |
| Non-cash interest expense |  | 33 |  |  | 33 |  |  | 32 |  |  | 98 |  |  | 97 |  |
| Other |  | — |  |  | 21 |  |  | 27 |  |  | (18) |  |  | 152 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 135 |  |  | 185 |  |  | 375 |  |  | 44 |  |  | (629) |  |
| Inventory |  | 44 |  |  | 13 |  |  | (170) |  |  | 83 |  |  | (540) |  |
| Accounts payable |  | 188 |  |  | (114) |  |  | (352) |  |  | (6) |  |  | (383) |  |
| Employee compensation and benefits |  | 184 |  |  | 91 |  |  | 321 |  |  | (382) |  |  | 8 |  |
| Other current assets and current liabilities |  | (339) |  |  | (165) |  |  | (198) |  |  | 66 |  |  | 610 |  |
| Other long-term assets and long-term liabilities |  | (139) |  |  | (179) |  |  | (260) |  |  | (482) |  |  | (367) |  |
| Net cash provided by operating activities |  | 4,719 |  |  | 4,502 |  |  | 4,424 |  |  | 13,257 |  |  | 12,153 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (17) |  |  | — |  |  | (5) |  |  | (17) |  |  | (239) |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (122) |  |  | (116) |  |  | (347) |  |  | (302) |  |
| Purchases of investments |  | (91) |  |  | (197) |  |  | — |  |  | (288) |  |  | (200) |  |
| Sales of investments |  | 74 |  |  | — |  |  | 200 |  |  | 74 |  |  | 200 |  |
| Other |  | 12 |  |  | 1 |  |  | 1 |  |  | 13 |  |  | 2 |  |
| Net cash provided by (used in) investing activities |  | (144) |  |  | (318) |  |  | 80 |  |  | (565) |  |  | (539) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,935 |  |
| Payments on debt obligations |  | — |  |  | — |  |  | — |  |  | (260) |  |  | (2,352) |  |
| Payments of dividends |  | (1,901) |  |  | (1,914) |  |  | (1,736) |  |  | (5,741) |  |  | (5,250) |  |
| Repurchases of common stock - repurchase program |  | (1,707) |  |  | (2,806) |  |  | (1,500) |  |  | (5,701) |  |  | (7,000) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (460) |  |  | (614) |  |  | (292) |  |  | (1,407) |  |  | (1,181) |  |
| Issuance of common stock |  | — |  |  | 63 |  |  | — |  |  | 63 |  |  | 60 |  |
| Other |  | (5) |  |  | (7) |  |  | (4) |  |  | (7) |  |  | (12) |  |
| Net cash used in financing activities |  | (4,073) |  |  | (5,278) |  |  | (3,532) |  |  | (13,053) |  |  | (13,800) |  |
| Net change in cash and cash equivalents |  | 502 |  |  | (1,094) |  |  | 972 |  |  | (361) |  |  | (2,186) |  |
| Cash and cash equivalents at beginning of period |  | 11,553 |  |  | 12,647 |  |  | 9,005 |  |  | 12,416 |  |  | 12,163 |  |
| Cash and cash equivalents at end of period |  | $ | 12,055 |  |  | $ | 11,553 |  |  | $ | 9,977 |  |  | $ | 12,055 |  |  | $ | 9,977 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 348 |  |  | $ | 397 |  |  | $ | 290 |  |  | $ | 1,106 |  |  | $ | 989 |  |
| Cash paid for income taxes |  | $ | 427 |  |  | $ | 891 |  |  | $ | 231 |  |  | $ | 1,591 |  |  | $ | 657 |  |
