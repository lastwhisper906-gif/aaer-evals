# AVGO notes — 0001730168-23-000077


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-23-000077:notes:1]
[same as prior period, unchanged from 0001730168-23-000064:notes:1]

[0001730168-23-000077:notes:2]
[same as prior period, unchanged from 0001730168-23-000064:notes:2]

[0001730168-23-000077:notes:3]
[same as prior period, unchanged from 0001730168-23-000064:notes:3]

[0001730168-23-000077:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 29, 2023 (“fiscal year 2023”) is a 52-week fiscal year. The first quarter of our fiscal year 2023 ended on January 29, 2023, the second quarter ended on April 30, 2023 and the third quarter ended on July 30, 2023. Our fiscal year ended October 30, 2022 (“fiscal year 2022”) was also a 52-week fiscal year.

[0001730168-23-000077:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 30, 2022 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2022 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended July 30, 2023 are not necessarily indicative of the results that may be expected for fiscal year 2023, or for any other future period.

[0001730168-23-000077:notes:6]
[same as prior period, unchanged from 0001730168-23-000064:notes:6]

[0001730168-23-000077:notes:7]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from those estimates, and such differences could affect the results of operations reported in future periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-23-000077:notes:8]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable that we will collect substantially all of the consideration to which we are entitled. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-23-000077:notes:9]
Disaggregation

[0001730168-23-000077:notes:10]
[same as prior period, unchanged from 0001730168-23-000064:notes:9]

[0001730168-23-000077:notes:11]
[same as prior period, unchanged from 0001730168-23-000064:notes:10]

[0001730168-23-000077:notes:12]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services (a) |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |

[0001730168-23-000077:notes:13]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |

[0001730168-23-000077:notes:14]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services (a) |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |

[0001730168-23-000077:notes:15]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |

[0001730168-23-000077:notes:16]
[same as prior period, unchanged from 0001730168-23-000064:notes:15]

[0001730168-23-000077:notes:17]
[same as prior period, unchanged from 0001730168-23-000064:notes:16]

[0001730168-23-000077:notes:18]
[same as prior period, unchanged from 0001730168-23-000064:notes:17]

[0001730168-23-000077:notes:19]
[same as prior period, unchanged from 0001730168-23-000064:notes:18]

[0001730168-23-000077:notes:20]
|  |  | July 30,2023 |  | October 30,2022 |
|  | (In millions) |
| Contract Assets |  | $ | 652 |  |  | $ | 128 |  |
| Contract Liabilities |  | $ | 3,256 |  |  | $ | 3,341 |  |

[0001730168-23-000077:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended July 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,677 million. The amount of revenue recognized during the three fiscal quarters ended July 31, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $2,482 million.

[0001730168-23-000077:notes:22]
[same as prior period, unchanged from 0001730168-23-000064:notes:21]

[0001730168-23-000077:notes:23]
[same as prior period, unchanged from 0001730168-23-000064:notes:22]

[0001730168-23-000077:notes:24]
Certain multi-year customer contracts, primarily in our semiconductor solutions segment, contain firmly committed amounts and the remaining performance obligations under these contracts as of July 30, 2023 were approximately $21.4 billion. We expect approximately 27% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## avgo:PendingBusinessCombinationDisclosureTextBlock

[0001730168-23-000077:notes:25]
Pending Acquisition of VMware, Inc.
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion based on the closing price of Broadcom common stock on May 25, 2022. We will also assume VMware’s closing date outstanding debt.

[0001730168-23-000077:notes:26]
[same as prior period, unchanged from 0001730168-23-000064:notes:25]

[0001730168-23-000077:notes:27]
[same as prior period, unchanged from 0001730168-23-000064:notes:26]

[0001730168-23-000077:notes:28]
[same as prior period, unchanged from 0001730168-23-000064:notes:27]

[0001730168-23-000077:notes:29]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion. In connection with our entry into the 2023 Credit Agreement as discussed below, we terminated this commitment letter.

[0001730168-23-000077:notes:30]
The VMware Merger, which is expected to be completed on October 30, 2023, is subject to satisfaction or waiver of customary closing conditions, including clearance under the antitrust laws of certain jurisdictions. On October 3, 2022, we registered approximately 59 million shares of our common stock. On November 4, 2022, VMware stockholders adopted the

[0001730168-23-000077:notes:31]
VMware Merger Agreement. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-23-000077:notes:32]
2023 Term Loans

[0001730168-23-000077:notes:33]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provides us with the ability to borrow up to $28,390 million of term loan commitments (the “2023 Term Facilities”) in connection with the VMware Merger. The 2023 Term Facilities consist of a $10,695 million unsecured term A-2 facility, a $10,695 million unsecured term A-3 facility, and a $7,000 million unsecured term A-5 facility. The funding of the 2023 Term Facilities is dependent on the closing of the VMware Merger, and may be increased by up to $2,000 million.
The 2023 Term Facilities, once funded, will bear interest at floating interest rates and will mature and be payable on the second, third or fifth anniversary of the funding date. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-23-000077:notes:34]
[same as prior period, unchanged from 0001730168-23-000064:notes:30]

[0001730168-23-000077:notes:35]
Cash equivalents included $2,921 million and $3,915 million of time deposits and $2,241 million and $2,365 million of money-market funds as of July 30, 2023 and October 30, 2022, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-23-000077:notes:36]
[same as prior period, unchanged from 0001730168-23-000064:notes:32]

[0001730168-23-000077:notes:37]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $900 million and $2,825 million during the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, and $900 million and $3,000 million during the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-23-000077:notes:38]
[same as prior period, unchanged from 0001730168-23-000064:notes:34]

[0001730168-23-000077:notes:39]
|  |  | July 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Finished goods |  | $ | 581 |  |  | $ | 780 |  |
| Work-in-process |  | 938 |  |  | 966 |  |
| Raw materials |  | 323 |  |  | 179 |  |
| Total inventory |  | $ | 1,842 |  |  | $ | 1,925 |  |

[0001730168-23-000077:notes:40]
[same as prior period, unchanged from 0001730168-23-000064:notes:36]

[0001730168-23-000077:notes:41]
|  |  | July 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 433 |  |  | $ | 864 |  |
| Other |  | 1,089 |  |  | 341 |  |
| Total other current assets |  | $ | 1,522 |  |  | $ | 1,205 |  |

[0001730168-23-000077:notes:42]
[same as prior period, unchanged from 0001730168-23-000064:notes:38]

[0001730168-23-000077:notes:43]
|  |  | July 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 2,941 |  |  | $ | 2,931 |  |
| Tax liabilities |  | 515 |  |  | 680 |  |
| Interest payable |  | 406 |  |  | 393 |  |
| Other |  | 541 |  |  | 408 |  |
| Total other current liabilities |  | $ | 4,403 |  |  | $ | 4,412 |  |

[0001730168-23-000077:notes:44]
[same as prior period, unchanged from 0001730168-23-000064:notes:40]

[0001730168-23-000077:notes:45]
|  |  | July 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 2,885 |  |  | $ | 3,229 |  |
| Other |  | 1,064 |  |  | 1,184 |  |
| Total other long-term liabilities |  | $ | 3,949 |  |  | $ | 4,413 |  |

[0001730168-23-000077:notes:46]
[same as prior period, unchanged from 0001730168-23-000064:notes:42]

[0001730168-23-000077:notes:47]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 348 |  |  | $ | 290 |  |  | $ | 1,106 |  |  | $ | 989 |  |
| Cash paid for income taxes |  | $ | 427 |  |  | $ | 231 |  |  | $ | 1,591 |  |  | $ | 657 |  |

[0001730168-23-000077:notes:48]
[same as prior period, unchanged from 0001730168-23-000064:notes:44]

[0001730168-23-000077:notes:49]
During the fiscal quarter ended January 29, 2023 and fiscal year 2022, we entered into treasury rate lock contracts with original maturities of approximately one year to hedge variability of cash flows due to changes in the benchmark interest rate of anticipated future debt issuances. These treasury rate lock contracts are designated and accounted for as cash flow hedging instruments. As of July 30, 2023 and October 30, 2022, the total notional amounts of these contracts were $5.5 billion and $1.3 billion, respectively. As of July 30, 2023, the fair value of $175 million was recorded in other current assets. As of October 30, 2022, the fair value of $47 million was recorded in other long-term assets. The change in fair value was recorded as a component of other comprehensive income, net of tax, in our condensed consolidated statements of comprehensive income. In August 2023, we early settled all treasury rate lock contracts for a cumulative gain of $371 million.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-23-000077:notes:50]
[same as prior period, unchanged from 0001730168-23-000064:notes:46]

[0001730168-23-000077:notes:51]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of July 30, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 19,456 |  |  | $ | (16,828) |  |  | $ | 2,628 |  |
| Customer contracts and related relationships |  | 7,059 |  |  | (5,447) |  |  | 1,612 |  |
| Order backlog |  | 484 |  |  | (458) |  |  | 26 |  |
| Trade names |  | 699 |  |  | (421) |  |  | 278 |  |
| Other |  | 174 |  |  | (93) |  |  | 81 |  |
| Intangible assets subject to amortization |  | 27,872 |  |  | (23,247) |  |  | 4,625 |  |
| In-process research and development |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 27,901 |  |  | $ | (23,247) |  |  | $ | 4,654 |  |
| As of October 30, 2022: |  |  |  |  |  |  |
| Purchased technology |  | $ | 19,450 |  |  | $ | (15,422) |  |  | $ | 4,028 |  |
| Customer contracts and related relationships |  | 7,066 |  |  | (4,535) |  |  | 2,531 |  |
| Order backlog |  | 484 |  |  | (382) |  |  | 102 |  |
| Trade names |  | 700 |  |  | (372) |  |  | 328 |  |
| Other |  | 174 |  |  | (81) |  |  | 93 |  |
| Intangible assets subject to amortization |  | 27,874 |  |  | (20,792) |  |  | 7,082 |  |
| In-process research and development |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 27,903 |  |  | $ | (20,792) |  |  | $ | 7,111 |  |

[0001730168-23-000077:notes:52]
Based on the amount of intangible assets subject to amortization as of July 30, 2023, the expected amortization expense was as follows:

[0001730168-23-000077:notes:53]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 789 |  |
| 2024 |  | 2,389 |  |
| 2025 |  | 682 |  |
| 2026 |  | 345 |  |
| 2027 |  | 218 |  |
| Thereafter |  | 202 |  |
| Total |  | $ | 4,625 |  |

[0001730168-23-000077:notes:54]
[same as prior period, unchanged from 0001730168-23-000064:notes:50]

[0001730168-23-000077:notes:55]
| Amortizable intangible assets: |  | July 30,2023 |
|  |  | (In years) |
| Purchased technology |  | 3 |
| Customer contracts and related relationships |  | 2 |
| Trade names |  | 8 |
| Other |  | 8 |

[0001730168-23-000077:notes:56]
The weighted-average remaining amortization period of order backlog was less than one year.


## us-gaap:EarningsPerShareTextBlock

[0001730168-23-000077:notes:57]
Net Income Per Share
Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-23-000077:notes:58]
Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and employee stock purchase plan (“ESPP”) rights, (collectively referred to as “equity awards”), as well as 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”), which was all converted into shares of our common stock before the end of fiscal year 2022. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-23-000077:notes:59]
[same as prior period, unchanged from 0001730168-23-000064:notes:54]

[0001730168-23-000077:notes:60]
[same as prior period, unchanged from 0001730168-23-000064:notes:56]

[0001730168-23-000077:notes:61]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,303 |  |  | $ | 3,074 |  |  | $ | 10,558 |  |  | $ | 8,136 |  |
| Dividends on preferred stock |  | — |  |  | (75) |  |  | — |  |  | (224) |  |
| Net income attributable to common stock |  | $ | 3,303 |  |  | $ | 2,999 |  |  | $ | 10,558 |  |  | $ | 7,912 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 413 |  | 405 |  | 415 |  | 408 |
| Dilutive effect of equity awards |  | 14 |  | 13 |  | 12 |  | 15 |
| Dilutive effect of Mandatory Convertible Preferred Stock |  | — |  |  | 12 |  | — |  |  | 12 |
| Weighted-average shares outstanding - diluted |  | 427 |  | 430 |  | 427 |  | 435 |

[0001730168-23-000077:notes:62]
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.00 |  |  | $ | 7.40 |  |  | $ | 25.44 |  |  | $ | 19.39 |  |
| Diluted |  | $ | 7.74 |  |  | $ | 7.15 |  |  | $ | 24.73 |  |  | $ | 18.70 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-23-000077:notes:63]
Borrowings

[0001730168-23-000077:notes:64]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |

[0001730168-23-000077:notes:65]
|  |  | Effective Interest Rate |  | July 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 42 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,119 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 8 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,667) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,222 |  |  | $ | 39,075 |  |

[0001730168-23-000077:notes:66]
2021 Credit Agreement

[0001730168-23-000077:notes:67]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either July 30, 2023 or October 30, 2022.

[0001730168-23-000077:notes:68]
Commercial Paper

[0001730168-23-000077:notes:69]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either July 30, 2023 or October 30, 2022.

[0001730168-23-000077:notes:70]
Fair Value of Debt

[0001730168-23-000077:notes:71]
As of July 30, 2023, the estimated aggregate fair value of debt was $35,072 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-23-000077:notes:72]
Future Principal Payments of Debt

[0001730168-23-000077:notes:73]
The future scheduled principal payments of debt as of July 30, 2023 were as follows:

[0001730168-23-000077:notes:74]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 143 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 495 |  |
| 2026 |  | 1,652 |  |
| 2027 |  | 3,137 |  |
| Thereafter |  | 33,968 |  |
| Total |  | $ | 40,958 |  |

[0001730168-23-000077:notes:75]
As of July 30, 2023 and October 30, 2022, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-23-000077:notes:76]
[same as prior period, unchanged from 0001730168-23-000064:notes:72]

[0001730168-23-000077:notes:77]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 4.60 |  |  | $ | 4.10 |  |  | $ | 13.80 |  |  | $ | 12.30 |  |
| Dividends to common stockholders |  | $ | 1,901 |  |  | $ | 1,661 |  |  | $ | 5,741 |  |  | $ | 5,026 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 20.00 |  |  | $ | — |  |  | $ | 60.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 224 |  |

[0001730168-23-000077:notes:78]
[same as prior period, unchanged from 0001730168-23-000064:notes:74]

[0001730168-23-000077:notes:79]
[same as prior period, unchanged from 0001730168-23-000064:notes:75]

[0001730168-23-000077:notes:80]
[same as prior period, unchanged from 0001730168-23-000064:notes:76]

[0001730168-23-000077:notes:81]
We repurchased and retired approximately 2 million and 9 million shares of our common stock for $1,707 million and $5,701 million during the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, and approximately 3 million and 12 million shares of our common stock for $1,500 million and $7,000 million during the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, under these stock repurchase programs.

[0001730168-23-000077:notes:82]
[same as prior period, unchanged from 0001730168-23-000064:notes:78]

[0001730168-23-000077:notes:83]
[same as prior period, unchanged from 0001730168-23-000064:notes:79]

[0001730168-23-000077:notes:84]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 25 |  |  | $ | 15 |  |  | $ | 63 |  |  | $ | 49 |  |
| Cost of subscriptions and services |  | 36 |  |  | 22 |  |  | 85 |  |  | 60 |  |
| Research and development |  | 444 |  |  | 259 |  |  | 1,065 |  |  | 788 |  |
| Selling, general and administrative |  | 124 |  |  | 77 |  |  | 320 |  |  | 249 |  |
| Total stock-based compensation expense |  | $ | 629 |  |  | $ | 373 |  |  | $ | 1,533 |  |  | $ | 1,146 |  |

[0001730168-23-000077:notes:85]
As of July 30, 2023, the total unrecognized compensation cost related to unvested stock-based awards was $6,878 million, which is expected to be recognized over the remaining weighted-average service period of 3.6 years.

[0001730168-23-000077:notes:86]
[same as prior period, unchanged from 0001730168-23-000064:notes:82]

[0001730168-23-000077:notes:87]
[same as prior period, unchanged from 0001730168-23-000064:notes:83]

[0001730168-23-000077:notes:88]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 30, 2022 |  | 18 |  |  | $ | 238.49 |  |  |  |  |  |
| Granted |  | 12 |  |  | $ | 516.85 |  |  |  |  |  |
| Vested |  | (6) |  |  | $ | 248.02 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 286.21 |  |  |  |  |  |
| Balance as of July 30, 2023 |  | 23 |  |  | $ | 381.67 |  |  |  |  |  |

[0001730168-23-000077:notes:89]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended July 30, 2023 was $4,036 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-23-000077:notes:90]
Income Taxes
The provision for income taxes was $271 million and $572 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, compared to $263 million and $678 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively. The increase in the provision for income taxes in the fiscal quarter ended July 30, 2023, as compared to the prior year fiscal period, was primarily due to higher income before income taxes, substantially offset by an increase in excess tax benefits from stock-based awards. The decrease in the provision for income taxes in the three fiscal quarters ended July 30, 2023, as compared to the prior year fiscal period, was primarily due to an increase in the recognition of uncertain tax benefits as a result of lapses of statutes of limitations and an increase in excess tax benefits from stock-based awards, partially offset by higher income before income taxes.

[0001730168-23-000077:notes:91]
As of July 30, 2023, we had $5,491 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $427 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations and changes in balances related to tax positions to be taken during the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-23-000077:notes:92]
[same as prior period, unchanged from 0001730168-23-000064:notes:89]

[0001730168-23-000077:notes:93]
[same as prior period, unchanged from 0001730168-23-000064:notes:90]

[0001730168-23-000077:notes:94]
[same as prior period, unchanged from 0001730168-23-000064:notes:91]

[0001730168-23-000077:notes:95]
[same as prior period, unchanged from 0001730168-23-000064:notes:92]

[0001730168-23-000077:notes:96]
[same as prior period, unchanged from 0001730168-23-000064:notes:93]

[0001730168-23-000077:notes:97]
[same as prior period, unchanged from 0001730168-23-000064:notes:94]

[0001730168-23-000077:notes:98]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-23-000077:notes:99]
[same as prior period, unchanged from 0001730168-23-000064:notes:96]

[0001730168-23-000077:notes:100]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 30,2023 |  | July 31,2022 |  | July 30,2023 |  | July 31,2022 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 6,941 |  |  | $ | 6,624 |  |  | $ | 20,856 |  |  | $ | 18,726 |  |
| Infrastructure software |  | 1,935 |  |  | 1,840 |  |  | 5,668 |  |  | 5,547 |  |
| Total net revenue |  | $ | 8,876 |  |  | $ | 8,464 |  |  | $ | 26,524 |  |  | $ | 24,273 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,092 |  |  | $ | 3,916 |  |  | $ | 12,215 |  |  | $ | 10,891 |  |
| Infrastructure software |  | 1,444 |  |  | 1,283 |  |  | 4,163 |  |  | 3,903 |  |
| Unallocated expenses |  | (1,680) |  |  | (1,462) |  |  | (4,411) |  |  | (4,555) |  |
| Total operating income |  | $ | 3,856 |  |  | $ | 3,737 |  |  | $ | 11,967 |  |  | $ | 10,239 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-23-000077:notes:101]
Commitments and Contingencies
Commitments

[0001730168-23-000077:notes:102]
The following table summarizes contractual obligations and commitments as of July 30, 2023:

[0001730168-23-000077:notes:103]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 35 |  |  | $ | 81 |  |
| 2024 |  | 254 |  |  | 306 |  |
| 2025 |  | 153 |  |  | 223 |  |
| 2026 |  | 9 |  |  | 232 |  |
| 2027 |  | 7 |  |  | 175 |  |
| Thereafter |  | 7 |  |  | 478 |  |
| Total |  | $ | 465 |  |  | $ | 1,495 |  |

[0001730168-23-000077:notes:104]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-23-000077:notes:105]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-23-000077:notes:106]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of July 30, 2023, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,885 million of unrecognized tax benefits and accrued interest and penalties as of July 30, 2023 have been excluded from the table above.

[0001730168-23-000077:notes:107]
Contingencies

[0001730168-23-000077:notes:108]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-23-000077:notes:109]
Lawsuits Relating to California Institute of Technology

[0001730168-23-000077:notes:110]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in

[0001730168-23-000077:notes:111]
enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”). In February 2022, the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, but it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. In May 2022, the Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court. Subsequently, Caltech withdrew its infringement allegations as to the 7,916,781 patent. On July 7, 2023, the parties informed the U.S. Central District Court that they have entered into settlement discussions and requested that the U.S. Central District Court stay the case pending execution of a final settlement agreement.

[0001730168-23-000077:notes:112]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. The ultimate outcome of the case has not yet been determined as the U.S. Central District Court has stayed the retrial pending a final settlement agreement and a number of factors could significantly change the assessment of damages. In the fiscal quarter ended July 30, 2023, we accrued our best estimate to restructuring and other charges in the condensed consolidated statements of operations.

[0001730168-23-000077:notes:113]
Other Matters

[0001730168-23-000077:notes:114]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-23-000077:notes:115]
Contingency Assessment

[0001730168-23-000077:notes:116]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-23-000077:notes:117]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-23-000077:notes:118]
Other Indemnifications

[0001730168-23-000077:notes:119]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:SubsequentEventsTextBlock

[0001730168-23-000077:notes:120]
Subsequent Events
Cash Dividends Declared

[0001730168-23-000077:notes:121]
On August 30, 2023, our Board of Directors declared a quarterly cash dividend of $4.60 per share on our common stock, payable on September 29, 2023 to stockholders of record on September 21, 2023.
