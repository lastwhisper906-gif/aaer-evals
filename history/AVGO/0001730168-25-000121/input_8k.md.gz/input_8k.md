# AVGO 8-K — 0001730168-25-000116 filed 2025-12-11

## item codes, every 8-K on or before 2025-12-18

- 2025-12-11 0001730168-25-000116 — 2.02, 8.01, 9.01
- 2025-09-29 0001193125-25-223202 — 8.01, 9.01
- 2025-09-10 0001193125-25-200108 — 8.01, 9.01
- 2025-09-09 0001193125-25-199281 — 5.02, 9.01
- 2025-09-04 0001730168-25-000094 — 2.02, 8.01, 9.01
- 2025-07-11 0001193125-25-158202 — 1.02, 8.01, 9.01
- 2025-06-05 0001730168-25-000061 — 2.02, 8.01, 9.01
- 2025-04-22 0001730168-25-000037 — 5.07
- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2025-12-18

- none on or before 2025-12-18

## item 2.02 — earnings release, exhibit 99.1

[0001730168-25-000116:8k_2_02:1]
EX-99.1
2
avgo-11022025x8kxex99.htm
EX-99.1

[0001730168-25-000116:8k_2_02:2]
Document

[0001730168-25-000116:8k_2_02:3]
Exhibit 99.1

[0001730168-25-000116:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2025 Financial Results and Quarterly Dividend

[0001730168-25-000116:8k_2_02:5]
•Revenue of $18,015 million for the fourth quarter, up 28 percent from the prior year period

[0001730168-25-000116:8k_2_02:6]
•GAAP net income of $8,518 million for the fourth quarter; Non-GAAP net income of $9,714 million for the fourth quarter

[0001730168-25-000116:8k_2_02:7]
•Adjusted EBITDA of $12,218 million for the fourth quarter, or 68 percent of revenue

[0001730168-25-000116:8k_2_02:8]
•GAAP diluted EPS of $1.74 for the fourth quarter; Non-GAAP diluted EPS of $1.95 for the fourth quarter

[0001730168-25-000116:8k_2_02:9]
•Cash from operations of $7,703 million for the fourth quarter, less capital expenditures of $237 million, resulted in $7,466 million of free cash flow, or 41 percent of revenue

[0001730168-25-000116:8k_2_02:10]
•Quarterly common stock dividend increased by 10 percent from the prior quarter to $0.65 per share

[0001730168-25-000116:8k_2_02:11]
•First quarter fiscal year 2026 revenue guidance of approximately $19.1 billion, an increase of 28 percent from the prior year period

[0001730168-25-000116:8k_2_02:12]
•First quarter fiscal year 2026 Adjusted EBITDA guidance of 67 percent of projected revenue (1)

[0001730168-25-000116:8k_2_02:13]
PALO ALTO, Calif. – December 11, 2025 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year ended November 2, 2025, provided guidance for its first quarter of fiscal year 2026 and announced its quarterly dividend.

[0001730168-25-000116:8k_2_02:14]
“In Q4, record revenue of $18.0 billion grew 28% year-over-year, driven primarily by AI semiconductor revenue increasing 74% year-over-year,” said Hock Tan, President and CEO of Broadcom Inc. “We see the momentum continuing in Q1 and expect AI semiconductor revenue to double year-over-year to $8.2 billion, driven by custom AI accelerators and Ethernet AI switches. We forecast Q1’26 total revenue of $19.1 billion and adjusted EBITDA of 67%.”

[0001730168-25-000116:8k_2_02:15]
“In fiscal year 2025 adjusted EBITDA increased 35% year-over-year to a record $43.0 billion, and free cash flow was strong at $26.9 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Based on increased cash flows in fiscal year 2025, we are increasing our quarterly common stock dividend by 10% to $0.65 per share for fiscal year 2026. The target fiscal year 2026 annual common stock dividend of $2.60 per share is a record, and the fifteenth consecutive increase in annual dividends since we initiated dividends in fiscal 2011.”

[0001730168-25-000116:8k_2_02:16]
________________________________

[0001730168-25-000116:8k_2_02:17]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-25-000116:8k_2_02:18]
Fourth Quarter Fiscal Year 2025 Financial Highlights

[0001730168-25-000116:8k_2_02:19]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 25 |  | Q4 24 |  | Change |  | Q4 25 |  | Q4 24 |  | Change |
| Net revenue |  | $ | 18,015 |  |  | $ | 14,054 |  |  | +28 | % |  | $ | 18,015 |  |  | $ | 14,054 |  |  | +28 | % |
| Net income |  | $ | 8,518 |  |  | $ | 4,324 |  |  | +97 | % |  | $ | 9,714 |  |  | $ | 6,965 |  |  | +39 | % |
| Earnings per common share - diluted |  | $ | 1.74 |  |  | $ | 0.90 |  |  | +93 | % |  | $ | 1.95 |  |  | $ | 1.42 |  |  | +37 | % |

[0001730168-25-000116:8k_2_02:20]
| (Dollars in millions) |  | Q4 25 |  | Q4 24 |  | Change |  |
| Cash flow from operations |  | $ | 7,703 |  |  | $ | 5,604 |  |  | +37 | % |  |
| Adjusted EBITDA |  | $ | 12,218 |  |  | $ | 9,089 |  |  | +34 | % |  |
| Free cash flow |  | $ | 7,466 |  |  | $ | 5,482 |  |  | +36 | % |  |

[0001730168-25-000116:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 25 |  |  |  | Q4 24 |  | Change |  |
| Semiconductor solutions |  | $ | 11,072 |  |  | 61 | % |  |  |  |  |  |  | $ | 8,230 |  |  | 59 | % |  | +35 | % |  |
| Infrastructure software |  | 6,943 |  |  | 39 |  |  |  |  |  |  |  | 5,824 |  |  | 41 |  |  | +19 | % |  |
| Total net revenue |  | $ | 18,015 |  |  | 100 | % |  |  |  |  |  |  | $ | 14,054 |  |  | 100 | % |  |  |  |  |

[0001730168-25-000116:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $16,178 million, compared to $10,718 million at the end of the prior fiscal quarter.

[0001730168-25-000116:8k_2_02:23]
During the fourth fiscal quarter, the Company generated $7,703 million in cash from operations and spent $237 million on capital expenditures, resulting in $7,466 million of free cash flow.

[0001730168-25-000116:8k_2_02:24]
On September 30, 2025, the Company paid a cash dividend of $0.59 per share, totaling $2,797 million.

[0001730168-25-000116:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-25-000116:8k_2_02:26]
Fiscal Year 2025 Financial Highlights

[0001730168-25-000116:8k_2_02:27]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | FY 25 |  | FY 24 |  | Change |  | FY 25 |  | FY 24 |  | Change |
| Net revenue |  | $ | 63,887 |  |  | $ | 51,574 |  |  | +24 | % |  | $ | 63,887 |  |  | $ | 51,574 |  |  | +24 | % |
| Net income |  | $ | 23,126 |  |  | $ | 5,895 |  |  | +292 | % |  | $ | 33,728 |  |  | $ | 23,733 |  |  | +42 | % |
| Earnings per common share - diluted |  | $ | 4.77 |  |  | $ | 1.23 |  |  | +288 | % |  | $ | 6.82 |  |  | $ | 4.87 |  |  | +40 | % |

[0001730168-25-000116:8k_2_02:28]
| (Dollars in millions) |  | FY 25 |  | FY 24 |  | Change |  |
| Cash flow from operations |  | $ | 27,537 |  |  | $ | 19,962 |  |  | +38 | % |  |
| Adjusted EBITDA |  | $ | 43,004 |  |  | $ | 31,897 |  |  | +35 | % |  |
| Free cash flow |  | $ | 26,914 |  |  | $ | 19,414 |  |  | +39 | % |  |

[0001730168-25-000116:8k_2_02:29]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | FY 25 |  |  |  | FY 24 |  | Change |  |
| Semiconductor solutions |  | $ | 36,858 |  |  | 58 | % |  |  |  |  |  |  | $ | 30,096 |  |  | 58 | % |  | +22 | % |  |
| Infrastructure software |  | 27,029 |  |  | 42 |  |  |  |  |  |  |  | 21,478 |  |  | 42 |  |  | +26 | % |  |
| Total net revenue |  | $ | 63,887 |  |  | 100 | % |  |  |  |  |  |  | $ | 51,574 |  |  | 100 | % |  |  |  |  |

[0001730168-25-000116:8k_2_02:30]
2

[0001730168-25-000116:8k_2_02:31]
First Quarter Fiscal Year 2026 Business Outlook

[0001730168-25-000116:8k_2_02:32]
Based on current business trends and conditions, the outlook for the first quarter of fiscal year 2026, ending February 1, 2026, is expected to be as follows:

[0001730168-25-000116:8k_2_02:33]
•First quarter revenue guidance of approximately $19.1 billion; and

[0001730168-25-000116:8k_2_02:34]
•First quarter Adjusted EBITDA guidance of 67 percent of projected revenue.

[0001730168-25-000116:8k_2_02:35]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000116:8k_2_02:36]
Quarterly Dividends

[0001730168-25-000116:8k_2_02:37]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.65 per share. The dividend is payable on December 31, 2025 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 22, 2025.

[0001730168-25-000116:8k_2_02:38]
Financial Results Conference Call

[0001730168-25-000116:8k_2_02:39]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter and fiscal year 2025 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-25-000116:8k_2_02:40]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-25-000116:8k_2_02:41]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-25-000116:8k_2_02:42]
Non-GAAP Financial Measures

[0001730168-25-000116:8k_2_02:43]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-25-000116:8k_2_02:44]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these

[0001730168-25-000116:8k_2_02:45]
3

[0001730168-25-000116:8k_2_02:46]
items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-25-000116:8k_2_02:47]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-25-000116:8k_2_02:48]
About Broadcom

[0001730168-25-000116:8k_2_02:49]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-25-000116:8k_2_02:50]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-25-000116:8k_2_02:51]
expectations with regard to our share repurchases, and other statements identified by words such as “will,” “expect,” “believe,” “anticipate,” “estimate,” “should,” “intend,” “plan,” “potential,” “predict,” “project,” “aim,” and similar words, phrases or expressions. These forward-looking statements are based on current expectations and beliefs of Broadcom’s management, current information available to Broadcom’s management, and current market trends and market conditions and involve risks and uncertainties that may cause actual results to differ materially from those contained in forward-looking statements. Accordingly, undue reliance should not be placed on such statements.

[0001730168-25-000116:8k_2_02:52]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; the slow or unsuccessful return on our investments, expansion of our business strategy or adoption of new business models; cyclicality in the semiconductor industry or in our target markets; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cybersecurity threats and a breach

[0001730168-25-000116:8k_2_02:53]
of security systems; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our dependency on a limited number of suppliers; prolonged disruptions of our, our customers’ or our suppliers’ facilities or other significant operations; our ability to maintain appropriate manufacturing capacity and quality; our ability to continue winning business in the semiconductor solutions industry; dependence on and risks associated with distributors and other channel partners of our products; ability of our software products to manage and secure IT infrastructures and environments; demand for our data center virtualization products and customer acceptance of our products, services and business strategy; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; our competitive performance; quarterly and annual fluctuations in operating results; our ability to maintain or improve gross margin; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; corporate responsibility matters; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our stock repurchase program; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000116:8k_2_02:54]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000116:8k_2_02:55]
Contact:

[0001730168-25-000116:8k_2_02:56]
Ji Yoo

[0001730168-25-000116:8k_2_02:57]
Broadcom Inc.

[0001730168-25-000116:8k_2_02:58]
Investor Relations

[0001730168-25-000116:8k_2_02:59]
650-427-6000

[0001730168-25-000116:8k_2_02:60]
investor.relations@broadcom.com

[0001730168-25-000116:8k_2_02:61]
(AVGO-Q)

[0001730168-25-000116:8k_2_02:62]
5

[0001730168-25-000116:8k_2_02:63]
BROADCOM INC.

[0001730168-25-000116:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-25-000116:8k_2_02:65]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-25-000116:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 2,2025 |  | August 3,2025 |  | November 3,2024 |  | November 2,2025 |  | November 3,2024 |
| Net revenue |  | $ | 18,015 |  |  | $ | 15,952 |  |  | $ | 14,054 |  |  | $ | 63,887 |  |  | $ | 51,574 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 4,213 |  |  | 3,704 |  |  | 3,399 |  |  | 14,486 |  |  | 12,788 |  |
| Amortization of acquisition-related intangible assets |  | 1,545 |  |  | 1,519 |  |  | 1,602 |  |  | 6,031 |  |  | 6,023 |  |
| Restructuring charges |  | 8 |  |  | 26 |  |  | 51 |  |  | 76 |  |  | 254 |  |
| Total cost of revenue |  | 5,766 |  |  | 5,249 |  |  | 5,052 |  |  | 20,593 |  |  | 19,065 |  |
| Gross margin |  | 12,249 |  |  | 10,703 |  |  | 9,002 |  |  | 43,294 |  |  | 32,509 |  |
| Research and development |  | 2,981 |  |  | 3,050 |  |  | 2,234 |  |  | 10,977 |  |  | 9,310 |  |
| Selling, general and administrative |  | 1,107 |  |  | 1,072 |  |  | 1,010 |  |  | 4,211 |  |  | 4,959 |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 507 |  |  | 813 |  |  | 2,031 |  |  | 3,244 |  |
| Restructuring and other charges |  | 146 |  |  | 187 |  |  | 318 |  |  | 591 |  |  | 1,533 |  |
| Total operating expenses |  | 4,741 |  |  | 4,816 |  |  | 4,375 |  |  | 17,810 |  |  | 19,046 |  |
| Operating income |  | 7,508 |  |  | 5,887 |  |  | 4,627 |  |  | 25,484 |  |  | 13,463 |  |
| Interest expense |  | (761) |  |  | (807) |  |  | (916) |  |  | (3,210) |  |  | (3,953) |  |
| Other income, net |  | 122 |  |  | 205 |  |  | 52 |  |  | 455 |  |  | 406 |  |
| Income from continuing operations before income taxes |  | 6,869 |  |  | 5,285 |  |  | 3,763 |  |  | 22,729 |  |  | 9,916 |  |
| Provision for (benefit from) income taxes |  | (1,649) |  |  | 1,145 |  |  | (442) |  |  | (397) |  |  | 3,748 |  |
| Income from continuing operations |  | 8,518 |  |  | 4,140 |  |  | 4,205 |  |  | 23,126 |  |  | 6,168 |  |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 119 |  |  | — |  |  | (273) |  |
| Net income |  | $ | 8,518 |  |  | $ | 4,140 |  |  | $ | 4,324 |  |  | $ | 23,126 |  |  | $ | 5,895 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.80 |  |  | $ | 0.88 |  |  | $ | 0.89 |  |  | $ | 4.91 |  |  | $ | 1.33 |  |
| Income (loss) per share from discontinued operations |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | (0.06) |  |
| Net income per share |  | $ | 1.80 |  |  | $ | 0.88 |  |  | $ | 0.92 |  |  | $ | 4.91 |  |  | $ | 1.27 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.74 |  |  | $ | 0.85 |  |  | $ | 0.87 |  |  | $ | 4.77 |  |  | $ | 1.29 |  |
| Income (loss) per share from discontinued operations |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | (0.06) |  |
| Net income per share |  | $ | 1.74 |  |  | $ | 0.85 |  |  | $ | 0.90 |  |  | $ | 4.77 |  |  | $ | 1.23 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,732 |  |  | 4,714 |  |  | 4,679 |  |  | 4,712 |  |  | 4,624 |  |
| Diluted |  | 4,889 |  |  | 4,860 |  |  | 4,828 |  |  | 4,853 |  |  | 4,778 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 237 |  |  | $ | 251 |  |  | $ | 159 |  |  | $ | 844 |  |  | $ | 664 |  |
| Research and development |  | 1,456 |  |  | 1,573 |  |  | 839 |  |  | 5,020 |  |  | 3,460 |  |
| Selling, general and administrative |  | 502 |  |  | 498 |  |  | 316 |  |  | 1,704 |  |  | 1,546 |  |
| Total stock-based compensation expense |  | $ | 2,195 |  |  | $ | 2,322 |  |  | $ | 1,314 |  |  | $ | 7,568 |  |  | $ | 5,670 |  |

[0001730168-25-000116:8k_2_02:67]
BROADCOM INC.

[0001730168-25-000116:8k_2_02:68]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-25-000116:8k_2_02:69]
(IN MILLIONS)

[0001730168-25-000116:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 2,2025 |  | August 3,2025 |  | November 3,2024 |  | November 2,2025 |  | November 3,2024 |
| Gross margin on GAAP basis |  | $ | 12,249 |  |  | $ | 10,703 |  |  | $ | 9,002 |  |  | $ | 43,294 |  |  | $ | 32,509 |  |
| Amortization of acquisition-related intangible assets |  | 1,545 |  |  | 1,519 |  |  | 1,602 |  |  | 6,031 |  |  | 6,023 |  |
| Stock-based compensation expense |  | 237 |  |  | 251 |  |  | 159 |  |  | 844 |  |  | 664 |  |
| Restructuring charges |  | 8 |  |  | 26 |  |  | 51 |  |  | 76 |  |  | 254 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Gross margin on non-GAAP basis |  | $ | 14,039 |  |  | $ | 12,499 |  |  | $ | 10,814 |  |  | $ | 50,245 |  |  | $ | 39,459 |  |
| Research and development on GAAP basis |  | $ | 2,981 |  |  | $ | 3,050 |  |  | $ | 2,234 |  |  | $ | 10,977 |  |  | $ | 9,310 |  |
| Stock-based compensation expense |  | 1,456 |  |  | 1,573 |  |  | 839 |  |  | 5,020 |  |  | 3,460 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 1,525 |  |  | $ | 1,477 |  |  | $ | 1,395 |  |  | $ | 5,957 |  |  | $ | 5,847 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,107 |  |  | $ | 1,072 |  |  | $ | 1,010 |  |  | $ | 4,211 |  |  | $ | 4,959 |  |
| Stock-based compensation expense |  | 502 |  |  | 498 |  |  | 316 |  |  | 1,704 |  |  | 1,546 |  |
| Acquisition-related costs |  | 12 |  |  | 7 |  |  | 86 |  |  | 216 |  |  | 537 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 593 |  |  | $ | 567 |  |  | $ | 608 |  |  | $ | 2,291 |  |  | $ | 2,876 |  |
| Total operating expenses on GAAP basis |  | $ | 4,741 |  |  | $ | 4,816 |  |  | $ | 4,375 |  |  | $ | 17,810 |  |  | $ | 19,046 |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 507 |  |  | 813 |  |  | 2,031 |  |  | 3,244 |  |
| Stock-based compensation expense |  | 1,958 |  |  | 2,071 |  |  | 1,155 |  |  | 6,724 |  |  | 5,006 |  |
| Restructuring and other charges |  | 146 |  |  | 187 |  |  | 318 |  |  | 591 |  |  | 1,533 |  |
| Acquisition-related costs |  | 12 |  |  | 7 |  |  | 86 |  |  | 216 |  |  | 540 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,118 |  |  | $ | 2,044 |  |  | $ | 2,003 |  |  | $ | 8,248 |  |  | $ | 8,723 |  |
| Operating income on GAAP basis |  | $ | 7,508 |  |  | $ | 5,887 |  |  | $ | 4,627 |  |  | $ | 25,484 |  |  | $ | 13,463 |  |
| Amortization of acquisition-related intangible assets |  | 2,052 |  |  | 2,026 |  |  | 2,415 |  |  | 8,062 |  |  | 9,267 |  |
| Stock-based compensation expense |  | 2,195 |  |  | 2,322 |  |  | 1,314 |  |  | 7,568 |  |  | 5,670 |  |
| Restructuring and other charges |  | 154 |  |  | 213 |  |  | 369 |  |  | 667 |  |  | 1,787 |  |
| Acquisition-related costs |  | 12 |  |  | 7 |  |  | 86 |  |  | 216 |  |  | 549 |  |
| Operating income on non-GAAP basis |  | $ | 11,921 |  |  | $ | 10,455 |  |  | $ | 8,811 |  |  | $ | 41,997 |  |  | $ | 30,736 |  |
| Interest expense on GAAP basis |  | $ | (761) |  |  | $ | (807) |  |  | $ | (916) |  |  | $ | (3,210) |  |  | $ | (3,953) |  |
| Loss on debt extinguishment |  | 20 |  |  | 53 |  |  | 52 |  |  | 138 |  |  | 157 |  |
| Interest expense on non-GAAP basis |  | $ | (741) |  |  | $ | (754) |  |  | $ | (864) |  |  | $ | (3,072) |  |  | $ | (3,796) |  |
| Other income, net on GAAP basis |  | $ | 122 |  |  | $ | 205 |  |  | $ | 52 |  |  | $ | 455 |  |  | $ | 406 |  |
| (Gains) losses on investments |  | (6) |  |  | 10 |  |  | 30 |  |  | 17 |  |  | 12 |  |
| Gain from sale of business |  | — |  |  | (163) |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | — |  |  | 19 |  |  | — |  |  | (15) |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 116 |  |  | $ | 71 |  |  | $ | 82 |  |  | $ | 294 |  |  | $ | 418 |  |

[0001730168-25-000116:8k_2_02:71]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 2,2025 |  | August 3,2025 |  | November 3,2024 |  | November 2,2025 |  | November 3,2024 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (1,649) |  |  | $ | 1,145 |  |  | $ | (442) |  |  | $ | (397) |  |  | $ | 3,748 |  |
| Non-GAAP tax reconciling adjustments (1) |  | 3,231 |  |  | 223 |  |  | 1,506 |  |  | 5,888 |  |  | (123) |  |
| Provision for income taxes on non-GAAP basis |  | $ | 1,582 |  |  | $ | 1,368 |  |  | $ | 1,064 |  |  | $ | 5,491 |  |  | $ | 3,625 |  |
| Net income on GAAP basis |  | $ | 8,518 |  |  | $ | 4,140 |  |  | $ | 4,324 |  |  | $ | 23,126 |  |  | $ | 5,895 |  |
| Amortization of acquisition-related intangible assets |  | 2,052 |  |  | 2,026 |  |  | 2,415 |  |  | 8,062 |  |  | 9,267 |  |
| Stock-based compensation expense |  | 2,195 |  |  | 2,322 |  |  | 1,314 |  |  | 7,568 |  |  | 5,670 |  |
| Restructuring and other charges |  | 154 |  |  | 213 |  |  | 369 |  |  | 667 |  |  | 1,787 |  |
| Acquisition-related costs |  | 12 |  |  | 7 |  |  | 86 |  |  | 216 |  |  | 549 |  |
| Loss on debt extinguishment |  | 20 |  |  | 53 |  |  | 52 |  |  | 138 |  |  | 157 |  |
| (Gains) losses on investments |  | (6) |  |  | 10 |  |  | 30 |  |  | 17 |  |  | 12 |  |
| Gain from sale of business |  | — |  |  | (163) |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | — |  |  | 19 |  |  | — |  |  | (15) |  |  | — |  |
| Non-GAAP tax reconciling adjustments (1) |  | (3,231) |  |  | (223) |  |  | (1,506) |  |  | (5,888) |  |  | 123 |  |
| (Income) loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (119) |  |  | — |  |  | 273 |  |
| Net income on non-GAAP basis |  | $ | 9,714 |  |  | $ | 8,404 |  |  | $ | 6,965 |  |  | $ | 33,728 |  |  | $ | 23,733 |  |
| Net income on GAAP basis |  | $ | 8,518 |  |  | $ | 4,140 |  |  | $ | 4,324 |  |  | $ | 23,126 |  |  | $ | 5,895 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,052 |  |  | 2,026 |  |  | 2,415 |  |  | 8,062 |  |  | 9,267 |  |
| Stock-based compensation expense |  | 2,195 |  |  | 2,322 |  |  | 1,314 |  |  | 7,568 |  |  | 5,670 |  |
| Restructuring and other charges |  | 154 |  |  | 213 |  |  | 369 |  |  | 667 |  |  | 1,787 |  |
| Acquisition-related costs |  | 12 |  |  | 7 |  |  | 86 |  |  | 216 |  |  | 549 |  |
| Loss on debt extinguishment |  | 20 |  |  | 53 |  |  | 52 |  |  | 138 |  |  | 157 |  |
| (Gains) losses on investments |  | (6) |  |  | 10 |  |  | 30 |  |  | 17 |  |  | 12 |  |
| Gain from sale of business |  | — |  |  | (163) |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | — |  |  | 19 |  |  | — |  |  | (15) |  |  | — |  |
| Non-GAAP tax reconciling adjustments (1) |  | (3,231) |  |  | (223) |  |  | (1,506) |  |  | (5,888) |  |  | 123 |  |
| (Income) loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (119) |  |  | — |  |  | 273 |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 741 |  |  | 754 |  |  | 864 |  |  | 3,072 |  |  | 3,796 |  |
| Provision for income taxes on non-GAAP basis |  | 1,582 |  |  | 1,368 |  |  | 1,064 |  |  | 5,491 |  |  | 3,625 |  |
| Depreciation |  | 148 |  |  | 142 |  |  | 156 |  |  | 574 |  |  | 593 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 33 |  |  | 34 |  |  | 40 |  |  | 139 |  |  | 150 |  |
| Adjusted EBITDA |  | $ | 12,218 |  |  | $ | 10,702 |  |  | $ | 9,089 |  |  | $ | 43,004 |  |  | $ | 31,897 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,889 |  |  | 4,860 |  |  | 4,828 |  |  | 4,853 |  |  | 4,778 |  |
| Non-GAAP adjustment (2) |  | 80 |  |  | 112 |  |  | 77 |  |  | 90 |  |  | 99 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,969 |  |  | 4,972 |  |  | 4,905 |  |  | 4,943 |  |  | 4,877 |  |
| Net cash provided by operating activities |  | $ | 7,703 |  |  | $ | 7,166 |  |  | $ | 5,604 |  |  | $ | 27,537 |  |  | $ | 19,962 |  |
| Purchases of property, plant and equipment |  | (237) |  |  | (142) |  |  | (122) |  |  | (623) |  |  | (548) |  |
| Free cash flow |  | $ | 7,466 |  |  | $ | 7,024 |  |  | $ | 5,482 |  |  | $ | 26,914 |  |  | $ | 19,414 |  |

[0001730168-25-000116:8k_2_02:72]
|  |  | Fiscal Quarter Ending |
|  |  | February 1, |
| Expected average diluted share count (3): |  | 2026 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,902 |  |
| Non-GAAP adjustment (2) |  | 67 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,969 |  |

[0001730168-25-000116:8k_2_02:73]
| (1) For the fiscal quarter and fiscal year ended November 2, 2025, non-GAAP tax reconciling adjustments included a one-time discrete non-cash tax benefit of $2.1 billion from the impact of lapses of statutes of limitations. |
| (2) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |
| (3) Excludes the effects of potential share repurchases. |

[0001730168-25-000116:8k_2_02:74]
BROADCOM INC.

[0001730168-25-000116:8k_2_02:75]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-25-000116:8k_2_02:76]
(IN MILLIONS)

[0001730168-25-000116:8k_2_02:77]
|  |  | November 2,2025 |  | November 3,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 16,178 |  |  | $ | 9,348 |  |
| Trade accounts receivable, net |  | 7,145 |  |  | 4,416 |  |
| Inventory |  | 2,270 |  |  | 1,760 |  |
| Other current assets |  | 5,980 |  |  | 4,071 |  |
| Total current assets |  | 31,573 |  |  | 19,595 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,530 |  |  | 2,521 |  |
| Goodwill |  | 97,801 |  |  | 97,873 |  |
| Intangible assets, net |  | 32,273 |  |  | 40,583 |  |
| Other long-term assets |  | 6,915 |  |  | 5,073 |  |
| Total assets |  | $ | 171,092 |  |  | $ | 165,645 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,560 |  |  | $ | 1,662 |  |
| Employee compensation and benefits |  | 2,129 |  |  | 1,971 |  |
| Short-term debt |  | 3,152 |  |  | 1,271 |  |
| Other current liabilities |  | 11,673 |  |  | 11,793 |  |
| Total current liabilities |  | 18,514 |  |  | 16,697 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 61,984 |  |  | 66,295 |  |
| Other long-term liabilities |  | 9,302 |  |  | 14,975 |  |
| Total liabilities |  | 89,800 |  |  | 97,967 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 71,308 |  |  | 67,466 |  |
| Retained earnings |  | 9,761 |  |  | — |  |
| Accumulated other comprehensive income |  | 218 |  |  | 207 |  |
| Total stockholders' equity |  | 81,292 |  |  | 67,678 |  |
| Total liabilities and equity |  | $ | 171,092 |  |  | $ | 165,645 |  |

[0001730168-25-000116:8k_2_02:78]
| BROADCOM INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |
| (IN MILLIONS) |  |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |  |
|  |  | November 2,2025 |  | August 3,2025 |  | November 3,2024 |  | November 2,2025 |  | November 3,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 8,518 |  |  | $ | 4,140 |  |  | $ | 4,324 |  |  | $ | 23,126 |  |  | $ | 5,895 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,085 |  |  | 2,060 |  |  | 2,455 |  |  | 8,201 |  |  | 9,417 |  |  |
| Depreciation |  | 148 |  |  | 142 |  |  | 156 |  |  | 574 |  |  | 593 |  |  |
| Stock-based compensation |  | 2,195 |  |  | 2,322 |  |  | 1,314 |  |  | 7,568 |  |  | 5,741 |  |  |
| Deferred taxes and other non-cash taxes |  | (3,025) |  |  | 284 |  |  | (868) |  |  | (4,008) |  |  | 1,965 |  |  |
| Loss on debt extinguishment |  | 20 |  |  | 53 |  |  | 52 |  |  | 138 |  |  | 157 |  |  |
| Non-cash interest expense |  | 71 |  |  | 82 |  |  | 91 |  |  | 344 |  |  | 427 |  |  |
| Other |  | 36 |  |  | (23) |  |  | 138 |  |  | 94 |  |  | 404 |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (651) |  |  | (937) |  |  | 249 |  |  | (2,717) |  |  | 2,327 |  |  |
| Inventory |  | (90) |  |  | (163) |  |  | 134 |  |  | (510) |  |  | 150 |  |  |
| Accounts payable |  | 118 |  |  | 136 |  |  | (85) |  |  | (118) |  |  | 121 |  |  |
| Employee compensation and benefits |  | 410 |  |  | 511 |  |  | 196 |  |  | 300 |  |  | 78 |  |  |
| Other current assets and current liabilities |  | (809) |  |  | (999) |  |  | (1,410) |  |  | (1,837) |  |  | (5,323) |  |  |
| Other long-term assets and long-term liabilities |  | (1,323) |  |  | (442) |  |  | (1,142) |  |  | (3,618) |  |  | (1,990) |  |  |
| Net cash provided by operating activities |  | 7,703 |  |  | 7,166 |  |  | 5,604 |  |  | 27,537 |  |  | 19,962 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | — |  |  | (25,978) |  |  |
| Proceeds from sales of businesses |  | — |  |  | 300 |  |  | — |  |  | 300 |  |  | 3,485 |  |  |
| Purchases of property, plant and equipment |  | (237) |  |  | (142) |  |  | (122) |  |  | (623) |  |  | (548) |  |  |
| Purchases of investments |  | (336) |  |  | (99) |  |  | (30) |  |  | (597) |  |  | (175) |  |  |
| Sales of investments |  | 101 |  |  | 51 |  |  | 20 |  |  | 248 |  |  | 156 |  |  |
| Other |  | 105 |  |  | (16) |  |  | — |  |  | 92 |  |  | (10) |  |  |
| Net cash provided by (used in) investing activities |  | (367) |  |  | 94 |  |  | (132) |  |  | (580) |  |  | (23,070) |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 4,971 |  |  | 6,960 |  |  | 4,969 |  |  | 15,666 |  |  | 39,954 |  |  |
| Payments on debt obligations |  | (3,638) |  |  | (6,750) |  |  | (7,472) |  |  | (18,478) |  |  | (19,608) |  |  |
| Repayments of commercial paper, net |  | (488) |  |  | (3,373) |  |  | — |  |  | — |  |  | — |  |  |
| Payments of dividends |  | (2,797) |  |  | (2,786) |  |  | (2,484) |  |  | (11,142) |  |  | (9,814) |  |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | — |  |  | (2,450) |  |  | (7,176) |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (58) |  |  | (1,204) |  |  | (3,860) |  |  | (5,216) |  |  |
| Issuance of common stock |  | 103 |  |  | — |  |  | 126 |  |  | 221 |  |  | 190 |  |  |
| Other |  | (27) |  |  | (7) |  |  | (11) |  |  | (84) |  |  | (63) |  |  |
| Net cash used in financing activities |  | (1,876) |  |  | (6,014) |  |  | (6,076) |  |  | (20,127) |  |  | (1,733) |  |  |
| Net change in cash and cash equivalents |  | 5,460 |  |  | 1,246 |  |  | (604) |  |  | 6,830 |  |  | (4,841) |  |  |
| Cash and cash equivalents at beginning of period |  | 10,718 |  |  | 9,472 |  |  | 9,952 |  |  | 9,348 |  |  | 14,189 |  |  |
| Cash and cash equivalents at end of period |  | $ | 16,178 |  |  | $ | 10,718 |  |  | $ | 9,348 |  |  | $ | 16,178 |  |  | $ | 9,348 |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 699 |  |  | $ | 602 |  |  | $ | 738 |  |  | $ | 2,672 |  |  | $ | 3,250 |  |  |
| Cash paid for income taxes |  | $ | 755 |  |  | $ | 822 |  |  | $ | 832 |  |  | $ | 2,589 |  |  | $ | 3,155 |  |  |
