# AVGO notes — 0001730168-25-000121


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001730168-25-000121:notes:1]
Portions of the registrant’s definitive proxy statement for its 2026 annual meeting of stockholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. The registrant’s definitive proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001730168-25-000121:notes:2]
Our cybersecurity risk management program is intended to protect the confidentiality, integrity and availability of our critical systems and information. At any given time, we face cybersecurity risks and threats, some of which are not fully mitigated, and we routinely address newly discovered vulnerabilities. We continuously work to enhance our information security program and risk management efforts. Our program includes processes for identifying, assessing and managing material risks from cybersecurity threats that are guided by the National Institute of Standards & Technology’s Cybersecurity Framework, the ISO 27001 international standard for information security and other applicable industry benchmarks.

[0001730168-25-000121:notes:3]
Our cybersecurity risk management program is integrated into our overall enterprise risk management system and processes, and includes:

[0001730168-25-000121:notes:4]
•a team of professionals within our Global Technology Organization who are responsible for identifying and mitigating cybersecurity risks and managing our security controls and response activities;

[0001730168-25-000121:notes:5]
•risk assessment processes designed to identify cybersecurity risks to our critical systems, information, products, services and our broader enterprise IT environment;

[0001730168-25-000121:notes:6]
•an annual tabletop exercise to simulate a response to a cybersecurity incident; and

[0001730168-25-000121:notes:7]
•mandatory training annually and upon hiring for all employees and contractors on data privacy and cybersecurity topics.

[0001730168-25-000121:notes:8]
When appropriate, we utilize independent, external service providers to assess, test or otherwise assist with certain aspects of our cybersecurity risk management program and related processes, including for penetration testing, threat

[0001730168-25-000121:notes:9]
monitoring and incident response. We also employ a vendor risk assessment process to mitigate risks presented by certain third-party service providers, and we require such providers to manage their cybersecurity risks in conformance to industry standards, notify us of relevant cybersecurity events and satisfy additional contractual requirements.

[0001730168-25-000121:notes:10]
As of the date of this Annual Report on Form 10-K, we are not aware of any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially affected or are reasonably likely to materially affect us, including our business strategy, results of operations, or financial condition. However, despite our efforts, we cannot eliminate all risks from cybersecurity threats, or provide assurances that we have not experienced undetected cybersecurity incidents. For additional information about our cybersecurity-related risks, see Item 1A. Risk Factors in this Annual Report on Form 10-K.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001730168-25-000121:notes:11]
Our Board of Directors is actively involved in overseeing our cybersecurity risk management and shares oversight responsibility and processes with the Audit Committee of the Board of Directors (the “Audit Committee”).

[0001730168-25-000121:notes:12]
Our management, including our Chief Information Officer (“CIO”), in consultation with our Chief Information Security Officer (“CISO”), reviews with the Audit Committee quarterly, or more frequently as determined to be necessary or advisable, regarding our cybersecurity security policies, practices and protective measures, threat intelligence, cybersecurity incidents and related risks. At least quarterly, our CIO also provides the Audit Committee with an update on our enterprise security program that includes procedures and policies for testing vulnerabilities, responding to cybersecurity threats, and training and evaluating our employees. The Audit Committee and management also update our Board of Directors at least quarterly on our cybersecurity performance and risk profile and the effectiveness of our cybersecurity processes. We also have protocols in place for escalating certain cybersecurity incidents to the Audit Committee and the Board of Directors.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001730168-25-000121:notes:13]
Our management, including our Chief Information Officer (“CIO”), in consultation with our Chief Information Security Officer (“CISO”), reviews with the Audit Committee quarterly, or more frequently as determined to be necessary or advisable, regarding our cybersecurity security policies, practices and protective measures, threat intelligence, cybersecurity incidents and related risks. At least quarterly, our CIO also provides the Audit Committee with an update on our enterprise security program that includes procedures and policies for testing vulnerabilities, responding to cybersecurity threats, and training and evaluating our employees. The Audit Committee and management also update our Board of Directors at least quarterly on our cybersecurity performance and risk profile and the effectiveness of our cybersecurity processes. We also have protocols in place for escalating certain cybersecurity incidents to the Audit Committee and the Board of Directors.
Our management, including our CIO and CISO, are responsible for assessing and managing material risks from cybersecurity threats. Our CIO oversees our Global Technology Organization that has primary responsibility for our overall cybersecurity risk management program.


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0001730168-25-000121:notes:14]
Our CIO, who reports to our Chief Executive Officer, has over 20 years of experience managing global IT operations, including strategy, applications, infrastructure, information security, support and execution. Our CISO, who reports to the CIO, has approximately 30 years of cybersecurity experience assessing and managing cybersecurity programs.


## cyd:CybersecurityRiskProcessForInformingManagementOrCommitteesResponsibleTextBlock

[0001730168-25-000121:notes:15]
Our management is informed about and monitors the prevention, detection, mitigation, and remediation of cybersecurity risks and incidents through various means, which may include, among other things, threat intelligence and other information obtained from governmental, public or private sources, including external consultants engaged by us, and alerts and reports produced by security tools deployed in our IT environment.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-25-000121:notes:16]
Overview and Basis of Presentation 
Overview

[0001730168-25-000121:notes:17]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, subsystems and, in some cases, racks. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.

[0001730168-25-000121:notes:18]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The accompanying consolidated financial statements include the results of operations of VMware commencing on November 22, 2023. See Note 4. “Acquisitions” for additional information.

[0001730168-25-000121:notes:19]
Basis of Presentation

[0001730168-25-000121:notes:20]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year ended November 2, 2025 (“fiscal year 2025”) was a 52-week fiscal year. Our fiscal year ended November 3, 2024 (“fiscal year 2024”) was a 53-week fiscal year. Our fiscal year ended October 29, 2023 (“fiscal year 2023”) was a 52-week fiscal year.

[0001730168-25-000121:notes:21]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany balances and transactions have been eliminated in consolidation.
Certain prior period amounts reported in our consolidated statements of operations have been reclassified to conform to the current year presentation. See Note 3. “Revenue from Contracts with Customers” for additional information.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-25-000121:notes:22]
Summary of Significant Accounting Policies 
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. Foreign currency assets and liabilities for monetary accounts are remeasured into U.S. dollars at current exchange rates. Non-monetary items such as inventory and property, plant and equipment, are measured and recorded at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.

[0001730168-25-000121:notes:23]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.

[0001730168-25-000121:notes:24]
Cash and cash equivalents.  We consider all highly liquid investment securities with original maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.

[0001730168-25-000121:notes:25]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the expected credit losses in our existing accounts receivable. We determine the allowance based on historical experience and current economic conditions, among other factors. Allowances for doubtful accounts were not material as of November 2, 2025 or November 3, 2024. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These

[0001730168-25-000121:notes:26]
amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances as of November 2, 2025 and November 3, 2024 were $74 million and $101 million, respectively.

[0001730168-25-000121:notes:27]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-25-000121:notes:28]
Concentration of other risks.  We operate in markets that are highly competitive and rapidly changing. Significant technological changes, shifting customer needs, the emergence of competitive products with new capabilities, general economic conditions worldwide, the ability to safeguard patents and other intellectual property (“IP”) in a rapidly evolving market and reliance on third-party wafer fabricators, assembly and test subcontractors and independent distributors and other factors could affect our financial results.

[0001730168-25-000121:notes:29]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.

[0001730168-25-000121:notes:30]
Retirement benefit plans. For defined benefit pension plans, we consider various factors in determining our respective benefit obligations and net periodic benefit cost, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-25-000121:notes:31]
The key assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on a hypothetical yield curve constructed using high-quality corporate bonds selected to yield cash flows that match the expected timing and amount of the benefit payments. The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy. We evaluate these assumptions at least annually. For the non-U.S. plans, we set assumptions specific to each country. We have elected to measure defined benefit pension plan assets and liabilities as of October 31, which is the month end that is closest to our fiscal year end.

[0001730168-25-000121:notes:32]
Derivative instruments.  We use derivative financial instruments to manage exposure to foreign exchange risk and interest rate risk. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-25-000121:notes:33]
Outstanding derivatives are recognized as assets or liabilities at their fair values based on Level 2 inputs, as defined in the fair value hierarchy. For derivative instruments designated as cash flow hedges, the changes in fair value are initially recognized in other comprehensive income, net of tax in the period of change, and are subsequently reclassified and recognized in the same line item as the hedged item when either the hedged transactions affect earnings or it becomes probable that the hedged transactions will not occur.

[0001730168-25-000121:notes:34]
We use foreign exchange forward contracts to manage exposure to foreign exchange risk. These forward contracts are not designated as hedging instruments, and the changes in fair value are recognized in other income, net in the period of change. We did not have any material foreign exchange forward contracts outstanding as of November 2, 2025 or November 3, 2024. The gains and losses recorded in other income, net for derivative instruments not designated as hedges were not material.

[0001730168-25-000121:notes:35]
During fiscal year 2023 and the fiscal year ended October 30, 2022, we entered into treasury rate lock contracts that mature in approximately one year to hedge variability of cash flows due to changes in the benchmark interest rate of anticipated future debt issuances. These treasury rate locks were designated and accounted for as cash flow hedging instruments. In August 2023, we early settled all treasury rate lock contracts, which had a $5.5 billion notional amount, for a cumulative gain of $371 million, net of $44 million of tax, as a component of accumulated other comprehensive income as of October 29, 2023. The cash receipts from the settlement were included in cash flows from operating activities in the consolidated statement of cash flows during fiscal year 2023. In fiscal years 2025 and 2024, upon the issuance of certain senior notes, as discussed in Note 10. “Borrowings”, we began amortizing a portion of the pre-tax cumulative gain in accumulated other comprehensive income to interest expense using the effective interest method through the maturity dates of the senior notes.

[0001730168-25-000121:notes:36]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years, or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over 3 to 10 years. We use the straight-line method of depreciation for all property, plant and equipment.

[0001730168-25-000121:notes:37]
Leases.  We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize right-of-use (“ROU”) assets and lease liabilities for operating and finance leases with terms greater than 12 months, and account for the lease and non-lease components as a single component. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0001730168-25-000121:notes:38]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three-level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-25-000121:notes:39]
The three levels of the fair value hierarchy under the guidance on fair value measurements are described below:

[0001730168-25-000121:notes:40]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date.

[0001730168-25-000121:notes:41]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-25-000121:notes:42]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Quantitative and qualitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.

[0001730168-25-000121:notes:43]
Business combinations.  We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition-date fair values, except for revenue contracts acquired, which are recognized in accordance with our revenue recognition policy. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets include the present value of projected cash flows regarding the projected revenues, projected expenses which include cost of revenue, research and development and selling, general and administrative expenses, technology obsolescence rate, contributory asset charges, discount rate and income tax rate for developed technology; the projected revenues, customer retention rate, customer ramp up period, discount rate and income tax rate for the customer contracts and related relationships; the projected revenues, technology obsolescence rate, expected costs to develop in-process research and development (“IPR&D”) into commercially

[0001730168-25-000121:notes:44]
viable products, discount rate and income tax rate for the IPR&D; and the projected revenues, brand asset phase-out pattern, brand asset royalty rate, discount rate and the income tax rate for the trade name. Unanticipated events and circumstances may occur which could affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-25-000121:notes:45]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-25-000121:notes:46]
Long-lived assets.  Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets, ROU assets, and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.

[0001730168-25-000121:notes:47]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the product requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-25-000121:notes:48]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-25-000121:notes:49]
Payment terms and conditions vary by contract type, and terms between invoicing and when payment is due are short-term in duration. The timing of revenue recognition and required payments can differ and payment terms are generally structured to provide the customer with predictable and dependable ways to procure our products, not to provide or receive financing from the customer.

[0001730168-25-000121:notes:50]
Nature of Products and Services

[0001730168-25-000121:notes:51]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-25-000121:notes:52]
Products.  Our products revenue consists of sales of semiconductor and semiconductor-based solutions and the license portion of software arrangements when we recognize revenue upfront.

[0001730168-25-000121:notes:53]
We recognize semiconductor products revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product. From time to time, certain customers agree to pay us secure supply fees in exchange for prioritized fulfillment of product orders. Such fees are included in the transaction price of the product orders and are recognized as revenue in the period that control over the products is transferred to the customer.

[0001730168-25-000121:notes:54]
We recognize software products revenue for the upfront license portion of software arrangements sold. Our software arrangements primarily consist of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services. Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. Certain of our software arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue, within products revenue. For software arrangements with termination for convenience provisions, we account for these arrangements as a series of daily contracts, resulting in ratable revenue recognition of software revenue over the contractual period, and include them within subscriptions and services revenue.

[0001730168-25-000121:notes:55]
Subscriptions and services.  Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

[0001730168-25-000121:notes:56]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-25-000121:notes:57]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-25-000121:notes:58]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-25-000121:notes:59]
There are two main categories of NRE contracts that we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost as the services are provided. For NRE contracts that do not meet the over time criteria, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-25-000121:notes:60]
Material rights.  Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-25-000121:notes:61]
Arrangements with Multiple Performance Obligations

[0001730168-25-000121:notes:62]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-25-000121:notes:63]
Allocation of consideration.  We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-25-000121:notes:64]
Standalone selling price.  When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. When directly observable transactions are not available, our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, reasonably available data points such as costs incurred to provide the good or service, market conditions, entity-specific factors such as pricing strategies and objectives, and information about the customer.

[0001730168-25-000121:notes:65]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-25-000121:notes:66]
We also estimate the standalone selling price of our material rights. We estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-25-000121:notes:67]
Other Policies and Judgments

[0001730168-25-000121:notes:68]
Contract modifications.  We may modify contracts to offer customers additional products or services. Each of the additional products and services is generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or a combination of both based on the nature of the modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-25-000121:notes:69]
Right of return.  Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-25-000121:notes:70]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-25-000121:notes:71]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units (“RSUs”) using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”) based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-25-000121:notes:72]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-25-000121:notes:73]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-25-000121:notes:74]
Shipping and handling costs.  Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in cost of revenue for all periods presented.

[0001730168-25-000121:notes:75]
Litigation and settlement costs.  We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.

[0001730168-25-000121:notes:76]
Income taxes.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-25-000121:notes:77]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of

[0001730168-25-000121:notes:78]
deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes or increase the benefit from income taxes. Likewise, if we determine that we are not able to realize all or part of our net deferred tax assets, we increase the provision for income taxes or decrease the benefit from income taxes in the period such determination is made.

[0001730168-25-000121:notes:79]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.

[0001730168-25-000121:notes:80]
Net income per share.  Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and ESPP rights (together referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-25-000121:notes:81]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for purchasing shares under the ESPP and the amount of compensation expense for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0001730168-25-000121:notes:82]
Recently Adopted Accounting Guidance.  In November 2023, the Financial Accounting Standards Board issued Accounting Standards Update 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which enhances disclosures about significant segment expenses. We adopted this standard in the fourth quarter of fiscal year 2025. See Note 13. “Segment Information” for additional information.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-25-000121:notes:83]
Revenue from Contracts with Customers 
Reclassifications to Consolidated Statements of Operations

[0001730168-25-000121:notes:84]
In fiscal year 2025, we included upfront license revenue of $7,800 million within products revenue in our consolidated statements of operations. To conform to the current year presentation, we reclassified $4,601 million and $1,058 million of upfront license revenue from subscriptions and services revenue to products revenue for fiscal years 2024 and 2023, respectively. We also reclassified the related costs for the upfront license revenue, which were immaterial, for the periods presented.

[0001730168-25-000121:notes:85]
In the revenue disaggregation tables by type and by region presented below, we included $5,539 million, $559 million and $1,702 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for fiscal year 2025. To conform to the current year presentation, we reclassified $2,654 million, $650 million, and $1,297 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for fiscal year 2024. We also reclassified $990 million, $9 million, and $59 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for fiscal year 2023.

[0001730168-25-000121:notes:86]
Disaggregation

[0001730168-25-000121:notes:87]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 13. “Segment Information.”

[0001730168-25-000121:notes:88]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

[0001730168-25-000121:notes:89]
|  |  | Fiscal Year 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 7,908 |  |  | $ | 33,596 |  |  | $ | 3,343 |  |  | $ | 44,847 |  |
| Subscriptions and services |  | 11,031 |  |  | 2,300 |  |  | 5,709 |  |  | 19,040 |  |
| Total |  | $ | 18,939 |  |  | $ | 35,896 |  |  | $ | 9,052 |  |  | $ | 63,887 |  |

[0001730168-25-000121:notes:90]
|  |  | Fiscal Year 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 4,898 |  |  | $ | 26,869 |  |  | $ | 3,193 |  |  | $ | 34,960 |  |
| Subscriptions and services |  | 10,072 |  |  | 1,553 |  |  | 4,989 |  |  | 16,614 |  |
| Total |  | $ | 14,970 |  |  | $ | 28,422 |  |  | $ | 8,182 |  |  | $ | 51,574 |  |

[0001730168-25-000121:notes:91]
|  |  | Fiscal Year 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 3,591 |  |  | $ | 23,272 |  |  | $ | 2,086 |  |  | $ | 28,949 |  |
| Subscriptions and services |  | 4,688 |  |  | 648 |  |  | 1,534 |  |  | 6,870 |  |
| Total |  | $ | 8,279 |  |  | $ | 23,920 |  |  | $ | 3,620 |  |  | $ | 35,819 |  |

[0001730168-25-000121:notes:92]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer (“OEM”) customers, contract manufacturers, channel partners, or software customers.

[0001730168-25-000121:notes:93]
Contract Balances

[0001730168-25-000121:notes:94]
Contract assets and contract liabilities balances were as follows:

[0001730168-25-000121:notes:95]
|  |  | November 2,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 8,922 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 13,016 |  |  | $ | 14,495 |  |

[0001730168-25-000121:notes:96]
We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when revenue recognized on a contract exceeds the amount invoiced. A contract asset is a right to consideration that is conditional on something other than the passage of time. A contract asset becomes a receivable when invoiced upon the right to consideration becoming unconditional.

[0001730168-25-000121:notes:97]
We recognize a contract liability when billings on a contract exceed the revenue recognized and there is a future obligation to transfer products or services to a customer. Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment.

[0001730168-25-000121:notes:98]
As of November 2, 2025, approximately 67% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during fiscal year 2025 that was included in the contract liabilities balance as of November 3, 2024 was $9,205 million. The amount of revenue recognized during fiscal year 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,440 million.

[0001730168-25-000121:notes:99]
Remaining Performance Obligations

[0001730168-25-000121:notes:100]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract permits termination for convenience. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of IP.

[0001730168-25-000121:notes:101]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of November 2, 2025 were approximately $33.3 billion. We expect approximately 35% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-25-000121:notes:102]
Acquisitions 
Acquisition of VMware, Inc.

[0001730168-25-000121:notes:103]
On November 22, 2023, we completed the VMware Merger. Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash or 2.52 shares of Broadcom common stock (on a split adjusted basis). The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the VMware Merger. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million.

[0001730168-25-000121:notes:104]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 10. “Borrowings”, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-25-000121:notes:105]
Purchase Consideration

[0001730168-25-000121:notes:106]
|  |  | (In millions) |
| Fair value of Broadcom common stock issued for outstanding VMware common stock |  | $ | 53,398 |  |
| Cash paid for outstanding VMware common stock |  | 30,788 |  |
| Cash paid by Broadcom to retire VMware’s term loan |  | 1,257 |  |
| Fair value of partially vested assumed VMware equity awards |  | 805 |  |
| Fair value of Broadcom common stock issued for accelerated VMware equity awards |  | 23 |  |
| Cash paid for accelerated VMware equity awards |  | 13 |  |
| Effective settlement of pre-existing relationships |  | 6 |  |
| Total purchase consideration |  | 86,290 |  |
| Less: cash acquired |  | 6,642 |  |
| Total purchase consideration, net of cash acquired |  | $ | 79,648 |  |

[0001730168-25-000121:notes:107]
We assumed all outstanding VMware RSU awards and performance stock unit (“PSU”) awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-25-000121:notes:108]
The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-25-000121:notes:109]
|  |  | Fair Value |
|  |  | (In millions) |
| Trade accounts receivable |  | $ | 3,571 |  |
| Inventory |  | 15 |  |
| Assets held-for-sale |  | 5,206 |  |
| Other current assets |  | 757 |  |
| Property, plant and equipment |  | 531 |  |
| Goodwill |  | 54,206 |  |
| Intangible assets |  | 45,572 |  |
| Other long-term assets |  | 1,064 |  |
| Total assets acquired |  | 110,922 |  |
| Accounts payable |  | (359) |  |
| Employee compensation and benefits |  | (848) |  |
| Current portion of long-term debt |  | (1,264) |  |
| Liabilities held-for-sale |  | (1,901) |  |
| Other current liabilities |  | (11,041) |  |
| Long-term debt |  | (6,254) |  |
| Other long-term liabilities |  | (9,607) |  |
| Total liabilities assumed |  | (31,274) |  |
| Fair value of net assets acquired |  | $ | 79,648 |  |

[0001730168-25-000121:notes:110]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the VMware business. The synergies include certain cost savings, operating efficiencies and other strategic benefits projected to be achieved as a result of the VMware Merger. Goodwill is not deductible for tax purposes.

[0001730168-25-000121:notes:111]
Assets and liabilities held-for-sale primarily included the end-user computing (“EUC”) business and certain other assets and liabilities, which were not aligned with our strategic objectives. On July 1, 2024, we sold the EUC business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-25-000121:notes:112]
Our results of continuing operations included $12,384 million of net revenue attributable to VMware for fiscal year 2024. It is impracticable to determine the effect on net income attributable to VMware as we immediately integrated VMware into our ongoing operations. Transaction costs related to the VMware Merger of $255 million were included in selling, general and administrative expense for fiscal year 2024.

[0001730168-25-000121:notes:113]
Intangible Assets

[0001730168-25-000121:notes:114]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 24,156 |  |  | 8 |
| Customer contracts and related relationships |  | 15,239 |  |  | 8 |
| Trade name |  | 1,205 |  |  | 14 |
| Off-market component of customer contracts |  | 242 |  |  | 2 |
| Total identified finite-lived intangible assets |  | 40,842 |  |  |  |
| IPR&D |  | 4,730 |  |  | N/A |
| Total identified intangible assets |  | $ | 45,572 |  |  |  |

[0001730168-25-000121:notes:115]
Developed technology relates to products used for VMware cloud foundation, application management, security, application networking and security, and software-defined edge. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-25-000121:notes:116]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of VMware. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-25-000121:notes:117]
Trade name relates to the “VMware” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-25-000121:notes:118]
Off-market component of customer contracts relate to rebates and marketing development funds provided to customers prior to the VMware Merger. We valued these contracts based on their remaining unamortized balances, which approximate their fair value. The economic useful life was determined based on the remaining terms of customer contracts.

[0001730168-25-000121:notes:119]
The fair value of IPR&D was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-25-000121:notes:120]
The following table presents the details of IPR&D by category as of the date of the VMware Merger:

[0001730168-25-000121:notes:121]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |  |
|  |  | (Dollars in millions) |  |
| VMware cloud foundation July 2024 releases |  | $ | 790 |  |  | 67 | % |  | $ | 38 |  |  | 2024 | (a) |
| VMware cloud foundation March 2025 releases |  | $ | 2,900 |  |  | 58 | % |  | $ | 185 |  |  | 2025 | (b) |
| VMware cloud foundation July 2025 releases |  | $ | 750 |  |  | 43 | % |  | $ | 65 |  |  | 2025 | (c) |
| VMware cloud foundation networking and security virtualization |  | $ | 265 |  |  | 21 | % |  | $ | 59 |  |  | 2024 | (a) |
| Application networking and security |  | $ | 25 |  |  | 21 | % |  | $ | 47 |  |  | 2024 | (a) |

[0001730168-25-000121:notes:122]
____________________________

[0001730168-25-000121:notes:123]
(a) Released during fiscal year 2024.

[0001730168-25-000121:notes:124]
(b) $1,520 million and $1,380 million were released during fiscal years 2025 and 2024, respectively.

[0001730168-25-000121:notes:125]
(c) Expected to be released during the first half of the fiscal year ending November 1, 2026.

[0001730168-25-000121:notes:126]
VMware cloud foundation is a private cloud platform that integrates compute, storage, networking, and management into a single solution and provides license portability. It enables customers to modernize infrastructure and accelerate developer productivity with greater resilience and security.

[0001730168-25-000121:notes:127]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the date of the VMware Merger.

[0001730168-25-000121:notes:128]
Unaudited Pro Forma Information

[0001730168-25-000121:notes:129]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if VMware had been acquired as of the beginning of fiscal year 2023. The unaudited pro forma information includes adjustments to amortization for intangible assets acquired, stock-based compensation expense, interest expense for acquisition financing, amortization of deferred assets and liabilities, and depreciation for property and equipment acquired. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2023 or of the results of our future operations of the combined business.

[0001730168-25-000121:notes:130]
|  |  |  | Fiscal Year |
|  |  |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Pro forma net revenue |  |  | $ | 52,188 |  |  | $ | 48,227 |  |
| Pro forma net income |  |  | $ | 6,473 |  |  | $ | 8,215 |  |

[0001730168-25-000121:notes:131]
Acquisition of Seagate’s SoC Operations

[0001730168-25-000121:notes:132]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip (“SoC”) operations of Seagate Technology Holdings plc for $600 million. We acquired these assets to strengthen our portfolio of SoC products.

[0001730168-25-000121:notes:133]
The following table presents our allocation of the total purchase price. Goodwill is allocated to the semiconductor solutions segment and is deductible for tax purposes.

[0001730168-25-000121:notes:134]
|  |  | Fair Value |
|  |  | (In millions) |
| Intangible assets |  | $ | 570 |  |
| Goodwill |  | 14 |  |
| Other assets |  | 16 |  |
| Total assets acquired |  | $ | 600 |  |

[0001730168-25-000121:notes:135]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Customer contracts and related relationships |  | $ | 410 |  |  | 11 |
| Developed technology |  | 90 |  |  | 11 |
| Total identified finite-lived intangible assets |  | 500 |  |  |  |
| IPR&D |  | 70 |  |  | N/A |
| Total identified intangible assets |  | $ | 570 |  |  |  |

[0001730168-25-000121:notes:136]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of SoC controller products for hard disk drive applications. Customer contracts and related relationships were valued using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and related relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the useful lives of other intangible assets and the length of time remaining on the acquired contracts.

[0001730168-25-000121:notes:137]
Developed technology relates to SoC controller products for hard disk drive applications. We valued the developed technology using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the developed technology. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.
The fair value of IPR&D was determined using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue from the IPR&D.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-25-000121:notes:138]
Supplemental Financial Information 
Cash Equivalents

[0001730168-25-000121:notes:139]
Cash equivalents included $3,163 million and $1,716 million of time deposits and $2,239 million and $1,171 million of money-market funds as of November 2, 2025 and November 3, 2024, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-25-000121:notes:140]
Accounts Receivable Factoring

[0001730168-25-000121:notes:141]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $7,401 million, $5,900 million and $3,975 million during fiscal years 2025, 2024 and 2023, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any of the periods presented.

[0001730168-25-000121:notes:142]
Inventory

[0001730168-25-000121:notes:143]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Finished goods |  | $ | 682 |  |  | $ | 504 |  |
| Work-in-process |  | 1,280 |  |  | 970 |  |
| Raw materials |  | 308 |  |  | 286 |  |
| Total inventory |  | $ | 2,270 |  |  | $ | 1,760 |  |

[0001730168-25-000121:notes:144]
Property, Plant and Equipment, Net

[0001730168-25-000121:notes:145]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Land |  | $ | 204 |  |  | $ | 204 |  |
| Construction in progress |  | 78 |  |  | 57 |  |
| Buildings and leasehold improvements |  | 1,488 |  |  | 1,518 |  |
| Machinery and equipment |  | 5,656 |  |  | 5,246 |  |
| Total property, plant and equipment |  | 7,426 |  |  | 7,025 |  |
| Accumulated depreciation and amortization |  | (4,896) |  |  | (4,504) |  |
| Total property, plant and equipment, net |  | $ | 2,530 |  |  | $ | 2,521 |  |

[0001730168-25-000121:notes:146]
Depreciation expense was $574 million, $593 million and $502 million for fiscal years 2025, 2024 and 2023, respectively.

[0001730168-25-000121:notes:147]
Other Current Assets

[0001730168-25-000121:notes:148]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 5,005 |  |  | $ | 1,916 |  |
| Prepaid expenses |  | 518 |  |  | 1,391 |  |
| Other |  | 457 |  |  | 764 |  |
| Total other current assets |  | $ | 5,980 |  |  | $ | 4,071 |  |

[0001730168-25-000121:notes:149]
Other Current Liabilities

[0001730168-25-000121:notes:150]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,469 |  |  | $ | 9,395 |  |
| Tax liabilities |  | 921 |  |  | 720 |  |
| Interest payable |  | 620 |  |  | 535 |  |
| Other |  | 663 |  |  | 1,143 |  |
| Total other current liabilities |  | $ | 11,673 |  |  | $ | 11,793 |  |

[0001730168-25-000121:notes:151]
Other Long-Term Liabilities

[0001730168-25-000121:notes:152]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,547 |  |  | $ | 5,100 |  |
| Deferred tax liabilities |  | 2,704 |  |  | 4,703 |  |
| Unrecognized tax benefits, interest and penalties |  | 1,628 |  |  | 3,669 |  |
| Other |  | 1,423 |  |  | 1,503 |  |
| Total other long-term liabilities |  | $ | 9,302 |  |  | $ | 14,975 |  |

[0001730168-25-000121:notes:153]
Other Income, Net

[0001730168-25-000121:notes:154]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Interest income |  | $ | 347 |  |  | $ | 461 |  |  | $ | 535 |  |
| Other income |  | 210 |  |  | 21 |  |  | 15 |  |
| Gain (loss) on investments |  | (17) |  |  | (12) |  |  | 11 |  |
| Other expense |  | (85) |  |  | (64) |  |  | (49) |  |
| Other income, net |  | $ | 455 |  |  | $ | 406 |  |  | $ | 512 |  |

[0001730168-25-000121:notes:155]
Other income and other expense include gains on sales of businesses, foreign exchange gains and losses, factoring fees for the sales of receivables, and other miscellaneous items.

[0001730168-25-000121:notes:156]
Discontinued Operations

[0001730168-25-000121:notes:157]
During fiscal year 2024, we sold the EUC business for $3.5 billion, after working capital adjustments. In connection with the sale, we agreed to provide transitional services to the buyer on a short-term basis. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-25-000121:notes:158]
The following table summarizes the selected financial information of discontinued operations:

[0001730168-25-000121:notes:159]
|  |  |  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |
|  |  |  | 2024 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | (In millions) |
| Net revenue |  |  |  |  |  | $ | 858 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  |  |  |  | $ | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  |  |  |  |  | (261) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations, net of income taxes |  |  |  |  |  | $ | (273) |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001730168-25-000121:notes:160]
Leases
We have operating leases for our facilities, land, data centers and certain equipment. Operating lease expense was $182 million, $187 million and $91 million for fiscal years 2025, 2024 and 2023, respectively.

[0001730168-25-000121:notes:161]
Other operating lease information, which included the impact of VMware leases acquired on November 22, 2023, was as follows:

[0001730168-25-000121:notes:162]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Cash paid for leases included in operating cash flows |  | $ | 277 |  |  | $ | 223 |  |  | $ | 90 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 220 |  |  | $ | 1,165 |  |  | $ | 28 |  |

[0001730168-25-000121:notes:163]
|  |  | November 2,2025 |  | November 3,2024 |  |
| Weighted-average remaining lease term (in years) |  | 11 |  | 11 |  |
| Weighted-average discount rate |  | 4.78 |  | % | 5.31 |  | % |

[0001730168-25-000121:notes:164]
Supplemental balance sheet information related to operating leases was as follows:

[0001730168-25-000121:notes:165]
|  |  | Classification on the Consolidated Balance Sheets |  | November 2,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| ROU assets |  | Other long-term assets |  | $ | 1,318 |  |  | $ | 1,325 |  |
| Short-term lease liabilities |  | Other current liabilities |  | $ | 144 |  |  | $ | 207 |  |
| Long-term lease liabilities |  | Other long-term liabilities |  | $ | 1,181 |  |  | $ | 1,143 |  |

[0001730168-25-000121:notes:166]
Future minimum operating lease payments under non-cancelable leases as of November 2, 2025 were as follows:

[0001730168-25-000121:notes:167]
|  |  | (In millions) |  |  |
| 2026 |  | $ | 212 |  |  |  |
| 2027 |  | 196 |  |  |  |
| 2028 |  | 168 |  |  |  |
| 2029 |  | 144 |  |  |  |
| 2030 |  | 128 |  |  |  |
| Thereafter |  | 877 |  |  |  |
| Total undiscounted liabilities |  | 1,725 |  |  |  |
| Less: interest |  | (400) |  |  |  |
| Present value of lease liabilities |  | $ | 1,325 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-25-000121:notes:168]
Goodwill and Intangible Assets 
Goodwill

[0001730168-25-000121:notes:169]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  |  |  |  |  |  |  |  |  | (In millions) |
| Balance as of October 29, 2023 |  |  |  |  |  |  |  |  |  | $ | 26,001 |  |  | $ | 17,652 |  |  | $ | 43,653 |  |
| Acquisition of VMware |  |  |  |  |  |  |  |  |  | — |  |  | 54,206 |  |  | 54,206 |  |
| Acquisition of Seagate's SoC operations |  |  |  |  |  |  |  |  |  | 14 |  |  | — |  |  | 14 |  |
| Balance as of November 3, 2024 |  |  |  |  |  |  |  |  |  | 26,015 |  |  | 71,858 |  |  | 97,873 |  |
| Sales of businesses |  |  |  |  |  |  |  |  |  | (2) |  |  | (70) |  |  | (72) |  |
| Balance as of November 2, 2025 |  |  |  |  |  |  |  |  |  | $ | 26,013 |  |  | $ | 71,788 |  |  | $ | 97,801 |  |

[0001730168-25-000121:notes:170]
During the fourth quarter of fiscal years 2025, 2024 and 2023, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-25-000121:notes:171]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of November 2, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 32,781 |  |  | $ | (14,401) |  |  | $ | 18,380 |  |
| Customer contracts and related relationships |  | 15,791 |  |  | (4,003) |  |  | 11,788 |  |
| Trade names |  | 1,612 |  |  | (399) |  |  | 1,213 |  |
| Other |  | 186 |  |  | (114) |  |  | 72 |  |
| Intangible assets subject to amortization |  | 50,370 |  |  | (18,917) |  |  | 31,453 |  |
| IPR&D |  | 820 |  |  | — |  |  | 820 |  |
| Total |  | $ | 51,190 |  |  | $ | (18,917) |  |  | $ | 32,273 |  |
| As of November 3, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (12,551) |  |  | $ | 22,916 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,271) |  |  | 13,915 |  |
| Trade names |  | 1,720 |  |  | (369) |  |  | 1,351 |  |
| Other |  | 166 |  |  | (105) |  |  | 61 |  |
| Intangible assets subject to amortization |  | 53,539 |  |  | (15,296) |  |  | 38,243 |  |
| IPR&D |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,879 |  |  | $ | (15,296) |  |  | $ | 40,583 |  |

[0001730168-25-000121:notes:172]
Based on the amount of intangible assets subject to amortization at November 2, 2025, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-25-000121:notes:173]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2026 |  | $ | 7,880 |  |
| 2027 |  | 6,805 |  |
| 2028 |  | 5,673 |  |
| 2029 |  | 4,547 |  |
| 2030 |  | 3,365 |  |
| Thereafter |  | 3,183 |  |
| Total |  | $ | 31,453 |  |

[0001730168-25-000121:notes:174]
The weighted-average remaining amortization periods by intangible asset category were as follows:

[0001730168-25-000121:notes:175]
| Amortizable intangible assets: |  | November 2,2025 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 6 |
| Trade names |  | 11 |
| Other |  | 11 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-25-000121:notes:176]
Net Income Per Share

[0001730168-25-000121:notes:177]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 23,126 |  |  | $ | 6,168 |  |  | $ | 14,082 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (273) |  |  | — |  |
| Net income |  | $ | 23,126 |  |  | $ | 5,895 |  |  | $ | 14,082 |  |
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,712 |  |  | 4,624 |  |  | 4,149 |  |
| Dilutive effect of equity awards |  | 141 |  |  | 154 |  |  | 123 |  |
| Weighted-average shares outstanding - diluted |  | 4,853 |  |  | 4,778 |  |  | 4,272 |  |
| Basic income per share: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.91 |  |  | $ | 1.33 |  |  | $ | 3.39 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.06) |  |  | — |  |
| Net income per share |  | $ | 4.91 |  |  | $ | 1.27 |  |  | $ | 3.39 |  |
| Diluted income per share: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.77 |  |  | $ | 1.29 |  |  | $ | 3.30 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.06) |  |  | — |  |
| Net income per share |  | $ | 4.77 |  |  | $ | 1.23 |  |  | $ | 3.30 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-25-000121:notes:178]
Retirement Plans 
Defined Benefit Pension Plans

[0001730168-25-000121:notes:179]
The U.S. defined benefit pension plans primarily consist of a qualified pension plan. Benefits of the qualified pension plan are provided under an adjusted career-average-pay program, a cash-balance program or a dollar-per-month program. Benefit accruals under this plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the dollar-per-month program.

[0001730168-25-000121:notes:180]
For certain non-U.S. countries, we also have defined benefit pension plans for eligible employees. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-25-000121:notes:181]
Net Periodic Benefit Cost

[0001730168-25-000121:notes:182]
|  |  | Fiscal Year |  |  |
|  |  | 2025 |  | 2024 |  | 2023 |  |  |  |  |  |  |
|  |  | (In millions) |
| Service cost |  | $ | 13 |  |  | $ | 17 |  |  | $ | 8 |  |  |  |  |  |  |  |
| Interest cost |  | 56 |  |  | 63 |  |  | 60 |  |  |  |  |  |  |  |
| Expected return on plan assets |  | (53) |  |  | (60) |  |  | (59) |  |  |  |  |  |  |  |
| Other |  | (3) |  |  | (2) |  |  | — |  |  |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 13 |  |  | $ | 18 |  |  | $ | 9 |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  | $ | (1) |  |  | $ | (3) |  |  | $ | 20 |  |  |  |  |  |  |  |

[0001730168-25-000121:notes:183]
The components of net periodic benefit cost other than the service cost are included in other income, net and service cost is recognized in operating expenses in the consolidated statements of operations.

[0001730168-25-000121:notes:184]
Benefit Obligations and Plan Assets

[0001730168-25-000121:notes:185]
|  |  | Pension Benefits |  |  |
|  |  | November 2,2025 |  | November 3,2024 |  |  |  |  |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,158 |  |  | $ | 1,105 |  |  |  |  |  |
| Actual return on plan assets |  | 120 |  |  | 123 |  |  |  |  |  |
| Employer contributions |  | 28 |  |  | 21 |  |  |  |  |  |
| Plan participants’ contributions |  | 1 |  |  | 1 |  |  |  |  |  |
| Benefit payments |  | (107) |  |  | (108) |  |  |  |  |  |
| Plan assets acquired in VMware acquisition |  | — |  |  | 18 |  |  |  |  |  |
| Foreign currency impact |  | (3) |  |  | (2) |  |  |  |  |  |
| Fair value of plan assets — end of period |  | 1,197 |  |  | 1,158 |  |  |  |  |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,194 |  |  | 1,101 |  |  |  |  |  |
| Service cost |  | 13 |  |  | 17 |  |  |  |  |  |
| Interest cost |  | 56 |  |  | 63 |  |  |  |  |  |
| Actuarial loss |  | 86 |  |  | 65 |  |  |  |  |  |
| Plan participants’ contributions |  | 1 |  |  | 1 |  |  |  |  |  |
| Benefit payments |  | (107) |  |  | (108) |  |  |  |  |  |
| Curtailments |  | (4) |  |  | (13) |  |  |  |  |  |
| Benefit obligations assumed in VMware acquisition |  | — |  |  | 72 |  |  |  |  |  |
| Foreign currency impact |  | (3) |  |  | (4) |  |  |  |  |  |
| Benefit obligations — end of period |  | 1,236 |  |  | 1,194 |  |  |  |  |  |
| Underfunded status of benefit obligations (a) |  | $ | (39) |  |  | $ | (36) |  |  |  |  |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive income, net of taxes |  | $ | (111) |  |  | $ | (106) |  |  |  |  |  |

[0001730168-25-000121:notes:186]
_______________________________

[0001730168-25-000121:notes:187]
(a)Substantially all amounts recognized on the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented.

[0001730168-25-000121:notes:188]
Plans with benefit obligations less than plan assets:

[0001730168-25-000121:notes:189]
|  |  | November 2,2025 |  | November 3,2024 |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 136 |  |  | $ | 1,064 |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 135 |  |  | $ | 1,063 |  |  |  |  |  |
| Fair value of plan assets |  | $ | 193 |  |  | $ | 1,118 |  |  |  |  |  |

[0001730168-25-000121:notes:190]
Plans with benefit obligations in excess of plan assets:

[0001730168-25-000121:notes:191]
|  |  | November 2,2025 |  | November 3,2024 |  |  |  |  |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 1,100 |  |  | $ | 130 |  |  |  |  |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 1,066 |  |  | $ | 99 |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets |  | $ | 1,004 |  |  | $ | 40 |  |  |  |  |  |  |  |  |  |

[0001730168-25-000121:notes:192]
The fair value of pension plan assets as of November 2, 2025 and November 3, 2024 included $299 million and $229 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-25-000121:notes:193]
The projected benefit obligations as of November 2, 2025 and November 3, 2024 included $329 million and $260 million, respectively, of obligations related to our non-U.S. pension plans. The accumulated benefit obligations as of November 2, 2025 and November 3, 2024 included $294 million and $229 million, respectively, of obligations related to our non-U.S. pension plans.

[0001730168-25-000121:notes:194]
Expected Future Benefit Payments

[0001730168-25-000121:notes:195]
| Fiscal Years: |  | Expected Benefit Payments |  |  |
|  |  | (In millions) |
| 2026 |  | $ | 102 |  |  |  |
| 2027 |  | $ | 96 |  |  |  |
| 2028 |  | $ | 95 |  |  |  |
| 2029 |  | $ | 94 |  |  |  |
| 2030 |  | $ | 92 |  |  |  |
| 2031-2035 |  | $ | 423 |  |  |  |

[0001730168-25-000121:notes:196]
Investment Policy

[0001730168-25-000121:notes:197]
Plan assets of the U.S. qualified pension plan, which represent substantially all of the plan assets, are generally invested in funds held by third-party fund managers. Our benefit plan investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has the discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-25-000121:notes:198]
The target asset allocation for the U.S. qualified pension plan reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2025 and 2024, 100% of the U.S. qualified pension plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-25-000121:notes:199]
Fair Value Measurement of Plan Assets

[0001730168-25-000121:notes:200]
|  |  | November 2, 2025 |  |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |  |  |
|  |  | (In millions) |  |  |
| Cash equivalents |  | $ | 17 |  | (a) |  | $ | — |  |  |  |  |  | $ | 17 |  |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 40 |  | (b) |  | — |  |  |  |  |  | 40 |  |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 116 |  | (c) |  |  |  | 116 |  |  |  |
| Corporate bonds |  | — |  |  |  | 820 |  | (c) |  |  |  | 820 |  |  |  |
| Municipal bonds |  | — |  |  |  | 18 |  | (c) |  |  |  | 18 |  |  |  |
| Government bonds |  | — |  |  |  | 47 |  | (c) |  |  |  | 47 |  |  |  |
| Plan assets measured by fair value hierarchy |  | $ | 57 |  |  |  | $ | 1,001 |  |  |  |  |  | 1,058 |  |  |  |
| Plan assets measured at net asset value |  |  |  |  |  |  |  |  |  | 139 |  | (d) |  |
| Total plan assets |  |  |  |  |  |  |  |  |  | $ | 1,197 |  |  |  |

[0001730168-25-000121:notes:201]
|  |  | November 3, 2024 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |  |
|  |  | (In millions) |  |
| Cash equivalents |  | $ | 17 |  | (a) |  | $ | — |  |  |  |  |  | $ | 17 |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 83 |  | (b) |  | — |  |  |  |  |  | 83 |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 184 |  | (c) |  |  |  | 184 |  |  |
| Corporate bonds |  | — |  |  |  | 715 |  | (c) |  |  |  | 715 |  |  |
| Municipal bonds |  | — |  |  |  | 22 |  | (c) |  |  |  | 22 |  |  |
| Government bonds |  | — |  |  |  | 14 |  | (c) |  |  |  | 14 |  |  |
| Asset-backed securities |  | — |  |  |  | 1 |  | (c) |  |  |  | 1 |  |  |
| Plan assets measured by fair value hierarchy |  | $ | 100 |  |  |  | $ | 936 |  |  |  |  |  | 1,036 |  |  |
| Plan assets measured at net asset value |  |  |  |  |  |  |  |  |  | 122 |  | (d) |
| Total plan assets |  |  |  |  |  |  |  |  |  | $ | 1,158 |  |  |

[0001730168-25-000121:notes:202]
______________________________

[0001730168-25-000121:notes:203]
(a)Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets.

[0001730168-25-000121:notes:204]
(b)These equity securities were valued based on quoted prices in active markets.

[0001730168-25-000121:notes:205]
(c)These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the assets, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals.

[0001730168-25-000121:notes:206]
(d)Plan assets measured at fair value using net asset value as a practical expedient were excluded from the fair value hierarchy.

[0001730168-25-000121:notes:207]
Assumptions

[0001730168-25-000121:notes:208]
The assumptions used to determine the benefit obligations and net periodic benefit cost for our defined benefit pension plans are presented in the table below. The expected long-term return on assets shown in the table below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes in which the pension funds are invested. Discount rates reflect the current rate at which defined benefit pension obligations could be settled based on the measurement dates of the plans, which is October 31, the month end closest to our fiscal year end. The range of assumptions reflects the different economic environments within various countries.

[0001730168-25-000121:notes:209]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit CostFiscal Year |
|  |  | November 2,2025 |  | November 3,2024 |  | 2025 |  | 2024 |  | 2023 |
| Discount rate |  | 1.00%-6.75% |  | 1.75%-6.75% |  | 1.75%-6.75% |  | 1.75%-7.10% |  | 1.25%-7.25% |
| Average increase in compensation levels |  | 1.50%-8.85% |  | 2.00%-8.80% |  | 2.00%-8.85% |  | 2.00%-8.80% |  | 2.00%-10.00% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 2.50%-6.75% |  | 2.50%-7.25% |  | 2.50%-7.00% |

[0001730168-25-000121:notes:210]
Defined Contribution Plans

[0001730168-25-000121:notes:211]
Our eligible U.S. employees participate in a company-sponsored 401(k) plan. Under the plan, we match employee contributions dollar for dollar up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2025, 2024 and 2023, we made contributions of $174 million, $210 million and $100 million, respectively, to the 401(k) plan. The increase in fiscal year 2024 was due to the VMware Merger.
In addition, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans.


## us-gaap:DebtDisclosureTextBlock

[0001730168-25-000121:notes:212]
Borrowings

[0001730168-25-000121:notes:213]
|  |  | Effective Interest Rate |  | November 2,2025 |  | November 3,2024 |
|  |  | (Dollars in millions) |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | $ | 1,000 |  |  | $ | — |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | — |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |

[0001730168-25-000121:notes:214]
|  |  | Effective Interest Rate |  | November 2,2025 |  | November 3,2024 |
|  |  | (Dollars in millions) |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | — |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 777 |  |  | 4,194 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | — |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 7,000 |  |
| Assumed CA Senior Notes |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | — |  |  | 215 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 65,370 |  |  | 56,252 |  |

[0001730168-25-000121:notes:215]
|  |  | Effective Interest Rate |  | November 2,2025 |  | November 3,2024 |
|  |  | (Dollars in millions) |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 13,595 |  |
| Total debt principal outstanding |  |  |  | $ | 67,120 |  |  | $ | 69,847 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,152 |  |  | $ | 1,245 |  |
| Short-term finance lease liabilities |  |  |  | — |  |  | 26 |  |
| Total short-term debt |  |  |  | $ | 3,152 |  |  | $ | 1,271 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 63,968 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  |  |  | — |  |  | 13 |  |
| Unamortized discount and issuance costs |  |  |  | (1,984) |  |  | (2,320) |  |
| Total long-term debt |  |  |  | $ | 61,984 |  |  | $ | 66,295 |  |

[0001730168-25-000121:notes:216]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives. See Note 2. "Summary of Significant Accounting Policies" for additional information for derivative instruments.

[0001730168-25-000121:notes:217]
The senior notes and term loans are recorded net of discount and issuance costs, which are amortized to interest expense over the respective terms of such instruments.

[0001730168-25-000121:notes:218]
Senior Notes

[0001730168-25-000121:notes:219]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. With the exception of the senior notes issued in September 2025, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

[0001730168-25-000121:notes:220]
During fiscal year 2025, we issued senior unsecured notes for an aggregate principal amount of $3.0 billion in January 2025, $6.0 billion in July 2025, and $5.0 billion in September 2025. We repaid and redeemed a total of $4,882 million of senior notes.

[0001730168-25-000121:notes:221]
Fixed-Rate Term Loans

[0001730168-25-000121:notes:222]
We entered into a $750 million three-year term loan at a 4.489% fixed rate on May 2, 2025 and a $1.0 billion three-year term loan at a 4.540% fixed rate on May 9, 2025. Interest on the term loans is due quarterly. We are permitted to prepay the term loans at any time, subject to a specified make-whole premium determined in accordance with the credit agreements governing the respective term loans, plus accrued and unpaid interest.

[0001730168-25-000121:notes:223]
2025 Credit Agreement

[0001730168-25-000121:notes:224]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either November 2, 2025 or November 3, 2024.

[0001730168-25-000121:notes:225]
Commercial Paper

[0001730168-25-000121:notes:226]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either November 2, 2025 or November 3, 2024.

[0001730168-25-000121:notes:227]
2023 Term Loans

[0001730168-25-000121:notes:228]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered a series of unsecured facilities for an aggregate principal amount of $30,390 million (the “2023 Term Loans”). The 2023 Term Loans bore interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). Subject to the terms of the 2023 Credit Agreement, we were permitted to voluntarily make prepayments of the term loans without penalty. During fiscal year 2025, we repaid the remaining $13,595 million of 2023 Term Loans and terminated the 2023 Credit Agreement. As a result of these repayments, we wrote off unamortized discount and issuance costs of $118 million, which were included in interest expense in the consolidated statements of operations.

[0001730168-25-000121:notes:229]
Fair Value of Debt

[0001730168-25-000121:notes:230]
As of November 2, 2025, the estimated aggregate fair value of our debt was $64,609 million which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-25-000121:notes:231]
Future Principal Payments of Debt

[0001730168-25-000121:notes:232]
The future scheduled principal payments of debt as of November 2, 2025 were as follows:

[0001730168-25-000121:notes:233]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2026 |  | $ | 3,152 |  |
| 2027 |  | 2,500 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| 2030 |  | 6,406 |  |
| Thereafter |  | 43,287 |  |
| Total |  | $ | 67,120 |  |

[0001730168-25-000121:notes:234]
As of November 2, 2025 and November 3, 2024, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-25-000121:notes:235]
Stockholders’ Equity 
Cash Dividends Declared and Paid

[0001730168-25-000121:notes:236]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 2.360 |  |  | $ | 2.105 |  |  | $ | 1.840 |  |
| Dividends to common stockholders |  | $ | 11,142 |  |  | $ | 9,814 |  |  | $ | 7,645 |  |

[0001730168-25-000121:notes:237]
Stock Repurchase Programs

[0001730168-25-000121:notes:238]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025, which was extended to December 31, 2026 subsequent to fiscal year 2025. During fiscal year 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million  with a $7,550 million remaining authorized amount available for future purchases as of November 2, 2025. Repurchases under this stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000121:notes:239]
In December 2021 and May 2022, our Board of Directors authorized stock repurchase programs to repurchase up to an aggregate of $20 billion of our common stock from time to time through December 31, 2023. During fiscal years 2024 and 2023, we repurchased and retired 67 million and 91 million shares of our common stock for $7,176 million and $5,824 million, respectively. All $20 billion of the aggregate authorized amount was utilized prior to expiration on December 31, 2023.

[0001730168-25-000121:notes:240]
Equity Incentive Award Plans

[0001730168-25-000121:notes:241]
2012 Plan

[0001730168-25-000121:notes:242]
Under the Broadcom Inc. 2012 Stock Incentive Plan (the “2012 Plan”), we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock awards, and RSUs to employees. No participant may be granted such awards for more than an aggregate of 40 million shares in any fiscal year. Equity awards granted generally vest over four years. The total shares authorized for issuance under the 2012 Plan are 450 million. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of November 2, 2025, 299 million shares remained available for issuance under the 2012 Plan.

[0001730168-25-000121:notes:243]
We may grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2025, 2024 and 2023, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 200% of the original grant at vesting based upon the total stockholder return (“TSR”) on our common stock on an absolute basis and as compared to the TSR of an index group of companies. During fiscal year 2023, we also granted market-based RSUs vesting over five years, subject to satisfaction of stock price performance milestones.

[0001730168-25-000121:notes:244]
2007 Plan

[0001730168-25-000121:notes:245]
In connection with the VMware Merger, we assumed the VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan (the “2007 Plan”) and outstanding unvested RSU awards and PSU awards originally granted by VMware under the 2007 Plan that were held by continuing employees. These assumed awards were converted into approximately 46 million Broadcom RSUs and will vest in accordance with their original terms, generally over four years. Under the 2007 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock, RSUs, and other stock-based or cash-based awards to employees. Equity awards granted under the 2007 Plan following the VMware Merger are expected to be on similar terms and consistent with similar grants made pursuant to the 2012 Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of November 2, 2025, 33 million shares remained available for issuance under the 2007 Plan.

[0001730168-25-000121:notes:246]
Employee Stock Purchase Plan

[0001730168-25-000121:notes:247]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or the end of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974.

[0001730168-25-000121:notes:248]
Stock-Based Compensation Expense

[0001730168-25-000121:notes:249]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 218 |  |  | $ | 119 |  |  | $ | 88 |  |
| Cost of subscriptions and services |  | 626 |  |  | 545 |  |  | 122 |  |
| Research and development |  | 5,020 |  |  | 3,460 |  |  | 1,513 |  |
| Selling, general and administrative |  | 1,704 |  |  | 1,546 |  |  | 448 |  |
| Total stock-based compensation expense(a) |  | $ | 7,568 |  |  | $ | 5,670 |  |  | $ | 2,171 |  |
| Estimated income tax benefits for stock-based compensation |  | $ | 1,278 |  |  | $ | 991 |  |  | $ | 367 |  |
| Excess income tax benefits for stock-based awards exercised or released |  | $ | 2,186 |  |  | $ | 1,296 |  |  | $ | 507 |  |

[0001730168-25-000121:notes:250]
_____________________________

[0001730168-25-000121:notes:251]
(a) Does not include stock-based compensation expense related to discontinued operations recognized during fiscal year 2024, which was included in loss from discontinued operations, net of income taxes in our consolidated statement of operations.

[0001730168-25-000121:notes:252]
Stock-based compensation expense for fiscal years 2025 and 2024 included $479 million and $1,613 million, respectively, related to equity awards assumed in connection with the VMware Merger.

[0001730168-25-000121:notes:253]
During the second quarter of fiscal year 2025, we granted two-year time- and market-based RSU awards (the “Two-Year Equity Awards”) in lieu of our annual employee equity awards historically granted in the second quarter of each fiscal year. Each of the Two-Year Equity Awards vests on the same basis as two annual grants with staggered vesting start dates of March 15, 2025 and March 15, 2026 and successive four-year vesting periods. We recognize stock-based compensation expense related to these awards from the grant date through their respective vesting date, ranging from four to five years. Stock-based compensation expense related to the Two-Year Equity Awards was $2,846 million for fiscal year 2025.

[0001730168-25-000121:notes:254]
As of November 2, 2025, the total unrecognized compensation cost related to unvested stock-based awards was $23,833 million, which is expected to be recognized over the remaining weighted-average service period of 3.4 years.

[0001730168-25-000121:notes:255]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-25-000121:notes:256]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
| Risk-free interest rate |  | 4.0 | % |  | 4.2 | % |  | 4.0 | % |
| Dividend yield |  | 1.2 | % |  | 1.7 | % |  | 3.3 | % |
| Volatility |  | 39.1 | % |  | 32.0 | % |  | 32.8 | % |
| Expected term (in years) |  | 4.4 |  | 3.6 |  | 4.8 |

[0001730168-25-000121:notes:257]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-25-000121:notes:258]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-25-000121:notes:259]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-25-000121:notes:260]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-25-000121:notes:261]
Restricted Stock Unit Awards

[0001730168-25-000121:notes:262]
A summary of RSU activity was as follows:

[0001730168-25-000121:notes:263]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |
|  |  | (In millions, except per share data) |
| Balance as of October 30, 2022 |  | 175 |  |  | $ | 23.85 |  |  |  |
| Granted |  | 124 |  |  | $ | 51.98 |  |  |  |
| Vested |  | (74) |  |  | $ | 26.25 |  |  |  |
| Forfeited |  | (7) |  |  | $ | 30.79 |  |  |  |
| Balance as of October 29, 2023 |  | 218 |  |  | $ | 38.92 |  |  |  |
| Assumed in VMware Merger |  | 46 |  |  | $ | 96.85 |  |  |  |
| Granted |  | 81 |  |  | $ | 115.58 |  |  |  |
| Vested |  | (107) |  |  | $ | 54.34 |  |  |  |
| Forfeited |  | (25) |  |  | $ | 88.62 |  |  |  |
| Balance as of November 3, 2024 |  | 213 |  |  | $ | 66.44 |  |  |  |
| Granted |  | 120 |  |  | $ | 192.37 |  |  |  |
| Vested |  | (87) |  |  | $ | 71.63 |  |  |  |
| Forfeited |  | (17) |  |  | $ | 108.28 |  |  |  |
| Balance as of November 2, 2025 |  | 229 |  |  | $ | 127.63 |  |  |  |

[0001730168-25-000121:notes:264]
The aggregate fair value of RSUs that vested in fiscal years 2025, 2024 and 2023 was $21,721 million, $14,914 million and $5,423 million, respectively, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-25-000121:notes:265]
Income Taxes 
The components of income before income taxes by U.S. and foreign jurisdictions were as follows:

[0001730168-25-000121:notes:266]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Domestic income (loss) |  | $ | 2,507 |  |  | $ | (4,851) |  |  | $ | (63) |  |
| Foreign income |  | 20,222 |  |  | 14,767 |  |  | 15,160 |  |
| Income from continuing operations before income taxes |  | $ | 22,729 |  |  | $ | 9,916 |  |  | $ | 15,097 |  |

[0001730168-25-000121:notes:267]
The components of the provision for (benefit from) income taxes were as follows:

[0001730168-25-000121:notes:268]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Current tax provision: |  |  |  |  |  |  |
| Federal |  | $ | 660 |  |  | $ | 1,030 |  |  | $ | 952 |  |
| State |  | 185 |  |  | 52 |  |  | 23 |  |
| Foreign |  | 791 |  |  | 701 |  |  | 541 |  |
| Total |  | 1,636 |  |  | 1,783 |  |  | 1,516 |  |
| Deferred tax provision (benefit): |  |  |  |  |  |  |
| Federal |  | (1,844) |  |  | 1,855 |  |  | (499) |  |
| State |  | (257) |  |  | (70) |  |  | (31) |  |
| Foreign |  | 68 |  |  | 180 |  |  | 29 |  |
| Total |  | (2,033) |  |  | 1,965 |  |  | (501) |  |
| Total provision for (benefit from) income taxes |  | $ | (397) |  |  | $ | 3,748 |  |  | $ | 1,015 |  |

[0001730168-25-000121:notes:269]
The following is a reconciliation of our effective tax rate to the statutory federal tax rate:

[0001730168-25-000121:notes:270]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
| Statutory tax rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State, net of federal benefit |  | (0.2) |  |  | (0.1) |  |  | — |  |
| Foreign income taxed at different rates |  | (14.9) |  |  | (22.4) |  |  | (17.3) |  |
| Deemed inclusion of foreign earnings |  | 7.1 |  |  | 16.3 |  |  | 9.9 |  |
| Change in valuation allowance |  | 5.8 |  |  | — |  |  | — |  |
| Impact of non-recurring intra-group transfer of certain IP rights |  | — |  |  | 39.6 |  |  | — |  |
| Releases and settlements from statutes expirations |  | (7.9) |  |  | — |  |  | (2.2) |  |
| Tax contingency interest accrual |  | 0.3 |  |  | 1.8 |  |  | 0.3 |  |
| Excess tax benefits from stock-based compensation |  | (9.6) |  |  | (13.1) |  |  | (3.4) |  |
| Research and development credit |  | (3.8) |  |  | (6.0) |  |  | (1.8) |  |
| Other, net |  | 0.5 |  |  | 0.7 |  |  | 0.2 |  |
| Effective tax rate on income before income taxes |  | (1.7) | % |  | 37.8 | % |  | 6.7 | % |

[0001730168-25-000121:notes:271]
On July 4, 2025, the United States enacted the One Big Beautiful Bill Act, which allows for the immediate expensing of domestic research and development costs and certain capital expenditures, and changes the United States taxation of profits derived from foreign operations. As a result, it is no longer more-likely-than-not that we are able to utilize our federal corporate alternative minimum tax (“CAMT”) credits, and we established a $1,321 million valuation allowance against our CAMT credit carryforwards and CAMT credits generated in the current fiscal year. Our policy is to not consider the impact of future years’ CAMT in our valuation allowance assessment for regular deferred tax assets. Most of the provisions are effective beginning in our fiscal years ending November 1, 2026 or October 31, 2027, with the exception of immediate expensing of qualifying property being effective in fiscal year 2025.

[0001730168-25-000121:notes:272]
The benefit from income taxes in fiscal year 2025 was primarily due to the recognition of uncertain tax benefits from expiration of statutes of limitations and audit settlements, and excess tax benefits from stock-based awards, partially offset by income from operations and a valuation allowance against our CAMT credits.

[0001730168-25-000121:notes:273]
The increase in provision for income taxes in fiscal year 2024 compared to fiscal year 2023 was primarily due to the impact of a non-recurring intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in jurisdictional mix of income, partially offset by an increase in excess tax benefits from stock-based awards.

[0001730168-25-000121:notes:274]
We derive the effective tax rate benefit attributed to foreign income taxed at different rates primarily from our operations in Singapore and Malaysia. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are

[0001730168-25-000121:notes:275]
scheduled to expire through November 2030. We have also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to decrease the provision for income taxes by approximately $2,709 million, $2,261 million and $2,104 million for fiscal years 2025, 2024 and 2023, respectively.

[0001730168-25-000121:notes:276]
Significant components of our deferred tax assets and liabilities consisted of the following:

[0001730168-25-000121:notes:277]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |
| Net operating loss, credits and other carryforwards |  | $ | 4,261 |  |  | $ | 2,905 |  |
| Capitalized research and development |  | 3,581 |  |  | 2,459 |  |
| Deferred revenue |  | 490 |  |  | 776 |  |
| Employee stock awards |  | 474 |  |  | 291 |  |
| Depreciation and amortization |  | 80 |  |  | 81 |  |
| Other deferred income tax assets |  | 519 |  |  | 672 |  |
| Gross deferred income tax assets |  | 9,405 |  |  | 7,184 |  |
| Less: valuation allowance |  | (3,983) |  |  | (2,218) |  |
| Deferred income tax assets |  | 5,422 |  |  | 4,966 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 7,157 |  |  | 8,772 |  |
| Unamortized debt discount and issuance costs |  | 359 |  |  | 420 |  |
| Foreign earnings not indefinitely reinvested |  | 131 |  |  | 105 |  |
| Other deferred income tax liabilities |  | 286 |  |  | 210 |  |
| Deferred income tax liabilities |  | 7,933 |  |  | 9,507 |  |
| Net deferred income tax liabilities |  | $ | (2,511) |  |  | $ | (4,541) |  |

[0001730168-25-000121:notes:278]
The valuation allowance disclosed in the table above relates to all CAMT credit carryforwards and substantially all U.S. state and foreign net operating loss carryforwards and research and development tax credits that may not be realized.

[0001730168-25-000121:notes:279]
We continue to indefinitely reinvest $1,606 million of certain accumulated foreign earnings. The unrecognized deferred income tax liability related to these earnings is estimated to be $169 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-25-000121:notes:280]
As of November 2, 2025, we had tax effected U.S. state net operating loss carryforwards of $182 million and foreign net operating loss carryforwards of $151 million, all of which expire in various years beginning in fiscal year ended November 1, 2026 ("fiscal year 2026"). We had $2,504 million of state research and development tax credits which begin to expire in fiscal year 2026. We had $1,321 million of CAMT credits which do not expire under the current law.

[0001730168-25-000121:notes:281]
Uncertain Tax Positions

[0001730168-25-000121:notes:282]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-25-000121:notes:283]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Beginning balance |  | $ | 5,843 |  |  | $ | 4,655 |  |  | $ | 5,117 |  |
| Lapses of statutes of limitations |  | (3,162) |  |  | (39) |  |  | (634) |  |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | 184 |  |  | 844 |  |  | 26 |  |
| Decreases in balances related to tax positions taken during prior periods |  | (10) |  |  | (9) |  |  | (13) |  |
| Increases in balances related to tax positions taken during current period |  | 371 |  |  | 447 |  |  | 170 |  |
| Decreases in balances related to settlements with taxing authorities |  | (52) |  |  | (55) |  |  | (11) |  |
| Ending balance |  | $ | 3,174 |  |  | $ | 5,843 |  |  | $ | 4,655 |  |

[0001730168-25-000121:notes:284]
We recognize interest and penalties related to unrecognized tax benefits within the provision for (benefit from) income taxes. Accrued interest and penalties were included within other long-term liabilities. In fiscal year 2025, we recognized a benefit of $118 million related to interest and penalties within the benefit from income taxes. During fiscal years 2024 and 2023, we recognized interest and penalties of $144 million and $22 million, respectively, within the provision for income taxes. As of November 2, 2025 and November 3, 2024, the total accrued interest and penalties was approximately $583 million and $701 million, respectively. The decrease in total accrued interest and penalties was primarily the result of the lapses of statutes of limitations.

[0001730168-25-000121:notes:285]
As of November 2, 2025 and November 3, 2024, approximately $3,757 million and $6,544 million, respectively, of the unrecognized tax benefits and accrued interest and penalties would, if recognized, benefit our effective income tax rate. We are subject to U.S. income tax examination for the fiscal years ended October 30, 2022 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for the fiscal years ended October 31, 2005 and later. It is possible that our existing unrecognized tax benefits may change up to $841 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-25-000121:notes:286]
Segment Information 
Reportable Segments

[0001730168-25-000121:notes:287]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment has separate financial information. The CODM considers actual and expected results of regularly provided net revenue and operating income by segment during the budgeting and forecasting processes to support strategic decision-making and to evaluate the performance of and allocate resources to each of the segments. Operating income by segment includes items that are directly attributable to each segment and shared expenses such as marketing, general and administrative activities, facilities and IT expenses. Shared expenses are primarily allocated based on revenue and headcount. The CODM does not evaluate each segment using discrete asset information. The reportable segments are also determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-25-000121:notes:288]
Semiconductor solutions. Our semiconductor solutions are used in a wide array of environments, end products and applications such as enterprise and AI data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-25-000121:notes:289]
Infrastructure software. Our infrastructure software solutions include revenues from software arrangements, related support, and professional services that help enterprises simplify their IT environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical FC SAN products and related software.

[0001730168-25-000121:notes:290]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by segment and, therefore, it is not separately presented. Amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, and acquisition-related costs are not used in evaluating the results of, or in allocating resources to, our segments and therefore are not allocated to each segment. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-25-000121:notes:291]
|  |  | Fiscal Year |
|  |  | 2025 |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Semiconductor solutions: |  |  |  |  |  |  |
| Net revenue |  | $ | 36,858 |  |  | $ | 30,096 |  |  | $ | 28,182 |  |
| Cost of revenue |  | 11,740 |  |  | 9,809 |  |  | 8,447 |  |
| Research and development |  | 3,407 |  |  | 3,140 |  |  | 2,896 |  |
| Selling, general and administrative |  | 479 |  |  | 388 |  |  | 353 |  |
| Operating income |  | $ | 21,232 |  |  | $ | 16,759 |  |  | $ | 16,486 |  |
| Infrastructure software: |  |  |  |  |  |  |
| Net revenue |  | $ | 27,029 |  |  | $ | 21,478 |  |  | $ | 7,637 |  |
| Cost of revenue |  | 1,902 |  |  | 2,306 |  |  | 615 |  |
| Research and development |  | 2,550 |  |  | 2,707 |  |  | 844 |  |
| Selling, general and administrative |  | 1,812 |  |  | 2,488 |  |  | 539 |  |
| Operating income |  | $ | 20,765 |  |  | $ | 13,977 |  |  | $ | 5,639 |  |
| Total: |  |  |  |  |  |  |
| Net revenue |  | $ | 63,887 |  |  | $ | 51,574 |  |  | $ | 35,819 |  |
| Cost of revenue |  | 13,642 |  |  | 12,115 |  |  | 9,062 |  |
| Research and development |  | 5,957 |  |  | 5,847 |  |  | 3,740 |  |
| Selling, general and administrative |  | 2,291 |  |  | 2,876 |  |  | 892 |  |
| Unallocated expenses: |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 8,062 |  |  | 9,267 |  |  | 3,247 |  |
| Stock-based compensation |  | 7,568 |  |  | 5,670 |  |  | 2,171 |  |
| Restructuring and other charges |  | 667 |  |  | 1,787 |  |  | 248 |  |
| Acquisition-related costs |  | 216 |  |  | 549 |  |  | 252 |  |
| Operating income |  | $ | 25,484 |  |  | $ | 13,463 |  |  | $ | 16,207 |  |

[0001730168-25-000121:notes:292]
Geographic Information

[0001730168-25-000121:notes:293]
Net revenue by country is based primarily on the geographic shipment or delivery location as specified by the distributors, OEMs, contract manufacturers, channel partners, or software customers who purchased our products or services. For the majority of our products, title and control transfer to our customers in Penang, Malaysia. The products are then transported to the customer specific locations. Net revenue from the United States for fiscal years 2025, 2024 and 2023 was $16,506 million, $12,887 million and $6,975 million, respectively. Net revenue from China (including Hong Kong) for fiscal years 2025, 2024 and 2023 was $11,155 million, $10,483 million and $11,533 million, respectively. Net revenue from Singapore for fiscal years 2025, 2024 and 2023 was $10,796 million, $9,559 million and $4,479 million, respectively. Net revenue from Taiwan for fiscal year 2025 was $6,451 million (the amount was less than 10% for fiscal years 2024 and 2023). Net revenue from other foreign countries for fiscal years 2025, 2024 and 2023 was $18,979 million, $18,645 million and $12,832 million, respectively. These geographic delivery locations are not necessarily indicative of the geographic location of our end customers or the country in which our end customers sell devices containing our products. For example, we believe a substantial portion of our products shipped or delivered to China (including Hong Kong) is included in devices sold by our end customers in the United States and Europe.

[0001730168-25-000121:notes:294]
Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-25-000121:notes:295]
|  |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,697 |  |  | $ | 1,685 |  |
| Taiwan |  | 446 |  |  | 365 |  |
| Other |  | 387 |  |  | 471 |  |
| Total long-lived assets |  | $ | 2,530 |  |  | $ | 2,521 |  |

[0001730168-25-000121:notes:296]
Significant Customer Information
We sell our products through our direct sales force and a select network of distributors and channel partners globally. During fiscal years 2025, 2024 and 2023, one customer accounted for 32%, 28% and 21% of our net revenue, respectively. Revenue from this customer was included in our semiconductor solutions segment. One customer accounted for 44% and 18% of our net accounts receivable balance as of November 2, 2025 and November 3, 2024, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-25-000121:notes:297]
Commitments and Contingencies
Commitments

[0001730168-25-000121:notes:298]
The following table summarizes contractual obligations and commitments as of November 2, 2025:

[0001730168-25-000121:notes:299]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  | (In millions) |
| 2026 |  | $ | 106 |  |  | $ | 777 |  |
| 2027 |  | 12 |  |  | 650 |  |
| 2028 |  | 10 |  |  | 624 |  |
| 2029 |  | 4 |  |  | 890 |  |
| 2030 |  | — |  |  | 300 |  |
| Thereafter |  | — |  |  | 873 |  |
| Total |  | $ | 132 |  |  | $ | 4,114 |  |

[0001730168-25-000121:notes:300]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-25-000121:notes:301]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-25-000121:notes:302]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 2, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,628 million of unrecognized tax benefits and accrued interest and penalties as of November 2, 2025 have been excluded from the table above.

[0001730168-25-000121:notes:303]
Contingencies

[0001730168-25-000121:notes:304]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-25-000121:notes:305]
Lawsuits Relating to VMware Backlog

[0001730168-25-000121:notes:306]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms and in March 2025 the California Court approved the settlement.

[0001730168-25-000121:notes:307]
Other Matters

[0001730168-25-000121:notes:308]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-25-000121:notes:309]
Contingency Assessment

[0001730168-25-000121:notes:310]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-25-000121:notes:311]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our consolidated financial statements.

[0001730168-25-000121:notes:312]
Other Indemnifications

[0001730168-25-000121:notes:313]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-25-000121:notes:314]
Restructuring and Other Charges 
Restructuring Charges

[0001730168-25-000121:notes:315]
The following table summarizes the significant activities within, and components of, the restructuring liabilities:

[0001730168-25-000121:notes:316]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 30, 2022 |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Restructuring charges |  | 20 |  |  | 24 |  |  | 44 |  |
| Utilization |  | (22) |  |  | (24) |  |  | (46) |  |
| Balance as of October 29, 2023 |  | 2 |  |  | — |  |  | 2 |  |
| Restructuring charges |  | 1,510 |  |  | 277 |  |  | 1,787 |  |
| Utilization |  | (1,393) |  |  | (277) |  |  | (1,670) |  |
| Balance as of November 3, 2024 |  | 119 |  |  | — |  | (a) | 119 |  |
| Restructuring charges |  | 428 |  |  | 169 |  |  | 597 |  |
| Utilization |  | (471) |  |  | (169) |  |  | (640) |  |
| Balance as of November 2, 2025 |  | $ | 76 |  |  | $ | — |  | (a) | $ | 76 |  |

[0001730168-25-000121:notes:317]
(a) As of November 2, 2025 and November 3, 2024, outstanding restructured lease liabilities of $172 million and $192 million, respectively, were primarily included in long-term lease liabilities within other long-term liabilities.

[0001730168-25-000121:notes:318]
In connection with the VMware Merger, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. Restructuring charges in fiscal years 2025 and 2024 primarily related to employee termination costs. We also recognized lease and impairment charges primarily related to lease assets and property, plant and equipment of $169 million and $277 million during fiscal years 2025 and 2024, respectively. We have substantially completed these restructuring activities. These charges were recognized primarily in operating expenses.

[0001730168-25-000121:notes:319]
Other Charges
Restructuring and other charges in our consolidated statements of operations included a $70 million non-recurring impairment charge related to an asset held-for-sale during fiscal year 2025 and $204 million of non-recurring charges related to IP litigation during fiscal year 2023


## us-gaap:SubsequentEventsTextBlock

[0001730168-25-000121:notes:320]
Subsequent Events 
Cash Dividends Declared

[0001730168-25-000121:notes:321]
On December 9, 2025, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on December 31, 2025 to stockholders of record on December 22, 2025.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-25-000121:notes:322]
Schedule II — Valuation and Qualifying Accounts

[0001730168-25-000121:notes:323]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (a) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 2, 2025 |  | $ | 94 |  |  | $ | 418 |  |  | $ | (439) |  |  | $ | 73 |  |
| Fiscal year ended November 3, 2024 |  | $ | 133 |  |  | $ | 351 |  |  | $ | (390) |  |  | $ | 94 |  |
| Fiscal year ended October 29, 2023 |  | $ | 125 |  |  | $ | 502 |  |  | $ | (494) |  |  | $ | 133 |  |
| Other accounts receivable allowances (b) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 2, 2025 |  | $ | 11 |  |  | $ | 11 |  |  | $ | (19) |  |  | $ | 3 |  |
| Fiscal year ended November 3, 2024 |  | $ | 4 |  |  | $ | 17 |  |  | $ | (10) |  |  | $ | 11 |  |
| Fiscal year ended October 29, 2023 |  | $ | 1 |  |  | $ | 5 |  |  | $ | (2) |  |  | $ | 4 |  |
| Income tax valuation allowances: |  |  |  |  |  |  |  |  |
| Fiscal year ended November 2, 2025 |  | $ | 2,218 |  |  | $ | 1,867 |  |  | $ | (102) |  |  | $ | 3,983 |  |
| Fiscal year ended November 3, 2024 |  | $ | 1,789 |  |  | $ | 3,151 |  |  | $ | (2,722) |  |  | $ | 2,218 |  |
| Fiscal year ended October 29, 2023 |  | $ | 1,777 |  |  | $ | 117 |  |  | $ | (105) |  |  | $ | 1,789 |  |

[0001730168-25-000121:notes:324]
________________________________

[0001730168-25-000121:notes:325]
(a)Distributor credit allowances relate to price adjustments and other allowances.

[0001730168-25-000121:notes:326]
(b)Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts.
