# AVGO MD&A — 0001730168-25-000121


## mdna

[0001730168-25-000121:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-25-000121:mdna:2]
The following section generally discusses our financial condition and results of operations for our fiscal year ended November 2, 2025 (“fiscal year 2025”) compared to our fiscal year ended November 3, 2024 (“fiscal year 2024”). A discussion regarding our financial condition and results of operations for fiscal year 2024 compared to our fiscal year ended October 29, 2023 can be found in Part II, Item 7 of our Annual Report on Form 10-K for fiscal year 2024, filed with the Securities and Exchange Commission (the “SEC”) on December 20, 2024.

[0001730168-25-000121:mdna:3]
Overview

[0001730168-25-000121:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, subsystems and, in some cases, racks. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-25-000121:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our semiconductor-based product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our private cloud, mainframe software, cybersecurity and enterprise software portfolios, and our FC SAN business.

[0001730168-25-000121:mdna:6]
Our strategy is focused on sustained technology leadership and developing category-leading solutions to deliver a comprehensive suite of innovative infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through extensive internal research and development, as well as strategic acquisitions of businesses and technologies, to ensure our products retain their technology market leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-25-000121:mdna:7]
The demand for our solutions has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-25-000121:mdna:8]
•gain or loss of significant customers;

[0001730168-25-000121:mdna:9]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-25-000121:mdna:10]
•anticipated or actual demand for AI-related products and solutions;

[0001730168-25-000121:mdna:11]
•our distributors’ product inventory and end-user demand;

[0001730168-25-000121:mdna:12]
•the rate at which our present and future customers and end-users adopt our solutions in our target markets, including our AI-related solutions, and the rate at which our customers' products that include our solutions are accepted in their markets;

[0001730168-25-000121:mdna:13]
•the shift to cloud-based information technology solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our solutions for use in traditional enterprise data centers; and

[0001730168-25-000121:mdna:14]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-25-000121:mdna:15]
Fiscal Year Highlights

[0001730168-25-000121:mdna:16]
Highlights during fiscal year 2025 include the following:

[0001730168-25-000121:mdna:17]
•We generated $27,537 million of cash from operations.

[0001730168-25-000121:mdna:18]
•We paid $11,142 million in cash dividends.

[0001730168-25-000121:mdna:19]
•We repurchased $2,450 million of common stock.

[0001730168-25-000121:mdna:20]
Acquisitions and Divestitures

[0001730168-25-000121:mdna:21]
Acquisition of VMware and Divestiture of EUC

[0001730168-25-000121:mdna:22]
On November 22, 2023, we acquired VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million. In addition, we assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding RSU awards held by non-employee directors and in-the-money VMware stock options were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-25-000121:mdna:23]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 10. “Borrowings” included in Part II, Item 8 of this Annual Report on Form 10-K, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-25-000121:mdna:24]
On July 1, 2024, we sold VMware’s end-user computing (“EUC”) business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments.

[0001730168-25-000121:mdna:25]
Acquisition of Seagate’s System-on-Chip Operations

[0001730168-25-000121:mdna:26]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip operations of Seagate Technology Holdings plc for $600 million.

[0001730168-25-000121:mdna:27]
Net Revenue

[0001730168-25-000121:mdna:28]
A majority of our net revenue is derived from sales of a broad range of semiconductor and semiconductor-based solutions that are incorporated into electronic products, as well as from modules, switches and subsystems and, in some cases, racks. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, deliver, automate, manage, and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms.

[0001730168-25-000121:mdna:29]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, have varied from quarter to quarter, due largely to fluctuations in end-market demand which are discussed in detail in Part I, Item 1A. Risk Factors of this Annual Report on Form 10-K.

[0001730168-25-000121:mdna:30]
Distributors and original equipment manufacturers (“OEMs”), or their contract manufacturers, typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive IP portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon the delivery of our products to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-25-000121:mdna:31]
Our software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. Our private cloud infrastructure suite of solutions is available directly from Broadcom, resellers and distributors, hyperscale cloud providers, value-added OEMs and VMware cloud service provider partners. VMware Cloud Foundation (“VCF”) provides license portability, which enables customers to purchase subscriptions of VCF software and move their VCF environments between on-premises data centers and supported cloud endpoints. We remain focused on strengthening relationships and increasing penetration within our existing core, mainframe, VMware, and Symantec endpoint

[0001730168-25-000121:mdna:32]
customers and expanding the adoption of our enterprise software offerings with these customers. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-25-000121:mdna:33]
Costs and Expenses

[0001730168-25-000121:mdna:34]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense, related occupancy, computer services, equipment costs, manufacturing quality, order fulfillment, warranty adjustments, and inventory adjustments including write-downs for inventory obsolescence.

[0001730168-25-000121:mdna:35]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-25-000121:mdna:36]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-25-000121:mdna:37]
Total cost of revenue also includes amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-25-000121:mdna:38]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses, and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-25-000121:mdna:39]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs, which include direct transaction costs and integration costs, and other corporate expenses.

[0001730168-25-000121:mdna:40]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with our acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-25-000121:mdna:41]
Restructuring and other charges.  Restructuring and other charges consist primarily of non-recurring charges related to compensation costs associated with employee exit programs, IP litigation, alignment of our global manufacturing operations, rationalization of product development program costs, facility and lease abandonments, asset impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-25-000121:mdna:42]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-25-000121:mdna:43]
Other income, net.  Other income, net includes interest income, gains and losses on investments or sales of businesses, foreign currency remeasurement, and other miscellaneous items.

[0001730168-25-000121:mdna:44]
Provision for (benefit from) income taxes.  We benefit from the tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are scheduled to expire through November 2030. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday from our qualifying income earned in Malaysia, which is scheduled to expire in 2028.

[0001730168-25-000121:mdna:45]
Each tax incentive and tax holiday is subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our

[0001730168-25-000121:mdna:46]
operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the impacts of indirect taxes, the effect of these tax incentives and tax holiday decreased the provision for income taxes by approximately $2,709 million and $2,261 million for fiscal years 2025 and 2024, respectively.

[0001730168-25-000121:mdna:47]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect, the benefits of the tax incentives may be adversely affected.

[0001730168-25-000121:mdna:48]
Many countries have enacted or are in the process of enacting a global minimum tax, some of which became effective for us starting in our fiscal year 2025 and, more importantly, the enactment in Singapore will become effective in our fiscal year ending November 1, 2026 (“fiscal year 2026”). While the tax did not have a material impact on our fiscal year 2025 consolidated results of operations, we expect a material impact from the enactment of these laws on our consolidated results of operations and cash flows for our fiscal year 2026.

[0001730168-25-000121:mdna:49]
Critical Accounting Estimates

[0001730168-25-000121:mdna:50]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of goodwill and long-lived assets, and income taxes. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8 of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-25-000121:mdna:51]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-25-000121:mdna:52]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-25-000121:mdna:53]
Business combinations.  Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets include, the present value of projected cash flows regarding the projected revenues, projected expenses which include cost of revenue, research and development and selling, general and administrative expenses, technology obsolescence rate, contributory asset charges, discount rate and income tax rate for developed technology; the projected revenues, customer retention rate, customer ramp up period, discount rate and income tax rate for the customer contracts and related relationships; the projected revenues, technology obsolescence rate, expected costs to develop IPR&D into commercially viable products, discount rate and income tax rate for the IPR&D; and the projected revenues, brand asset phase-out pattern, brand asset royalty rate, discount rate and the income tax rate for the trade name. Unanticipated events and circumstances may occur which could affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-25-000121:mdna:54]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each fiscal year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-25-000121:mdna:55]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance, including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting the financial multiples of comparable companies and applying a control premium. A reporting unit's carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-25-000121:mdna:56]
We assess the impairment of long-lived assets, including purchased IPR&D, property, plant and equipment, right-of-use assets, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment, and intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business to which the long-lived assets relate. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived assets stated on our consolidated balance sheets to reflect their estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-25-000121:mdna:57]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition.

[0001730168-25-000121:mdna:58]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax laws and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-25-000121:mdna:59]
37

[0001730168-25-000121:mdna:60]
Fiscal Year Presentation

[0001730168-25-000121:mdna:61]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year 2025 was a 52-week fiscal year. Fiscal year 2024 was a 53-week fiscal year and fiscal year 2023 was a 52-week fiscal year.

[0001730168-25-000121:mdna:62]
The financial statements included in Part II, Item 8 of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-25-000121:mdna:63]
Results of Operations

[0001730168-25-000121:mdna:64]
Fiscal Year 2025 Compared to Fiscal Year 2024

[0001730168-25-000121:mdna:65]
The following table sets forth our results of operations for the periods presented:

[0001730168-25-000121:mdna:66]
|  |  | Fiscal Year Ended |
|  |  | November 2,2025 |  | November 3,2024 |  | November 2,2025 |  | November 3,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 44,847 |  |  | $ | 34,960 |  |  | 70 | % |  | 68 | % |
| Subscriptions and services |  | 19,040 |  |  | 16,614 |  |  | 30 |  |  | 32 |  |
| Total net revenue |  | 63,887 |  |  | 51,574 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 12,115 |  |  | 9,805 |  |  | 19 |  |  | 19 |  |
| Cost of subscriptions and services |  | 2,371 |  |  | 2,983 |  |  | 4 |  |  | 6 |  |
| Amortization of acquisition-related intangible assets |  | 6,031 |  |  | 6,023 |  |  | 9 |  |  | 12 |  |
| Restructuring charges |  | 76 |  |  | 254 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 20,593 |  |  | 19,065 |  |  | 32 |  |  | 37 |  |
| Gross margin |  | 43,294 |  |  | 32,509 |  |  | 68 |  |  | 63 |  |
| Research and development |  | 10,977 |  |  | 9,310 |  |  | 17 |  |  | 18 |  |
| Selling, general and administrative |  | 4,211 |  |  | 4,959 |  |  | 7 |  |  | 10 |  |
| Amortization of acquisition-related intangible assets |  | 2,031 |  |  | 3,244 |  |  | 3 |  |  | 6 |  |
| Restructuring and other charges |  | 591 |  |  | 1,533 |  |  | 1 |  |  | 3 |  |
| Total operating expenses |  | 17,810 |  |  | 19,046 |  |  | 28 |  |  | 37 |  |
| Operating income |  | $ | 25,484 |  |  | $ | 13,463 |  |  | 40 | % |  | 26 | % |

[0001730168-25-000121:mdna:67]
In fiscal year 2025, we included upfront license revenue of $7,800 million within products revenue. To conform to the current year presentation, we reclassified $4,601 million of upfront license revenue from subscriptions and services revenue to products revenue for fiscal year 2024. We also reclassified the related costs for the upfront license revenue, which were immaterial, for the periods presented. See Note 3. “Revenue from Contracts with Customers” in Part II, Item 8. of this Annual Report on Form 10-K for additional information.

[0001730168-25-000121:mdna:68]
Net Revenue

[0001730168-25-000121:mdna:69]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one semiconductor solutions customer, which is a distributor, accounted for 32% and 28% of our net revenue for fiscal years 2025 and 2024, respectively.

[0001730168-25-000121:mdna:70]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% of our net revenue for each of the fiscal years 2025 and 2024. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-25-000121:mdna:71]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our products used in AI and wireless applications as fluctuations may be magnified by the timing of customer deployments, as well as product launches. For infrastructure software, the transition to subscription licenses, as well as whether or not a customer has the right to terminate, causes variations in revenue recognized in each period.

[0001730168-25-000121:mdna:72]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based primarily on the geographic shipment or delivery location specified by our distributors, OEMs, contract manufacturers, channel partners, or software customers. In fiscal years 2025 and 2024, 17% and 20%, respectively, of our net revenue came from shipments or deliveries to China (including Hong Kong). However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net

[0001730168-25-000121:mdna:73]
revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-25-000121:mdna:74]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-25-000121:mdna:75]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | November 2,2025 |  | November 3,2024 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 36,858 |  |  | $ | 30,096 |  |  | $ | 6,762 |  |  | 22 | % |
| Infrastructure software |  | 27,029 |  |  | 21,478 |  |  | 5,551 |  |  | 26 | % |
| Total net revenue |  | $ | 63,887 |  |  | $ | 51,574 |  |  | $ | 12,313 |  |  | 24 | % |

[0001730168-25-000121:mdna:76]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | November 2, 2025 |  | November 3, 2024 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 58 | % |  | 58 | % |
| Infrastructure software |  | 42 |  |  | 42 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-25-000121:mdna:77]
Net revenue from our semiconductor solutions segment increased due to strong demand for our networking solutions, primarily custom AI accelerators and AI networking products. Net revenue from our infrastructure software segment increased primarily due to strong demand for our VCF product, including license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model.

[0001730168-25-000121:mdna:78]
Gross Margin

[0001730168-25-000121:mdna:79]
Gross margin was $43,294 million for fiscal year 2025 compared to $32,509 million for fiscal year 2024. The increase was primarily due to higher software revenue and strong product demand for our AI-related semiconductor solutions.

[0001730168-25-000121:mdna:80]
As a percentage of net revenue, gross margin was 68% and 63% of net revenue for the fiscal years 2025 and 2024, respectively. The increase was primarily due to higher revenue impact on margin and higher infrastructure software gross margin percentage, driven by an increase in license revenue and lower infrastructure software labor costs following our integration of the VMware business.

[0001730168-25-000121:mdna:81]
Research and Development Expense

[0001730168-25-000121:mdna:82]
Research and development expense increased $1,667 million, or 18%, in fiscal year 2025, compared to the prior fiscal year. The increase was primarily due to higher stock-based compensation.

[0001730168-25-000121:mdna:83]
Selling, General and Administrative Expense

[0001730168-25-000121:mdna:84]
Selling, general and administrative expense decreased $748 million, or 15%, in fiscal year 2025, compared to the prior fiscal year. The decrease was primarily due to lower compensation resulting from a decrease in headcount and lower VMware acquisition-related costs, partially offset by higher stock-based compensation.

[0001730168-25-000121:mdna:85]
Amortization of Acquisition-Related Intangible Assets in Operating Expenses

[0001730168-25-000121:mdna:86]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $1,213 million, or 37%, in fiscal year 2025, compared to the prior fiscal year primarily due to full amortization of customer-related intangible assets from previous software acquisitions other than VMware.

[0001730168-25-000121:mdna:87]
Restructuring and Other Charges

[0001730168-25-000121:mdna:88]
Restructuring and other charges recognized in operating expenses decreased $942 million, or 61%, in fiscal year 2025, compared to the prior fiscal year primarily due to lower employee termination costs associated with the integration of the VMware business.

[0001730168-25-000121:mdna:89]
Stock-Based Compensation Expense

[0001730168-25-000121:mdna:90]
During the fiscal quarter ended May 4, 2025, we granted two-year time- and market-based restricted stock unit awards (the “Two-Year Equity Awards”), in lieu of our annual employee equity awards historically granted in the second quarter of each fiscal year. Each Two-Year Equity Award vests on the same basis as two annual grants with staggered vesting start dates

[0001730168-25-000121:mdna:91]
40

[0001730168-25-000121:mdna:92]
of March 15, 2025 and March 15, 2026 and successive four-year vesting periods. We recognize stock-based compensation expense related to these awards from the grant date through their respective vesting date, ranging from four to five years.

[0001730168-25-000121:mdna:93]
Total stock-based compensation expense was $7,568 million and $5,670 million for fiscal years 2025 and 2024, respectively. The increase was primarily due to the Two-Year Equity Awards granted at higher grant-date fair values, partially offset by the full vesting and forfeitures of certain equity awards assumed in the VMware acquisition.

[0001730168-25-000121:mdna:94]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of November 2, 2025. The remaining weighted-average service period was 3.4 years.

[0001730168-25-000121:mdna:95]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2026 |  | $ | 8,301 |  |
| 2027 |  | 7,118 |  |
| 2028 |  | 4,985 |  |
| 2029 |  | 2,689 |  |
| 2030 |  | 740 |  |
| Total |  | $ | 23,833 |  |

[0001730168-25-000121:mdna:96]
Segment Operating Results

[0001730168-25-000121:mdna:97]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | November 2, 2025 |  | November 3, 2024 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 21,232 |  |  | $ | 16,759 |  |  | $ | 4,473 |  |  | 27 | % |
| Infrastructure software |  | 20,765 |  |  | 13,977 |  |  | 6,788 |  |  | 49 | % |
| Unallocated expenses |  | (16,513) |  |  | (17,273) |  |  | 760 |  |  | (4) | % |
| Total operating income |  | $ | 25,484 |  |  | $ | 13,463 |  |  | $ | 12,021 |  |  | 89 | % |

[0001730168-25-000121:mdna:98]
Operating income from our semiconductor solutions segment increased due to strong demand for our networking solutions, primarily custom AI accelerators and AI networking products.

[0001730168-25-000121:mdna:99]
Higher operating income from our infrastructure software segment was primarily due to strong demand for our VCF product, including license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model. In addition, labor costs were lower following our integration of the VMware business.

[0001730168-25-000121:mdna:100]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, and acquisition-related costs which are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 4% in fiscal year 2025, compared to the prior fiscal year, primarily due to lower amortization of acquisition-related intangible assets, restructuring and other charges, and acquisition-related costs, partially offset by higher stock-based compensation expense.

[0001730168-25-000121:mdna:101]
Non-Operating Income and Expenses

[0001730168-25-000121:mdna:102]
Interest expense.  Interest expense was $3,210 million and $3,953 million for fiscal years 2025 and 2024, respectively. The decrease was primarily from a reduction in outstanding debt balances and debt refinancing activities that drove lower effective interest rates compared to the prior fiscal year.

[0001730168-25-000121:mdna:103]
Other income, net.  Other income, net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $455 million and $406 million for fiscal years 2025 and 2024, respectively. The increase was primarily due to a gain on the sale of a business, partially offset by lower interest income as a result of lower interest rates on lower invested balances.

[0001730168-25-000121:mdna:104]
Provision for (benefit from) income taxes. On July 4, 2025, the United States enacted the One Big Beautiful Bill Act, which allows for the immediate expensing of domestic research and development costs and certain capital expenditures, and changes the United States taxation of profits derived from foreign operations. As a result, it is no longer more-likely-than-not that we are able to utilize our federal corporate alternative minimum tax (“CAMT”) credits, and we established a $1,321 million valuation allowance against our CAMT credit carryforwards and CAMT credits generated in the current fiscal year. Our policy is to not consider the impact of future years’ CAMT in our valuation allowance assessment for regular deferred tax assets. Most of the provisions are effective beginning in our fiscal years ending November 1, 2026 or October 31, 2027, with the exception of immediate expensing of qualifying property being effective in fiscal year 2025.

[0001730168-25-000121:mdna:105]
The benefit from income taxes was $397 million for fiscal year 2025, and was primarily due to the recognition of uncertain tax benefits from expiration of statutes of limitations and audit settlements, and excess tax benefits from stock-based awards, partially offset by income from operations and a valuation allowance against our CAMT credits.

[0001730168-25-000121:mdna:106]
The provision for income taxes was $3,748 million for fiscal year 2024, and was primarily due to the impact of a non-recurring intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000121:mdna:107]
Liquidity and Capital Resources

[0001730168-25-000121:mdna:108]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-25-000121:mdna:109]
Our primary sources of liquidity as of November 2, 2025 consisted of: (i) $16,178 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-25-000121:mdna:110]
Our short-term and long-term liquidity requirements primarily arise from: (i) working capital requirements, (ii) research and development and capital expenditure needs, (iii) cash dividend payments (if and when declared by our Board of Directors), (iv) interest and principal payments related to our $67,120 million of outstanding indebtedness with $3,152 million principal amounts payable within 12 months, (v) payment of income taxes, (vi) business acquisitions and investments we may make from time to time, and (vii) discretionary share repurchases. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2026 as compared to fiscal year 2025.

[0001730168-25-000121:mdna:111]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations, indebtedness and lease obligations, see Note 14. “Commitments and Contingencies”, Note 10. “Borrowings” and Note 6. “Leases” in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-25-000121:mdna:112]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our outstanding indebtedness and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to issue additional debt or equity securities for reasons other than those specified above. From time to time, we manage our indebtedness through financings, redemptions, repayments, exchanges, tender offers, and other transactions. Such transactions will depend on prevailing market conditions, our liquidity requirements, the terms of indentures, contractual restrictions and other factors.

[0001730168-25-000121:mdna:113]
42

[0001730168-25-000121:mdna:114]
Working Capital

[0001730168-25-000121:mdna:115]
Working capital increased to $13,059 million at November 2, 2025 from $2,898 million at November 3, 2024. The increase was primarily attributable to the following:

[0001730168-25-000121:mdna:116]
•Cash and cash equivalents increased to $16,178 million at November 2, 2025 from $9,348 million at November 3, 2024 primarily due to $27,537 million in net cash provided by operating activities, partially offset by $11,142 million of dividend payments, $3,860 million of employee withholding tax payments related to net settled equity awards, $2,812 million of net repayments of borrowings, and $2,450 million of common stock repurchases.

[0001730168-25-000121:mdna:117]
•Trade accounts receivable, net increased to $7,145 million at November 2, 2025 from $4,416 million at November 3, 2024 primarily due to higher billings.

[0001730168-25-000121:mdna:118]
•Other current assets increased to $5,980 million at November 2, 2025 from $4,071 million at November 3, 2024 primarily from higher software contract assets, offset in part by lower prepaid taxes and the sale of assets held for sale.

[0001730168-25-000121:mdna:119]
These increases in working capital were offset in part by the following:

[0001730168-25-000121:mdna:120]
•Short-term debt increased to $3,152 million at November 2, 2025 from $1,271 million at November 3, 2024 primarily due to certain senior notes becoming due within the next twelve months, offset in part by repayments.

[0001730168-25-000121:mdna:121]
Capital Returns

[0001730168-25-000121:mdna:122]
|  |  | Fiscal Year Ended |
| Cash Dividends Declared and Paid |  | November 2, 2025 |  | November 3, 2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 2.360 |  |  | $ | 2.105 |  |
| Dividends to common stockholders |  | $ | 11,142 |  |  | $ | 9,814 |  |

[0001730168-25-000121:mdna:123]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025, which was extended to December 31, 2026 subsequent to fiscal year 2025. During fiscal year 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million  with a $7,550 million remaining authorized amount available for future purchases as of November 2, 2025.

[0001730168-25-000121:mdna:124]
Repurchases under this stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000121:mdna:125]
In December 2021 and May 2022, our Board of Directors authorized stock repurchase programs to repurchase up to an aggregate of $20 billion of our common stock from time to time through December 31, 2023. During the first quarter of fiscal year 2024, we repurchased and retired 67 million shares of our common stock for $7,176 million, and all $20 billion of the aggregate authorized amount was utilized prior to expiration on December 31, 2023.

[0001730168-25-000121:mdna:126]
During fiscal years 2025 and 2024, we paid $3,860 million and $5,216 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld 17 million and 38 million shares of common stock from employees in connection with such net share settlements during fiscal years 2025 and 2024, respectively. In the second half of fiscal year 2025, we settled withholding taxes upon the vesting of employee equity awards using proceeds from the sale of a portion of the vested shares.

[0001730168-25-000121:mdna:127]
Cash Flows

[0001730168-25-000121:mdna:128]
|  |  | Fiscal Year Ended |
|  |  | November 2, 2025 |  | November 3, 2024 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 27,537 |  |  | $ | 19,962 |  |
| Net cash used in investing activities |  | (580) |  |  | (23,070) |  |
| Net cash used in financing activities |  | (20,127) |  |  | (1,733) |  |
| Net change in cash and cash equivalents |  | $ | 6,830 |  |  | $ | (4,841) |  |

[0001730168-25-000121:mdna:129]
Operating Activities

[0001730168-25-000121:mdna:130]
Cash flows from operating activities consist of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $7,575 million increase in cash provided by operations during fiscal year 2025 compared to fiscal year 2024 was primarily due to $17,231 million higher net income, offset in part by $5,973 million lower non-cash adjustments for deferred taxes and other non-cash taxes, as well as $3,863 million from changes in operating assets and liabilities.

[0001730168-25-000121:mdna:131]
Investing Activities

[0001730168-25-000121:mdna:132]
Cash flows from investing activities primarily consist of cash used for acquisitions, proceeds from sales of businesses, capital expenditures, and proceeds and payments related to investments. The $22,490 million decrease in cash used in investing activities during fiscal year 2025 compared to fiscal year 2024 was primarily due to $25,416 million cash paid in connection with the acquisition of VMware, net of cash acquired in fiscal year 2024, offset in part by $3,185 million lower proceeds from sales of businesses in fiscal year 2025 compared to fiscal year 2024.

[0001730168-25-000121:mdna:133]
Financing Activities

[0001730168-25-000121:mdna:134]
Cash flows from financing activities primarily consist of proceeds and payments related to our borrowings, dividend payments, employee withholding tax payments related to net settled equity awards and authorized stock repurchases. The $18,394 million increase in cash used in financing activities during fiscal year 2025 compared to fiscal year 2024 was primarily due to net proceeds from term loans issued in connection with the acquisition of VMware in fiscal year 2024, debt repayments and higher dividend payments in fiscal year 2025, offset in part by lower stock repurchases and employee withholding tax payments related to net settled equity awards in fiscal year 2025 compared to fiscal year 2024.
