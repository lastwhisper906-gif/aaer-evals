# AVGO MD&A — 0001730168-25-000098


## mdna

[0001730168-25-000098:mdna:1]
[same as prior period, unchanged from 0001730168-25-000064:mdna:1]

[0001730168-25-000098:mdna:2]
[same as prior period, unchanged from 0001730168-25-000064:mdna:2]

[0001730168-25-000098:mdna:3]
[same as prior period, unchanged from 0001730168-25-000064:mdna:3]

[0001730168-25-000098:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Our semiconductor solutions include a broad portfolio of complex digital and mixed signal complementary metal oxide semiconductor based devices, analog III-V based products, network interface cards and other modules, switches, subsystems and, in some cases, racks that are used in a wide array of environments, end products and applications such as artificial intelligence (“AI”) and enterprise data centers, servers, networking and connectivity equipment, storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-25-000098:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our semiconductor-based product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our private and hybrid cloud, application development and delivery, software-defined edge, application networking and security, mainframe, distributed and cybersecurity solutions, and our FC SAN business.

[0001730168-25-000098:mdna:6]
[same as prior period, unchanged from 0001730168-25-000064:mdna:8]

[0001730168-25-000098:mdna:7]
Highlights during the fiscal quarter ended August 3, 2025 include the following:

[0001730168-25-000098:mdna:8]
•We generated $7,166 million of cash from operations.

[0001730168-25-000098:mdna:9]
•We paid $2,786 million in cash dividends.

[0001730168-25-000098:mdna:10]
•We issued $6,000 million of senior unsecured notes and used the net proceeds to repay the outstanding balance of our floating rate unsecured term loan.

[0001730168-25-000098:mdna:11]
[same as prior period, unchanged from 0001730168-25-000064:mdna:13]

[0001730168-25-000098:mdna:12]
[same as prior period, unchanged from 0001730168-25-000064:mdna:14]

[0001730168-25-000098:mdna:13]
There were no significant changes in our critical accounting estimates during the three fiscal quarters ended August 3, 2025 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2024 Annual Report on Form 10-K.

[0001730168-25-000098:mdna:14]
[same as prior period, unchanged from 0001730168-25-000064:mdna:16]

[0001730168-25-000098:mdna:15]
[same as prior period, unchanged from 0001730168-25-000064:mdna:17]

[0001730168-25-000098:mdna:16]
26

[0001730168-25-000098:mdna:17]
[same as prior period, unchanged from 0001730168-25-000064:mdna:19]

[0001730168-25-000098:mdna:18]
Fiscal Quarter and Three Fiscal Quarters Ended August 3, 2025 Compared to Fiscal Quarter and Three Fiscal Quarters Ended August 4, 2024

[0001730168-25-000098:mdna:19]
[same as prior period, unchanged from 0001730168-25-000064:mdna:21]

[0001730168-25-000098:mdna:20]
|  |  | Fiscal Quarter Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 9,257 |  |  | $ | 7,439 |  |  | 58 | % |  | 57 | % |
| Subscriptions and services |  | 6,695 |  |  | 5,633 |  |  | 42 |  |  | 43 |  |
| Total net revenue |  | 15,952 |  |  | 13,072 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 3,096 |  |  | 2,434 |  |  | 19 |  |  | 19 |  |
| Cost of subscriptions and services |  | 608 |  |  | 699 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,519 |  |  | 1,525 |  |  | 10 |  |  | 12 |  |
| Restructuring charges |  | 26 |  |  | 58 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,249 |  |  | 4,716 |  |  | 33 |  |  | 36 |  |
| Gross margin |  | 10,703 |  |  | 8,356 |  |  | 67 |  |  | 64 |  |
| Research and development |  | 3,050 |  |  | 2,353 |  |  | 19 |  |  | 18 |  |
| Selling, general and administrative |  | 1,072 |  |  | 1,100 |  |  | 7 |  |  | 9 |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 812 |  |  | 3 |  |  | 6 |  |
| Restructuring and other charges |  | 187 |  |  | 303 |  |  | 1 |  |  | 2 |  |
| Total operating expenses |  | 4,816 |  |  | 4,568 |  |  | 30 |  |  | 35 |  |
| Operating income |  | $ | 5,887 |  |  | $ | 3,788 |  |  | 37 | % |  | 29 | % |

[0001730168-25-000098:mdna:21]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 25,934 |  |  | $ | 22,043 |  |  | 57 | % |  | 59 | % |
| Subscriptions and services |  | 19,938 |  |  | 15,477 |  |  | 43 |  |  | 41 |  |
| Total net revenue |  | 45,872 |  |  | 37,520 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 8,509 |  |  | 7,023 |  |  | 18 |  |  | 19 |  |
| Cost of subscriptions and services |  | 1,764 |  |  | 2,366 |  |  | 4 |  |  | 6 |  |
| Amortization of acquisition-related intangible assets |  | 4,486 |  |  | 4,421 |  |  | 10 |  |  | 12 |  |
| Restructuring charges |  | 68 |  |  | 203 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 14,827 |  |  | 14,013 |  |  | 32 |  |  | 37 |  |
| Gross margin |  | 31,045 |  |  | 23,507 |  |  | 68 |  |  | 63 |  |
| Research and development |  | 7,996 |  |  | 7,076 |  |  | 18 |  |  | 19 |  |
| Selling, general and administrative |  | 3,104 |  |  | 3,949 |  |  | 7 |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,524 |  |  | 2,431 |  |  | 3 |  |  | 6 |  |
| Restructuring and other charges |  | 445 |  |  | 1,215 |  |  | 1 |  |  | 3 |  |
| Total operating expenses |  | 13,069 |  |  | 14,671 |  |  | 29 |  |  | 39 |  |
| Operating income |  | $ | 17,976 |  |  | $ | 8,836 |  |  | 39 | % |  | 24 | % |

[0001730168-25-000098:mdna:22]
[same as prior period, unchanged from 0001730168-25-000064:mdna:25]

[0001730168-25-000098:mdna:23]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one semiconductor solutions customer, which is a distributor, accounted for 32% and 30% of our net revenue for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and 26% and 27% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively.

[0001730168-25-000098:mdna:24]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 3, 2025, and 35% and 40% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-25-000098:mdna:25]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our products used in AI and wireless applications as fluctuations may be magnified by the timing of customer deployments, as well as product launches and seasonal variations for wireless applications. For infrastructure software, the transition to subscription licenses, as well as whether or not a customer has the right to terminate, causes variations in revenue recognized in each period.

[0001730168-25-000098:mdna:26]
[same as prior period, unchanged from 0001730168-25-000064:mdna:54]

[0001730168-25-000098:mdna:27]
[same as prior period, unchanged from 0001730168-25-000064:mdna:29]

[0001730168-25-000098:mdna:28]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |  |  |  |  |
| Net Revenue by Segment |  | August 3, 2025 |  | August 4, 2024 |  | $ Change |  | % Change |  | August 3, 2025 |  | August 4, 2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 9,166 |  |  | $ | 7,274 |  |  | $ | 1,892 |  |  | 26 | % |  | $ | 25,786 |  |  | $ | 21,866 |  |  | $ | 3,920 |  |  | 18 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 6,786 |  |  | 5,798 |  |  | 988 |  |  | 17 | % |  | 20,086 |  |  | 15,654 |  |  | 4,432 |  |  | 28 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 15,952 |  |  | $ | 13,072 |  |  | $ | 2,880 |  |  | 22 | % |  | $ | 45,872 |  |  | $ | 37,520 |  |  | $ | 8,352 |  |  | 22 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000098:mdna:29]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |  |  |
| Net Revenue by Segment |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 57 | % |  | 56 | % |  | 56 | % |  | 58 | % |  |  |  |  |
| Infrastructure software |  | 43 |  |  | 44 |  |  | 44 |  |  | 42 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-25-000098:mdna:30]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and three fiscal quarters ended August 3, 2025 compared to the prior year fiscal periods due to strong demand for our networking products, primarily custom AI accelerators and AI networking solutions.

[0001730168-25-000098:mdna:31]
Net revenue from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended August 3, 2025 compared to the prior year fiscal periods primarily due to strong demand for our VMware Cloud Foundation (“VCF”) product, including additional license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model.

[0001730168-25-000098:mdna:32]
[same as prior period, unchanged from 0001730168-25-000064:mdna:34]

[0001730168-25-000098:mdna:33]
Gross margin was $10,703 million for the fiscal quarter ended August 3, 2025 compared to $8,356 million for the fiscal quarter ended August 4, 2024, and $31,045 million for the three fiscal quarters ended August 3, 2025 compared to $23,507 million for the three fiscal quarters ended August 4, 2024. The increases were primarily due to higher software revenue and strong product demand for our AI-related semiconductor solutions.

[0001730168-25-000098:mdna:34]
As a percentage of net revenue, gross margin was 67% and 68% of net revenue for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and 64% and 63% for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. The increases were primarily due to higher software revenue mix and lower amortization of acquisition-related intangible assets as a percentage of revenue.

[0001730168-25-000098:mdna:35]
[same as prior period, unchanged from 0001730168-25-000064:mdna:37]

[0001730168-25-000098:mdna:36]
Research and development expense increased $697 million, or 30%, and $920 million, or 13%, for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher stock-based compensation.

[0001730168-25-000098:mdna:37]
[same as prior period, unchanged from 0001730168-25-000064:mdna:39]

[0001730168-25-000098:mdna:38]
Selling, general and administrative expense decreased $28 million, or 3%, and $845 million, or 21%, for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower compensation resulting from a decrease in headcount and lower VMware acquisition-related costs. The decrease in the fiscal quarter ended August 3, 2025 compared to the prior year fiscal period was partially offset by higher stock-based compensation.

[0001730168-25-000098:mdna:39]
[same as prior period, unchanged from 0001730168-25-000064:mdna:68]

[0001730168-25-000098:mdna:40]
[same as prior period, unchanged from 0001730168-25-000064:mdna:42]

[0001730168-25-000098:mdna:41]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $305 million, or 38%, and $907 million, or 37%, for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, compared to the prior year fiscal periods primarily due to full amortization of customer-related intangible assets from previous software acquisitions other than VMware.

[0001730168-25-000098:mdna:42]
[same as prior period, unchanged from 0001730168-25-000064:mdna:44]

[0001730168-25-000098:mdna:43]
Restructuring and other charges recognized in operating expenses decreased $116 million, or 38%, and $770 million, or 63%, for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, compared to the prior year fiscal periods primarily due to lower employee termination costs associated with the integration of the VMware business.

[0001730168-25-000098:mdna:44]
[same as prior period, unchanged from 0001730168-25-000064:mdna:46]

[0001730168-25-000098:mdna:45]
[same as prior period, unchanged from 0001730168-25-000064:mdna:47]

[0001730168-25-000098:mdna:46]
Total stock-based compensation expense was $2,322 million and $1,381 million for the fiscal quarters ended August 3, 2025 and August 4, 2024, respectively, and $5,373 million and $4,356 million for the three fiscal quarters ended August 3, 2025 and August 4, 2024, respectively. The increases were due to the Two-Year Equity Awards granted at higher grant-date fair values, partially offset by the full vesting and forfeitures of certain equity awards assumed in the VMware acquisition.

[0001730168-25-000098:mdna:47]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of August 3, 2025. The remaining weighted-average service period was 3.6 years.

[0001730168-25-000098:mdna:48]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 2,172 |  |
| 2026 |  | 8,104 |  |
| 2027 |  | 6,925 |  |
| 2028 |  | 4,772 |  |
| 2029 |  | 2,487 |  |
| Thereafter |  | 597 |  |
| Total |  | $ | 25,057 |  |

[0001730168-25-000098:mdna:49]
[same as prior period, unchanged from 0001730168-25-000064:mdna:52]

[0001730168-25-000098:mdna:50]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |  |  |  |  |
| Operating Income by Segment |  | August 3,2025 |  | August 4,2024 |  | $ Change |  | % Change |  | August 3,2025 |  | August 4,2024 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 5,217 |  |  | $ | 4,042 |  |  | $ | 1,175 |  |  | 29 | % |  | $ | 14,729 |  |  | $ | 12,136 |  |  | $ | 2,593 |  |  | 21 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 5,238 |  |  | 3,906 |  |  | 1,332 |  |  | 34 | % |  | 15,347 |  |  | 9,789 |  |  | 5,558 |  |  | 57 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (4,568) |  |  | (4,160) |  |  | (408) |  |  | 10 | % |  | (12,100) |  |  | (13,089) |  |  | 989 |  |  | (8) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 5,887 |  |  | $ | 3,788 |  |  | $ | 2,099 |  |  | 55 | % |  | $ | 17,976 |  |  | $ | 8,836 |  |  | $ | 9,140 |  |  | 103 | % |  |  |  |  |  |  |  |  |

[0001730168-25-000098:mdna:51]
Operating income from our semiconductor solutions segment increased for the fiscal quarter and three fiscal quarters ended August 3, 2025 compared to the prior year fiscal periods due to strong demand for our networking products, primarily custom AI accelerators and AI networking solutions.

[0001730168-25-000098:mdna:52]
Higher operating income from our infrastructure software segment in the fiscal quarter and three fiscal quarters ended August 3, 2025 compared to the prior year fiscal periods was primarily due to strong demand for our VCF product, including additional license revenue recognized on contracts where customers do not have the right to terminate and the transition to a subscription license model.

[0001730168-25-000098:mdna:53]
30

[0001730168-25-000098:mdna:54]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 10% for the fiscal quarter ended August 3, 2025 compared to the prior year fiscal period primarily due to higher stock-based compensation expense, partially offset by lower amortization of acquisition-related intangible assets, and decreased 8% for the three fiscal quarters ended August 3, 2025 compared to the prior year fiscal period primarily due to lower restructuring and other charges and lower amortization of acquisition-related intangible assets, partially offset by higher stock-based compensation expense.

[0001730168-25-000098:mdna:55]
[same as prior period, unchanged from 0001730168-25-000064:mdna:58]

[0001730168-25-000098:mdna:56]
Interest expense. Interest expense was $807 million and $2,449 million for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and $1,064 million and $3,037 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. The decreases were primarily from an overall reduction in outstanding debt balances and debt refinancing activities that drove lower effective interest rates compared to the prior year fiscal periods.

[0001730168-25-000098:mdna:57]
Other income, net. Other income, net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $205 million and $82 million for the fiscal quarters ended August 3, 2025 and August 4, 2024, respectively. The increase was primarily due to a gain on the sale of a business. Other income, net was $333 million and $354 million for the three fiscal quarters ended August 3, 2025 and August 4, 2024, respectively. The decrease was primarily due to lower interest income as a result of lower interest rates on lower invested balances, partially offset by a gain on the sale of a business.

[0001730168-25-000098:mdna:58]
Provision for income taxes. On July 4, 2025, the United States enacted the One Big Beautiful Bill Act, which allows for the immediate expensing of domestic research and development costs, certain capital expenditures, and changes to the United States taxation of profits derived from foreign operations. As a result, it is no longer more-likely-than-not that we are able to utilize our federal corporate alternative minimum tax (“CAMT”) credits, and we established a $1,058 million valuation allowance against our CAMT credit carryforwards and CAMT credits generated in the current fiscal year. Our policy is to not consider the impact of future years’ CAMT in our valuation allowance assessment for regular deferred tax assets. Most of the provisions are effective beginning in our fiscal years ending November 1, 2026 or October 31, 2027, with immediate expensing of qualifying property being effective in fiscal year 2025. We will continue to evaluate the full impact of these legislative changes as more guidance becomes available.

[0001730168-25-000098:mdna:59]
The provision for income taxes was $1,145 million and $1,252 million for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and was primarily due to the impact from a valuation allowance against our CAMT credits, income before income taxes, and the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000098:mdna:60]
The provision for income taxes was $4,238 million and $4,190 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and was primarily due to an intra-group transfer of certain IP rights during the fiscal quarter ended August 4, 2024 to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000098:mdna:61]
[same as prior period, unchanged from 0001730168-25-000064:mdna:62]

[0001730168-25-000098:mdna:62]
[same as prior period, unchanged from 0001730168-25-000064:mdna:63]

[0001730168-25-000098:mdna:63]
Our primary sources of liquidity as of August 3, 2025 consisted of: (i) $10,718 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-25-000098:mdna:64]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $66,257 million of outstanding indebtedness with $1,400 million principal amounts payable within 12 months, (vi) discretionary share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-25-000098:mdna:65]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-25-000098:mdna:66]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our outstanding indebtedness and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-25-000098:mdna:67]
[same as prior period, unchanged from 0001730168-25-000064:mdna:70]

[0001730168-25-000098:mdna:68]
[same as prior period, unchanged from 0001730168-25-000064:mdna:71]

[0001730168-25-000098:mdna:69]
Working capital increased to $8,294 million at August 3, 2025 from $2,898 million at November 3, 2024. The increase was primarily attributable to the following:

[0001730168-25-000098:mdna:70]
•Cash and cash equivalents increased to $10,718 million at August 3, 2025 from $9,348 million at November 3, 2024, primarily due to $19,834 million in net cash provided by operating activities, partially offset by $8,345 million of dividend payments, $3,860 million of employee withholding tax payments related to net settled equity awards, $3,657 million of net repayments of borrowings, and $2,450 million of common stock repurchases.

[0001730168-25-000098:mdna:71]
•Trade accounts receivable, net increased to $6,494 million at August 3, 2025 from $4,416 million at November 3, 2024 primarily due to higher billings and the timing of collections.

[0001730168-25-000098:mdna:72]
•Other current assets increased to $5,606 million at August 3, 2025 from $4,071 million at November 3, 2024 primarily from higher software contract assets, offset in part by lower prepaid taxes.

[0001730168-25-000098:mdna:73]
[same as prior period, unchanged from 0001730168-25-000064:mdna:79]

[0001730168-25-000098:mdna:74]
|  |  | Three Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 1.770 |  |  | $ | 1.575 |  |
| Dividends to common stockholders |  | $ | 8,345 |  |  | $ | 7,330 |  |

[0001730168-25-000098:mdna:75]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025. During the fiscal quarter ended May 4, 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million under this stock repurchase program. As of August 3, 2025, $7,550 million of the authorized amount remained available for repurchases.

[0001730168-25-000098:mdna:76]
[same as prior period, unchanged from 0001730168-25-000064:mdna:82]

[0001730168-25-000098:mdna:77]
[same as prior period, unchanged from 0001730168-25-000064:mdna:83]

[0001730168-25-000098:mdna:78]
During the three fiscal quarters ended August 3, 2025 and August 4, 2024, we paid $3,860 million and $4,012 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld 17 million and 30 million shares of common stock from employees in connection with such net share settlements during the three fiscal quarters ended August 3, 2025 and August 4, 2024, respectively. Beginning in the fiscal quarter ended August 3, 2025, we settle withholding taxes upon the vesting of employee equity awards using proceeds from the sale of a portion of the vested shares, thereby eliminating our cash outflow for employee withholding taxes on equity award vesting.

[0001730168-25-000098:mdna:79]
32

[0001730168-25-000098:mdna:80]
[same as prior period, unchanged from 0001730168-25-000064:mdna:85]

[0001730168-25-000098:mdna:81]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 19,834 |  |  | $ | 14,358 |  |
| Net cash used in investing activities |  | (213) |  |  | (22,938) |  |
| Net cash provided by (used in) financing activities |  | (18,251) |  |  | 4,343 |  |
| Net change in cash and cash equivalents |  | $ | 1,370 |  |  | $ | (4,237) |  |

[0001730168-25-000098:mdna:82]
[same as prior period, unchanged from 0001730168-25-000064:mdna:87]

[0001730168-25-000098:mdna:83]
Cash flows from operating activities consist of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $5,476 million increase in cash provided by operations during the three fiscal quarters ended August 3, 2025 compared to the prior year fiscal period was primarily due to $13,037 million higher net income, offset in part by $3,816 million lower non-cash adjustments for deferred taxes and other non-cash taxes, as well as $3,576 million from changes in operating assets and liabilities.

[0001730168-25-000098:mdna:84]
[same as prior period, unchanged from 0001730168-25-000064:mdna:89]

[0001730168-25-000098:mdna:85]
Cash flows from investing activities primarily consist of cash related to acquisitions and divestitures, capital expenditures and proceeds and payments related to investments. The $22,725 million decrease in cash used in investing activities during the three fiscal quarters ended August 3, 2025 compared to the prior year fiscal period was primarily due to $25,416 million cash paid in connection with the acquisition of VMware, net of cash acquired, in the prior year fiscal period, offset in part by $3,185 million lower proceeds from sales of businesses during the three fiscal quarters ended August 3, 2025 compared to the prior year fiscal period.

[0001730168-25-000098:mdna:86]
[same as prior period, unchanged from 0001730168-25-000064:mdna:91]

[0001730168-25-000098:mdna:87]
Cash flows from financing activities primarily consist of proceeds and payments related to our borrowings, dividend payments, employee withholding tax payments related to net settled equity awards and authorized stock repurchases. Cash flows from financing activities during the three fiscal quarters ended August 3, 2025 compared to the prior year fiscal period decreased $22,594 million. The decrease was primarily from the net proceeds from term loans issued in connection with the acquisition of VMware in the prior year fiscal period, debt repayments and higher dividend payments in the current year fiscal period, offset in part by a decrease in stock repurchases.
