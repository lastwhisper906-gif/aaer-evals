# AVGO 8-K — 0001730168-25-000094 filed 2025-09-04

## item codes, every 8-K on or before 2025-09-10

- 2025-09-10 0001193125-25-200108 — 8.01, 9.01
- 2025-09-09 0001193125-25-199281 — 5.02, 9.01
- 2025-09-04 0001730168-25-000094 — 2.02, 8.01, 9.01
- 2025-07-11 0001193125-25-158202 — 1.02, 8.01, 9.01
- 2025-06-05 0001730168-25-000061 — 2.02, 8.01, 9.01
- 2025-04-22 0001730168-25-000037 — 5.07
- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2025-09-10

- none on or before 2025-09-10

## item 2.02 — earnings release, exhibit 99.1

[0001730168-25-000094:8k_2_02:1]
EX-99.1
2
avgo-08032025x8kxex99.htm
EX-99.1

[0001730168-25-000094:8k_2_02:2]
Document

[0001730168-25-000094:8k_2_02:3]
Exhibit 99.1

[0001730168-25-000094:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2025 Financial Results and Quarterly Dividend

[0001730168-25-000094:8k_2_02:5]
•Revenue of $15,952 million for the third quarter, up 22 percent from the prior year period

[0001730168-25-000094:8k_2_02:6]
•GAAP net income of $4,140 million for the third quarter; Non-GAAP net income of $8,404 million for the third quarter

[0001730168-25-000094:8k_2_02:7]
•Adjusted EBITDA of $10,702 million for the third quarter, or 67 percent of revenue

[0001730168-25-000094:8k_2_02:8]
•GAAP diluted EPS of $0.85 for the third quarter; Non-GAAP diluted EPS of $1.69 for the third quarter

[0001730168-25-000094:8k_2_02:9]
•Cash from operations of $7,166 million for the third quarter, less capital expenditures of $142 million, resulted in $7,024 million of free cash flow, or 44 percent of revenue

[0001730168-25-000094:8k_2_02:10]
•Quarterly common stock dividend of $0.59 per share

[0001730168-25-000094:8k_2_02:11]
•Fourth quarter fiscal year 2025 revenue guidance of approximately $17.4 billion, an increase of 24 percent from the prior year period

[0001730168-25-000094:8k_2_02:12]
•Fourth quarter fiscal year 2025 Adjusted EBITDA guidance of 67 percent of projected revenue (1)

[0001730168-25-000094:8k_2_02:13]
PALO ALTO, Calif. – September 4, 2025 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2025, ended August 3, 2025, provided guidance for its fourth quarter of fiscal year 2025 and announced its quarterly dividend.

[0001730168-25-000094:8k_2_02:14]
“Broadcom achieved record third quarter revenue on continued strength in custom AI accelerators, networking and VMware. Q3 AI revenue growth accelerated to 63% year-over-year to $5.2 billion,” said Hock Tan, President and CEO of Broadcom Inc. “We expect growth in AI semiconductor revenue to accelerate to $6.2 billion in Q4, delivering eleven consecutive quarters of growth, as our customers continue to strongly invest.”

[0001730168-25-000094:8k_2_02:15]
“Consolidated revenue grew 22% year-over-year to a record $16.0 billion. Adjusted EBITDA increased 30% year-over-year to $10.7 billion reflecting strong operating leverage,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow was a record $7.0 billion, up 47% year-over-year. Consistent with our commitment to return excess cash to shareholders, we returned $2.8 billion to shareholders in the third quarter through cash dividends.”

[0001730168-25-000094:8k_2_02:16]
________________________________

[0001730168-25-000094:8k_2_02:17]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-25-000094:8k_2_02:18]
Third Quarter Fiscal Year 2025 Financial Highlights

[0001730168-25-000094:8k_2_02:19]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q3 25 |  | Q3 24 |  | Change |  | Q3 25 |  | Q3 24 |  | Change |
| Net revenue |  | $ | 15,952 |  |  | $ | 13,072 |  |  | +22 | % |  | $ | 15,952 |  |  | $ | 13,072 |  |  | +22 | % |
| Net income (loss) |  | $ | 4,140 |  |  | $ | (1,875) |  |  | +$6,015 |  |  | $ | 8,404 |  |  | $ | 6,120 |  |  | +$2,284 |  |
| Earnings (loss) per common share - diluted |  | $ | 0.85 |  |  | $ | (0.40) |  |  | +$1.25 |  |  | $ | 1.69 |  |  | $ | 1.24 |  |  | +$0.45 |  |

[0001730168-25-000094:8k_2_02:20]
| (Dollars in millions) |  | Q3 25 |  | Q3 24 |  | Change |  |
| Cash flow from operations |  | $ | 7,166 |  |  | $ | 4,963 |  |  | +$2,203 |  |
| Adjusted EBITDA |  | $ | 10,702 |  |  | $ | 8,223 |  |  | +$2,479 |  |
| Free cash flow |  | $ | 7,024 |  |  | $ | 4,791 |  |  | +$2,233 |  |

[0001730168-25-000094:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 25 |  |  |  | Q3 24 |  | Change |  |
| Semiconductor solutions |  | $ | 9,166 |  |  | 57 | % |  |  |  |  |  |  | $ | 7,274 |  |  | 56 | % |  | +26 | % |  |
| Infrastructure software |  | 6,786 |  |  | 43 |  |  |  |  |  |  |  | 5,798 |  |  | 44 |  |  | +17 | % |  |
| Total net revenue |  | $ | 15,952 |  |  | 100 | % |  |  |  |  |  |  | $ | 13,072 |  |  | 100 | % |  |  |  |  |

[0001730168-25-000094:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $10,718 million, compared to $9,472 million at the end of the prior fiscal quarter.

[0001730168-25-000094:8k_2_02:23]
During the third fiscal quarter, the Company generated $7,166 million in cash from operations and spent $142 million on capital expenditures, resulting in $7,024 million of free cash flow.

[0001730168-25-000094:8k_2_02:24]
On June 30, 2025, the Company paid a cash dividend of $0.59 per share, totaling $2,786 million.

[0001730168-25-000094:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-25-000094:8k_2_02:26]
Fourth Quarter Fiscal Year 2025 Business Outlook

[0001730168-25-000094:8k_2_02:27]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2025, ending November 2, 2025, is expected to be as follows:

[0001730168-25-000094:8k_2_02:28]
•Fourth quarter revenue guidance of approximately $17.4 billion; and

[0001730168-25-000094:8k_2_02:29]
•Fourth quarter Adjusted EBITDA guidance of 67 percent of projected revenue.

[0001730168-25-000094:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000094:8k_2_02:31]
2

[0001730168-25-000094:8k_2_02:32]
Quarterly Dividends

[0001730168-25-000094:8k_2_02:33]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.59 per share. The dividend is payable on September 30, 2025 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 22, 2025.

[0001730168-25-000094:8k_2_02:34]
Financial Results Conference Call

[0001730168-25-000094:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the third quarter of fiscal year 2025 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-25-000094:8k_2_02:36]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-25-000094:8k_2_02:37]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-25-000094:8k_2_02:38]
Non-GAAP Financial Measures

[0001730168-25-000094:8k_2_02:39]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-25-000094:8k_2_02:40]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-25-000094:8k_2_02:41]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-25-000094:8k_2_02:42]
3

[0001730168-25-000094:8k_2_02:43]
About Broadcom

[0001730168-25-000094:8k_2_02:44]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-25-000094:8k_2_02:45]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-25-000094:8k_2_02:46]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; cyclicality in the semiconductor industry or in our target markets; our acquisition of VMware, Inc., including our ability to realize the expected benefits; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and other channel partners of our products; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cybersecurity threats and a breach of security systems; our ability to make successful investments in research and development; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to improve our manufacturing capacity and quality; involvement in legal proceedings; ability of our software products to manage and secure IT infrastructures and environments; demand for our data center virtualization products and customer acceptance of our products, services and business strategy; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance;

[0001730168-25-000094:8k_2_02:47]
4

[0001730168-25-000094:8k_2_02:48]
our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our stock repurchase program; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000094:8k_2_02:49]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-25-000094:8k_2_02:50]
Contact:

[0001730168-25-000094:8k_2_02:51]
Ji Yoo

[0001730168-25-000094:8k_2_02:52]
Broadcom Inc.

[0001730168-25-000094:8k_2_02:53]
Investor Relations

[0001730168-25-000094:8k_2_02:54]
650-427-6000

[0001730168-25-000094:8k_2_02:55]
investor.relations@broadcom.com

[0001730168-25-000094:8k_2_02:56]
(AVGO-Q)

[0001730168-25-000094:8k_2_02:57]
5

[0001730168-25-000094:8k_2_02:58]
BROADCOM INC.

[0001730168-25-000094:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-25-000094:8k_2_02:60]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-25-000094:8k_2_02:61]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | May 4,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
| Net revenue |  | $ | 15,952 |  |  | $ | 15,004 |  |  | $ | 13,072 |  |  | $ | 45,872 |  |  | $ | 37,520 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,704 |  |  | 3,296 |  |  | 3,133 |  |  | 10,273 |  |  | 9,389 |  |
| Amortization of acquisition-related intangible assets |  | 1,519 |  |  | 1,483 |  |  | 1,525 |  |  | 4,486 |  |  | 4,421 |  |
| Restructuring charges |  | 26 |  |  | 28 |  |  | 58 |  |  | 68 |  |  | 203 |  |
| Total cost of revenue |  | 5,249 |  |  | 4,807 |  |  | 4,716 |  |  | 14,827 |  |  | 14,013 |  |
| Gross margin |  | 10,703 |  |  | 10,197 |  |  | 8,356 |  |  | 31,045 |  |  | 23,507 |  |
| Research and development |  | 3,050 |  |  | 2,693 |  |  | 2,353 |  |  | 7,996 |  |  | 7,076 |  |
| Selling, general and administrative |  | 1,072 |  |  | 1,083 |  |  | 1,100 |  |  | 3,104 |  |  | 3,949 |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 506 |  |  | 812 |  |  | 1,524 |  |  | 2,431 |  |
| Restructuring and other charges |  | 187 |  |  | 86 |  |  | 303 |  |  | 445 |  |  | 1,215 |  |
| Total operating expenses |  | 4,816 |  |  | 4,368 |  |  | 4,568 |  |  | 13,069 |  |  | 14,671 |  |
| Operating income |  | 5,887 |  |  | 5,829 |  |  | 3,788 |  |  | 17,976 |  |  | 8,836 |  |
| Interest expense |  | (807) |  |  | (769) |  |  | (1,064) |  |  | (2,449) |  |  | (3,037) |  |
| Other income, net |  | 205 |  |  | 25 |  |  | 82 |  |  | 333 |  |  | 354 |  |
| Income from continuing operations before income taxes |  | 5,285 |  |  | 5,085 |  |  | 2,806 |  |  | 15,860 |  |  | 6,153 |  |
| Provision for income taxes |  | 1,145 |  |  | 120 |  |  | 4,238 |  |  | 1,252 |  |  | 4,190 |  |
| Income (loss) from continuing operations |  | 4,140 |  |  | 4,965 |  |  | (1,432) |  |  | 14,608 |  |  | 1,963 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (443) |  |  | — |  |  | (392) |  |
| Net income (loss) |  | $ | 4,140 |  |  | $ | 4,965 |  |  | $ | (1,875) |  |  | $ | 14,608 |  |  | $ | 1,571 |  |
| Basic income (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.88 |  |  | $ | 1.05 |  |  | $ | (0.31) |  |  | $ | 3.10 |  |  | $ | 0.43 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.09) |  |  | — |  |  | (0.09) |  |
| Net income (loss) per share |  | $ | 0.88 |  |  | $ | 1.05 |  |  | $ | (0.40) |  |  | $ | 3.10 |  |  | $ | 0.34 |  |
| Diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.85 |  |  | $ | 1.03 |  |  | $ | (0.31) |  |  | $ | 3.02 |  |  | $ | 0.41 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.09) |  |  | — |  |  | (0.08) |  |
| Net income (loss) per share |  | $ | 0.85 |  |  | $ | 1.03 |  |  | $ | (0.40) |  |  | $ | 3.02 |  |  | $ | 0.33 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,714 |  |  | 4,707 |  |  | 4,663 |  |  | 4,705 |  |  | 4,606 |  |
| Diluted |  | 4,860 |  |  | 4,826 |  |  | 4,663 |  |  | 4,841 |  |  | 4,762 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 251 |  |  | $ | 203 |  |  | $ | 174 |  |  | $ | 607 |  |  | $ | 505 |  |
| Research and development |  | 1,573 |  |  | 1,169 |  |  | 877 |  |  | 3,564 |  |  | 2,621 |  |
| Selling, general and administrative |  | 498 |  |  | 399 |  |  | 330 |  |  | 1,202 |  |  | 1,230 |  |
| Total stock-based compensation expense |  | $ | 2,322 |  |  | $ | 1,771 |  |  | $ | 1,381 |  |  | $ | 5,373 |  |  | $ | 4,356 |  |

[0001730168-25-000094:8k_2_02:62]
BROADCOM INC.

[0001730168-25-000094:8k_2_02:63]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-25-000094:8k_2_02:64]
(IN MILLIONS)

[0001730168-25-000094:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | May 4,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
| Gross margin on GAAP basis |  | $ | 10,703 |  |  | $ | 10,197 |  |  | $ | 8,356 |  |  | $ | 31,045 |  |  | $ | 23,507 |  |
| Amortization of acquisition-related intangible assets |  | 1,519 |  |  | 1,483 |  |  | 1,525 |  |  | 4,486 |  |  | 4,421 |  |
| Stock-based compensation expense |  | 251 |  |  | 203 |  |  | 174 |  |  | 607 |  |  | 505 |  |
| Restructuring charges |  | 26 |  |  | 28 |  |  | 58 |  |  | 68 |  |  | 203 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Gross margin on non-GAAP basis |  | $ | 12,499 |  |  | $ | 11,911 |  |  | $ | 10,113 |  |  | $ | 36,206 |  |  | $ | 28,645 |  |
| Research and development on GAAP basis |  | $ | 3,050 |  |  | $ | 2,693 |  |  | $ | 2,353 |  |  | $ | 7,996 |  |  | $ | 7,076 |  |
| Stock-based compensation expense |  | 1,573 |  |  | 1,169 |  |  | 877 |  |  | 3,564 |  |  | 2,621 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 1,477 |  |  | $ | 1,524 |  |  | $ | 1,474 |  |  | $ | 4,432 |  |  | $ | 4,452 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,072 |  |  | $ | 1,083 |  |  | $ | 1,100 |  |  | $ | 3,104 |  |  | $ | 3,949 |  |
| Stock-based compensation expense |  | 498 |  |  | 399 |  |  | 330 |  |  | 1,202 |  |  | 1,230 |  |
| Acquisition-related costs |  | 7 |  |  | 90 |  |  | 79 |  |  | 204 |  |  | 451 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 567 |  |  | $ | 594 |  |  | $ | 691 |  |  | $ | 1,698 |  |  | $ | 2,268 |  |
| Total operating expenses on GAAP basis |  | $ | 4,816 |  |  | $ | 4,368 |  |  | $ | 4,568 |  |  | $ | 13,069 |  |  | $ | 14,671 |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 506 |  |  | 812 |  |  | 1,524 |  |  | 2,431 |  |
| Stock-based compensation expense |  | 2,071 |  |  | 1,568 |  |  | 1,207 |  |  | 4,766 |  |  | 3,851 |  |
| Restructuring and other charges |  | 187 |  |  | 86 |  |  | 303 |  |  | 445 |  |  | 1,215 |  |
| Acquisition-related costs |  | 7 |  |  | 90 |  |  | 81 |  |  | 204 |  |  | 454 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,044 |  |  | $ | 2,118 |  |  | $ | 2,165 |  |  | $ | 6,130 |  |  | $ | 6,720 |  |
| Operating income on GAAP basis |  | $ | 5,887 |  |  | $ | 5,829 |  |  | $ | 3,788 |  |  | $ | 17,976 |  |  | $ | 8,836 |  |
| Amortization of acquisition-related intangible assets |  | 2,026 |  |  | 1,989 |  |  | 2,337 |  |  | 6,010 |  |  | 6,852 |  |
| Stock-based compensation expense |  | 2,322 |  |  | 1,771 |  |  | 1,381 |  |  | 5,373 |  |  | 4,356 |  |
| Restructuring and other charges |  | 213 |  |  | 114 |  |  | 361 |  |  | 513 |  |  | 1,418 |  |
| Acquisition-related costs |  | 7 |  |  | 90 |  |  | 81 |  |  | 204 |  |  | 463 |  |
| Operating income on non-GAAP basis |  | $ | 10,455 |  |  | $ | 9,793 |  |  | $ | 7,948 |  |  | $ | 30,076 |  |  | $ | 21,925 |  |
| Interest expense on GAAP basis |  | $ | (807) |  |  | $ | (769) |  |  | $ | (1,064) |  |  | $ | (2,449) |  |  | $ | (3,037) |  |
| Loss on debt extinguishment |  | 53 |  |  | — |  |  | 83 |  |  | 118 |  |  | 105 |  |
| Interest expense on non-GAAP basis |  | $ | (754) |  |  | $ | (769) |  |  | $ | (981) |  |  | $ | (2,331) |  |  | $ | (2,932) |  |
| Other income, net on GAAP basis |  | $ | 205 |  |  | $ | 25 |  |  | $ | 82 |  |  | $ | 333 |  |  | $ | 354 |  |
| (Gains) losses on investments |  | 10 |  |  | 9 |  |  | 6 |  |  | 23 |  |  | (18) |  |
| Gain from sale of business |  | (163) |  |  | — |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | 19 |  |  | (3) |  |  | — |  |  | (15) |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 71 |  |  | $ | 31 |  |  | $ | 88 |  |  | $ | 178 |  |  | $ | 336 |  |

[0001730168-25-000094:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | May 4,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
| Provision for income taxes on GAAP basis |  | $ | 1,145 |  |  | $ | 120 |  |  | $ | 4,238 |  |  | $ | 1,252 |  |  | $ | 4,190 |  |
| Non-GAAP tax reconciling adjustments (1) |  | 223 |  |  | 1,148 |  |  | (3,303) |  |  | 2,657 |  |  | (1,629) |  |
| Provision for income taxes on non-GAAP basis |  | $ | 1,368 |  |  | $ | 1,268 |  |  | $ | 935 |  |  | $ | 3,909 |  |  | $ | 2,561 |  |
| Net income (loss) on GAAP basis |  | $ | 4,140 |  |  | $ | 4,965 |  |  | $ | (1,875) |  |  | $ | 14,608 |  |  | $ | 1,571 |  |
| Amortization of acquisition-related intangible assets |  | 2,026 |  |  | 1,989 |  |  | 2,337 |  |  | 6,010 |  |  | 6,852 |  |
| Stock-based compensation expense |  | 2,322 |  |  | 1,771 |  |  | 1,381 |  |  | 5,373 |  |  | 4,356 |  |
| Restructuring and other charges |  | 213 |  |  | 114 |  |  | 361 |  |  | 513 |  |  | 1,418 |  |
| Acquisition-related costs |  | 7 |  |  | 90 |  |  | 81 |  |  | 204 |  |  | 463 |  |
| Loss on debt extinguishment |  | 53 |  |  | — |  |  | 83 |  |  | 118 |  |  | 105 |  |
| (Gains) losses on investments |  | 10 |  |  | 9 |  |  | 6 |  |  | 23 |  |  | (18) |  |
| Gain from sale of business |  | (163) |  |  | — |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | 19 |  |  | (3) |  |  | — |  |  | (15) |  |  | — |  |
| Non-GAAP tax reconciling adjustments (1) |  | (223) |  |  | (1,148) |  |  | 3,303 |  |  | (2,657) |  |  | 1,629 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 443 |  |  | — |  |  | 392 |  |
| Net income on non-GAAP basis |  | $ | 8,404 |  |  | $ | 7,787 |  |  | $ | 6,120 |  |  | $ | 24,014 |  |  | $ | 16,768 |  |
| Net income (loss) on GAAP basis |  | $ | 4,140 |  |  | $ | 4,965 |  |  | $ | (1,875) |  |  | $ | 14,608 |  |  | $ | 1,571 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,026 |  |  | 1,989 |  |  | 2,337 |  |  | 6,010 |  |  | 6,852 |  |
| Stock-based compensation expense |  | 2,322 |  |  | 1,771 |  |  | 1,381 |  |  | 5,373 |  |  | 4,356 |  |
| Restructuring and other charges |  | 213 |  |  | 114 |  |  | 361 |  |  | 513 |  |  | 1,418 |  |
| Acquisition-related costs |  | 7 |  |  | 90 |  |  | 81 |  |  | 204 |  |  | 463 |  |
| Loss on debt extinguishment |  | 53 |  |  | — |  |  | 83 |  |  | 118 |  |  | 105 |  |
| (Gains) losses on investments |  | 10 |  |  | 9 |  |  | 6 |  |  | 23 |  |  | (18) |  |
| Gain from sale of business |  | (163) |  |  | — |  |  | — |  |  | (163) |  |  | — |  |
| Other |  | 19 |  |  | (3) |  |  | — |  |  | (15) |  |  | — |  |
| Non-GAAP tax reconciling adjustments (1) |  | (223) |  |  | (1,148) |  |  | 3,303 |  |  | (2,657) |  |  | 1,629 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 443 |  |  | — |  |  | 392 |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 754 |  |  | 769 |  |  | 981 |  |  | 2,331 |  |  | 2,932 |  |
| Provision for income taxes on non-GAAP basis |  | 1,368 |  |  | 1,268 |  |  | 935 |  |  | 3,909 |  |  | 2,561 |  |
| Depreciation |  | 142 |  |  | 142 |  |  | 149 |  |  | 426 |  |  | 437 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 34 |  |  | 35 |  |  | 38 |  |  | 106 |  |  | 110 |  |
| Adjusted EBITDA |  | $ | 10,702 |  |  | $ | 10,001 |  |  | $ | 8,223 |  |  | $ | 30,786 |  |  | $ | 22,808 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,860 |  |  | 4,826 |  |  | 4,663 |  |  | 4,841 |  |  | 4,762 |  |
| Non-GAAP adjustment (2) |  | 112 |  |  | 111 |  |  | 254 |  |  | 94 |  |  | 106 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,972 |  |  | 4,937 |  |  | 4,917 |  |  | 4,935 |  |  | 4,868 |  |
| Net cash provided by operating activities |  | $ | 7,166 |  |  | $ | 6,555 |  |  | $ | 4,963 |  |  | $ | 19,834 |  |  | $ | 14,358 |  |
| Purchases of property, plant and equipment |  | (142) |  |  | (144) |  |  | (172) |  |  | (386) |  |  | (426) |  |
| Free cash flow |  | $ | 7,024 |  |  | $ | 6,411 |  |  | $ | 4,791 |  |  | $ | 19,448 |  |  | $ | 13,932 |  |

[0001730168-25-000094:8k_2_02:67]
|  |  | Fiscal Quarter Ending |
|  |  | November 2, |
| Expected average diluted share count (3): |  | 2025 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,881 |  |
| Non-GAAP adjustment (2) |  | 89 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,970 |  |

[0001730168-25-000094:8k_2_02:68]
| (1) Non-GAAP tax reconciling adjustments included a one-time discrete non-cash tax provision of $4.5 billion from the impact of an intra-group transfer of certain IP rights to the United States as a result of supply chain realignment for the fiscal quarter and three fiscal quarters ended August 4, 2024. |
| (2) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter ended August 4, 2024, non-GAAP adjustment included the dilutive effect of the equity awards that were antidilutive on a GAAP basis. |
| (3) Excludes the effects of potential share repurchases. |

[0001730168-25-000094:8k_2_02:69]
BROADCOM INC.

[0001730168-25-000094:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-25-000094:8k_2_02:71]
(IN MILLIONS)

[0001730168-25-000094:8k_2_02:72]
|  |  | August 3,2025 |  | November 3,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 10,718 |  |  | $ | 9,348 |  |
| Trade accounts receivable, net |  | 6,494 |  |  | 4,416 |  |
| Inventory |  | 2,180 |  |  | 1,760 |  |
| Other current assets |  | 5,606 |  |  | 4,071 |  |
| Total current assets |  | 24,998 |  |  | 19,595 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,451 |  |  | 2,521 |  |
| Goodwill |  | 97,801 |  |  | 97,873 |  |
| Intangible assets, net |  | 34,344 |  |  | 40,583 |  |
| Other long-term assets |  | 6,027 |  |  | 5,073 |  |
| Total assets |  | $ | 165,621 |  |  | $ | 165,645 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,432 |  |  | $ | 1,662 |  |
| Employee compensation and benefits |  | 1,719 |  |  | 1,971 |  |
| Short-term debt |  | 1,399 |  |  | 1,271 |  |
| Other current liabilities |  | 12,154 |  |  | 11,793 |  |
| Total current liabilities |  | 16,704 |  |  | 16,697 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 62,830 |  |  | 66,295 |  |
| Other long-term liabilities |  | 12,810 |  |  | 14,975 |  |
| Total liabilities |  | 92,344 |  |  | 97,967 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 69,011 |  |  | 67,466 |  |
| Retained earnings |  | 4,040 |  |  | — |  |
| Accumulated other comprehensive income |  | 221 |  |  | 207 |  |
| Total stockholders' equity |  | 73,277 |  |  | 67,678 |  |
| Total liabilities and equity |  | $ | 165,621 |  |  | $ | 165,645 |  |

[0001730168-25-000094:8k_2_02:73]
| BROADCOM INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |
| (IN MILLIONS) |  |
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |  |
|  |  | August 3,2025 |  | May 4,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 4,140 |  |  | $ | 4,965 |  |  | $ | (1,875) |  |  | $ | 14,608 |  |  | $ | 1,571 |  |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,060 |  |  | 2,024 |  |  | 2,375 |  |  | 6,116 |  |  | 6,962 |  |  |
| Depreciation |  | 142 |  |  | 142 |  |  | 149 |  |  | 426 |  |  | 437 |  |  |
| Stock-based compensation |  | 2,322 |  |  | 1,771 |  |  | 1,388 |  |  | 5,373 |  |  | 4,427 |  |  |
| Deferred taxes and other non-cash taxes |  | 284 |  |  | (571) |  |  | 3,638 |  |  | (983) |  |  | 2,833 |  |  |
| Loss on debt extinguishment |  | 53 |  |  | — |  |  | 83 |  |  | 118 |  |  | 105 |  |  |
| Non-cash interest expense |  | 82 |  |  | 94 |  |  | 115 |  |  | 273 |  |  | 336 |  |  |
| Other |  | (23) |  |  | 40 |  |  | 158 |  |  | 58 |  |  | 266 |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (937) |  |  | (590) |  |  | 835 |  |  | (2,066) |  |  | 2,078 |  |  |
| Inventory |  | (163) |  |  | (109) |  |  | (52) |  |  | (420) |  |  | 16 |  |  |
| Accounts payable |  | 136 |  |  | (613) |  |  | 373 |  |  | (236) |  |  | 206 |  |  |
| Employee compensation and benefits |  | 511 |  |  | 287 |  |  | 291 |  |  | (110) |  |  | (118) |  |  |
| Other current assets and current liabilities |  | (999) |  |  | (55) |  |  | (1,345) |  |  | (1,028) |  |  | (3,913) |  |  |
| Other long-term assets and long-term liabilities |  | (442) |  |  | (830) |  |  | (1,170) |  |  | (2,295) |  |  | (848) |  |  |
| Net cash provided by operating activities |  | 7,166 |  |  | 6,555 |  |  | 4,963 |  |  | 19,834 |  |  | 14,358 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (25,978) |  |  |
| Proceeds from sales of businesses |  | 300 |  |  | — |  |  | 3,485 |  |  | 300 |  |  | 3,485 |  |  |
| Purchases of property, plant and equipment |  | (142) |  |  | (144) |  |  | (172) |  |  | (386) |  |  | (426) |  |  |
| Purchases of investments |  | (99) |  |  | (57) |  |  | (73) |  |  | (261) |  |  | (145) |  |  |
| Sales of investments |  | 51 |  |  | 78 |  |  | 5 |  |  | 147 |  |  | 136 |  |  |
| Other |  | (16) |  |  | (10) |  |  | 2 |  |  | (13) |  |  | (10) |  |  |
| Net cash provided by (used in) investing activities |  | 94 |  |  | (133) |  |  | 3,245 |  |  | (213) |  |  | (22,938) |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 6,960 |  |  | 749 |  |  | 4,975 |  |  | 10,695 |  |  | 34,985 |  |  |
| Payments on debt obligations |  | (6,750) |  |  | — |  |  | (9,202) |  |  | (14,840) |  |  | (12,136) |  |  |
| Proceeds from (repayments of) commercial paper, net |  | (3,373) |  |  | (119) |  |  | — |  |  | 488 |  |  | — |  |  |
| Payments of dividends |  | (2,786) |  |  | (2,785) |  |  | (2,452) |  |  | (8,345) |  |  | (7,330) |  |  |
| Repurchases of common stock - repurchase program |  | — |  |  | (2,450) |  |  | — |  |  | (2,450) |  |  | (7,176) |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (58) |  |  | (1,766) |  |  | (1,350) |  |  | (3,860) |  |  | (4,012) |  |  |
| Issuance of common stock |  | — |  |  | 118 |  |  | — |  |  | 118 |  |  | 64 |  |  |
| Other |  | (7) |  |  | (4) |  |  | (36) |  |  | (57) |  |  | (52) |  |  |
| Net cash provided by (used in) financing activities |  | (6,014) |  |  | (6,257) |  |  | (8,065) |  |  | (18,251) |  |  | 4,343 |  |  |
| Net change in cash and cash equivalents |  | 1,246 |  |  | 165 |  |  | 143 |  |  | 1,370 |  |  | (4,237) |  |  |
| Cash and cash equivalents at beginning of period |  | 9,472 |  |  | 9,307 |  |  | 9,809 |  |  | 9,348 |  |  | 14,189 |  |  |
| Cash and cash equivalents at end of period |  | $ | 10,718 |  |  | $ | 9,472 |  |  | $ | 9,952 |  |  | $ | 10,718 |  |  | $ | 9,952 |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 602 |  |  | $ | 700 |  |  | $ | 816 |  |  | $ | 1,973 |  |  | $ | 2,512 |  |  |
| Cash paid for income taxes |  | $ | 822 |  |  | $ | 608 |  |  | $ | 585 |  |  | $ | 1,834 |  |  | $ | 2,323 |  |  |
