# AVGO note change history — 0001730168-25-000064 → 0001730168-25-000098


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:1]
The following table summarizes contractual obligations and commitments as of August 3, 2025:
  (was, 2025-06-11, similarity 0.9595):
[0001730168-25-000064:note_history:1]
The following table summarizes contractual obligations and commitments as of May 4, 2025:

- changed (2025-09-10):
[0001730168-25-000098:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 3, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,817 million of unrecognized tax benefits and accrued interest and penalties as of August 3, 2025 have been excluded from the table above.
  (was, 2025-06-11, similarity 0.9028):
[0001730168-25-000064:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 4, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,732 million of unrecognized tax benefits and accrued interest and penalties as of May 4, 2025 have been excluded from the table above.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Our semiconductor solutions include a broad portfolio of complex digital and mixed signal complementary metal oxide semiconductor based devices, analog III-V based products, network interface cards and other modules, switches, subsystems and, in some cases, racks that are used in a wide array of environments, end products and applications such as artificial intelligence (“AI”) and enterprise data centers, servers, networking and connectivity equipment, storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.
  (was, 2025-06-11, similarity 0.8122):
[0001730168-25-000064:note_history:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- changed (2025-09-10):
[0001730168-25-000098:note_history:4]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 3, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.
  (was, 2025-06-11, similarity 0.9955):
[0001730168-25-000064:note_history:4]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 4, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.

- removed (2025-09-10):
[0001730168-25-000064:note_history:5]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock through the filing of an amendment (“Amendment”) to our Amended and Restated Certificate of Incorporation. The Amendment proportionately increased the number of shares of our authorized common stock without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented in the accompanying condensed consolidated financial statements and notes thereto have been retroactively adjusted, where applicable, to reflect the stock split.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:6]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| July 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | $ | 1,750 |  |  | $ | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
  (was, 2025-06-11, similarity 0.7913):
[0001730168-25-000064:note_history:6]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| May 2025 Term Loan - fixed rate |  |  |  |  |  |  |
| 4.489% loan due May 2028 |  | 4.55 | % |  | $ | 750 |  |  | $ | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.45 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:7]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 6,250 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
  (was, 2025-06-11, similarity 0.8063):
[0001730168-25-000064:note_history:7]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,507 |  |  | 69,847 |  |
| Commercial paper |  | 4.69 | % | (b) | 3,900 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 69,407 |  |  | $ | 69,847 |  |

- added (2025-09-10):
[0001730168-25-000098:note_history:8]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.71 | % | (b) | 500 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 66,257 |  |  | $ | 69,847 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:9]
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes outstanding |  | $ | 900 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 496 |  |  | — |  |
| Short-term finance lease liabilities |  | 3 |  |  | 26 |  |
| Total short-term debt |  | $ | 1,399 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 64,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,034) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 62,830 |  |  | $ | 66,295 |  |
  (was, 2025-06-11, similarity 0.9421):
[0001730168-25-000064:note_history:9]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,877 |  |  | — |  |
| Short-term finance lease liabilities |  | 4 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,531 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,113) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 61,751 |  |  | $ | 66,295 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:10]
(b) Represents the weighted average interest rate on commercial paper outstanding as of August 3, 2025.
  (was, 2025-06-11, similarity 0.9637):
[0001730168-25-000064:note_history:10]
(b) Represents the weighted average interest rate on commercial paper outstanding as of May 4, 2025.

- added (2025-09-10):
[0001730168-25-000098:note_history:11]
We entered into a $750 million three-year term loan at a 4.489% fixed rate and a $1.0 billion three-year term loan at a 4.540% fixed rate on May 2, 2025 and May 9, 2025, respectively. Using the proceeds and cash on hand, we repaid the $750 million of senior notes that matured on May 15, 2025 and $3.4 billion of commercial paper during the fiscal quarter ended August 3, 2025.

- added (2025-09-10):
[0001730168-25-000098:note_history:12]
In July 2025, we issued senior unsecured notes for an aggregate principal amount of $6,000 million. Using the net proceeds from these senior notes, we repaid the remaining $6,000 million of our unsecured term facility due November 2028. Upon repayment, we terminated the credit agreement entered into on August 15, 2023.

- added (2025-09-10):
[0001730168-25-000098:note_history:13]
As a result of these repayments, we wrote off unamortized discount and issuance costs of $53 million during the fiscal quarter ended August 3, 2025, and $65 million during the fiscal quarter ended February 2, 2025, which were included in

- added (2025-09-10):
[0001730168-25-000098:note_history:14]
interest expense in the condensed consolidated statements of operations.

- changed (2025-09-10):
[0001730168-25-000098:note_history:15]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either August 3, 2025 or November 3, 2024.
  (was, 2025-06-11, similarity 0.975):
[0001730168-25-000064:note_history:15]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either May 4, 2025 or November 3, 2024.

- changed (2025-09-10):
[0001730168-25-000098:note_history:16]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of August 3, 2025, we had $500 million of commercial paper outstanding with maturities ranging from 40 days to 187 days.
  (was, 2025-06-11, similarity 0.9924):
[0001730168-25-000064:note_history:16]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of May 4, 2025, we had $3.9 billion of commercial paper outstanding with maturities ranging from 22 days to 187 days.

- changed (2025-09-10):
[0001730168-25-000098:note_history:17]
As of August 3, 2025, the estimated aggregate fair value of our fixed-rate borrowings was $62,489 million, which was determined using quoted prices from less active markets or other observable inputs. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2025-06-11, similarity 0.728):
[0001730168-25-000064:note_history:17]
As of May 4, 2025, the estimated aggregate fair value of our fixed-rate borrowings was $55,001 million, which was determined using quoted prices from less active markets or other observable inputs. The carrying value of the floating-rate term loans approximates their fair value as they bear interest at the market observable interest rate tied to the Secured Overnight Financing Rate (“SOFR”) that resets periodically. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

- changed (2025-09-10):
[0001730168-25-000098:note_history:18]
The future scheduled principal payments of senior notes and term loans as of August 3, 2025 were as follows:
  (was, 2025-06-11, similarity 0.9659):
[0001730168-25-000064:note_history:18]
The future scheduled principal payments of senior notes and term loans as of May 4, 2025 were as follows:

- changed (2025-09-10):
[0001730168-25-000098:note_history:19]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| Thereafter |  | 44,693 |  |
| Total |  | $ | 65,757 |  |
  (was, 2025-06-11, similarity 0.9952):
[0001730168-25-000064:note_history:19]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 750 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 6,120 |  |
| 2029 |  | 10,655 |  |
| Thereafter |  | 38,693 |  |
| Total |  | $ | 65,507 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:20]
As of August 3, 2025 and November 3, 2024, we were in compliance with all debt covenants.
  (was, 2025-06-11, similarity 0.9554):
[0001730168-25-000064:note_history:20]
As of May 4, 2025 and November 3, 2024, we were in compliance with all debt covenants.

- removed (2025-09-10):
[0001730168-25-000064:note_history:21]
On May 2, 2025, we entered into a $750 million three-year fixed-rate term loan (the “May 2025 Term Loan”).

- removed (2025-09-10):
[0001730168-25-000064:note_history:22]
Subsequent to the fiscal quarter ended May 4, 2025, we entered into a $1.0 billion three-year term loan at a 4.540% fixed rate and used the proceeds as well as cash on hand to repay $1.9 billion of commercial paper. We also used the May 2025 Term Loan proceeds to repay the $750 million of senior notes that matured on May 15, 2025.

- removed (2025-09-10):
[0001730168-25-000064:note_history:23]
As a result of these repayments, we wrote off unamortized discount and issuance costs of $65 million during the fiscal quarter ended February 2, 2025, which were included in interest expense in the condensed consolidated statement of operations.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:24]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| July 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | $ | 1,750 |  |  | $ | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
  (was, 2025-06-11, similarity 0.7913):
[0001730168-25-000064:note_history:24]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| May 2025 Term Loan - fixed rate |  |  |  |  |  |  |
| 4.489% loan due May 2028 |  | 4.55 | % |  | $ | 750 |  |  | $ | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.45 | % |  | 6,000 |  |  | 8,000 |  |
|  |  |  |  | 6,000 |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:25]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 6,250 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
  (was, 2025-06-11, similarity 0.8063):
[0001730168-25-000064:note_history:25]
|  |  | Effective Interest Rate |  | May 4,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 7,000 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,507 |  |  | 69,847 |  |
| Commercial paper |  | 4.69 | % | (b) | 3,900 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 69,407 |  |  | $ | 69,847 |  |

- added (2025-09-10):
[0001730168-25-000098:note_history:26]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.71 | % | (b) | 500 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 66,257 |  |  | $ | 69,847 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:27]
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes outstanding |  | $ | 900 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 496 |  |  | — |  |
| Short-term finance lease liabilities |  | 3 |  |  | 26 |  |
| Total short-term debt |  | $ | 1,399 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 64,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,034) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 62,830 |  |  | $ | 66,295 |  |
  (was, 2025-06-11, similarity 0.9421):
[0001730168-25-000064:note_history:27]
|  |  | May 4,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes and term loans outstanding |  | $ | 1,650 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 3,877 |  |  | — |  |
| Short-term finance lease liabilities |  | 4 |  |  | 26 |  |
| Total short-term debt |  | $ | 5,531 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 63,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,113) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 61,751 |  |  | $ | 66,295 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:28]
(b) Represents the weighted average interest rate on commercial paper outstanding as of August 3, 2025.
  (was, 2025-06-11, similarity 0.9637):
[0001730168-25-000064:note_history:28]
(b) Represents the weighted average interest rate on commercial paper outstanding as of May 4, 2025.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:29]
The future scheduled principal payments of senior notes and term loans as of August 3, 2025 were as follows:
  (was, 2025-06-11, similarity 0.9659):
[0001730168-25-000064:note_history:29]
The future scheduled principal payments of senior notes and term loans as of May 4, 2025 were as follows:

- changed (2025-09-10):
[0001730168-25-000098:note_history:30]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| Thereafter |  | 44,693 |  |
| Total |  | $ | 65,757 |  |
  (was, 2025-06-11, similarity 0.9952):
[0001730168-25-000064:note_history:30]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 750 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 6,120 |  |
| 2029 |  | 10,655 |  |
| Thereafter |  | 38,693 |  |
| Total |  | $ | 65,507 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:31]
|  |  | Fiscal Quarter Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 662 |  |  | $ | 8,181 |  |  | $ | 414 |  |  | $ | 9,257 |  |
| Subscriptions and services |  | 4,062 |  |  | 779 |  |  | 1,854 |  |  | 6,695 |  |
| Total |  | $ | 4,724 |  |  | $ | 8,960 |  |  | $ | 2,268 |  |  | $ | 15,952 |  |
  (was, 2025-06-11, similarity 0.9861):
[0001730168-25-000064:note_history:31]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 635 |  |  | $ | 7,454 |  |  | $ | 417 |  |  | $ | 8,506 |  |
| Subscriptions and services |  | 4,071 |  |  | 646 |  |  | 1,781 |  |  | 6,498 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:32]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |
  (was, 2025-06-11, similarity 0.9861):
[0001730168-25-000064:note_history:32]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:33]
|  |  | Three Fiscal Quarters Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,787 |  |  | $ | 22,904 |  |  | $ | 1,243 |  |  | $ | 25,934 |  |
| Subscriptions and services |  | 12,275 |  |  | 2,188 |  |  | 5,475 |  |  | 19,938 |  |
| Total |  | $ | 14,062 |  |  | $ | 25,092 |  |  | $ | 6,718 |  |  | $ | 45,872 |  |
  (was, 2025-06-11, similarity 0.9773):
[0001730168-25-000064:note_history:33]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,125 |  |  | $ | 14,723 |  |  | $ | 829 |  |  | $ | 16,677 |  |
| Subscriptions and services |  | 8,213 |  |  | 1,409 |  |  | 3,621 |  |  | 13,243 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:34]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |
  (was, 2025-06-11, similarity 0.9773):
[0001730168-25-000064:note_history:34]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:35]
|  |  | Fiscal Quarter Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 662 |  |  | $ | 8,181 |  |  | $ | 414 |  |  | $ | 9,257 |  |
| Subscriptions and services |  | 4,062 |  |  | 779 |  |  | 1,854 |  |  | 6,695 |  |
| Total |  | $ | 4,724 |  |  | $ | 8,960 |  |  | $ | 2,268 |  |  | $ | 15,952 |  |
  (was, 2025-06-11, similarity 0.9861):
[0001730168-25-000064:note_history:35]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 635 |  |  | $ | 7,454 |  |  | $ | 417 |  |  | $ | 8,506 |  |
| Subscriptions and services |  | 4,071 |  |  | 646 |  |  | 1,781 |  |  | 6,498 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:36]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |
  (was, 2025-06-11, similarity 0.9861):
[0001730168-25-000064:note_history:36]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:37]
|  |  | Three Fiscal Quarters Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,787 |  |  | $ | 22,904 |  |  | $ | 1,243 |  |  | $ | 25,934 |  |
| Subscriptions and services |  | 12,275 |  |  | 2,188 |  |  | 5,475 |  |  | 19,938 |  |
| Total |  | $ | 14,062 |  |  | $ | 25,092 |  |  | $ | 6,718 |  |  | $ | 45,872 |  |
  (was, 2025-06-11, similarity 0.9773):
[0001730168-25-000064:note_history:37]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,125 |  |  | $ | 14,723 |  |  | $ | 829 |  |  | $ | 16,677 |  |
| Subscriptions and services |  | 8,213 |  |  | 1,409 |  |  | 3,621 |  |  | 13,243 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:38]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |
  (was, 2025-06-11, similarity 0.9773):
[0001730168-25-000064:note_history:38]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

- changed (2025-09-10):
[0001730168-25-000098:note_history:39]
|  |  | August 3,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 7,575 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,336 |  |  | $ | 14,495 |  |
  (was, 2025-06-11, similarity 0.9754):
[0001730168-25-000064:note_history:39]
|  |  | May 4,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 6,427 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,457 |  |  | $ | 14,495 |  |

- added (2025-09-10):
[0001730168-25-000098:note_history:40]
We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when revenue recognized on a contract exceeds the amount invoiced. A contract asset is a right to consideration that is conditional on something other than the passage of time. A contract asset becomes a receivable when invoiced upon the right to consideration becoming unconditional.

- added (2025-09-10):
[0001730168-25-000098:note_history:41]
We recognize a contract liability when billings on a contract exceed the revenue recognized and there is a future obligation to transfer products or services to a customer. Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment.

- added (2025-09-10):
[0001730168-25-000098:note_history:42]
As of August 3, 2025, approximately 66% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 3, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $8,021 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million.

- changed (2025-09-10):
[0001730168-25-000098:note_history:43]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of August 3, 2025 were approximately $27.5 billion. We expect approximately 34% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2025-06-11, similarity 0.993):
[0001730168-25-000064:note_history:43]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of May 4, 2025 were approximately $24.7 billion. We expect approximately 36% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2025-09-10):
[0001730168-25-000064:note_history:44]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of May 4, 2025, approximately 66% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 4, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $6,103 million. The amount of revenue recognized during the two fiscal quarters ended May 5, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,965 million.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-09-10):
[0001730168-25-000098:note_history:45]
On September 3, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on September 30, 2025 to stockholders of record on September 22, 2025.
  (was, 2025-06-11, similarity 0.9038):
[0001730168-25-000064:note_history:45]
On June 4, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on June 30, 2025 to stockholders of record on June 20, 2025.
