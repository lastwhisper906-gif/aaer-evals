# AVGO notes — 0001730168-25-000098


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-25-000098:notes:1]
[same as prior period, unchanged from 0001730168-25-000064:notes:1]

[0001730168-25-000098:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Our semiconductor solutions include a broad portfolio of complex digital and mixed signal complementary metal oxide semiconductor based devices, analog III-V based products, network interface cards and other modules, switches, subsystems and, in some cases, racks that are used in a wide array of environments, end products and applications such as artificial intelligence (“AI”) and enterprise data centers, servers, networking and connectivity equipment, storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-25-000098:notes:3]
[same as prior period, unchanged from 0001730168-25-000064:notes:3]

[0001730168-25-000098:notes:4]
[same as prior period, unchanged from 0001730168-25-000064:notes:4]

[0001730168-25-000098:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 3, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.

[0001730168-25-000098:notes:6]
[same as prior period, unchanged from 0001730168-25-000064:notes:7]

[0001730168-25-000098:notes:7]
[same as prior period, unchanged from 0001730168-25-000064:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-25-000098:notes:8]
[same as prior period, unchanged from 0001730168-25-000064:notes:9]

[0001730168-25-000098:notes:9]
[same as prior period, unchanged from 0001730168-25-000064:notes:10]

[0001730168-25-000098:notes:10]
[same as prior period, unchanged from 0001730168-25-000064:notes:11]

[0001730168-25-000098:notes:11]
[same as prior period, unchanged from 0001730168-25-000064:notes:12]

[0001730168-25-000098:notes:12]
|  |  | Fiscal Quarter Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 662 |  |  | $ | 8,181 |  |  | $ | 414 |  |  | $ | 9,257 |  |
| Subscriptions and services |  | 4,062 |  |  | 779 |  |  | 1,854 |  |  | 6,695 |  |
| Total |  | $ | 4,724 |  |  | $ | 8,960 |  |  | $ | 2,268 |  |  | $ | 15,952 |  |

[0001730168-25-000098:notes:13]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

[0001730168-25-000098:notes:14]
|  |  | Three Fiscal Quarters Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,787 |  |  | $ | 22,904 |  |  | $ | 1,243 |  |  | $ | 25,934 |  |
| Subscriptions and services |  | 12,275 |  |  | 2,188 |  |  | 5,475 |  |  | 19,938 |  |
| Total |  | $ | 14,062 |  |  | $ | 25,092 |  |  | $ | 6,718 |  |  | $ | 45,872 |  |

[0001730168-25-000098:notes:15]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |

[0001730168-25-000098:notes:16]
[same as prior period, unchanged from 0001730168-25-000064:notes:17]

[0001730168-25-000098:notes:17]
[same as prior period, unchanged from 0001730168-25-000064:notes:18]

[0001730168-25-000098:notes:18]
[same as prior period, unchanged from 0001730168-25-000064:notes:19]

[0001730168-25-000098:notes:19]
|  |  | August 3,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 7,575 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,336 |  |  | $ | 14,495 |  |

[0001730168-25-000098:notes:20]
We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when revenue recognized on a contract exceeds the amount invoiced. A contract asset is a right to consideration that is conditional on something other than the passage of time. A contract asset becomes a receivable when invoiced upon the right to consideration becoming unconditional.

[0001730168-25-000098:notes:21]
We recognize a contract liability when billings on a contract exceed the revenue recognized and there is a future obligation to transfer products or services to a customer. Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment.

[0001730168-25-000098:notes:22]
As of August 3, 2025, approximately 66% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 3, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $8,021 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million.

[0001730168-25-000098:notes:23]
[same as prior period, unchanged from 0001730168-25-000064:notes:22]

[0001730168-25-000098:notes:24]
[same as prior period, unchanged from 0001730168-25-000064:notes:23]

[0001730168-25-000098:notes:25]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of August 3, 2025 were approximately $27.5 billion. We expect approximately 34% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-25-000098:notes:26]
[same as prior period, unchanged from 0001730168-25-000064:notes:25]

[0001730168-25-000098:notes:27]
[same as prior period, unchanged from 0001730168-25-000064:notes:26]

[0001730168-25-000098:notes:28]
[same as prior period, unchanged from 0001730168-25-000064:notes:27]

[0001730168-25-000098:notes:29]
[same as prior period, unchanged from 0001730168-25-000064:notes:28]

[0001730168-25-000098:notes:30]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |  |  |
|  |  | August 4,2024 |  | August 4,2024 |  |  |  |  |  |  |  |  |  |  |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 13,088 |  |  | $ | 38,118 |  |  |  |  |  |  |  |  |  |  |  |
| Pro forma net income (loss) |  | $ | (1,819) |  |  | $ | 2,057 |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-25-000098:notes:31]
[same as prior period, unchanged from 0001730168-25-000064:notes:30]

[0001730168-25-000098:notes:32]
Cash equivalents included $1,564 million and $1,716 million of time deposits and $1,454 million and $1,171 million of money-market funds as of August 3, 2025 and November 3, 2024, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-25-000098:notes:33]
[same as prior period, unchanged from 0001730168-25-000064:notes:32]

[0001730168-25-000098:notes:34]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,700 million and $5,651 million during the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and $1,450 million and $3,950 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively.

[0001730168-25-000098:notes:35]
[same as prior period, unchanged from 0001730168-25-000064:notes:34]

[0001730168-25-000098:notes:36]
|  |  | August 3,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Finished goods |  | $ | 477 |  |  | $ | 504 |  |
| Work-in-process |  | 1,349 |  |  | 970 |  |
| Raw materials |  | 354 |  |  | 286 |  |
| Total inventory |  | $ | 2,180 |  |  | $ | 1,760 |  |

[0001730168-25-000098:notes:37]
[same as prior period, unchanged from 0001730168-25-000064:notes:36]

[0001730168-25-000098:notes:38]
|  |  | August 3,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 4,157 |  |  | $ | 1,916 |  |
| Prepaid expenses |  | 793 |  |  | 1,391 |  |
| Other |  | 656 |  |  | 764 |  |
| Total other current assets |  | $ | 5,606 |  |  | $ | 4,071 |  |

[0001730168-25-000098:notes:39]
[same as prior period, unchanged from 0001730168-25-000064:notes:38]

[0001730168-25-000098:notes:40]
|  |  | August 3,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 10,305 |  |  | $ | 9,395 |  |
| Interest payable |  | 644 |  |  | 535 |  |
| Tax liabilities |  | 410 |  |  | 720 |  |
| Other |  | 795 |  |  | 1,143 |  |
| Total other current liabilities |  | $ | 12,154 |  |  | $ | 11,793 |  |

[0001730168-25-000098:notes:41]
[same as prior period, unchanged from 0001730168-25-000064:notes:40]

[0001730168-25-000098:notes:42]
|  |  | August 3,2025 |  | November 3,2024 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 4,031 |  |  | $ | 5,100 |  |
| Unrecognized tax benefits |  | 3,817 |  |  | 3,669 |  |
| Deferred tax liabilities |  | 3,552 |  |  | 4,703 |  |
| Other |  | 1,410 |  |  | 1,503 |  |
| Total other long-term liabilities |  | $ | 12,810 |  |  | $ | 14,975 |  |

[0001730168-25-000098:notes:43]
[same as prior period, unchanged from 0001730168-25-000064:notes:42]

[0001730168-25-000098:notes:44]
[same as prior period, unchanged from 0001730168-25-000064:notes:43]

[0001730168-25-000098:notes:45]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |  |  |
|  |  | August 4,2024 |  |  |  |  |  | August 4,2024 |  |  |  |  |  |  |
|  |  | (In millions) |
| Net revenue |  | $ | 178 |  |  |  |  |  |  | $ | 858 |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  | $ | (100) |  |  |  |  |  |  | $ | (31) |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | (343) |  |  |  |  |  |  | (361) |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations, net of income taxes |  | $ | (443) |  |  |  |  |  |  | $ | (392) |  |  |  |  |  |  |  |  |  |

[0001730168-25-000098:notes:46]
[same as prior period, unchanged from 0001730168-25-000064:notes:45]

[0001730168-25-000098:notes:47]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |  | (In millions) |
| Cash paid for interest |  | $ | 602 |  |  | $ | 816 |  |  | $ | 1,973 |  |  | $ | 2,512 |  |
| Cash paid for income taxes |  | $ | 822 |  |  | $ | 585 |  |  | $ | 1,834 |  |  | $ | 2,323 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-25-000098:notes:48]
[same as prior period, unchanged from 0001730168-25-000064:notes:47]

[0001730168-25-000098:notes:49]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of August 3, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 36,957 |  |  | $ | (17,034) |  |  | $ | 19,923 |  |
| Customer contracts and related relationships |  | 16,043 |  |  | (3,757) |  |  | 12,286 |  |
| Trade names |  | 1,685 |  |  | (446) |  |  | 1,239 |  |
| Other |  | 191 |  |  | (115) |  |  | 76 |  |
| Intangible assets subject to amortization |  | 54,876 |  |  | (21,352) |  |  | 33,524 |  |
| In-process research and development |  | 820 |  |  | — |  |  | 820 |  |
| Total |  | $ | 55,696 |  |  | $ | (21,352) |  |  | $ | 34,344 |  |
| As of November 3, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (12,551) |  |  | $ | 22,916 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,271) |  |  | 13,915 |  |
| Trade names |  | 1,720 |  |  | (369) |  |  | 1,351 |  |
| Other |  | 166 |  |  | (105) |  |  | 61 |  |
| Intangible assets subject to amortization |  | 53,539 |  |  | (15,296) |  |  | 38,243 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,879 |  |  | $ | (15,296) |  |  | $ | 40,583 |  |

[0001730168-25-000098:notes:50]
Based on the amount of intangible assets subject to amortization as of August 3, 2025, the expected amortization expense was as follows:

[0001730168-25-000098:notes:51]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 2,072 |  |
| 2026 |  | 7,880 |  |
| 2027 |  | 6,805 |  |
| 2028 |  | 5,673 |  |
| 2029 |  | 4,547 |  |
| Thereafter |  | 6,547 |  |
| Total |  | $ | 33,524 |  |

[0001730168-25-000098:notes:52]
[same as prior period, unchanged from 0001730168-25-000064:notes:51]

[0001730168-25-000098:notes:53]
| Amortizable intangible assets: |  | August 3,2025 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 6 |
| Trade names |  | 11 |
| Other |  | 11 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-25-000098:notes:54]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-25-000098:notes:55]
Potentially dilutive shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”) and employee stock purchase plan (“ESPP”) rights (collectively referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income (loss) per share.

[0001730168-25-000098:notes:56]
[same as prior period, unchanged from 0001730168-25-000064:notes:55]

[0001730168-25-000098:notes:57]
For the fiscal quarter ended August 4, 2024, diluted net income (loss) per share excluded the potentially dilutive effect of 159 million shares of weighted-average equity awards outstanding as their effect was antidilutive.

[0001730168-25-000098:notes:58]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income (loss) per share computations for the periods presented:

[0001730168-25-000098:notes:59]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 4,140 |  |  | $ | (1,432) |  |  | $ | 14,608 |  |  | $ | 1,963 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (443) |  |  | — |  |  | (392) |  |
| Net income (loss) |  | $ | 4,140 |  |  | $ | (1,875) |  |  | $ | 14,608 |  |  | $ | 1,571 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,714 |  |  | 4,663 |  |  | 4,705 |  |  | 4,606 |  |
| Dilutive effect of equity awards |  | 146 |  |  | — |  |  | 136 |  |  | 156 |  |
| Weighted-average shares outstanding - diluted |  | 4,860 |  |  | 4,663 |  |  | 4,841 |  |  | 4,762 |  |

[0001730168-25-000098:notes:60]
| Basic income (loss) per share: |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.88 |  |  | $ | (0.31) |  |  | $ | 3.10 |  |  | $ | 0.43 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.09) |  |  | — |  |  | (0.09) |  |
| Net income (loss) per share |  | $ | 0.88 |  |  | $ | (0.40) |  |  | $ | 3.10 |  |  | $ | 0.34 |  |
| Diluted income (loss) per share: |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.85 |  |  | $ | (0.31) |  |  | $ | 3.02 |  |  | $ | 0.41 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.09) |  |  | — |  |  | (0.08) |  |
| Net income (loss) per share |  | $ | 0.85 |  |  | $ | (0.40) |  |  | $ | 3.02 |  |  | $ | 0.33 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-25-000098:notes:61]
Borrowings

[0001730168-25-000098:notes:62]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| July 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | $ | 1,750 |  |  | $ | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

[0001730168-25-000098:notes:63]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 6,250 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |

[0001730168-25-000098:notes:64]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.71 | % | (b) | 500 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 66,257 |  |  | $ | 69,847 |  |

[0001730168-25-000098:notes:65]
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes outstanding |  | $ | 900 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 496 |  |  | — |  |
| Short-term finance lease liabilities |  | 3 |  |  | 26 |  |
| Total short-term debt |  | $ | 1,399 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 64,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,034) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 62,830 |  |  | $ | 66,295 |  |

[0001730168-25-000098:notes:66]
______________________________

[0001730168-25-000098:notes:67]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

[0001730168-25-000098:notes:68]
(b) Represents the weighted average interest rate on commercial paper outstanding as of August 3, 2025.

[0001730168-25-000098:notes:69]
Fixed-Rate Term Loans

[0001730168-25-000098:notes:70]
We entered into a $750 million three-year term loan at a 4.489% fixed rate and a $1.0 billion three-year term loan at a 4.540% fixed rate on May 2, 2025 and May 9, 2025, respectively. Using the proceeds and cash on hand, we repaid the $750 million of senior notes that matured on May 15, 2025 and $3.4 billion of commercial paper during the fiscal quarter ended August 3, 2025.

[0001730168-25-000098:notes:71]
Interest on the term loans is due quarterly. We are permitted to prepay the term loans at any time, subject to a specified make-whole premium determined in accordance with the credit agreements governing the respective term loans, plus accrued and unpaid interest.

[0001730168-25-000098:notes:72]
Senior Notes

[0001730168-25-000098:notes:73]
In July 2025, we issued senior unsecured notes for an aggregate principal amount of $6,000 million. Using the net proceeds from these senior notes, we repaid the remaining $6,000 million of our unsecured term facility due November 2028. Upon repayment, we terminated the credit agreement entered into on August 15, 2023.

[0001730168-25-000098:notes:74]
In January 2025, we issued senior unsecured notes for an aggregate principal amount of $3,000 million. Using the net proceeds from these senior notes and commercial paper issued in January 2025 and cash on hand, we repaid the remaining $5,595 million of our unsecured term facility due November 2026 and $2,000 million of our unsecured term facility due November 2028.

[0001730168-25-000098:notes:75]
As a result of these repayments, we wrote off unamortized discount and issuance costs of $53 million during the fiscal quarter ended August 3, 2025, and $65 million during the fiscal quarter ended February 2, 2025, which were included in

[0001730168-25-000098:notes:76]
interest expense in the condensed consolidated statements of operations.

[0001730168-25-000098:notes:77]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

[0001730168-25-000098:notes:78]
2025 Credit Agreement

[0001730168-25-000098:notes:79]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either August 3, 2025 or November 3, 2024.

[0001730168-25-000098:notes:80]
Commercial Paper

[0001730168-25-000098:notes:81]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of August 3, 2025, we had $500 million of commercial paper outstanding with maturities ranging from 40 days to 187 days.

[0001730168-25-000098:notes:82]
Fair Value of Debt

[0001730168-25-000098:notes:83]
As of August 3, 2025, the estimated aggregate fair value of our fixed-rate borrowings was $62,489 million, which was determined using quoted prices from less active markets or other observable inputs. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-25-000098:notes:84]
Future Principal Payments of Debt

[0001730168-25-000098:notes:85]
The future scheduled principal payments of senior notes and term loans as of August 3, 2025 were as follows:

[0001730168-25-000098:notes:86]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| Thereafter |  | 44,693 |  |
| Total |  | $ | 65,757 |  |

[0001730168-25-000098:notes:87]
As of August 3, 2025 and November 3, 2024, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-25-000098:notes:88]
[same as prior period, unchanged from 0001730168-25-000064:notes:84]

[0001730168-25-000098:notes:89]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.590 |  |  | $ | 0.525 |  |  | $ | 1.770 |  |  | $ | 1.575 |  |
| Dividends to common stockholders |  | $ | 2,786 |  |  | $ | 2,452 |  |  | $ | 8,345 |  |  | $ | 7,330 |  |

[0001730168-25-000098:notes:90]
[same as prior period, unchanged from 0001730168-25-000064:notes:86]

[0001730168-25-000098:notes:91]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2025. During the fiscal quarter ended May 4, 2025, we repurchased and retired 16 million shares of our common stock for $2,450 million under this stock repurchase program. Repurchases under this stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-25-000098:notes:92]
[same as prior period, unchanged from 0001730168-25-000064:notes:88]

[0001730168-25-000098:notes:93]
[same as prior period, unchanged from 0001730168-25-000064:notes:89]

[0001730168-25-000098:notes:94]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 69 |  |  | $ | 31 |  |  | $ | 152 |  |  | $ | 87 |  |
| Cost of subscriptions and services |  | 182 |  |  | 143 |  |  | 455 |  |  | 418 |  |
| Research and development |  | 1,573 |  |  | 877 |  |  | 3,564 |  |  | 2,621 |  |
| Selling, general and administrative |  | 498 |  |  | 330 |  |  | 1,202 |  |  | 1,230 |  |
| Total stock-based compensation expense (a) |  | $ | 2,322 |  |  | $ | 1,381 |  |  | $ | 5,373 |  |  | $ | 4,356 |  |

[0001730168-25-000098:notes:95]
[same as prior period, unchanged from 0001730168-25-000064:notes:91]

[0001730168-25-000098:notes:96]
(a) Does not include stock-based compensation expense related to discontinued operations recognized during the fiscal quarter and three fiscal quarters ended August 4, 2024, which was included in loss from discontinued operations, net of income taxes in our condensed consolidated statements of operations.

[0001730168-25-000098:notes:97]
[same as prior period, unchanged from 0001730168-25-000064:notes:93]

[0001730168-25-000098:notes:98]
As of August 3, 2025, the total unrecognized compensation cost related to unvested stock-based awards was $25,057 million, which is expected to be recognized over the remaining weighted-average service period of 3.6 years.

[0001730168-25-000098:notes:99]
[same as prior period, unchanged from 0001730168-25-000064:notes:95]

[0001730168-25-000098:notes:100]
[same as prior period, unchanged from 0001730168-25-000064:notes:96]

[0001730168-25-000098:notes:101]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 3, 2024 |  | 213 |  |  | $ | 66.44 |  |  |  |  |  |
| Granted |  | 117 |  |  | $ | 187.96 |  |  |  |  |  |
| Vested |  | (69) |  |  | $ | 66.46 |  |  |  |  |  |
| Forfeited |  | (14) |  |  | $ | 101.17 |  |  |  |  |  |
| Balance as of August 3, 2025 |  | 247 |  |  | $ | 122.05 |  |  |  |  |  |

[0001730168-25-000098:notes:102]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended August 3, 2025 was $15,075 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-25-000098:notes:103]
Income Taxes
On July 4, 2025, the United States enacted the One Big Beautiful Bill Act, which allows for the immediate expensing of domestic research and development costs, certain capital expenditures, and changes to the United States taxation of profits derived from foreign operations. As a result, it is no longer more-likely-than-not that we are able to utilize our federal corporate alternative minimum tax (“CAMT”) credits, and we established a $1,058 million valuation allowance against our CAMT credit carryforwards and CAMT credits generated in the current fiscal year. Our policy is to not consider the impact of future years’ CAMT in our valuation allowance assessment for regular deferred tax assets. Most of the provisions are effective beginning in our fiscal years ending November 1, 2026 or October 31, 2027, with immediate expensing of qualifying property being effective in fiscal year 2025. We will continue to evaluate the full impact of these legislative changes as more guidance becomes available.

[0001730168-25-000098:notes:104]
The provision for income taxes was $1,145 million and $1,252 million for the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and was primarily due to the impact from a valuation allowance against our CAMT credits, income before income taxes, and the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000098:notes:105]
The provision for income taxes was $4,238 million and $4,190 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and was primarily due to an intra-group transfer of certain IP rights during the fiscal quarter ended August 4, 2024 to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income, partially offset by excess tax benefits from stock-based awards.

[0001730168-25-000098:notes:106]
As of August 3, 2025, we had $6,930 million of gross unrecognized tax benefits and accrued interest and penalties. Subsequent to the fiscal quarter ended August 3, 2025, certain statutes of limitations have lapsed. This is expected to reduce unrecognized tax benefits by approximately $3.1 billion in the fiscal quarter ending November 2, 2025, and by up to $3.5 billion within the next 12 months. As a result of these lapses of statutes of limitations, we estimate that we will recognize a discrete tax benefit of up to $2.1 billion during the fiscal quarter ending November 2, 2025. We are continuing to evaluate the impact of these lapses of statutes of limitations on our estimated annual effective tax rate and income tax provision.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-25-000098:notes:107]
[same as prior period, unchanged from 0001730168-25-000064:notes:101]

[0001730168-25-000098:notes:108]
[same as prior period, unchanged from 0001730168-25-000064:notes:102]

[0001730168-25-000098:notes:109]
Semiconductor solutions. Our semiconductor solutions are used in a wide array of environments, end products and applications such as AI and enterprise data centers, servers, networking and connectivity equipment, storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-25-000098:notes:110]
[same as prior period, unchanged from 0001730168-25-000064:notes:104]

[0001730168-25-000098:notes:111]
[same as prior period, unchanged from 0001730168-25-000064:notes:105]

[0001730168-25-000098:notes:112]
[same as prior period, unchanged from 0001730168-25-000064:notes:106]

[0001730168-25-000098:notes:113]
[same as prior period, unchanged from 0001730168-25-000064:notes:107]

[0001730168-25-000098:notes:114]
[same as prior period, unchanged from 0001730168-25-000064:notes:108]

[0001730168-25-000098:notes:115]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 3,2025 |  | August 4,2024 |  | August 3,2025 |  | August 4,2024 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 9,166 |  |  | $ | 7,274 |  |  | $ | 25,786 |  |  | $ | 21,866 |  |
| Infrastructure software |  | 6,786 |  |  | 5,798 |  |  | 20,086 |  |  | 15,654 |  |
| Total net revenue |  | $ | 15,952 |  |  | $ | 13,072 |  |  | $ | 45,872 |  |  | $ | 37,520 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 5,217 |  |  | $ | 4,042 |  |  | $ | 14,729 |  |  | $ | 12,136 |  |
| Infrastructure software |  | 5,238 |  |  | 3,906 |  |  | 15,347 |  |  | 9,789 |  |
| Unallocated expenses |  | (4,568) |  |  | (4,160) |  |  | (12,100) |  |  | (13,089) |  |
| Total operating income |  | $ | 5,887 |  |  | $ | 3,788 |  |  | $ | 17,976 |  |  | $ | 8,836 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-25-000098:notes:116]
Commitments and Contingencies
Commitments

[0001730168-25-000098:notes:117]
The following table summarizes contractual obligations and commitments as of August 3, 2025:

[0001730168-25-000098:notes:118]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 106 |  |  | $ | 264 |  |
| 2026 |  | 103 |  |  | 634 |  |
| 2027 |  | 12 |  |  | 604 |  |
| 2028 |  | 10 |  |  | 530 |  |
| 2029 |  | 4 |  |  | 718 |  |
| Thereafter |  | — |  |  | 1,027 |  |
| Total |  | $ | 235 |  |  | $ | 3,777 |  |

[0001730168-25-000098:notes:119]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-25-000098:notes:120]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-25-000098:notes:121]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 3, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,817 million of unrecognized tax benefits and accrued interest and penalties as of August 3, 2025 have been excluded from the table above.

[0001730168-25-000098:notes:122]
Contingencies

[0001730168-25-000098:notes:123]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-25-000098:notes:124]
Lawsuits Relating to VMware Backlog

[0001730168-25-000098:notes:125]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms and in March 2025 the California Court approved the settlement.

[0001730168-25-000098:notes:126]
Other Matters

[0001730168-25-000098:notes:127]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-25-000098:notes:128]
Contingency Assessment

[0001730168-25-000098:notes:129]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-25-000098:notes:130]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-25-000098:notes:131]
Other Indemnifications

[0001730168-25-000098:notes:132]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-25-000098:notes:133]
Restructuring and Other Charges
Restructuring Charges

[0001730168-25-000098:notes:134]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended August 3, 2025:

[0001730168-25-000098:notes:135]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2024 |  | $ | 119 |  |  | $ | — |  |  | $ | 119 |  |
| Restructuring charges |  | 302 |  |  | 141 |  |  | 443 |  |
| Utilization |  | (389) |  |  | (141) |  |  | (530) |  |
| Balance as of August 3, 2025 |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |

[0001730168-25-000098:notes:136]
In connection with the acquisition of VMware, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized restructuring charges related to employee termination costs of $108 million and $302 million during the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and $294 million and $1,270 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively.

[0001730168-25-000098:notes:137]
We also recognized impairment charges primarily related to lease assets and property, plant and equipment of $35 million and $141 million during the fiscal quarter and three fiscal quarters ended August 3, 2025, respectively, and $67 million and $148 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses.

[0001730168-25-000098:notes:138]
Other Charges

[0001730168-25-000098:notes:139]
Restructuring and other charges for the fiscal quarter ended August 3, 2025 included a $70 million non-recurring impairment charge related to an asset held-for-sale.


## us-gaap:SubsequentEventsTextBlock

[0001730168-25-000098:notes:140]
Subsequent Events
Cash Dividends Declared

[0001730168-25-000098:notes:141]
On September 3, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on September 30, 2025 to stockholders of record on September 22, 2025.
