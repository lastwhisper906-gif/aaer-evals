# AVGO notes — 0001730168-18-000084


## avgo:ConcentrationsRiskOtherRisksPolicyPolicyTextBlock

[0001730168-18-000084:notes:1]
Concentration of other risks.  The semiconductor industry is characterized by rapid technological change, competitive pricing pressures and cyclical market patterns. Our financial results are affected by a wide variety of factors, including general economic conditions worldwide, economic conditions specific to the semiconductor industry, timely implementation of new manufacturing technologies, ability to safeguard patents and other intellectual property in a rapidly evolving market and reliance on assembly and test subcontractors, third-party wafer fabricators and independent distributors. In addition, the semiconductor market has historically been cyclical and subject to significant economic downturns at various times. We are exposed to the risk of obsolescence of our inventory depending on the mix of future business.


## avgo:LongLivedAssetsPolicyPolicyTextBlock

[0001730168-18-000084:notes:2]
Long-lived assets. Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as an amortizable purchased intangible asset and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.


## avgo:ScheduleofAccumulatedBenefitObligationlessthanFairvalueofplanassetsTableTextBlock

[0001730168-18-000084:notes:3]
Plans with benefit obligations less than plan assets:

[0001730168-18-000084:notes:4]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 4, 2018 |  | October 29, 2017 |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 813 |  |  | $ | 807 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 812 |  |  | $ | 805 |  |  | $ | 60 |  |  | $ | 65 |  |
| Fair value of plan assets |  | $ | 866 |  |  | $ | 823 |  |  | $ | 81 |  |  | $ | 83 |  |


## avgo:ScheduleofIntangibleAssetsbyMajorClassTableTextBlock

[0001730168-18-000084:notes:5]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of November 4, 2018: |  |  |  |  |  |  |
| Purchased technology |  | $ | 15,806 |  |  | $ | (6,816 | ) |  | $ | 8,990 |  |
| Customer contracts and related relationships |  | 1,792 |  |  | (878 | ) |  | 914 |  |
| Trade names |  | 578 |  |  | (170 | ) |  | 408 |  |
| Other |  | 239 |  |  | (53 | ) |  | 186 |  |
| Intangible assets subject to amortization |  | 18,415 |  |  | (7,917 | ) |  | 10,498 |  |
| IPR&D |  | 264 |  |  | — |  |  | 264 |  |
| Total |  | $ | 18,679 |  |  | $ | (7,917 | ) |  | $ | 10,762 |  |
| As of October 29, 2017: |  |  |  |  |  |  |
| Purchased technology |  | $ | 12,724 |  |  | $ | (4,265 | ) |  | $ | 8,459 |  |
| Customer contracts and related relationships |  | 4,240 |  |  | (3,100 | ) |  | 1,140 |  |
| Trade names |  | 528 |  |  | (117 | ) |  | 411 |  |
| Other |  | 135 |  |  | (25 | ) |  | 110 |  |
| Intangible assets subject to amortization |  | 17,627 |  |  | (7,507 | ) |  | 10,120 |  |
| IPR&D |  | 712 |  |  | — |  |  | 712 |  |
| Total |  | $ | 18,339 |  |  | $ | (7,507 | ) |  | $ | 10,832 |  |

[0001730168-18-000084:notes:6]
Intangible Assets

[0001730168-18-000084:notes:7]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 9,010 |  |  | 6 |
| Customer contracts and related relationships |  | 2,703 |  |  | 2 |
| Order backlog |  | 750 |  |  | < 1 |
| Trade name |  | 350 |  |  | 17 |
| Other |  | 45 |  |  | 16 |
| Total identified finite-lived intangible assets |  | 12,858 |  |  |  |
| IPR&D |  | 1,950 |  |  | N/A |
| Total identified intangible assets, net of assets held-for-sale |  | 14,808 |  |  |  |
| Intangible assets included in assets held-for-sale |  | 320 |  |  |  |
| Identified intangible assets |  | $ | 15,128 |  |  |  |

[0001730168-18-000084:notes:8]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,925 |  |  | 10 |
| Customer contracts and related relationships |  | 255 |  |  | 11 |
| Trade name and other |  | 61 |  |  | 6 |
| Total identified finite-lived intangible assets |  | 3,241 |  |  |  |
| IPR&D |  | 155 |  |  | N/A |
| Total identified intangible assets |  | $ | 3,396 |  |  |  |


## avgo:ScheduleofSharebasedPaymentAwardValuationAssumptionsTableTextBlock

[0001730168-18-000084:notes:9]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-18-000084:notes:10]
|  |  | Market-Based Awards |
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
| Risk-free interest rate |  | 2.4 | % |  | 1.7 | % |  | 1.2 | % |
| Dividend yield |  | 2.6 | % |  | 1.8 | % |  | 1.3 | % |
| Volatility |  | 32.5 | % |  | 32.3 | % |  | 35.0 | % |
| Expected term (in years) |  | 4.0 |  |  | 4.0 |  |  | 3.8 |  |


## srt:CondensedStatementOfComprehensiveIncomeTableTextBlock

[0001730168-18-000084:notes:11]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Year Ended |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Net revenue |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 20,848 |  |  | $ | — |  |  | $ | 20,848 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 1,924 |  |  | — |  |  | (1,924 | ) |  | — |  |
| Total revenue |  | — |  |  | — |  |  | 1,924 |  |  | 20,848 |  |  | (1,924 | ) |  | 20,848 |  |
| Cost of products sold: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 132 |  |  | 6,889 |  |  | — |  |  | 7,021 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 126 |  |  | (126 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 3,004 |  |  | — |  |  | 3,004 |  |
| Restructuring charges |  | — |  |  | — |  |  | 1 |  |  | 19 |  |  | — |  |  | 20 |  |
| Total cost of products sold |  | — |  |  | — |  |  | 133 |  |  | 10,108 |  |  | (126 | ) |  | 10,115 |  |
| Gross margin |  | — |  |  | — |  |  | 1,791 |  |  | 10,740 |  |  | (1,798 | ) |  | 10,733 |  |
| Research and development |  | — |  |  | — |  |  | 1,651 |  |  | 2,117 |  |  | — |  |  | 3,768 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 1,798 |  |  | (1,798 | ) |  | — |  |
| Selling, general and administrative |  | 31 |  |  | 80 |  |  | 297 |  |  | 648 |  |  | — |  |  | 1,056 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 541 |  |  | — |  |  | 541 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 53 |  |  | 166 |  |  | — |  |  | 219 |  |
| Litigation settlements |  | — |  |  | — |  |  | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Total operating expenses |  | 31 |  |  | 80 |  |  | 2,015 |  |  | 5,270 |  |  | (1,798 | ) |  | 5,598 |  |
| Operating income (loss) |  | (31 | ) |  | (80 | ) |  | (224 | ) |  | 5,470 |  |  | — |  |  | 5,135 |  |
| Interest expense |  | — |  |  | — |  |  | (626 | ) |  | (2 | ) |  | — |  |  | (628 | ) |
| Intercompany interest expense |  | (67 | ) |  | — |  |  | (199 | ) |  | (1,449 | ) |  | 1,715 |  |  | — |  |
| Impairment on investment |  | — |  |  | — |  |  | — |  |  | (106 | ) |  | — |  |  | (106 | ) |
| Other income, net |  | — |  |  | 4 |  |  | 88 |  |  | 52 |  |  | — |  |  | 144 |  |
| Intercompany interest income |  | — |  |  | 1 |  |  | 1,516 |  |  | 198 |  |  | (1,715 | ) |  | — |  |
| Intercompany other income (expense), net |  | 111 |  |  | 230 |  |  | (56 | ) |  | (285 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | 13 |  |  | 155 |  |  | 499 |  |  | 3,878 |  |  | — |  |  | 4,545 |  |
| Provision for (benefit from) income taxes |  | 44 |  |  | 2 |  |  | (8,043 | ) |  | (87 | ) |  | — |  |  | (8,084 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (31 | ) |  | 153 |  |  | 8,542 |  |  | 3,965 |  |  | — |  |  | 12,629 |  |
| Earnings in subsidiaries |  | 12,290 |  |  | 12,654 |  |  | 4,114 |  |  | 14,809 |  |  | (43,867 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 12,259 |  |  | 12,807 |  |  | 12,656 |  |  | 18,774 |  |  | (43,867 | ) |  | 12,629 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (2 | ) |  | (17 | ) |  | — |  |  | (19 | ) |
| Net income |  | 12,259 |  |  | 12,807 |  |  | 12,654 |  |  | 18,757 |  |  | (43,867 | ) |  | 12,610 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | — |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 12,259 |  |  | $ | 12,456 |  |  | $ | 12,654 |  |  | $ | 18,757 |  |  | $ | (43,867 | ) |  | $ | 12,259 |  |
| Net income |  | $ | 12,259 |  |  | $ | 12,807 |  |  | $ | 12,654 |  |  | $ | 18,757 |  |  | $ | (43,867 | ) |  | $ | 12,610 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Other comprehensive loss |  | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Comprehensive income |  | 12,259 |  |  | 12,807 |  |  | 12,654 |  |  | 18,749 |  |  | (43,867 | ) |  | 12,602 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | — |  |  | 351 |  |
| Comprehensive income attributable to common stock |  | $ | 12,259 |  |  | $ | 12,456 |  |  | $ | 12,654 |  |  | $ | 18,749 |  |  | $ | (43,867 | ) |  | $ | 12,251 |  |

[0001730168-18-000084:notes:12]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Loss |
|  |  | Fiscal Year Ended |
|  |  | October 29, 2017 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Net revenue |  | $ | — |  |  | $ | — |  |  | $ | 73 |  |  | $ | 17,563 |  |  | $ | — |  |  | $ | 17,636 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 2,046 |  |  | 8 |  |  | (2,054 | ) |  | — |  |
| Total revenue |  | — |  |  | — |  |  | 2,119 |  |  | 17,571 |  |  | (2,054 | ) |  | 17,636 |  |
| Cost of products sold: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 154 |  |  | 6,439 |  |  | — |  |  | 6,593 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | (12 | ) |  | 174 |  |  | (162 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 7 |  |  | 2,504 |  |  | — |  |  | 2,511 |  |
| Restructuring charges |  | — |  |  | — |  |  | 5 |  |  | 14 |  |  | — |  |  | 19 |  |
| Total cost of products sold |  | — |  |  | — |  |  | 154 |  |  | 9,135 |  |  | (162 | ) |  | 9,127 |  |
| Gross margin |  | — |  |  | — |  |  | 1,965 |  |  | 8,436 |  |  | (1,892 | ) |  | 8,509 |  |
| Research and development |  | — |  |  | — |  |  | 1,490 |  |  | 1,802 |  |  | — |  |  | 3,292 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | (66 | ) |  | 1,958 |  |  | (1,892 | ) |  | — |  |
| Selling, general and administrative |  | — |  |  | 23 |  |  | 339 |  |  | 425 |  |  | — |  |  | 787 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 7 |  |  | 1,757 |  |  | — |  |  | 1,764 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 54 |  |  | 107 |  |  | — |  |  | 161 |  |
| Litigation settlements |  | — |  |  | — |  |  | — |  |  | 122 |  |  | — |  |  | 122 |  |
| Total operating expenses |  | — |  |  | 23 |  |  | 1,824 |  |  | 6,171 |  |  | (1,892 | ) |  | 6,126 |  |
| Operating income (loss) |  | — |  |  | (23 | ) |  | 141 |  |  | 2,265 |  |  | — |  |  | 2,383 |  |
| Interest expense |  | — |  |  | — |  |  | (411 | ) |  | (43 | ) |  | — |  |  | (454 | ) |
| Intercompany interest expense |  | — |  |  | (12 | ) |  | (274 | ) |  | (1,420 | ) |  | 1,706 |  |  | — |  |
| Loss on extinguishment of debt |  | — |  |  | — |  |  | (59 | ) |  | (107 | ) |  | — |  |  | (166 | ) |
| Other income, net |  | — |  |  | 2 |  |  | 30 |  |  | 30 |  |  | — |  |  | 62 |  |
| Intercompany interest income |  | — |  |  | 1 |  |  | 1,425 |  |  | 280 |  |  | (1,706 | ) |  | — |  |
| Intercompany other income (expense), net |  | — |  |  | 1,390 |  |  | (589 | ) |  | (801 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | — |  |  | 1,358 |  |  | 263 |  |  | 204 |  |  | — |  |  | 1,825 |  |
| Provision for (benefit from) income taxes |  | — |  |  | — |  |  | 67 |  |  | (32 | ) |  | — |  |  | 35 |  |
| Income from continuing operations before earnings in subsidiaries |  | — |  |  | 1,358 |  |  | 196 |  |  | 236 |  |  | — |  |  | 1,790 |  |
| Earnings in subsidiaries |  | 1,692 |  |  | 426 |  |  | 243 |  |  | 4,453 |  |  | (6,814 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 1,692 |  |  | 1,784 |  |  | 439 |  |  | 4,689 |  |  | (6,814 | ) |  | 1,790 |  |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (13 | ) |  | 7 |  |  | — |  |  | (6 | ) |
| Net income |  | $ | 1,692 |  |  | $ | 1,784 |  |  | $ | 426 |  |  | $ | 4,696 |  |  | $ | (6,814 | ) |  | $ | 1,784 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 92 |  |  | — |  |  | — |  |  | — |  |  | 92 |  |
| Net income attributable to common stock |  | $ | 1,692 |  |  | $ | 1,692 |  |  | $ | 426 |  |  | $ | 4,696 |  |  | $ | (6,814 | ) |  | $ | 1,692 |  |
| Net income |  | $ | 1,692 |  |  | $ | 1,784 |  |  | $ | 426 |  |  | $ | 4,696 |  |  | $ | (6,814 | ) |  | $ | 1,784 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial gain and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Other comprehensive income |  | — |  |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Comprehensive income |  | 1,692 |  |  | 1,784 |  |  | 426 |  |  | 4,739 |  |  | (6,814 | ) |  | 1,827 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 92 |  |  | — |  |  | — |  |  | — |  |  | 92 |  |
| Comprehensive income attributable to common stock |  | $ | 1,692 |  |  | $ | 1,692 |  |  | $ | 426 |  |  | $ | 4,739 |  |  | $ | (6,814 | ) |  | $ | 1,735 |  |

[0001730168-18-000084:notes:13]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Year Ended |
|  |  | October 30, 2016 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Net revenue |  | $ | — |  |  | $ | — |  |  | $ | 402 |  |  | $ | 12,838 |  |  | $ | — |  |  | $ | 13,240 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 353 |  |  | 55 |  |  | (408 | ) |  | — |  |
| Total revenue |  | — |  |  | — |  |  | 755 |  |  | 12,893 |  |  | (408 | ) |  | 13,240 |  |
| Cost of products sold: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 237 |  |  | 5,058 |  |  | — |  |  | 5,295 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | (149 | ) |  | 557 |  |  | (408 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 15 |  |  | 1,170 |  |  | — |  |  | 1,185 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 14 |  |  | 749 |  |  | — |  |  | 763 |  |
| Restructuring charges |  | — |  |  | — |  |  | 36 |  |  | 21 |  |  | — |  |  | 57 |  |
| Total cost of products sold |  | — |  |  | — |  |  | 153 |  |  | 7,555 |  |  | (408 | ) |  | 7,300 |  |
| Gross margin |  | — |  |  | — |  |  | 602 |  |  | 5,338 |  |  | — |  |  | 5,940 |  |
| Research and development |  | — |  |  | — |  |  | 1,237 |  |  | 1,437 |  |  | — |  |  | 2,674 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | (1,337 | ) |  | 1,337 |  |  | — |  |  | — |  |
| Selling, general and administrative |  | — |  |  | 41 |  |  | 254 |  |  | 511 |  |  | — |  |  | 806 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 82 |  |  | 1,791 |  |  | — |  |  | 1,873 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 309 |  |  | 687 |  |  | — |  |  | 996 |  |
| Total operating expenses |  | — |  |  | 41 |  |  | 545 |  |  | 5,763 |  |  | — |  |  | 6,349 |  |
| Operating income (loss) |  | — |  |  | (41 | ) |  | 57 |  |  | (425 | ) |  | — |  |  | (409 | ) |
| Interest expense |  | — |  |  | — |  |  | (312 | ) |  | (273 | ) |  | — |  |  | (585 | ) |
| Intercompany interest expense |  | — |  |  | (3 | ) |  | (262 | ) |  | (3 | ) |  | 268 |  |  | — |  |
| Loss on extinguishment of debt |  | — |  |  | — |  |  | (113 | ) |  | (10 | ) |  | — |  |  | (123 | ) |
| Other income (expense), net |  | — |  |  | — |  |  | (27 | ) |  | 37 |  |  | — |  |  | 10 |  |
| Intercompany interest income |  | — |  |  | 1 |  |  | 2 |  |  | 265 |  |  | (268 | ) |  | — |  |
| Intercompany other income (expense), net |  | — |  |  | 753 |  |  | (277 | ) |  | (476 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | — |  |  | 710 |  |  | (932 | ) |  | (885 | ) |  | — |  |  | (1,107 | ) |
| Provision for income taxes |  | — |  |  | — |  |  | 447 |  |  | 195 |  |  | — |  |  | 642 |  |
| Income (loss) from continuing operations before loss from subsidiaries |  | — |  |  | 710 |  |  | (1,379 | ) |  | (1,080 | ) |  | — |  |  | (1,749 | ) |
| Loss from subsidiaries |  | (1,739 | ) |  | (2,571 | ) |  | (1,034 | ) |  | (2,221 | ) |  | 7,565 |  |  | — |  |
| Loss from continuing operations and loss in subsidiaries |  | (1,739 | ) |  | (1,861 | ) |  | (2,413 | ) |  | (3,301 | ) |  | 7,565 |  |  | (1,749 | ) |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (158 | ) |  | 46 |  |  | — |  |  | (112 | ) |
| Net loss |  | (1,739 | ) |  | (1,861 | ) |  | (2,571 | ) |  | (3,255 | ) |  | 7,565 |  |  | (1,861 | ) |
| Net loss attributable to noncontrolling interest |  | — |  |  | (122 | ) |  | — |  |  | — |  |  | — |  |  | (122 | ) |
| Net loss attributable to common stock |  | $ | (1,739 | ) |  | $ | (1,739 | ) |  | $ | (2,571 | ) |  | $ | (3,255 | ) |  | $ | 7,565 |  |  | $ | (1,739 | ) |
| Net loss |  | $ | (1,739 | ) |  | $ | (1,861 | ) |  | $ | (2,571 | ) |  | $ | (3,255 | ) |  | $ | 7,565 |  |  | $ | (1,861 | ) |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | — |  |  | (61 | ) |  | — |  |  | (61 | ) |
| Other comprehensive loss |  | — |  |  | — |  |  | — |  |  | (61 | ) |  | — |  |  | (61 | ) |
| Comprehensive loss |  | (1,739 | ) |  | (1,861 | ) |  | (2,571 | ) |  | (3,316 | ) |  | 7,565 |  |  | (1,922 | ) |
| Comprehensive loss attributable to noncontrolling interest |  | — |  |  | (122 | ) |  | — |  |  | — |  |  | — |  |  | (122 | ) |
| Comprehensive loss attributable to common stock |  | $ | (1,739 | ) |  | $ | (1,739 | ) |  | $ | (2,571 | ) |  | $ | (3,316 | ) |  | $ | 7,565 |  |  | $ | (1,800 | ) |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001730168-18-000084:notes:14]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| ASSETS |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | 6 |  |  | $ | 2,461 |  |  | $ | 1,825 |  |  | $ | — |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 3,325 |  |  | — |  |  | 3,325 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,124 |  |  | — |  |  | 1,124 |  |
| Intercompany receivable |  | 56 |  |  | 40 |  |  | 182 |  |  | 103 |  |  | (381 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 46 |  |  | 9,780 |  |  | 4,667 |  |  | (14,493 | ) |  | — |  |
| Other current assets |  | 52 |  |  | — |  |  | 37 |  |  | 277 |  |  | — |  |  | 366 |  |
| Total current assets |  | 108 |  |  | 92 |  |  | 12,460 |  |  | 11,321 |  |  | (14,874 | ) |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 772 |  |  | 1,863 |  |  | — |  |  | 2,635 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 25,553 |  |  | — |  |  | 26,913 |  |
| Intangible assets, net |  | — |  |  | — |  |  | 84 |  |  | 10,678 |  |  | — |  |  | 10,762 |  |
| Investment in subsidiaries |  | 35,268 |  |  | 35,271 |  |  | 46,745 |  |  | 35,268 |  |  | (152,552 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | — |  |  | 991 |  |  | (991 | ) |  | — |  |
| Other long-term assets |  | — |  |  | — |  |  | 250 |  |  | 457 |  |  | — |  |  | 707 |  |
| Total assets |  | $ | 35,376 |  |  | $ | 35,363 |  |  | $ | 61,671 |  |  | $ | 86,131 |  |  | $ | (168,417 | ) |  | $ | 50,124 |  |
| LIABILITIES AND EQUITY |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 19 |  |  | $ | — |  |  | $ | 44 |  |  | $ | 748 |  |  | $ | — |  |  | $ | 811 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 272 |  |  | 443 |  |  | — |  |  | 715 |  |
| Intercompany payable |  | 9 |  |  | 93 |  |  | 58 |  |  | 221 |  |  | (381 | ) |  | — |  |
| Intercompany loan payable |  | 8,691 |  |  | — |  |  | 4,713 |  |  | 1,089 |  |  | (14,493 | ) |  | — |  |
| Other current liabilities |  | — |  |  | 2 |  |  | 219 |  |  | 591 |  |  | — |  |  | 812 |  |
| Total current liabilities |  | 8,719 |  |  | 95 |  |  | 5,306 |  |  | 3,092 |  |  | (14,874 | ) |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | — |  |  | 17,456 |  |  | 37 |  |  | — |  |  | 17,493 |  |
| Deferred tax liabilities |  | — |  |  | — |  |  | (47 | ) |  | 216 |  |  | — |  |  | 169 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | 991 |  |  | — |  |  | (991 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 2,563 |  |  | 525 |  |  | — |  |  | 3,088 |  |
| Other long-term liabilities |  | — |  |  | — |  |  | 131 |  |  | 248 |  |  | — |  |  | 379 |  |
| Total liabilities |  | 8,719 |  |  | 95 |  |  | 26,400 |  |  | 4,118 |  |  | (15,865 | ) |  | 23,467 |  |
| Total Broadcom Inc. stockholders’ equity |  | 26,657 |  |  | 35,268 |  |  | 35,271 |  |  | 82,013 |  |  | (152,552 | ) |  | 26,657 |  |
| Total liabilities and equity |  | $ | 35,376 |  |  | $ | 35,363 |  |  | $ | 61,671 |  |  | $ | 86,131 |  |  | $ | (168,417 | ) |  | $ | 50,124 |  |

[0001730168-18-000084:notes:15]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | October 29, 2017 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| ASSETS |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | 194 |  |  | $ | 7,555 |  |  | $ | 3,455 |  |  | $ | — |  |  | $ | 11,204 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 2,448 |  |  | — |  |  | 2,448 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,447 |  |  | — |  |  | 1,447 |  |
| Intercompany receivable |  | — |  |  | 32 |  |  | 279 |  |  | 309 |  |  | (620 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 28 |  |  | 1,891 |  |  | 8,849 |  |  | (10,768 | ) |  | — |  |
| Other current assets |  | — |  |  | — |  |  | 350 |  |  | 374 |  |  | — |  |  | 724 |  |
| Total current assets |  | — |  |  | 254 |  |  | 10,075 |  |  | 16,882 |  |  | (11,388 | ) |  | 15,823 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 207 |  |  | 2,392 |  |  | — |  |  | 2,599 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 23,346 |  |  | — |  |  | 24,706 |  |
| Intangible assets, net |  | — |  |  | — |  |  | — |  |  | 10,832 |  |  | — |  |  | 10,832 |  |
| Investment in subsidiaries |  | 20,285 |  |  | 23,112 |  |  | 7,709 |  |  | 22,776 |  |  | (73,882 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 41,547 |  |  | — |  |  | (41,547 | ) |  | — |  |
| Other long-term assets |  | — |  |  | — |  |  | 213 |  |  | 245 |  |  | — |  |  | 458 |  |
| Total assets |  | $ | 20,285 |  |  | $ | 23,366 |  |  | $ | 61,111 |  |  | $ | 76,473 |  |  | $ | (126,817 | ) |  | $ | 54,418 |  |
| LIABILITIES AND EQUITY |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | — |  |  | $ | 7 |  |  | $ | 72 |  |  | $ | 1,026 |  |  | $ | — |  |  | $ | 1,105 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 274 |  |  | 352 |  |  | — |  |  | 626 |  |
| Current portion of long-term debt |  | — |  |  | — |  |  | 117 |  |  | — |  |  | — |  |  | 117 |  |
| Intercompany payable |  | — |  |  | 123 |  |  | 186 |  |  | 311 |  |  | (620 | ) |  | — |  |
| Intercompany loan payable |  | — |  |  | 50 |  |  | 8,799 |  |  | 1,919 |  |  | (10,768 | ) |  | — |  |
| Other current liabilities |  | — |  |  | — |  |  | 254 |  |  | 427 |  |  | — |  |  | 681 |  |
| Total current liabilities |  | — |  |  | 180 |  |  | 9,702 |  |  | 4,035 |  |  | (11,388 | ) |  | 2,529 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | — |  |  | 17,431 |  |  | — |  |  | — |  |  | 17,431 |  |
| Deferred tax liabilities |  | — |  |  | — |  |  | 10,293 |  |  | (274 | ) |  | — |  |  | 10,019 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | — |  |  | 41,547 |  |  | (41,547 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 497 |  |  | 514 |  |  | — |  |  | 1,011 |  |
| Other long-term liabilities |  | — |  |  | — |  |  | 76 |  |  | 166 |  |  | — |  |  | 242 |  |
| Total liabilities |  | — |  |  | 180 |  |  | 37,999 |  |  | 45,988 |  |  | (52,935 | ) |  | 31,232 |  |
| Total Broadcom Inc. stockholders’ equity |  | 20,285 |  |  | 20,285 |  |  | 23,112 |  |  | 30,485 |  |  | (73,882 | ) |  | 20,285 |  |
| Noncontrolling interest |  | — |  |  | 2,901 |  |  | — |  |  | — |  |  | — |  |  | 2,901 |  |
| Total liabilities and equity |  | $ | 20,285 |  |  | $ | 23,366 |  |  | $ | 61,111 |  |  | $ | 76,473 |  |  | $ | (126,817 | ) |  | $ | 54,418 |  |


## srt:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001730168-18-000084:notes:16]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,259 |  |  | $ | 12,807 |  |  | $ | 12,654 |  |  | $ | 18,757 |  |  | $ | (43,867 | ) |  | $ | 12,610 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (12,323 | ) |  | (12,926 | ) |  | (12,906 | ) |  | (9,671 | ) |  | 44,096 |  |  | (3,730 | ) |
| Net cash provided by (used in) operating activities |  | (64 | ) |  | (119 | ) |  | (252 | ) |  | 9,086 |  |  | 229 |  |  | 8,880 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | (102 | ) |  | (9,099 | ) |  | (3,002 | ) |  | 12,203 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | 1,521 |  |  | — |  |  | 1,521 |  |  | (3,042 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | (19 | ) |  | 2,637 |  |  | (164 | ) |  | (2,454 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (4,800 | ) |  | — |  |  | (4,800 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 773 |  |  | — |  |  | 773 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (196 | ) |  | (497 | ) |  | 58 |  |  | (635 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 55 |  |  | 242 |  |  | (58 | ) |  | 239 |  |
| Purchases of investments |  | — |  |  | — |  |  | (50 | ) |  | (199 | ) |  | — |  |  | (249 | ) |
| Proceeds from sales and maturities of investments |  | — |  |  | — |  |  | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Other |  | — |  |  | — |  |  | (50 | ) |  | (6 | ) |  | — |  |  | (56 | ) |
| Net cash provided by (used in) investing activities |  | — |  |  | 1,400 |  |  | (6,649 | ) |  | (6,132 | ) |  | 6,707 |  |  | (4,674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | — |  |  | 3,231 |  |  | 9,201 |  |  | (12,432 | ) |  | — |  |
| Dividend and distribution payments |  | (1,477 | ) |  | (1,521 | ) |  | (1,521 | ) |  | (1,521 | ) |  | 3,042 |  |  | (2,998 | ) |
| Net intercompany borrowings |  | 8,690 |  |  | (50 | ) |  | 261 |  |  | (11,355 | ) |  | 2,454 |  |  | — |  |
| Repayment of debt |  | — |  |  | — |  |  | (117 | ) |  | (856 | ) |  | — |  |  | (973 | ) |
| Repurchase of common stock |  | (7,258 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (7,258 | ) |
| Issuance of common stock, net of shares withheld for employee taxes |  | 109 |  |  | 102 |  |  | (20 | ) |  | (35 | ) |  | — |  |  | 156 |  |
| Payment of capital lease obligations |  | — |  |  | — |  |  | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Other |  | — |  |  | — |  |  | (27 | ) |  | 3 |  |  | — |  |  | (24 | ) |
| Net cash provided by (used in) financing activities |  | 64 |  |  | (1,469 | ) |  | 1,807 |  |  | (4,584 | ) |  | (6,936 | ) |  | (11,118 | ) |
| Net change in cash and cash equivalents |  | — |  |  | (188 | ) |  | (5,094 | ) |  | (1,630 | ) |  | — |  |  | (6,912 | ) |
| Cash and cash equivalents at beginning of period |  | — |  |  | 194 |  |  | 7,555 |  |  | 3,455 |  |  | — |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 6 |  |  | $ | 2,461 |  |  | $ | 1,825 |  |  | $ | — |  |  | $ | 4,292 |  |

[0001730168-18-000084:notes:17]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | October 29, 2017 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,692 |  |  | $ | 1,784 |  |  | $ | 426 |  |  | $ | 4,696 |  |  | $ | (6,814 | ) |  | $ | 1,784 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (1,692 | ) |  | (1,980 | ) |  | 2,282 |  |  | (822 | ) |  | 6,979 |  |  | 4,767 |  |
| Net cash provided by (used in) operating activities |  | — |  |  | (196 | ) |  | 2,708 |  |  | 3,874 |  |  | 165 |  |  | 6,551 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | (40 | ) |  | — |  |  | (40 | ) |  | 80 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | 1,834 |  |  | — |  |  | 1,858 |  |  | (3,692 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | 410 |  |  | (286 | ) |  | 5,664 |  |  | (5,788 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (254 | ) |  | (841 | ) |  | 26 |  |  | (1,069 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 25 |  |  | 442 |  |  | (26 | ) |  | 441 |  |
| Purchases of investments |  | — |  |  | — |  |  | (200 | ) |  | (7 | ) |  | — |  |  | (207 | ) |
| Proceeds from sales and maturities of investments |  | — |  |  | — |  |  | 200 |  |  | — |  |  | — |  |  | 200 |  |
| Other |  | — |  |  | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net cash provided by (used in) investing activities |  | — |  |  | 2,204 |  |  | (515 | ) |  | 7,037 |  |  | (9,400 | ) |  | (674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | — |  |  | 205 |  |  | 40 |  |  | (245 | ) |  | — |  |
| Dividend and distribution payments |  | — |  |  | (1,745 | ) |  | (1,834 | ) |  | (1,858 | ) |  | 3,692 |  |  | (1,745 | ) |
| Net intercompany borrowings |  | — |  |  | (379 | ) |  | (5,797 | ) |  | 388 |  |  | 5,788 |  |  | — |  |
| Proceeds from issuance of long-term debt |  | — |  |  | — |  |  | 17,426 |  |  | — |  |  | — |  |  | 17,426 |  |
| Repayment of debt |  | — |  |  | — |  |  | (5,704 | ) |  | (7,964 | ) |  | — |  |  | (13,668 | ) |
| Payment of debt issuance costs |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | — |  |  | (24 | ) |
| Issuance of common stock, net of shares withheld for employee taxes |  | — |  |  | 257 |  |  | — |  |  | — |  |  | — |  |  | 257 |  |
| Payment of capital lease obligations |  | — |  |  | — |  |  | (2 | ) |  | (14 | ) |  | — |  |  | (16 | ) |
| Net cash provided by (used in) financing activities |  | — |  |  | (1,867 | ) |  | 4,270 |  |  | (9,408 | ) |  | 9,235 |  |  | 2,230 |  |
| Net change in cash and cash equivalents |  | — |  |  | 141 |  |  | 6,463 |  |  | 1,503 |  |  | — |  |  | 8,107 |  |
| Cash and cash equivalents at the beginning of period |  | — |  |  | 53 |  |  | 1,092 |  |  | 1,952 |  |  | — |  |  | 3,097 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 194 |  |  | $ | 7,555 |  |  | $ | 3,455 |  |  | $ | — |  |  | $ | 11,204 |  |

[0001730168-18-000084:notes:18]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | October 30, 2016 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (1,739 | ) |  | $ | (1,861 | ) |  | $ | (2,571 | ) |  | $ | (3,255 | ) |  | $ | 7,565 |  |  | $ | (1,861 | ) |
| Total adjustments to reconcile net loss to net cash provided by (used in) operating activities |  | 1,739 |  |  | 1,818 |  |  | 2,303 |  |  | 6,637 |  |  | (7,225 | ) |  | 5,272 |  |
| Net cash provided by (used in) operating activities |  | — |  |  | (43 | ) |  | (268 | ) |  | 3,382 |  |  | 340 |  |  | 3,411 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | (35 | ) |  | (7,400 | ) |  | (4,970 | ) |  | 12,405 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | 250 |  |  | 356 |  |  | 250 |  |  | (856 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | — |  |  | (102 | ) |  | (10,587 | ) |  | 10,689 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (10,965 | ) |  | 910 |  |  | — |  |  | (10,055 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 58 |  |  | 840 |  |  | — |  |  | 898 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (80 | ) |  | (643 | ) |  | — |  |  | (723 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Purchases of investments |  | — |  |  | — |  |  | — |  |  | (58 | ) |  | — |  |  | (58 | ) |
| Proceeds from sales and maturities of investments |  | — |  |  | — |  |  | 13 |  |  | 91 |  |  | — |  |  | 104 |  |
| Other |  | — |  |  | — |  |  | (2 | ) |  | (9 | ) |  | — |  |  | (11 | ) |
| Net cash provided by (used in) investing activities |  | — |  |  | 215 |  |  | (18,122 | ) |  | (14,171 | ) |  | 22,238 |  |  | (9,840 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | — |  |  | 5,310 |  |  | 7,435 |  |  | (12,745 | ) |  | — |  |
| Dividend and distribution payments |  | — |  |  | (628 | ) |  | (250 | ) |  | (728 | ) |  | 856 |  |  | (750 | ) |
| Net intercompany borrowings |  | — |  |  | 286 |  |  | 10,301 |  |  | 102 |  |  | (10,689 | ) |  | — |  |
| Proceeds from issuance of long-term debt |  | — |  |  | — |  |  | 9,551 |  |  | 9,959 |  |  | — |  |  | 19,510 |  |
| Repayment of debt |  | — |  |  | — |  |  | (5,358 | ) |  | (5,959 | ) |  | — |  |  | (11,317 | ) |
| Payment of debt issuance costs |  | — |  |  | — |  |  | (77 | ) |  | (46 | ) |  | — |  |  | (123 | ) |
| Excess tax benefits from stock-based compensation |  | — |  |  | — |  |  | 5 |  |  | 84 |  |  | — |  |  | 89 |  |
| Issuance of common stock, net of shares withheld for employee taxes |  | — |  |  | 223 |  |  | — |  |  | 72 |  |  | — |  |  | 295 |  |
| Net cash provided by (used in) financing activities |  | — |  |  | (119 | ) |  | 19,482 |  |  | 10,919 |  |  | (22,578 | ) |  | 7,704 |  |
| Net change in cash and cash equivalents |  | — |  |  | 53 |  |  | 1,092 |  |  | 130 |  |  | — |  |  | 1,275 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | — |  |  | — |  |  | 1,822 |  |  | — |  |  | 1,822 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 53 |  |  | $ | 1,092 |  |  | $ | 1,952 |  |  | $ | — |  |  | $ | 3,097 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-18-000084:notes:19]
Schedule II — Valuation and Qualifying Accounts

[0001730168-18-000084:notes:20]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (1) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 4, 2018 |  | $ | 177 |  |  | $ | 882 |  |  | $ | (908 | ) |  | $ | 151 |  |
| Fiscal year ended October 29, 2017 |  | $ | 252 |  |  | $ | 1,176 |  |  | $ | (1,251 | ) |  | $ | 177 |  |
| Fiscal year ended October 30, 2016 |  | $ | 66 |  |  | $ | 1,216 |  |  | $ | (1,030 | ) |  | $ | 252 |  |
| Other accounts receivable allowances (2) |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended November 4, 2018 |  | $ | 31 |  |  | $ | 116 |  |  | $ | (135 | ) |  | $ | 12 |  |
| Fiscal year ended October 29, 2017 |  | $ | 40 |  |  | $ | 49 |  |  | $ | (58 | ) |  | $ | 31 |  |
| Fiscal year ended October 30, 2016 |  | $ | 9 |  |  | $ | 142 |  |  | $ | (111 | ) |  | $ | 40 |  |
| Income tax valuation allowances (3) |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended November 4, 2018 |  | $ | 1,447 |  |  | $ | 314 |  |  | $ | (414 | ) |  | $ | 1,347 |  |
| Fiscal year ended October 29, 2017 |  | $ | 1,003 |  |  | $ | 460 |  |  | $ | (16 | ) |  | $ | 1,447 |  |
| Fiscal year ended October 30, 2016 |  | $ | 147 |  |  | $ | 882 |  |  | $ | (26 | ) |  | $ | 1,003 |  |

[0001730168-18-000084:notes:21]
_______________________________________

[0001730168-18-000084:notes:22]
| (1) | Distributor credit allowances relate to price adjustments and other allowances. |

[0001730168-18-000084:notes:23]
| (2) | Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts. |

[0001730168-18-000084:notes:24]
| (3) | The decrease in the fiscal year 2018 valuation allowance resulted from restructuring activities offset by increases due to the Brocade Merger and in foreign deferred tax assets arising from foreign credits and losses not expected to be realized. The increase in the fiscal year 2017 valuation allowances resulted from foreign deferred tax assets arising from foreign losses not expected to be realized. |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001730168-18-000084:notes:25]
On November 17, 2017, we acquired Brocade Communications Systems, Inc., or Brocade. On February 1, 2016, we acquired Broadcom Corporation, or BRCM. The accompanying consolidated financial statements include the results of operations of Brocade and BRCM commencing as of their respective acquisition dates.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001730168-18-000084:notes:26]
|  |  | Fiscal Year |
|  |  | 2016 |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 15,281 |  |
| Pro forma net loss attributable to common stock |  | $ | (1,291 | ) |

[0001730168-18-000084:notes:27]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |
| Pro forma net revenue |  | $ | 20,978 |  |  | $ | 19,441 |  |
| Pro forma net income attributable to common stock |  | $ | 12,408 |  |  | $ | 986 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-18-000084:notes:28]
Acquisitions

[0001730168-18-000084:notes:29]
Acquisition of Brocade

[0001730168-18-000084:notes:30]
On November 17, 2017, or the Brocade Acquisition Date, we acquired Brocade, or the Brocade Merger. Brocade was a supplier of networking hardware, software and services, including Fibre Channel Storage Area Network, or FC SAN, solutions and Internet Protocol Networking, or IP Networking, solutions. We acquired Brocade to enhance our position as a provider of enterprise storage connectivity solutions, broaden our portfolio for enterprise storage, and to increase our ability to address the evolving needs of our original equipment manufacturer, or OEM, customers. We financed the Brocade Merger with a portion of the net proceeds from the issuance of the 2017 Senior Notes, as defined and discussed in further detail in Note 8. “Borrowings,” as well as with cash on hand.

[0001730168-18-000084:notes:31]
Purchase Consideration

[0001730168-18-000084:notes:32]
|  |  | (In millions) |
| Cash paid for outstanding Brocade common stock |  | $ | 5,298 |  |
| Cash paid by Broadcom to retire Brocade’s term loan |  | 701 |  |
| Cash paid for Brocade equity awards |  | 31 |  |
| Fair value of partially vested assumed equity awards |  | 8 |  |
| Total purchase consideration |  | 6,038 |  |
| Less: cash acquired |  | 1,250 |  |
| Total purchase consideration, net of cash acquired |  | $ | 4,788 |  |

[0001730168-18-000084:notes:33]
We assumed all unvested Brocade stock options, RSUs and performance stock units, or PSUs, held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of Brocade employees represents a component of the total consideration as presented above. All vested in-the-money Brocade stock options, after giving effect to any acceleration, were cashed out upon the completion of the Brocade Merger. RSUs and PSUs were valued based on our share price as of the Brocade Acquisition Date.

[0001730168-18-000084:notes:34]
The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-18-000084:notes:35]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,297 |  |
| Goodwill |  | 2,187 |  |
| Intangible assets |  | 3,396 |  |
| Other long-term assets |  | 82 |  |
| Total assets acquired |  | 6,962 |  |
| Current portion of long-term debt |  | (856 | ) |
| Other current liabilities |  | (374 | ) |
| Long-term debt |  | (38 | ) |
| Other long-term liabilities |  | (906 | ) |
| Total liabilities assumed |  | (2,174 | ) |
| Fair value of net assets acquired |  | $ | 4,788 |  |

[0001730168-18-000084:notes:36]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Brocade business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Brocade Merger. Goodwill is not deductible for tax purposes.

[0001730168-18-000084:notes:37]
Current assets included assets held-for-sale related to Brocade’s IP Networking business, which was not aligned with our strategic objectives. On December 1, 2017, we sold this business to ARRIS International plc, or ARRIS, for cash consideration of $800 million, before contractual working capital adjustments. In connection with this sale, we indemnified ARRIS for $116 million of potential income tax liabilities. We provided transitional services as short-term assistance to ARRIS in assuming the operations of the purchased business. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-18-000084:notes:38]
Current assets also included assets held-for-sale for Brocade’s headquarters, which was sold for $224 million during fiscal year 2018, for no gain or loss.

[0001730168-18-000084:notes:39]
Our results of continuing operations for fiscal year 2018 included $1,780 million of net revenue attributable to Brocade. It is impracticable to determine the effect on net income attributable to Brocade as we have integrated a substantial portion of Brocade into our ongoing operations. The results of operations of Brocade were primarily included in our enterprise storage segment. Transaction costs of $29 million related to the Brocade Merger were included in selling, general and administrative expense for fiscal year 2018.

[0001730168-18-000084:notes:40]
Developed technology relates to products for FC SAN applications. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-18-000084:notes:41]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Brocade. Customer contracts and related relationships were valued using the distributor method and the with-and-without-method under the income approach. The distributor method determines the fair value by measuring the economic profits generated by an intermediary, which in our case represents OEM customers. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. In both instances, the economic useful life was determined based on historical customer turnover rates.

[0001730168-18-000084:notes:42]
Trade name relates to the “Brocade” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-18-000084:notes:43]
The fair value of IPR&D was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-18-000084:notes:44]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Brocade Acquisition Date.

[0001730168-18-000084:notes:45]
The following table summarizes the details of IPR&D by category at the Brocade Acquisition Date:

[0001730168-18-000084:notes:46]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Directors |  | $ | 64 |  |  | 72 | % |  | $ | 45 |  |  | 2019 |
| Switches |  | $ | 50 |  |  | 81 | % |  | $ | 21 |  |  | 2018 |
| Embedded |  | $ | 31 |  |  | 74 | % |  | $ | 22 |  |  | 2019 |
| Networking software |  | $ | 10 |  |  | 73 | % |  | $ | 27 |  |  | 2018 |

[0001730168-18-000084:notes:47]
A discount rate of 11% was applied to the projected cash flows to reflect the risk related to these IPR&D projects. The discount rate represents a premium of 1% over the weighted-average cost of capital to reflect the higher risk and uncertainty of the cash flows for IPR&D relative to the overall businesses.

[0001730168-18-000084:notes:48]
Unaudited Pro Forma Information

[0001730168-18-000084:notes:49]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if Brocade had been acquired as of the beginning of fiscal year 2017. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2017 or of the results of our future operations of the combined business.

[0001730168-18-000084:notes:50]
Acquisition of Broadcom Corporation

[0001730168-18-000084:notes:51]
On February 1, 2016, or the Broadcom Acquisition Date, we acquired BRCM, or the Broadcom Merger, for aggregate consideration, consisting of both cash and equity consideration, of approximately $28,758 million, net of cash acquired.

[0001730168-18-000084:notes:52]
We funded the cash portion of the Broadcom Merger with the net proceeds from the issuance of the term loan facilities provided for under our guaranteed, collateralized credit agreement entered into on February 1, 2016, or the 2016 Credit Agreement, as well as cash on hand of the combined companies. The 2016 Credit Agreement provided for a Term A loan facility in the aggregate principal amount of $4,400 million, a Term B-1 dollar loan facility in the aggregate principal amount of $9,750 million, or the Term B-1 Loan, a Term B-1 euro loan facility in the aggregate principal amount of €900 million, equivalent to $978 million as of February 1, 2016, and a Term B-2 loan facility in the aggregate principal amount of $500 million.

[0001730168-18-000084:notes:53]
BRCM was a leader in semiconductor solutions for wired and wireless communications and provided a broad portfolio of highly-integrated system-on-a-chip solutions that seamlessly deliver voice, video, data and multimedia connectivity in the home, office and mobile environments. We acquired BRCM to position us as a global diversified leader in wired and wireless communication semiconductors, to deepen our broad portfolios, and to enable us to better address the evolving needs of customers across the wired and wireless end markets.

[0001730168-18-000084:notes:54]
|  |  | (In millions) |
| Cash for outstanding BRCM common stock |  | $ | 16,798 |  |
| Fair value of Broadcom common stock issued for outstanding BRCM common stock |  | 15,438 |  |
| Fair value of Partnership LP units issued for outstanding BRCM common stock |  | 3,140 |  |
| Fair value of partially vested assumed RSU awards |  | 182 |  |
| Cash for vested BRCM equity awards |  | 137 |  |
| Effective settlement of pre-existing relationships |  | 11 |  |
| Total purchase consideration |  | 35,706 |  |
| Less: cash acquired |  | 6,948 |  |
| Total purchase consideration, net of cash acquired |  | $ | 28,758 |  |

[0001730168-18-000084:notes:55]
We issued 112 million shares of common stock and the Partnership issued 23 million Partnership LP Units, all of which are valued and presented in the above table, to former BRCM shareholders in the Broadcom Merger. Broadcom also assumed unvested RSUs originally granted by BRCM and converted them into 6 million Broadcom RSUs. The portion of the fair value of partially vested assumed RSUs associated with prior service of BRCM employees represented a component of the total consideration, as presented above, and was valued based on Broadcom’s stock price as of the Broadcom Acquisition Date.

[0001730168-18-000084:notes:56]
|  |  | Fair Value |
|  |  | (In millions) |
| Trade accounts receivable |  | $ | 669 |  |
| Inventory |  | 1,853 |  |
| Assets held-for-sale |  | 833 |  |
| Other current assets |  | 194 |  |
| Property, plant and equipment |  | 889 |  |
| Goodwill |  | 22,992 |  |
| Intangible assets |  | 14,808 |  |
| Other long-term assets |  | 121 |  |
| Total assets acquired |  | 42,359 |  |
| Accounts payable |  | (559 | ) |
| Employee compensation and benefits |  | (104 | ) |
| Current portion of long-term debt |  | (1,475 | ) |
| Other current liabilities |  | (780 | ) |
| Long-term debt |  | (139 | ) |
| Other long-term liabilities |  | (10,544 | ) |
| Total liabilities assumed |  | (13,601 | ) |
| Fair value of net assets acquired |  | $ | 28,758 |  |

[0001730168-18-000084:notes:57]
Goodwill is primarily attributable to the assembled workforce, anticipated synergies and economies of scale expected from the operations of the combined company. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Broadcom Merger. Goodwill is not deductible for tax purposes.

[0001730168-18-000084:notes:58]
The assets held-for-sale represented those BRCM businesses that were not aligned with our strategic objectives. During fiscal year 2016, we sold certain BRCM businesses for aggregate cash proceeds of $830 million. In connection with these sales, we provided transitional services to the buyers as short-term assistance in assuming the operations of the purchased businesses. We do not have any material continuing involvement with these businesses and have presented their results in discontinued operations.

[0001730168-18-000084:notes:59]
Our results of continuing operations for fiscal year 2016 included $6,993 million of net revenue attributable to BRCM. It is impracticable to determine the effect on net loss attributable to BRCM for fiscal year 2016 as we immediately integrated BRCM into our ongoing operations. Transaction costs of $42 million incurred related to the Broadcom Merger were included in selling, general and administrative expense in the consolidated statements of operations for fiscal year 2016.

[0001730168-18-000084:notes:60]
Developed technology relates to products for wired and wireless communication applications. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-18-000084:notes:61]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of BRCM. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In this method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined based on historical customer turnover rates.

[0001730168-18-000084:notes:62]
Order backlog represents business under existing contractual obligations. The fair value of backlog was determined using the multi-period excess earnings method under the income approach based on expected operating cash flows from future contractual revenue. The economic useful life was determined based on the expected life of the backlog and the cash flows over the forecast period.

[0001730168-18-000084:notes:63]
Trade name relates to the “Broadcom” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This valuation method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001730168-18-000084:notes:64]
We believe the amounts of purchased intangible assets recorded above represented the fair values of, and approximated the amounts a market participant would pay for, these intangible assets.

[0001730168-18-000084:notes:65]
The following table summarizes the details of IPR&D by category as of the Broadcom Acquisition Date:

[0001730168-18-000084:notes:66]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Set-top box solutions |  | $ | 90 |  |  | 56 | % |  | $ | 90 |  |  | 2016 - 2017 |
| Broadband carrier access solutions |  | $ | 390 |  |  | 34 | % |  | $ | 376 |  |  | 2016 - 2018 |
| Carrier switch solutions |  | $ | 270 |  |  | 51 | % |  | $ | 255 |  |  | 2016 - 2019 |
| Compute and connectivity solutions |  | $ | 170 |  |  | 61 | % |  | $ | 136 |  |  | 2016 - 2018 |
| Physical layer product solutions |  | $ | 190 |  |  | 51 | % |  | $ | 71 |  |  | 2016 - 2019 |
| Wireless connectivity combo solutions |  | $ | 770 |  |  | 57 | % |  | $ | 364 |  |  | 2016 - 2018 |
| Touch controllers |  | $ | 70 |  |  | 39 | % |  | $ | 21 |  |  | 2016 - 2017 |

[0001730168-18-000084:notes:67]
Discount rates of 14% and 16% were applied to the projected cash flows to reflect the risk related to these wired and wireless IPR&D projects, respectively. These discount rates represent a premium of 2% over the respective wired and wireless weighted-average cost of capital to reflect the higher risk and uncertainty of the cash flows for IPR&D relative to the overall businesses.

[0001730168-18-000084:notes:68]
During fiscal year 2016, we wrote off $411 million of acquired IPR&D to restructuring, impairment and disposal charges as we will no longer develop and invest in these projects. The majority of these abandoned IPR&D projects related to wireless connectivity combo and broadband carrier access solutions.

[0001730168-18-000084:notes:69]
The following unaudited pro forma financial information presents combined results of operations for fiscal year 2016, as if BRCM had been acquired as of the beginning of fiscal year 2015. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of the consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2015 or of the results of future operations of the combined business.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001730168-18-000084:notes:70]
Cash and cash equivalents.  We consider all highly liquid investment securities with original or remaining maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-18-000084:notes:71]
Commitments and Contingencies

[0001730168-18-000084:notes:72]
Commitments

[0001730168-18-000084:notes:73]
The following table summarizes contractual obligations and commitments as of November 4, 2018:

[0001730168-18-000084:notes:74]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |  |  |
| Debt principal and interest |  | $ | 20,941 |  |  | $ | 566 |  |  | $ | 3,321 |  |  | $ | 1,242 |  |  | $ | 3,940 |  |  | $ | 1,366 |  |  | $ | 10,506 |  |
| Purchase commitments |  | 852 |  |  | 776 |  |  | 74 |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Other contractual commitments |  | 175 |  |  | 105 |  |  | 63 |  |  | 5 |  |  | 2 |  |  | — |  |  | — |  |
| Operating lease obligations |  | 650 |  |  | 75 |  |  | 62 |  |  | 51 |  |  | 39 |  |  | 36 |  |  | 387 |  |
| Total |  | $ | 22,618 |  |  | $ | 1,522 |  |  | $ | 3,520 |  |  | $ | 1,299 |  |  | $ | 3,982 |  |  | $ | 1,402 |  |  | $ | 10,893 |  |

[0001730168-18-000084:notes:75]
Debt Principal and Interest. Represents principal and interest on borrowings under the 2017 Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes.

[0001730168-18-000084:notes:76]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with internal fabrication facility expansion and construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-18-000084:notes:77]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, financial infrastructure outsourcing services and other service agreements.

[0001730168-18-000084:notes:78]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $233 million, $253 million and $229 million for fiscal years 2018, 2017 and 2016, respectively.

[0001730168-18-000084:notes:79]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 4, 2018, we are unable to reliably estimate the timing of cash settlement with the respective taxing authority. Therefore, $3,088 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our consolidated balance sheet as of November 4, 2018 have been excluded from the contractual obligations table above.

[0001730168-18-000084:notes:80]
Standby Letters of Credit

[0001730168-18-000084:notes:81]
As of each November 4, 2018 and October 29, 2017, we had outstanding obligations relating to standby letters of credit of $14 million and $12 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees. The fair values of the letters of credit approximate the contract amounts. The standby letters of credit generally renew annually.

[0001730168-18-000084:notes:82]
Contingencies

[0001730168-18-000084:notes:83]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other intellectual property rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. Intellectual property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing intellectual property. Claims that our products or processes infringe or misappropriate any third-party intellectual property rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our intellectual property rights. Regardless of the merit or resolution of any such litigation, complex intellectual property litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-18-000084:notes:84]
Lawsuits Relating to the Acquisition of CA, Inc.

[0001730168-18-000084:notes:85]
On August 3, 2018, a purported stockholder of CA commenced a putative class action lawsuit captioned Harvey v. CA, Inc., et al. against CA, the CA board of directors, Broadcom and Broadcom’s wholly owned subsidiary party to the merger agreement with CA in the United States District Court for the Southern District of New York. On August 9, 2018, another putative class action lawsuit captioned Vladimir Gusinsky Rev. Trust v. CA, Inc., et al. was filed against CA and the CA board of directors in the United States District Court for the District of Delaware, or Delaware District Court. On August 15, 2018, a third putative class action lawsuit captioned Jacob Scheiner Retirement Account v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court. On August 22, 2018, a fourth putative class action lawsuit captioned Kenneth Gilley v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court. The Harvey and Vladimir Gusinsky Rev. Trust complaints alleged violations of Sections 14(a) and 20(a) of the Exchange Act arising out of CA’s preliminary proxy statement relating to the CA Merger, filed with the SEC on July 24, 2018. The Scheiner Retirement Account and Gilley complaints alleged violations of Sections 14(a) and 20(a) of the Exchange Act and Rule 14a-9 promulgated thereunder arising out of CA’s definitive proxy statement relating to the CA Merger, filed with the SEC on August 10, 2018. The complaints asserted that the preliminary proxy statement or definitive proxy statement, as applicable, contain incomplete and misleading information regarding CA’s financial projections and the financial analysis performed by Qatalyst Partners, CA’s financial advisor, as well as, for the Harvey, Scheiner Retirement Account and Gilley complaints, the sales process undertaken by CA in connection with its proposed merger with Broadcom. Plaintiffs sought to enjoin the defendants from consummating the CA Merger, or, if the CA Merger is consummated, rescission and/or damages. The plaintiffs also sought costs and fees. On September 4, 2018, the parties to each of the four lawsuits reached an agreement in principle providing for a dismissal of each of the lawsuits following the CA shareholder vote with respect to the CA Merger. In connection with this agreement, CA filed a supplement to the definitive proxy statement relating to the CA Merger. On September, 24, 2018, all four lawsuits were dismissed.

[0001730168-18-000084:notes:86]
Lawsuits Relating to the Acquisition of Brocade Communications Systems, Inc.

[0001730168-18-000084:notes:87]
On December 13, 2016, December 15, 2016, December 21, 2016, January 5, 2017 and January 18, 2017, six putative class action complaints were filed in the United States District Court for the Northern District of California, or the U.S. Northern District Court, captioned Steinberg v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7081-EMC, Gross v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7173-EJD, Jha v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7270-HRL, Bragan v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7271-JSD, Chuakay v. Brocade Communications Systems, Inc., et al., No. 3:17-cv-0058-PJH, and Mathew v. Brocade Communications Systems, Inc., et al., No. 3:16-cv-7271-HSG, respectively. The Steinberg, Bragan and Mathew complaints named as defendants Brocade, the members of Brocade’s board of directors, Broadcom, BRCM and Bobcat Merger Sub, Inc. The Gross, Jha and Chuakay complaints named as defendants Brocade and the members of Brocade’s board of directors. All of the complaints asserted claims under Sections 14(a) and 20(a) of the Exchange Act and Rule 14a-9 promulgated thereunder. The complaints alleged, among other things, that the board of directors of Brocade failed to provide material information and/or omitted material information from the Preliminary Proxy Statement filed with the SEC on December 6, 2016 by Brocade. The complaints sought to enjoin the closing of the transaction between Brocade and Broadcom, as well as certain other equitable and declaratory relief and attorneys’ fees and costs. On January 10, 2017, January 27, 2017 and February 15, 2017, the U.S. Northern District Court granted motions to relate the cases, all of which were then related to the Steinberg action and before the Honorable Judge Edward Chen. On January 11, 2017, Plaintiff Jha filed a motion for a preliminary injunction, which was subsequently withdrawn on January 18, 2017. On February 6, 2017, Plaintiff Gross voluntarily dismissed the Gross action without prejudice, which was ordered by the U.S. Northern District Court on February 15, 2017. On April 14, 2017, the U.S. Northern District Court granted the Motion for Consolidation, Appointment as Lead Plaintiff and Approval of Lead Plaintiff’s Selection of Counsel filed by Plaintiff Giulio D. Cessario, a plaintiff in the Steinberg action, which consolidated these actions under the caption In re Brocade Communications Systems, Inc. Securities Litigation, Case No. 3:16-cv-07081-EMC. On December 29, 2017, Lead Plaintiff voluntarily dismissed the consolidated action without prejudice and withdrew as Lead Plaintiff. On February 16, 2018, Plaintiffs Gross, Chuakay and Jha filed a joint motion for an award of attorneys’ fees. On March 2, 2018, the defendants filed a joint opposition to the motion for attorneys’ fees. On May 3, 2018, Plaintiffs Gross, Chuakay and Jha withdrew their motion for an award of attorneys’ fees. As of May 6, 2018, all actions have been dismissed and motions withdrawn, thereby concluding all actions with respect to these lawsuits.

[0001730168-18-000084:notes:88]
Lawsuits Relating to Tessera, Inc.

[0001730168-18-000084:notes:89]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., or Tessera, and Invensas Corp., an affiliate of Tessera, or Invensas or collectively, the Complainants, filed a complaint to institute an investigation with the U.S. International Trade Commission, or the ITC. The Complainants alleged infringement by Broadcom and our subsidiaries, BRCM, Avago, and Avago Technologies U.S. Inc., or Avago U.S., or collectively, the Respondents, of three patents relating to semiconductor packaging and semiconductor manufacturing technology. The downstream respondents, which are customers of the Respondents, were Arista Networks, Inc., ARRIS International plc, ARRIS Group, Inc., ARRIS Technology, Inc., ARRIS Enterprises LLC, ARRIS Solutions, Inc., Pace Ltd., Pace Americas, LLC, Pace USA, LLC, ASUSteK Computer Inc., ASUS Computer International, Comcast Cable Communications, LLC, Comcast Cable Communications Management, LLC, Comcast Business Communications, LLC, HTC Corporation, HTC America, Inc., NETGEAR, Inc., Technicolor S.A., Technicolor USA, Inc., and Technicolor Connected Home USA LLC, or collectively, the Downstream Respondents. On July 20, 2016, the ITC instituted the investigation, or the ITC Investigation. Complainants sought the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of the Respondents' semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation and (2) a permanent cease and desist order prohibiting the Respondents and Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the Respondents' semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation.

[0001730168-18-000084:notes:90]
On May 23, 2016, Tessera and Invensas filed a complaint against BRCM in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-00379, alleging infringement of the three patents subject to the ITC Investigation. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

[0001730168-18-000084:notes:91]
On May 23, 2016, Tessera and Tessera Advanced Technologies, Inc. filed a complaint against BRCM in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-00380, alleging infringement of four patents relating to semiconductor packaging and circuit technologies. On June 19, 2016, the complaint was amended to add three more patents relating to semiconductor packaging technologies for a total of seven patents in this matter. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

[0001730168-18-000084:notes:92]
On May 23, 2016, Invensas filed a Writ of Summons against Broadcom, BRCM, Broadcom Netherlands B.V. and Broadcom Communications Netherlands B.V. in the Hague District Court in the Netherlands, Case No. L1422381, alleging infringement of a single European patent that is a foreign counterpart to one of the patents subject to the ITC Investigation, or the European Patent. The named defendants also included distributors EBV Elektronik GmbH, Arrow Central Europe GmbH, and Mouser Electronics Netherlands B.V. The requested relief included a cease-and-desist order and damages in an unspecified amount.

[0001730168-18-000084:notes:93]
On May 23, 2016, Invensas also filed a complaint against each of (i) Broadcom Germany GmbH and Broadcom‘s German distributors, Case No. 7 O 97/16, and (ii) Broadcom and BRCM, Case No. 7 O 98/16, in the Mannheim District Court in Germany, alleging infringement of the European Patent. The requested relief included damages in an unspecified amount and an injunction preventing the sale of the accused products.

[0001730168-18-000084:notes:94]
On November 7, 2016, Invensas filed a complaint against Avago, Avago U.S., Emulex Corporation, or Emulex, LSI and PLX Technology, Inc., a subsidiary of Broadcom, or PLX, in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-01033, alleging infringement of two of the patents subject to the ITC Investigation. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

[0001730168-18-000084:notes:95]
On November 7, 2016, Tessera and Invensas filed a complaint against Avago, Avago U.S., and Avago Technologies Wireless (U.S.A.) Manufacturing Inc., or AT Wireless in the U.S. District Court for the District of Delaware, Case No. 1-16-cv-01034, alleging infringement of two patents relating to semiconductor packaging technology. On January 31, 2017, Tessera and Invensas amended the complaint in this matter and added three additional patents related to semiconductor packaging technology, which were also at issue in case No. 1-16-cv-00379 pending in Delaware. The complaint sought compensatory damages in an unspecified amount, as well as an award of reasonable attorneys’ fees, interest, and costs.

[0001730168-18-000084:notes:96]
On December 18, 2017, Broadcom and its subsidiaries entered into comprehensive settlement agreements and a patent license agreement with Tessera and its affiliates resolving all outstanding litigation. Pursuant to the agreements between the parties, the ITC investigation was terminated, and all of the other litigations were dismissed, thereby concluding all actions with respect to these matters.

[0001730168-18-000084:notes:97]
Lawsuits Relating to the Acquisition of Emulex

[0001730168-18-000084:notes:98]
On March 3, 2015, two putative stockholder class action complaints were filed in the Court of Chancery of the State of Delaware, or the Delaware Court of Chancery, against Emulex, its directors, AT Wireless, and Emerald Merger Sub, Inc., or Emerald Merger Sub, captioned as follows: James Tullman v. Emulex Corporation, et al., Case No. 10743-VCL (Del. Ch.); Moshe Silver ACF/Yehudit Silver U/NY/UTMA v. Emulex Corporation, et al., Case No. 10744-VCL (Del. Ch.). On March 11, 2015, a third complaint was filed in the Delaware Court of Chancery, captioned Hoai Vu v. Emulex Corporation, et al., Case No. 10776-VCL (Del. Ch.). The complaints alleged, among other things, that Emulex’s directors breached their fiduciary duties by approving the Agreement and Plan of Merger, dated February 25, 2015, by and among AT Wireless, Emerald Merger Sub and Emulex and that AT Wireless and Emerald Merger Sub aided and abetted these alleged breaches of fiduciary duty. The complaints sought, among other things, either to enjoin the transaction or to rescind it following its completion, as well as damages, including attorneys’ and experts’ fees. The Delaware Court of Chancery has entered an order consolidating the three Delaware actions under the caption In re Emulex Corporation Stockholder Litigation, Consolidated C.A. No. 10743-VCL. On May 5, 2015, we completed our acquisition of Emulex. On June 5, 2015, the Court of Chancery dismissed the consolidated action without prejudice.

[0001730168-18-000084:notes:99]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc.  On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court. We believe these claims are all without merit and intend to vigorously defend these actions.

[0001730168-18-000084:notes:100]
Other Matters

[0001730168-18-000084:notes:101]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-18-000084:notes:102]
Contingency Assessment

[0001730168-18-000084:notes:103]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, taken individually or as a whole, will have a material adverse effect on our financial condition, results of operations or cash flows. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-18-000084:notes:104]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our results of operations, financial position or cash flows.

[0001730168-18-000084:notes:105]
Other Indemnifications

[0001730168-18-000084:notes:106]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for intellectual property claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-18-000084:notes:107]
Condensed Consolidating Financial Information

[0001730168-18-000084:notes:108]
The 2017 Senior Notes, which are discussed in further detail in Note 8. “Borrowings”, are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by the Guarantors, subject to certain release conditions described in the respective Indentures and below.

[0001730168-18-000084:notes:109]
The guarantee by Broadcom will be automatically and unconditionally released (solely in the case of clauses (1) or (2) below) in the events of (1) sale, exchange, disposition or other transfer of all or substantially all of Guarantors’ assets, (2) the Issuers’ exercise of their legal defeasance option or covenant defeasance options or if the Issuers’ obligations under the indenture are satisfied and discharged or (3) release of obligations under the 2017 Senior Notes. The Parent Guarantor’s guarantee may also be released under other circumstances described in the Indentures.

[0001730168-18-000084:notes:110]
The following information sets forth the condensed consolidating financial information as of November 4, 2018 and October 29, 2017 and for the fiscal years ended November 4, 2018, October 29, 2017 and October 30, 2016 for the Parent Guarantor, Subsidiary Guarantor, Subsidiary Issuers, and non-guarantor subsidiaries. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor and all of our guarantor and non-guarantor subsidiaries are reflected in the eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.


## us-gaap:DebtDisclosureTextBlock

[0001730168-18-000084:notes:111]
Borrowings

[0001730168-18-000084:notes:112]
|  |  | Effective Interest Rate |  | November 4, 2018 |  | October 29, 2017 |
|  |  |  |  | (In millions) |
| 2017 Senior Notes |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | $ | 2,750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |
| 2.70% notes due November 2018 |  | 2.700 | % |  | — |  |  | 117 |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
|  |  |  |  | 22 |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,609 |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (116 | ) |  | (141 | ) |
| Carrying value of debt |  |  |  | $ | 17,493 |  |  | $ | 17,548 |  |

[0001730168-18-000084:notes:113]
2017 Senior Notes

[0001730168-18-000084:notes:114]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, or together with BRCM referred to as the Subsidiary Issuers, issued $17,550 million of senior unsecured notes, or the 2017 Senior Notes. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom-Singapore and the Partnership, subject to certain release conditions described in the indenture governing the 2017 Senior Notes, or the 2017 Indentures. On April 9, 2018, Broadcom, or Parent Guarantor, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. At that time, Broadcom-Singapore, a guarantor at the issuance of the 2017 Senior Notes, became an indirect wholly-owned subsidiary of Broadcom and a subsidiary guarantor, or Subsidiary Guarantor, together with Parent Guarantor referred to as the Guarantors. In addition, the Partnership was released from its guarantee of the 2017 Senior Notes under each of the 2017 Indentures in accordance with their terms. Each series of 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year. As of November 4, 2018 and October 29, 2017, we accrued interest payable of $165 million and $136 million, respectively.

[0001730168-18-000084:notes:115]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of the Parent Guarantor, the Subsidiary Issuers and the Subsidiary Guarantor to merge, consolidate or sell all or substantially all of their assets.

[0001730168-18-000084:notes:116]
During fiscal year 2018, substantially all of the 2017 Senior Notes were tendered and exchanged for notes registered with the U.S. Securities and Exchange Commission, or SEC, with substantially identical terms.

[0001730168-18-000084:notes:117]
We were in compliance with all of the covenants related to the 2017 Senior Notes as of November 4, 2018.

[0001730168-18-000084:notes:118]
Assumed BRCM Senior Notes

[0001730168-18-000084:notes:119]
As a result of the Broadcom Merger, we assumed $1,614 million of BRCM’s outstanding senior unsecured notes, or the Assumed BRCM Senior Notes, at fair value on the Broadcom Acquisition Date. During fiscal years 2018 and 2016, we repaid $117 million and $1,475 million of the Assumed BRCM Senior Notes, respectively.

[0001730168-18-000084:notes:120]
We were in compliance with all of the covenants related to the Assumed BRCM Senior Notes as of November 4, 2018.

[0001730168-18-000084:notes:121]
Assumed Brocade Debt

[0001730168-18-000084:notes:122]
As a result of the Brocade Merger, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes due 2020, or the Assumed Brocade Convertible Notes. The Brocade Merger was a “fundamental change” as well as a “make-whole fundamental change” as defined under the terms of the indenture governing the Assumed Brocade Convertible Notes. Accordingly, the holders of the Assumed Brocade Convertible Notes received the right to require us to repurchase their notes for cash. During fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. The remaining outstanding Assumed Brocade Convertible Notes are convertible into cash at a conversion rate of $812 for each $1,000 of principal. We were in compliance with all of the covenants related to the Assumed Brocade Convertible Notes as of November 4, 2018.

[0001730168-18-000084:notes:123]
We also assumed $300 million of Brocade’s 4.625% senior unsecured notes due 2023. On January 16, 2018, we redeemed all of these outstanding notes for a total payment of $308 million.

[0001730168-18-000084:notes:124]
Fair Value of Debt

[0001730168-18-000084:notes:125]
As of November 4, 2018, the estimated aggregate fair value of our borrowings was $16,627 million, which was classified as Level 2 as we used quoted prices from less active markets.

[0001730168-18-000084:notes:126]
Future Principal Payments of Debt

[0001730168-18-000084:notes:127]
The future contractual maturities of borrowings as of November 4, 2018 are as follows:

[0001730168-18-000084:notes:128]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 |  | $ | — |  |
| 2020 |  | 2,787 |  |
| 2021 |  | 750 |  |
| 2022 |  | 3,509 |  |
| 2023 |  | 1,000 |  |
| Thereafter |  | 9,563 |  |
| Total |  | $ | 17,609 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001730168-18-000084:notes:129]
Derivative instruments.  We are subject to foreign currency risks for transactions denominated in foreign currencies, primarily the Singapore Dollar, Israeli Shekel, Euro, Japanese Yen and Indian Rupee. Therefore, we enter into foreign exchange forward contracts to manage financial exposures resulting from the changes in the exchange rates of these foreign currencies. These contracts are designated at inception as hedges of the related foreign currency exposures, which include committed and forecasted revenue and expense transactions that are denominated in currencies other than the functional currency of the subsidiary which has the exposure. We exclude time value from the measurement of effectiveness. To achieve hedge accounting, contracts must reduce the foreign currency exchange rate risk otherwise inherent in the amount and duration of the hedged exposures and comply with established risk management policies; our hedging contracts generally mature within three months. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-18-000084:notes:130]
We designate our forward contracts as either cash flow or fair value hedges. All derivatives are recognized on the consolidated balance sheets at their fair values based on Level 2 inputs as defined in the fair value hierarchy. The accounting for gains and losses resulting from changes in fair value depends on the use of the derivative and whether it is designated and qualifies for hedge accounting. For derivative instruments that are designated and qualify as fair value hedges, changes in value of the instruments are recognized in income (loss) in the current period. Such hedges are recognized in net income (loss) and are offset by the changes in fair value of the underlying assets or liabilities being hedged. For derivative instruments that are designated and qualify as cash flow hedges, changes in the value of the effective portion of the derivative instrument are recognized in accumulated other comprehensive loss, a component of stockholders’ equity. These amounts are then reclassified and recognized in net income (loss) when either the forecasted transaction affects earnings or it becomes probable the forecasted transaction will not occur. Changes in the fair value of the ineffective portion of derivative instruments are recognized in net income (loss) in the current period, which have not been material to date. Changes in the value of derivative instruments not designated as hedges are recognized in other income, net, in our consolidated statements of operations.


## us-gaap:DividendsDeclaredTableTextBlock

[0001730168-18-000084:notes:131]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 7.00 |  |  | $ | 4.08 |  |  | $ | 1.94 |  |
| Cash dividends paid to stockholders |  | $ | 2,921 |  |  | $ | 1,653 |  |  | $ | 716 |  |
| Cash distributions paid to limited partners |  | $ | 77 |  |  | $ | 92 |  |  | $ | 34 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001730168-18-000084:notes:132]
Net income (loss) per share. Basic net income (loss) per share is computed by dividing net income (loss) attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested RSUs and ESPP rights (together referred to as equity awards). Diluted shares outstanding also included shares issuable upon the exchange of LP Units for fiscal year 2016. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income (loss) per share.

[0001730168-18-000084:notes:133]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and to purchase shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. For fiscal year 2016, the amount of tax benefits that would be recognized when equity awards become deductible for income tax purposes was also assumed to be used to repurchase shares.

[0001730168-18-000084:notes:134]
The dilutive effect of LP Units was calculated using the if-converted method. The if-converted method assumed that the LP Units were converted at the beginning of the reporting period and included net loss attributable to noncontrolling interest for fiscal year 2016.


## us-gaap:EarningsPerShareTextBlock

[0001730168-18-000084:notes:135]
Net Income (Loss) Per Share

[0001730168-18-000084:notes:136]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions, except per share data) |
| Numerator - Basic: |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 12,629 |  |  | $ | 1,790 |  |  | $ | (1,749 | ) |
| Less: Income (loss) from continuing operations attributable to noncontrolling interest |  | 352 |  |  | 92 |  |  | (116 | ) |
| Income (loss) from continuing operations attributable to common stock |  | 12,277 |  |  | 1,698 |  |  | (1,633 | ) |
| Loss from discontinued operations, net of income taxes |  | (19 | ) |  | (6 | ) |  | (112 | ) |
| Less: Loss from discontinued operations, net of income taxes, attributable to noncontrolling interest |  | (1 | ) |  | — |  |  | (6 | ) |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (18 | ) |  | (6 | ) |  | (106 | ) |
| Net income (loss) attributable to common stock |  | $ | 12,259 |  |  | $ | 1,692 |  |  | $ | (1,739 | ) |
| Numerator - Diluted: |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 12,277 |  |  | $ | 1,698 |  |  | $ | (1,749 | ) |
| Loss from discontinued operations, net of income taxes |  | (18 | ) |  | (6 | ) |  | (112 | ) |
| Net income (loss) |  | $ | 12,259 |  |  | $ | 1,692 |  |  | $ | (1,861 | ) |

[0001730168-18-000084:notes:137]
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 418 |  |  | 405 |  |  | 366 |  |
| Dilutive effect of equity awards |  | 13 |  |  | 16 |  |  | — |  |
| Exchange of noncontrolling interest |  | — |  |  | — |  |  | 17 |  |
| Weighted-average shares outstanding - diluted |  | 431 |  |  | 421 |  |  | 383 |  |
| Basic income (loss) per share: |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 29.37 |  |  | $ | 4.19 |  |  | $ | (4.46 | ) |
| Loss per share from discontinued operations |  | (0.04 | ) |  | (0.01 | ) |  | (0.29 | ) |
| Net income (loss) per share |  | $ | 29.33 |  |  | $ | 4.18 |  |  | $ | (4.75 | ) |
| Diluted income (loss) per share: |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 28.48 |  |  | $ | 4.03 |  |  | $ | (4.57 | ) |
| Loss per share from discontinued operations |  | (0.04 | ) |  | (0.01 | ) |  | (0.29 | ) |
| Net income (loss) per share |  | $ | 28.44 |  |  | $ | 4.02 |  |  | $ | (4.86 | ) |
| Potentially dilutive shares excluded from the calculation of diluted income (loss) per share because their effect would have been antidilutive (a) |  | 9 |  |  | 22 |  |  | 12 |  |

[0001730168-18-000084:notes:138]
________________________________

[0001730168-18-000084:notes:139]
(a) For fiscal years 2018 and 2017, these weighted shares related to common stock shares issuable upon the exchange of LP Units prior to the effective time of the Mandatory Exchange (refer to Note 9. “Stockholders’ Equity” for additional information). As a result, diluted net income per share excluded net income attributable to noncontrolling interest. For fiscal year 2016, these weighted shares related to antidilutive equity awards.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001730168-18-000084:notes:140]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-18-000084:notes:141]
The three levels of the fair value hierarchy under the guidance for fair value measurements are described below:

[0001730168-18-000084:notes:142]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date. Our Level 1 assets include cash equivalents, banker's acceptances, trading securities investments and investment funds. We measure trading securities investments and investment funds at quoted market prices as they are traded in an active market with sufficient volume and frequency of transactions.

[0001730168-18-000084:notes:143]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-18-000084:notes:144]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Level 3 assets and liabilities include cost method investments, goodwill, intangible assets, and property, plant and equipment, which are measured at fair value using a discounted cash flow approach when they are impaired. Quantitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001730168-18-000084:notes:145]
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. As such, foreign currency assets and liabilities are remeasured into U.S. dollars at current exchange rates except for non-monetary items such as inventory and property, plant and equipment, which are remeasured at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-18-000084:notes:146]
Goodwill and Intangible Assets

[0001730168-18-000084:notes:147]
Goodwill

[0001730168-18-000084:notes:148]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Total |
|  |  | (In millions) |
| Balance as of October 30, 2016 |  | $ | 17,641 |  |  | $ | 5,952 |  |  | $ | 995 |  |  | $ | 144 |  |  | $ | 24,732 |  |
| Broadcom Merger adjustments |  | (25 | ) |  | (7 | ) |  | — |  |  | — |  |  | (32 | ) |
| Acquisitions |  | 6 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |
| Balance as of October 29, 2017 |  | 17,622 |  |  | 5,945 |  |  | 995 |  |  | 144 |  |  | 24,706 |  |
| Acquisitions |  | 83 |  |  | — |  |  | 2,117 |  |  | 7 |  |  | 2,207 |  |
| Balance as of November 4, 2018 |  | $ | 17,705 |  |  | $ | 5,945 |  |  | $ | 3,112 |  |  | $ | 151 |  |  | $ | 26,913 |  |

[0001730168-18-000084:notes:149]
During each of the fourth quarters of fiscal years 2018, 2017 and 2016, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-18-000084:notes:150]
Based on the amount of intangible assets subject to amortization at November 4, 2018, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-18-000084:notes:151]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2019 |  | $ | 2,882 |  |
| 2020 |  | 2,437 |  |
| 2021 |  | 1,945 |  |
| 2022 |  | 1,441 |  |
| 2023 |  | 650 |  |
| Thereafter |  | 1,143 |  |
| Total |  | $ | 10,498 |  |

[0001730168-18-000084:notes:152]
The weighted-average amortization periods remaining by intangible asset category were as follows:

[0001730168-18-000084:notes:153]
| Amortizable intangible assets: |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In years) |
| Purchased technology |  | 6 |  | 5 |
| Customer contracts and related relationships |  | 5 |  | 4 |
| Trade names |  | 12 |  | 13 |
| Other |  | 10 |  | 10 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-18-000084:notes:154]
Income Taxes

[0001730168-18-000084:notes:155]
Components of Income (Loss) from Continuing Operations Before Income Taxes

[0001730168-18-000084:notes:156]
As a result of the Redomiciliation Transaction on April 4, 2018, the following references to domestic activities represent the U.S. for fiscal year 2018 and Singapore for fiscal years 2017 and 2016, respectively. The following table presents the components of income (loss) from continuing operations before income taxes for financial reporting purposes:

[0001730168-18-000084:notes:157]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Domestic income (loss) |  | $ | (705 | ) |  | $ | 2,102 |  |  | $ | 1,365 |  |
| Foreign income (loss) |  | 5,250 |  |  | (277 | ) |  | (2,472 | ) |
| Income (loss) from continuing operations before income taxes |  | $ | 4,545 |  |  | $ | 1,825 |  |  | $ | (1,107 | ) |

[0001730168-18-000084:notes:158]
Components of Provision for (Benefit from) Income Taxes

[0001730168-18-000084:notes:159]
The benefit from income taxes in fiscal year 2018 was primarily due to income tax benefits recognized from the enactment of the 2017 Tax Reform Act and the Redomiciliation Transaction. The 2017 Tax Reform Act makes significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations, or the Transition Tax.

[0001730168-18-000084:notes:160]
On December 22, 2017, the SEC issued Staff Accounting Bulletin No. 118, or SAB 118, to address the application of GAAP in situations when a registrant does not have the necessary information available, prepared, or analyzed (including computations) in reasonable detail to complete the accounting for certain income tax effects of the 2017 Tax Reform Act. The benefit from income taxes below for fiscal year 2018 represents reasonable estimates of the effects of the 2017 Tax Reform Act for which our analysis is not yet complete. As we complete our analysis of the 2017 Tax Reform Act, including collecting, preparing, and analyzing necessary information, performing and refining calculations, and obtaining additional guidance from standard setting and regulatory bodies on the 2017 Tax Reform Act, we may record adjustments to our benefit from income taxes, which may be material. In accordance with SAB 118, our accounting for the tax effects of the 2017 Tax Reform Act will be completed during the measurement period, which should not extend beyond one year from the enactment date. At November 4, 2018, there were no provisions for which we were unable to record a reasonable estimate of the impact. However, all income tax effects are provisional, including accounting for global intangible low tax income and foreign derived intangible income deductions, in addition to those effects discussed below.

[0001730168-18-000084:notes:161]
As a result of the 2017 Tax Reform Act, we recorded a total provisional benefit of $7,278 million. This provisional benefit included $7,212 million related to the Transition Tax, which was primarily due to a reduction of $10,457 million in our federal deferred income tax liabilities on accumulated non-U.S. earnings, partially offset by $2,133 million of federal provisional long-term Transaction Tax payable and $1,112 million of unrecognized federal tax benefits related to the Transition Tax. The provisional benefit also included $66 million related to the remeasurement of certain deferred tax assets and liabilities, which were based on the tax rates at which they were expected to be reversed in the future as a result of the 2017 Tax Reform Act.

[0001730168-18-000084:notes:162]
Additionally, in connection with the Brocade Merger, we established $846 million of net deferred tax liabilities on the excess of book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that have not been indefinitely reinvested, partially offset by acquired tax attributes. We also recognized discrete benefits from the recognition of $181 million of excess tax benefits from stock-based awards that were vested or exercised during fiscal year 2018.

[0001730168-18-000084:notes:163]
The impact of the Redomiciliation Transaction and the related internal reorganizations included tax benefits of $1,162 million from the remeasurement of withholding taxes on undistributed earnings, partially offset by a $167 million tax provision on foreign earnings and profits subject to U.S. tax.

[0001730168-18-000084:notes:164]
The income tax provision for fiscal year 2017 was primarily due to profit before tax and a discrete expense of $76 million resulting from entity reorganizations partially offset by the recognition of $273 million of excess tax benefits from stock-based awards that vested or were exercised during fiscal year 2017 and, to a lesser extent, the recognition of previously unrecognized tax benefits primarily as a result of audit settlements.

[0001730168-18-000084:notes:165]
The income tax provision for fiscal year 2016 was primarily the result of tax associated with our undistributed earnings, partially offset by income tax benefits from losses from continuing operations and the recognition of previously unrecognized tax benefits as a result of audit settlements.

[0001730168-18-000084:notes:166]
In addition, we obtained several tax incentives from the Singapore Economic Development Board, an agency of the Government of Singapore, which provide that qualifying income earned in Singapore is subject to tax incentive or reduced rates of Singapore income tax. Each tax incentive was separate and distinct from the others, and may be granted, withheld, extended, modified, truncated, complied with or terminated independently without any effect on the other incentives. During fiscal year 2018, one of our tax incentives was no longer in effect due to reorganizations made in connection with the Redomiciliation Transaction. Subject to our compliance with the conditions specified in these incentives and legislative developments, the remaining Singapore tax incentive is presently expected to expire in fiscal year 2020, subject in certain cases to potential extensions, which we may or may not be able to obtain.

[0001730168-18-000084:notes:167]
We also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with the conditions specified, we will lose the related tax benefits and we could be required to refund previously realized material tax benefits.

[0001730168-18-000084:notes:168]
The effect of these tax incentives and tax holiday was to increase the benefit from income taxes by approximately $590 million and increase diluted net income per share by $1.37 for fiscal year 2018. For fiscal years 2017 and 2016, the effect of these tax incentives and tax holiday, in the aggregate, was to reduce the overall provision for income taxes by approximately $237 million and $169 million, respectively, increase diluted net income per share by $0.56 for fiscal year 2017, and reduce diluted net loss per share by $0.44 for fiscal year 2016.

[0001730168-18-000084:notes:169]
Significant components of the provision for (benefit from) income taxes are as follows:

[0001730168-18-000084:notes:170]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Current tax expense: |  |  |  |  |  |  |  |  |  |
| Domestic |  | $ | 293 |  |  | $ | 112 |  |  | $ | 59 |  |
| Foreign |  | 171 |  |  | 158 |  |  | 165 |  |
|  |  | 464 |  |  | 270 |  |  | 224 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |  |  |  |
| Domestic |  | (8,769 | ) |  | (1 | ) |  | 9 |  |
| Foreign |  | 221 |  |  | (234 | ) |  | 409 |  |
|  |  | (8,548 | ) |  | (235 | ) |  | 418 |  |
| Total provision for (benefit from) income taxes |  | $ | (8,084 | ) |  | $ | 35 |  |  | $ | 642 |  |

[0001730168-18-000084:notes:171]
Rate Reconciliation

[0001730168-18-000084:notes:172]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
| Statutory tax rate |  | 21.0 | % |  | 17.0 | % |  | 17.0 | % |
| 2017 Tax reform |  | (160.1 | ) |  | — |  |  | — |  |
| Withholding tax |  | (25.6 | ) |  | — |  |  | — |  |
| Foreign income taxed at different rates |  | (16.3 | ) |  | (0.8 | ) |  | (89.7 | ) |
| Excess tax benefits from stock-based compensation |  | (4.0 | ) |  | — |  |  | — |  |
| Research and development credit |  | (2.9 | ) |  | — |  |  | — |  |
| Deemed inclusion of foreign earnings |  | 4.7 |  |  | — |  |  | — |  |
| Tax holidays and concessions |  | — |  |  | (13.0 | ) |  | 15.3 |  |
| Other, net |  | 5.3 |  |  | (1.3 | ) |  | (0.6 | ) |
| Actual tax rate on income (loss) before income taxes |  | (177.9 | )% |  | 1.9 | % |  | (58.0 | )% |

[0001730168-18-000084:notes:173]
Summary of Deferred Income Taxes

[0001730168-18-000084:notes:174]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |  |  |
| Depreciation and amortization |  | $ | 7 |  |  | $ | 8 |  |
| Employee benefits |  | 119 |  |  | 145 |  |
| Employee stock awards |  | 159 |  |  | 180 |  |
| Net operating loss carryovers and credit carryovers |  | 1,421 |  |  | 2,356 |  |
| Other deferred income tax assets |  | 100 |  |  | 70 |  |
| Gross deferred income tax assets |  | 1,806 |  |  | 2,759 |  |
| Less valuation allowance |  | (1,347 | ) |  | (1,447 | ) |
| Deferred income tax assets |  | 459 |  |  | 1,312 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 316 |  |  | 96 |  |
| Other deferred income tax liabilities |  | 12 |  |  | 12 |  |
| Foreign earnings not indefinitely reinvested |  | 16 |  |  | 11,202 |  |
| Deferred income tax liabilities |  | 344 |  |  | 11,310 |  |
| Net deferred income tax assets (liabilities) |  | $ | 115 |  |  | $ | (9,998 | ) |

[0001730168-18-000084:notes:175]
Deferred income taxes reflect the net effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and their basis for income tax purposes and the tax effects of net operating losses and tax credit carryforwards. The decrease in foreign earnings not indefinitely reinvested results from the 2017 Tax Reform Act and the Redomiciliation Transaction.

[0001730168-18-000084:notes:176]
The following table presents net deferred income tax assets (liabilities) as reflected on the consolidated balance sheets:

[0001730168-18-000084:notes:177]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Other long-term assets |  | $ | 284 |  |  | $ | 21 |  |
| Other long-term liabilities |  | (169 | ) |  | (10,019 | ) |
| Net long-term income tax assets (liabilities) |  | $ | 115 |  |  | $ | (9,998 | ) |

[0001730168-18-000084:notes:178]
The decrease in the valuation allowance from $1,447 million in fiscal year 2017 to $1,347 million in fiscal year 2018 was primarily due to restructuring activities, offset by increases due to the Brocade Merger, foreign deferred tax assets arising from foreign credits, and losses not expected to be realized.

[0001730168-18-000084:notes:179]
As of November 4, 2018, we had U.S. federal net operating loss carryforwards of $120 million, U.S. state net operating loss carryforwards of $2,434 million and other foreign net operating loss carryforwards of $884 million. U.S. federal and state net operating loss carryforwards begin to expire in fiscal year 2019. The other foreign net operating losses expire in various fiscal years beginning 2019. As of November 4, 2018, we had $349 million and $1,532 million of U.S. federal and state research and development tax credits, respectively, which if not utilized, begin to expire in fiscal year 2019.

[0001730168-18-000084:notes:180]
The U.S. Tax Reform Act of 1986 limits the use of net operating loss and tax credit carryforwards in the case of an “ownership change” of a corporation or separate return loss year limitations. Any ownership changes, as defined, may restrict utilization of carryforwards. As of November 4, 2018, we had approximately $120 million and $349 million of federal net operating loss and tax credit carryforwards, respectively, in the U.S. subject to an annual limitation. We do not expect these limitations to result in any permanent loss of our tax benefits.

[0001730168-18-000084:notes:181]
Uncertain Tax Positions

[0001730168-18-000084:notes:182]
Gross unrecognized tax benefits increased by $1,774 million during fiscal year 2018, resulting in gross unrecognized tax benefits of $4,030 million as of November 4, 2018. The increase in gross unrecognized tax benefits was primarily due to the recognition of uncertain tax positions of $1,112 million related to the Transition Tax, offset by a reduction of our federal deferred income tax liabilities on accumulated non-U.S. earnings. The increase in gross unrecognized tax benefits was also due to the Redomiciliation Transaction, and to a lesser extent, the Brocade Merger.

[0001730168-18-000084:notes:183]
Gross unrecognized tax benefits increased by $273 million during fiscal year 2017, resulting in gross unrecognized tax benefits of $2,256 million as of October 29, 2017.  The increase in gross unrecognized tax benefits was primarily a result of restructuring activities in fiscal year 2017.  During fiscal year 2017, we recognized $121 million of previously unrecognized tax benefits as a result of the audit settlement with taxing authorities, and $12 million as a result of the expiration of the statute of limitations for certain audit periods.

[0001730168-18-000084:notes:184]
Gross unrecognized tax benefits increased by $1,405 million during fiscal year 2016, resulting in gross unrecognized tax benefits of $1,983 million as of October 30, 2016.  The increase in gross unrecognized tax benefits was primarily a result of the Broadcom Merger in fiscal year 2016.

[0001730168-18-000084:notes:185]
We recognize interest and penalties related to unrecognized tax benefits within provision for income taxes in the accompanying consolidated statements of operations. We recognized approximately $59 million of expense related to interest and penalties in fiscal year 2018. Accrued interest and penalties were included within other long-term liabilities on the consolidated balance sheets. As of November 4, 2018 and October 29, 2017, the combined amount of cumulative accrued interest and penalties was approximately $190 million and $132 million, respectively. The increase in cumulative accrued interest and penalties was primarily a result of an increase in interest accrual from various unrecognized tax benefit items.

[0001730168-18-000084:notes:186]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-18-000084:notes:187]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Beginning balance |  | $ | 2,256 |  |  | $ | 1,983 |  |  | $ | 578 |  |
| Lapse of statute of limitations |  | (20 | ) |  | (12 | ) |  | (8 | ) |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | 361 |  |  | 47 |  |  | 1,325 |  |
| Decreases in balances related to tax positions taken during prior periods |  | (289 | ) |  | (32 | ) |  | (1 | ) |
| Increases in balances related to tax positions taken during current period |  | 1,726 |  |  | 391 |  |  | 138 |  |
| Decreases in balances related to settlement with taxing authorities |  | (4 | ) |  | (121 | ) |  | (49 | ) |
| Ending balance |  | $ | 4,030 |  |  | $ | 2,256 |  |  | $ | 1,983 |  |

[0001730168-18-000084:notes:188]
A portion of our unrecognized tax benefits will affect our effective tax rate if they are recognized upon favorable resolution of the uncertain tax positions. As of November 4, 2018, approximately $4,220 million of the unrecognized tax benefits including accrued interest and penalties would affect our effective tax rate. As of October 29, 2017, approximately $2,388 million of the unrecognized tax benefits including accrued interest and penalties would have affected our effective tax rate.

[0001730168-18-000084:notes:189]
We are subject to U.S. income tax examination for fiscal years 2010 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2012 and later. It is possible that we may recognize up to $468 million of our existing unrecognized tax benefits within the next 12 months as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:IncomeTaxPolicyTextBlock

[0001730168-18-000084:notes:190]
Taxes on income.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-18-000084:notes:191]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes. Likewise, if we determine that we are not be able to realize all or part of our net deferred tax assets, we increase the provision for income taxes in the period such determination is made.

[0001730168-18-000084:notes:192]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.


## us-gaap:InventoryPolicyTextBlock

[0001730168-18-000084:notes:193]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.


## us-gaap:LegalCostsPolicyTextBlock

[0001730168-18-000084:notes:194]
Litigation and settlement cost. We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001730168-18-000084:notes:195]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,859 |  |  | $ | 1,822 |  |
| Taiwan |  | 264 |  |  | 268 |  |
| Other |  | 512 |  |  | 509 |  |
|  |  | $ | 2,635 |  |  | $ | 2,599 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001730168-18-000084:notes:196]
Recently Adopted Accounting Guidance

[0001730168-18-000084:notes:197]
In the first quarter of fiscal year 2018, we early adopted guidance issued by the Financial Accounting Standards Board, or FASB, in October 2016 related to the recognition of income tax consequences of an intra-entity transfer of an asset other than inventory. The standard requires a modified-retrospective transition method by means of a cumulative-effect adjustment as of the beginning of the period in which the guidance is adopted. The adoption of this guidance resulted in a decrease in current and long-term prepaid tax expense of $67 million and $199 million, respectively, an increase of $252 million to our accumulated deficit and a decrease of $14 million to our noncontrolling interest.

[0001730168-18-000084:notes:198]
In the second quarter of fiscal year 2018, we early adopted guidance issued by the FASB in February 2018 that allows companies to reclassify stranded income tax effects resulting from the U.S. Tax Cuts and Jobs Act, or the 2017 Tax Reform Act, from accumulated other comprehensive loss to retained earnings. The stranded income tax effects resulted from the change in the federal tax rate for deferred taxes recorded in accumulated other comprehensive loss. The adoption of this guidance resulted in a cumulative-effect adjustment as of the beginning of the second quarter of fiscal year 2018, which consisted of an increase to our accumulated other comprehensive loss of $16 million, an increase to retained earnings of $15 million and a $1 million increase to noncontrolling interest.

[0001730168-18-000084:notes:199]
Recent Accounting Guidance Not Yet Adopted

[0001730168-18-000084:notes:200]
In August 2016, the FASB issued guidance related to the classification of certain transactions on the statement of cash flows. This guidance will be effective for the first quarter of our fiscal year 2019; however, early adoption is permitted. We will present our statements of cash flows in accordance with this guidance for the affected transactions occurring subsequent to adoption.

[0001730168-18-000084:notes:201]
In February 2016, the FASB issued guidance related to the accounting for leases, which among other things, requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. The new guidance is required to be applied using a modified retrospective approach. We are evaluating the impact that this guidance will have on our consolidated financial statements, consisting primarily of a balance sheet gross up of right-of-use assets and lease liabilities on the consolidated balance sheets upon adoption, which will increase the Company's total assets and liabilities.

[0001730168-18-000084:notes:202]
In January 2016, the FASB issued guidance related to the recognition, measurement, presentation and disclosure of financial instruments and requires, among others, equity securities to be measured at fair value with changes in fair value recognized through net income. The guidance is required to be applied by means of a cumulative-effect adjustment to the balance sheet as of the beginning of the fiscal year of adoption, with other amendments related specifically to equity securities without readily determinable fair values applied prospectively. This guidance will be effective for the first quarter of our fiscal year 2019. We are evaluating the impact that this guidance will have on our consolidated financial statements, including other long-term assets and other income, net, for changes in fair value of equity securities.

[0001730168-18-000084:notes:203]
In May 2014, the FASB issued guidance that outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance. The effective date of the guidance, as amended, will be the first quarter of our fiscal year 2019. The new standard creates a single source of revenue guidance under GAAP, eliminating industry-specific guidance.

[0001730168-18-000084:notes:204]
The underlying principle of the standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. An entity should apply a five-step approach for recognizing revenue as follows (1) identify the contract with a customer; (2) identify the performance obligations in the contract; (3) determine the transaction price; (4) allocate the transaction price to the performance obligations in the contract; and (5) recognize revenue when, or as, the entity satisfies a performance obligation. The standard also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0001730168-18-000084:notes:205]
The standard allows two methods of adoption: (1) retrospectively to each prior period presented (“full retrospective method”), or (2) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). We plan to adopt the new standard using the modified retrospective method at the beginning of our first quarter of fiscal year 2019. We are finalizing our analysis to quantify the adoption impact of the provisions of the new standard. We expect to use the input method to determine our revenue from development arrangements that are currently recognized upon completion and acceptance of our contract deliverables.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-18-000084:notes:206]
Overview and Basis of Presentation

[0001730168-18-000084:notes:207]
Overview

[0001730168-18-000084:notes:208]
Broadcom Inc., or Broadcom, is the successor to Broadcom Limited, a company organized under the laws of the Republic of Singapore, or Broadcom-Singapore. As part of the plan to cause the publicly traded parent company of Broadcom to be a Delaware corporation, or the Redomiciliation Transaction, after the close of market trading on April 4, 2018, Broadcom and Broadcom-Singapore completed a statutory scheme of arrangement under Singapore law pursuant to which all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom common stock and Broadcom-Singapore became an indirect wholly-owned subsidiary of Broadcom.

[0001730168-18-000084:notes:209]
In conjunction with the Redomiciliation Transaction, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, a subsidiary of Broadcom-Singapore, were mandatorily exchanged, or the Mandatory Exchange, on a one-for-one basis for newly issued shares of Broadcom common stock. As a result, all limited partners of the Partnership became common stockholders of Broadcom. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. Consequently, the limited partners no longer hold a noncontrolling interest in the Partnership and we subsequently deregistered the Partnership.

[0001730168-18-000084:notes:210]
The scheme of arrangement was accounted for as an exchange of equity interests among entities under common control. All assets and liabilities of Broadcom-Singapore were assumed by Broadcom, resulting in the retention of the historical basis of accounting as if they had always been combined for accounting and financial reporting purposes.

[0001730168-18-000084:notes:211]
The financial statements relate to:

[0001730168-18-000084:notes:212]
| • | Avago Technologies Limited, or Avago, predecessor to Broadcom-Singapore, for periods prior to February 1, 2016; |

[0001730168-18-000084:notes:213]
| • | Broadcom-Singapore for the period from February 1, 2016 to April 4, 2018, the effective date of the Redomiciliation Transaction; and |

[0001730168-18-000084:notes:214]
| • | Broadcom for periods after April 4, 2018. |

[0001730168-18-000084:notes:215]
Unless stated otherwise or the context otherwise requires, references to "Broadcom", "we", "our" and "us" mean Broadcom Inc. and its consolidated subsidiaries from the effective date of the Redomiciliation Transaction and, prior to that time, our predecessors Broadcom-Singapore or Avago for the periods specified above.

[0001730168-18-000084:notes:216]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Through our fiscal year ended November 4, 2018, or fiscal year 2018, we had four reportable segments: wired infrastructure, wireless communications, enterprise storage and industrial & other, which align with our principal target markets.

[0001730168-18-000084:notes:217]
Basis of Presentation

[0001730168-18-000084:notes:218]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2018 was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. The first quarter of our fiscal year 2018 ended on February 4, 2018, the second quarter ended on May 6, 2018 and the third quarter ended on August 5, 2018. Our fiscal years ended October 29, 2017, or fiscal year 2017, and October 30, 2016, or fiscal year 2016, were 52-week fiscal years.

[0001730168-18-000084:notes:219]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted principles in the United States, or GAAP. All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001730168-18-000084:notes:220]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Interest payable |  | $ | 165 |  |  | $ | 136 |  |
| Deferred revenue |  | 164 |  |  | 51 |  |
| Accrued rebates |  | 161 |  |  | 124 |  |
| Tax liabilities |  | 162 |  |  | 123 |  |
| Other (miscellaneous) |  | 160 |  |  | 247 |  |
| Total other current liabilities |  | $ | 812 |  |  | $ | 681 |  |


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001730168-18-000084:notes:221]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Unrecognized tax benefits (a) (b) |  | $ | 3,088 |  |  | $ | 1,011 |  |
| Deferred tax liabilities (a) |  | 169 |  |  | 10,019 |  |
| Tax indemnification liability |  | 116 |  |  | — |  |
| Other (miscellaneous) |  | 263 |  |  | 242 |  |
| Total other long-term liabilities |  | $ | 3,636 |  |  | $ | 11,272 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-18-000084:notes:222]
Retirement Plans and Post-Retirement Benefits

[0001730168-18-000084:notes:223]
Pension and Post-Retirement Benefit Plans

[0001730168-18-000084:notes:224]
Defined Benefit Plans.  The U.S. defined benefit pension plans include a management plan and a represented plan. Benefits under the management plan are provided under either an adjusted career-average-pay program or a cash-balance program. Benefits under the represented plan are based on a dollar-per-month formula. Benefit accruals under the management plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the represented plan. We also have a non-qualified supplemental pension plan in the United States that principally provides benefits based on compensation in excess of amounts that can be considered under the management plan. We also have pension plans covering certain non-U.S. employees.

[0001730168-18-000084:notes:225]
Post-Retirement Benefit Plans.  Certain of our U.S. employees who meet the retirement eligibility requirements as of their termination dates, may receive post-retirement medical benefits under our retiree medical account program. Eligible employees receive a medical benefit spending account of $55,000 upon retirement to pay premiums for medical coverage through the maximum age of 75 as retiree.

[0001730168-18-000084:notes:226]
Our group life insurance plan offers post-retirement life insurance coverage for certain U.S. employees.

[0001730168-18-000084:notes:227]
Non-U.S Retirement Benefit Plans.  In addition to the defined benefit plans for certain employees in Taiwan, India, Japan, Israel, Italy and Germany, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-18-000084:notes:228]
Net Periodic Benefit (Income) Cost

[0001730168-18-000084:notes:229]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | Fiscal Year |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Service cost |  | $ | 4 |  |  | $ | 4 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost |  | 51 |  |  | 53 |  |  | 59 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets |  | (51 | ) |  | (65 | ) |  | (72 | ) |  | (4 | ) |  | (4 | ) |  | (4 | ) |
| Other |  | 1 |  |  | 1 |  |  | 4 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit (income) cost |  | $ | 5 |  |  | $ | (7 | ) |  | $ | (6 | ) |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (1 | ) |
| Net actuarial (gain) loss |  | $ | 14 |  |  | $ | (60 | ) |  | $ | 88 |  |  | $ | (3 | ) |  | $ | (3 | ) |  | $ | 11 |  |

[0001730168-18-000084:notes:230]
Funded Status

[0001730168-18-000084:notes:231]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 4, 2018 |  | October 29, 2017 |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,426 |  |  | $ | 1,050 |  |  | $ | 83 |  |  | $ | 78 |  |
| Actual return on plan assets |  | (65 | ) |  | 108 |  |  | — |  |  | 7 |  |
| Employer contributions |  | 130 |  |  | 361 |  |  | — |  |  | — |  |
| Payments from plan assets |  | (93 | ) |  | (93 | ) |  | (2 | ) |  | (2 | ) |
| Foreign currency impact |  | (4 | ) |  | — |  |  | — |  |  | — |  |
| Fair value of plan assets — end of period |  | 1,394 |  |  | 1,426 |  |  | 81 |  |  | 83 |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,508 |  |  | 1,566 |  |  | 80 |  |  | 79 |  |
| Service cost |  | 4 |  |  | 4 |  |  | — |  |  | — |  |
| Interest cost |  | 51 |  |  | 53 |  |  | 3 |  |  | 3 |  |
| Actuarial gain |  | (102 | ) |  | (13 | ) |  | (7 | ) |  | — |  |
| Benefit payments |  | (93 | ) |  | (93 | ) |  | (2 | ) |  | (2 | ) |
| Curtailments |  | — |  |  | (4 | ) |  | — |  |  | — |  |
| Settlements |  | — |  |  | (8 | ) |  | — |  |  | — |  |
| Plan amendment |  | 3 |  |  | — |  |  | — |  |  | — |  |
| Foreign currency impact |  | (7 | ) |  | 3 |  |  | — |  |  | — |  |
| Benefit obligations — end of period |  | 1,364 |  |  | 1,508 |  |  | 74 |  |  | 80 |  |
| Overfunded (underfunded) status of benefit obligations (a) |  | $ | 30 |  |  | $ | (82 | ) |  | $ | 7 |  |  | $ | 3 |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive loss, net of taxes |  | $ | (110 | ) |  | $ | (85 | ) |  | $ | (5 | ) |  | $ | (6 | ) |

[0001730168-18-000084:notes:232]
_________________________________

[0001730168-18-000084:notes:233]
| (a) | Substantially all amounts recognized in the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented. |

[0001730168-18-000084:notes:234]
Plans with benefit obligations in excess of plan assets:

[0001730168-18-000084:notes:235]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 4, 2018 |  | October 29, 2017 |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 551 |  |  | $ | 701 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 546 |  |  | $ | 696 |  |  | $ | 14 |  |  | $ | 15 |  |
| Fair value of plan assets |  | $ | 528 |  |  | $ | 603 |  |  | $ | — |  |  | $ | — |  |

[0001730168-18-000084:notes:236]
The fair value of pension plan assets at November 4, 2018 and October 29, 2017 included $147 million and $20 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-18-000084:notes:237]
The projected benefit obligations as of November 4, 2018 and October 29, 2017 included $129 million and $106 million, respectively, of obligations related to our non-U.S. plans. The accumulated benefit obligations as of November 4, 2018 and October 29, 2017 included $122 million and $100 million, respectively, of obligations related to our non-U.S. plans.

[0001730168-18-000084:notes:238]
We currently expect to make contributions of $6 million to our defined benefit pension plans in fiscal year 2019.

[0001730168-18-000084:notes:239]
Expected Future Benefit Payments

[0001730168-18-000084:notes:240]
| Fiscal Years: |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | (In millions) |
| 2019 |  | $ | 93 |  |  | $ | 3 |  |
| 2020 |  | $ | 91 |  |  | $ | 3 |  |
| 2021 |  | $ | 91 |  |  | $ | 3 |  |
| 2022 |  | $ | 91 |  |  | $ | 3 |  |
| 2023 |  | $ | 91 |  |  | $ | 4 |  |
| 2024-2028 |  | $ | 445 |  |  | $ | 20 |  |

[0001730168-18-000084:notes:241]
Defined Benefit Plan Investment Policy

[0001730168-18-000084:notes:242]
Plan assets of the funded defined benefit pension plans are invested in funds held by third-party fund managers or are deposited into government-managed accounts in which we have no active involvement in and no control over investment strategy, other than establishing broad investment guidelines and parameters.

[0001730168-18-000084:notes:243]
Our plan’s investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-18-000084:notes:244]
The target asset allocation for U.S. plans reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plans. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2018 and 2017, 100% of U. S. plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-18-000084:notes:245]
Fair Value Measurement of Plan Assets

[0001730168-18-000084:notes:246]
|  |  | November 4, 2018 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 36 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 36 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 19 |  | (b) |  | — |  |  |  | — |  |  | 19 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 80 |  | (c) |  | — |  |  | 80 |  |
| Corporate bonds |  | — |  |  |  | 1,229 |  | (c) |  | — |  |  | 1,229 |  |
| Municipal bonds |  | — |  |  |  | 17 |  | (c) |  | — |  |  | 17 |  |
| Government bonds |  | — |  |  |  | 13 |  | (c) |  | — |  |  | 13 |  |
| Total plan assets |  | $ | 55 |  |  |  | $ | 1,339 |  |  |  | $ | — |  |  | $ | 1,394 |  |

[0001730168-18-000084:notes:247]
|  |  | October 29, 2017 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 943 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 943 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 7 |  | (b) |  | — |  |  |  | — |  |  | 7 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 39 |  | (c) |  | — |  |  | 39 |  |
| Corporate bonds |  | — |  |  |  | 393 |  | (c) |  | — |  |  | 393 |  |
| Asset-backed and mortgage-backed securities |  | — |  |  |  | 1 |  | (c) |  | — |  |  | 1 |  |
| Municipal bonds |  | — |  |  |  | 25 |  | (c) |  | — |  |  | 25 |  |
| Government bonds |  | — |  |  |  | 18 |  | (c) |  | — |  |  | 18 |  |
| Total plan assets |  | $ | 950 |  |  |  | $ | 476 |  |  |  | $ | — |  |  | $ | 1,426 |  |

[0001730168-18-000084:notes:248]
| (a) | Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets. |

[0001730168-18-000084:notes:249]
| (b) | These equity securities were valued based on quoted prices in active markets. |

[0001730168-18-000084:notes:250]
| (c) | These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the asset, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals. |

[0001730168-18-000084:notes:251]
Post-Retirement Benefit Plan Investment Policy

[0001730168-18-000084:notes:252]
Our overall investment strategy for the group life insurance plan is to allocate assets in a manner that seeks to both maximize the safety of promised benefits and minimize the cost of funding those benefits. The target asset allocation for plan assets reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. We set the overall portfolio allocation and use an investment manager that directs the investment of funds consistent with that allocation. The investment manager invests the plan assets in index funds that it manages.

[0001730168-18-000084:notes:253]
The following table presents the plan asset allocations by category:

[0001730168-18-000084:notes:254]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | Actual |  | Target |  | Actual |  | Target |
| Commingled funds - U.S. equities |  | — | % |  | — | % |  | 20 | % |  | 20 | % |
| Commingled funds - Non-U.S. equities |  | — |  |  | — |  |  | 20 |  |  | 20 |  |
| Commingled funds - bonds |  | 100 |  |  | 100 |  |  | 60 |  |  | 60 |  |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-18-000084:notes:255]
Assumptions

[0001730168-18-000084:notes:256]
The assumptions used to determine the benefit obligations and net periodic benefit (income) cost from our defined benefit and post-retirement benefit plans are presented in the table below. The expected long-term return on assets shown in the table below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes (both historical and forecasted) in which we expect the pension and post-retirement funds to be invested. Discount rates reflect the current rate at which defined benefit and post-retirement benefit obligations could be settled based on the measurement dates of the plans, which in each case is our fiscal year end. The range of assumptions that are used for defined benefit pension plans reflects the different economic environments within various countries.

[0001730168-18-000084:notes:257]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 4, 2018 |  | October 29, 2017 |  | 2018 |  | 2017 |  | 2016 |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 0.50%-8.00% |  | 0.50%-7.00% |  | 0.50%-7.00% |  | 0.50%-7.00% |  | 0.75%-7.75% |
| Average increase in compensation levels |  | 2.00%-10.00% |  | 2.00%-11.00% |  | 2.00%-11.00% |  | 2.00%-9.15% |  | 2.50%-11.72% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 1.50%-7.50% |  | 0.25%-8.00% |  | 1.50%-9.00% |

[0001730168-18-000084:notes:258]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 4, 2018 |  | October 29, 2017 |  | 2018 |  | 2017 |  | 2016 |
| Post-retirement benefits plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 4.30%-4.60% |  | 3.40%-3.80% |  | 3.40%-3.80% |  | 3.30%-3.90% |  | 3.90%-4.50% |
| Average increase in compensation levels |  | 3.00% |  | 3.00% |  | 3.00% |  | 3.50% |  | 3.50% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 4.80% |  | 4.40% |  | 5.10% |

[0001730168-18-000084:notes:259]
We assume that the health care cost trend rate for fiscal year 2019 will be 6.7% and will decrease to the ultimate health care cost trend rate of 3.5% in fiscal year 2031.

[0001730168-18-000084:notes:260]
A one percentage point increase or decrease in the assumed health care cost trend rates would not have had a material effect on the benefit obligations or service and interest cost components of the net periodic benefit cost for all the periods presented.

[0001730168-18-000084:notes:261]
401(k) Defined Contribution Plans

[0001730168-18-000084:notes:262]
Our eligible U.S. employees participate in company-sponsored 401(k) plans. Under these plans, we provide matching contributions to employees up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2018, 2017 and 2016, we made contributions of $73 million, $61 million and $43 million, respectively, to the 401(k) plans.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001730168-18-000084:notes:263]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years, or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over three to ten years. We use the straight-line method of depreciation for all property, plant and equipment.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001730168-18-000084:notes:264]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Land |  | $ | 189 |  |  | $ | 177 |  |
| Construction in progress |  | 67 |  |  | 411 |  |
| Buildings and leasehold improvements |  | 1,016 |  |  | 579 |  |
| Machinery and equipment |  | 3,257 |  |  | 2,925 |  |
| Total property, plant and equipment |  | 4,529 |  |  | 4,092 |  |
| Accumulated depreciation and amortization |  | (1,894 | ) |  | (1,493 | ) |
| Total property, plant and equipment, net |  | $ | 2,635 |  |  | $ | 2,599 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001730168-18-000084:notes:265]
Supplementary Financial Data — Quarterly Data (Unaudited)

[0001730168-18-000084:notes:266]
|  |  | Fiscal Quarter Ended |
|  |  | November 4, 2018 (1) |  | August 5, 2018 (2) |  | May 6, 2018 (3) |  | February 4, 2018 (4) |  | October 29, 2017 (5) |  | July 30, 2017 (6) |  | April 30, 2017 (7) |  | January 29, 2017 (8) |
|  |  | (In millions, except per share data) |
| Net revenue |  | $ | 5,444 |  |  | $ | 5,063 |  |  | $ | 5,014 |  |  | $ | 5,327 |  |  | $ | 4,844 |  |  | $ | 4,463 |  |  | $ | 4,190 |  |  | $ | 4,139 |  |
| Gross margin |  | 2,935 |  |  | 2,619 |  |  | 2,551 |  |  | 2,628 |  |  | 2,383 |  |  | 2,149 |  |  | 1,976 |  |  | 2,001 |  |
| Operating income |  | 1,652 |  |  | 1,339 |  |  | 1,201 |  |  | 943 |  |  | 755 |  |  | 648 |  |  | 474 |  |  | 506 |  |
| Income from continuing operations |  | 1,115 |  |  | 1,197 |  |  | 3,736 |  |  | 6,581 |  |  | 556 |  |  | 509 |  |  | 468 |  |  | 257 |  |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | (1 | ) |  | (3 | ) |  | (15 | ) |  | 5 |  |  | (2 | ) |  | (4 | ) |  | (5 | ) |
| Net income |  | 1,115 |  |  | 1,196 |  |  | 3,733 |  |  | 6,566 |  |  | 561 |  |  | 507 |  |  | 464 |  |  | 252 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | — |  |  | 15 |  |  | 336 |  |  | 29 |  |  | 26 |  |  | 24 |  |  | 13 |  |
| Net income attributable to common stock |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 3,718 |  |  | $ | 6,230 |  |  | $ | 532 |  |  | $ | 481 |  |  | $ | 440 |  |  | $ | 239 |  |
| Diluted income (loss) per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 8.34 |  |  | $ | 14.66 |  |  | $ | 1.24 |  |  | $ | 1.14 |  |  | $ | 1.06 |  |  | $ | 0.58 |  |
| Income (loss) per share from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (0.01 | ) |  | (0.04 | ) |  | 0.01 |  |  | — |  |  | (0.01 | ) |  | (0.01 | ) |
| Net income per share |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 8.33 |  |  | $ | 14.62 |  |  | $ | 1.25 |  |  | $ | 1.14 |  |  | $ | 1.05 |  |  | $ | 0.57 |  |
| Dividends declared and paid per share |  | $ | 1.75 |  |  | $ | 1.75 |  |  | $ | 1.75 |  |  | $ | 1.75 |  |  | $ | 1.02 |  |  | $ | 1.02 |  |  | $ | 1.02 |  |  | $ | 1.02 |  |
| Dividends declared and paid per share-full year |  | $ | 7.00 |  |  |  |  |  |  |  |  | $ | 4.08 |  |  |  |  |  |  |  |

[0001730168-18-000084:notes:267]
| (1) | Includes amortization of acquisition-related intangible assets of $829 million and impairment on investment of $106 million. |

[0001730168-18-000084:notes:268]
| (2) | Includes amortization of acquisition-related intangible assets of $830 million. |

[0001730168-18-000084:notes:269]
| (3) | Includes amortization of acquisition-related intangible assets of $832 million. |

[0001730168-18-000084:notes:270]
| (4) | Includes the results of Brocade beginning with the fiscal quarter ended February 4, 2018 in connection with the completion of the Brocade Merger on November 17, 2017. Also includes amortization of acquisition-related intangible assets of $1,054 million, a purchase accounting effect on inventory charge of $70 million and restructuring, impairment and disposal charges of $145 million. |

[0001730168-18-000084:notes:271]
| (5) | Includes amortization of acquisition-related intangible assets of $1,099 million and $110 million of litigation settlement charges. |

[0001730168-18-000084:notes:272]
| (6) | Includes amortization of acquisition-related intangible assets of $1,096 million. |

[0001730168-18-000084:notes:273]
| (7) | Includes amortization of acquisition-related intangible assets of $1,081 million. |

[0001730168-18-000084:notes:274]
| (8) | Includes amortization of acquisition-related intangible assets of $999 million and a loss on debt extinguishment of $159 million. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001730168-18-000084:notes:275]
Related Party Transactions

[0001730168-18-000084:notes:276]
Silicon Manufacturing Partners Pte. Ltd.

[0001730168-18-000084:notes:277]
We have a 51% equity interest in Silicon Manufacturing Partners Pte. Ltd., or SMP, a joint venture with GlobalFoundries. We have a take-or-pay agreement with SMP under which we have agreed to purchase 51% of the managed wafer capacity from SMP’s integrated circuit manufacturing facility and GlobalFoundries has agreed to purchase the remaining managed wafer capacity. SMP determines its managed wafer capacity each year based on forecasts provided by us and GlobalFoundries. If we fail to purchase our required commitments, we will be required to pay SMP for the fixed costs associated with the unpurchased wafers. GlobalFoundries is similarly obligated with respect to the wafers allotted to it. The agreement may be terminated by either party upon two years written notice. The agreement may also be terminated for material breach, bankruptcy or insolvency. We purchased $66 million, $59 million and $41 million of inventory from SMP for fiscal years 2018, 2017 and 2016, respectively. As of November 4, 2018, the amount payable to SMP was $11 million.

[0001730168-18-000084:notes:278]
During fiscal years 2018, 2017 and 2016, in the ordinary course of business, we purchased from, or sold to, entities of which one of our directors also serves or served as a director, or entities that are otherwise affiliated with one of our directors.

[0001730168-18-000084:notes:279]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Total net revenue |  | $ | 664 |  |  | $ | 346 |  |  | $ | 335 |  |
| Total costs and expenses including inventory purchases |  | $ | 109 |  |  | $ | 145 |  |  | $ | 81 |  |

[0001730168-18-000084:notes:280]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | — |  |  | $ | 31 |  |
| Total payables |  | $ | 11 |  |  | $ | 12 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-18-000084:notes:281]
Restructuring, Impairment and Disposal Charges

[0001730168-18-000084:notes:282]
Restructuring Charges

[0001730168-18-000084:notes:283]
The following is a summary of significant restructuring expense recognized in continuing operations, primarily in operating expenses:

[0001730168-18-000084:notes:284]
| • | During fiscal year 2018, we initiated cost reduction activities associated with the Brocade Merger. As a result, we recognized $176 million of restructuring expense primarily related to employee termination costs. Approximately 1,200 employees were terminated from our workforce across all business and functional areas on a global basis as a result of the Brocade Merger during fiscal year 2018. |

[0001730168-18-000084:notes:285]
| • | During fiscal year 2016, we initiated cost reduction activities associated with the acquisition of BRCM. As a result, we recognized $50 million, $124 million and $447 million of restructuring expense in fiscal years 2018, 2017, and 2016 respectively. These restructuring expenses primarily related to lease and other exit costs for fiscal year 2018 and employee termination costs for fiscal years 2017 and 2016. |

[0001730168-18-000084:notes:286]
As of November 4, 2018, we have substantially completed the restructuring activities related to the acquisition of BRCM.

[0001730168-18-000084:notes:287]
|  |  | Employee Termination Costs |  | Lease and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 2, 2015 |  | $ | 13 |  |  | $ | 13 |  |  | $ | 26 |  |
| Liabilities assumed from BRCM |  | 2 |  |  | 13 |  |  | 15 |  |
| Restructuring charges |  | 445 |  |  | 37 |  |  | 482 |  |
| Utilization |  | (344 | ) |  | (28 | ) |  | (372 | ) |
| Balance as of October 30, 2016 |  | 116 |  |  | 35 |  |  | 151 |  |
| Restructuring charges |  | 86 |  |  | 43 |  |  | 129 |  |
| Utilization |  | (174 | ) |  | (61 | ) |  | (235 | ) |
| Balance as of October 29, 2017 |  | 28 |  |  | 17 |  |  | 45 |  |
| Restructuring charges (a) |  | 153 |  |  | 75 |  |  | 228 |  |
| Utilization |  | (165 | ) |  | (86 | ) |  | (251 | ) |
| Balance as of November 4, 2018 (b) |  | $ | 16 |  |  | $ | 6 |  |  | $ | 22 |  |

[0001730168-18-000084:notes:288]
| (a) | Included $2 million, $5 million and $35 million of restructuring charges related to discontinued operations recognized during fiscal years 2018, 2017 and 2016, respectively, which was included in loss from discontinued operations in our consolidated statements of operations. |

[0001730168-18-000084:notes:289]
| (b) | The majority of the employee termination costs balance is expected to be paid during the first quarter of fiscal year 2019. The leases and other exit costs balance is expected to be paid by the end of fiscal year 2019. |

[0001730168-18-000084:notes:290]
Impairment and Disposal Charges

[0001730168-18-000084:notes:291]
During fiscal year 2018, impairment and disposal charges of $13 million primarily related to leasehold improvements.

[0001730168-18-000084:notes:292]
During fiscal year 2017, impairment and disposal charges of $56 million related to property, plant and equipment and IPR&D projects acquired in the BRCM acquisition.

[0001730168-18-000084:notes:293]
During fiscal year 2016, impairment and disposal charges of $417 million primarily related to IPR&D projects which were abandoned as a result of the BRCM acquisition. In addition, we recorded impairment charges of $173 million primarily for property, plant and equipment and a $16 million loss on disposal of these assets acquired in the BRCM acquisition.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001730168-18-000084:notes:294]
Revenue recognition.  We recognize revenue related to sales of our products, net of trade discounts and allowances, provided that (i) persuasive evidence of an arrangement exists, (ii) delivery has occurred and title and risk of loss have transferred, (iii) the price is fixed or determinable and (iv) collectibility is reasonably assured. Delivery is considered to have occurred when title and risk of loss have transferred to the customer. We consider the price to be determinable when the price is not subject to refund or adjustments or when any such adjustments can be estimated. We evaluate the creditworthiness of our customers to determine that appropriate credit limits are established prior to the acceptance of an order. Revenue, including sales to resellers and distributors, is reduced for estimated returns and distributor allowances.

[0001730168-18-000084:notes:295]
We recognize revenue from sales of our products to distributors upon delivery of product to the distributors. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and results of operations in subsequent periods.

[0001730168-18-000084:notes:296]
Certain of our product sales are sold in multiple-element arrangements including networking hardware with embedded software products and support, which are considered separate units of accounting. For certain of our products, software and non-software components function together to deliver the tangible products’ essential functionality.

[0001730168-18-000084:notes:297]
We allocate revenue to each element in a multiple-element arrangement based upon the relative selling price. When applying the relative selling price method, we determine the selling price for each deliverable using vendor-specific objective evidence, or VSOE, of selling price, if it exists, or third-party evidence, or TPE, of selling price. If neither VSOE nor TPE of selling price exist for a deliverable, we use our best estimate of selling price for that deliverable. Revenue allocated to each element is then recognized when the basic revenue recognition criteria are met for each element.  Revenue related to support is deferred and recognized ratably over the contractual period.

[0001730168-18-000084:notes:298]
We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. For support, we consider stated renewal rates in determining VSOE.

[0001730168-18-000084:notes:299]
In most instances, we are not able to establish VSOE for all deliverables in an arrangement with multiple elements. When VSOE cannot be established, we attempt to establish the selling price for each element based on TPE.  When we are unable to establish selling price using VSOE or TPE, we use best estimated selling price, or BESP, in our allocation of the arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. We determine BESP for a product by considering multiple factors including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives and pricing practices taking into consideration our go-to-market strategy.

[0001730168-18-000084:notes:300]
We enter into development agreements with some of our customers and recognize revenue from these agreements upon completion and acceptance by the customer of contract deliverables or as services are provided, depending on the terms of the arrangement. Revenue is deferred for any amounts billed or received prior to completion or delivery of services. As we retain the intellectual property generated from these development agreements, costs related to these arrangements are included in research and development expense.

[0001730168-18-000084:notes:301]
Revenue from upfront payments for the licensing of our patents is recognized when the arrangement is mutually signed, if there is no future delivery or future performance obligation and all other criteria are met. Revenue from guaranteed royalty streams are recognized when paid, or collection is reasonably assured and all other criteria are met. When patent licensing arrangements include royalties for future sales of the licensees’ products using our licensed patented technology, revenue is recognized when the royalty report is received from the licensee, at which time the sales price is determinable, provided that all other criteria have been met.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001730168-18-000084:notes:302]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Beginning balance |  | $ | (91 | ) |  | $ | (134 | ) |
| Changes in accumulated other comprehensive loss: |  |  |  |  |
| Unrealized gain (loss) on defined benefit pension plans and post-retirement benefit plans before reclassification |  | (11 | ) |  | 63 |  |
| Amounts reclassified out of accumulated other comprehensive loss (a) |  | 1 |  |  | 1 |  |
| Tax effects |  | 2 |  |  | (21 | ) |
| Other comprehensive income (loss) |  | (8 | ) |  | 43 |  |
| Cumulative effect of accounting change |  | (16 | ) |  | — |  |
| Ending balance |  | $ | (115 | ) |  | $ | (91 | ) |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001730168-18-000084:notes:303]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 86 |  |  | $ | 64 |  |  | $ | 48 |  |
| Research and development |  | 855 |  |  | 636 |  |  | 430 |  |
| Selling, general and administrative |  | 286 |  |  | 220 |  |  | 186 |  |
| Total stock-based compensation expense (a) |  | $ | 1,227 |  |  | $ | 920 |  |  | $ | 664 |  |
| Income tax benefits for stock-based compensation |  | $ | 181 |  |  | $ | 273 |  |  | $ | 89 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001730168-18-000084:notes:304]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Finished goods |  | $ | 483 |  |  | $ | 562 |  |
| Work-in-process |  | 505 |  |  | 696 |  |
| Raw materials |  | 136 |  |  | 189 |  |
| Total inventory |  | $ | 1,124 |  |  | $ | 1,447 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001730168-18-000084:notes:305]
|  |  | November 4, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 243 |  |  | $ | 440 |  |
| Other receivables |  | 65 |  |  | 155 |  |
| Other (miscellaneous) |  | 58 |  |  | 129 |  |
| Total other current assets |  | $ | 366 |  |  | $ | 724 |  |


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001730168-18-000084:notes:306]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Other income |  | $ | 30 |  |  | $ | 43 |  |  | $ | 27 |  |
| Interest income |  | 114 |  |  | 44 |  |  | 10 |  |
| Other expense |  | — |  |  | (25 | ) |  | (27 | ) |
| Other income, net |  | $ | 144 |  |  | $ | 62 |  |  | $ | 10 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001730168-18-000084:notes:307]
The following tables present net revenue and long-lived asset information based on geographic region. Net revenue is based on the geographic location of the distributors, OEMs or contract manufacturers who purchased our products, which may differ from the geographic location of the end customers. Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-18-000084:notes:308]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| China |  | $ | 10,305 |  |  | $ | 9,460 |  |  | $ | 7,184 |  |
| United States |  | 2,697 |  |  | 1,266 |  |  | 1,124 |  |
| Other |  | 7,846 |  |  | 6,910 |  |  | 4,932 |  |
|  |  | $ | 20,848 |  |  | $ | 17,636 |  |  | $ | 13,240 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001730168-18-000084:notes:309]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Wired infrastructure |  | $ | 8,674 |  |  | $ | 8,549 |  |  | $ | 6,582 |  |
| Wireless communications |  | 6,490 |  |  | 5,404 |  |  | 3,724 |  |
| Enterprise storage |  | 4,673 |  |  | 2,799 |  |  | 2,291 |  |
| Industrial & other |  | 1,011 |  |  | 884 |  |  | 643 |  |
| Total net revenue |  | $ | 20,848 |  |  | $ | 17,636 |  |  | $ | 13,240 |  |
| Operating income (loss): |  |  |  |  |  |  |
| Wired infrastructure |  | $ | 4,093 |  |  | $ | 3,853 |  |  | $ | 2,664 |  |
| Wireless communications |  | 2,840 |  |  | 2,155 |  |  | 1,282 |  |
| Enterprise storage |  | 2,906 |  |  | 1,527 |  |  | 995 |  |
| Industrial & other |  | 571 |  |  | 447 |  |  | 327 |  |
| Unallocated expenses |  | (5,275 | ) |  | (5,599 | ) |  | (5,677 | ) |
| Total operating income (loss) |  | $ | 5,135 |  |  | $ | 2,383 |  |  | $ | (409 | ) |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001730168-18-000084:notes:310]
A summary of time- and market-based RSU activity is as follows:

[0001730168-18-000084:notes:311]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of November 1, 2015 |  | 5 |  |  | $ | 95.17 |  |
| Assumed in Broadcom Merger |  | 6 |  |  | $ | 135.58 |  |
| Granted |  | 12 |  |  | $ | 138.45 |  |
| Vested |  | (4 | ) |  | $ | 114.49 |  |
| Forfeited |  | (2 | ) |  | $ | 130.30 |  |
| Balance as of October 30, 2016 |  | 17 |  |  | $ | 130.71 |  |
| Granted |  | 8 |  |  | $ | 199.33 |  |
| Vested |  | (5 | ) |  | $ | 126.81 |  |
| Forfeited |  | (2 | ) |  | $ | 142.78 |  |
| Balance as of October 29, 2017 |  | 18 |  |  | $ | 163.42 |  |
| Granted |  | 7 |  |  | $ | 239.48 |  |
| Vested |  | (6 | ) |  | $ | 155.78 |  |
| Forfeited |  | (1 | ) |  | $ | 175.46 |  |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001730168-18-000084:notes:312]
A summary of time- and market-based stock option activity is as follows:

[0001730168-18-000084:notes:313]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 1, 2015 |  | 21 |  |  | $ | 47.92 |  |  |  |  |  |
| Exercised |  | (5 | ) |  | $ | 44.35 |  |  |  |  | $ | 579 |  |
| Cancelled |  | (1 | ) |  | $ | 53.56 |  |  |  |  |  |
| Balance as of October 30, 2016 |  | 15 |  |  | $ | 48.77 |  |  |  |  |  |
| Exercised |  | (4 | ) |  | $ | 45.48 |  |  |  |  | $ | 682 |  |
| Cancelled |  | (1 | ) |  | $ | 66.08 |  |  |  |  |  |
| Balance as of October 29, 2017 |  | 10 |  |  | $ | 49.54 |  |  |  |  |  |
| Exercised |  | (2 | ) |  | $ | 47.41 |  |  |  |  | $ | 534 |  |
| Cancelled |  | — |  | * | $ | 72.37 |  |  |  |  |  |
| Balance as of November 4, 2018 |  | 8 |  |  | $ | 50.14 |  |  | 1.96 |  | $ | 1,316 |  |
| Fully vested as of November 4, 2018 |  | 8 |  |  | $ | 49.97 |  |  | 1.95 |  | $ | 1,313 |  |
| Fully vested and expected to vest as of November 4, 2018 |  | 8 |  |  | $ | 50.14 |  |  | 1.96 |  | $ | 1,316 |  |

[0001730168-18-000084:notes:314]
* Represents fewer than 0.5 million shares.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-18-000084:notes:315]
Segment Information

[0001730168-18-000084:notes:316]
Reportable Segments

[0001730168-18-000084:notes:317]
We have four reportable segments: wired infrastructure, wireless communications, enterprise storage and industrial & other. These segments align with our principal target markets. The segments represent components for which separate financial information is available that is utilized on a regular basis by the Chief Executive Officer of Broadcom, who has been identified as the Chief Operating Decision Maker, or the CODM, as defined by authoritative guidance on segment reporting, in determining how to allocate resources and evaluate performance. The segments are determined based on several factors, including client base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-18-000084:notes:318]
Our CODM assesses the performance of each segment and allocates resources to those segments based on net revenue and operating results and does not evaluate our segments using discrete asset information. Operating results by segment include items that are directly attributable to each segment. Operating results by segment also include shared expenses such as global operations, including manufacturing support, logistics and quality control, in addition to expenses associated with selling, general and administrative activities for the business, which are allocated primarily based on revenue, while facilities expenses are primarily allocated based on site-specific headcount.

[0001730168-18-000084:notes:319]
Unallocated Expenses

[0001730168-18-000084:notes:320]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, charges related to inventory step-up to fair value, litigation settlement charges, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs also include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-18-000084:notes:321]
Depreciation expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-18-000084:notes:322]
Significant Customer Information

[0001730168-18-000084:notes:323]
We sell our products through our direct sales force and a select network of distributors globally. Two direct customers accounted for 20% and 14% of our net accounts receivable balance at November 4, 2018 compared with one direct customer which accounted for 17% of our net accounts receivable balance at October 29, 2017. During fiscal year 2018, no direct customers represented more than 10% of our net revenue. During fiscal years 2017 and 2016, one direct customer represented 14% of our net revenue in each period. The majority of the revenue from this customer was included in our wireless communications and wired infrastructure segments. This customer is a contract manufacturer for a number of OEMs.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-18-000084:notes:324]
Stockholders’ Equity

[0001730168-18-000084:notes:325]
Completion of the Redomiciliation Transaction

[0001730168-18-000084:notes:326]
For the period prior to the Redomiciliation Transaction, our stockholders’ equity reflected Broadcom-Singapore’s outstanding ordinary shares, all of which were publicly traded on The Nasdaq Global Select Market. After the close of market trading on April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom common stock, and Broadcom-Singapore became an indirect wholly-owned subsidiary of Broadcom.

[0001730168-18-000084:notes:327]
In conjunction with the Redomiciliation Transaction and pursuant to the Mandatory Exchange, all outstanding LP Units held by the limited partners were mandatorily exchanged for approximately 22 million newly issued shares of Broadcom common stock on a one-for-one basis. As a result, all limited partners of the Partnership became common stockholders of Broadcom. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange.

[0001730168-18-000084:notes:328]
Singapore Statutory Scheme of Arrangement

[0001730168-18-000084:notes:329]
For the period prior to the Broadcom Acquisition Date, our stockholders’ equity reflected outstanding ordinary shares of Avago. Pursuant to a Singapore statutory scheme of arrangement, Broadcom-Singapore issued 278 million shares to holders of Avago ordinary shares and issued 112 million shares to former BRCM stockholders pursuant to the Broadcom Merger. Consequently, the number of shares outstanding increased from 278 million ordinary shares on January 31, 2016 to 390 million shares on February 1, 2016. Both Avago and BRCM became indirect subsidiaries of Broadcom-Singapore and the Partnership, where Broadcom-Singapore was the sole General Partner of the Partnership. In connection with the Broadcom Merger, Broadcom-Singapore also issued 23 million special preference shares.

[0001730168-18-000084:notes:330]
Noncontrolling Interest

[0001730168-18-000084:notes:331]
As of October 29, 2017 and immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income (loss) attributable to our common stock in our consolidated statements of operations excluded the noncontrolling interest’s proportionate share of the results for periods prior to the Redomiciliation Transaction. In addition, we presented the proportionate share of equity attributable to the noncontrolling interest as a separate component of total equity within our consolidated balance sheet as of October 29, 2017 and consolidated statements of equity for the periods prior to the Redomiciliation Transaction.

[0001730168-18-000084:notes:332]
Dividends and Distributions

[0001730168-18-000084:notes:333]
Stock Repurchase Program

[0001730168-18-000084:notes:334]
In April 2018, our Board of Directors authorized the repurchase of up to $12 billion of our common stock from time to time on or prior to November 3, 2019, the end of our fiscal year 2019. During fiscal year 2018, we repurchased and retired approximately 32 million shares of our common stock for $7,258 million at a weighted average price of $227.60 under this stock repurchase program. As of November 4, 2018, $4,742 million of the current authorization remained available under our stock repurchase program.

[0001730168-18-000084:notes:335]
Repurchases under our stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and number of shares of common stock repurchased will depend on a variety of factors, including price, general business and market conditions and alternative investment opportunities. We are not obligated to repurchase any specific number of shares of common stock, and we may suspend or discontinue our stock repurchase program at any time.

[0001730168-18-000084:notes:336]
Equity Incentive Award Plans

[0001730168-18-000084:notes:337]
Stock-based incentive awards are provided to employees and directors under the terms of various Broadcom equity incentive plans.

[0001730168-18-000084:notes:338]
2009 Plan

[0001730168-18-000084:notes:339]
In July 2009, our Board of Directors adopted, and our stockholders approved, the Avago Technologies Limited 2009 Equity Incentive Award Plan, or the 2009 Plan, to authorize the grant of options, stock appreciation rights, RSUs, dividend equivalents, performance awards, and other stock-based awards. A total of 20 million shares of common stock were initially reserved for issuance under the 2009 Plan, subject to annual increases starting in fiscal year 2012. The amount of the annual increase is equal to the least of (a) 6 million shares, (b) 3% of the common stock outstanding on the last day of the immediately preceding fiscal year and (c) such smaller number of common stock as determined by our Board. However, no more than 90 million shares of common stock may be issued upon the exercise of equity awards issued under the 2009 Plan. The 2009 Plan became effective on July 27, 2009.

[0001730168-18-000084:notes:340]
Options issued to employees under the 2009 Plan prior to March 2011 generally expire ten years following the date of grant. Since March 2011, options issued to employees under the 2009 Plan generally expire seven years after the date of grant. Options awarded to non-employees under this plan generally expire after five years. Options issued to both employees and non-employees under the 2009 Plan generally vest over a four-year period from the date of grant and are granted with an exercise price equal to the fair market value on the date of grant. Any stock options cancelled or forfeited after July 27, 2009 under the equity incentive plans adopted prior to the 2009 Plan become available for issuance under the 2009 Plan.

[0001730168-18-000084:notes:341]
RSU awards granted to employees under the 2009 Plan generally vest in equal annual installments over four years. An RSU is an equity award that is granted with an exercise price equal to zero and which represents the right to receive one share of our common stock immediately upon vesting.

[0001730168-18-000084:notes:342]
As of November 4, 2018, 24 million shares remained available for issuance under the 2009 Plan.

[0001730168-18-000084:notes:343]
2003 Plan

[0001730168-18-000084:notes:344]
In connection with the acquisition of LSI Corporation, or LSI, we assumed the LSI 2003 Equity Incentive Plan, or the 2003 Plan, and outstanding unvested stock options and RSUs originally granted by LSI under the 2003 Plan that were held by continuing employees. At the time of the acquisition, these awards were converted to Broadcom stock options and RSUs, with adjustments made to the exercise price of stock options and the number of shares subject to stock options and RSU awards so that the intrinsic value of each award was approximately the same immediately before and immediately after the adjustment. These unvested options and RSUs vest in accordance with their original terms, generally vesting in equal annual installments over a four-year period from the original grant date. Options expire seven years after the grant date. Under the 2003 Plan, we may grant to former employees of LSI and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options covering more than four million shares or more than an aggregate of one million shares of restricted stock and RSUs in any fiscal year. Equity awards granted under the 2003 Plan following the LSI acquisition are expected to be on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 4, 2018, three million shares remained available for issuance under the 2003 Plan.

[0001730168-18-000084:notes:345]
2012 Plan

[0001730168-18-000084:notes:346]
In connection with the Broadcom Merger, we assumed the BRCM 2012 Stock Incentive Plan, or the 2012 Plan, and outstanding unvested RSUs originally granted by BRCM under the 2012 Plan that were held by continuing employees. At the time of the acquisition, these awards were converted to Broadcom RSUs, with adjustments made to the number of shares subject to RSU awards so that the intrinsic value of each award was approximately the same immediately before and immediately after the adjustment. These unvested RSUs vest in accordance with their original terms, generally vesting in equal quarterly installments over a four-year period from the original grant date. Under the 2012 Plan, we may grant to former employees of BRCM and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options, restricted stock or RSUs, covering more than an aggregate of four million shares in any fiscal year. Equity awards granted under the 2012 Plan following the Broadcom Merger are expected to be on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 4, 2018, 90 million shares remained available for issuance under the 2012 Plan. The number of shares available for issuance under the 2012 Plan is subject to an annual increase of 12 million shares.

[0001730168-18-000084:notes:347]
We also grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs under the 2009 Plan and 2012 Plan. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2018 and 2017, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 450% of the original grant at vesting based upon the total stockholder return, or TSR, on our common stock as compared to the TSR of an index group of companies.

[0001730168-18-000084:notes:348]
Employee Stock Purchase Plan

[0001730168-18-000084:notes:349]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or ending of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of Employee Retirement Income Security Act of 1974. The ESPP will terminate on July 27, 2019 unless sooner terminated.

[0001730168-18-000084:notes:350]
Stock-Based Compensation Expense

[0001730168-18-000084:notes:351]
| (a) | Does not include stock-based compensation related to discontinued operations recognized during fiscal years 2017 and 2016, which was included in loss from discontinued operations, net of income taxes in our consolidated statements of operations. |

[0001730168-18-000084:notes:352]
We have assumed an annualized forfeiture rate for RSUs of 5%. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated.

[0001730168-18-000084:notes:353]
As of November 4, 2018, the total unrecognized compensation cost related to unvested stock-based awards was $2,479 million, which is expected to be recognized over the remaining weighted-average service period of 2.7 years.

[0001730168-18-000084:notes:354]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-18-000084:notes:355]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-18-000084:notes:356]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-18-000084:notes:357]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-18-000084:notes:358]
Restricted Stock Unit Awards

[0001730168-18-000084:notes:359]
The aggregate fair value of time- and market-based RSUs that vested in fiscal years 2018, 2017 and 2016 was $1,516 million, $1,172 million and $590 million, respectively, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax withholding obligations due upon the vesting of RSUs.

[0001730168-18-000084:notes:360]
Stock Option Awards


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001730168-18-000084:notes:361]
Shipping and handling costs.  Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in cost of products sold in the consolidated statements of operations for all periods presented.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-18-000084:notes:362]
Summary of Significant Accounting Policies

[0001730168-18-000084:notes:363]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates, and such differences could affect the results of operations reported in future periods.

[0001730168-18-000084:notes:364]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the amount of probable credit losses in our existing accounts receivable. We determine the allowance based on customer-specific experience and the aging of such receivables, among other factors. Allowances for doubtful accounts were not material as of November 4, 2018 or October 29, 2017. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances at November 4, 2018 and October 29, 2017 were $161 million and $208 million, respectively.

[0001730168-18-000084:notes:365]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with several financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-18-000084:notes:366]
Retirement benefits. Post-retirement benefit plan assets and liabilities are estimates of benefits that we expect to pay to eligible retirees. We consider various factors in determining the value of our post-retirement net assets, including the number of employees that we expect to receive benefits and other actuarial assumptions.

[0001730168-18-000084:notes:367]
For defined benefit pension plans, we consider various factors in determining our respective pension liabilities and net periodic benefit costs, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the retirement benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-18-000084:notes:368]
The key benefit plan assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on the results of matching expected plan benefit payments with cash flows from a hypothetical yield curve constructed with high-quality corporate bond yields. The U. S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy.

[0001730168-18-000084:notes:369]
For the non-U.S. plans, we set assumptions specific to each country.

[0001730168-18-000084:notes:370]
We designate our forward contracts as either cash flow or fair value hedges. All derivatives are recognized on the consolidated balance sheets at their fair values based on Level 2 inputs as defined in the fair value hierarchy. The accounting for gains and losses resulting from changes in fair value depends on the use of the derivative and whether it is designated and qualifies for hedge accounting. For derivative instruments that are designated and qualify as fair value hedges, changes in value of the instruments are recognized in income (loss) in the current period. Such hedges are recognized in net income (loss) and are offset by the changes in fair value of the underlying assets or liabilities being hedged. For derivative instruments that are designated and qualify as cash flow hedges, changes in the value of the effective portion of the derivative instrument are recognized in accumulated other comprehensive loss, a component of stockholders’ equity. These amounts are then reclassified and recognized in net income (loss) when either the forecasted transaction affects earnings or it becomes probable the forecasted transaction will not occur. Changes in the fair value of the ineffective portion of derivative instruments are recognized in net income (loss) in the current period, which have not been material to date. Changes in the value of derivative instruments not designated as hedges are recognized in other income, net, in our consolidated statements of operations. As of November 4, 2018 and October 29, 2017, we did not have any outstanding foreign exchange forward contracts.

[0001730168-18-000084:notes:371]
Business combinations. We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition date fair values. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date including our estimates for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets under the income approach include growth in future expected cash flows from product sales, customer contracts and acquired technologies, technology obsolescence rates, expected costs to develop in-process research and development, or IPR&D, into commercially viable products, estimated cash flows from the projects when completed and discount rates. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-18-000084:notes:372]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-18-000084:notes:373]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-18-000084:notes:374]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-18-000084:notes:375]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units, or RSUs, using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for time-based stock options and employee stock purchase plan rights under the Broadcom Limited Second Amended and Restated Employee Share Purchase Plan, as amended, or ESPP, based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-18-000084:notes:376]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-18-000084:notes:377]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-18-000084:notes:378]
Reclassifications. Certain reclassifications have been made to the prior period consolidated balance sheet and statements of cash flows. These reclassifications have no impact on the previously reported net assets or net cash activities.


## us-gaap:SubsequentEventsTextBlock

[0001730168-18-000084:notes:379]
Subsequent Events

[0001730168-18-000084:notes:380]
Acquisition of CA, Inc.

[0001730168-18-000084:notes:381]
On November 5, 2018, we completed our acquisition, or the CA Merger, of CA, Inc., or CA. We assumed all unvested CA stock options, outstanding restricted stock awards, restricted stock units and performance stock units held by continuing employees. All vested in-the-money CA stock options and director stock units were cashed out upon the completion of the CA Merger. CA was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities.

[0001730168-18-000084:notes:382]
Preliminary Purchase Consideration

[0001730168-18-000084:notes:383]
|  |  | (In millions) |
| Cash paid for outstanding CA common stock |  | $ | 18,402 |  |
| Cash paid by Broadcom to retire CA’s term loan |  | 274 |  |
| Cash paid for vested CA equity awards |  | 77 |  |
| Fair value of partially vested assumed equity awards |  | 91 |  |
| Total purchase consideration |  | $ | 18,844 |  |

[0001730168-18-000084:notes:384]
We financed the CA Merger with the net proceeds from borrowings under the 2019 Term Loans, as discussed in further detail below, as well as cash on hand of the combined companies. We assumed $2.25 billion of CA’s outstanding senior unsecured notes.

[0001730168-18-000084:notes:385]
We are currently evaluating the purchase price allocation following the consummation of the CA Merger. It is not practicable to disclose the preliminary purchase price allocation or unaudited pro forma combined financial information for this transaction, given the short period of time between the acquisition date and the issuance of these consolidated financial statements.

[0001730168-18-000084:notes:386]
2019 Term Loans

[0001730168-18-000084:notes:387]
In connection with the completion of the CA Merger, on November 5, 2018, we entered into a credit agreement, or the 2019 Credit Agreement, which provides for a $5 billion unsecured revolving credit facility, or the Revolving Facility, a $9 billion unsecured term A-3 facility, or the Term A-3 Loan, and a $9 billion unsecured term A-5 facility, or the Term A-5 Loan, and together with the Term A-3 Loan, referred to as the 2019 Term Loans. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited and Broadcom-Singapore.

[0001730168-18-000084:notes:388]
The term loans under the Term A-3 Loan and Term A-5 Loan have variable interest rates and will mature and be payable in full on the third or fifth anniversary, respectively. The Revolving Facility is a five-year unsecured revolving facility. Initially, the aggregate commitment is equal to $5 billion, of which $500 million is available for the issuance of multicurrency letters of credit. The issuance of letters of credit reduces the aggregate amount otherwise available under the Revolving Facility for the making of revolving loans. Subject to the terms of the 2019 Credit Agreement, we may borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) the fifth anniversary, and (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on November 5, 2018.

[0001730168-18-000084:notes:389]
In connection with the CA Merger, we entered into a definitive agreement to sell Veracode, Inc., a wholly owned subsidiary of CA and provider of application security testing solutions, to Thoma Bravo, LLC for cash consideration of $950 million, subject to customary closing conditions.

[0001730168-18-000084:notes:390]
Stock Repurchase Authorization

[0001730168-18-000084:notes:391]
On December 5, 2018, our Board of Directors increased our current stock repurchase program authorization by $6 billion. The repurchase authorization is effective through November 3, 2019, the end of Broadcom’s fiscal year 2019.

[0001730168-18-000084:notes:392]
Cash Dividends Declared

[0001730168-18-000084:notes:393]
On December 6, 2018, we announced that our Board of Directors has declared a cash dividend of $2.65 per share, payable on December 28, 2018 to stockholders of record on December 19, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-18-000084:notes:394]
Supplemental Financial Information

[0001730168-18-000084:notes:395]
Cash and Cash Equivalents

[0001730168-18-000084:notes:396]
Cash equivalents included $1,406 million and $6,002 million of time deposits as of November 4, 2018 and October 29, 2017, respectively. As of November 4, 2018 and October 29, 2017, cash equivalents also included $202 million and $401 million, respectively, of money-market funds. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-18-000084:notes:397]
Accounts Receivable Factoring

[0001730168-18-000084:notes:398]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring agreements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring agreements were $362 million and $178 million during fiscal years 2018 and 2017, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any period presented.

[0001730168-18-000084:notes:399]
Inventory

[0001730168-18-000084:notes:400]
Property, Plant and Equipment, Net

[0001730168-18-000084:notes:401]
Depreciation expense was $515 million, $451 million and $402 million for fiscal years 2018, 2017 and 2016, respectively.

[0001730168-18-000084:notes:402]
As of November 4, 2018 and October 29, 2017, we had $22 million and $122 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable and other current liabilities. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the consolidated statements of cash flows in the period in which they are paid.

[0001730168-18-000084:notes:403]
Other Current Assets

[0001730168-18-000084:notes:404]
Other Current Liabilities

[0001730168-18-000084:notes:405]
Other Long-Term Liabilities

[0001730168-18-000084:notes:406]
(a) Refer to Note 10. “Income Taxes” for additional information regarding these balances.

[0001730168-18-000084:notes:407]
(b) Includes accrued interest and penalties.

[0001730168-18-000084:notes:408]
Accumulated Other Comprehensive Loss

[0001730168-18-000084:notes:409]
(a) Relates to amortization of actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans and are included in the computation of net periodic benefit (income) cost (refer to Note 7. “Retirement Plans and Post-Retirement Benefits” for additional information).

[0001730168-18-000084:notes:410]
Other Income, Net

[0001730168-18-000084:notes:411]
Other income includes gains (losses) on foreign currency remeasurement and other miscellaneous items.
