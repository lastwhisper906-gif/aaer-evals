# AVGO 8-K — 0001193125-18-343743 filed 2018-12-06

## item codes, every 8-K on or before 2018-12-21

- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2018-12-21

- none on or before 2018-12-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-343743:8k_2_02:1]
EX-99.1
6
d665420dex991.htm
EX-99.1

[0001193125-18-343743:8k_2_02:2]
EX-99.1

[0001193125-18-343743:8k_2_02:3]
Exhibit 99.1

[0001193125-18-343743:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2018 Financial Results

[0001193125-18-343743:8k_2_02:5]
and Quarterly Dividend

[0001193125-18-343743:8k_2_02:6]
|  | • |  | Revenue of $5,444 million for the fourth quarter, up 12 percent from the prior year |

[0001193125-18-343743:8k_2_02:7]
|  | • |  | Revenue of $20,848 million for the fiscal year, up 18 percent from the prior year |

[0001193125-18-343743:8k_2_02:8]
|  | • |  | Non-GAAP diluted EPS of $5.85 for the fourth quarter, up 27 percent from the prior year; GAAP diluted EPS of $2.64 for the fourth quarter, up 111 percent from the prior year |

[0001193125-18-343743:8k_2_02:9]
|  | • |  | Non-GAAP diluted EPS of $20.82 for the fiscal year, up 30 percent from the prior year; GAAP diluted EPS for the fiscal year of $28.44, up 607 percent from the prior year |

[0001193125-18-343743:8k_2_02:10]
|  | • |  | Free cash flow for the fourth quarter of $2,529 million, up 47 percent from the prior year |

[0001193125-18-343743:8k_2_02:11]
|  | • |  | Free cash flow for the fiscal year of $8,245 million, up 50 percent from the prior year |

[0001193125-18-343743:8k_2_02:12]
|  | • |  | Quarterly dividend increased by 51 percent to $2.65 per share from the prior quarter |

[0001193125-18-343743:8k_2_02:13]
|  | • |  | Repurchased 6.4 million shares in the fourth quarter for $1,533 million |

[0001193125-18-343743:8k_2_02:14]
|  | • |  | Repurchased 31.9 million shares in the fiscal year for $7,258 million |

[0001193125-18-343743:8k_2_02:15]
SAN JOSE, Calif. – December 6, 2018 - Broadcom Inc. (Nasdaq:
AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for the fourth fiscal quarter and fiscal year ended November 4, 2018, and
provided guidance for its fiscal year 2019. The Company completed its acquisition of CA Technologies on November 5, 2018. The financial results provided below do not include any contribution from CA Technologies.

[0001193125-18-343743:8k_2_02:16]
“Strong operating performance in the fiscal fourth quarter caps a year of solid results that continues to reinforce the sustainability of our business
model. Revenues grew 18% to nearly $21 billion on the back of strong demand for our networking, enterprise storage, wireless and industrial products while operating margin continued to progressively expand to 50%.” said Hock Tan, President
and CEO of Broadcom Inc. “Looking forward to fiscal year 2019, we expect another year of double digit revenue growth. Sustained demand within our semiconductor segment will be augmented by the newly acquired mainframe and enterprise software
businesses to our infrastructure software segment. We also expect operating margin to hit another record in fiscal year 2019 driven by improved operating leverage.”

[0001193125-18-343743:8k_2_02:17]
“Free cash flow from operations grew 50% in fiscal year 2018 to $8.2 billion. As a result, we are raising our target dividend by 51 percent to
$2.65 per share per quarter for fiscal year 2019,” said Tom Krause, CFO of Broadcom Inc. “Looking ahead for the year, we expect sustained revenue growth and improving operating leverage to accelerate cash generation from operations. Our
capital allocation strategy remains unchanged for fiscal year 2019. We plan to return 50% of our prior fiscal year free cash flows to stockholders in the form of dividends and use the balance of our free cash flows to buy back stock and support
additional acquisitions, while remaining focused on maintaining our investment grade credit rating.”

[0001193125-18-343743:8k_2_02:18]
1

[0001193125-18-343743:8k_2_02:19]
Fourth Quarter Fiscal Year 2018 GAAP Results from Continuing Operations

[0001193125-18-343743:8k_2_02:20]
Net revenue was $5,444 million, an increase of 8 percent from $5,063 million in the previous quarter and an increase of 12 percent from
$4,844 million in the same quarter last year.

[0001193125-18-343743:8k_2_02:21]
Gross margin was $2,935 million, or 53.9 percent of net revenue. This compares with gross
margin of $2,619 million, or 51.7 percent of net revenue, in the prior quarter, and gross margin of $2,383 million, or 49.2 percent of net revenue, in the same quarter last year.

[0001193125-18-343743:8k_2_02:22]
Operating expenses were $1,283 million. This compares with $1,280 million in the prior quarter and $1,628 million in the same quarter last
year.

[0001193125-18-343743:8k_2_02:23]
Operating income was $1,652 million, or 30.3 percent of net revenue. This compares with operating income of $1,339 million, or
26.4 percent of net revenue, in the prior quarter, and operating income of $755 million, or 15.6 percent of net revenue, in the same quarter last year.

[0001193125-18-343743:8k_2_02:24]
Net income, which includes the impact of discontinued operations, was $1,115 million, or $2.64 per diluted share. This compares with net income of
$1,196 million, or $2.71 per diluted share, in the prior quarter, and net income of $561 million, or $1.25 per diluted share, in the same quarter last year.

[0001193125-18-343743:8k_2_02:25]
| Fourth Quarter Fiscal Year 2018 GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q4 18 |  |  | Q3 18 |  |  | Q4 17 |  |  | Q/Q |  |  | Y/Y |  |
| Net revenue |  | $ | 5,444 |  |  | $ | 5,063 |  |  | $ | 4,844 |  |  |  |  |  | +8 | % |  |  |  |  | +12 | % |
| Gross margin |  |  | 53.9 | % |  |  | 51.7 | % |  |  | 49.2 | % |  |  |  |  | +220bps |  |  |  |  |  | +470bps |  |
| Operating expenses |  | $ | 1,283 |  |  | $ | 1,280 |  |  | $ | 1,628 |  |  | +$ |  |  | 3 |  |  | -$ |  |  | 345 |  |
| Net income |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 561 |  |  | -$ |  |  | 81 |  |  | +$ |  |  | 554 |  |
| Net income attributable to noncontrolling interest |  | $ | — |  |  | $ | — |  |  | $ | 29 |  |  | $ |  |  | — |  |  | -$ |  |  | 29 |  |
| Net income attributable to common stock |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 532 |  |  | -$ |  |  | 81 |  |  | +$ |  |  | 583 |  |
| Earnings per share - diluted |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 1.25 |  |  | -$ |  |  | 0.07 |  |  | +$ |  |  | 1.39 |  |

[0001193125-18-343743:8k_2_02:26]
The Company’s cash and cash equivalents at the end of the fourth fiscal quarter were $4,292 million, compared to
$4,136 million at the end of the prior quarter.

[0001193125-18-343743:8k_2_02:27]
During the fourth fiscal quarter, the Company generated $2,635 million in cash from operations
and spent $1,533 million repurchasing an aggregate of 6.4 million shares and $106 million in capital expenditures.

[0001193125-18-343743:8k_2_02:28]
On September 28,
2018, the Company paid a cash dividend of $1.75 per share of common stock, totaling $723 million.

[0001193125-18-343743:8k_2_02:29]
2

[0001193125-18-343743:8k_2_02:30]
Fourth Quarter Fiscal Year 2018 Non-GAAP Results From Continuing
Operations

[0001193125-18-343743:8k_2_02:31]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001193125-18-343743:8k_2_02:32]
Net revenue from continuing operations was $5,448 million, an increase of 8 percent from $5,066 million in the previous quarter, and an
increase of 12 percent from $4,848 million in the same quarter last year.

[0001193125-18-343743:8k_2_02:33]
Gross margin from continuing operations was $3,725 million, or
68.4 percent of net revenue. This compares with gross margin from continuing operations of $3,410 million, or 67.3 percent of net revenue, in the prior quarter, and $3,068 million, or 63.3 percent of net revenue, in the same
quarter last year.

[0001193125-18-343743:8k_2_02:34]
Operating income from continuing operations was $2,862 million, or 52.5 percent of net revenue. This compares with operating
income from continuing operations of $2,536 million, or 50.1 percent of net revenue, in the prior quarter, and $2,293 million, or 47.3 percent of net revenue, in the same quarter last year.

[0001193125-18-343743:8k_2_02:35]
Net income from continuing operations was $2,546 million, or $5.85 per diluted share. This compares with net income of $2,257 million, or $4.98 per
diluted share, in the prior quarter, and net income of $2,091 million, or $4.59 per diluted share, in the same quarter last year.

[0001193125-18-343743:8k_2_02:36]
Free cash flow
from operations, defined as cash from operations less capital expenditures, was $2,529 million in the quarter, compared to $1,726 million in the same quarter last year.

[0001193125-18-343743:8k_2_02:37]
| Fourth Quarter Fiscal Year 2018 Non-GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q4 18 |  |  | Q3 18 |  |  | Q4 17 |  |  | Q/Q |  |  | Y/Y |  |
| Net revenue |  | $ | 5,448 |  |  | $ | 5,066 |  |  | $ | 4,848 |  |  |  | +8 | % |  |  | +12 | % |
| Gross margin |  |  | 68.4 | % |  |  | 67.3 | % |  |  | 63.3 | % |  |  | +110bps |  |  |  | +510bps |  |
| Operating expenses |  | $ | 863 |  |  | $ | 874 |  |  | $ | 775 |  |  |  | -$ 11 |  |  | +$ | 88 |  |
| Net income |  | $ | 2,546 |  |  | $ | 2,257 |  |  | $ | 2,091 |  |  |  | +$ 289 |  |  | +$ | 455 |  |
| Earnings per share - diluted |  | $ | 5.85 |  |  | $ | 4.98 |  |  | $ | 4.59 |  |  |  | +$ 0.87 |  |  | +$ | 1.26 |  |

[0001193125-18-343743:8k_2_02:38]
3

[0001193125-18-343743:8k_2_02:39]
Other Quarterly Data

[0001193125-18-343743:8k_2_02:40]
| Net revenue by segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q4 18 |  |  | Q3 18 |  |  | Q4 17 |  |  | Q/Q |  |  | Y/Y |  |
| Wired infrastructure |  | $ | 2,208 |  |  |  | 41 | % |  | $ | 2,297 |  |  |  | 45 | % |  | $ | 2,146 |  |  |  | 45 | % |  |  | -4 | % |  |  | 3 | % |
| Wireless communications |  |  | 1,698 |  |  |  | 31 |  |  |  | 1,288 |  |  |  | 25 |  |  |  | 1,796 |  |  |  | 37 |  |  |  | 32 | % |  |  | -5 | % |
| Enterprise storage |  |  | 1,266 |  |  |  | 23 |  |  |  | 1,253 |  |  |  | 25 |  |  |  | 645 |  |  |  | 13 |  |  |  | 1 | % |  |  | 96 | % |
| Industrial & other |  |  | 272 |  |  |  | 5 |  |  |  | 225 |  |  |  | 5 |  |  |  | 257 |  |  |  | 5 |  |  |  | 21 | % |  |  | 6 | % |
| Total net revenue |  | $ | 5,444 |  |  |  | 100 | % |  | $ | 5,063 |  |  |  | 100 | % |  | $ | 4,844 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-18-343743:8k_2_02:41]
| Non-GAAP net revenue by segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q4 18 |  |  | Q3 18 |  |  | Q4 17 |  |  | Q/Q |  |  | Y/Y |  |
| Wired infrastructure (1) |  | $ | 2,212 |  |  |  | 41 | % |  | $ | 2,300 |  |  |  | 45 | % |  | $ | 2,150 |  |  |  | 45 | % |  |  | -4 | % |  |  | 3 | % |
| Wireless communications |  |  | 1,698 |  |  |  | 31 |  |  |  | 1,288 |  |  |  | 25 |  |  |  | 1,796 |  |  |  | 37 |  |  |  | 32 | % |  |  | -5 | % |
| Enterprise storage |  |  | 1,266 |  |  |  | 23 |  |  |  | 1,253 |  |  |  | 25 |  |  |  | 645 |  |  |  | 13 |  |  |  | 1 | % |  |  | 96 | % |
| Industrial & other |  |  | 272 |  |  |  | 5 |  |  |  | 225 |  |  |  | 5 |  |  |  | 257 |  |  |  | 5 |  |  |  | 21 | % |  |  | 6 | % |
| Total non-GAAP net revenue |  | $ | 5,448 |  |  |  | 100 | % |  | $ | 5,066 |  |  |  | 100 | % |  | $ | 4,848 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-18-343743:8k_2_02:42]
|  | (1) | Non-GAAP data include the effect of acquisition-related purchase accounting adjustments relating to licensing revenue. |

[0001193125-18-343743:8k_2_02:43]
| Key Statistics |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 18 |  |  | Q3 18 |  |  | Q4 17 |  |
| Cash from operations |  | $ | 2,635 |  |  | $ | 2,247 |  |  | $ | 1,959 |  |
| Depreciation |  | $ | 132 |  |  | $ | 129 |  |  | $ | 117 |  |
| Amortization of acquisition-related intangible assets |  | $ | 829 |  |  | $ | 830 |  |  | $ | 1,099 |  |
| Capital expenditures |  | $ | 106 |  |  | $ | 120 |  |  | $ | 233 |  |
| Days sales outstanding (“DSO”) |  |  | 56 |  |  |  | 54 |  |  |  | 46 |  |
| Inventory days on hand (“DOH”) |  |  | 59 |  |  |  | 66 |  |  |  | 73 |  |
| Non-GAAP DSO |  |  | 56 |  |  |  | 54 |  |  |  | 46 |  |
| Non-GAAP Inventory DOH |  |  | 59 |  |  |  | 67 |  |  |  | 74 |  |

[0001193125-18-343743:8k_2_02:44]
Fiscal Year 2018 Financial Results From Continuing Operations

[0001193125-18-343743:8k_2_02:45]
Net revenue from continuing operations was $20,848 million, an increase of 18 percent from $17,636 million in the prior year. Gross margin was
$10,733 million, or 51.5 percent of net revenue, versus $8,509 million, or 48.2 percent of net revenue, in the prior year. Operating income was $5,135 million compared with $2,383 million in the prior year. Net income,
which includes the impact from discontinued operations, was $12,610 million, or $28.44 per diluted share. This compares with a net income of $1,784 million, or $4.02 per diluted share, in fiscal year 2017.

[0001193125-18-343743:8k_2_02:46]
4

[0001193125-18-343743:8k_2_02:47]
| Fiscal Year 2018 GAAP Results |  |  |  |  |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | 2018 |  |  | 2017 |  |  | Change |  |
| Net revenue |  | $ | 20,848 |  |  | $ | 17,636 |  |  |  | +18 | % |
| Gross margin |  |  | 51.5 | % |  |  | 48.2 | % |  |  | +330bps |  |
| Operating expenses |  | $ | 5,598 |  |  | $ | 6,126 |  |  | -$ | 528 |  |
| Net income |  | $ | 12,610 |  |  | $ | 1,784 |  |  | +$ | 10,826 |  |
| Net income attributable to noncontrolling interest |  | $ | 351 |  |  | $ | 92 |  |  | +$ | 259 |  |
| Net income attributable to common stock |  | $ | 12,259 |  |  | $ | 1,692 |  |  | +$ | 10,567 |  |
| Earnings per share - diluted |  | $ | 28.44 |  |  | $ | 4.02 |  |  | +$ | 24.42 |  |

[0001193125-18-343743:8k_2_02:48]
Non-GAAP net revenue from continuing operations was $20,862 million, an
increase of 18 percent from $17,665 million in the prior year. Non-GAAP gross margin was $13,931 million, or 66.8 percent of net revenue, versus $11,137 million, or
63.0 percent of net revenue, in the prior year. Non-GAAP operating income from continuing operations was $10,424 million. This compares with $8,011 million in the prior year. Non-GAAP net income was $9,391 million, or $20.82 per diluted share. This compares with non-GAAP net income of $7,255 million,
or $16.02 per diluted share, in fiscal year 2017.

[0001193125-18-343743:8k_2_02:49]
| Fiscal Year 2018 Non-GAAP Results |  |  |  |  |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | 2018 |  |  | 2017 |  |  | Change |  |
| Net revenue |  | $ | 20,862 |  |  | $ | 17,665 |  |  |  | +18 | % |
| Gross margin |  |  | 66.8 | % |  |  | 63.0 | % |  |  | +380bps |  |
| Operating expenses |  | $ | 3,507 |  |  | $ | 3,126 |  |  | +$ | 381 |  |
| Net income |  | $ | 9,391 |  |  | $ | 7,255 |  |  | +$ | 2,136 |  |
| Earnings per share - diluted |  | $ | 20.82 |  |  | $ | 16.02 |  |  | +$ | 4.81 |  |

[0001193125-18-343743:8k_2_02:50]
Fiscal Year 2019 Business Outlook

[0001193125-18-343743:8k_2_02:51]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2019, ending November 3, 2019, including
contributions from CA, is expected to be as follows:

[0001193125-18-343743:8k_2_02:52]
|  |  | GAAP |  |  | Reconciling Items |  |  | Non-GAAP |  |
| Net revenue |  | $ | 24,500M |  |  |  | — |  |  | $ | 24,500M |  |
| Operating margin |  |  | 20 | % |  | $ | 7,580M |  |  |  | 51 | % |
| Net interest expense and other |  | $ | 1,250M |  |  |  | — |  |  | $ | 1,250M |  |
| Provision for income taxes |  |  | 13 | % |  |  | 2 | % |  |  | 11 | % |

[0001193125-18-343743:8k_2_02:53]
| • |  | Non-GAAP operating margin excludes $4,700 million of amortization of acquisition-related intangible assets, $2,100 million of stock-based compensation expense, $570 million of restructuring charges, and $210 million of acquisition-related costs; and |

[0001193125-18-343743:8k_2_02:54]
5

[0001193125-18-343743:8k_2_02:55]
| • |  | Non-GAAP tax provision is 2% lower than GAAP due to the tax effects of the projected reconciling items noted above. |

[0001193125-18-343743:8k_2_02:56]
Capital expenditures for the fiscal year are expected to be approximately
$550 million. For the fiscal year, depreciation is expected to be $600 million and amortization is expected to be approximately $4,700 million.

[0001193125-18-343743:8k_2_02:57]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. Among other things, this guidance
is based on an initial estimate of purchase accounting adjustments and allocations, all of which are subject to revision. The guidance excludes the impact of any mergers, acquisitions, divestiture and stock repurchase activity that may occur during
fiscal year 2019. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future
events or otherwise, except as required by law.

[0001193125-18-343743:8k_2_02:58]
Quarterly Dividend

[0001193125-18-343743:8k_2_02:59]
The Company’s Board of Directors has approved a quarterly cash dividend of $2.65 per share.

[0001193125-18-343743:8k_2_02:60]
The dividend is payable on December 28, 2018 to stockholders of record at the close of business (5:00 p.m.) Eastern Time on December 19, 2018.

[0001193125-18-343743:8k_2_02:61]
Financial Results Conference Call

[0001193125-18-343743:8k_2_02:62]
Broadcom Inc. will
host a conference call to review its financial results for the fourth quarter of fiscal year 2018, ended November 4, 2018, and to provide guidance for fiscal year 2019, today at 2:00 p.m. Pacific Time. Those wishing to access the call should
dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 8281408. A replay of the call will be accessible for one week after the call. To access the replay
dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 8281408. A webcast of the conference call will also be available in the
“Investors” section of Broadcom’s website at www.broadcom.com.

[0001193125-18-343743:8k_2_02:63]
Basis of Presentation

[0001193125-18-343743:8k_2_02:64]
Broadcom Inc. is the successor to Broadcom Limited for financial reporting purposes effective as of the close of trading on April 4, 2018. Information
provided for fiscal periods beginning with the fiscal quarter ended May 6, 2018, relates to Broadcom Inc. and for prior fiscal periods relates to Broadcom Limited. Unless the context otherwise requires, references in this press release to
“Broadcom,” “the Company,” “we,” “our,” “us” and similar terms are to Broadcom Inc. from and after the effective time of the redomiciliation and, prior to that time, are to our predecessor, Broadcom
Limited.

[0001193125-18-343743:8k_2_02:65]
6

[0001193125-18-343743:8k_2_02:66]
The Company’s financial results include contributions from Brocade Communication Systems’
continuing operations starting in the first fiscal quarter of 2018. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented
below, unless otherwise stated.

[0001193125-18-343743:8k_2_02:67]
Due to the Company’s 52/53 week reporting cycle, fiscal year 2018 included an extra week in the first quarter,
compared to fiscal year 2017.

[0001193125-18-343743:8k_2_02:68]
Non-GAAP Financial Measures

[0001193125-18-343743:8k_2_02:69]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash
flow and other data on a non-GAAP basis. This non-GAAP information includes the effect, where applicable, of purchase accounting on revenue, and excludes amortization of
acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements,
impairment on investment, debt-related costs, gain (loss) on extinguishment of debt, gain (loss) on acquisition-related assets, income (loss) from discontinued operations and non-GAAP tax reconciling
adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for
purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted
business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The
exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring,
infrequent or unusual. Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not
consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-18-343743:8k_2_02:70]
Broadcom believes this non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s
on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a substitute for, or
superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press
release.

[0001193125-18-343743:8k_2_02:71]
7

[0001193125-18-343743:8k_2_02:72]
About Broadcom Inc.

[0001193125-18-343743:8k_2_02:73]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad
range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, software, broadband, wireless, storage and industrial.

[0001193125-18-343743:8k_2_02:74]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-18-343743:8k_2_02:75]
Particular uncertainties that could
materially affect future results include risks associated with: our acquisition of CA, including (1) potential difficulties in employee retention, (2) unexpected costs, charges or expenses, and (3) our ability to successfully
integrate CA’s business and achieve the anticipated benefits of the transaction; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and
outsourced supply chain; our dependency on a limited number of suppliers; any other acquisitions we may make, including integrating acquired companies with our existing businesses and our ability to achieve the benefits, growth prospects and
synergies expected by such acquisitions; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our significant indebtedness, including the additional indebtedness that we incurred in
connection with the CA acquisition and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors of our products; dependence on senior management; quarterly and annual
fluctuations in operating results; global economic conditions and concerns; the amount and frequency of our stock repurchases; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue
achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities or other significant operations; our ability to improve our manufacturing
efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve

[0001193125-18-343743:8k_2_02:76]
8

[0001193125-18-343743:8k_2_02:77]
gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments,
platforms or third-party products; our ability to enter into satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any
expenses or reputational damage associated with resolving customer product warranty and indemnification claims; our ability to sell to new types of customers and to keep pace with technological advances; market acceptance of the end products into
which our products are designed; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax
concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001193125-18-343743:8k_2_02:78]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may
affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made
in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-18-343743:8k_2_02:79]
Contact:

[0001193125-18-343743:8k_2_02:80]
Beatrice F. Russotto

[0001193125-18-343743:8k_2_02:81]
Investor Relations

[0001193125-18-343743:8k_2_02:82]
408-433-8000

[0001193125-18-343743:8k_2_02:83]
investor.relations@broadcom.com

[0001193125-18-343743:8k_2_02:84]
9

[0001193125-18-343743:8k_2_02:85]
BROADCOM INC.

[0001193125-18-343743:8k_2_02:86]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-18-343743:8k_2_02:87]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-18-343743:8k_2_02:88]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 4,2018 |  |  | August 5,2018 |  |  | October 29,2017 |  |  | November 4,2018 |  |  | October 29,2017 |  |
| Net revenue |  | $ | 5,444 |  |  | $ | 5,063 |  |  | $ | 4,844 |  |  | $ | 20,848 |  |  | $ | 17,636 |  |
| Cost of products sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  |  | 1,746 |  |  |  | 1,680 |  |  |  | 1,798 |  |  |  | 7,021 |  |  |  | 6,593 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 70 |  |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  |  | 762 |  |  |  | 762 |  |  |  | 658 |  |  |  | 3,004 |  |  |  | 2,511 |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |  |  | 20 |  |  |  | 19 |  |
| Total cost of products sold |  |  | 2,509 |  |  |  | 2,444 |  |  |  | 2,461 |  |  |  | 10,115 |  |  |  | 9,127 |  |
| Gross margin |  |  | 2,935 |  |  |  | 2,619 |  |  |  | 2,383 |  |  |  | 10,733 |  |  |  | 8,509 |  |
| Research and development |  |  | 948 |  |  |  | 959 |  |  |  | 828 |  |  |  | 3,768 |  |  |  | 3,292 |  |
| Selling, general and administrative |  |  | 237 |  |  |  | 234 |  |  |  | 194 |  |  |  | 1,056 |  |  |  | 787 |  |
| Amortization of acquisition-related intangible assets |  |  | 67 |  |  |  | 68 |  |  |  | 441 |  |  |  | 541 |  |  |  | 1,764 |  |
| Restructuring, impairment and disposal charges |  |  | 17 |  |  |  | 19 |  |  |  | 55 |  |  |  | 219 |  |  |  | 161 |  |
| Litigation settlements |  |  | 14 |  |  |  | — |  |  |  | 110 |  |  |  | 14 |  |  |  | 122 |  |
| Total operating expenses |  |  | 1,283 |  |  |  | 1,280 |  |  |  | 1,628 |  |  |  | 5,598 |  |  |  | 6,126 |  |
| Operating income |  |  | 1,652 |  |  |  | 1,339 |  |  |  | 755 |  |  |  | 5,135 |  |  |  | 2,383 |  |
| Interest expense |  |  | (148 | ) |  |  | (149 | ) |  |  | (119 | ) |  |  | (628 | ) |  |  | (454 | ) |
| Impairment on investment |  |  | (106 | ) |  |  | — |  |  |  | — |  |  |  | (106 | ) |  |  | — |  |
| Loss on debt extinguishment |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | — |  |  |  | (166 | ) |
| Other income, net |  |  | 24 |  |  |  | 39 |  |  |  | 16 |  |  |  | 144 |  |  |  | 62 |  |
| Income from continuing operations before income taxes |  |  | 1,422 |  |  |  | 1,229 |  |  |  | 645 |  |  |  | 4,545 |  |  |  | 1,825 |  |
| Provision for (benefit from) income taxes |  |  | 307 |  |  |  | 32 |  |  |  | 89 |  |  |  | (8,084 | ) |  |  | 35 |  |
| Income from continuing operations |  |  | 1,115 |  |  |  | 1,197 |  |  |  | 556 |  |  |  | 12,629 |  |  |  | 1,790 |  |
| Income (loss) from discontinued operations, net of income taxes |  |  | — |  |  |  | (1 | ) |  |  | 5 |  |  |  | (19 | ) |  |  | (6 | ) |
| Net income |  |  | 1,115 |  |  |  | 1,196 |  |  |  | 561 |  |  |  | 12,610 |  |  |  | 1,784 |  |
| Net income attributable to noncontrolling interest (1) |  |  | — |  |  |  | — |  |  |  | 29 |  |  |  | 351 |  |  |  | 92 |  |
| Net income attributable to common stock |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 532 |  |  | $ | 12,259 |  |  | $ | 1,692 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.71 |  |  | $ | 2.78 |  |  | $ | 1.29 |  |  | $ | 29.37 |  |  | $ | 4.19 |  |
| Income (loss) per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | (0.04 | ) |  |  | (0.01 | ) |
| Net income per share |  | $ | 2.71 |  |  | $ | 2.78 |  |  | $ | 1.30 |  |  | $ | 29.33 |  |  | $ | 4.18 |  |
| Diluted income per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 1.24 |  |  | $ | 28.48 |  |  | $ | 4.03 |  |
| Income (loss) per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | (0.04 | ) |  |  | (0.01 | ) |
| Net income per share |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 1.25 |  |  | $ | 28.44 |  |  | $ | 4.02 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 412 |  |  |  | 430 |  |  |  | 408 |  |  |  | 418 |  |  |  | 405 |  |
| Diluted |  |  | 423 |  |  |  | 441 |  |  |  | 424 |  |  |  | 431 |  |  |  | 421 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | $ | 23 |  |  | $ | 22 |  |  | $ | 17 |  |  | $ | 86 |  |  | $ | 64 |  |
| Research and development |  |  | 225 |  |  |  | 222 |  |  |  | 171 |  |  |  | 855 |  |  |  | 636 |  |
| Selling, general and administrative |  |  | 69 |  |  |  | 71 |  |  |  | 64 |  |  |  | 286 |  |  |  | 220 |  |
| Total stock-based compensation expense |  | $ | 317 |  |  | $ | 315 |  |  | $ | 252 |  |  | $ | 1,227 |  |  | $ | 920 |  |

[0001193125-18-343743:8k_2_02:89]
| (1) | In connection with the redomiciliation to the United States on April 4, 2018, or the Redomiciliation, all outstanding exchangeable limited partnership units, or LP Units, in Broadcom Cayman L.P. were exchanged for common stock of Broadcom on a one-for-one basis and the noncontrolling interest, or NCI, was eliminated. Net income attributable to NCI prior to the Redomiciliation represents approximately 5% of net income attributable to LP Units. |

[0001193125-18-343743:8k_2_02:90]
| (2) | For the fiscal year ended November 4, 2018 and for each fiscal year 2017 period presented, diluted income per share excluded the potentially dilutive effect of the exchange of LP Units as their effect was antidilutive. There were no LP Units outstanding during the fiscal quarters ended November 4, 2018 and August 5, 2018 due to the Redomiciliation. |

[0001193125-18-343743:8k_2_02:91]
BROADCOM INC.

[0001193125-18-343743:8k_2_02:92]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-18-343743:8k_2_02:93]
(IN MILLIONS, EXCEPT DAYS)

[0001193125-18-343743:8k_2_02:94]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 4,2018 |  |  | August 5,2018 |  |  | October 29,2017 |  |  | November 4,2018 |  |  | October 29,2017 |  |
| Net revenue on GAAP basis |  | $ | 5,444 |  |  | $ | 5,063 |  |  | $ | 4,844 |  |  | $ | 20,848 |  |  | $ | 17,636 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | 4 |  |  |  | 3 |  |  |  | 4 |  |  |  | 14 |  |  |  | 29 |  |
| Net revenue on non-GAAP basis |  | $ | 5,448 |  |  | $ | 5,066 |  |  | $ | 4,848 |  |  | $ | 20,862 |  |  | $ | 17,665 |  |
| Gross margin on GAAP basis |  | $ | 2,935 |  |  | $ | 2,619 |  |  | $ | 2,383 |  |  | $ | 10,733 |  |  | $ | 8,509 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | 4 |  |  |  | 3 |  |  |  | 4 |  |  |  | 14 |  |  |  | 29 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 70 |  |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  |  | 762 |  |  |  | 762 |  |  |  | 658 |  |  |  | 3,004 |  |  |  | 2,511 |  |
| Stock-based compensation expense |  |  | 23 |  |  |  | 22 |  |  |  | 17 |  |  |  | 86 |  |  |  | 64 |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |  | 3 |  |  |  | 20 |  |  |  | 19 |  |
| Acquisition-related costs |  |  | — |  |  |  | 2 |  |  |  | 1 |  |  |  | 4 |  |  |  | 1 |  |
| Gross margin on non-GAAP basis |  | $ | 3,725 |  |  | $ | 3,410 |  |  | $ | 3,068 |  |  | $ | 13,931 |  |  | $ | 11,137 |  |
| Research and development on GAAP basis |  | $ | 948 |  |  | $ | 959 |  |  | $ | 828 |  |  | $ | 3,768 |  |  | $ | 3,292 |  |
| Stock-based compensation expense |  |  | 225 |  |  |  | 222 |  |  |  | 171 |  |  |  | 855 |  |  |  | 636 |  |
| Acquisition-related costs |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | 6 |  |
| Research and development on non-GAAP basis |  | $ | 722 |  |  | $ | 737 |  |  | $ | 657 |  |  | $ | 2,909 |  |  | $ | 2,650 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 237 |  |  | $ | 234 |  |  | $ | 194 |  |  | $ | 1,056 |  |  | $ | 787 |  |
| Stock-based compensation expense |  |  | 69 |  |  |  | 71 |  |  |  | 64 |  |  |  | 286 |  |  |  | 220 |  |
| Acquisition-related costs |  |  | 27 |  |  |  | 26 |  |  |  | 12 |  |  |  | 172 |  |  |  | 91 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 141 |  |  | $ | 137 |  |  | $ | 118 |  |  | $ | 598 |  |  | $ | 476 |  |
| Total operating expenses on GAAP basis |  | $ | 1,283 |  |  | $ | 1,280 |  |  | $ | 1,628 |  |  | $ | 5,598 |  |  | $ | 6,126 |  |
| Amortization of acquisition-related intangible assets |  |  | 67 |  |  |  | 68 |  |  |  | 441 |  |  |  | 541 |  |  |  | 1,764 |  |
| Stock-based compensation expense |  |  | 294 |  |  |  | 293 |  |  |  | 235 |  |  |  | 1,141 |  |  |  | 856 |  |
| Restructuring, impairment and disposal charges |  |  | 17 |  |  |  | 19 |  |  |  | 55 |  |  |  | 219 |  |  |  | 161 |  |
| Litigation settlements |  |  | 14 |  |  |  | — |  |  |  | 110 |  |  |  | 14 |  |  |  | 122 |  |
| Acquisition-related costs |  |  | 28 |  |  |  | 26 |  |  |  | 12 |  |  |  | 176 |  |  |  | 97 |  |
| Total operating expenses on non-GAAP basis |  | $ | 863 |  |  | $ | 874 |  |  | $ | 775 |  |  | $ | 3,507 |  |  | $ | 3,126 |  |
| Operating income on GAAP basis |  | $ | 1,652 |  |  | $ | 1,339 |  |  | $ | 755 |  |  | $ | 5,135 |  |  | $ | 2,383 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | 4 |  |  |  | 3 |  |  |  | 4 |  |  |  | 14 |  |  |  | 29 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 70 |  |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  |  | 829 |  |  |  | 830 |  |  |  | 1,099 |  |  |  | 3,545 |  |  |  | 4,275 |  |
| Stock-based compensation expense |  |  | 317 |  |  |  | 315 |  |  |  | 252 |  |  |  | 1,227 |  |  |  | 920 |  |
| Restructuring, impairment and disposal charges |  |  | 18 |  |  |  | 21 |  |  |  | 58 |  |  |  | 239 |  |  |  | 180 |  |
| Litigation settlements |  |  | 14 |  |  |  | — |  |  |  | 110 |  |  |  | 14 |  |  |  | 122 |  |
| Acquisition-related costs |  |  | 28 |  |  |  | 28 |  |  |  | 13 |  |  |  | 180 |  |  |  | 98 |  |
| Operating income on non-GAAP basis |  | $ | 2,862 |  |  | $ | 2,536 |  |  | $ | 2,293 |  |  | $ | 10,424 |  |  | $ | 8,011 |  |
| Interest expense on GAAP basis |  | $ | (148 | ) |  | $ | (149 | ) |  | $ | (119 | ) |  | $ | (628 | ) |  | $ | (454 | ) |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 1 |  |
| Interest expense on non-GAAP basis |  | $ | (148 | ) |  | $ | (149 | ) |  | $ | (119 | ) |  | $ | (596 | ) |  | $ | (453 | ) |
| Other income, net on GAAP basis |  | $ | 24 |  |  | $ | 39 |  |  | $ | 16 |  |  | $ | 144 |  |  | $ | 62 |  |
| (Gains) losses on acquisition-related assets |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (3 | ) |  |  | (23 | ) |
| Other income, net on non-GAAP basis |  | $ | 24 |  |  | $ | 40 |  |  | $ | 16 |  |  | $ | 141 |  |  | $ | 39 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 1,422 |  |  | $ | 1,229 |  |  | $ | 645 |  |  | $ | 4,545 |  |  | $ | 1,825 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | 4 |  |  |  | 3 |  |  |  | 4 |  |  |  | 14 |  |  |  | 29 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 70 |  |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  |  | 829 |  |  |  | 830 |  |  |  | 1,099 |  |  |  | 3,545 |  |  |  | 4,275 |  |
| Stock-based compensation expense |  |  | 317 |  |  |  | 315 |  |  |  | 252 |  |  |  | 1,227 |  |  |  | 920 |  |
| Restructuring, impairment and disposal charges |  |  | 18 |  |  |  | 21 |  |  |  | 58 |  |  |  | 239 |  |  |  | 180 |  |
| Litigation settlements |  |  | 14 |  |  |  | — |  |  |  | 110 |  |  |  | 14 |  |  |  | 122 |  |
| Acquisition-related costs |  |  | 28 |  |  |  | 28 |  |  |  | 13 |  |  |  | 180 |  |  |  | 98 |  |
| Impairment on investment |  |  | 106 |  |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 1 |  |
| Loss on debt extinguishment |  |  | — |  |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 166 |  |
| (Gains) losses on acquisition-related assets |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (3 | ) |  |  | (23 | ) |
| Income before income taxes on non-GAAP basis |  | $ | 2,738 |  |  | $ | 2,427 |  |  | $ | 2,190 |  |  | $ | 9,969 |  |  | $ | 7,597 |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 307 |  |  | $ | 32 |  |  | $ | 89 |  |  | $ | (8,084 | ) |  | $ | 35 |  |
| Non-GAAP tax reconciling adjustments |  |  | (115 | ) |  |  | 138 |  |  |  | 10 |  |  |  | 8,662 |  |  |  | 307 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 192 |  |  | $ | 170 |  |  | $ | 99 |  |  | $ | 578 |  |  | $ | 342 |  |
| Net income on GAAP basis |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 561 |  |  | $ | 12,610 |  |  | $ | 1,784 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | 4 |  |  |  | 3 |  |  |  | 4 |  |  |  | 14 |  |  |  | 29 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 70 |  |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  |  | 829 |  |  |  | 830 |  |  |  | 1,099 |  |  |  | 3,545 |  |  |  | 4,275 |  |
| Stock-based compensation expense |  |  | 317 |  |  |  | 315 |  |  |  | 252 |  |  |  | 1,227 |  |  |  | 920 |  |
| Restructuring, impairment and disposal charges |  |  | 18 |  |  |  | 21 |  |  |  | 58 |  |  |  | 239 |  |  |  | 180 |  |
| Litigation settlements |  |  | 14 |  |  |  | — |  |  |  | 110 |  |  |  | 14 |  |  |  | 122 |  |
| Acquisition-related costs |  |  | 28 |  |  |  | 28 |  |  |  | 13 |  |  |  | 180 |  |  |  | 98 |  |
| Impairment on investment |  |  | 106 |  |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Debt-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 1 |  |
| Loss on debt extinguishment |  |  | — |  |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 166 |  |
| (Gains) losses on acquisition-related assets |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (3 | ) |  |  | (23 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 115 |  |  |  | (138 | ) |  |  | (10 | ) |  |  | (8,662 | ) |  |  | (307 | ) |
| Discontinued operations, net of income taxes |  |  | — |  |  |  | 1 |  |  |  | (5 | ) |  |  | 19 |  |  |  | 6 |  |
| Net income on non-GAAP basis |  | $ | 2,546 |  |  | $ | 2,257 |  |  | $ | 2,091 |  |  | $ | 9,391 |  |  | $ | 7,255 |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 423 |  |  |  | 441 |  |  |  | 424 |  |  |  | 431 |  |  |  | 421 |  |
| Non-GAAP adjustment (2) |  |  | 12 |  |  |  | 12 |  |  |  | 32 |  |  |  | 20 |  |  |  | 32 |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 435 |  |  |  | 453 |  |  |  | 456 |  |  |  | 451 |  |  |  | 453 |  |
| Inventory days on hand on GAAP basis |  |  | 59 |  |  |  | 66 |  |  |  | 73 |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustment (3) |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Inventory days on hand on non-GAAP basis |  |  | 59 |  |  |  | 67 |  |  |  | 74 |  |  |  |  |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 2,546 |  |  | $ | 2,257 |  |  | $ | 2,091 |  |  |  |  |  |  |  |  |  |
| Interest expense on non-GAAP basis |  |  | 148 |  |  |  | 149 |  |  |  | 119 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  |  | 192 |  |  |  | 170 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 132 |  |  |  | 129 |  |  |  | 117 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 3,018 |  |  | $ | 2,705 |  |  | $ | 2,426 |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 2,635 |  |  | $ | 2,247 |  |  | $ | 1,959 |  |  | $ | 8,880 |  |  | $ | 6,551 |  |
| Purchases of property, plant and equipment |  |  | (106 | ) |  |  | (120 | ) |  |  | (233 | ) |  |  | (635 | ) |  |  | (1,069 | ) |
| Free cash flow |  | $ | 2,529 |  |  | $ | 2,127 |  |  | $ | 1,726 |  |  | $ | 8,245 |  |  | $ | 5,482 |  |

[0001193125-18-343743:8k_2_02:95]
| (1) | Amounts represent licensing revenue not included in GAAP net revenue as a result of the effect of purchase accounting for acquisitions. |

[0001193125-18-343743:8k_2_02:96]
| (2) | Non-GAAP adjustment for number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. Non-GAAP adjustment also includes the impact of LP Units that are anti-dilutive on a GAAP basis for the fiscal year ended November 4, 2018 and for each fiscal year 2017 period presented. |

[0001193125-18-343743:8k_2_02:97]
| (3) | Non-GAAP adjustment for inventory days on hand represents the impact of purchase accounting on inventory, stock-based compensation expense, and acquisition-related costs. |

[0001193125-18-343743:8k_2_02:98]
BROADCOM INC.

[0001193125-18-343743:8k_2_02:99]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-18-343743:8k_2_02:100]
(IN MILLIONS)

[0001193125-18-343743:8k_2_02:101]
|  |  | November 4,2018 |  |  | October 29,2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,292 |  |  | $ | 11,204 |  |
| Trade accounts receivable, net |  |  | 3,325 |  |  |  | 2,448 |  |
| Inventory |  |  | 1,124 |  |  |  | 1,447 |  |
| Other current assets |  |  | 366 |  |  |  | 724 |  |
| Total current assets |  |  | 9,107 |  |  |  | 15,823 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,635 |  |  |  | 2,599 |  |
| Goodwill |  |  | 26,913 |  |  |  | 24,706 |  |
| Intangible assets, net |  |  | 10,762 |  |  |  | 10,832 |  |
| Other long-term assets |  |  | 707 |  |  |  | 458 |  |
| Total assets |  | $ | 50,124 |  |  | $ | 54,418 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 811 |  |  | $ | 1,105 |  |
| Employee compensation and benefits |  |  | 715 |  |  |  | 626 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 117 |  |
| Other current liabilities |  |  | 812 |  |  |  | 681 |  |
| Total current liabilities |  |  | 2,338 |  |  |  | 2,529 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 17,493 |  |  |  | 17,431 |  |
| Other long-term liabilities |  |  | 3,636 |  |  |  | 11,272 |  |
| Total liabilities |  |  | 23,467 |  |  |  | 31,232 |  |
| Equity: |  |  |  |  |  |  |  |  |
| Broadcom Inc. stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital |  |  | 23,285 |  |  |  | 20,505 |  |
| Retained earnings (accumulated deficit) |  |  | 3,487 |  |  |  | (129 | ) |
| Accumulated other comprehensive loss |  |  | (115 | ) |  |  | (91 | ) |
| Total Broadcom Inc. stockholders’ equity |  |  | 26,657 |  |  |  | 20,285 |  |
| Noncontrolling interest |  |  | — |  |  |  | 2,901 |  |
| Total equity |  |  | 26,657 |  |  |  | 23,186 |  |
| Total liabilities and equity |  | $ | 50,124 |  |  | $ | 54,418 |  |

[0001193125-18-343743:8k_2_02:102]
BROADCOM INC.

[0001193125-18-343743:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-18-343743:8k_2_02:104]
(IN MILLIONS)

[0001193125-18-343743:8k_2_02:105]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 4,2018 |  |  | August 5,2018 |  |  | October 29,2017 |  |  | November 4,2018 |  |  | October 29,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 561 |  |  | $ | 12,610 |  |  | $ | 1,784 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 836 |  |  |  | 836 |  |  |  | 1,102 |  |  |  | 3,566 |  |  |  | 4,286 |  |
| Depreciation |  |  | 132 |  |  |  | 129 |  |  |  | 117 |  |  |  | 515 |  |  |  | 451 |  |
| Stock-based compensation |  |  | 317 |  |  |  | 315 |  |  |  | 252 |  |  |  | 1,227 |  |  |  | 921 |  |
| Deferred taxes and other non-cash taxes |  |  | 242 |  |  |  | 22 |  |  |  | (74 | ) |  |  | (8,270 | ) |  |  | (173 | ) |
| Impairment on investment |  |  | 106 |  |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |
| Non-cash portion of debt extinguishment loss |  |  | — |  |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 166 |  |
| Non-cash restructuring, impairment and disposal charges |  |  | 8 |  |  |  | 3 |  |  |  | 17 |  |  |  | 21 |  |  |  | 71 |  |
| Amortization of debt issuance costs and accretion of debt discount |  |  | 6 |  |  |  | 6 |  |  |  | 5 |  |  |  | 24 |  |  |  | 24 |  |
| Other |  |  | 15 |  |  |  | 5 |  |  |  | 9 |  |  |  | 37 |  |  |  | 7 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | (312 | ) |  |  | (262 | ) |  |  | (31 | ) |  |  | (652 | ) |  |  | (267 | ) |
| Inventory |  |  | 92 |  |  |  | 19 |  |  |  | (16 | ) |  |  | 417 |  |  |  | (39 | ) |
| Accounts payable |  |  | 28 |  |  |  | (41 | ) |  |  | (63 | ) |  |  | (325 | ) |  |  | (97 | ) |
| Employee compensation and benefits |  |  | 93 |  |  |  | 205 |  |  |  | 80 |  |  |  | 6 |  |  |  | 109 |  |
| Contributions to defined benefit pension plans |  |  | — |  |  |  | (1 | ) |  |  | (345 | ) |  |  | (130 | ) |  |  | (361 | ) |
| Other current assets and current liabilities |  |  | 163 |  |  |  | (148 | ) |  |  | 80 |  |  |  | 369 |  |  |  | (490 | ) |
| Other long-term assets and long-term liabilities |  |  | (206 | ) |  |  | (37 | ) |  |  | 258 |  |  |  | (641 | ) |  |  | 159 |  |
| Net cash provided by operating activities |  |  | 2,635 |  |  |  | 2,247 |  |  |  | 1,959 |  |  |  | 8,880 |  |  |  | 6,551 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (7 | ) |  |  | (7 | ) |  |  | — |  |  |  | (4,800 | ) |  |  | (40 | ) |
| Business sale proceeds (repayments) |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | 773 |  |  |  | 10 |  |
| Purchases of property, plant and equipment |  |  | (106 | ) |  |  | (120 | ) |  |  | (233 | ) |  |  | (635 | ) |  |  | (1,069 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 1 |  |  |  | — |  |  |  | 440 |  |  |  | 239 |  |  |  | 441 |  |
| Purchases of investments |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | (249 | ) |  |  | (207 | ) |
| Proceeds from sale and maturity of investments |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  | 54 |  |  |  | 200 |  |
| Other |  |  | 3 |  |  |  | (47 | ) |  |  | (4 | ) |  |  | (56 | ) |  |  | (9 | ) |
| Net cash provided by (used in) investing activities |  |  | (118 | ) |  |  | (174 | ) |  |  | 396 |  |  |  | (4,674 | ) |  |  | (674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of long-term debt |  |  | — |  |  |  | — |  |  |  | 3,980 |  |  |  | — |  |  |  | 17,426 |  |
| Repayment of debt |  |  | (117 | ) |  |  | — |  |  |  | — |  |  |  | (973 | ) |  |  | (13,668 | ) |
| Payment of debt issuance costs |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (24 | ) |
| Dividend and distribution payments |  |  | (723 | ) |  |  | (754 | ) |  |  | (439 | ) |  |  | (2,998 | ) |  |  | (1,745 | ) |
| Repurchases of common stock |  |  | (1,533 | ) |  |  | (5,378 | ) |  |  | — |  |  |  | (7,258 | ) |  |  | — |  |
| Issuance of common stock, net of shares withheld for employee taxes |  |  | 38 |  |  |  | 6 |  |  |  | 66 |  |  |  | 156 |  |  |  | 257 |  |
| Payment of capital lease obligations |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | (21 | ) |  |  | (16 | ) |
| Other |  |  | (26 | ) |  |  | 2 |  |  |  | — |  |  |  | (24 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | (2,361 | ) |  |  | (6,124 | ) |  |  | 3,600 |  |  |  | (11,118 | ) |  |  | 2,230 |  |
| Net change in cash and cash equivalents |  |  | 156 |  |  |  | (4,051 | ) |  |  | 5,955 |  |  |  | (6,912 | ) |  |  | 8,107 |  |
| Cash and cash equivalents at the beginning of period |  |  | 4,136 |  |  |  | 8,187 |  |  |  | 5,249 |  |  |  | 11,204 |  |  |  | 3,097 |  |
| Cash and cash equivalents at end of period |  | $ | 4,292 |  |  | $ | 4,136 |  |  | $ | 11,204 |  |  | $ | 4,292 |  |  | $ | 11,204 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 2 |  |  | $ | 312 |  |  | $ | 1 |  |  | $ | 547 |  |  | $ | 310 |  |
| Cash paid for income taxes |  | $ | 189 |  |  | $ | 127 |  |  | $ | 96 |  |  | $ | 512 |  |  | $ | 349 |  |

## item 5.02 — body, verbatim

[0001193125-18-343743:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers;
Compensatory Arrangements of Certain Officers.

[0001193125-18-343743:8k_body:2]
At a regular meeting of the Board of Directors (the “Board”) of the Company
held on December 5, 2018 (the “Meeting”), James V. Diller notified the Board that he will not be standing for re-election as a director at the Company’s 2019 annual meeting of stockholders
(the “2019 Annual Meeting”). Mr. Diller also stepped down from his position as Chairman of the Board and Chairman of the Executive Committee, effective at the conclusion of the Meeting. Mr. Diller’s decision not to seek re-election and to step down as Chairman of the Board and of the Executive Committee is not due to any disagreement between Mr. Diller and Broadcom.

[0001193125-18-343743:8k_body:3]
Also on December 5, 2018, the Board elected Henry Samueli, Ph.D., an existing director, as Chairman of the Board and Chairman of the
Executive Committee, effective at the conclusion of the Meeting. Upon his election as Chairman of the Board, Dr. Samueli resigned from his position as Chief Technology Officer of the Company. Dr. Samueli also informed the Board that he
will decline all compensation for his service on the Board and as its Chairman. The unvested equity awards that the Company previously granted to Dr. Samueli will continue to vest, subject to the terms and conditions of the awards.

[0001193125-18-343743:8k_body:4]
In addition, the Board elected Eddy W. Hartenstein, an existing director, as Lead Independent Director, a newly created position, effective at
the conclusion of the Meeting. Mr. Hartenstein will continue to serve as the Chairman of the Compensation Committee and as a member of the Audit and Executive Committees.

[0001193125-18-343743:8k_body:5]
Mr. Diller will continue to serve as a director and as a member of the Compensation and Executive Committees until the 2019 Annual
Meeting. He will also continue to serve as the Chairman of the Nominating and Corporate Governance Committee.

[0001193125-18-343743:8k_body:6]
At the Meeting, the Board,
with advice from its independent compensation consultant, Compensia, Inc. (“Compensia”), also approved certain changes to amounts payable under its non-employee director compensation program,
effective immediately, as follows:

[0001193125-18-343743:8k_body:7]
Cash Compensation

[0001193125-18-343743:8k_body:8]
Previous
Annual Amount

[0001193125-18-343743:8k_body:9]
Revised
Annual Amount

[0001193125-18-343743:8k_body:10]
Board membership (payable to all non-employee
directors)

[0001193125-18-343743:8k_body:11]
$

[0001193125-18-343743:8k_body:12]
80,000

[0001193125-18-343743:8k_body:13]
$

[0001193125-18-343743:8k_body:14]
90,000

[0001193125-18-343743:8k_body:15]
Additional amounts, as applicable, payable to:

[0001193125-18-343743:8k_body:16]
Independent Chairperson of the Board

[0001193125-18-343743:8k_body:17]
$

[0001193125-18-343743:8k_body:18]
150,000

[0001193125-18-343743:8k_body:19]
$

[0001193125-18-343743:8k_body:20]
150,000

[0001193125-18-343743:8k_body:21]
Lead Independent Director

[0001193125-18-343743:8k_body:22]
N/A

[0001193125-18-343743:8k_body:23]
$

[0001193125-18-343743:8k_body:24]
100,000

[0001193125-18-343743:8k_body:25]
Chairperson of the Audit Committee

[0001193125-18-343743:8k_body:26]
$

[0001193125-18-343743:8k_body:27]
35,000

[0001193125-18-343743:8k_body:28]
$

[0001193125-18-343743:8k_body:29]
40,000

[0001193125-18-343743:8k_body:30]
Chairperson of the Compensation Committee

[0001193125-18-343743:8k_body:31]
$

[0001193125-18-343743:8k_body:32]
22,500

[0001193125-18-343743:8k_body:33]
$

[0001193125-18-343743:8k_body:34]
22,500

[0001193125-18-343743:8k_body:35]
Chairperson of the Nominating & Corporate Governance Committee

[0001193125-18-343743:8k_body:36]
$

[0001193125-18-343743:8k_body:37]
18,000

[0001193125-18-343743:8k_body:38]
$

[0001193125-18-343743:8k_body:39]
20,000

[0001193125-18-343743:8k_body:40]
Member of the Audit Committee (other than the chairperson)

[0001193125-18-343743:8k_body:41]
$

[0001193125-18-343743:8k_body:42]
12,500

[0001193125-18-343743:8k_body:43]
$

[0001193125-18-343743:8k_body:44]
15,000

[0001193125-18-343743:8k_body:45]
Member of the Compensation Committee (other than the chairperson)

[0001193125-18-343743:8k_body:46]
$

[0001193125-18-343743:8k_body:47]
10,000

[0001193125-18-343743:8k_body:48]
$

[0001193125-18-343743:8k_body:49]
10,000

[0001193125-18-343743:8k_body:50]
Member of the Nominating & Corporate Governance Committee (other than the
chairperson)

[0001193125-18-343743:8k_body:51]
$

[0001193125-18-343743:8k_body:52]
6,000

[0001193125-18-343743:8k_body:53]
$

[0001193125-18-343743:8k_body:54]
10,000

[0001193125-18-343743:8k_body:55]
Equity Compensation

[0001193125-18-343743:8k_body:56]
Annual restricted stock unit (“RSU”) award (target value)(1)

[0001193125-18-343743:8k_body:57]
$

[0001193125-18-343743:8k_body:58]
200,000

[0001193125-18-343743:8k_body:59]
$

[0001193125-18-343743:8k_body:60]
220,000

[0001193125-18-343743:8k_body:61]
(1)

[0001193125-18-343743:8k_body:62]
Grants for new directors are pro-rated, based on the expected portion
of a year served prior to the annual meeting of stockholders following the date of appointment to the Board.

[0001193125-18-343743:8k_body:63]
At the
Meeting, the Board also approved the Company’s Fiscal Year 2019 Annual Performance Bonus Plan for Executive Employees (the “Plan”), which is the Company’s performance-based annual cash incentive bonus plan for its executive
management employees for its fiscal year ending November 3, 2019. The terms of the Plan are substantially the same as the Fiscal Year 2018 Annual Performance Bonus Plan for Executive Employees, adopted in respect of the Company’s Fiscal
Year 2018, other than with regard to the applicable annual performance metrics.

[0001193125-18-343743:8k_body:64]
The disclosure under the heading “Multi-Year Equity
Grant Program” in Item 8.01 of this Current Report on Form 8-K is hereby incorporated into this Item 5.02 by reference.
