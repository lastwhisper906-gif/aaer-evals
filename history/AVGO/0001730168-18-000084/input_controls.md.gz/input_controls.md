# AVGO 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001730168-18-000084:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001730168-18-000084:item_9a:2]
Evaluation of Disclosure Controls and Procedures.

[0001730168-18-000084:item_9a:3]
Our management, with the participation of our Chief Executive Officer, or CEO, and Chief Financial Officer, or CFO, evaluated the effectiveness of Broadcom’s disclosure controls and procedures as of November 4, 2018. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to our management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the evaluation of our disclosure controls and procedures as of November 4, 2018, our CEO and CFO concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001730168-18-000084:item_9a:4]
109

[0001730168-18-000084:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting.

[0001730168-18-000084:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting.  Internal control over financial reporting is defined in Rules 13a-15(f) and 15d-15(f) promulgated under the Exchange Act as a process designed by, or under the supervision of, our principal executive and principal financial officers and effected by the Board, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with GAAP and includes those policies and procedures that:

[0001730168-18-000084:item_9a:7]
| • | pertain to the maintenance of records that in reasonable detail accurately and fairly reflect the transactions and dispositions of the assets; |

[0001730168-18-000084:item_9a:8]
| • | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with GAAP, and that receipts and expenditures of us are being made only in accordance with authorizations of management and directors; and |

[0001730168-18-000084:item_9a:9]
| • | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the financial statements. |

[0001730168-18-000084:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001730168-18-000084:item_9a:11]
Our management assessed the effectiveness of our internal control over financial reporting as of November 4, 2018. In making this assessment, our management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework (2013). Based on this assessment, our management concluded that, as of November 4, 2018, our internal control over financial reporting is effective based on those criteria.

[0001730168-18-000084:item_9a:12]
The effectiveness of our internal control over financial reporting, as of November 4, 2018 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which is included in Part II, Item 8. of this Annual Report on Form 10-K.

[0001730168-18-000084:item_9a:13]
Changes in Internal Control over Financial Reporting.

[0001730168-18-000084:item_9a:14]
No change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) occurred during the fiscal quarter ended November 4, 2018 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001730168-18-000084:item_9a:15]
110
