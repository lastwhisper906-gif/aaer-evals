# AVGO note change history — 0001730168-18-000019 → 0001730168-18-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:1]
The following table summarizes contractual obligations and commitments as of August 5, 2018 that materially changed from the end of fiscal year 2017:
  (was, 2018-06-14, similarity 0.9751):
[0001730168-18-000019:note_history:1]
The following table summarizes contractual obligations and commitments as of May 6, 2018 that materially changed from the end of fiscal year 2017:

- changed (2018-09-13):
[0001730168-18-000039:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2018(remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
|  |  | (In millions) |
| Debt principal and interest |  | $ | 21,059 |  |  | $ | 118 |  |  | $ | 566 |  |  | $ | 3,321 |  |  | $ | 1,242 |  |  | $ | 3,940 |  |  | $ | 11,872 |  |
| Purchase commitments |  | $ | 946 |  |  | $ | 823 |  |  | $ | 70 |  |  | $ | 52 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
  (was, 2018-06-14, similarity 0.9683):
[0001730168-18-000019:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2018(remainder) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 21,371 |  |  | $ | 430 |  |  | $ | 566 |  |  | $ | 3,321 |  |  | $ | 1,242 |  |  | $ | 3,940 |  |  | $ | 11,872 |  |
| Purchase commitments |  | $ | 931 |  |  | $ | 843 |  |  | $ | 69 |  |  | $ | 18 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |

- changed (2018-09-13):
[0001730168-18-000039:note_history:3]
Debt Principal and Interest. Represents principal and interest on borrowings under the 2017 Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes.
  (was, 2018-06-14, similarity 0.9609):
[0001730168-18-000019:note_history:3]
Debt Principal, Interest and Fees. Represents principal and interest on borrowings under the 2017 Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes.

- changed (2018-09-13):
[0001730168-18-000039:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 5, 2018, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,769 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 5, 2018 have been excluded from the contractual obligations table above.
  (was, 2018-06-14, similarity 0.9816):
[0001730168-18-000019:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 6, 2018, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,700 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 6, 2018 have been excluded from the contractual obligations table above.

- added (2018-09-13):
[0001730168-18-000039:note_history:5]
Lawsuits Relating to the Acquisition of CA, Inc.

- added (2018-09-13):
[0001730168-18-000039:note_history:6]
On August 3, 2018, a purported stockholder of CA commenced a putative class action lawsuit captioned Harvey v. CA, Inc., et al. against CA, the CA board of directors, Broadcom and Broadcom’s wholly owned subsidiary party to the merger agreement with CA in the United States District Court for the Southern District of New York. On August 9, 2018, another putative class action lawsuit captioned Vladimir Gusinsky Rev. Trust v. CA, Inc., et al. was filed against CA and the CA board of directors in the United States District Court for the District of Delaware, or Delaware District Court. On August 15, 2018, a third putative class action lawsuit captioned Jacob Scheiner Retirement Account v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court.  On August 22, 2018, a fourth putative class action lawsuit captioned Kenneth Gilley v. CA, Inc., et al. was filed against CA and the CA board of directors in the Delaware District Court. The Harvey and Vladimir Gusinsky Rev. Trust complaints allege violations of Sections 14(a) and 20(a) of the Exchange Act arising out of CA’s preliminary proxy statement relating to the CA Merger, filed with the SEC on July 24, 2018.  The Scheiner Retirement Account and Gilley complaints allege violations of Sections 14(a) and 20(a) of the Exchange Act and Rule 14a-9 promulgated thereunder arising out of CA’s definitive proxy statement relating to the CA Merger, filed with the SEC on August 10, 2018. The complaints assert that the preliminary proxy statement or definitive proxy statement, as applicable, contain incomplete and misleading information regarding CA’s financial projections and the financial analysis performed by Qatalyst Partners, CA’s financial advisor, as well as, for the Harvey, Scheiner Retirement Account and Gilley complaints, the sales process undertaken by CA in connection with its proposed merger with Broadcom. Plaintiffs seek to enjoin the defendants from consummating the CA Merger, or, if the CA Merger is consummated, rescission and/or damages. The plaintiffs also seek costs and fees. On September 4, 2018, the parties to each of the four lawsuits reached an agreement in principle providing for a dismissal of each of the lawsuits following the CA shareholder vote with respect to the CA Merger. In connection with this agreement, CA filed a supplement to the definitive proxy statement relating to the CA Merger.

- changed (2018-09-13):
[0001730168-18-000039:note_history:7]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleges, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral argument on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. We believe these claims are all entirely without merit and intend to vigorously defend these actions.
  (was, 2018-06-14, similarity 0.9412):
[0001730168-18-000019:note_history:7]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleges, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral argument on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. We believe these claims are all entirely without merit and intend to vigorously defend these actions.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:8]
Broadcom Inc., a Delaware corporation, is the successor to Broadcom Limited, a company organized under the laws of the Republic of Singapore, or Broadcom-Singapore. As part of the plan to cause the publicly traded parent company of Broadcom to be a Delaware corporation, or the Redomiciliation Transaction, after the close of market trading on April 4, 2018, Broadcom Inc. and Broadcom-Singapore completed a statutory scheme of arrangement under Singapore law pursuant to which all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom Inc. common stock and Broadcom-Singapore became an indirect wholly-owned subsidiary of Broadcom Inc.
  (was, 2018-06-14, similarity 0.8807):
[0001730168-18-000019:note_history:8]
Broadcom Inc., a Delaware corporation, is the successor to Broadcom Limited, a company organized under the laws of the Republic of Singapore, or Broadcom-Singapore. As part of the plan to cause the publicly traded parent company of Broadcom to be a Delaware corporation, or the Redomiciliation Transaction, after the close of market trading on April 4, 2018, Broadcom Inc. and Broadcom-Singapore completed a statutory scheme of arrangement under Singapore law, or the Scheme of Arrangement. Pursuant to the Scheme of Arrangement, all Broadcom-Singapore ordinary shares outstanding immediately prior to the effective time of the Scheme of Arrangement were exchanged on a one-for-one basis for newly issued shares of Broadcom Inc. common stock and Broadcom-Singapore became an indirect wholly-owned subsidiary of Broadcom Inc.

- changed (2018-09-13):
[0001730168-18-000039:note_history:9]
In conjunction with the Redomiciliation Transaction, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, were mandatorily exchanged, or the Mandatory Exchange, on a one-for-one basis for newly issued shares of Broadcom Inc. common stock. As a result, all limited partners of the Partnership became common stockholders of Broadcom Inc. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. Consequently, the limited partners no longer hold a noncontrolling interest in the Partnership and we subsequently deregistered the Partnership.
  (was, 2018-06-14, similarity 0.7711):
[0001730168-18-000019:note_history:9]
In conjunction with the Redomiciliation Transaction and pursuant to an amendment to the Amended and Restated Limited Partnership Agreement of Broadcom Cayman L.P., or the Partnership, all outstanding exchangeable limited partnership units, or LP Units, were mandatorily exchanged, or the Mandatory Exchange, on a one-for-one basis for newly issued shares of Broadcom Inc. common stock immediately prior to the effective time of the Scheme of Arrangement. As a result, all limited partners of the Partnership became common stockholders of Broadcom Inc. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed pursuant to Broadcom-Singapore’s governing documents upon the Mandatory Exchange of the LP Units. Consequently, the limited partners no longer hold a noncontrolling interest in the Partnership and we subsequently deregistered the Partnership.

- changed (2018-09-13):
[0001730168-18-000039:note_history:10]
The financial statements for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, relate to Broadcom-Singapore and relate to Broadcom Inc. for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom Inc. and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.
  (was, 2018-06-14, similarity 0.9826):
[0001730168-18-000019:note_history:10]
The financial statements for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, relate to Broadcom-Singapore and relate to Broadcom Inc. for the period after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom Inc. and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

- changed (2018-09-13):
[0001730168-18-000039:note_history:11]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 4, 2018, or fiscal year 2018, is a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. The first quarter of our fiscal year 2018 ended on February 4, 2018, the second quarter ended on May 6, 2018 and the third quarter ended on August 5, 2018. Our fiscal year ended October 29, 2017, or fiscal year 2017, was a 52-week fiscal year.
  (was, 2018-06-14, similarity 0.997):
[0001730168-18-000019:note_history:11]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 4, 2018, or fiscal year 2018, is a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. The first quarter of our fiscal year 2018 ended on February 4, 2018, the second quarter ended on May 6, 2018 and the third quarter ends on August 5, 2018. Our fiscal year ended October 29, 2017, or fiscal year 2017, was a 52-week fiscal year.

- changed (2018-09-13):
[0001730168-18-000039:note_history:12]
On November 17, 2017, we acquired Brocade Communications Systems, Inc., or Brocade. The unaudited condensed consolidated financial statements include the results of operations of Brocade commencing as of the acquisition date. See Note 2. “Acquisitions” for additional information.
  (was, 2018-06-14, similarity 0.9784):
[0001730168-18-000019:note_history:12]
On November 17, 2017, we acquired Brocade Communications Systems, Inc., or Brocade. The unaudited condensed consolidated financial statements include the results of operations of Brocade commencing as of the acquisition date. See Note 2. “Acquisition of Brocade” for additional information.

- changed (2018-09-13):
[0001730168-18-000039:note_history:13]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared by us in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2017 condensed consolidated balance sheet data were derived from Broadcom-Singapore’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2017 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 5, 2018 are not necessarily indicative of the results that may be expected for fiscal year 2018, or for any other future period.
  (was, 2018-06-14, similarity 0.9932):
[0001730168-18-000019:note_history:13]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared by us in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2017 condensed consolidated balance sheet data were derived from Broadcom-Singapore’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2017 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 6, 2018 are not necessarily indicative of the results that may be expected for fiscal year 2018, or for any other future period.

- changed (2018-09-13):
[0001730168-18-000039:note_history:14]
The standard allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”) or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). We plan to adopt the new standard using the modified retrospective method at the beginning of the first quarter of fiscal year 2019. We have established a cross-functional team to assess the potential impact of the new revenue standard and are on schedule in establishing new accounting policies, processes, and internal controls necessary to support the requirements of the new standard. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, the exact impact of the new standard will be dependent on facts and circumstances at adoption.
  (was, 2018-06-14, similarity 0.9774):
[0001730168-18-000019:note_history:14]
The standard allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). We plan to adopt the new standard using the modified retrospective method at the beginning of the first quarter of fiscal year 2019. We have established a cross-functional team to assess the potential impact of the new revenue standard and are on schedule in establishing new accounting policies, processes, and internal controls necessary to support the requirements of the new standard. While we are still finalizing our analysis to quantify the adoption impact of the provisions of the new standard, the exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:15]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of August 5, 2018 were as follows:
  (was, 2018-06-14, similarity 0.9796):
[0001730168-18-000019:note_history:15]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of May 6, 2018 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:16]
|  |  | As of August 5, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (123 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,604 |  |  |  |  | $ | 17,548 |  |
  (was, 2018-06-14, similarity 0.997):
[0001730168-18-000019:note_history:16]
|  |  | As of May 6, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (129 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,598 |  |  |  |  | $ | 17,548 |  |

- changed (2018-09-13):
[0001730168-18-000039:note_history:17]
2017 Senior Notes and Assumed BRCM Senior Notes
  (was, 2018-06-14, similarity 0.9767):
[0001730168-18-000019:note_history:17]
Senior Notes and Assumed BRCM Senior Notes

- changed (2018-09-13):
[0001730168-18-000039:note_history:18]
In fiscal year 2017, Broadcom Corporation, or BRCM, and Broadcom Cayman Finance Limited, or together with BRCM referred to as the Subsidiary Issuers, completed the issuance and sale of senior unsecured notes, or the 2017 Senior Notes, in an aggregate principal amount of $17,550 million. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom-Singapore and the Partnership, subject to certain release conditions described in the indentures governing the 2017 Senior Notes, or the 2017 Indentures. On April 9, 2018, Broadcom Inc., or Parent Guarantor, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. At that time, Broadcom-Singapore, a guarantor at the issuance of the 2017 Senior Notes, became an indirect wholly-owned subsidiary of Broadcom Inc. and a subsidiary guarantor, or Subsidiary Guarantor. In addition, the Partnership was released from its guarantee of the 2017 Senior Notes under each of the 2017 Indentures in accordance with their terms. Each series of 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year. As of August 5, 2018 and October 29, 2017, we accrued interest payable of $25 million and $136 million, respectively.
  (was, 2018-06-14, similarity 0.9966):
[0001730168-18-000019:note_history:18]
In fiscal year 2017, Broadcom Corporation, or BRCM, and Broadcom Cayman Finance Limited, or together with BRCM referred to as the Subsidiary Issuers, completed the issuance and sale of senior unsecured notes, or the 2017 Senior Notes, in an aggregate principal amount of $17,550 million. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom-Singapore and the Partnership, subject to certain release conditions described in the indentures governing the 2017 Senior Notes, or the 2017 Indentures. On April 9, 2018, Broadcom Inc., or Parent Guarantor, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. At that time, Broadcom-Singapore, a guarantor at the issuance of the 2017 Senior Notes, became an indirect wholly-owned subsidiary of Broadcom Inc. and a subsidiary guarantor, or Subsidiary Guarantor. In addition, the Partnership was released from its guarantee of the 2017 Senior Notes under each of the 2017 Indentures in accordance with their terms. Each series of 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year. As of May 6, 2018 and October 29, 2017, we accrued interest payable of $194 million and $136 million, respectively.

- changed (2018-09-13):
[0001730168-18-000039:note_history:19]
We were in compliance with all of the covenants related to the 2017 Senior Notes and senior unsecured notes assumed in connection with the acquisition of BRCM, or the Assumed BRCM Senior Notes, as of August 5, 2018.
  (was, 2018-06-14, similarity 0.8856):
[0001730168-18-000019:note_history:19]
We were in compliance with all of the covenants related to the 2017 Senior Notes and senior unsecured notes assumed in the connection with acquisition of BRCM, or the Assumed BRCM Senior Notes, as of May 6, 2018.

- changed (2018-09-13):
[0001730168-18-000039:note_history:20]
As a result of the Brocade Merger, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes due 2020, or the Assumed Brocade Convertible Notes. The Brocade Merger was a “fundamental change” as well as a “make-whole fundamental change” as defined under the terms of the indenture governing the Assumed Brocade Convertible Notes. Accordingly, the holders of the Assumed Brocade Convertible Notes received the right to require us to repurchase their notes for cash. In the first quarter of fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. The remaining outstanding Assumed Brocade Convertible Notes are convertible into cash at a conversion rate of $812 for each $1,000 of principal. We were in compliance with all of the covenants related to the Assumed Brocade Convertible Notes as of August 5, 2018.
  (was, 2018-06-14, similarity 0.8219):
[0001730168-18-000019:note_history:20]
As a result of the Brocade Merger, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes due 2020, or the Assumed Brocade Convertible Notes. The Brocade Merger was a “fundamental change” as well as a “make-whole fundamental change” as defined under the terms of the indenture governing the Assumed Brocade Convertible Notes. Accordingly, the holders of the Assumed Brocade Convertible Notes received the right to require us to repurchase their notes for cash. In the first quarter of fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. As of May 6, 2018, the outstanding principal amount of the Assumed Brocade Convertible Notes was $38 million. The remaining outstanding Assumed Brocade Convertible Notes are convertible into cash at a conversion rate of $812 for each $1,000 of principal. We were in compliance with all of the covenants related to the Assumed Brocade Convertible Notes as of May 6, 2018.

- changed (2018-09-13):
[0001730168-18-000039:note_history:21]
As of August 5, 2018, the estimated aggregate fair value of the 2017 Senior Notes, the Assumed BRCM Senior Notes and the Assumed Brocade Convertible Notes was $16,953 million and was primarily classified as Level 2 as we used quoted prices from less active markets.
  (was, 2018-06-14, similarity 0.982):
[0001730168-18-000019:note_history:21]
As of May 6, 2018, the estimated aggregate fair value of the 2017 Senior Notes, the Assumed BRCM Senior Notes and the Assumed Brocade Convertible Notes was $17,024 million and was primarily classified as Level 2 as we used quoted prices from less active markets.

- changed (2018-09-13):
[0001730168-18-000039:note_history:22]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of August 5, 2018 were as follows:
  (was, 2018-06-14, similarity 0.9796):
[0001730168-18-000019:note_history:22]
The future scheduled principal payments for the outstanding 2017 Senior Notes, Assumed BRCM Senior Notes and Assumed Brocade Convertible Notes as of May 6, 2018 were as follows:


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:23]
|  |  | As of August 5, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (123 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,604 |  |  |  |  | $ | 17,548 |  |
  (was, 2018-06-14, similarity 0.997):
[0001730168-18-000019:note_history:23]
|  |  | As of May 6, 2018: |  | As of October 29, 2017: |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions, except for percentages) |
| 2017 Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.375% notes due January 2020 |  | 2.615 | % |  | $ | 2,750 |  |  | 2.615 | % |  | $ | 2,750 |  |
| Fixed rate 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 2.406 | % |  | 750 |  |
| Fixed rate 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3.214 | % |  | 3,500 |  |
| Fixed rate 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 2.781 | % |  | 1,000 |  |
| Fixed rate 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 3.744 | % |  | 2,500 |  |
| Fixed rate 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 3.234 | % |  | 1,000 |  |
| Fixed rate 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4.018 | % |  | 4,800 |  |
| Fixed rate 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 3.596 | % |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  |  |  | 17,550 |  |
| Assumed BRCM Senior Notes |  |  |  |  |  |  |  |  |
| Fixed rate 2.70% notes due November 2018 |  | 2.70 | % |  | 117 |  |  | 2.70 | % |  | 117 |  |
| Fixed rate 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 2.50% - 4.50% |  |  | 22 |  |
|  |  |  |  | 139 |  |  |  |  | 139 |  |
| Assumed Brocade Convertible Notes |  |  |  |  |  |  |  |  |
| Fixed rate 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 38 |  |  |  |  | — |  |
| Total principal amount outstanding |  |  |  | 17,727 |  |  |  |  | 17,689 |  |
| Less: Unaccreted discount and unamortized debt issuance costs |  |  |  | (129 | ) |  |  |  | (141 | ) |
| Total carrying value of debt |  |  |  | $ | 17,598 |  |  |  |  | $ | 17,548 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:24]
During the fiscal quarter and three fiscal quarters ended August 5, 2018 and July 30, 2017, in the ordinary course of business, we purchased from, or sold to, entities of which one of our directors also serves or served as a director, or entities that are otherwise affiliated with one of our directors.
  (was, 2018-06-14, similarity 0.9313):
[0001730168-18-000019:note_history:24]
During the fiscal quarter and two fiscal quarters ended May 6, 2018 and April 30, 2017, in the ordinary course of business, we purchased from, or sold to, entities of which one of our directors also serves or served as a director, or entities that are otherwise affiliated with one of our directors.

- changed (2018-09-13):
[0001730168-18-000039:note_history:25]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |  | July 30, 2017 |  | August 5, 2018 |  | July 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 282 |  |  | $ | 97 |  |  | $ | 664 |  |  | $ | 245 |  |
| Total costs and expenses, including inventory purchases |  | $ | 25 |  |  | $ | 28 |  |  | $ | 92 |  |  | $ | 93 |  |
  (was, 2018-06-14, similarity 0.8864):
[0001730168-18-000019:note_history:25]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 6, 2018 |  | April 30, 2017 |  | May 6, 2018 |  | April 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 200 |  |  | $ | 71 |  |  | $ | 382 |  |  | $ | 148 |  |
| Total costs and expenses, including inventory purchases |  | $ | 31 |  |  | $ | 46 |  |  | $ | 67 |  |  | $ | 65 |  |

- changed (2018-09-13):
[0001730168-18-000039:note_history:26]
|  |  | August 5, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 79 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |
  (was, 2018-06-14, similarity 0.9756):
[0001730168-18-000019:note_history:26]
|  |  | May 6, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 76 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:27]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 5, 2018 |  | July 30, 2017 |  | August 5, 2018 |  | July 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 282 |  |  | $ | 97 |  |  | $ | 664 |  |  | $ | 245 |  |
| Total costs and expenses, including inventory purchases |  | $ | 25 |  |  | $ | 28 |  |  | $ | 92 |  |  | $ | 93 |  |
  (was, 2018-06-14, similarity 0.8864):
[0001730168-18-000019:note_history:27]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 6, 2018 |  | April 30, 2017 |  | May 6, 2018 |  | April 30, 2017 |
|  |  | (In millions) |
| Total net revenue |  | $ | 200 |  |  | $ | 71 |  |  | $ | 382 |  |  | $ | 148 |  |
| Total costs and expenses, including inventory purchases |  | $ | 31 |  |  | $ | 46 |  |  | $ | 67 |  |  | $ | 65 |  |

- changed (2018-09-13):
[0001730168-18-000039:note_history:28]
|  |  | August 5, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 79 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |
  (was, 2018-06-14, similarity 0.9756):
[0001730168-18-000019:note_history:28]
|  |  | May 6, 2018 |  | October 29, 2017 |
|  |  | (In millions) |
| Total receivables |  | $ | 76 |  |  | $ | 31 |  |
| Total payables |  | $ | 8 |  |  | $ | 12 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-09-13):
[0001730168-18-000039:note_history:29]
On September 5, 2018, our Board of Directors declared a cash dividend of $1.75 per share, payable on September 28, 2018 to stockholders of record at the close of business on September 19, 2018.
  (was, 2018-06-14, similarity 0.9009):
[0001730168-18-000019:note_history:29]
On June 6, 2018, our Board of Directors declared a cash dividend of $1.75 per share, payable on June 29, 2018 to stockholders of record at the close of business on June 20, 2018.
