# AVGO MD&A — 0001730168-23-000064


## mdna

[0001730168-23-000064:mdna:1]
[same as prior period, unchanged from 0001730168-23-000008:mdna:1]

[0001730168-23-000064:mdna:2]
[same as prior period, unchanged from 0001730168-23-000008:mdna:3]

[0001730168-23-000064:mdna:3]
[same as prior period, unchanged from 0001730168-23-000008:mdna:4]

[0001730168-23-000064:mdna:4]
[same as prior period, unchanged from 0001730168-23-000008:mdna:5]

[0001730168-23-000064:mdna:5]
[same as prior period, unchanged from 0001730168-23-000008:mdna:6]

[0001730168-23-000064:mdna:6]
Highlights during the fiscal quarter ended April 30, 2023 include the following:

[0001730168-23-000064:mdna:7]
•We generated $4,502 million of cash from operations.

[0001730168-23-000064:mdna:8]
•We paid $1,914 million in cash dividends.

[0001730168-23-000064:mdna:9]
•We repurchased $2,806 million of common stock.

[0001730168-23-000064:mdna:10]
[same as prior period, unchanged from 0001730168-23-000008:mdna:11]

[0001730168-23-000064:mdna:11]
[same as prior period, unchanged from 0001730168-23-000008:mdna:12]

[0001730168-23-000064:mdna:12]
22

[0001730168-23-000064:mdna:13]
[same as prior period, unchanged from 0001730168-23-000008:mdna:13]

[0001730168-23-000064:mdna:14]
[same as prior period, unchanged from 0001730168-23-000008:mdna:14]

[0001730168-23-000064:mdna:15]
[same as prior period, unchanged from 0001730168-23-000008:mdna:15]

[0001730168-23-000064:mdna:16]
[same as prior period, unchanged from 0001730168-23-000008:mdna:16]

[0001730168-23-000064:mdna:17]
[same as prior period, unchanged from 0001730168-23-000008:mdna:17]

[0001730168-23-000064:mdna:18]
[same as prior period, unchanged from 0001730168-23-000008:mdna:18]

[0001730168-23-000064:mdna:19]
[same as prior period, unchanged from 0001730168-23-000008:mdna:19]

[0001730168-23-000064:mdna:20]
There were no significant changes in our critical accounting estimates during the two fiscal quarters ended April 30, 2023 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2022 Annual Report on Form 10-K.

[0001730168-23-000064:mdna:21]
[same as prior period, unchanged from 0001730168-23-000008:mdna:22]

[0001730168-23-000064:mdna:22]
Fiscal Quarter and Two Fiscal Quarters Ended April 30, 2023 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 1, 2022

[0001730168-23-000064:mdna:23]
[same as prior period, unchanged from 0001730168-23-000008:mdna:21]

[0001730168-23-000064:mdna:24]
The following tables set forth our results of operations for the periods presented:

[0001730168-23-000064:mdna:25]
|  |  | Fiscal Quarter Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 6,741 |  |  | $ | 6,417 |  |  | 77 | % |  | 79 | % |
| Subscriptions and services |  | 1,992 |  |  | 1,686 |  |  | 23 |  |  | 21 |  |
| Total net revenue |  | 8,733 |  |  | 8,103 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,019 |  |  | 1,798 |  |  | 23 |  |  | 22 |  |
| Cost of subscriptions and services |  | 158 |  |  | 158 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 441 |  |  | 707 |  |  | 5 |  |  | 9 |  |
| Restructuring charges |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,618 |  |  | 2,664 |  |  | 30 |  |  | 33 |  |
| Gross margin |  | 6,115 |  |  | 5,439 |  |  | 70 |  |  | 67 |  |
| Research and development |  | 1,312 |  |  | 1,261 |  |  | 15 |  |  | 16 |  |
| Selling, general and administrative |  | 438 |  |  | 368 |  |  | 5 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 348 |  |  | 398 |  |  | 4 |  |  | 5 |  |
| Restructuring, impairment and disposal charges |  | 9 |  |  | 18 |  |  | — |  |  | — |  |
| Total operating expenses |  | 2,107 |  |  | 2,045 |  |  | 24 |  |  | 25 |  |
| Operating income |  | $ | 4,008 |  |  | $ | 3,394 |  |  | 46 | % |  | 42 | % |

[0001730168-23-000064:mdna:26]
|  |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 13,823 |  |  | $ | 12,470 |  |  | 78 | % |  | 79 | % |
| Subscriptions and services |  | 3,825 |  |  | 3,339 |  |  | 22 |  |  | 21 |  |
| Total net revenue |  | 17,648 |  |  | 15,809 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,244 |  |  | 3,567 |  |  | 24 |  |  | 23 |  |
| Cost of subscriptions and services |  | 307 |  |  | 314 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 976 |  |  | 1,437 |  |  | 5 |  |  | 9 |  |
| Restructuring charges |  | 2 |  |  | 3 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,529 |  |  | 5,321 |  |  | 31 |  |  | 34 |  |
| Gross margin |  | 12,119 |  |  | 10,488 |  |  | 69 |  |  | 66 |  |
| Research and development |  | 2,507 |  |  | 2,467 |  |  | 14 |  |  | 16 |  |
| Selling, general and administrative |  | 786 |  |  | 689 |  |  | 5 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 696 |  |  | 795 |  |  | 4 |  |  | 5 |  |
| Restructuring, impairment and disposal charges |  | 19 |  |  | 35 |  |  | — |  |  | — |  |
| Total operating expenses |  | 4,008 |  |  | 3,986 |  |  | 23 |  |  | 25 |  |
| Operating income |  | $ | 8,111 |  |  | $ | 6,502 |  |  | 46 | % |  | 41 | % |

[0001730168-23-000064:mdna:27]
[same as prior period, unchanged from 0001730168-23-000008:mdna:30]

[0001730168-23-000064:mdna:28]
[same as prior period, unchanged from 0001730168-23-000008:mdna:26]

[0001730168-23-000064:mdna:29]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 17% and 19% of our net revenue for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, and 17% and 20% of our net revenue for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively.

[0001730168-23-000064:mdna:30]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and two fiscal quarters ended April 30, 2023 and May 1, 2022. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 18% and 20% of our net revenue for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, and approximately 20% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 1, 2022. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-23-000064:mdna:31]
[same as prior period, unchanged from 0001730168-23-000008:mdna:29]

[0001730168-23-000064:mdna:32]
[same as prior period, unchanged from 0001730168-23-000008:mdna:31]

[0001730168-23-000064:mdna:33]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | April 30, 2023 |  | May 1, 2022 |  | $ Change |  | % Change |  | April 30, 2023 |  | May 1, 2022 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 6,808 |  |  | $ | 6,229 |  |  | $ | 579 |  |  | 9 | % |  | $ | 13,915 |  |  | $ | 12,102 |  |  | $ | 1,813 |  |  | 15 | % |
| Infrastructure software |  | 1,925 |  |  | 1,874 |  |  | 51 |  |  | 3 | % |  | 3,733 |  |  | 3,707 |  |  | 26 |  |  | 1 | % |
| Total net revenue |  | $ | 8,733 |  |  | $ | 8,103 |  |  | $ | 630 |  |  | 8 | % |  | $ | 17,648 |  |  | $ | 15,809 |  |  | $ | 1,839 |  |  | 12 | % |

[0001730168-23-000064:mdna:34]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 78 | % |  | 77 | % |  | 79 | % |  | 77 | % |
| Infrastructure software |  | 22 |  |  | 23 |  |  | 21 |  |  | 23 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-23-000064:mdna:35]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended April 30, 2023 compared to the prior year fiscal periods due to strong product demand, primarily for networking, server storage and broadband products, partially offset by lower demand for wireless products. Net revenue from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended April 30, 2023 compared to the prior year fiscal periods primarily due to increases in sales from our mainframe solutions products, partially offset by lower demand for our FC SAN products.

[0001730168-23-000064:mdna:36]
[same as prior period, unchanged from 0001730168-23-000008:mdna:35]

[0001730168-23-000064:mdna:37]
Gross margin was $6,115 million, or 70% of net revenue, for the fiscal quarter ended April 30, 2023 compared to $5,439 million, or 67% of net revenue, for the fiscal quarter ended May 1, 2022, and $12,119 million, or 69% of net revenue, for the two fiscal quarters ended April 30, 2023 compared to $10,488 million, or 66% of net revenue, for the two fiscal quarters ended May 1, 2022.

[0001730168-23-000064:mdna:38]
The increases were primarily due to lower amortization of acquisition-related intangible assets, mainly from our 2016 acquisition of Broadcom Corporation, slightly offset by less favorable margin within our semiconductor solutions segment driven primarily by product mix.

[0001730168-23-000064:mdna:39]
[same as prior period, unchanged from 0001730168-23-000008:mdna:37]

[0001730168-23-000064:mdna:40]
Research and development expense increased $51 million, or 4%, and $40 million, or 2%, for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to the prior year fiscal periods. The increases were primarily due

[0001730168-23-000064:mdna:41]
[same as prior period, unchanged from 0001730168-23-000008:mdna:47]

[0001730168-23-000064:mdna:42]
to higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values and an increase in headcount, partially offset by lower variable employee compensation expense.

[0001730168-23-000064:mdna:43]
[same as prior period, unchanged from 0001730168-23-000008:mdna:39]

[0001730168-23-000064:mdna:44]
Selling, general and administrative expense increased $70 million, or 19%, and $97 million, or 14%, for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher costs incurred in connection with the pending VMware Merger and higher stock-based compensation expense as a result of annual employee equity awards granted at higher grant-date fair values, partially offset by lower variable employee compensation expense.

[0001730168-23-000064:mdna:45]
[same as prior period, unchanged from 0001730168-23-000008:mdna:41]

[0001730168-23-000064:mdna:46]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $50 million, or 13%, and $99 million, or 12%, for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower amortization of customer-related intangible assets from our acquisition of LSI Corporation.

[0001730168-23-000064:mdna:47]
[same as prior period, unchanged from 0001730168-23-000008:mdna:43]

[0001730168-23-000064:mdna:48]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $9 million, or 50%, and $16 million, or 46%, for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower lease-related charges following the completion of key restructuring activities from acquisitions.

[0001730168-23-000064:mdna:49]
[same as prior period, unchanged from 0001730168-23-000008:mdna:45]

[0001730168-23-000064:mdna:50]
Total stock-based compensation expense was $513 million and $904 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, and $386 million and $773 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. The increases were primarily due to annual employee equity awards granted at higher grant-date fair values during the fiscal quarter ended April 30, 2023.

[0001730168-23-000064:mdna:51]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of April 30, 2023. The remaining weighted-average service period was 3.8 years.

[0001730168-23-000064:mdna:52]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 1,230 |  |
| 2024 |  | 2,209 |  |
| 2025 |  | 1,780 |  |
| 2026 |  | 1,346 |  |
| 2027 |  | 670 |  |
| Thereafter |  | 122 |  |
| Total |  | $ | 7,357 |  |

[0001730168-23-000064:mdna:53]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made on March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-23-000064:mdna:54]
26

[0001730168-23-000064:mdna:55]
[same as prior period, unchanged from 0001730168-23-000008:mdna:51]

[0001730168-23-000064:mdna:56]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | April 30,2023 |  | May 1,2022 |  | $ Change |  | % Change |  | April 30, 2023 |  | May 1, 2022 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,000 |  |  | $ | 3,626 |  |  | $ | 374 |  |  | 10 | % |  | $ | 8,123 |  |  | $ | 6,975 |  |  | $ | 1,148 |  |  | 16 | % |
| Infrastructure software |  | 1,412 |  |  | 1,313 |  |  | 99 |  |  | 8 | % |  | 2,719 |  |  | 2,620 |  |  | 99 |  |  | 4 | % |
| Unallocated expenses |  | (1,404) |  |  | (1,545) |  |  | 141 |  |  | (9) | % |  | (2,731) |  |  | (3,093) |  |  | 362 |  |  | (12) | % |
| Total operating income |  | $ | 4,008 |  |  | $ | 3,394 |  |  | $ | 614 |  |  | 18 | % |  | $ | 8,111 |  |  | $ | 6,502 |  |  | $ | 1,609 |  |  | 25 | % |

[0001730168-23-000064:mdna:57]
Operating income from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended April 30, 2023 compared to the prior year fiscal periods primarily due to higher net revenue from networking, server storage, and broadband products, partially offset by lower net revenue from wireless products. Operating income from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended April 30, 2023 compared to the prior year fiscal periods primarily due to higher net revenue from our mainframe solutions products, partially offset by lower net revenue from our FC SAN products.

[0001730168-23-000064:mdna:58]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 9% and 12% for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to the prior year fiscal periods, primarily due to lower amortization of acquisition-related intangible assets, partially offset by higher stock-based compensation expense.

[0001730168-23-000064:mdna:59]
[same as prior period, unchanged from 0001730168-23-000008:mdna:55]

[0001730168-23-000064:mdna:60]
Interest expense. Interest expense was $405 million and $811 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to $518 million and $925 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. The decreases were primarily due to losses on extinguishment of debt related to debt transactions incurred in the fiscal quarter ended May 1, 2022. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the pending VMware Merger.

[0001730168-23-000064:mdna:61]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $113 million and $256 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to other expense, net, of $86 million and $100 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. The changes were primarily due to higher interest income as a result of higher interest rates and changes in investment gains or losses.

[0001730168-23-000064:mdna:62]
Provision for income taxes. The provision for income taxes was $235 million and $301 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to $200 million and $415 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. The increase for the fiscal quarter ended April 30, 2023 compared to the prior year fiscal period was primarily due to higher income before income taxes, partially offset by the recognition of uncertain tax benefits as a result of lapses of statutes of limitations. The decrease for the two fiscal quarters ended April 30, 2023 compared to the prior year fiscal period was primarily due to the recognition of uncertain tax benefits as a result of lapses of statutes of limitations, partially offset by higher income before income taxes.

[0001730168-23-000064:mdna:63]
[same as prior period, unchanged from 0001730168-23-000008:mdna:59]

[0001730168-23-000064:mdna:64]
[same as prior period, unchanged from 0001730168-23-000008:mdna:60]

[0001730168-23-000064:mdna:65]
Our primary sources of liquidity as of April 30, 2023 consisted of: (i) $11,553 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-23-000064:mdna:66]
[same as prior period, unchanged from 0001730168-23-000008:mdna:62]

[0001730168-23-000064:mdna:67]
We believe that our cash and cash equivalents on hand, cash flows from operations, our revolving credit facility, as well as the committed debt funding related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-23-000064:mdna:68]
[same as prior period, unchanged from 0001730168-23-000008:mdna:64]

[0001730168-23-000064:mdna:69]
[same as prior period, unchanged from 0001730168-23-000008:mdna:65]

[0001730168-23-000064:mdna:70]
[same as prior period, unchanged from 0001730168-23-000008:mdna:66]

[0001730168-23-000064:mdna:71]
Working capital decreased to $10,360 million at April 30, 2023 from $11,452 million at October 30, 2022. The decrease was primarily attributable to the following:

[0001730168-23-000064:mdna:72]
•Cash and cash equivalents decreased to $11,553 million at April 30, 2023 from $12,416 million at October 30, 2022, primarily due to $3,994 million of common stock repurchases, $3,840 million of dividend payments, $947 million of employee withholding tax payments related to net settled equity awards, and $260 million of a debt payment, substantially offset by $8,538 million in net cash provided by operating activities.

[0001730168-23-000064:mdna:73]
•Current portion of long-term debt increased to $1,117 million at April 30, 2023 from $440 million at October 30, 2022 due to certain debt instruments becoming due within the next twelve months, partially offset by a repayment.

[0001730168-23-000064:mdna:74]
•Other current liabilities increased to $4,929 million at April 30, 2023 from $4,412 million at October 30, 2022, primarily due to increases in contract liabilities and derivative liabilities.

[0001730168-23-000064:mdna:75]
[same as prior period, unchanged from 0001730168-23-000008:mdna:71]

[0001730168-23-000064:mdna:76]
•Employee compensation and benefits decreased to $634 million at April 30, 2023 from $1,202 million at October 30, 2022, primarily due to the timing of employee bonus plan payments.

[0001730168-23-000064:mdna:77]
•Other current assets increased to $1,401 million at April 30, 2023 from $1,205 million at October 30, 2022, primarily due to purchases of short-term investments and an increase in contract assets, offset in part by a decrease in prepaid income taxes.

[0001730168-23-000064:mdna:78]
•Accounts payable decreased to $831 million at April 30, 2023 from $998 million at October 30, 2022, primarily due to the timing of vendor payments.

[0001730168-23-000064:mdna:79]
[same as prior period, unchanged from 0001730168-23-000008:mdna:76]

[0001730168-23-000064:mdna:80]
|  |  | Two Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 9.20 |  |  | $ | 8.20 |  |
| Dividends to common stockholders |  | $ | 3,840 |  |  | $ | 3,365 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 40.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 149 |  |

[0001730168-23-000064:mdna:81]
[same as prior period, unchanged from 0001730168-23-000008:mdna:78]

[0001730168-23-000064:mdna:82]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2022, which was subsequently extended to December 31, 2023 (the “December 2021 Authorization”). In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023 (the “May 2022 Authorization”). As of April 30, 2023, $9,006 million of the authorized amount remained available for repurchases.

[0001730168-23-000064:mdna:83]
During the two fiscal quarters ended April 30, 2023 and May 1, 2022, we repurchased and retired approximately 7 million and 9 million shares of our common stock for $3,994 million and $5,500 million, respectively, under these stock repurchase programs.

[0001730168-23-000064:mdna:84]
[same as prior period, unchanged from 0001730168-23-000008:mdna:81]

[0001730168-23-000064:mdna:85]
During the two fiscal quarters ended April 30, 2023 and May 1, 2022, we paid approximately $947 million and $889 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the two fiscal quarters ended April 30, 2023 and May 1, 2022.

[0001730168-23-000064:mdna:86]
[same as prior period, unchanged from 0001730168-23-000008:mdna:83]

[0001730168-23-000064:mdna:87]
|  |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 8,538 |  |  | $ | 7,729 |  |
| Net cash used in investing activities |  | (421) |  |  | (619) |  |
| Net cash used in financing activities |  | (8,980) |  |  | (10,268) |  |
| Net change in cash and cash equivalents |  | $ | (863) |  |  | $ | (3,158) |  |

[0001730168-23-000064:mdna:88]
[same as prior period, unchanged from 0001730168-23-000008:mdna:85]

[0001730168-23-000064:mdna:89]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $809 million increase in cash provided by operations during the two fiscal quarters ended April 30, 2023 compared to the prior year fiscal period was primarily due to $2,193 million higher net income and a $267 million increase resulting from changes in operating assets and liabilities, offset in part by $1,651 million lower non-cash adjustments including deferred taxes and other non-cash taxes, and amortization of intangible assets.

[0001730168-23-000064:mdna:90]
[same as prior period, unchanged from 0001730168-23-000008:mdna:87]

[0001730168-23-000064:mdna:91]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures and purchases of investments. The $198 million decrease in cash used in investing activities during the two fiscal quarters ended April 30, 2023 compared to the prior year fiscal period was primarily due to $234 million in cash paid for acquisitions in the prior year fiscal period.

[0001730168-23-000064:mdna:92]
[same as prior period, unchanged from 0001730168-23-000008:mdna:89]

[0001730168-23-000064:mdna:93]
Cash flows from financing activities primarily consisted of our stock repurchases, dividend payments, proceeds and payments related to our long-term borrowings, and employee withholding tax payments related to net settled equity awards. The $1,288 million decrease in cash used in financing activities during the two fiscal quarters ended April 30, 2023 compared to the prior year fiscal period was primarily due to a $1,506 million decrease in stock repurchases and a $157 million change in net borrowing activities, offset in part by a $326 million increase in dividend payments.

[0001730168-23-000064:mdna:94]
[same as prior period, unchanged from 0001730168-23-000008:mdna:91]

[0001730168-23-000064:mdna:95]
[same as prior period, unchanged from 0001730168-23-000008:mdna:92]
