# AVGO notes — 0001730168-23-000064


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-23-000064:notes:1]
[same as prior period, unchanged from 0001730168-23-000008:notes:1]

[0001730168-23-000064:notes:2]
[same as prior period, unchanged from 0001730168-23-000008:notes:2]

[0001730168-23-000064:notes:3]
[same as prior period, unchanged from 0001730168-23-000008:notes:3]

[0001730168-23-000064:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 29, 2023 (“fiscal year 2023”) is a 52-week fiscal year. The first quarter of our fiscal year 2023 ended on January 29, 2023, the second quarter ended on April 30, 2023 and the third quarter ends on July 30, 2023. Our fiscal year ended October 30, 2022 (“fiscal year 2022”) was also a 52-week fiscal year.

[0001730168-23-000064:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 30, 2022 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2022 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended April 30, 2023 are not necessarily indicative of the results that may be expected for fiscal year 2023, or for any other future period.

[0001730168-23-000064:notes:6]
[same as prior period, unchanged from 0001730168-23-000008:notes:6]

[0001730168-23-000064:notes:7]
[same as prior period, unchanged from 0001730168-23-000008:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-23-000064:notes:8]
Revenue from Contracts with Customers We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable that we will collect substantially all of the consideration to which we are entitled. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
Disaggregation

[0001730168-23-000064:notes:9]
[same as prior period, unchanged from 0001730168-23-000008:notes:9]

[0001730168-23-000064:notes:10]
[same as prior period, unchanged from 0001730168-23-000008:notes:10]

[0001730168-23-000064:notes:11]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services (a) |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

[0001730168-23-000064:notes:12]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

[0001730168-23-000064:notes:13]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services (a) |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

[0001730168-23-000064:notes:14]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

[0001730168-23-000064:notes:15]
[same as prior period, unchanged from 0001730168-23-000008:notes:13]

[0001730168-23-000064:notes:16]
[same as prior period, unchanged from 0001730168-23-000008:notes:14]

[0001730168-23-000064:notes:17]
[same as prior period, unchanged from 0001730168-23-000008:notes:15]

[0001730168-23-000064:notes:18]
[same as prior period, unchanged from 0001730168-23-000008:notes:16]

[0001730168-23-000064:notes:19]
|  |  | April 30,2023 |  | October 30,2022 |
|  | (In millions) |
| Contract Assets |  | $ | 401 |  |  | $ | 128 |  |
| Contract Liabilities |  | $ | 3,793 |  |  | $ | 3,341 |  |

[0001730168-23-000064:notes:20]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended April 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,287 million. The amount of revenue recognized during the two fiscal quarters ended May 1, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,974 million.

[0001730168-23-000064:notes:21]
[same as prior period, unchanged from 0001730168-23-000008:notes:19]

[0001730168-23-000064:notes:22]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are not considered committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-23-000064:notes:23]
Certain multi-year customer contracts primarily in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of April 30, 2023 were approximately $21.4 billion. We expect approximately 27% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## avgo:PendingBusinessCombinationDisclosureTextBlock

[0001730168-23-000064:notes:24]
[same as prior period, unchanged from 0001730168-23-000008:notes:23]

[0001730168-23-000064:notes:25]
[same as prior period, unchanged from 0001730168-23-000008:notes:24]

[0001730168-23-000064:notes:26]
[same as prior period, unchanged from 0001730168-23-000008:notes:25]

[0001730168-23-000064:notes:27]
[same as prior period, unchanged from 0001730168-23-000008:notes:26]

[0001730168-23-000064:notes:28]
[same as prior period, unchanged from 0001730168-23-000008:notes:27]

[0001730168-23-000064:notes:29]
[same as prior period, unchanged from 0001730168-23-000008:notes:28]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-23-000064:notes:30]
[same as prior period, unchanged from 0001730168-23-000008:notes:29]

[0001730168-23-000064:notes:31]
Cash equivalents included $3,018 million and $3,915 million of time deposits and $2,414 million and $2,365 million of money-market funds as of April 30, 2023 and October 30, 2022, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-23-000064:notes:32]
[same as prior period, unchanged from 0001730168-23-000008:notes:31]

[0001730168-23-000064:notes:33]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $900 million and $1,925 million during the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, and $900 million and $2,100 million during the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-23-000064:notes:34]
[same as prior period, unchanged from 0001730168-23-000008:notes:34]

[0001730168-23-000064:notes:35]
|  |  | April 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Finished goods |  | $ | 577 |  |  | $ | 780 |  |
| Work-in-process |  | 1,038 |  |  | 966 |  |
| Raw materials |  | 271 |  |  | 179 |  |
| Total inventory |  | $ | 1,886 |  |  | $ | 1,925 |  |

[0001730168-23-000064:notes:36]
[same as prior period, unchanged from 0001730168-23-000008:notes:36]

[0001730168-23-000064:notes:37]
|  |  | April 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 676 |  |  | $ | 864 |  |
| Other |  | 725 |  |  | 341 |  |
| Total other current assets |  | $ | 1,401 |  |  | $ | 1,205 |  |

[0001730168-23-000064:notes:38]
[same as prior period, unchanged from 0001730168-23-000008:notes:38]

[0001730168-23-000064:notes:39]
|  |  | April 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,427 |  |  | $ | 2,931 |  |
| Tax liabilities |  | 650 |  |  | 680 |  |
| Interest payable |  | 382 |  |  | 393 |  |
| Other |  | 470 |  |  | 408 |  |
| Total other current liabilities |  | $ | 4,929 |  |  | $ | 4,412 |  |

[0001730168-23-000064:notes:40]
[same as prior period, unchanged from 0001730168-23-000008:notes:40]

[0001730168-23-000064:notes:41]
|  |  | April 30,2023 |  | October 30,2022 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 2,841 |  |  | $ | 3,229 |  |
| Other |  | 1,114 |  |  | 1,184 |  |
| Total other long-term liabilities |  | $ | 3,955 |  |  | $ | 4,413 |  |

[0001730168-23-000064:notes:42]
[same as prior period, unchanged from 0001730168-23-000008:notes:42]

[0001730168-23-000064:notes:43]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 397 |  |  | $ | 459 |  |  | $ | 758 |  |  | $ | 699 |  |
| Cash paid for income taxes |  | $ | 891 |  |  | $ | 240 |  |  | $ | 1,164 |  |  | $ | 426 |  |

[0001730168-23-000064:notes:44]
Derivative Instruments

[0001730168-23-000064:notes:45]
During the fiscal quarter ended January 29, 2023 and fiscal year 2022, we entered into treasury rate lock contracts with original maturities of approximately one year to hedge variability of cash flows due to changes in the benchmark interest rate of anticipated future debt issuances. These treasury rate locks are designated and accounted for as cash flow hedging instruments. As of April 30, 2023 and October 30, 2022, the total notional amounts of these contracts were $5.5 billion and $1.3 billion, respectively. As of April 30, 2023, the fair value of $120 million was recorded in other current liabilities. As of October 30, 2022, the fair value of $47 million was recorded in other long-term assets. The change in fair value was recorded as a component of other comprehensive income (loss), net of tax, in our condensed consolidated statements of comprehensive income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-23-000064:notes:46]
[same as prior period, unchanged from 0001730168-23-000008:notes:45]

[0001730168-23-000064:notes:47]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of April 30, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 19,450 |  |  | $ | (16,396) |  |  | $ | 3,054 |  |
| Customer contracts and related relationships |  | 7,066 |  |  | (5,147) |  |  | 1,919 |  |
| Order backlog |  | 484 |  |  | (432) |  |  | 52 |  |
| Trade names |  | 700 |  |  | (405) |  |  | 295 |  |
| Other |  | 174 |  |  | (89) |  |  | 85 |  |
| Intangible assets subject to amortization |  | 27,874 |  |  | (22,469) |  |  | 5,405 |  |
| In-process research and development |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 27,903 |  |  | $ | (22,469) |  |  | $ | 5,434 |  |
| As of October 30, 2022: |  |  |  |  |  |  |
| Purchased technology |  | $ | 19,450 |  |  | $ | (15,422) |  |  | $ | 4,028 |  |
| Customer contracts and related relationships |  | 7,066 |  |  | (4,535) |  |  | 2,531 |  |
| Order backlog |  | 484 |  |  | (382) |  |  | 102 |  |
| Trade names |  | 700 |  |  | (372) |  |  | 328 |  |
| Other |  | 174 |  |  | (81) |  |  | 93 |  |
| Intangible assets subject to amortization |  | 27,874 |  |  | (20,792) |  |  | 7,082 |  |
| In-process research and development |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 27,903 |  |  | $ | (20,792) |  |  | $ | 7,111 |  |

[0001730168-23-000064:notes:48]
Based on the amount of intangible assets subject to amortization as of April 30, 2023, the expected amortization expense was as follows:

[0001730168-23-000064:notes:49]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 1,578 |  |
| 2024 |  | 2,388 |  |
| 2025 |  | 681 |  |
| 2026 |  | 344 |  |
| 2027 |  | 216 |  |
| Thereafter |  | 198 |  |
| Total |  | $ | 5,405 |  |

[0001730168-23-000064:notes:50]
[same as prior period, unchanged from 0001730168-23-000008:notes:49]

[0001730168-23-000064:notes:51]
| Amortizable intangible assets: |  | April 30,2023 |
|  |  | (In years) |
| Purchased technology |  | 3 |
| Customer contracts and related relationships |  | 2 |
| Order backlog |  | 1 |
| Trade names |  | 8 |
| Other |  | 8 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-23-000064:notes:52]
[same as prior period, unchanged from 0001730168-23-000008:notes:51]

[0001730168-23-000064:notes:53]
Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan (“ESPP”), (collectively referred to as “equity awards”), as well as 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”), which was all converted into shares of our common stock before the end of fiscal year 2022. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-23-000064:notes:54]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for purchasing shares under the ESPP and the amount of stock-based compensation expense for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of Mandatory Convertible Preferred Stock is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.

[0001730168-23-000064:notes:55]
For each of the fiscal quarter and two fiscal quarters ended May 1, 2022, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-23-000064:notes:56]
[same as prior period, unchanged from 0001730168-23-000008:notes:55]

[0001730168-23-000064:notes:57]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,481 |  |  | $ | 2,590 |  |  | $ | 7,255 |  |  | $ | 5,062 |  |
| Dividends on preferred stock |  | — |  |  | (75) |  |  | — |  |  | (149) |  |
| Net income attributable to common stock |  | $ | 3,481 |  |  | $ | 2,515 |  |  | $ | 7,255 |  |  | $ | 4,913 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 415 |  | 408 |  | 417 |  | 410 |
| Dilutive effect of equity awards |  | 12 |  | 16 |  | 11 |  | 16 |
| Weighted-average shares outstanding - diluted |  | 427 |  | 424 |  | 428 |  | 426 |

[0001730168-23-000064:notes:58]
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.39 |  |  | $ | 6.16 |  |  | $ | 17.40 |  |  | $ | 11.98 |  |
| Diluted |  | $ | 8.15 |  |  | $ | 5.93 |  |  | $ | 16.95 |  |  | $ | 11.53 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-23-000064:notes:59]
Borrowings

[0001730168-23-000064:notes:60]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | — |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |

[0001730168-23-000064:notes:61]
|  |  | Effective Interest Rate |  | April 30,2023 |  | October 30,2022 |
|  |  | (Dollars in millions) |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,023 |  |  | 5,283 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
|  |  |  |  | 358 |  |  | 358 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,218 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,077 |  |  | $ | 403 |  |
| Short-term finance lease liabilities |  |  |  | 40 |  |  | 37 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,117 |  |  | $ | 440 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 39,881 |  |  | $ | 40,815 |  |
| Long-term finance lease liabilities |  |  |  | 12 |  |  | 22 |  |
| Unamortized discount and issuance costs |  |  |  | (1,699) |  |  | (1,762) |  |
| Total long-term debt |  |  |  | $ | 38,194 |  |  | $ | 39,075 |  |

[0001730168-23-000064:notes:62]
Credit Agreement

[0001730168-23-000064:notes:63]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either April 30, 2023 or October 30, 2022.

[0001730168-23-000064:notes:64]
Commercial Paper

[0001730168-23-000064:notes:65]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either April 30, 2023 or October 30, 2022.

[0001730168-23-000064:notes:66]
Fair Value of Debt

[0001730168-23-000064:notes:67]
As of April 30, 2023, the estimated aggregate fair value of debt was $35,573 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-23-000064:notes:68]
Future Principal Payments of Debt

[0001730168-23-000064:notes:69]
The future scheduled principal payments of debt as of April 30, 2023 were as follows:

[0001730168-23-000064:notes:70]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 143 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 495 |  |
| 2026 |  | 1,652 |  |
| 2027 |  | 3,137 |  |
| Thereafter |  | 33,968 |  |
| Total |  | $ | 40,958 |  |

[0001730168-23-000064:notes:71]
As of April 30, 2023 and October 30, 2022, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-23-000064:notes:72]
[same as prior period, unchanged from 0001730168-23-000008:notes:71]

[0001730168-23-000064:notes:73]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 4.60 |  |  | $ | 4.10 |  |  | $ | 9.20 |  |  | $ | 8.20 |  |
| Dividends to common stockholders |  | $ | 1,914 |  |  | $ | 1,676 |  |  | $ | 3,840 |  |  | $ | 3,365 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | 20.00 |  |  | $ | — |  |  | $ | 40.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | 74 |  |  | $ | — |  |  | $ | 149 |  |

[0001730168-23-000064:notes:74]
[same as prior period, unchanged from 0001730168-23-000008:notes:73]

[0001730168-23-000064:notes:75]
[same as prior period, unchanged from 0001730168-23-000008:notes:74]

[0001730168-23-000064:notes:76]
[same as prior period, unchanged from 0001730168-23-000008:notes:75]

[0001730168-23-000064:notes:77]
We repurchased and retired approximately 5 million and 7 million shares of our common stock for $2,806 million and $3,994 million during the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, and approximately 5 million and 9 million shares of our common stock for $2,776 million and $5,500 million during the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, under these stock repurchase programs.

[0001730168-23-000064:notes:78]
[same as prior period, unchanged from 0001730168-23-000008:notes:77]

[0001730168-23-000064:notes:79]
[same as prior period, unchanged from 0001730168-23-000008:notes:78]

[0001730168-23-000064:notes:80]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 22 |  |  | $ | 16 |  |  | $ | 38 |  |  | $ | 34 |  |
| Cost of subscriptions and services |  | 28 |  |  | 20 |  |  | 49 |  |  | 38 |  |
| Research and development |  | 354 |  |  | 261 |  |  | 621 |  |  | 529 |  |
| Selling, general and administrative |  | 109 |  |  | 89 |  |  | 196 |  |  | 172 |  |
| Total stock-based compensation expense |  | $ | 513 |  |  | $ | 386 |  |  | $ | 904 |  |  | $ | 773 |  |

[0001730168-23-000064:notes:81]
As of April 30, 2023, the total unrecognized compensation cost related to unvested stock-based awards was $7,357 million, which is expected to be recognized over the remaining weighted-average service period of 3.8 years.

[0001730168-23-000064:notes:82]
[same as prior period, unchanged from 0001730168-23-000008:notes:81]

[0001730168-23-000064:notes:83]
[same as prior period, unchanged from 0001730168-23-000008:notes:82]

[0001730168-23-000064:notes:84]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 30, 2022 |  | 18 |  |  | $ | 238.49 |  |  |  |  |  |
| Granted |  | 12 |  |  | $ | 513.28 |  |  |  |  |  |
| Vested |  | (5) |  |  | $ | 224.49 |  |  |  |  |  |
| Forfeited |  | — |  | * | $ | 266.60 |  |  |  |  |  |
| Balance as of April 30, 2023 |  | 25 |  |  | $ | 373.97 |  |  |  |  |  |

[0001730168-23-000064:notes:85]
[same as prior period, unchanged from 0001730168-23-000008:notes:84]

[0001730168-23-000064:notes:86]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended April 30, 2023 was $2,591 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-23-000064:notes:87]
Income Taxes
The provision for income taxes was $235 million and $301 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively, compared to $200 million and $415 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively. The increase in the provision for income taxes in the fiscal quarter ended April 30, 2023, as compared to the prior year fiscal period, was primarily due to higher income before income taxes, partially offset by an increase in the recognition of uncertain tax benefits as a result of lapses of statutes of limitations. The decrease in the provision for income taxes in the two fiscal quarters ended April 30, 2023, as compared to the prior year fiscal period, was primarily due to the recognition of uncertain tax benefits as a result of lapses of statutes of limitations, partially offset by higher income before income taxes.

[0001730168-23-000064:notes:88]
As of April 30, 2023, we had $5,384 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $329 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations and changes in balances related to tax positions to be taken during the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-23-000064:notes:89]
[same as prior period, unchanged from 0001730168-23-000008:notes:87]

[0001730168-23-000064:notes:90]
[same as prior period, unchanged from 0001730168-23-000008:notes:88]

[0001730168-23-000064:notes:91]
[same as prior period, unchanged from 0001730168-23-000008:notes:89]

[0001730168-23-000064:notes:92]
[same as prior period, unchanged from 0001730168-23-000008:notes:90]

[0001730168-23-000064:notes:93]
[same as prior period, unchanged from 0001730168-23-000008:notes:91]

[0001730168-23-000064:notes:94]
[same as prior period, unchanged from 0001730168-23-000008:notes:92]

[0001730168-23-000064:notes:95]
[same as prior period, unchanged from 0001730168-23-000008:notes:93]

[0001730168-23-000064:notes:96]
[same as prior period, unchanged from 0001730168-23-000008:notes:94]

[0001730168-23-000064:notes:97]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | April 30,2023 |  | May 1,2022 |  | April 30,2023 |  | May 1,2022 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 6,808 |  |  | $ | 6,229 |  |  | $ | 13,915 |  |  | $ | 12,102 |  |
| Infrastructure software |  | 1,925 |  |  | 1,874 |  |  | 3,733 |  |  | 3,707 |  |
| Total net revenue |  | $ | 8,733 |  |  | $ | 8,103 |  |  | $ | 17,648 |  |  | $ | 15,809 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,000 |  |  | $ | 3,626 |  |  | $ | 8,123 |  |  | $ | 6,975 |  |
| Infrastructure software |  | 1,412 |  |  | 1,313 |  |  | 2,719 |  |  | 2,620 |  |
| Unallocated expenses |  | (1,404) |  |  | (1,545) |  |  | (2,731) |  |  | (3,093) |  |
| Total operating income |  | $ | 4,008 |  |  | $ | 3,394 |  |  | $ | 8,111 |  |  | $ | 6,502 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-23-000064:notes:98]
Commitments and Contingencies
Commitments

[0001730168-23-000064:notes:99]
The following table summarizes contractual obligations and commitments as of April 30, 2023:

[0001730168-23-000064:notes:100]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2023 (remainder) |  | $ | 55 |  |  | $ | 146 |  |
| 2024 |  | 256 |  |  | 271 |  |
| 2025 |  | 136 |  |  | 158 |  |
| 2026 |  | 9 |  |  | 169 |  |
| 2027 |  | 7 |  |  | 112 |  |
| Thereafter |  | 7 |  |  | 447 |  |
| Total |  | $ | 470 |  |  | $ | 1,303 |  |

[0001730168-23-000064:notes:101]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-23-000064:notes:102]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-23-000064:notes:103]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of April 30, 2023, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $2,841 million of unrecognized tax benefits and accrued interest and penalties as of April 30, 2023 have been excluded from the table above.

[0001730168-23-000064:notes:104]
Contingencies

[0001730168-23-000064:notes:105]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-23-000064:notes:106]
Lawsuits Relating to California Institute of Technology

[0001730168-23-000064:notes:107]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in

[0001730168-23-000064:notes:108]
enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”). In February 2022, the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, but it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. In May 2022, the Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court. Subsequently, Caltech withdrew its infringement allegations as to the 7,916,781 patent.

[0001730168-23-000064:notes:109]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a retrial at the lower court and further appeals) could significantly change the assessment of damages. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards.

[0001730168-23-000064:notes:110]
Other Matters

[0001730168-23-000064:notes:111]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-23-000064:notes:112]
Contingency Assessment

[0001730168-23-000064:notes:113]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-23-000064:notes:114]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-23-000064:notes:115]
Other Indemnifications

[0001730168-23-000064:notes:116]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:SubsequentEventsTextBlock

[0001730168-23-000064:notes:117]
Subsequent Events
Cash Dividends Declared

[0001730168-23-000064:notes:118]
On May 31, 2023, our Board of Directors declared a quarterly cash dividend of $4.60 per share on our common stock, payable on June 30, 2023 to stockholders of record on June 22, 2023.
