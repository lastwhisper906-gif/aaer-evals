# AVGO MD&A — 0001730168-20-000045


## mdna

[0001730168-20-000045:mdna:1]
[same as prior period, unchanged from 0001730168-19-000118:mdna:1]

[0001730168-20-000045:mdna:2]
[same as prior period, unchanged from 0001730168-19-000118:mdna:2]

[0001730168-20-000045:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We also offer a cybersecurity solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions.

[0001730168-20-000045:mdna:4]
During the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines, except for those related to our fibre channel storage area networking (“FC SAN”) products, as well as our IP licensing. Our infrastructure software segment includes our FC SAN products; CA, Inc. (“CA”) mainframe and enterprise software solutions; and enterprise security solutions. Prior period segment results have been recast to conform to the current presentation.

[0001730168-20-000045:mdna:5]
[same as prior period, unchanged from 0001730168-19-000118:mdna:6]

[0001730168-20-000045:mdna:6]
Highlights during the first fiscal quarter ended February 2, 2020 include the following:

[0001730168-20-000045:mdna:7]
| • | We generated $2,322 million of cash from operations. |

[0001730168-20-000045:mdna:8]
| • | We paid $1,372 million in cash dividends. |

[0001730168-20-000045:mdna:9]
| • | We entered into a credit agreement which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. See Note 8. Borrowings in Part I, Item 1 of this Form 10-Q for more details. |

[0001730168-20-000045:mdna:10]
| • | During the fiscal quarter ended February 2, 2020, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation (now known as NortonLifeLock Inc.) Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). We financed the Symantec Asset Purchase with net proceeds from the 2020 Term Loans. |

[0001730168-20-000045:mdna:11]
| • | We paid off $750 million aggregate principal amount of 5.375% notes on December 1, 2019 and $2,750 million aggregate principal amount of 2.375% notes on January 15, 2020 with the remaining net proceeds from the 2020 Term Loans. |

[0001730168-20-000045:mdna:12]
| • | We increased our unsecured commercial paper notes borrowings by $1 billion and used the net proceeds to repay $500 million of each of our unsecured term A-5 and A-7 facilities provided for by a credit agreement entered into in May 2019. |

[0001730168-20-000045:mdna:13]
Acquisitions

[0001730168-20-000045:mdna:14]
Acquisition of Symantec Corporation’s Enterprise Security Business

[0001730168-20-000045:mdna:15]
During the fiscal quarter ended February 2, 2020, we completed the purchase of the Symantec Business for $10.7 billion. We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications.

[0001730168-20-000045:mdna:16]
Other Acquisitions

[0001730168-20-000045:mdna:17]
During the fiscal quarter ended February 2, 2020, we completed three other acquisitions for total consideration of $201 million. One acquisition was included in our semiconductor solutions segment. Two acquisitions were included in our infrastructure software segment.

[0001730168-20-000045:mdna:18]
[same as prior period, unchanged from 0001730168-19-000118:mdna:18]

[0001730168-20-000045:mdna:19]
[same as prior period, unchanged from 0001730168-19-000118:mdna:19]

[0001730168-20-000045:mdna:20]
There were no significant changes in our critical accounting policies during the fiscal quarter ended February 2, 2020 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2019 Annual Report on Form 10-K.

[0001730168-20-000045:mdna:21]
[same as prior period, unchanged from 0001730168-19-000118:mdna:21]

[0001730168-20-000045:mdna:22]
Fiscal Quarter Ended February 2, 2020 Compared to Fiscal Quarter Ended February 3, 2019

[0001730168-20-000045:mdna:23]
The following table sets forth our results of operations for the periods presented:

[0001730168-20-000045:mdna:24]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |  | (As a percentage of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,204 |  |  | $ | 4,639 |  |  | 72 | % |  | 80 | % |
| Subscriptions and services |  | 1,654 |  |  | 1,150 |  |  | 28 |  |  | 20 |  |
| Total net revenue |  | 5,858 |  |  | 5,789 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,459 |  |  | 1,554 |  |  | 25 |  |  | 27 |  |
| Cost of subscriptions and services |  | 177 |  |  | 138 |  |  | 3 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 950 |  |  | 833 |  |  | 16 |  |  | 15 |  |
| Restructuring charges |  | 8 |  |  | 56 |  |  | — |  |  | 1 |  |
| Total cost of revenue |  | 2,594 |  |  | 2,581 |  |  | 44 |  |  | 45 |  |
| Gross margin |  | 3,264 |  |  | 3,208 |  |  | 56 |  |  | 55 |  |
| Research and development |  | 1,289 |  |  | 1,133 |  |  | 22 |  |  | 19 |  |
| Selling, general and administrative |  | 601 |  |  | 471 |  |  | 11 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 603 |  |  | 476 |  |  | 10 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 57 |  |  | 573 |  |  | 1 |  |  | 10 |  |
| Total operating expenses |  | 2,550 |  |  | 2,653 |  |  | 44 |  |  | 45 |  |
| Operating income |  | $ | 714 |  |  | $ | 555 |  |  | 12 | % |  | 10 | % |

[0001730168-20-000045:mdna:25]
[same as prior period, unchanged from 0001730168-19-000118:mdna:27]

[0001730168-20-000045:mdna:26]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 14% and 15% of our net revenue for the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively. We believe aggregate sales to our top five end customers, through all channels, accounted for more than 30% and approximately 40% of our net revenue for the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for both of the fiscal quarters ended February 2, 2020 and February 3, 2019. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-20-000045:mdna:27]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the launches of, and seasonal variations in sales of mobile handsets.

[0001730168-20-000045:mdna:28]
The fundamental semiconductor backdrop has been improving, and we did not see any material impact on our businesses due to the COVID-19 pandemic in the first fiscal quarter ended February 2, 2020. However, visibility in our global markets is lacking and demand uncertainty is intensifying. As a result, it is difficult for us to predict the effects of the pandemic on our business.

[0001730168-20-000045:mdna:29]
[same as prior period, unchanged from 0001730168-19-000118:mdna:31]

[0001730168-20-000045:mdna:30]
|  |  | Fiscal Quarter Ended |
| Net Revenue by Segment |  | February 2, 2020 |  | February 3, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,191 |  |  | $ | 4,386 |  |  | $ | (195 | ) |  | (4 | )% |
| Infrastructure software |  | 1,667 |  |  | 1,403 |  |  | 264 |  |  | 19 | % |
| Total net revenue |  | $ | 5,858 |  |  | $ | 5,789 |  |  | $ | 69 |  |  | 1 | % |

[0001730168-20-000045:mdna:31]
|  |  | Fiscal Quarter Ended |
| % of Net Revenue by Segment |  | February 2, 2020 |  | February 3, 2019 |
| Semiconductor solutions |  | 72 | % |  | 76 | % |
| Infrastructure software |  | 28 |  |  | 24 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-20-000045:mdna:32]
Net revenue from our semiconductor solutions segment decreased in the fiscal quarter ended February 2, 2020 compared to the prior year fiscal period primarily due to lower demand for our wireless content in mobile handsets, partially offset by an increase in demand for our storage and certain networking and broadband products during the fiscal quarter ended February 2, 2020. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise software solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000045:mdna:33]
[same as prior period, unchanged from 0001730168-19-000118:mdna:36]

[0001730168-20-000045:mdna:34]
Gross margin was $3,264 million, or 56% of net revenue, for the fiscal quarter ended February 2, 2020, compared to $3,208 million, or 55% of net revenue, for the fiscal quarter ended February 3, 2019.

[0001730168-20-000045:mdna:35]
Gross margin remained relatively flat as contributions from our Symantec enterprise software products were substantially offset by the effects of an unfavorable product mix in our semiconductor solutions products, and higher amortization of acquisition-related intangible assets as a result of the Symantec Asset Purchase, in the fiscal quarter ended February 2, 2020.

[0001730168-20-000045:mdna:36]
[same as prior period, unchanged from 0001730168-19-000118:mdna:39]

[0001730168-20-000045:mdna:37]
Research and development expense increased $156 million, or 14%, for the fiscal quarter ended February 2, 2020 compared to the prior year fiscal period. The increase was primarily due to the Symantec Asset Purchase and higher stock-based compensation expense. The increase in stock-based compensation expense primarily resulted from the recognition of a full quarter of expense in the fiscal quarter ended February 2, 2020 for the multi-year equity grants of restricted stock units issued during the first quarter of fiscal year 2019.

[0001730168-20-000045:mdna:38]
[same as prior period, unchanged from 0001730168-19-000118:mdna:42]

[0001730168-20-000045:mdna:39]
Selling, general and administrative expense increased $130 million, or 28%, for the fiscal quarter ended February 2, 2020 compared to the prior year fiscal period. The increase was primarily due to the Symantec Asset Purchase and associated acquisition-related costs.

[0001730168-20-000045:mdna:40]
[same as prior period, unchanged from 0001730168-19-000118:mdna:44]

[0001730168-20-000045:mdna:41]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $127 million for the fiscal quarter ended February 2, 2020 compared to the prior year fiscal period. The increase was primarily due to intangible assets acquired in the Symantec Asset Purchase.

[0001730168-20-000045:mdna:42]
[same as prior period, unchanged from 0001730168-19-000118:mdna:46]

[0001730168-20-000045:mdna:43]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $516 million for the fiscal quarter ended February 2, 2020 compared to the prior year fiscal period. These charges were higher in the first quarter of fiscal year 2019 due to employee termination costs, as well as lease and other exit costs resulting from the acquisition of CA (“CA Merger”).

[0001730168-20-000045:mdna:44]
[same as prior period, unchanged from 0001730168-19-000118:mdna:48]

[0001730168-20-000045:mdna:45]
|  |  | Fiscal Quarter Ended |
| Operating Income (Loss) by Segment |  | February 2, 2020 |  | February 3, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 1,979 |  |  | $ | 2,032 |  |  | $ | (53 | ) |  | (3 | )% |
| Infrastructure software |  | 1,105 |  |  | 1,020 |  |  | 85 |  |  | 8 | % |
| Unallocated expenses |  | (2,370 | ) |  | (2,497 | ) |  | 127 |  |  | (5 | )% |
| Total operating income |  | $ | 714 |  |  | $ | 555 |  |  | $ | 159 |  |  | 29 | % |

[0001730168-20-000045:mdna:46]
Operating income from our semiconductor solutions segment decreased for the fiscal quarter ended February 2, 2020, compared to the prior year fiscal period, primarily due to lower demand for our wireless content in mobile handsets. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise software solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000045:mdna:47]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 5% for the fiscal quarter ended February 2, 2020, compared to the prior year fiscal period. The decrease was primarily due to lower restructuring, impairment and disposal charges partially offset by higher amortization of acquisition-related intangible assets, acquisition-related costs and stock-based compensation expense.

[0001730168-20-000045:mdna:48]
[same as prior period, unchanged from 0001730168-19-000118:mdna:54]

[0001730168-20-000045:mdna:49]
Interest expense. Interest expense was $406 million and $345 million for the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively. The increase was primarily due to interest on the debt we incurred to finance the Symantec Asset Purchase.

[0001730168-20-000045:mdna:50]
Other income (expense), net. Other income (expense), net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other expense, net of $4 million for the fiscal quarter ended February 2, 2020, as compared to other income, net of $68 million for the fiscal quarter ended February 3, 2019, was primarily due to unrealized losses on investments.

[0001730168-20-000045:mdna:51]
Benefit from income taxes. The benefit from income taxes was $76 million and $203 million for the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively. The benefit from income taxes for the fiscal quarter ended February 2, 2020 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards that vested or were exercised during the period. The benefit from income taxes for the fiscal quarter ended February 3, 2019 was primarily due to the resolution of uncertain tax positions as a result of audit settlements and lapses of statutes of limitations, partial release of our valuation allowance as a result of the CA Merger, and excess tax benefits from stock-based awards that were vested or exercised during the period.

[0001730168-20-000045:mdna:52]
[same as prior period, unchanged from 0001730168-19-000118:mdna:62]

[0001730168-20-000045:mdna:53]
[same as prior period, unchanged from 0001730168-19-000118:mdna:63]

[0001730168-20-000045:mdna:54]
Our primary sources of liquidity as of February 2, 2020 consisted of: (i) $6,444 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $5 billion revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-20-000045:mdna:55]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $45,022 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-20-000045:mdna:56]
We expect our capital expenditures for fiscal year 2020 will be higher than fiscal year 2019 due to the Symantec Asset Purchase on November 4, 2019.

[0001730168-20-000045:mdna:57]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-20-000045:mdna:58]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may also seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, outstanding term loans and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-20-000045:mdna:59]
[same as prior period, unchanged from 0001730168-19-000118:mdna:70]

[0001730168-20-000045:mdna:60]
Working capital increased to $4,370 million at February 2, 2020 from $3,018 million at November 3, 2019. The increase was primarily attributable to the following:

[0001730168-20-000045:mdna:61]
| • | Cash and cash equivalents increased to $6,444 million at February 2, 2020 from $5,055 million at November 3, 2019, primarily due to $16,099 million in proceeds from borrowings and $2,322 million in net cash provided by operating activities. These increases were partially offset by $10.7 billion paid for the Symantec Asset Purchase, $4,537 million of debt repayments, and $1,372 million of dividend payments. |

[0001730168-20-000045:mdna:62]
| • | Accounts receivable increased to $3,651 million at February 2, 2020 from $3,259 million at November 3, 2019 primarily due to revenue linearity, partially offset by $901 million of receivables sold through factoring arrangements. |

[0001730168-20-000045:mdna:63]
| • | Other current assets increased to $1,070 million at February 2, 2020 from $729 million at November 3, 2019, primarily due to assets acquired in the Symantec Asset Purchase and increases in prepaid taxes. |

[0001730168-20-000045:mdna:64]
| • | Employee compensation and benefits liabilities decreased to $435 million at February 2, 2020 from $641 million at November 3, 2019 primarily due to the timing of employee bonus plan payments. |

[0001730168-20-000045:mdna:65]
| • | Current portion of long-term debt decreased to $2,311 million at February 2, 2020 from $2,787 million at November 3, 2019 due to repayment of certain debt instruments, partially offset by certain debt instruments becoming due within the next twelve months. |

[0001730168-20-000045:mdna:66]
These increases in working capital were offset in part by the following:

[0001730168-20-000045:mdna:67]
| • | Accounts payable increased to $985 million at February 2, 2020 from $855 million at November 3, 2019, primarily due to timing of vendor payments. |

[0001730168-20-000045:mdna:68]
| • | Other current liabilities increased to $4,008 million at February 2, 2020 from $2,616 million at November 3, 2019, primarily due to the Symantec Asset Purchase, increases in contract liabilities, taxes payable, and lease liabilities resulting from the adoption of the new lease standard, partially offset by repayments of notional pooling liabilities. |

[0001730168-20-000045:mdna:69]
Working capital decreased to $2,255 million at February 3, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-20-000045:mdna:70]
| • | Current portion of long-term debt increased $3,537 million due to certain debt instruments becoming due within the next twelve months. |

[0001730168-20-000045:mdna:71]
| • | Other current liabilities increase to $3,611 million at February 3, 2019 from $812 million at November 4, 2018, primarily due to liabilities assumed in the CA Merger and increases in notional pooling liabilities and taxes payable. The increase was partially offset by interest payments for our long-term debt. |

[0001730168-20-000045:mdna:72]
[same as prior period, unchanged from 0001730168-19-000118:mdna:76]

[0001730168-20-000045:mdna:73]
| • | Our cash and cash equivalents increased to $5,093 million at February 3, 2019 from $4,292 million at November 4, 2018, primarily due to $17,896 million in proceeds from borrowings, $2,132 million in net cash provided by operating activities and $957 million in proceeds from the sale of a business, partially offset by $16,027 million paid for the CA Merger, $3,436 million of common stock repurchases and $1,067 million of dividend payments. |

[0001730168-20-000045:mdna:74]
| • | Other current assets increased to $760 million at February 3, 2019 from $366 million at November 4, 2018, primarily |

[0001730168-20-000045:mdna:75]
due to assets acquired in the CA Merger and an increase in taxes receivable.

[0001730168-20-000045:mdna:76]
| • | Accounts receivable increased to $3,677 million at February 3, 2019 from $3,325 million at November 4, 2018, primarily due to revenue linearity and an increase due to the CA Merger. |

[0001730168-20-000045:mdna:77]
| • | Employee compensation and benefits decreased to $463 million at February 3, 2019 from $715 million at November 4, 2018, primarily due to timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger. |

[0001730168-20-000045:mdna:78]
| • | Accounts payable decreased to $738 million at February 3, 2019 from $811 million at November 4, 2018, primarily due to timing of vendor payments, partially offset by increases due to the CA Merger. |

[0001730168-20-000045:mdna:79]
[same as prior period, unchanged from 0001730168-19-000118:mdna:89]

[0001730168-20-000045:mdna:80]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.25 |  |  | $ | 2.65 |  |
| Dividends to common stockholders |  | $ | 1,297 |  |  | $ | 1,067 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | — |  |
| Stock repurchases |  | $ | — |  |  | $ | 3,436 |  |

[0001730168-20-000045:mdna:81]
In addition, during the fiscal quarters ended February 2, 2020 and February 3, 2019, we paid approximately $169 million and $77 million, respectively, in employee withholding taxes due upon the vesting of, and related to net settled equity awards. We withheld approximately 0.5 million and 0.3 million shares of common stock from employees in connection with such net share settlements during the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively.

[0001730168-20-000045:mdna:82]
[same as prior period, unchanged from 0001730168-19-000118:mdna:96]

[0001730168-20-000045:mdna:83]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 2,322 |  |  | $ | 2,132 |  |
| Net cash used in investing activities |  | (10,987 | ) |  | (15,193 | ) |
| Net cash provided by financing activities |  | 10,054 |  |  | 13,862 |  |
| Net change in cash and cash equivalents |  | $ | 1,389 |  |  | $ | 801 |  |

[0001730168-20-000045:mdna:84]
[same as prior period, unchanged from 0001730168-19-000118:mdna:98]

[0001730168-20-000045:mdna:85]
Cash provided by operating activities consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. The $190 million increase in cash provided by operations during the fiscal quarter ended February 2, 2020 compared to the fiscal quarter ended February 3, 2019 was due to cash flows from net income adjusted for non-cash items, including amortization of intangible and right-of-use assets, stock-based compensation and deferred taxes and other non-cash taxes. The increase was partially offset by changes in operating assets and liabilities.

[0001730168-20-000045:mdna:86]
[same as prior period, unchanged from 0001730168-19-000118:mdna:100]

[0001730168-20-000045:mdna:87]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures and proceeds from the sale of a business. The $4,206 million decrease in cash used in investing activities during the fiscal quarter ended February 2, 2020 compared to the fiscal quarter ended February 3, 2019 was primarily related to $10.7 billion paid for the Symantec Asset Purchase in the fiscal year 2020 period, compared to $16,027 million paid for the CA Merger, offset in part by $957 million in proceeds from the sale of a business, in the prior year fiscal period.

[0001730168-20-000045:mdna:88]
[same as prior period, unchanged from 0001730168-19-000118:mdna:102]

[0001730168-20-000045:mdna:89]
Cash flows from financing activities primarily consisted of net proceeds and payments related to our long-term debt, dividend payments and stock repurchases. The $3,808 million decrease in cash provided by financing activities during the fiscal quarter ended February 2, 2020 compared to the fiscal quarter ended February 3, 2019 was primarily due to a decrease of $6,865 million in net proceeds from borrowings and an increase of $305 million of dividend payments, partially offset by an absence of repurchases of common stock under our repurchase program, which ended in the fiscal year 2019, as compared to $3,436 million of repurchases in the fiscal year 2019 period.

[0001730168-20-000045:mdna:90]
[same as prior period, unchanged from 0001730168-19-000118:mdna:104]

[0001730168-20-000045:mdna:91]
See Note 8. “Borrowings” in Part I, Item 1 of this Form 10-Q for additional information related to our indebtedness.

[0001730168-20-000045:mdna:92]
[same as prior period, unchanged from 0001730168-19-000118:mdna:106]

[0001730168-20-000045:mdna:93]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000045:mdna:94]
[same as prior period, unchanged from 0001730168-19-000118:mdna:108]

[0001730168-20-000045:mdna:95]
We had no material off-balance sheet arrangements at February 2, 2020 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-20-000045:mdna:96]
[same as prior period, unchanged from 0001730168-19-000118:mdna:110]

[0001730168-20-000045:mdna:97]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000045:mdna:98]
[same as prior period, unchanged from 0001730168-19-000118:mdna:113]

[0001730168-20-000045:mdna:99]
[same as prior period, unchanged from 0001730168-19-000118:mdna:114]
