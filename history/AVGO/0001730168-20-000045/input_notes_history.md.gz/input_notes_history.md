# AVGO note change history — 0001730168-19-000118 → 0001730168-20-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-03-13):
[0001730168-20-000045:note_history:1]
The following table summarizes contractual obligations and commitments as of February 2, 2020 that materially changed from the end of fiscal year 2019:
  (was, 2019-09-13, similarity 0.958):
[0001730168-19-000118:note_history:1]
The following table summarizes contractual obligations and commitments as of August 4, 2019 that materially changed from the end of fiscal year 2018:

- changed (2020-03-13):
[0001730168-20-000045:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 51,917 |  |  | $ | 4,236 |  |  | $ | 5,668 |  |  | $ | 8,289 |  |  | $ | 8,560 |  |  | $ | 6,382 |  |  | $ | 18,782 |  |
| Purchase commitments |  | 823 |  |  | 743 |  |  | 64 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 550 |  |  | 137 |  |  | 105 |  |  | 90 |  |  | 81 |  |  | 72 |  |  | 65 |  |
| Total |  | $ | 53,290 |  |  | $ | 5,116 |  |  | $ | 5,837 |  |  | $ | 8,395 |  |  | $ | 8,641 |  |  | $ | 6,454 |  |  | $ | 18,847 |  |
  (was, 2019-09-13, similarity 0.7393):
[0001730168-19-000118:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 (remainder) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 44,728 |  |  | $ | 1,306 |  |  | $ | 5,207 |  |  | $ | 4,112 |  |  | $ | 8,930 |  |  | $ | 2,490 |  |  | $ | 22,683 |  |
| Purchase commitments |  | 802 |  |  | 697 |  |  | 60 |  |  | 45 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 187 |  |  | 55 |  |  | 92 |  |  | 23 |  |  | 10 |  |  | 7 |  |  | — |  |
| Operating lease obligations |  | 769 |  |  | 31 |  |  | 105 |  |  | 89 |  |  | 59 |  |  | 51 |  |  | 434 |  |
| Total |  | $ | 46,486 |  |  | $ | 2,089 |  |  | $ | 5,464 |  |  | $ | 4,269 |  |  | $ | 8,999 |  |  | $ | 2,548 |  |  | $ | 23,117 |  |

- changed (2020-03-13):
[0001730168-20-000045:note_history:3]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended February 2, 2020.
  (was, 2019-09-13, similarity 0.9743):
[0001730168-19-000118:note_history:3]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 4, 2019.

- changed (2020-03-13):
[0001730168-20-000045:note_history:4]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.
  (was, 2019-09-13, similarity 0.7358):
[0001730168-19-000118:note_history:4]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

- changed (2020-03-13):
[0001730168-20-000045:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,297 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 2, 2020 have been excluded from the contractual obligations table above.
  (was, 2019-09-13, similarity 0.9716):
[0001730168-19-000118:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 4, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,361 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 4, 2019 have been excluded from the contractual obligations table above.

- changed (2020-03-13):
[0001730168-20-000045:note_history:6]
As of February 2, 2020 and November 3, 2019, we had standby letters of credit of $59 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.
  (was, 2019-09-13, similarity 0.9786):
[0001730168-19-000118:note_history:6]
As of August 4, 2019 and November 4, 2018, we had standby letters of credit of $65 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- added (2020-03-13):
[0001730168-20-000045:note_history:7]
Lawsuits Relating to California Institute of Technology

- added (2020-03-13):
[0001730168-20-000045:note_history:8]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties will file post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

- added (2020-03-13):
[0001730168-20-000045:note_history:9]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

- added (2020-03-13):
[0001730168-20-000045:note_history:10]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint

- added (2020-03-13):
[0001730168-20-000045:note_history:11]
seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

- removed (2020-03-13):
[0001730168-19-000118:note_history:12]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $61 million and $187 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Rent expense was $51 million and $178 million for the fiscal quarter and three fiscal quarters ended August 5, 2018, respectively.

- removed (2020-03-13):
[0001730168-19-000118:note_history:13]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On August 6, 2019, the U.S. Central District Court issued an order setting the briefing schedule for defendants’ motion to dismiss. We believe these claims are all without merit and intend to vigorously defend these actions.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-03-13):
[0001730168-20-000045:note_history:14]
Overview

- added (2020-03-13):
[0001730168-20-000045:note_history:15]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We also offer a cybersecurity solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries.

- added (2020-03-13):
[0001730168-20-000045:note_history:16]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing as of the acquisition date.

- added (2020-03-13):
[0001730168-20-000045:note_history:17]
During the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Prior period segment results have been recast to conform to the current presentation.

- added (2020-03-13):
[0001730168-20-000045:note_history:18]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ends on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

- changed (2020-03-13):
[0001730168-20-000045:note_history:19]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.
  (was, 2019-09-13, similarity 0.8784):
[0001730168-19-000118:note_history:19]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 4, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.

- changed (2020-03-13):
[0001730168-20-000045:note_history:20]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net cash activities.
  (was, 2019-09-13, similarity 0.8838):
[0001730168-19-000118:note_history:20]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statements of operations and condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net income or net cash activities.

- added (2020-03-13):
[0001730168-20-000045:note_history:21]
In February 2016, the Financial Accounting Standards Board issued ASU 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of the comparative period is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets

- added (2020-03-13):
[0001730168-20-000045:note_history:22]
included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statement of operations and comprehensive income and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.

- removed (2020-03-13):
[0001730168-19-000118:note_history:23]
Overview, Basis of Presentation and Significant Accounting Policies
Overview

- removed (2020-03-13):
[0001730168-19-000118:note_history:24]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Pte. Ltd. (formerly Broadcom Limited), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom eliminating their noncontrolling interest. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. We deregistered the Partnership and liquidated Broadcom-Singapore.

- removed (2020-03-13):
[0001730168-19-000118:note_history:25]
The Redomiciliation Transaction was accounted for as an exchange of equity interests among entities under common control and the historical basis of accounting was retained as if the entities had always been combined for financial reporting purposes.

- removed (2020-03-13):
[0001730168-19-000118:note_history:26]
The financial statements relate to Broadcom-Singapore for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, and relate to Broadcom for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

- removed (2020-03-13):
[0001730168-19-000118:note_history:27]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mobile, cloud, distributed and mainframe platforms.

- removed (2020-03-13):
[0001730168-19-000118:note_history:28]
On November 5, 2018, we acquired CA, Inc. (“CA”) for $16.1 billion, net of cash acquired (the “CA Merger”). CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018 (the “CA Acquisition Date”). See Note 3. “Acquisitions” for additional information.

- removed (2020-03-13):
[0001730168-19-000118:note_history:29]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property (“IP”) licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

- removed (2020-03-13):
[0001730168-19-000118:note_history:30]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ended on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.

- removed (2020-03-13):
[0001730168-19-000118:note_history:31]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board (“FASB”) guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.

- removed (2020-03-13):
[0001730168-19-000118:note_history:32]
In the first quarter of fiscal year 2019, we adopted the FASB guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and three fiscal quarters ended August 4, 2019, we also recognized $28 million and $95 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.

- removed (2020-03-13):
[0001730168-19-000118:note_history:33]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (“Topic 606”). We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. “Revenue from Contracts with Customers” for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

- removed (2020-03-13):
[0001730168-19-000118:note_history:34]
Recent Accounting Guidance Not Yet Adopted

- removed (2020-03-13):
[0001730168-19-000118:note_history:35]
In February 2016, the FASB issued guidance related to the accounting for leases, which principally requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. We will adopt this guidance using the optional transition method and will not restate comparative prior periods. We are finalizing the implementation of related systems, policies, processes and internal controls to comply with this guidance. Based on our lease portfolio as of August 4, 2019, we expect the adoption of the new leasing guidance to result in recognition of right-of-use assets and corresponding liabilities on our condensed consolidated balance sheet within a range of $500 million to $600 million, primarily related to real estate. However, the actual impact will depend on our lease portfolio as of the adoption date.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-03-13):
[0001730168-20-000045:note_history:36]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:
  (was, 2019-09-13, similarity 0.9268):
[0001730168-19-000118:note_history:36]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-03-13):
[0001730168-20-000045:note_history:37]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| 2020 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 3.13 | % |  | $ | 7,750 |  |  |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 3.14 | % |  | 7,750 |  |  |  |  | — |  |
|  |  |  |  | 15,500 |  |  |  |  | — |  |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 2,000 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
|  |  |  |  | 11,000 |  |  |  |  | 11,000 |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.10 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.19 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
|  |  |  |  | 600 |  |  |  |  | 1,600 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 750 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 3,500 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
|  |  |  |  | 14,800 |  |  |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
|  |  |  |  | 1,100 |  |  |  |  | 1,850 |  |
| Commercial paper |  | 2.27 | % | (a) | 2,000 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  |  | 22 |  |  | 2.59% - 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 45,022 |  |  |  |  | 33,059 |  |
| Less: Unaccreted net discount and unamortized debt issuance costs |  |  |  | (359 | ) |  |  |  | (261 | ) |
| Total debt |  |  |  | $ | 44,663 |  |  |  |  | $ | 32,798 |  |

- changed (2020-03-13):
[0001730168-20-000045:note_history:38]
(a) Represents the weighted average interest rate on outstanding commercial paper for each of the periods presented.
  (was, 2019-09-13, similarity 0.8411):
[0001730168-19-000118:note_history:38]
(a) Represents the weighted average interest rate on outstanding commercial paper as of August 4, 2019.

- added (2020-03-13):
[0001730168-20-000045:note_history:39]
As of February 2, 2020, $11 million and $44 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- added (2020-03-13):
[0001730168-20-000045:note_history:40]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to pay off $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”).

- added (2020-03-13):
[0001730168-20-000045:note_history:41]
2019 Term Loans

- added (2020-03-13):
[0001730168-20-000045:note_history:42]
In January 2020, we repaid $500 million of each of our unsecured term A-5 and A-7 facilities, collectively referred to as the “2019 Term Loans”, under the credit agreement entered into in May 2019 (the “2019 Credit Agreement), using net proceeds from Commercial Paper, as defined below.

- changed (2020-03-13):
[0001730168-20-000045:note_history:43]
The 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of February 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.
  (was, 2019-09-13, similarity 0.8133):
[0001730168-19-000118:note_history:43]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on August 4, 2019.

- added (2020-03-13):
[0001730168-20-000045:note_history:44]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of February 2, 2020 and November 3, 2019, we had $2 billion and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than seventy-five days. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance our Commercial Paper with newly issued Commercial Paper upon maturity. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- added (2020-03-13):
[0001730168-20-000045:note_history:45]
As of February 2, 2020, the estimated aggregate fair value of debt was $46,381 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 and 2020 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2020-03-13):
[0001730168-20-000045:note_history:46]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:
  (was, 2019-09-13, similarity 0.9268):
[0001730168-19-000118:note_history:46]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:

- changed (2020-03-13):
[0001730168-20-000045:note_history:47]
As of February 2, 2020 and November 3, 2019, we accrued interest payable of $203 million and $214 million, respectively, and were in compliance with all debt covenants.
  (was, 2019-09-13, similarity 0.9577):
[0001730168-19-000118:note_history:47]
As of August 4, 2019 and November 4, 2018, we accrued interest payable of $208 million and $165 million, respectively and were in compliance with all debt covenants.

- removed (2020-03-13):
[0001730168-19-000118:note_history:48]
|  |  | Effective Interest Rate |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due May 2022 |  | 3.683 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.729 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.820 | % |  | 2,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.855 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (294 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 37,565 |  |  | $ | 17,493 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:49]
2019 Senior Notes

- removed (2020-03-13):
[0001730168-19-000118:note_history:50]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.

- removed (2020-03-13):
[0001730168-19-000118:note_history:51]
In November 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- removed (2020-03-13):
[0001730168-19-000118:note_history:52]
On May 7, 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- removed (2020-03-13):
[0001730168-19-000118:note_history:53]
Revolving Facility

- removed (2020-03-13):
[0001730168-19-000118:note_history:54]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of August 4, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.

- removed (2020-03-13):
[0001730168-19-000118:note_history:55]
Assumed CA Senior Notes

- removed (2020-03-13):
[0001730168-19-000118:note_history:56]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- removed (2020-03-13):
[0001730168-19-000118:note_history:57]
As of August 4, 2019, the estimated aggregate fair value of debt was $37,934 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- removed (2020-03-13):
[0001730168-19-000118:note_history:58]
Pending Financing Arrangement
In connection with the Symantec Purchase Agreement, we entered into a commitment letter, with certain financial institutions to provide (i) up to $12 billion in term loans to fund the Symantec Asset Purchase and (ii) $3.5 billion in term loans to refinance certain existing senior notes maturing in the first quarter of our fiscal year 2020 (which begins on November 4, 2019).


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-03-13):
[0001730168-20-000045:note_history:59]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| 2020 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 3.13 | % |  | $ | 7,750 |  |  |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 3.14 | % |  | 7,750 |  |  |  |  | — |  |
|  |  |  |  | 15,500 |  |  |  |  | — |  |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 2,000 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
|  |  |  |  | 11,000 |  |  |  |  | 11,000 |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.10 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.19 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
|  |  |  |  | 600 |  |  |  |  | 1,600 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 750 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 3,500 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
|  |  |  |  | 14,800 |  |  |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
|  |  |  |  | 1,100 |  |  |  |  | 1,850 |  |
| Commercial paper |  | 2.27 | % | (a) | 2,000 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  |  | 22 |  |  | 2.59% - 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 45,022 |  |  |  |  | 33,059 |  |
| Less: Unaccreted net discount and unamortized debt issuance costs |  |  |  | (359 | ) |  |  |  | (261 | ) |
| Total debt |  |  |  | $ | 44,663 |  |  |  |  | $ | 32,798 |  |

- changed (2020-03-13):
[0001730168-20-000045:note_history:60]
(a) Represents the weighted average interest rate on outstanding commercial paper for each of the periods presented.
  (was, 2019-09-13, similarity 0.8411):
[0001730168-19-000118:note_history:60]
(a) Represents the weighted average interest rate on outstanding commercial paper as of August 4, 2019.

- added (2020-03-13):
[0001730168-20-000045:note_history:61]
As of February 2, 2020, $11 million and $44 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- added (2020-03-13):
[0001730168-20-000045:note_history:62]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to pay off $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”).

- added (2020-03-13):
[0001730168-20-000045:note_history:63]
2019 Term Loans

- added (2020-03-13):
[0001730168-20-000045:note_history:64]
In January 2020, we repaid $500 million of each of our unsecured term A-5 and A-7 facilities, collectively referred to as the “2019 Term Loans”, under the credit agreement entered into in May 2019 (the “2019 Credit Agreement), using net proceeds from Commercial Paper, as defined below.

- changed (2020-03-13):
[0001730168-20-000045:note_history:65]
The 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of February 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.
  (was, 2019-09-13, similarity 0.8133):
[0001730168-19-000118:note_history:65]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on August 4, 2019.

- added (2020-03-13):
[0001730168-20-000045:note_history:66]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of February 2, 2020 and November 3, 2019, we had $2 billion and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than seventy-five days. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance our Commercial Paper with newly issued Commercial Paper upon maturity. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- added (2020-03-13):
[0001730168-20-000045:note_history:67]
As of February 2, 2020, the estimated aggregate fair value of debt was $46,381 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 and 2020 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2020-03-13):
[0001730168-20-000045:note_history:68]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:
  (was, 2019-09-13, similarity 0.9268):
[0001730168-19-000118:note_history:68]
The future scheduled principal payments of debt as of August 4, 2019 were as follows:

- removed (2020-03-13):
[0001730168-19-000118:note_history:69]
|  |  | Effective Interest Rate |  | August 4, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due May 2022 |  | 3.683 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.729 | % |  | 2,000 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.820 | % |  | 2,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.855 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (294 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 37,565 |  |  | $ | 17,493 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:70]
2019 Senior Notes

- removed (2020-03-13):
[0001730168-19-000118:note_history:71]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.

- removed (2020-03-13):
[0001730168-19-000118:note_history:72]
In November 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- removed (2020-03-13):
[0001730168-19-000118:note_history:73]
On May 7, 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- removed (2020-03-13):
[0001730168-19-000118:note_history:74]
Revolving Facility

- removed (2020-03-13):
[0001730168-19-000118:note_history:75]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of August 4, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.

- removed (2020-03-13):
[0001730168-19-000118:note_history:76]
Assumed CA Senior Notes

- removed (2020-03-13):
[0001730168-19-000118:note_history:77]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- removed (2020-03-13):
[0001730168-19-000118:note_history:78]
As of August 4, 2019, the estimated aggregate fair value of debt was $37,934 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-03-13):
[0001730168-20-000045:note_history:79]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- added (2020-03-13):
[0001730168-20-000045:note_history:80]
|  |  | Fiscal Quarter Ended February 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services (a) |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:81]
|  |  | Fiscal Quarter Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:82]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- removed (2020-03-13):
[0001730168-19-000118:note_history:83]
Nature of Products and Services

- removed (2020-03-13):
[0001730168-19-000118:note_history:84]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

- removed (2020-03-13):
[0001730168-19-000118:note_history:85]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

- removed (2020-03-13):
[0001730168-19-000118:note_history:86]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

- removed (2020-03-13):
[0001730168-19-000118:note_history:87]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

- removed (2020-03-13):
[0001730168-19-000118:note_history:88]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

- removed (2020-03-13):
[0001730168-19-000118:note_history:89]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

- removed (2020-03-13):
[0001730168-19-000118:note_history:90]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

- removed (2020-03-13):
[0001730168-19-000118:note_history:91]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

- removed (2020-03-13):
[0001730168-19-000118:note_history:92]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- removed (2020-03-13):
[0001730168-19-000118:note_history:93]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- removed (2020-03-13):
[0001730168-19-000118:note_history:94]
Arrangements with Multiple Performance Obligations

- removed (2020-03-13):
[0001730168-19-000118:note_history:95]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

- removed (2020-03-13):
[0001730168-19-000118:note_history:96]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

- removed (2020-03-13):
[0001730168-19-000118:note_history:97]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

- removed (2020-03-13):
[0001730168-19-000118:note_history:98]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

- removed (2020-03-13):
[0001730168-19-000118:note_history:99]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

- removed (2020-03-13):
[0001730168-19-000118:note_history:100]
Other Policies and Judgments

- removed (2020-03-13):
[0001730168-19-000118:note_history:101]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

- removed (2020-03-13):
[0001730168-19-000118:note_history:102]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

- removed (2020-03-13):
[0001730168-19-000118:note_history:103]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-03-13):
[0001730168-20-000045:note_history:104]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations and comprehensive income. In addition, revenues by reportable segment are presented in Note 11. “Segment Information”.
  (was, 2019-09-13, similarity 0.9824):
[0001730168-19-000118:note_history:104]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. “Segment Information”.

- added (2020-03-13):
[0001730168-20-000045:note_history:105]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- added (2020-03-13):
[0001730168-20-000045:note_history:106]
|  |  | Fiscal Quarter Ended February 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services (a) |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- added (2020-03-13):
[0001730168-20-000045:note_history:107]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.

- changed (2020-03-13):
[0001730168-20-000045:note_history:108]
Contract assets and contract liabilities balances were as follows:
  (was, 2019-09-13, similarity 0.8049):
[0001730168-19-000118:note_history:108]
Contract assets and contract liabilities balances for the periods indicated below were as follows:

- changed (2020-03-13):
[0001730168-20-000045:note_history:109]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of February 2, 2020 (a) |  | $ | 208 |  |  | $ | 3,668 |  |
  (was, 2019-09-13, similarity 0.6612):
[0001730168-19-000118:note_history:109]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |

- added (2020-03-13):
[0001730168-20-000045:note_history:110]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of February 2, 2020.

- added (2020-03-13):
[0001730168-20-000045:note_history:111]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

- added (2020-03-13):
[0001730168-20-000045:note_history:112]
________________________________

- changed (2020-03-13):
[0001730168-20-000045:note_history:113]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.
  (was, 2019-09-13, similarity 0.7718):
[0001730168-19-000118:note_history:113]
(a) We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

- changed (2020-03-13):
[0001730168-20-000045:note_history:114]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.
  (was, 2019-09-13, similarity 0.9156):
[0001730168-19-000118:note_history:114]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.

- changed (2020-03-13):
[0001730168-20-000045:note_history:115]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for CA where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).
  (was, 2019-09-13, similarity 0.9805):
[0001730168-19-000118:note_history:115]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

- added (2020-03-13):
[0001730168-20-000045:note_history:116]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 2, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- removed (2020-03-13):
[0001730168-19-000118:note_history:117]
Nature of Products and Services

- removed (2020-03-13):
[0001730168-19-000118:note_history:118]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

- removed (2020-03-13):
[0001730168-19-000118:note_history:119]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

- removed (2020-03-13):
[0001730168-19-000118:note_history:120]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

- removed (2020-03-13):
[0001730168-19-000118:note_history:121]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

- removed (2020-03-13):
[0001730168-19-000118:note_history:122]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

- removed (2020-03-13):
[0001730168-19-000118:note_history:123]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

- removed (2020-03-13):
[0001730168-19-000118:note_history:124]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

- removed (2020-03-13):
[0001730168-19-000118:note_history:125]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

- removed (2020-03-13):
[0001730168-19-000118:note_history:126]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- removed (2020-03-13):
[0001730168-19-000118:note_history:127]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- removed (2020-03-13):
[0001730168-19-000118:note_history:128]
Arrangements with Multiple Performance Obligations

- removed (2020-03-13):
[0001730168-19-000118:note_history:129]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

- removed (2020-03-13):
[0001730168-19-000118:note_history:130]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

- removed (2020-03-13):
[0001730168-19-000118:note_history:131]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

- removed (2020-03-13):
[0001730168-19-000118:note_history:132]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

- removed (2020-03-13):
[0001730168-19-000118:note_history:133]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

- removed (2020-03-13):
[0001730168-19-000118:note_history:134]
Other Policies and Judgments

- removed (2020-03-13):
[0001730168-19-000118:note_history:135]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

- removed (2020-03-13):
[0001730168-19-000118:note_history:136]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

- removed (2020-03-13):
[0001730168-19-000118:note_history:137]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

- removed (2020-03-13):
[0001730168-19-000118:note_history:138]
|  |  | Fiscal Quarter Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:139]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:140]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 4, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- removed (2020-03-13):
[0001730168-19-000118:note_history:141]
Contract Costs

- removed (2020-03-13):
[0001730168-19-000118:note_history:142]
We have applied the practical expedient to expense commission costs as incurred for costs to obtain a contract when the amortization period would have been one year or less. As a result, no commission costs are capitalized.

- removed (2020-03-13):
[0001730168-19-000118:note_history:143]
We recognize an asset for costs incurred to fulfill a contract that are not within the scope of other accounting literature. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

- removed (2020-03-13):
[0001730168-19-000118:note_history:144]
Topic 606 Adoption

- removed (2020-03-13):
[0001730168-19-000118:note_history:145]
We applied Topic 606 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, we reflected the aggregate effect of all modifications when identifying the performance obligations and allocating the transaction price at transition, which did not have a material effect on the adjustment to retained earnings as of November 5, 2018.

- removed (2020-03-13):
[0001730168-19-000118:note_history:146]
We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:

- removed (2020-03-13):
[0001730168-19-000118:note_history:147]
| Balance Sheet |  | Ending Balance as of November 4, 2018 |  | Adjustments Due to Topic 606 |  | Opening Balance as of November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:148]
Impact of New Revenue Guidance on Net Revenue

- removed (2020-03-13):
[0001730168-19-000118:note_history:149]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and three fiscal quarters ended August 4, 2019 or in the condensed consolidated balance sheet as of August 4, 2019 were significantly affected by the new revenue guidance.

- removed (2020-03-13):
[0001730168-19-000118:note_history:150]
|  |  | Fiscal Quarter Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,413 |  |  | $ | — |  |  | $ | 4,413 |  |
| Subscriptions and services |  | 1,078 |  |  | 24 |  |  | 1,102 |  |
| Total net revenue |  | $ | 5,491 |  |  | $ | 24 |  |  | $ | 5,515 |  |

- removed (2020-03-13):
[0001730168-19-000118:note_history:151]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 13,470 |  |  | $ | — |  |  | $ | 13,470 |  |
| Subscriptions and services |  | 3,124 |  |  | 227 |  |  | 3,351 |  |
| Total net revenue |  | $ | 16,594 |  |  | $ | 227 |  |  | $ | 16,821 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-03-13):
[0001730168-20-000045:note_history:152]
Subsequent Events
Preferred Stock Cash Dividends Declared
  (was, 2019-09-13, similarity 0.8247):
[0001730168-19-000118:note_history:152]
Subsequent Event
Cash Dividends Declared

- changed (2020-03-13):
[0001730168-20-000045:note_history:153]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2020 to stockholders of record on March 15, 2020.
  (was, 2019-09-13, similarity 0.6978):
[0001730168-19-000118:note_history:153]
On September 11, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on October 1, 2019 to stockholders of record at the close of business on September 23, 2019.

- added (2020-03-13):
[0001730168-20-000045:note_history:154]
Common Stock Cash Dividends Declared

- added (2020-03-13):
[0001730168-20-000045:note_history:155]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on March 31, 2020 to stockholders of record on March 23, 2020.
