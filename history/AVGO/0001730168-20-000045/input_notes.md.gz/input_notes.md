# AVGO notes — 0001730168-20-000045


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-20-000045:notes:1]
Overview

[0001730168-20-000045:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We also offer a cybersecurity solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries.

[0001730168-20-000045:notes:3]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing as of the acquisition date.

[0001730168-20-000045:notes:4]
During the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Prior period segment results have been recast to conform to the current presentation.

[0001730168-20-000045:notes:5]
[same as prior period, unchanged from 0001730168-19-000118:notes:8]

[0001730168-20-000045:notes:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ends on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

[0001730168-20-000045:notes:7]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

[0001730168-20-000045:notes:8]
[same as prior period, unchanged from 0001730168-19-000118:notes:11]

[0001730168-20-000045:notes:9]
[same as prior period, unchanged from 0001730168-19-000118:notes:12]

[0001730168-20-000045:notes:10]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net cash activities.

[0001730168-20-000045:notes:11]
Recently Adopted Accounting Guidance

[0001730168-20-000045:notes:12]
In February 2016, the Financial Accounting Standards Board issued ASU 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of the comparative period is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets

[0001730168-20-000045:notes:13]
included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statement of operations and comprehensive income and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-20-000045:notes:14]
[same as prior period, unchanged from 0001730168-19-000118:notes:20]

[0001730168-20-000045:notes:15]
[same as prior period, unchanged from 0001730168-19-000118:notes:42]

[0001730168-20-000045:notes:16]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations and comprehensive income. In addition, revenues by reportable segment are presented in Note 11. “Segment Information”.

[0001730168-20-000045:notes:17]
[same as prior period, unchanged from 0001730168-19-000118:notes:44]

[0001730168-20-000045:notes:18]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

[0001730168-20-000045:notes:19]
|  |  | Fiscal Quarter Ended February 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services (a) |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

[0001730168-20-000045:notes:20]
[same as prior period, unchanged from 0001730168-19-000118:notes:47]

[0001730168-20-000045:notes:21]
[same as prior period, unchanged from 0001730168-19-000118:notes:48]

[0001730168-20-000045:notes:22]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.

[0001730168-20-000045:notes:23]
[same as prior period, unchanged from 0001730168-19-000118:notes:49]

[0001730168-20-000045:notes:24]
Contract assets and contract liabilities balances were as follows:

[0001730168-20-000045:notes:25]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of February 2, 2020 (a) |  | $ | 208 |  |  | $ | 3,668 |  |

[0001730168-20-000045:notes:26]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of February 2, 2020.

[0001730168-20-000045:notes:27]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

[0001730168-20-000045:notes:28]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

[0001730168-20-000045:notes:29]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.

[0001730168-20-000045:notes:30]
[same as prior period, unchanged from 0001730168-19-000118:notes:54]

[0001730168-20-000045:notes:31]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for CA where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-20-000045:notes:32]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 2, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-20-000045:notes:33]
Acquisitions
Acquisition of Symantec Corporation’s Enterprise Security Business

[0001730168-20-000045:notes:34]
On November 4, 2019 (the “Symantec Asset Purchase Date”), we completed the purchase of the Symantec Business, which was an established leader in cybersecurity, for $10.7 billion in cash. We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications. We financed the Symantec Asset Purchase with the net proceeds from borrowings under the 2020 Term Loans, as defined in Note 8. “Borrowings”.

[0001730168-20-000045:notes:35]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on their estimated fair values, which were based on estimates and assumptions made by management at the time of acquisition. As additional information becomes available, we may further revise our preliminary purchase price allocation during the remainder of the measurement period (which will not exceed 12 months from the Symantec Asset Purchase Date). Any such revisions or changes may be material.

[0001730168-20-000045:notes:36]
The following table presents our preliminary allocation of the total purchase price:

[0001730168-20-000045:notes:37]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 258 |  |
| Goodwill |  | 6,650 |  |
| Intangible assets |  | 5,413 |  |
| Other long-term assets |  | 93 |  |
| Total assets acquired |  | 12,414 |  |
| Current liabilities |  | (1,126 | ) |
| Other long-term liabilities |  | (588 | ) |
| Total liabilities assumed |  | (1,714 | ) |
| Fair value of net assets acquired |  | $ | 10,700 |  |

[0001730168-20-000045:notes:38]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Symantec Business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Symantec Asset Purchase. Substantially all goodwill is deductible for tax purposes.

[0001730168-20-000045:notes:39]
Current assets and current liabilities included amounts held-for-sale related to the acquired Symantec Cyber Security Services (“CSS”) business. The CSS business was not aligned with our acquisition-date strategic objectives and in January 2020, we entered into an agreement to sell this business. Accordingly, the results of CSS are presented in discontinued operations.

[0001730168-20-000045:notes:40]
Revenue attributable to the Symantec Business has been included in our infrastructure software segment. Transaction costs related to the Symantec Asset Purchase of $104 million were included in selling, general and administrative expense for the fiscal quarter ended February 2, 2020.

[0001730168-20-000045:notes:41]
[same as prior period, unchanged from 0001730168-19-000118:notes:79]

[0001730168-20-000045:notes:42]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,902 |  |  | 5 |
| Customer contracts and related relationships |  | 2,410 |  |  | 5 |
| Trade names |  | 90 |  |  | 6 |
| Order backlog |  | 11 |  |  | 3 |
| Total identified intangible assets |  | $ | 5,413 |  |  |  |

[0001730168-20-000045:notes:43]
Developed technology relates to products used for cybersecurity solutions, including data loss prevention, endpoint protection, network security, email security and cloud application security. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-20-000045:notes:44]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of the Symantec Business. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-20-000045:notes:45]
[same as prior period, unchanged from 0001730168-19-000118:notes:83]

[0001730168-20-000045:notes:46]
Trade name relates to the “Symantec” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-20-000045:notes:47]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Symantec Asset Purchase Date.

[0001730168-20-000045:notes:48]
[same as prior period, unchanged from 0001730168-19-000118:notes:90]

[0001730168-20-000045:notes:49]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if we had completed the Symantec Asset Purchase as of the beginning of fiscal year 2019. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For fiscal year 2019, non-recurring pro forma adjustments directly attributable to the Symantec Asset Purchase included transaction costs of $130 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-20-000045:notes:50]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 5,639 |  |  | $ | 6,333 |  |
| Pro forma net income attributable to common stock |  | $ | 229 |  |  | $ | 316 |  |

[0001730168-20-000045:notes:51]
Other Acquisitions

[0001730168-20-000045:notes:52]
During the fiscal quarter ended February 2, 2020, we also completed three other acquisitions qualifying as business combinations for total consideration of $201 million, of which $108 million was allocated to goodwill and $46 million was allocated to intangible assets. We do not consider these acquisitions to be material, individually or in the aggregate, to our condensed consolidated statements of operations and comprehensive income.

[0001730168-20-000045:notes:53]
Acquisition of CA, Inc.

[0001730168-20-000045:notes:54]
On November 5, 2018, we acquired CA for total consideration of $16.1 billion, net of cash acquired (“CA Merger”). CA was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities.

[0001730168-20-000045:notes:55]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if CA had been acquired as of the beginning of our fiscal year ended November 4, 2018 (“fiscal year 2018”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-20-000045:notes:56]
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |
| Pro forma net revenue |  | $ | 5,561 |  |
| Pro forma net income attributable to common stock |  | $ | 795 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-20-000045:notes:57]
[same as prior period, unchanged from 0001730168-19-000118:notes:101]

[0001730168-20-000045:notes:58]
Cash equivalents included $1,167 million and $850 million of time deposits as of February 2, 2020 and November 3, 2019, respectively. As of February 2, 2020 and November 3, 2019, cash equivalents also included $716 million and $649 million of money-market funds, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-20-000045:notes:59]
[same as prior period, unchanged from 0001730168-19-000118:notes:103]

[0001730168-20-000045:notes:60]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring agreements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring agreements were $901 million during the fiscal quarter ended February 2, 2020. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for the fiscal quarter ended February 2, 2020. There were no accounts receivable factoring activities during the fiscal quarter ended February 3, 2019.

[0001730168-20-000045:notes:61]
[same as prior period, unchanged from 0001730168-19-000118:notes:105]

[0001730168-20-000045:notes:62]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | (In millions) |
| Finished goods |  | $ | 359 |  |  | $ | 339 |  |
| Work-in-process |  | 427 |  |  | 414 |  |
| Raw materials |  | 158 |  |  | 121 |  |
| Total inventory |  | $ | 944 |  |  | $ | 874 |  |

[0001730168-20-000045:notes:63]
[same as prior period, unchanged from 0001730168-19-000118:notes:107]

[0001730168-20-000045:notes:64]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 420 |  |  | $ | 302 |  |
| Other (miscellaneous) |  | 650 |  |  | 427 |  |
| Total other current assets |  | $ | 1,070 |  |  | $ | 729 |  |

[0001730168-20-000045:notes:65]
[same as prior period, unchanged from 0001730168-19-000118:notes:109]

[0001730168-20-000045:notes:66]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 2,880 |  |  | $ | 1,501 |  |
| Other (miscellaneous) |  | 1,128 |  |  | 1,115 |  |
| Total other current liabilities |  | $ | 4,008 |  |  | $ | 2,616 |  |

[0001730168-20-000045:notes:67]
[same as prior period, unchanged from 0001730168-19-000118:notes:112]

[0001730168-20-000045:notes:68]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,297 |  |  | $ | 3,269 |  |
| Contract liabilities |  | 788 |  |  | 307 |  |
| Other (miscellaneous) |  | 2,379 |  |  | 2,037 |  |
| Total other long-term liabilities |  | $ | 6,464 |  |  | $ | 5,613 |  |

[0001730168-20-000045:notes:69]
[same as prior period, unchanged from 0001730168-19-000118:notes:116]

[0001730168-20-000045:notes:70]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 381 |  |  | $ | 423 |  |
| Cash paid for income taxes |  | $ | 131 |  |  | $ | 95 |  |

[0001730168-20-000045:notes:71]
As of February 2, 2020 and November 3, 2019, we had $46 million and $35 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## avgo:LesseeOperatingandFinanceLeasesTextBlockTextBlock

[0001730168-20-000045:notes:72]
Effective November 4, 2019, we adopted Topic 842 using the optional adoption method and elected practical expedients which allowed us to account for the lease and non-lease components as a single component. In addition, we elected not to reassess whether any expired or existing contracts contain leases and the corresponding lease classification and initial direct costs. The practical expedients were applied across our lease portfolios.

[0001730168-20-000045:notes:73]
We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize ROU assets and lease liabilities for operating and finance leases with terms greater than 12 months. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective-interest method over the lease term.

[0001730168-20-000045:notes:74]
We entered into operating and finance leases for our facilities, data centers and certain equipment. For the fiscal quarter ended February 2, 2020, we recorded $25 million of operating lease expense and $2 million of finance lease expense. For the fiscal quarter ended February 3, 2019, rent expense was $67 million.

[0001730168-20-000045:notes:75]
Other information related to leases was as follows:

[0001730168-20-000045:notes:76]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |
|  |  | (In millions) |
| Cash paid for operating leases included in operating cash flows |  | $ | 32 |  |  |
| ROU assets obtained in exchange for operating lease obligation |  | $ | 642 |  |  |
| ROU assets obtained in exchange for finance lease obligation |  | $ | 57 |  |  |
|  |  | February 2, 2020 |
| Weighted-average remaining lease term – operating leases (In years) |  | 11 |  |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 5 |  |  |
| Weighted-average discount rate – operating leases |  | 3.70 |  | % |
| Weighted-average discount rate – finance leases |  | 3.33 |  | % |

[0001730168-20-000045:notes:77]
Supplemental balance sheet information related to leases was as follows:

[0001730168-20-000045:notes:78]
|  |  | Classification on the Condensed Consolidated Balance Sheet |  | February 2, 2020 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  | $ | 620 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  | $ | 55 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  | $ | 95 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 568 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  | $ | 11 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 44 |  |

[0001730168-20-000045:notes:79]
The maturities of lease liabilities were as follows:

[0001730168-20-000045:notes:80]
|  |  | February 2, 2020 |
|  |  | Operating Lease |  | Finance Lease |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 87 |  |  | $ | 9 |  |
| 2021 |  | 110 |  |  | 13 |  |
| 2022 |  | 87 |  |  | 13 |  |
| 2023 |  | 80 |  |  | 13 |  |
| 2024 |  | 59 |  |  | 12 |  |
| Thereafter |  | 403 |  |  | — |  |
| Total undiscounted liabilities |  | 826 |  |  | 60 |  |
| Less: interest |  | 163 |  |  | 5 |  |
| Present value of lease liabilities |  | $ | 663 |  |  | $ | 55 |  |

[0001730168-20-000045:notes:81]
As of November 3, 2019, future minimum lease payments under non-cancelable lease liabilities prior to our adoption of Topic 842 were as follows:

[0001730168-20-000045:notes:82]
|  |  | November 3, 2019 |
|  |  | (In millions) |
| 2020 |  | $ | 115 |  |
| 2021 |  | 99 |  |
| 2022 |  | 80 |  |
| 2023 |  | 69 |  |
| 2024 |  | 47 |  |
| Thereafter |  | 390 |  |
| Total minimum lease payments |  | $ | 800 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-20-000045:notes:83]
[same as prior period, unchanged from 0001730168-19-000118:notes:119]

[0001730168-20-000045:notes:84]
|  |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 25,929 |  |  | $ | 10,776 |  |  | $ | 9 |  |  | $ | 36,714 |  |
| Reallocation due to change in segments |  | 9 |  |  | — |  |  | (9 | ) |  | — |  |
| Acquisitions |  | 35 |  |  | 6,723 |  |  | — |  |  | 6,758 |  |
| Balance as of February 2, 2020 |  | $ | 25,973 |  |  | $ | 17,499 |  |  | $ | — |  |  | $ | 43,472 |  |

[0001730168-20-000045:notes:85]
During the first quarter of fiscal year 2020, we changed our organizational structure to include our IP licensing segment in our semiconductor solutions segment, resulting in two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-20-000045:notes:86]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of February 2, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,031 |  |  | $ | (11,061 | ) |  | $ | 12,970 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (2,138 | ) |  | 6,251 |  |
| Order backlog |  | 2,579 |  |  | (1,140 | ) |  | 1,439 |  |
| Trade names |  | 797 |  |  | (262 | ) |  | 535 |  |
| Other |  | 247 |  |  | (91 | ) |  | 156 |  |
| Intangible assets subject to amortization |  | 36,043 |  |  | (14,692 | ) |  | 21,351 |  |
| In-process research and development |  | 114 |  |  | — |  |  | 114 |  |
| Total |  | $ | 36,157 |  |  | $ | (14,692 | ) |  | $ | 21,465 |  |
| As of November 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,935 |  |  | $ | (10,113 | ) |  | $ | 10,822 |  |
| Customer contracts and related relationships |  | 5,978 |  |  | (1,787 | ) |  | 4,191 |  |
| Order backlog |  | 2,569 |  |  | (908 | ) |  | 1,661 |  |
| Trade names |  | 712 |  |  | (247 | ) |  | 465 |  |
| Other |  | 241 |  |  | (89 | ) |  | 152 |  |
| Intangible assets subject to amortization |  | 30,435 |  |  | (13,144 | ) |  | 17,291 |  |
| In-process research and development |  | 263 |  |  | — |  |  | 263 |  |
| Total |  | $ | 30,698 |  |  | $ | (13,144 | ) |  | $ | 17,554 |  |

[0001730168-20-000045:notes:87]
Based on the amount of intangible assets subject to amortization at February 2, 2020, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-20-000045:notes:88]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 4,675 |  |
| 2021 |  | 5,394 |  |
| 2022 |  | 4,351 |  |
| 2023 |  | 3,222 |  |
| 2024 |  | 2,355 |  |
| Thereafter |  | 1,354 |  |
| Total |  | $ | 21,351 |  |

[0001730168-20-000045:notes:89]
[same as prior period, unchanged from 0001730168-19-000118:notes:125]

[0001730168-20-000045:notes:90]
| Amortizable intangible assets: |  | February 2, 2020 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 5 |
| Order backlog |  | 3 |
| Trade names |  | 9 |
| Other |  | 10 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-20-000045:notes:91]
[same as prior period, unchanged from 0001730168-19-000118:notes:127]

[0001730168-20-000045:notes:92]
Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested restricted stock units (“RSUs”), and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), collectively referred to as “equity awards,” as well as Mandatory Convertible Preferred Stock, as defined in Note 9. “Stockholders’ Equity.” Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-20-000045:notes:93]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of Mandatory Convertible Preferred Stock is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.

[0001730168-20-000045:notes:94]
For the fiscal quarter ended February 2, 2020, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-20-000045:notes:95]
[same as prior period, unchanged from 0001730168-19-000118:notes:131]

[0001730168-20-000045:notes:96]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |
| Income from continuing operations |  | $ | 380 |  |  | $ | 481 |  |
| Less: Dividends on preferred stock |  | 74 |  |  | — |  |
| Income from continuing operations attributable to common stock |  | 306 |  |  | 481 |  |
| Income (loss) from discontinued operations, net of income taxes, attributable to common stock |  | 5 |  |  | (10 | ) |
| Net income attributable to common stock |  | $ | 311 |  |  | $ | 471 |  |

[0001730168-20-000045:notes:97]
| Denominator: |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 398 |  |  | 401 |  |
| Dilutive effect of equity awards |  | 22 |  |  | 18 |  |
| Weighted-average shares outstanding - diluted |  | 420 |  |  | 419 |  |
| Basic income per share attributable to common stock: |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.77 |  |  | $ | 1.20 |  |
| Income (loss) per share from discontinued operations |  | 0.01 |  |  | (0.03 | ) |
| Net income per share |  | $ | 0.78 |  |  | $ | 1.17 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.73 |  |  | $ | 1.15 |  |
| Income (loss) per share from discontinued operations |  | 0.01 |  |  | (0.03 | ) |
| Net income per share |  | $ | 0.74 |  |  | $ | 1.12 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-20-000045:notes:98]
Borrowings

[0001730168-20-000045:notes:99]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| 2020 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 3.13 | % |  | $ | 7,750 |  |  |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 3.14 | % |  | 7,750 |  |  |  |  | — |  |
|  |  |  |  | 15,500 |  |  |  |  | — |  |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 2,000 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
|  |  |  |  | 11,000 |  |  |  |  | 11,000 |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.10 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.19 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
|  |  |  |  | 600 |  |  |  |  | 1,600 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 750 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 3,500 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
|  |  |  |  | 14,800 |  |  |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
|  |  |  |  | 1,100 |  |  |  |  | 1,850 |  |
| Commercial paper |  | 2.27 | % | (a) | 2,000 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  |  | 22 |  |  | 2.59% - 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 45,022 |  |  |  |  | 33,059 |  |
| Less: Unaccreted net discount and unamortized debt issuance costs |  |  |  | (359 | ) |  |  |  | (261 | ) |
| Total debt |  |  |  | $ | 44,663 |  |  |  |  | $ | 32,798 |  |

[0001730168-20-000045:notes:100]
(a) Represents the weighted average interest rate on outstanding commercial paper for each of the periods presented.

[0001730168-20-000045:notes:101]
As of February 2, 2020, $11 million and $44 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

[0001730168-20-000045:notes:102]
2020 Term Loans

[0001730168-20-000045:notes:103]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to pay off $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”).

[0001730168-20-000045:notes:104]
2019 Term Loans

[0001730168-20-000045:notes:105]
In January 2020, we repaid $500 million of each of our unsecured term A-5 and A-7 facilities, collectively referred to as the “2019 Term Loans”, under the credit agreement entered into in May 2019 (the “2019 Credit Agreement), using net proceeds from Commercial Paper, as defined below.

[0001730168-20-000045:notes:106]
The 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of February 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

[0001730168-20-000045:notes:107]
Commercial Paper

[0001730168-20-000045:notes:108]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of February 2, 2020 and November 3, 2019, we had $2 billion and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than seventy-five days. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance our Commercial Paper with newly issued Commercial Paper upon maturity. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

[0001730168-20-000045:notes:109]
Fair Value of Debt

[0001730168-20-000045:notes:110]
As of February 2, 2020, the estimated aggregate fair value of debt was $46,381 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 and 2020 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-20-000045:notes:111]
Future Principal Payments of Debt

[0001730168-20-000045:notes:112]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:

[0001730168-20-000045:notes:113]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 3,162 |  |
| 2021 |  | 4,300 |  |
| 2022 |  | 7,059 |  |
| 2023 |  | 7,644 |  |
| 2024 |  | 5,582 |  |
| Thereafter |  | 17,275 |  |
| Total |  | $ | 45,022 |  |

[0001730168-20-000045:notes:114]
As of February 2, 2020 and November 3, 2019, we accrued interest payable of $203 million and $214 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-20-000045:notes:115]
Stockholders’ Equity
Mandatory Convertible Preferred Stock

[0001730168-20-000045:notes:116]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (the “Mandatory Convertible Preferred Stock”), which generated net proceeds of approximately $3,679 million.

[0001730168-20-000045:notes:117]
On September 30, 2022, unless earlier converted, each outstanding share of the Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rate. At any time prior to September 30, 2022, holders may elect to convert each share of the Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of February 2, 2020, the minimum conversion rate was 3.0360 and the maximum conversion rate was 3.5488.

[0001730168-20-000045:notes:118]
We recognized $28 million and $29 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets as of February 2, 2020 and November 3, 2019, respectively.

[0001730168-20-000045:notes:119]
Cash Dividends Declared and Paid

[0001730168-20-000045:notes:120]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.25 |  |  | $ | 2.65 |  |
| Dividends to common stockholders |  | $ | 1,297 |  |  | $ | 1,067 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | — |  |

[0001730168-20-000045:notes:121]
Stock-Based Compensation Expense

[0001730168-20-000045:notes:122]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 31 |  |  | $ | 26 |  |
| Cost of subscriptions and services |  | 12 |  |  | 8 |  |
| Research and development |  | 391 |  |  | 311 |  |
| Selling, general and administrative |  | 111 |  |  | 120 |  |
| Total stock-based compensation expense |  | $ | 545 |  |  | $ | 465 |  |

[0001730168-20-000045:notes:123]
As of February 2, 2020, the total unrecognized compensation cost related to unvested stock-based awards was $5,454 million, which is expected to be recognized over the remaining weighted-average service period of 3.9 years.

[0001730168-20-000045:notes:124]
Equity Incentive Award Plans

[0001730168-20-000045:notes:125]
A summary of time- and market-based RSU activity is as follows:

[0001730168-20-000045:notes:126]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |
| Granted |  | 2 |  |  | $ | 277.80 |  |
| Vested |  | (2 | ) |  | $ | 206.58 |  |
| Forfeited |  | (1 | ) |  | $ | 192.84 |  |
| Balance as of February 2, 2020 |  | 39 |  |  | $ | 191.37 |  |

[0001730168-20-000045:notes:127]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended February 2, 2020 was $503 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-20-000045:notes:128]
A summary of time- and market-based stock option activity is as follows:

[0001730168-20-000045:notes:129]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  |  |  |  |
| Exercised |  | — |  | * | $ | 45.70 |  |  |  |  | $ | 217 |  |
| Balance as of February 2, 2020 |  | 4 |  |  | $ | 53.22 |  |  | 0.9 |  | $ | 908 |  |
| Fully vested as of February 2, 2020 |  | 4 |  |  | $ | 53.21 |  |  | 0.9 |  | $ | 906 |  |
| Fully vested and expected to vest as of February 2, 2020 |  | 4 |  |  | $ | 53.22 |  |  | 0.9 |  | $ | 908 |  |

[0001730168-20-000045:notes:130]
* Represents fewer than 1 million shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-20-000045:notes:131]
Income Taxes
The benefit from income taxes was $76 million and $203 million for the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively.

[0001730168-20-000045:notes:132]
The benefit from income taxes for the fiscal quarter ended February 2, 2020 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-20-000045:notes:133]
The benefit from income taxes for the fiscal quarter ended February 3, 2019 was primarily due to the resolution of uncertain tax positions as a result of audit settlements and lapses of statutes of limitations, partial release of our valuation allowance as a result of the CA Merger, and excess tax benefits from stock-based awards that were vested or exercised during the period.

[0001730168-20-000045:notes:134]
In connection with the Symantec Asset Purchase, we established $28 million of net deferred tax assets primarily as a result of the difference in the book basis and tax basis related to acquired assets. The deferred tax assets are based upon certain assumptions underlying our preliminary purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes may be required, provided we are in the measurement period.

[0001730168-20-000045:notes:135]
[same as prior period, unchanged from 0001730168-19-000118:notes:193]

[0001730168-20-000045:notes:136]
The balance of gross unrecognized tax benefits was $4,483 million and $4,422 million as of February 2, 2020 and November 3, 2019, respectively. This increase was primarily due to changes in uncertain tax positions from audit adjustments.

[0001730168-20-000045:notes:137]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of February 2, 2020 and November 3, 2019, the combined amount of cumulative accrued interest and penalties was approximately $315 million and $303 million, respectively.

[0001730168-20-000045:notes:138]
As of February 2, 2020 and November 3, 2019, approximately $4,798 million and $4,725 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-20-000045:notes:139]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $168 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-20-000045:notes:140]
[same as prior period, unchanged from 0001730168-19-000118:notes:198]

[0001730168-20-000045:notes:141]
During the first quarter of fiscal year 2020, we updated our organizational structure resulting in two reportable segments: semiconductor solutions and infrastructure software. Each segment represents components for which separate financial information is available that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-20-000045:notes:142]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, telecom, enterprise and embedded networking applications. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions and custom touch controllers for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-20-000045:notes:143]
Infrastructure software. We provide a portfolio of mainframe, enterprise and storage area networking solutions, which enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments, and to reduce the cost and complexity of managing business information within a shared storage environment. We also offer a cybersecurity solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions.

[0001730168-20-000045:notes:144]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, in addition to expenses associated with selling, general and administrative activities for the business, which are allocated primarily based on revenue, while facilities expenses are allocated primarily based on site-specific headcount.

[0001730168-20-000045:notes:145]
[same as prior period, unchanged from 0001730168-19-000118:notes:204]

[0001730168-20-000045:notes:146]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, charges related to inventory step-up to fair value, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-20-000045:notes:147]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for the fiscal quarters ended February 2, 2020 and February 3, 2019. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-20-000045:notes:148]
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |  | February 3, 2019 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |
| Semiconductor solutions |  | $ | 4,191 |  |  | $ | 4,386 |  |
| Infrastructure software |  | 1,667 |  |  | 1,403 |  |
| Total net revenue |  | $ | 5,858 |  |  | $ | 5,789 |  |
| Operating income (loss): |  |  |  |  |
| Semiconductor solutions |  | $ | 1,979 |  |  | $ | 2,032 |  |
| Infrastructure software |  | 1,105 |  |  | 1,020 |  |
| Unallocated expenses |  | (2,370 | ) |  | (2,497 | ) |
| Total operating income |  | $ | 714 |  |  | $ | 555 |  |

[0001730168-20-000045:notes:149]
[same as prior period, unchanged from 0001730168-19-000118:notes:208]

[0001730168-20-000045:notes:150]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. No customers accounted for 10% or more of our net accounts receivable balance at February 2, 2020, compared with one customer who accounted for 24% of our net accounts receivable balance at November 3, 2019.
One customer accounted for 14% of our net revenue during the fiscal quarter ended February 2, 2020, compared to 15% of our net revenue during the fiscal quarter ended February 3, 2019. Net revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-20-000045:notes:151]
Commitments and Contingencies
Commitments

[0001730168-20-000045:notes:152]
The following table summarizes contractual obligations and commitments as of February 2, 2020 that materially changed from the end of fiscal year 2019:

[0001730168-20-000045:notes:153]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 51,917 |  |  | $ | 4,236 |  |  | $ | 5,668 |  |  | $ | 8,289 |  |  | $ | 8,560 |  |  | $ | 6,382 |  |  | $ | 18,782 |  |
| Purchase commitments |  | 823 |  |  | 743 |  |  | 64 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 550 |  |  | 137 |  |  | 105 |  |  | 90 |  |  | 81 |  |  | 72 |  |  | 65 |  |
| Total |  | $ | 53,290 |  |  | $ | 5,116 |  |  | $ | 5,837 |  |  | $ | 8,395 |  |  | $ | 8,641 |  |  | $ | 6,454 |  |  | $ | 18,847 |  |

[0001730168-20-000045:notes:154]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended February 2, 2020.

[0001730168-20-000045:notes:155]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-20-000045:notes:156]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-20-000045:notes:157]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,297 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 2, 2020 have been excluded from the contractual obligations table above.

[0001730168-20-000045:notes:158]
Standby Letters of Credit

[0001730168-20-000045:notes:159]
As of February 2, 2020 and November 3, 2019, we had standby letters of credit of $59 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-20-000045:notes:160]
Contingencies

[0001730168-20-000045:notes:161]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-20-000045:notes:162]
Lawsuits Relating to California Institute of Technology

[0001730168-20-000045:notes:163]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties will file post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

[0001730168-20-000045:notes:164]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

[0001730168-20-000045:notes:165]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-20-000045:notes:166]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint

[0001730168-20-000045:notes:167]
seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

[0001730168-20-000045:notes:168]
Other Matters

[0001730168-20-000045:notes:169]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-20-000045:notes:170]
Contingency Assessment

[0001730168-20-000045:notes:171]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-20-000045:notes:172]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-20-000045:notes:173]
Other Indemnifications

[0001730168-20-000045:notes:174]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001730168-20-000045:notes:175]
Restructuring Charges
The following is a summary of significant restructuring expense recognized primarily in operating expenses:

[0001730168-20-000045:notes:176]
| • | In connection with the Symantec Asset Purchase, we initiated cost reduction activities and recognized $33 million of restructuring expense primarily related to employee termination costs during the fiscal quarter ended February 2, 2020. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020. |

[0001730168-20-000045:notes:177]
| • | During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $19 million and $594 million of restructuring expense primarily related to employee termination and lease and other exit costs during the fiscal quarters ended February 2, 2020 and February 3, 2019, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020. |

[0001730168-20-000045:notes:178]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the fiscal quarter ended February 2, 2020.

[0001730168-20-000045:notes:179]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 69 |  |  | $ | 39 |  |  | $ | 108 |  |
| Restructuring charges (a) |  | 51 |  |  | 11 |  |  | 62 |  |
| Utilization |  | (41 | ) |  | (14 | ) |  | (55 | ) |
| Effect of adoption of Topic 842 (b) |  | — |  |  | (36 | ) |  | (36 | ) |
| Balance as of February 2, 2020 (c) |  | $ | 79 |  |  | $ | — |  |  | $ | 79 |  |

[0001730168-20-000045:notes:180]
[same as prior period, unchanged from 0001730168-19-000118:notes:240]

[0001730168-20-000045:notes:181]
(a) Included $5 million of restructuring expense related to discontinued operations recognized during the fiscal quarter ended February 2, 2020, which was included in income from discontinued operations.

[0001730168-20-000045:notes:182]
(b) Upon adoption of Topic 842, certain restructuring lease liabilities were required to be recognized as a reduction to the corresponding ROU assets.

[0001730168-20-000045:notes:183]
(c) The majority of the employee termination costs balance is expected to be paid by the end of fiscal year 2020.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-20-000045:notes:184]
Condensed Consolidating Financial Information
Broadcom and BTI, a 100%-owned subsidiary of Broadcom, fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the senior unsecured notes issued by BRCM and Broadcom Cayman Finance Limited (“Cayman Finance”) in fiscal year 2017 (the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC. During fiscal year 2019, Cayman Finance was merged into BTI, with BTI remaining as the surviving entity. In connection with this merger, BTI remains a guarantor and became co-issuer of the 2017 Senior Notes.

[0001730168-20-000045:notes:185]
We have applied the impacts of the change in guarantors and issuers retrospectively to all periods presented, which resulted in the following column headings in the proceeding tables:

[0001730168-20-000045:notes:186]
[same as prior period, unchanged from 0001730168-19-000118:notes:245]

[0001730168-20-000045:notes:187]
[same as prior period, unchanged from 0001730168-19-000118:notes:246]

[0001730168-20-000045:notes:188]
[same as prior period, unchanged from 0001730168-19-000118:notes:247]

[0001730168-20-000045:notes:189]
The following tables set forth the condensed consolidating financial information for the Parent Guarantor, the Subsidiary Issuers, and the Non-Guarantor Subsidiaries for the periods presented. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor, the Subsidiary Issuers and the Non-Guarantor Subsidiaries are reflected in the Eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.

[0001730168-20-000045:notes:190]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | February 2, 2020 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 576 |  |  | $ | 758 |  |  | $ | 5,110 |  |  | $ | — |  |  | $ | 6,444 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,651 |  |  | — |  |  | 3,651 |  |
| Inventory |  | — |  |  | — |  |  | 944 |  |  | — |  |  | 944 |  |
| Intercompany receivable |  | 3,667 |  |  | 835 |  |  | 145 |  |  | (4,647 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 9,996 |  |  | 8,228 |  |  | (18,224 | ) |  | — |  |
| Other current assets |  | 170 |  |  | 44 |  |  | 856 |  |  | — |  |  | 1,070 |  |
| Total current assets |  | 4,413 |  |  | 11,633 |  |  | 18,934 |  |  | (22,871 | ) |  | 12,109 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 771 |  |  | 1,845 |  |  | — |  |  | 2,616 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 42,112 |  |  | — |  |  | 43,472 |  |
| Intangible assets, net |  | — |  |  | 74 |  |  | 21,391 |  |  | — |  |  | 21,465 |  |
| Investment in subsidiaries |  | 52,576 |  |  | 47,524 |  |  | — |  |  | (100,100 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | 8,248 |  |  | — |  |  | 932 |  |  | (9,180 | ) |  | — |  |
| Other long-term assets |  | 23 |  |  | 389 |  |  | 932 |  |  | — |  |  | 1,344 |  |
| Total assets |  | $ | 65,260 |  |  | $ | 61,751 |  |  | $ | 86,146 |  |  | $ | (132,151 | ) |  | $ | 81,006 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 23 |  |  | $ | 56 |  |  | $ | 906 |  |  | $ | — |  |  | $ | 985 |  |
| Employee compensation and benefits |  | — |  |  | 90 |  |  | 345 |  |  | — |  |  | 435 |  |
| Current portion of long-term debt |  | 1,550 |  |  | 750 |  |  | 11 |  |  | — |  |  | 2,311 |  |
| Intercompany payable |  | 168 |  |  | 2,784 |  |  | 1,695 |  |  | (4,647 | ) |  | — |  |
| Intercompany loan payable |  | 11,848 |  |  | 5,271 |  |  | 1,105 |  |  | (18,224 | ) |  | — |  |
| Other current liabilities |  | 150 |  |  | 75 |  |  | 3,783 |  |  | — |  |  | 4,008 |  |
| Total current liabilities |  | 13,739 |  |  | 9,026 |  |  | 7,845 |  |  | (22,871 | ) |  | 7,739 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 27,287 |  |  | 13,987 |  |  | 1,133 |  |  | — |  |  | 42,407 |  |
| Deferred tax liabilities |  | (151 | ) | (a) | (292 | ) | (a) | 1,762 |  |  | — |  |  | 1,319 |  |
| Intercompany loan payable, long-term |  | — |  |  | 932 |  |  | 8,248 |  |  | (9,180 | ) |  | — |  |
| Unrecognized tax benefits |  | (11 | ) | (b) | 2,472 |  |  | 836 |  |  | — |  |  | 3,297 |  |
| Other long-term liabilities |  | — |  |  | 382 |  |  | 1,466 |  |  | — |  |  | 1,848 |  |
| Total liabilities |  | 40,864 |  |  | 26,507 |  |  | 21,290 |  |  | (32,051 | ) |  | 56,610 |  |
| Preferred stock dividend obligation |  | 28 |  |  | — |  |  | — |  |  | — |  |  | 28 |  |
| Total stockholders’ equity |  | 24,368 |  |  | 35,244 |  |  | 64,856 |  |  | (100,100 | ) |  | 24,368 |  |
| Total liabilities and equity |  | $ | 65,260 |  |  | $ | 61,751 |  |  | $ | 86,146 |  |  | $ | (132,151 | ) |  | $ | 81,006 |  |

[0001730168-20-000045:notes:191]
[same as prior period, unchanged from 0001730168-19-000118:notes:251]

[0001730168-20-000045:notes:192]
(b) Amount represents net unrecognized tax benefit assets that are offset by net unrecognized tax benefit liabilities on a consolidated basis.

[0001730168-20-000045:notes:193]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | November 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 374 |  |  | $ | 613 |  |  | $ | 4,068 |  |  | $ | — |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,259 |  |  | — |  |  | 3,259 |  |
| Inventory |  | — |  |  | — |  |  | 874 |  |  | — |  |  | 874 |  |
| Intercompany receivable |  | 59 |  |  | 439 |  |  | 35 |  |  | (533 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 10,576 |  |  | 9,188 |  |  | (19,764 | ) |  | — |  |
| Other current assets |  | 58 |  |  | 37 |  |  | 634 |  |  | — |  |  | 729 |  |
| Total current assets |  | 491 |  |  | 11,665 |  |  | 18,058 |  |  | (20,297 | ) |  | 9,917 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 759 |  |  | 1,806 |  |  | — |  |  | 2,565 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 35,354 |  |  | — |  |  | 36,714 |  |
| Intangible assets, net |  | — |  |  | 76 |  |  | 17,478 |  |  | — |  |  | 17,554 |  |
| Investment in subsidiaries |  | 51,558 |  |  | 45,981 |  |  | — |  |  | (97,539 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 932 |  |  | (932 | ) |  | — |  |
| Other long-term assets |  | 25 |  |  | 95 |  |  | 623 |  |  | — |  |  | 743 |  |
| Total assets |  | $ | 52,074 |  |  | $ | 59,936 |  |  | $ | 74,251 |  |  | $ | (118,768 | ) |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 24 |  |  | $ | 38 |  |  | $ | 793 |  |  | $ | — |  |  | $ | 855 |  |
| Employee compensation and benefits |  | — |  |  | 179 |  |  | 462 |  |  | — |  |  | 641 |  |
| Current portion of long-term debt |  | — |  |  | 2,750 |  |  | 37 |  |  | — |  |  | 2,787 |  |
| Intercompany payable |  | 32 |  |  | 4 |  |  | 497 |  |  | (533 | ) |  | — |  |
| Intercompany loan payable |  | 13,709 |  |  | 4,935 |  |  | 1,120 |  |  | (19,764 | ) |  | — |  |
| Other current liabilities |  | 25 |  |  | 186 |  |  | 2,405 |  |  | — |  |  | 2,616 |  |
| Total current liabilities |  | 13,790 |  |  | 8,092 |  |  | 5,314 |  |  | (20,297 | ) |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 13,440 |  |  | 14,731 |  |  | 1,840 |  |  | — |  |  | 30,011 |  |
| Deferred tax liabilities |  | (126 | ) | (a) | (295 | ) | (a) | 1,952 |  |  | — |  |  | 1,531 |  |
| Intercompany loan payable, long-term |  | — |  |  | 932 |  |  | — |  |  | (932 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | 2,422 |  |  | 847 |  |  | — |  |  | 3,269 |  |
| Other long-term liabilities |  | — |  |  | 107 |  |  | 706 |  |  | — |  |  | 813 |  |
| Total liabilities |  | 27,104 |  |  | 25,989 |  |  | 10,659 |  |  | (21,229 | ) |  | 42,523 |  |
| Preferred stock dividend obligation |  | 29 |  |  | — |  |  | — |  |  | — |  |  | 29 |  |
| Total stockholders’ equity |  | 24,941 |  |  | 33,947 |  |  | 63,592 |  |  | (97,539 | ) |  | 24,941 |  |
| Total liabilities and equity |  | $ | 52,074 |  |  | $ | 59,936 |  |  | $ | 74,251 |  |  | $ | (118,768 | ) |  | $ | 67,493 |  |

[0001730168-20-000045:notes:194]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 4,204 |  |  | $ | — |  |  | $ | 4,204 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 1,654 |  |  | — |  |  | 1,654 |  |
| Intercompany revenue |  | — |  |  | 405 |  |  | — |  |  | (405 | ) |  | — |  |
| Total net revenue |  | — |  |  | 405 |  |  | 5,858 |  |  | (405 | ) |  | 5,858 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 33 |  |  | 1,426 |  |  | — |  |  | 1,459 |  |
| Cost of subscriptions and services |  | — |  |  | 5 |  |  | 172 |  |  | — |  |  | 177 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 32 |  |  | (32 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 950 |  |  | — |  |  | 950 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total cost of revenue |  | — |  |  | 38 |  |  | 2,588 |  |  | (32 | ) |  | 2,594 |  |
| Gross margin |  | — |  |  | 367 |  |  | 3,270 |  |  | (373 | ) |  | 3,264 |  |
| Research and development |  | — |  |  | 482 |  |  | 807 |  |  | — |  |  | 1,289 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 373 |  |  | (373 | ) |  | — |  |
| Selling, general and administrative |  | 140 |  |  | 76 |  |  | 385 |  |  | — |  |  | 601 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 603 |  |  | — |  |  | 603 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 5 |  |  | 52 |  |  | — |  |  | 57 |  |
| Total operating expenses |  | 140 |  |  | 563 |  |  | 2,220 |  |  | (373 | ) |  | 2,550 |  |
| Operating income (loss) |  | (140 | ) |  | (196 | ) |  | 1,050 |  |  | — |  |  | 714 |  |
| Interest expense |  | (247 | ) |  | (145 | ) |  | (14 | ) |  | — |  |  | (406 | ) |
| Intercompany interest expense |  | (66 | ) |  | (34 | ) |  | (43 | ) |  | 143 |  |  | — |  |
| Other income (expense), net |  | 3 |  |  | 4 |  |  | (11 | ) |  | — |  |  | (4 | ) |
| Intercompany interest income |  | 33 |  |  | 64 |  |  | 46 |  |  | (143 | ) |  | — |  |
| Intercompany other income (expense), net |  | 166 |  |  | — |  |  | (166 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (251 | ) |  | (307 | ) |  | 862 |  |  | — |  |  | 304 |  |
| Provision for (benefit from) income taxes |  | (28 | ) |  | 81 |  |  | (129 | ) |  | — |  |  | (76 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (223 | ) |  | (388 | ) |  | 991 |  |  | — |  |  | 380 |  |
| Earnings in subsidiaries |  | 608 |  |  | 1,325 |  |  | — |  |  | (1,933 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 385 |  |  | 937 |  |  | 991 |  |  | (1,933 | ) |  | 380 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Net income |  | $ | 385 |  |  | $ | 937 |  |  | $ | 996 |  |  | $ | (1,933 | ) |  | $ | 385 |  |
| Comprehensive income |  | $ | 385 |  |  | $ | 937 |  |  | $ | 996 |  |  | $ | (1,933 | ) |  | $ | 385 |  |

[0001730168-20-000045:notes:195]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 1,150 |  |  | — |  |  | 1,150 |  |
| Intercompany revenue |  | — |  |  | 397 |  |  | — |  |  | (397 | ) |  | — |  |
| Total net revenue |  | — |  |  | 397 |  |  | 5,789 |  |  | (397 | ) |  | 5,789 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 31 |  |  | 1,523 |  |  | — |  |  | 1,554 |  |
| Cost of subscriptions and services |  | — |  |  | 3 |  |  | 135 |  |  | — |  |  | 138 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 23 |  |  | (23 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 833 |  |  | — |  |  | 833 |  |
| Restructuring charges |  | — |  |  | (7 | ) |  | 63 |  |  | — |  |  | 56 |  |
| Total cost of revenue |  | — |  |  | 27 |  |  | 2,577 |  |  | (23 | ) |  | 2,581 |  |
| Gross margin |  | — |  |  | 370 |  |  | 3,212 |  |  | (374 | ) |  | 3,208 |  |
| Research and development |  | — |  |  | 447 |  |  | 686 |  |  | — |  |  | 1,133 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 374 |  |  | (374 | ) |  | — |  |
| Selling, general and administrative |  | 52 |  |  | 81 |  |  | 338 |  |  | — |  |  | 471 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 476 |  |  | — |  |  | 476 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 8 |  |  | 565 |  |  | — |  |  | 573 |  |
| Total operating expenses |  | 52 |  |  | 536 |  |  | 2,439 |  |  | (374 | ) |  | 2,653 |  |
| Operating income (loss) |  | (52 | ) |  | (166 | ) |  | 773 |  |  | — |  |  | 555 |  |
| Interest expense |  | (175 | ) |  | (148 | ) |  | (22 | ) |  | — |  |  | (345 | ) |
| Intercompany interest expense |  | (86 | ) |  | (41 | ) |  | (8 | ) |  | 135 |  |  | — |  |
| Other income (expense), net |  | (1 | ) |  | 9 |  |  | 60 |  |  | — |  |  | 68 |  |
| Intercompany interest income |  | — |  |  | 79 |  |  | 56 |  |  | (135 | ) |  | — |  |
| Intercompany other income (expense), net |  | 77 |  |  | — |  |  | (77 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (237 | ) |  | (267 | ) |  | 782 |  |  | — |  |  | 278 |  |
| Benefit from income taxes |  | (24 | ) |  | (153 | ) |  | (26 | ) |  | — |  |  | (203 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (213 | ) |  | (114 | ) |  | 808 |  |  | — |  |  | 481 |  |
| Earnings in subsidiaries |  | 684 |  |  | 1,569 |  |  | — |  |  | (2,253 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 471 |  |  | 1,455 |  |  | 808 |  |  | (2,253 | ) |  | 481 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 798 |  |  | $ | (2,253 | ) |  | $ | 471 |  |
| Comprehensive income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 798 |  |  | $ | (2,253 | ) |  | $ | 471 |  |

[0001730168-20-000045:notes:196]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Quarter Ended |
|  |  | February 2, 2020 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 385 |  |  | $ | 937 |  |  | $ | 996 |  |  | $ | (1,933 | ) |  | $ | 385 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (4,106 | ) |  | 1,166 |  |  | 2,944 |  |  | 1,933 |  |  | 1,937 |  |
| Net cash provided by (used in) operating activities |  | (3,721 | ) |  | 2,103 |  |  | 3,940 |  |  | — |  |  | 2,322 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | (8,248 | ) |  | 580 |  |  | 959 |  |  | 6,709 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (10,870 | ) |  | — |  |  | (10,870 | ) |
| Purchases of property, plant and equipment |  | — |  |  | (40 | ) |  | (69 | ) |  | 1 |  |  | (108 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |  | — |  |
| Other |  | — |  |  | (4 | ) |  | (5 | ) |  | — |  |  | (9 | ) |
| Net cash provided by (used in) investing activities |  | (8,248 | ) |  | 537 |  |  | (9,985 | ) |  | 6,709 |  |  | (10,987 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Net intercompany borrowings |  | (1,861 | ) |  | 337 |  |  | 8,233 |  |  | (6,709 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 15,381 |  |  | — |  |  | — |  |  | — |  |  | 15,381 |  |
| Repayment of debt |  | (1,000 | ) |  | (2,750 | ) |  | (787 | ) |  | — |  |  | (4,537 | ) |
| Other borrowings, net |  | 991 |  |  | — |  |  | (273 | ) |  | — |  |  | 718 |  |
| Payment of dividends |  | (1,372 | ) |  | — |  |  | — |  |  | — |  |  | (1,372 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (82 | ) |  | (87 | ) |  | — |  |  | (169 | ) |
| Issuance of common stock |  | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |
| Other |  | (5 | ) |  | — |  |  | 1 |  |  | — |  |  | (4 | ) |
| Net cash provided by (used in) financing activities |  | 12,171 |  |  | (2,495 | ) |  | 7,087 |  |  | (6,709 | ) |  | 10,054 |  |
| Net change in cash and cash equivalents |  | 202 |  |  | 145 |  |  | 1,042 |  |  | — |  |  | 1,389 |  |
| Cash and cash equivalents at beginning of period |  | 374 |  |  | 613 |  |  | 4,068 |  |  | — |  |  | 5,055 |  |
| Cash and cash equivalents at end of period |  | $ | 576 |  |  | $ | 758 |  |  | $ | 5,110 |  |  | $ | — |  |  | $ | 6,444 |  |

[0001730168-20-000045:notes:197]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Quarter Ended |
|  |  | February 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 471 |  |  | $ | 1,455 |  |  | $ | 798 |  |  | $ | (2,253 | ) |  | $ | 471 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (561 | ) |  | (2,451 | ) |  | 2,420 |  |  | 2,253 |  |  | 1,661 |  |
| Net cash provided by (used in) operating activities |  | (90 | ) |  | (996 | ) |  | 3,218 |  |  | — |  |  | 2,132 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | 800 |  |  | (592 | ) |  | (3,087 | ) |  | 2,879 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | (17,865 | ) |  | — |  |  | 1,838 |  |  | — |  |  | (16,027 | ) |
| Proceeds from sale of business |  | — |  |  | — |  |  | 957 |  |  | — |  |  | 957 |  |
| Purchases of property, plant and equipment |  | — |  |  | (36 | ) |  | (71 | ) |  | 8 |  |  | (99 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 8 |  |  | — |  |  | (8 | ) |  | — |  |
| Other |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | (24 | ) |
| Net cash used in investing activities |  | (17,065 | ) |  | (620 | ) |  | (387 | ) |  | 2,879 |  |  | (15,193 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Net intercompany borrowings |  | 3,746 |  |  | (110 | ) |  | (757 | ) |  | (2,879 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 17,896 |  |  | — |  |  | — |  |  | — |  |  | 17,896 |  |
| Other borrowings, net |  | — |  |  | — |  |  | 531 |  |  | — |  |  | 531 |  |
| Payment of dividends |  | (1,067 | ) |  | — |  |  | — |  |  | — |  |  | (1,067 | ) |
| Repurchases of common stock - repurchase program |  | (3,436 | ) |  | — |  |  | — |  |  | — |  |  | (3,436 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (11 | ) |  | (66 | ) |  | — |  |  | (77 | ) |
| Issuance of common stock |  | 62 |  |  | — |  |  | — |  |  | — |  |  | 62 |  |
| Other |  | (46 | ) |  | — |  |  | (1 | ) |  | — |  |  | (47 | ) |
| Net cash provided by (used in) financing activities |  | 17,155 |  |  | (121 | ) |  | (293 | ) |  | (2,879 | ) |  | 13,862 |  |
| Net change in cash and cash equivalents |  | — |  |  | (1,737 | ) |  | 2,538 |  |  | — |  |  | 801 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | 2,461 |  |  | 1,831 |  |  | — |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 724 |  |  | $ | 4,369 |  |  | $ | — |  |  | $ | 5,093 |  |


## us-gaap:SubsequentEventsTextBlock

[0001730168-20-000045:notes:198]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-20-000045:notes:199]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2020 to stockholders of record on March 15, 2020.

[0001730168-20-000045:notes:200]
Common Stock Cash Dividends Declared

[0001730168-20-000045:notes:201]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on March 31, 2020 to stockholders of record on March 23, 2020.
