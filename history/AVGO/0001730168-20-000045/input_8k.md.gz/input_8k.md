# AVGO 8-K — 0001193125-20-071608 filed 2020-03-12

## item codes, every 8-K on or before 2020-03-13

- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2020-03-13

- none on or before 2020-03-13

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-071608:8k_2_02:1]
EX-99.1
2
d859221dex991.htm
EX-99.1

[0001193125-20-071608:8k_2_02:2]
EX-99.1

[0001193125-20-071608:8k_2_02:3]
Exhibit 99.1

[0001193125-20-071608:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2020 Financial Results, Quarterly Dividend and Updated Guidance

[0001193125-20-071608:8k_2_02:5]
|  | • |  | Revenue of $5,858 million; GAAP net income of $385 million; Adjusted EBITDA of $3,265 million |

[0001193125-20-071608:8k_2_02:6]
|  | • |  | GAAP diluted EPS of $0.74; Non-GAAP diluted EPS of $5.25 |

[0001193125-20-071608:8k_2_02:7]
|  | • |  | $2,214 million of free cash flow from operations, defined as cash from operations of $2,322 million less capital expenditures of $108 million |

[0001193125-20-071608:8k_2_02:8]
|  | • |  | Quarterly common stock dividend of $3.25 per share |

[0001193125-20-071608:8k_2_02:9]
|  | • |  | Providing quarterly guidance, and withdrawing prior annual guidance, in light of uncertainties arising from the effects of COVID-19 |

[0001193125-20-071608:8k_2_02:10]
|  | • |  | Second quarter revenue guidance of $5.7 billion plus or minus $150 million |

[0001193125-20-071608:8k_2_02:11]
|  | • |  | Second quarter Adjusted EBITDA guidance of $3,135 million plus or minus $75 million, or 55% of revenue at the midpoint of guidance 1 |

[0001193125-20-071608:8k_2_02:12]
SAN JOSE, Calif. – March 12, 2020 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and
supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2020, ended February 2, 2020, announced its quarterly dividend and updated guidance.

[0001193125-20-071608:8k_2_02:13]
“Our first fiscal quarter results were in line with our expectations, with our networking, storage and broadband businesses together growing nicely year
over year,” said Hock Tan, President and CEO of Broadcom Inc. “The fundamental semiconductor backdrop has been improving, and we did not see any material impact on our businesses due to COVID-19 in
our first quarter. However, visibility in our global markets is lacking and demand uncertainty is intensifying. As a result, we believe it prudent to withdraw our annual guidance until visibility returns to pre COVID-19 levels.”

[0001193125-20-071608:8k_2_02:14]
“We generated over $2.2 billion in free cash flow in the quarter, which represented 9% growth on a year on year basis,” said Tom Krause, CFO of
Broadcom Inc. “We ended the first quarter with over $6.4 billion of cash on hand and our cash flow outlook remains healthy. As a result, we are well positioned to continue to support our dividends to stockholders despite the challenging market
backdrop.”

[0001193125-20-071608:8k_2_02:15]
| 1 | The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort. |

[0001193125-20-071608:8k_2_02:16]
1

[0001193125-20-071608:8k_2_02:17]
First Quarter Fiscal Year 2020 Financial Highlights

[0001193125-20-071608:8k_2_02:18]
|  |  | GAAP |  |  | Non-GAAP |  |
| (Dollars in millions, except per share data) |  | Q1 20 |  |  | Q1 19 |  |  | Change |  |  | Q1 20 |  |  | Q1 19 |  |  | Change |  |
| Net revenue |  | $ | 5,858 |  |  | $ | 5,789 |  |  |  | +1 | % |  | $ | 5,858 |  |  | $ | 5,789 |  |  |  | +1 | % |
| Net income |  | $ | 385 |  |  | $ | 471 |  |  | -$ | 86 |  |  | $ | 2,370 |  |  | $ | 2,446 |  |  | -$ | 76 |  |
| Earnings per common share - diluted |  | $ | 0.74 |  |  | $ | 1.12 |  |  | -$ | 0.38 |  |  | $ | 5.25 |  |  | $ | 5.55 |  |  | -$ | 0.30 |  |

[0001193125-20-071608:8k_2_02:19]
| (Dollars in millions) |  | Q1 20 |  |  | Q1 19 |  |  | Change |  |
| Cash flow from operations |  | $ | 2,322 |  |  | $ | 2,132 |  |  | +$ | 190 |  |
| Adjusted EBITDA |  | $ | 3,265 |  |  | $ | 3,236 |  |  | +$ | 29 |  |
| Free cash flow |  | $ | 2,214 |  |  | $ | 2,033 |  |  | +$ | 181 |  |

[0001193125-20-071608:8k_2_02:20]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 20 |  |  | Q1 19 |  |  | Change |  |
| Semiconductor solutions |  | $ | 4,191 |  |  |  | 72 | % |  | $ | 4,386 |  |  |  | 76 | % |  |  | -4 | % |
| Infrastructure software |  |  | 1,667 |  |  |  | 28 |  |  |  | 1,403 |  |  |  | 24 |  |  |  | +19 | % |
| Total net revenue |  | $ | 5,858 |  |  |  | 100 | % |  | $ | 5,789 |  |  |  | 100 | % |  |  |  |  |

[0001193125-20-071608:8k_2_02:21]
The Company’s cash and cash equivalents at the end of the first fiscal quarter were $6,444 million, compared to
$5,055 million at the end of the prior quarter.

[0001193125-20-071608:8k_2_02:22]
During the first fiscal quarter, the Company generated $2,322 million in cash from operations
and spent $108 million on capital expenditures.

[0001193125-20-071608:8k_2_02:23]
On December 31, 2019, the Company paid a cash dividend of $3.25 per share of common stock,
totaling $1,297 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001193125-20-071608:8k_2_02:24]
The differences
between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the
financial reconciliation tables attached to this release.

[0001193125-20-071608:8k_2_02:25]
Second Quarter Fiscal Year 2020 Business Outlook

[0001193125-20-071608:8k_2_02:26]
In light of the uncertainties in the global business environment arising from the effects of COVID-19, the Company is
withdrawing its prior annual guidance for fiscal year 2020, and providing guidance for its second fiscal quarter.

[0001193125-20-071608:8k_2_02:27]
Based on current business trends and
conditions, the outlook for the second quarter of fiscal year 2020, ending May 3, 2020, including contributions from the Symantec enterprise security business, is expected to be as follows:

[0001193125-20-071608:8k_2_02:28]
2

[0001193125-20-071608:8k_2_02:29]
|  | • |  | Second quarter revenue guidance of $5.7 billion plus or minus $150 million |

[0001193125-20-071608:8k_2_02:30]
|  | • |  | Second quarter Adjusted EBITDA of $3,135 million plus or minus $75 million, or 55% of revenue at the midpoint of guidance 1 |

[0001193125-20-071608:8k_2_02:31]
The guidance provided above is only an estimate of what the
Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance
and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-20-071608:8k_2_02:32]
Quarterly Dividends

[0001193125-20-071608:8k_2_02:33]
The Company’s Board of
Directors has approved a quarterly cash dividend on its common stock of $3.25 per share. The common stock dividend is payable on March 31, 2020 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 23,
2020.

[0001193125-20-071608:8k_2_02:34]
The Company’s Board of Directors also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of
$20.00 per share. This dividend is payable on March 31, 2020 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 15, 2020.

[0001193125-20-071608:8k_2_02:35]
Financial Results Conference Call

[0001193125-20-071608:8k_2_02:36]
Broadcom Inc. will
host a conference call to review its financial results for the first quarter of fiscal year 2020, ended February 2, 2020, and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 5272427. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 5272427. A webcast of the conference call will also be available in the “Investors” section of
Broadcom’s website at www.broadcom.com.

[0001193125-20-071608:8k_2_02:37]
Basis of Presentation

[0001193125-20-071608:8k_2_02:38]
The Company’s financial results include contributions from the Symantec enterprise security business’ continuing operations starting in the first
quarter of fiscal year 2020. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented above, unless otherwise stated.

[0001193125-20-071608:8k_2_02:39]
Non-GAAP Financial Measures

[0001193125-20-071608:8k_2_02:40]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash
flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense,
restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, debt-related costs, gains (losses) on investments, income (loss) from
discontinued operations and non-GAAP tax reconciling adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development
programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s
operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be
interpreted as implying that these items are non-recurring, infrequent or unusual. Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not
represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not
be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-20-071608:8k_2_02:41]
Broadcom believes this
non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a
more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. These
non-GAAP measures are provided in addition to, and not as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release.

[0001193125-20-071608:8k_2_02:42]
About
Broadcom Inc.

[0001193125-20-071608:8k_2_02:43]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs,
develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless,
storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more
information, go to www.broadcom.com.

[0001193125-20-071608:8k_2_02:44]
4

[0001193125-20-071608:8k_2_02:45]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-20-071608:8k_2_02:46]
Particular uncertainties that could
materially affect future results include risks associated with: our acquisition of Symantec Corporation’s Enterprise Security business (“Symantec Business”), including (1) potential difficulties in employee retention,
(2) unexpected costs, charges or expenses, and (3) our ability to successfully integrate the Symantec Business and achieve the anticipated benefits of the transaction; any loss of our significant customers and fluctuations in the timing
and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; international political and economic
conditions; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing
businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions, including our recent acquisition of the Symantec Business; government regulations and trade restrictions; our significant indebtedness
and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified
personnel; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality
in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract
manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their
ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with
operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code
sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types
of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; changes in accounting standards; fluctuations in foreign exchange rates; our
provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale,
including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of
the global business and economic environment as a result.

[0001193125-20-071608:8k_2_02:47]
5

[0001193125-20-071608:8k_2_02:48]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov,
discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the
estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-20-071608:8k_2_02:49]
Contact:

[0001193125-20-071608:8k_2_02:50]
Broadcom Inc.

[0001193125-20-071608:8k_2_02:51]
Beatrice F. Russotto

[0001193125-20-071608:8k_2_02:52]
Investor Relations

[0001193125-20-071608:8k_2_02:53]
408-433-8000

[0001193125-20-071608:8k_2_02:54]
investor.relations@broadcom.com

[0001193125-20-071608:8k_2_02:55]
6

[0001193125-20-071608:8k_2_02:56]
BROADCOM INC.

[0001193125-20-071608:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-20-071608:8k_2_02:58]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-20-071608:8k_2_02:59]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 2, |  |  | November 3, |  |  | February 3, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Net revenue |  | $ | 5,858 |  |  | $ | 5,776 |  |  | $ | 5,789 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,636 |  |  |  | 1,788 |  |  |  | 1,692 |  |
| Amortization of acquisition-related intangible assets |  |  | 950 |  |  |  | 827 |  |  |  | 833 |  |
| Restructuring charges |  |  | 8 |  |  |  | 9 |  |  |  | 56 |  |
| Total cost of revenue |  |  | 2,594 |  |  |  | 2,624 |  |  |  | 2,581 |  |
| Gross margin |  |  | 3,264 |  |  |  | 3,152 |  |  |  | 3,208 |  |
| Research and development |  |  | 1,289 |  |  |  | 1,177 |  |  |  | 1,133 |  |
| Selling, general and administrative |  |  | 601 |  |  |  | 409 |  |  |  | 471 |  |
| Amortization of acquisition-related intangible assets |  |  | 603 |  |  |  | 474 |  |  |  | 476 |  |
| Restructuring, impairment and disposal charges |  |  | 57 |  |  |  | 38 |  |  |  | 573 |  |
| Total operating expenses |  |  | 2,550 |  |  |  | 2,098 |  |  |  | 2,653 |  |
| Operating income |  |  | 714 |  |  |  | 1,054 |  |  |  | 555 |  |
| Interest expense |  |  | (406 | ) |  |  | (361 | ) |  |  | (345 | ) |
| Other income (expense), net |  |  | (4 | ) |  |  | 54 |  |  |  | 68 |  |
| Income from continuing operations before income taxes |  |  | 304 |  |  |  | 747 |  |  |  | 278 |  |
| Benefit from income taxes |  |  | (76 | ) |  |  | (100 | ) |  |  | (203 | ) |
| Income from continuing operations |  |  | 380 |  |  |  | 847 |  |  |  | 481 |  |
| Income (loss) from discontinued operations, net of income taxes |  |  | 5 |  |  |  | — |  |  |  | (10 | ) |
| Net income |  |  | 385 |  |  |  | 847 |  |  |  | 471 |  |
| Dividends on preferred stock (1) |  |  | 74 |  |  |  | 29 |  |  |  | — |  |
| Net income attributable to common stock |  | $ | 311 |  |  | $ | 818 |  |  | $ | 471 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.77 |  |  | $ | 2.06 |  |  | $ | 1.20 |  |
| Income (loss) per share from discontinued operations |  |  | 0.01 |  |  |  | — |  |  |  | (0.03 | ) |
| Net income per share |  | $ | 0.78 |  |  | $ | 2.06 |  |  | $ | 1.17 |  |
| Diluted income per share attributable to common stock (2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.73 |  |  | $ | 1.97 |  |  | $ | 1.15 |  |
| Income (loss) per share from discontinued operations |  |  | 0.01 |  |  |  | — |  |  |  | (0.03 | ) |
| Net income per share |  | $ | 0.74 |  |  | $ | 1.97 |  |  | $ | 1.12 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 398 |  |  |  | 397 |  |  |  | 401 |  |
| Diluted |  |  | 420 |  |  |  | 416 |  |  |  | 419 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 43 |  |  | $ | 41 |  |  | $ | 34 |  |
| Research and development |  |  | 391 |  |  |  | 394 |  |  |  | 311 |  |
| Selling, general and administrative |  |  | 111 |  |  |  | 109 |  |  |  | 120 |  |
| Total stock-based compensation expense |  | $ | 545 |  |  | $ | 544 |  |  | $ | 465 |  |

[0001193125-20-071608:8k_2_02:60]
| (1) | For the fiscal quarters ended February 2, 2020 and November 3, 2019, net income attributable to common stock excludes dividends on Mandatory Convertible Preferred Stock issued during the fiscal quarter ended November 3, 2019. |

[0001193125-20-071608:8k_2_02:61]
| (2) | For the fiscal quarters ended February 2, 2020 and November 3, 2019, diluted income per share excluded the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001193125-20-071608:8k_2_02:62]
7

[0001193125-20-071608:8k_2_02:63]
BROADCOM INC.

[0001193125-20-071608:8k_2_02:64]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-20-071608:8k_2_02:65]
(IN MILLIONS)

[0001193125-20-071608:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 2, |  |  | November 3, |  |  | February 3, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Gross margin on GAAP basis |  | $ | 3,264 |  |  | $ | 3,152 |  |  | $ | 3,208 |  |
| Purchase accounting effect on inventory |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Amortization of acquisition-related intangible assets |  |  | 950 |  |  |  | 827 |  |  |  | 833 |  |
| Stock-based compensation expense |  |  | 43 |  |  |  | 41 |  |  |  | 34 |  |
| Restructuring charges |  |  | 8 |  |  |  | 9 |  |  |  | 56 |  |
| Acquisition-related costs |  |  | 1 |  |  |  | 6 |  |  |  | 2 |  |
| Gross margin on non-GAAP basis |  | $ | 4,277 |  |  | $ | 4,035 |  |  | $ | 4,133 |  |
| Research and development on GAAP basis |  | $ | 1,289 |  |  | $ | 1,177 |  |  | $ | 1,133 |  |
| Stock-based compensation expense |  |  | 391 |  |  |  | 394 |  |  |  | 311 |  |
| Acquisition-related costs |  |  | 7 |  |  |  | 1 |  |  |  | 2 |  |
| Research and development on non-GAAP basis |  | $ | 891 |  |  | $ | 782 |  |  | $ | 820 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 601 |  |  | $ | 409 |  |  | $ | 471 |  |
| Stock-based compensation expense |  |  | 111 |  |  |  | 109 |  |  |  | 120 |  |
| Acquisition-related costs |  |  | 175 |  |  |  | 65 |  |  |  | 90 |  |
| Litigation settlements |  |  | 13 |  |  |  | — |  |  |  | — |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 302 |  |  | $ | 235 |  |  | $ | 261 |  |
| Total operating expenses on GAAP basis |  | $ | 2,550 |  |  | $ | 2,098 |  |  | $ | 2,653 |  |
| Amortization of acquisition-related intangible assets |  |  | 603 |  |  |  | 474 |  |  |  | 476 |  |
| Stock-based compensation expense |  |  | 502 |  |  |  | 503 |  |  |  | 431 |  |
| Restructuring, impairment and disposal charges |  |  | 57 |  |  |  | 38 |  |  |  | 573 |  |
| Litigation settlements |  |  | 13 |  |  |  | — |  |  |  | — |  |
| Acquisition-related costs |  |  | 182 |  |  |  | 66 |  |  |  | 92 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,193 |  |  | $ | 1,017 |  |  | $ | 1,081 |  |
| Operating income on GAAP basis |  | $ | 714 |  |  | $ | 1,054 |  |  | $ | 555 |  |
| Purchase accounting effect on inventory |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Amortization of acquisition-related intangible assets |  |  | 1,553 |  |  |  | 1,301 |  |  |  | 1,309 |  |
| Stock-based compensation expense |  |  | 545 |  |  |  | 544 |  |  |  | 465 |  |
| Restructuring, impairment and disposal charges |  |  | 65 |  |  |  | 47 |  |  |  | 629 |  |
| Litigation settlements |  |  | 13 |  |  |  | — |  |  |  | — |  |
| Acquisition-related costs |  |  | 183 |  |  |  | 72 |  |  |  | 94 |  |
| Operating income on non-GAAP basis |  | $ | 3,084 |  |  | $ | 3,018 |  |  | $ | 3,052 |  |
| Interest expense on GAAP basis |  | $ | (406 | ) |  | $ | (361 | ) |  | $ | (345 | ) |
| Debt-related costs |  |  | 5 |  |  |  | 26 |  |  |  | — |  |
| Interest expense on non-GAAP basis |  | $ | (401 | ) |  | $ | (335 | ) |  | $ | (345 | ) |
| Other income (expense), net on GAAP basis |  | $ | (4 | ) |  | $ | 54 |  |  | $ | 68 |  |
| (Gains) losses on investments |  |  | 18 |  |  |  | (50 | ) |  |  | (27 | ) |
| Acquisition-related - non-operating contract fair value adjustment amortization |  |  | (4 | ) |  |  | — |  |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 10 |  |  | $ | 4 |  |  | $ | 41 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 304 |  |  | $ | 747 |  |  | $ | 278 |  |
| Purchase accounting effect on inventory |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Amortization of acquisition-related intangible assets |  |  | 1,553 |  |  |  | 1,301 |  |  |  | 1,309 |  |
| Stock-based compensation expense |  |  | 545 |  |  |  | 544 |  |  |  | 465 |  |
| Restructuring, impairment and disposal charges |  |  | 65 |  |  |  | 47 |  |  |  | 629 |  |
| Litigation settlements |  |  | 13 |  |  |  | — |  |  |  | — |  |
| Acquisition-related costs, net |  |  | 179 |  |  |  | 72 |  |  |  | 94 |  |
| Debt-related costs |  |  | 5 |  |  |  | 26 |  |  |  | — |  |
| (Gains) losses on investments |  |  | 18 |  |  |  | (50 | ) |  |  | (27 | ) |
| Income before income taxes on non-GAAP basis |  | $ | 2,693 |  |  | $ | 2,687 |  |  | $ | 2,748 |  |
| Benefit from income taxes on GAAP basis |  | $ | (76 | ) |  | $ | (100 | ) |  | $ | (203 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 399 |  |  |  | 396 |  |  |  | 505 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 323 |  |  | $ | 296 |  |  | $ | 302 |  |
| Net income on GAAP basis |  | $ | 385 |  |  | $ | 847 |  |  | $ | 471 |  |
| Purchase accounting effect on inventory |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Amortization of acquisition-related intangible assets |  |  | 1,553 |  |  |  | 1,301 |  |  |  | 1,309 |  |
| Stock-based compensation expense |  |  | 545 |  |  |  | 544 |  |  |  | 465 |  |
| Restructuring, impairment and disposal charges |  |  | 65 |  |  |  | 47 |  |  |  | 629 |  |
| Litigation settlements |  |  | 13 |  |  |  | — |  |  |  | — |  |
| Acquisition-related costs, net |  |  | 179 |  |  |  | 72 |  |  |  | 94 |  |
| Debt-related costs |  |  | 5 |  |  |  | 26 |  |  |  | — |  |
| (Gains) losses on investments |  |  | 18 |  |  |  | (50 | ) |  |  | (27 | ) |
| Non-GAAP tax reconciling adjustments |  |  | (399 | ) |  |  | (396 | ) |  |  | (505 | ) |
| Discontinued operations, net of income taxes |  |  | (5 | ) |  |  | — |  |  |  | 10 |  |
| Net income on non-GAAP basis |  | $ | 2,370 |  |  | $ | 2,391 |  |  | $ | 2,446 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  |  | 420 |  |  |  | 416 |  |  |  | 419 |  |
| Non-GAAP adjustment (1) |  |  | 31 |  |  |  | 28 |  |  |  | 22 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  |  | 451 |  |  |  | 444 |  |  |  | 441 |  |
| Net income on non-GAAP basis |  | $ | 2,370 |  |  | $ | 2,391 |  |  | $ | 2,446 |  |
| Interest expense on non-GAAP basis |  |  | 401 |  |  |  | 335 |  |  |  | 345 |  |
| Provision for income taxes on non-GAAP basis |  |  | 323 |  |  |  | 296 |  |  |  | 302 |  |
| Depreciation |  |  | 146 |  |  |  | 143 |  |  |  | 143 |  |
| Amortization on non-GAAP basis |  |  | 25 |  |  |  | — |  |  |  | — |  |
| Adjusted EBITDA |  | $ | 3,265 |  |  | $ | 3,165 |  |  | $ | 3,236 |  |
| Net cash provided by operating activities |  | $ | 2,322 |  |  | $ | 2,479 |  |  | $ | 2,132 |  |
| Purchases of property, plant and equipment |  |  | (108 | ) |  |  | (96 | ) |  |  | (99 | ) |
| Free cash flow |  | $ | 2,214 |  |  | $ | 2,383 |  |  | $ | 2,033 |  |

[0001193125-20-071608:8k_2_02:67]
| (1) | Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarters ended February 2, 2020 and November 3, 2019, non-GAAP adjustment included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. |

[0001193125-20-071608:8k_2_02:68]
8

[0001193125-20-071608:8k_2_02:69]
BROADCOM INC.

[0001193125-20-071608:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-20-071608:8k_2_02:71]
(IN MILLIONS)

[0001193125-20-071608:8k_2_02:72]
|  |  | February 2,2020 |  |  | November 3,2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,444 |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  |  | 3,651 |  |  |  | 3,259 |  |
| Inventory |  |  | 944 |  |  |  | 874 |  |
| Other current assets |  |  | 1,070 |  |  |  | 729 |  |
| Total current assets |  |  | 12,109 |  |  |  | 9,917 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,616 |  |  |  | 2,565 |  |
| Goodwill |  |  | 43,472 |  |  |  | 36,714 |  |
| Intangible assets, net |  |  | 21,465 |  |  |  | 17,554 |  |
| Other long-term assets |  |  | 1,344 |  |  |  | 743 |  |
| Total assets |  | $ | 81,006 |  |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 985 |  |  | $ | 855 |  |
| Employee compensation and benefits |  |  | 435 |  |  |  | 641 |  |
| Current portion of long-term debt |  |  | 2,311 |  |  |  | 2,787 |  |
| Other current liabilities |  |  | 4,008 |  |  |  | 2,616 |  |
| Total current liabilities |  |  | 7,739 |  |  |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 42,407 |  |  |  | 30,011 |  |
| Other long-term liabilities |  |  | 6,464 |  |  |  | 5,613 |  |
| Total liabilities |  |  | 56,610 |  |  |  | 42,523 |  |
| Preferred stock dividend obligation |  |  | 28 |  |  |  | 29 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  |  | — |  |
| Common stock |  |  | — |  |  |  | — |  |
| Additional paid-in capital |  |  | 24,500 |  |  |  | 25,081 |  |
| Retained earnings |  |  | — |  |  |  | — |  |
| Accumulated other comprehensive loss |  |  | (132 | ) |  |  | (140 | ) |
| Total stockholders’ equity |  |  | 24,368 |  |  |  | 24,941 |  |
| Total liabilities and equity |  | $ | 81,006 |  |  | $ | 67,493 |  |

[0001193125-20-071608:8k_2_02:73]
9

[0001193125-20-071608:8k_2_02:74]
BROADCOM INC.

[0001193125-20-071608:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-20-071608:8k_2_02:76]
(IN MILLIONS)

[0001193125-20-071608:8k_2_02:77]
|  |  | Fiscal Quarter Ended |  |
|  |  | February 2, |  |  | November 3, |  |  | February 3, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 385 |  |  | $ | 847 |  |  | $ | 471 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  |  | 1,582 |  |  |  | 1,309 |  |  |  | 1,316 |  |
| Depreciation |  |  | 146 |  |  |  | 143 |  |  |  | 143 |  |
| Stock-based compensation |  |  | 545 |  |  |  | 544 |  |  |  | 465 |  |
| Deferred taxes and other non-cash taxes |  |  | (72 | ) |  |  | (226 | ) |  |  | (379 | ) |
| Non-cash restructuring, impairment and disposal charges |  |  | 11 |  |  |  | 20 |  |  |  | 92 |  |
| Non-cash interest expense |  |  | 35 |  |  |  | 40 |  |  |  | 13 |  |
| Other |  |  | 19 |  |  |  | (44 | ) |  |  | (21 | ) |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | (392 | ) |  |  | 285 |  |  |  | 68 |  |
| Inventory |  |  | 40 |  |  |  | 217 |  |  |  | 50 |  |
| Accounts payable |  |  | 117 |  |  |  | (147 | ) |  |  | (169 | ) |
| Employee compensation and benefits |  |  | (217 | ) |  |  | 66 |  |  |  | (458 | ) |
| Other current assets and current liabilities |  |  | 346 |  |  |  | (398 | ) |  |  | 506 |  |
| Other long-term assets and long-term liabilities |  |  | (223 | ) |  |  | (177 | ) |  |  | 35 |  |
| Net cash provided by operating activities |  |  | 2,322 |  |  |  | 2,479 |  |  |  | 2,132 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (10,870 | ) |  |  | — |  |  |  | (16,027 | ) |
| Proceeds from sale of business |  |  | — |  |  |  | — |  |  |  | 957 |  |
| Purchases of property, plant and equipment |  |  | (108 | ) |  |  | (96 | ) |  |  | (99 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Other |  |  | (9 | ) |  |  | 2 |  |  |  | (24 | ) |
| Net cash used in investing activities |  |  | (10,987 | ) |  |  | (88 | ) |  |  | (15,193 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | 15,381 |  |  |  | — |  |  |  | 17,896 |  |
| Repayment of debt |  |  | (4,537 | ) |  |  | (4,800 | ) |  |  | — |  |
| Other borrowings, net |  |  | 718 |  |  |  | (104 | ) |  |  | 531 |  |
| Payments of dividends |  |  | (1,372 | ) |  |  | (1,054 | ) |  |  | (1,067 | ) |
| Repurchases of common stock - repurchase program |  |  | — |  |  |  | (433 | ) |  |  | (3,436 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  |  | (169 | ) |  |  | (154 | ) |  |  | (77 | ) |
| Issuance of preferred stock, net |  |  | — |  |  |  | 3,679 |  |  |  | — |  |
| Issuance of common stock |  |  | 37 |  |  |  | 59 |  |  |  | 62 |  |
| Other |  |  | (4 | ) |  |  | 9 |  |  |  | (47 | ) |
| Net cash provided by (used in) financing activities |  |  | 10,054 |  |  |  | (2,798 | ) |  |  | 13,862 |  |
| Net change in cash and cash equivalents |  |  | 1,389 |  |  |  | (407 | ) |  |  | 801 |  |
| Cash and cash equivalents at the beginning of period |  |  | 5,055 |  |  |  | 5,462 |  |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 6,444 |  |  | $ | 5,055 |  |  | $ | 5,093 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 381 |  |  | $ | 307 |  |  | $ | 423 |  |
| Cash paid for income taxes |  | $ | 131 |  |  | $ | 123 |  |  | $ | 95 |  |

[0001193125-20-071608:8k_2_02:78]
10
