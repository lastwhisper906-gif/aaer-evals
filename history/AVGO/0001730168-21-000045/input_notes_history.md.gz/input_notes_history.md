# AVGO note change history — 0001730168-20-000164 → 0001730168-21-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-03-12):
[0001730168-21-000045:note_history:1]
The following table summarizes contractual obligations and commitments as of January 31, 2021 that materially changed from the end of fiscal year 2020:
  (was, 2020-09-11, similarity 0.9684):
[0001730168-20-000164:note_history:1]
The following table summarizes contractual obligations and commitments as of August 2, 2020 that materially changed from the end of fiscal year 2019:

- added (2021-03-12):
[0001730168-21-000045:note_history:2]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |  |  |
|  |  | (In millions) |  |  |
| 2021 (remainder) |  | $ | 1,439 |  |  | $ | 883 |  |  | $ | 173 |  |  |  |
| 2022 |  | 2,506 |  |  | 76 |  |  | 227 |  |  |  |
| 2023 |  | 1,977 |  |  | 19 |  |  | 216 |  |  |  |
| 2024 |  | 4,053 |  |  | — |  |  | 157 |  |  |  |
| 2025 |  | 4,655 |  |  | — |  |  | 63 |  |  |  |
| Thereafter |  | 42,259 |  |  | — |  |  | 239 |  |  |  |
| Total |  | $ | 56,889 |  |  | $ | 978 |  |  | $ | 1,075 |  |  |  |

- added (2021-03-12):
[0001730168-21-000045:note_history:3]
Debt Principal, Interest and Fees. Represents principal, interest and fees on our borrowings.

- changed (2021-03-12):
[0001730168-21-000045:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 31, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,210 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of January 31, 2021 have been excluded from the contractual obligations table above.
  (was, 2020-09-11, similarity 0.9736):
[0001730168-20-000164:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,307 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 2, 2020 have been excluded from the contractual obligations table above.

- changed (2021-03-12):
[0001730168-21-000045:note_history:5]
As of January 31, 2021 and November 1, 2020, we had standby letters of credit of $62 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.
  (was, 2020-09-11, similarity 0.9801):
[0001730168-20-000164:note_history:5]
As of August 2, 2020 and November 3, 2019, we had standby letters of credit of $63 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- added (2021-03-12):
[0001730168-21-000045:note_history:6]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- changed (2021-03-12):
[0001730168-21-000045:note_history:7]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit.
  (was, 2020-09-11, similarity 0.955):
[0001730168-20-000164:note_history:7]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgement interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgement, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgement interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

- changed (2021-03-12):
[0001730168-21-000045:note_history:8]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.
  (was, 2020-09-11, similarity 0.9607):
[0001730168-20-000164:note_history:8]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgement and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

- changed (2021-03-12):
[0001730168-21-000045:note_history:9]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory
  (was, 2020-09-11, similarity 0.7094):
[0001730168-20-000164:note_history:9]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

- added (2021-03-12):
[0001730168-21-000045:note_history:10]
investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

- changed (2021-03-12):
[0001730168-21-000045:note_history:11]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.
  (was, 2020-09-11, similarity 0.9996):
[0001730168-20-000164:note_history:11]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgement for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.

- removed (2021-03-12):
[0001730168-20-000164:note_history:12]
|  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt principal, interest and fees |  | $ | 54,772 |  |  | $ | 375 |  |  | $ | 2,327 |  |  | $ | 3,314 |  |  | $ | 7,440 |  |  | $ | 4,705 |  |  | $ | 36,611 |  |
| Purchase commitments |  | 1,034 |  |  | 820 |  |  | 163 |  |  | 51 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 1,098 |  |  | 122 |  |  | 196 |  |  | 183 |  |  | 172 |  |  | 126 |  |  | 299 |  |
| Total |  | $ | 56,904 |  |  | $ | 1,317 |  |  | $ | 2,686 |  |  | $ | 3,548 |  |  | $ | 7,612 |  |  | $ | 4,831 |  |  | $ | 36,910 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:13]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 2, 2020.

- removed (2021-03-12):
[0001730168-20-000164:note_history:14]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- removed (2021-03-12):
[0001730168-20-000164:note_history:15]
Lawsuits Relating to the Acquisition of Emulex Corporation

- removed (2021-03-12):
[0001730168-20-000164:note_history:16]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and

- removed (2021-03-12):
[0001730168-20-000164:note_history:17]
approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-03-12):
[0001730168-21-000045:note_history:18]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of mainframe and BizOps software solutions enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.
  (was, 2020-09-11, similarity 0.7331):
[0001730168-20-000164:note_history:18]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We also offer a cybersecurity solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries.

- added (2021-03-12):
[0001730168-21-000045:note_history:19]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ends on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

- changed (2021-03-12):
[0001730168-21-000045:note_history:20]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 31, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.
  (was, 2020-09-11, similarity 0.8764):
[0001730168-20-000164:note_history:20]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

- changed (2021-03-12):
[0001730168-21-000045:note_history:21]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.
  (was, 2020-09-11, similarity 0.9995):
[0001730168-20-000164:note_history:21]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgement and carry a higher degree of variability and volatility, and may change materially in future periods.

- changed (2021-03-12):
[0001730168-21-000045:note_history:22]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to the current period presentation. These reclassifications had no impact on previously reported net cash activities.
  (was, 2020-09-11, similarity 0.9921):
[0001730168-20-000164:note_history:22]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to current period presentation. These reclassifications had no impact on previously reported net cash activities.

- removed (2021-03-12):
[0001730168-20-000164:note_history:23]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing on the acquisition date.

- removed (2021-03-12):
[0001730168-20-000164:note_history:24]
During the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Prior period segment results have been recast to conform to the current presentation.

- removed (2021-03-12):
[0001730168-20-000164:note_history:25]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ended on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

- removed (2021-03-12):
[0001730168-20-000164:note_history:26]
Recent Accounting Guidance

- removed (2021-03-12):
[0001730168-20-000164:note_history:27]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for 
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. This guidance had no impact on our contracts as of August 2, 2020.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-03-12):
[0001730168-21-000045:note_history:28]
The future scheduled principal payments of debt as of January 31, 2021 were as follows:
  (was, 2020-09-11, similarity 0.9448):
[0001730168-20-000164:note_history:28]
The future scheduled principal payments of debt as of August 2, 2020 were as follows:

- changed (2021-03-12):
[0001730168-21-000045:note_history:29]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 274 |  |
| 2022 |  | 910 |  |
| 2023 |  | 404 |  |
| 2024 |  | 2,515 |  |
| 2025 |  | 3,250 |  |
| Thereafter |  | 35,073 |  |
| Total |  | $ | 42,426 |  |
  (was, 2020-09-11, similarity 0.9952):
[0001730168-20-000164:note_history:29]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 6,069 |  |
| 2024 |  | 3,403 |  |
| Thereafter |  | 32,392 |  |
| Total |  | $ | 44,498 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-03-12):
[0001730168-21-000045:note_history:30]
|  |  | Effective Interest Rate |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | $ | 750 |  |  | $ | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 112 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 274 |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 188 |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 569 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 261 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 144 |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 42,426 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (558) |  |  | (504) |  |
| Total debt |  |  |  | $ | 41,868 |  |  | $ | 40,994 |  |

- added (2021-03-12):
[0001730168-21-000045:note_history:31]
As of January 31, 2021 and November 1, 2020, short-term finance lease liabilities of $21 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $43 million and $48 million, respectively, were included in long-term debt.

- changed (2021-03-12):
[0001730168-21-000045:note_history:32]
January 2021 Senior Notes
  (was, 2020-09-11, similarity 0.85):
[0001730168-20-000164:note_history:32]
May 2020 Senior Notes

- changed (2021-03-12):
[0001730168-21-000045:note_history:33]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). The January 2021 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation and Broadcom Technologies Inc. At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of January 31, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.
  (was, 2020-09-11, similarity 0.7743):
[0001730168-20-000164:note_history:33]
On May 8, 2020, we issued $8 billion of senior unsecured notes, which consisted of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the May 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- added (2021-03-12):
[0001730168-21-000045:note_history:34]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain series of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

- added (2021-03-12):
[0001730168-21-000045:note_history:35]
Subsequent to the fiscal quarter ended January 31, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain series of our outstanding notes maturing between 2021 and 2023. In February 2021, we used the remaining proceeds from the January 2021 Senior Notes to repurchase $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022. On March 5, 2021, we repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.

- added (2021-03-12):
[0001730168-21-000045:note_history:36]
January 2021 Credit Agreement

- added (2021-03-12):
[0001730168-21-000045:note_history:37]
In January 2021, we entered into a credit agreement ( the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of January 31, 2021, we had no borrowings outstanding under the Revolving Facility.

- added (2021-03-12):
[0001730168-21-000045:note_history:38]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of January 31, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

- added (2021-03-12):
[0001730168-21-000045:note_history:39]
As of January 31, 2021, the estimated aggregate fair value of debt was $46,533 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2021-03-12):
[0001730168-21-000045:note_history:40]
The future scheduled principal payments of debt as of January 31, 2021 were as follows:
  (was, 2020-09-11, similarity 0.9448):
[0001730168-20-000164:note_history:40]
The future scheduled principal payments of debt as of August 2, 2020 were as follows:

- changed (2021-03-12):
[0001730168-21-000045:note_history:41]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 274 |  |
| 2022 |  | 910 |  |
| 2023 |  | 404 |  |
| 2024 |  | 2,515 |  |
| 2025 |  | 3,250 |  |
| Thereafter |  | 35,073 |  |
| Total |  | $ | 42,426 |  |
  (was, 2020-09-11, similarity 0.9952):
[0001730168-20-000164:note_history:41]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 6,069 |  |
| 2024 |  | 3,403 |  |
| Thereafter |  | 32,392 |  |
| Total |  | $ | 44,498 |  |

- changed (2021-03-12):
[0001730168-21-000045:note_history:42]
As of January 31, 2021 and November 1, 2020, we accrued interest payable of $308 million and $304 million, respectively, and were in compliance with all debt covenants.
  (was, 2020-09-11, similarity 0.9707):
[0001730168-20-000164:note_history:42]
As of August 2, 2020 and November 3, 2019, we accrued interest payable of $306 million and $214 million, respectively, and were in compliance with all debt covenants.

- removed (2021-03-12):
[0001730168-20-000164:note_history:43]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.56 | % |  | 4,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.58 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:44]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%-4.55% |  | 22 |  |  | 2.59%-4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 44,498 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  | (542) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 43,956 |  |  |  |  | $ | 32,798 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:45]
________________________________________________________________

- removed (2021-03-12):
[0001730168-20-000164:note_history:46]
(a) Represents the weighted average interest rate on outstanding commercial paper.

- removed (2021-03-12):
[0001730168-20-000164:note_history:47]
As of August 2, 2020, $15 million of short-term and $52 million of long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- removed (2021-03-12):
[0001730168-20-000164:note_history:48]
June 2020 Senior Notes

- removed (2021-03-12):
[0001730168-20-000164:note_history:49]
On June 4, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024, for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “June 2020 Senior Notes”). As a result of this exchange, we incurred premiums of $177 million. The June 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). We may, at our option, redeem or purchase, in whole or in part, any of the June 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the June 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the June 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- removed (2021-03-12):
[0001730168-20-000164:note_history:50]
The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, as defined below, were used to repay an aggregate of $5,424 million of term loans outstanding under the November 2019 Credit Agreement, as defined below, consisting of repayments of $2,712 million of each of our unsecured term A-3 and A-5 facilities, and $3 billion of borrowings outstanding under the Revolving Facility, as defined below.

- removed (2021-03-12):
[0001730168-20-000164:note_history:51]
April 2020 Senior Notes

- removed (2021-03-12):
[0001730168-20-000164:note_history:52]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus

- removed (2021-03-12):
[0001730168-20-000164:note_history:53]
accrued and unpaid interest. As of August 2, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- removed (2021-03-12):
[0001730168-20-000164:note_history:54]
Pursuant to a cash tender offer that we completed on April 23, 2020, we repurchased $2,361 million of our 3.000% notes due January 2022, $1,274 million of our 3.125% notes due April 2021 and $351 million of our 2.200% notes due January 2021 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense in the condensed consolidated statements of operations.

- removed (2021-03-12):
[0001730168-20-000164:note_history:55]
November 2019 Term Loans

- removed (2021-03-12):
[0001730168-20-000164:note_history:56]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “November 2019 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the November 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. During the fiscal quarter ended May 3, 2020, we repaid $194 million of each of our unsecured term A-3 and A-5 facilities.

- removed (2021-03-12):
[0001730168-20-000164:note_history:57]
During the fiscal quarter ended August 2, 2020, as discussed above, we used the net proceeds from the May 2020 Senior Notes and the remaining net proceeds from the April 2020 Senior Notes to repay a portion of our November 2019 Term Loans. Additionally, we made repayments with cash on hand. In total, we repaid an aggregate of $6,224 million of our November 2019 Term Loans, consisting of repayments of $2,737 million and $3,487 million of our unsecured term A-3 and A-5 facilities, respectively, and wrote off $44 million of unamortized discount and issuance costs. As a result of these repayments, all remaining principal payments are due more than one year after August 2, 2020 and were included in long-term debt.

- removed (2021-03-12):
[0001730168-20-000164:note_history:58]
May 2019 Term Loans

- removed (2021-03-12):
[0001730168-20-000164:note_history:59]
In January 2020, we repaid an aggregate of $1 billion of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities (collectively, the “May 2019 Term Loans”) under the credit agreement entered into in May 2019 (the “May 2019 Credit Agreement”). In July 2020, we repaid an aggregate of $600 million of the May 2019 Term Loans, representing the outstanding balance of the May 2019 Term Loans.

- removed (2021-03-12):
[0001730168-20-000164:note_history:60]
The May 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the May 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the May 2019 Credit Agreement in accordance with the terms thereof. On May 8, 2020, using net proceeds from the May 2020 Senior Notes and April 2020 Senior Notes, we repaid $3 billion of borrowings outstanding under the Revolving Facility. As of August 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

- removed (2021-03-12):
[0001730168-20-000164:note_history:61]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of August 2, 2020, we had no Commercial Paper outstanding. We had $1 billion of Commercial Paper outstanding as of November 3, 2019 with maturities generally less than three months. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we record Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- removed (2021-03-12):
[0001730168-20-000164:note_history:62]
Exchange Offer

- removed (2021-03-12):
[0001730168-20-000164:note_history:63]
In connection with the issuance of the June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes (collectively, the “2020 Senior Notes”) and $11 billion of senior unsecured notes in April 2019 (the “April 2019 Senior Notes”), we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the SEC, and cause to be declared effective, a registration statement with respect to an offer to exchange (the “Exchange Offer”) each series of the 2020 Senior Notes and April 2019 Senior Notes for notes that are registered with the SEC (the “Registered Notes”), with substantially identical terms. On July 6, 2020, we launched the Exchange Offer, which expired on August 7, 2020. Substantially all of our 2020 Senior Notes and April 2019 Senior Notes were tendered and exchanged for the corresponding Registered Notes in the Exchange Offer.

- removed (2021-03-12):
[0001730168-20-000164:note_history:64]
As of August 2, 2020, the estimated aggregate fair value of debt was $48,483 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-03-12):
[0001730168-21-000045:note_history:65]
|  |  | Effective Interest Rate |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | $ | 750 |  |  | $ | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 112 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 274 |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 188 |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 569 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 261 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 144 |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 42,426 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (558) |  |  | (504) |  |
| Total debt |  |  |  | $ | 41,868 |  |  | $ | 40,994 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:66]
Borrowings

- removed (2021-03-12):
[0001730168-20-000164:note_history:67]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.56 | % |  | 4,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.58 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:68]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%-4.55% |  | 22 |  |  | 2.59%-4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 44,498 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  | (542) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 43,956 |  |  |  |  | $ | 32,798 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:69]
________________________________________________________________

- removed (2021-03-12):
[0001730168-20-000164:note_history:70]
(a) Represents the weighted average interest rate on outstanding commercial paper.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-03-12):
[0001730168-21-000045:note_history:71]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |
  (was, 2020-09-11, similarity 0.9343):
[0001730168-20-000164:note_history:71]
|  |  | Fiscal Quarter Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

- added (2021-03-12):
[0001730168-21-000045:note_history:72]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:73]
|  |  | Fiscal Quarter Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:74]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:75]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-03-12):
[0001730168-21-000045:note_history:76]
Revenue from Contracts with Customers We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
Disaggregation
  (was, 2020-09-11, similarity 0.9861):
[0001730168-20-000164:note_history:76]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

- changed (2021-03-12):
[0001730168-21-000045:note_history:77]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |
  (was, 2020-09-11, similarity 0.9343):
[0001730168-20-000164:note_history:77]
|  |  | Fiscal Quarter Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

- added (2021-03-12):
[0001730168-21-000045:note_history:78]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- changed (2021-03-12):
[0001730168-21-000045:note_history:79]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.
  (was, 2020-09-11, similarity 0.9606):
[0001730168-20-000164:note_history:79]
Although we recognize revenue for the majority of our semiconductor products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.

- changed (2021-03-12):
[0001730168-21-000045:note_history:80]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of January 1, 2021 |  | $ | 160 |  |  | $ | 3,833 |  |
  (was, 2020-09-11, similarity 0.9477):
[0001730168-20-000164:note_history:80]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of August 2, 2020 (a) |  | $ | 158 |  |  | $ | 3,463 |  |

- changed (2021-03-12):
[0001730168-21-000045:note_history:81]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million.
  (was, 2020-09-11, similarity 0.9727):
[0001730168-20-000164:note_history:81]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.

- added (2021-03-12):
[0001730168-21-000045:note_history:82]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and

- changed (2021-03-12):
[0001730168-21-000045:note_history:83]
recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).
  (was, 2020-09-11, similarity 0.6404):
[0001730168-20-000164:note_history:83]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to

- added (2021-03-12):
[0001730168-21-000045:note_history:84]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of January 31, 2021 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- removed (2021-03-12):
[0001730168-20-000164:note_history:85]
Disaggregation

- removed (2021-03-12):
[0001730168-20-000164:note_history:86]
|  |  | Fiscal Quarter Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:87]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:88]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:89]
________________________________

- removed (2021-03-12):
[0001730168-20-000164:note_history:90]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of August 2, 2020.

- removed (2021-03-12):
[0001730168-20-000164:note_history:91]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |

- removed (2021-03-12):
[0001730168-20-000164:note_history:92]
________________________________

- removed (2021-03-12):
[0001730168-20-000164:note_history:93]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balances do not include contract assets or contract liabilities associated with CA.

- removed (2021-03-12):
[0001730168-20-000164:note_history:94]
not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- removed (2021-03-12):
[0001730168-20-000164:note_history:95]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 2, 2020 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-03-12):
[0001730168-20-000164:note_history:96]
Subsequent Events
Preferred Stock Cash Dividends Declared

- removed (2021-03-12):
[0001730168-20-000164:note_history:97]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2020 to stockholders of record on September 15, 2020.

- removed (2021-03-12):
[0001730168-20-000164:note_history:98]
Common Stock Cash Dividends Declared

- removed (2021-03-12):
[0001730168-20-000164:note_history:99]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on September 30, 2020 to stockholders of record on September 22, 2020.
