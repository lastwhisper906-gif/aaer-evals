# AVGO 8-K — 0001730168-21-000026 filed 2021-03-04

## item codes, every 8-K on or before 2021-03-12

- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2021-03-12

- none on or before 2021-03-12

## item 2.02 — earnings release, exhibit 99.1

[0001730168-21-000026:8k_2_02:1]
EX-99.1
2
avgo-01312021x8kxex99.htm
EX-99.1

[0001730168-21-000026:8k_2_02:2]
Document

[0001730168-21-000026:8k_2_02:3]
Exhibit 99.1

[0001730168-21-000026:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2021 Financial Results and Quarterly Dividends

[0001730168-21-000026:8k_2_02:5]
•Revenue of $6,655 million for the first quarter, up 14 percent from the prior year period

[0001730168-21-000026:8k_2_02:6]
•GAAP net income of $1,378 million for the first quarter; Adjusted EBITDA of $3,941 million for the first quarter

[0001730168-21-000026:8k_2_02:7]
•GAAP diluted EPS of $3.05 for the first quarter; Non-GAAP diluted EPS of $6.61 for the first quarter

[0001730168-21-000026:8k_2_02:8]
•$2,999 million of free cash flow from operations for the first quarter, defined as cash from operations of $3,113 million less capital expenditures of $114 million

[0001730168-21-000026:8k_2_02:9]
•Quarterly common stock dividend of $3.60 per share

[0001730168-21-000026:8k_2_02:10]
•Second quarter revenue guidance of approximately $6.5 billion, an expected increase of 13 percent from the prior year period

[0001730168-21-000026:8k_2_02:11]
•Second quarter Adjusted EBITDA guidance of approximately 59 percent of projected revenue 1

[0001730168-21-000026:8k_2_02:12]
SAN JOSE, Calif. – March 4, 2021 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2021, ended January 31, 2021, provided guidance for the second quarter of its fiscal year 2021 and announced its quarterly dividends.

[0001730168-21-000026:8k_2_02:13]
“We executed well during our first fiscal quarter driving 14% organic growth year on year,” said Hock Tan, President and CEO of Broadcom Inc. “This growth reflects the critical role our technology franchises play in this environment of accelerated digital transformation.”

[0001730168-21-000026:8k_2_02:14]
“This quarter highlights the strength of our financial model with 14% year over year revenue growth translating to an increase in operating profit of 23%,” said Kirsten Spears, CFO of Broadcom Inc. “We continue to deliver strong free cash flow, approximately $3 billion in the quarter, representing 35% growth on a year on year basis.”

[0001730168-21-000026:8k_2_02:15]
First Quarter Fiscal Year 2021 Financial Highlights

[0001730168-21-000026:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 21 |  | Q1 20 |  | Change |  | Q1 21 |  | Q1 20 |  | Change |
| Net revenue |  | $ | 6,655 |  |  | $ | 5,858 |  |  | +14 | % |  | $ | 6,655 |  |  | $ | 5,858 |  |  | +14 | % |
| Net income |  | $ | 1,378 |  |  | $ | 385 |  |  | +$993 |  |  | $ | 2,973 |  |  | $ | 2,370 |  |  | +$603 |  |
| Earnings per common share - diluted |  | $ | 3.05 |  |  | $ | 0.74 |  |  | +$2.31 |  |  | $ | 6.61 |  |  | $ | 5.25 |  |  | +$1.36 |  |

[0001730168-21-000026:8k_2_02:17]
________________________________

[0001730168-21-000026:8k_2_02:18]
1 The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-21-000026:8k_2_02:19]
1

[0001730168-21-000026:8k_2_02:20]
| (Dollars in millions) |  | Q1 21 |  | Q1 20 |  | Change |  |
| Cash flow from operations |  | $ | 3,113 |  |  | $ | 2,322 |  |  | +$791 |  |
| Adjusted EBITDA |  | $ | 3,941 |  |  | $ | 3,265 |  |  | +$676 |  |
| Free cash flow |  | $ | 2,999 |  |  | $ | 2,214 |  |  | +$785 |  |

[0001730168-21-000026:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 21 |  |  |  | Q1 20 |  | Change |  |
| Semiconductor solutions |  | $ | 4,908 |  |  | 74 | % |  |  |  |  |  |  | $ | 4,191 |  |  | 72 | % |  | +17 | % |  |
| Infrastructure software |  | 1,747 |  |  | 26 |  |  |  |  |  |  |  | 1,667 |  |  | 28 |  |  | +5 | % |  |
| Total net revenue |  | $ | 6,655 |  |  | 100 | % |  |  |  |  |  |  | $ | 5,858 |  |  | 100 | % |  |  |  |  |

[0001730168-21-000026:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the first fiscal quarter were $9,552 million, compared to $7,618 million at the end of the prior quarter.

[0001730168-21-000026:8k_2_02:23]
During the first fiscal quarter, the Company generated $3,113 million in cash from operations and spent $114 million on capital expenditures.

[0001730168-21-000026:8k_2_02:24]
On December 31, 2020, the Company paid a cash dividend of $3.60 per share of common stock, totaling $1,468 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-21-000026:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-21-000026:8k_2_02:26]
Second Quarter Fiscal Year 2021 Business Outlook

[0001730168-21-000026:8k_2_02:27]
Based on current business trends and conditions, the outlook for the second quarter of fiscal year 2021, ending May 2, 2021, is expected to be as follows:

[0001730168-21-000026:8k_2_02:28]
•Second quarter revenue guidance of approximately $6.5 billion; and

[0001730168-21-000026:8k_2_02:29]
•Second quarter Adjusted EBITDA guidance of approximately 59 percent of projected revenue

[0001730168-21-000026:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000026:8k_2_02:31]
Quarterly Dividends

[0001730168-21-000026:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.60 per share. The common stock dividend is payable on March 31, 2021 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 22, 2021.

[0001730168-21-000026:8k_2_02:33]
2

[0001730168-21-000026:8k_2_02:34]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on March 31, 2021 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 15, 2021.

[0001730168-21-000026:8k_2_02:35]
Financial Results Conference Call

[0001730168-21-000026:8k_2_02:36]
Broadcom Inc. will host a conference call to review its financial results for the first quarter fiscal year ended January 31, 2021, and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 9555701. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 9555701. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001730168-21-000026:8k_2_02:37]
Non-GAAP Financial Measures

[0001730168-21-000026:8k_2_02:38]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-21-000026:8k_2_02:39]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-21-000026:8k_2_02:40]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-21-000026:8k_2_02:41]
3

[0001730168-21-000026:8k_2_02:42]
About Broadcom Inc.

[0001730168-21-000026:8k_2_02:43]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to www.broadcom.com.

[0001730168-21-000026:8k_2_02:44]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-21-000026:8k_2_02:45]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has, and will likely continue to, negatively impact the global economy and disrupt normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; global political and economic conditions; government regulations, trade restrictions and trade tensions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses;

[0001730168-21-000026:8k_2_02:46]
4

[0001730168-21-000026:8k_2_02:47]
compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-21-000026:8k_2_02:48]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000026:8k_2_02:49]
Contact:

[0001730168-21-000026:8k_2_02:50]
Ji Yoo

[0001730168-21-000026:8k_2_02:51]
Broadcom Inc.

[0001730168-21-000026:8k_2_02:52]
Investor Relations

[0001730168-21-000026:8k_2_02:53]
408-433-8000

[0001730168-21-000026:8k_2_02:54]
investor.relations@broadcom.com

[0001730168-21-000026:8k_2_02:55]
5

[0001730168-21-000026:8k_2_02:56]
BROADCOM INC.

[0001730168-21-000026:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-21-000026:8k_2_02:58]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-21-000026:8k_2_02:59]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | November 1,2020 |  | February 2,2020 |  |  |  |  |
| Net revenue |  | $ | 6,655 |  |  | $ | 6,467 |  |  | $ | 5,858 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,814 |  |  | 1,753 |  |  | 1,636 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 874 |  |  | 962 |  |  | 950 |  |  |  |  |  |
| Restructuring charges |  | 15 |  |  | 5 |  |  | 8 |  |  |  |  |  |
| Total cost of revenue |  | 2,703 |  |  | 2,720 |  |  | 2,594 |  |  |  |  |  |
| Gross margin |  | 3,952 |  |  | 3,747 |  |  | 3,264 |  |  |  |  |  |
| Research and development |  | 1,211 |  |  | 1,182 |  |  | 1,289 |  |  |  |  |  |
| Selling, general and administrative |  | 339 |  |  | 405 |  |  | 601 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 599 |  |  | 603 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 71 |  |  | 35 |  |  | 57 |  |  |  |  |  |
| Total operating expenses |  | 2,115 |  |  | 2,221 |  |  | 2,550 |  |  |  |  |  |
| Operating income |  | 1,837 |  |  | 1,526 |  |  | 714 |  |  |  |  |  |
| Interest expense |  | (570) |  |  | (420) |  |  | (406) |  |  |  |  |  |
| Other income (expense), net |  | 117 |  |  | 31 |  |  | (4) |  |  |  |  |  |
| Income from continuing operations before income taxes |  | 1,384 |  |  | 1,137 |  |  | 304 |  |  |  |  |  |
| Provision for (benefit from) income taxes |  | 6 |  |  | (187) |  |  | (76) |  |  |  |  |  |
| Income from continuing operations |  | 1,378 |  |  | 1,324 |  |  | 380 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 5 |  |  |  |  |  |
| Net income |  | 1,378 |  |  | 1,324 |  |  | 385 |  |  |  |  |  |
| Dividends on preferred stock |  | (74) |  |  | (74) |  |  | (74) |  |  |  |  |  |
| Net income attributable to common stock |  | $ | 1,304 |  |  | $ | 1,250 |  |  | $ | 311 |  |  |  |  |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.20 |  |  | $ | 3.09 |  |  | $ | 0.77 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 3.20 |  |  | $ | 3.09 |  |  | $ | 0.78 |  |  |  |  |  |
| Diluted income per share attributable to common stock (1): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.05 |  |  | $ | 2.93 |  |  | $ | 0.73 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 3.05 |  |  | $ | 2.93 |  |  | $ | 0.74 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 407 |  |  | 405 |  |  | 398 |  |  |  |  |  |
| Diluted |  | 428 |  |  | 426 |  |  | 420 |  |  |  |  |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 32 |  |  | $ | 38 |  |  | $ | 43 |  |  |  |  |  |
| Research and development |  | 328 |  |  | 318 |  |  | 391 |  |  |  |  |  |
| Selling, general and administrative |  | 84 |  |  | 93 |  |  | 111 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 444 |  |  | $ | 449 |  |  | $ | 545 |  |  |  |  |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-21-000026:8k_2_02:60]
BROADCOM INC.

[0001730168-21-000026:8k_2_02:61]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-21-000026:8k_2_02:62]
(IN MILLIONS)

[0001730168-21-000026:8k_2_02:63]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | November 1,2020 |  | February 2,2020 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 3,952 |  |  | $ | 3,747 |  |  | $ | 3,264 |  |  |  |  |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 11 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 874 |  |  | 962 |  |  | 950 |  |  |  |  |  |
| Stock-based compensation expense |  | 32 |  |  | 38 |  |  | 43 |  |  |  |  |  |
| Restructuring charges |  | 15 |  |  | 5 |  |  | 8 |  |  |  |  |  |
| Acquisition-related costs |  | 3 |  |  | 6 |  |  | 1 |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 4,876 |  |  | $ | 4,758 |  |  | $ | 4,277 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 1,211 |  |  | $ | 1,182 |  |  | $ | 1,289 |  |  |  |  |  |
| Stock-based compensation expense |  | 328 |  |  | 318 |  |  | 391 |  |  |  |  |  |
| Acquisition-related costs |  | 1 |  |  | 1 |  |  | 7 |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 882 |  |  | $ | 863 |  |  | $ | 891 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 339 |  |  | $ | 405 |  |  | $ | 601 |  |  |  |  |  |
| Stock-based compensation expense |  | 84 |  |  | 93 |  |  | 111 |  |  |  |  |  |
| Acquisition-related costs |  | 41 |  |  | 60 |  |  | 175 |  |  |  |  |  |
| Litigation settlements |  | — |  |  | — |  |  | 13 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 214 |  |  | $ | 252 |  |  | $ | 302 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 2,115 |  |  | $ | 2,221 |  |  | $ | 2,550 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 599 |  |  | 603 |  |  |  |  |  |
| Stock-based compensation expense |  | 412 |  |  | 411 |  |  | 502 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 71 |  |  | 35 |  |  | 57 |  |  |  |  |  |
| Litigation settlements |  | — |  |  | — |  |  | 13 |  |  |  |  |  |
| Acquisition-related costs |  | 42 |  |  | 61 |  |  | 182 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,096 |  |  | $ | 1,115 |  |  | $ | 1,193 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 1,837 |  |  | $ | 1,526 |  |  | $ | 714 |  |  |  |  |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 11 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,368 |  |  | 1,561 |  |  | 1,553 |  |  |  |  |  |
| Stock-based compensation expense |  | 444 |  |  | 449 |  |  | 545 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 86 |  |  | 40 |  |  | 65 |  |  |  |  |  |
| Litigation settlements |  | — |  |  | — |  |  | 13 |  |  |  |  |  |
| Acquisition-related costs |  | 45 |  |  | 67 |  |  | 183 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 3,780 |  |  | $ | 3,643 |  |  | $ | 3,084 |  |  |  |  |  |
| Interest expense on GAAP basis |  | $ | (570) |  |  | $ | (420) |  |  | $ | (406) |  |  |  |  |  |
| Loss on debt extinguishment |  | 172 |  |  | 16 |  |  | 5 |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | $ | (398) |  |  | $ | (404) |  |  | $ | (401) |  |  |  |  |  |
| Other income (loss), net on GAAP basis |  | $ | 117 |  |  | $ | 31 |  |  | $ | (4) |  |  |  |  |  |
| (Gains) losses on investments |  | (119) |  |  | (10) |  |  | 18 |  |  |  |  |  |
| Acquisition-related gain |  | (2) |  |  | (4) |  |  | (4) |  |  |  |  |  |
| Other income (loss), net on non-GAAP basis |  | $ | (4) |  |  | $ | 17 |  |  | $ | 10 |  |  |  |  |  |

[0001730168-21-000026:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | November 1,2020 |  | February 2,2020 |  |  |  |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 6 |  |  | $ | (187) |  |  | $ | (76) |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | 399 |  |  | 578 |  |  | 399 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 405 |  |  | $ | 391 |  |  | $ | 323 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 1,378 |  |  | $ | 1,324 |  |  | $ | 385 |  |  |  |  |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 11 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,368 |  |  | 1,561 |  |  | 1,553 |  |  |  |  |  |
| Stock-based compensation expense |  | 444 |  |  | 449 |  |  | 545 |  |  |  |  |  |
| Restructuring, impairment and disposal charges |  | 86 |  |  | 40 |  |  | 65 |  |  |  |  |  |
| Litigation settlements |  | — |  |  | — |  |  | 13 |  |  |  |  |  |
| Acquisition-related costs |  | 43 |  |  | 63 |  |  | 179 |  |  |  |  |  |
| Loss on debt extinguishment |  | 172 |  |  | 16 |  |  | 5 |  |  |  |  |  |
| (Gains) losses on investments |  | (119) |  |  | (10) |  |  | 18 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (399) |  |  | (578) |  |  | (399) |  |  |  |  |  |
| Discontinued operations, net of income taxes |  | — |  |  | — |  |  | (5) |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 2,973 |  |  | $ | 2,865 |  |  | $ | 2,370 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 428 |  |  | 426 |  |  | 420 |  |  |  |  |  |
| Non-GAAP adjustment (1) |  | 22 |  |  | 25 |  |  | 31 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 450 |  |  | 451 |  |  | 451 |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 2,973 |  |  | $ | 2,865 |  |  | $ | 2,370 |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | 398 |  |  | 404 |  |  | 401 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 405 |  |  | 391 |  |  | 323 |  |  |  |  |  |
| Depreciation |  | 138 |  |  | 139 |  |  | 146 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 27 |  |  | 28 |  |  | 25 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 3,941 |  |  | $ | 3,827 |  |  | $ | 3,265 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 3,113 |  |  | $ | 3,348 |  |  | $ | 2,322 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (114) |  |  | (102) |  |  | (108) |  |  |  |  |  |
| Free cash flow |  | $ | 2,999 |  |  | $ | 3,246 |  |  | $ | 2,214 |  |  |  |  |  |

[0001730168-21-000026:8k_2_02:65]
|  |  | Fiscal Quarter Ending |
|  |  | May 2, |
| Expected average diluted share count: |  | 2021 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 430 |  |
| Non-GAAP adjustment (1) |  | 20 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 450 |  |

[0001730168-21-000026:8k_2_02:66]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. The non-GAAP adjustment also included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. For the fiscal quarter ending May 2, 2021, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |

[0001730168-21-000026:8k_2_02:67]
BROADCOM INC.

[0001730168-21-000026:8k_2_02:68]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-21-000026:8k_2_02:69]
(IN MILLIONS)

[0001730168-21-000026:8k_2_02:70]
|  |  | January 31,2021 |  | November 1,2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,552 |  |  | $ | 7,618 |  |
| Trade accounts receivable, net |  | 2,524 |  |  | 2,297 |  |
| Inventory |  | 952 |  |  | 1,003 |  |
| Other current assets |  | 1,272 |  |  | 977 |  |
| Total current assets |  | 14,300 |  |  | 11,895 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,496 |  |  | 2,509 |  |
| Goodwill |  | 43,457 |  |  | 43,447 |  |
| Intangible assets, net |  | 15,419 |  |  | 16,782 |  |
| Other long-term assets |  | 1,300 |  |  | 1,300 |  |
| Total assets |  | $ | 76,972 |  |  | $ | 75,933 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 898 |  |  | $ | 836 |  |
| Employee compensation and benefits |  | 494 |  |  | 877 |  |
| Current portion of long-term debt |  | 864 |  |  | 827 |  |
| Other current liabilities |  | 4,438 |  |  | 3,831 |  |
| Total current liabilities |  | 6,694 |  |  | 6,371 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 41,068 |  |  | 40,235 |  |
| Other long-term liabilities |  | 5,211 |  |  | 5,426 |  |
| Total liabilities |  | 52,973 |  |  | 52,032 |  |
| Preferred stock dividend obligation |  | 26 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 24,080 |  |  | 23,982 |  |
| Retained earnings |  | — |  |  | — |  |
| Accumulated other comprehensive loss |  | (107) |  |  | (108) |  |
| Total stockholders' equity |  | 23,973 |  |  | 23,874 |  |
| Total liabilities and equity |  | $ | 76,972 |  |  | $ | 75,933 |  |

[0001730168-21-000026:8k_2_02:71]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | November 1,2020 |  | February 2,2020 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,378 |  |  | $ | 1,324 |  |  | $ | 385 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,395 |  |  | 1,589 |  |  | 1,582 |  |  |  |  |  |
| Depreciation |  | 138 |  |  | 139 |  |  | 146 |  |  |  |  |  |
| Stock-based compensation |  | 444 |  |  | 449 |  |  | 545 |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | (149) |  |  | (459) |  |  | (72) |  |  |  |  |  |
| Loss on debt extinguishment |  | 172 |  |  | 16 |  |  | 5 |  |  |  |  |  |
| Unrealized gain on investments |  | (119) |  |  | — |  |  | — |  |  |  |  |  |
| Non-cash restructuring, impairment and disposal charges |  | 15 |  |  | 12 |  |  | 11 |  |  |  |  |  |
| Non-cash interest expense |  | 22 |  |  | 25 |  |  | 30 |  |  |  |  |  |
| Other |  | (5) |  |  | (9) |  |  | 19 |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (247) |  |  | 391 |  |  | (392) |  |  |  |  |  |
| Inventory |  | 51 |  |  | 67 |  |  | 40 |  |  |  |  |  |
| Accounts payable |  | 44 |  |  | (230) |  |  | 117 |  |  |  |  |  |
| Employee compensation and benefits |  | (375) |  |  | 142 |  |  | (217) |  |  |  |  |  |
| Other current assets and current liabilities |  | 408 |  |  | (131) |  |  | 346 |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | (59) |  |  | 23 |  |  | (223) |  |  |  |  |  |
| Net cash provided by operating activities |  | 3,113 |  |  | 3,348 |  |  | 2,322 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (8) |  |  | — |  |  | (10,870) |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (114) |  |  | (102) |  |  | (108) |  |  |  |  |  |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 2 |  |  | — |  |  |  |  |  |
| Other |  | — |  |  | — |  |  | (9) |  |  |  |  |  |
| Net cash used in investing activities |  | (122) |  |  | (100) |  |  | (10,987) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 9,904 |  |  | — |  |  | 15,381 |  |  |  |  |  |
| Repayment of debt |  | (9,200) |  |  | (3,000) |  |  | (4,537) |  |  |  |  |  |
| Other borrowings, net |  | — |  |  | — |  |  | 718 |  |  |  |  |  |
| Payment of dividends |  | (1,543) |  |  | (1,395) |  |  | (1,372) |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (225) |  |  | (185) |  |  | (169) |  |  |  |  |  |
| Issuance of common stock |  | 35 |  |  | 102 |  |  | 37 |  |  |  |  |  |
| Other |  | (28) |  |  | (9) |  |  | (4) |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  | (1,057) |  |  | (4,487) |  |  | 10,054 |  |  |  |  |  |
| Net change in cash and cash equivalents |  | 1,934 |  |  | (1,239) |  |  | 1,389 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 7,618 |  |  | 8,857 |  |  | 5,055 |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 9,552 |  |  | $ | 7,618 |  |  | $ | 6,444 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 372 |  |  | $ | 383 |  |  | $ | 381 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 147 |  |  | $ | 202 |  |  | $ | 131 |  |  |  |  |  |
