# AVGO notes — 0001730168-21-000045


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-21-000045:notes:1]
[same as prior period, unchanged from 0001730168-20-000164:notes:1]

[0001730168-21-000045:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of mainframe and BizOps software solutions enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-21-000045:notes:3]
[same as prior period, unchanged from 0001730168-20-000164:notes:5]

[0001730168-21-000045:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ends on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

[0001730168-21-000045:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 31, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.

[0001730168-21-000045:notes:6]
[same as prior period, unchanged from 0001730168-20-000164:notes:8]

[0001730168-21-000045:notes:7]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

[0001730168-21-000045:notes:8]
Reclassifications. Certain reclassifications have been made to the prior period condensed consolidated statement of cash flows to conform to the current period presentation. These reclassifications had no impact on previously reported net cash activities.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-21-000045:notes:9]
Revenue from Contracts with Customers We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
Disaggregation

[0001730168-21-000045:notes:10]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. “Segment Information”.

[0001730168-21-000045:notes:11]
[same as prior period, unchanged from 0001730168-20-000164:notes:16]

[0001730168-21-000045:notes:12]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |

[0001730168-21-000045:notes:13]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

[0001730168-21-000045:notes:14]
[same as prior period, unchanged from 0001730168-20-000164:notes:21]

[0001730168-21-000045:notes:15]
[same as prior period, unchanged from 0001730168-20-000164:notes:22]

[0001730168-21-000045:notes:16]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.

[0001730168-21-000045:notes:17]
[same as prior period, unchanged from 0001730168-20-000164:notes:24]

[0001730168-21-000045:notes:18]
[same as prior period, unchanged from 0001730168-20-000164:notes:25]

[0001730168-21-000045:notes:19]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of January 1, 2021 |  | $ | 160 |  |  | $ | 3,833 |  |

[0001730168-21-000045:notes:20]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million.

[0001730168-21-000045:notes:21]
[same as prior period, unchanged from 0001730168-20-000164:notes:31]

[0001730168-21-000045:notes:22]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and

[0001730168-21-000045:notes:23]
recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-21-000045:notes:24]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of January 31, 2021 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-21-000045:notes:25]
Acquisitions
Acquisition of the Symantec Corporation Enterprise Security Business

[0001730168-21-000045:notes:26]
On November 4, 2019, we completed the purchase of certain assets and assumed certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”), which was an established leader in cyber security, for $10.7 billion in cash (the “Symantec Asset Purchase”). We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base.

[0001730168-21-000045:notes:27]
[same as prior period, unchanged from 0001730168-20-000164:notes:50]

[0001730168-21-000045:notes:28]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if we had completed the Symantec Asset Purchase as of the beginning of our fiscal year ended November 3, 2019 (“fiscal year 2019”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-21-000045:notes:29]
|  |  |  |  | Fiscal Quarter Ended |  |  |
|  |  |  |  | February 2,2020 |  |  |  |  |
|  |  |  |  | (In millions) |
| Pro forma net revenue |  |  |  | $ | 5,639 |  |  |  |  |  |
| Pro forma net income attributable to common stock |  |  |  | $ | 229 |  |  |  |  |  |

[0001730168-21-000045:notes:30]
Other Acquisitions 
During the fiscal quarter ended February 2, 2020, we also completed three other acquisitions qualifying as business combinations for total consideration of $201 million, of which $109 million was allocated to goodwill and $46 million was allocated to intangible assets. We do not consider these acquisitions to be material, individually or in the aggregate, to our condensed consolidated statements of operations.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-21-000045:notes:31]
[same as prior period, unchanged from 0001730168-20-000164:notes:59]

[0001730168-21-000045:notes:32]
Cash equivalents included $2,728 million and $2,471 million of time deposits and $715 million and $790 million of money-market funds as of January 31, 2021 and November 1, 2020, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-21-000045:notes:33]
[same as prior period, unchanged from 0001730168-20-000164:notes:61]

[0001730168-21-000045:notes:34]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the

[0001730168-21-000045:notes:35]
factoring arrangements were $927 million and $901 million during the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-21-000045:notes:36]
[same as prior period, unchanged from 0001730168-20-000164:notes:63]

[0001730168-21-000045:notes:37]
|  |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Finished goods |  | $ | 306 |  |  | $ | 323 |  |
| Work-in-process |  | 552 |  |  | 558 |  |
| Raw materials |  | 94 |  |  | 122 |  |
| Total inventory |  | $ | 952 |  |  | $ | 1,003 |  |

[0001730168-21-000045:notes:38]
[same as prior period, unchanged from 0001730168-20-000164:notes:65]

[0001730168-21-000045:notes:39]
|  |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 513 |  |  | $ | 387 |  |
| Other (miscellaneous) |  | 759 |  |  | 590 |  |
| Total other current assets |  | $ | 1,272 |  |  | $ | 977 |  |

[0001730168-21-000045:notes:40]
[same as prior period, unchanged from 0001730168-20-000164:notes:67]

[0001730168-21-000045:notes:41]
|  |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,098 |  |  | $ | 2,620 |  |
| Tax liabilities |  | 562 |  |  | 440 |  |
| Other (miscellaneous) |  | 778 |  |  | 771 |  |
| Total other current liabilities |  | $ | 4,438 |  |  | $ | 3,831 |  |

[0001730168-21-000045:notes:42]
[same as prior period, unchanged from 0001730168-20-000164:notes:69]

[0001730168-21-000045:notes:43]
|  |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,210 |  |  | $ | 3,185 |  |
| Contract liabilities |  | 735 |  |  | 823 |  |
| Other (miscellaneous) |  | 1,266 |  |  | 1,418 |  |
| Total other long-term liabilities |  | $ | 5,211 |  |  | $ | 5,426 |  |

[0001730168-21-000045:notes:44]
[same as prior period, unchanged from 0001730168-20-000164:notes:73]

[0001730168-21-000045:notes:45]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | February 2,2020 |  |  |
|  |  | (In millions) |  |  |
| Cash paid for interest |  | $ | 372 |  |  | $ | 381 |  |  |  |
| Cash paid for income taxes |  | $ | 147 |  |  | $ | 131 |  |  |  |

[0001730168-21-000045:notes:46]
At each of January 31, 2021 and February 2, 2020, $46 million of unpaid purchases of property, plant and equipment were included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001730168-21-000045:notes:47]
Goodwill

[0001730168-21-000045:notes:48]
|  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | 43,447 |  |
| Acquisition |  | — |  |  | 10 |  |  | 10 |  |
| Balance as of January 31, 2021 |  | $ | 25,959 |  |  | $ | 17,498 |  |  | $ | 43,457 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-21-000045:notes:49]
Intangible Assets

[0001730168-21-000045:notes:50]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of January 31, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,126 |  |  | $ | (14,797) |  |  | $ | 9,329 |  |
| Customer contracts and related relationships |  | 8,392 |  |  | (3,525) |  |  | 4,867 |  |
| Order backlog |  | 2,579 |  |  | (1,965) |  |  | 614 |  |
| Trade names |  | 797 |  |  | (341) |  |  | 456 |  |
| Other |  | 252 |  |  | (124) |  |  | 128 |  |
| Intangible assets subject to amortization |  | 36,146 |  |  | (20,752) |  |  | 15,394 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,171 |  |  | $ | (20,752) |  |  | $ | 15,419 |  |
| As of November 1, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,119 |  |  | $ | (13,925) |  |  | $ | 10,194 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (3,179) |  |  | 5,210 |  |
| Order backlog |  | 2,579 |  |  | (1,836) |  |  | 743 |  |
| Trade names |  | 797 |  |  | (322) |  |  | 475 |  |
| Other |  | 252 |  |  | (117) |  |  | 135 |  |
| Intangible assets subject to amortization |  | 36,136 |  |  | (19,379) |  |  | 16,757 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,161 |  |  | $ | (19,379) |  |  | $ | 16,782 |  |

[0001730168-21-000045:notes:51]
Based on the amount of intangible assets subject to amortization at January 31, 2021, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-21-000045:notes:52]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 4,047 |  |
| 2022 |  | 4,367 |  |
| 2023 |  | 3,237 |  |
| 2024 |  | 2,367 |  |
| 2025 |  | 656 |  |
| Thereafter |  | 720 |  |
| Total |  | $ | 15,394 |  |

[0001730168-21-000045:notes:53]
[same as prior period, unchanged from 0001730168-20-000164:notes:95]

[0001730168-21-000045:notes:54]
| Amortizable intangible assets: |  | January 31,2021 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 4 |
| Order backlog |  | 2 |
| Trade names |  | 9 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-21-000045:notes:55]
[same as prior period, unchanged from 0001730168-20-000164:notes:97]

[0001730168-21-000045:notes:56]
Diluted shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”), in-the-money stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), (collectively referred to as “equity awards”), as well as Mandatory Convertible Preferred Stock, as defined in Note 8. “Stockholders’ Equity.” Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-21-000045:notes:57]
[same as prior period, unchanged from 0001730168-20-000164:notes:99]

[0001730168-21-000045:notes:58]
For each of the fiscal quarters ended January 31, 2021 and February 2, 2020, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-21-000045:notes:59]
[same as prior period, unchanged from 0001730168-20-000164:notes:101]

[0001730168-21-000045:notes:60]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | February 2,2020 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1,378 |  |  | $ | 380 |  |  |  |  |  |
| Dividends on preferred stock |  | (74) |  |  | (74) |  |  |  |  |  |
| Income from continuing operations attributable to common stock |  | 1,304 |  |  | 306 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes, attributable to common stock |  | — |  |  | 5 |  |  |  |  |  |
| Net income attributable to common stock |  | $ | 1,304 |  |  | $ | 311 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 407 |  |  | 398 |  |  |  |  |  |
| Dilutive effect of equity awards |  | 21 |  |  | 22 |  |  |  |  |  |
| Weighted-average shares outstanding - diluted |  | 428 |  |  | 420 |  |  |  |  |  |

[0001730168-21-000045:notes:61]
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.20 |  |  | $ | 0.77 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 3.20 |  |  | $ | 0.78 |  |  |  |  |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.05 |  |  | $ | 0.73 |  |  |  |  |  |
| Income per share from discontinued operations |  | — |  |  | 0.01 |  |  |  |  |  |
| Net income per share |  | $ | 3.05 |  |  | $ | 0.74 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-21-000045:notes:62]
Borrowings

[0001730168-21-000045:notes:63]
|  |  | Effective Interest Rate |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | $ | 750 |  |  | $ | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 112 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 274 |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 188 |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 569 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 261 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 144 |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 42,426 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (558) |  |  | (504) |  |
| Total debt |  |  |  | $ | 41,868 |  |  | $ | 40,994 |  |

[0001730168-21-000045:notes:64]
As of January 31, 2021 and November 1, 2020, short-term finance lease liabilities of $21 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $43 million and $48 million, respectively, were included in long-term debt.

[0001730168-21-000045:notes:65]
January 2021 Senior Notes

[0001730168-21-000045:notes:66]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). The January 2021 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation and Broadcom Technologies Inc. At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of January 31, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-21-000045:notes:67]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain series of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

[0001730168-21-000045:notes:68]
Subsequent to the fiscal quarter ended January 31, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain series of our outstanding notes maturing between 2021 and 2023. In February 2021, we used the remaining proceeds from the January 2021 Senior Notes to repurchase $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022. On March 5, 2021, we repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.

[0001730168-21-000045:notes:69]
January 2021 Credit Agreement

[0001730168-21-000045:notes:70]
In January 2021, we entered into a credit agreement ( the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of January 31, 2021, we had no borrowings outstanding under the Revolving Facility.

[0001730168-21-000045:notes:71]
Commercial Paper

[0001730168-21-000045:notes:72]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of January 31, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

[0001730168-21-000045:notes:73]
Fair Value of Debt

[0001730168-21-000045:notes:74]
As of January 31, 2021, the estimated aggregate fair value of debt was $46,533 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-21-000045:notes:75]
Future Principal Payments of Debt

[0001730168-21-000045:notes:76]
The future scheduled principal payments of debt as of January 31, 2021 were as follows:

[0001730168-21-000045:notes:77]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 274 |  |
| 2022 |  | 910 |  |
| 2023 |  | 404 |  |
| 2024 |  | 2,515 |  |
| 2025 |  | 3,250 |  |
| Thereafter |  | 35,073 |  |
| Total |  | $ | 42,426 |  |

[0001730168-21-000045:notes:78]
As of January 31, 2021 and November 1, 2020, we accrued interest payable of $308 million and $304 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-21-000045:notes:79]
[same as prior period, unchanged from 0001730168-20-000164:notes:135]

[0001730168-21-000045:notes:80]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”).

[0001730168-21-000045:notes:81]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of January 31, 2021, the minimum conversion rate was 3.0637 and the maximum conversion rate was 3.5811.

[0001730168-21-000045:notes:82]
We recognized $26 million and $27 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets as of January 31, 2021 and November 1, 2020, respectively.

[0001730168-21-000045:notes:83]
[same as prior period, unchanged from 0001730168-20-000164:notes:139]

[0001730168-21-000045:notes:84]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | February 2,2020 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.60 |  |  | $ | 3.25 |  |  |  |  |  |
| Dividends to common stockholders |  | $ | 1,468 |  |  | $ | 1,297 |  |  |  |  |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |  |  |  |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | 75 |  |  |  |  |  |

[0001730168-21-000045:notes:85]
[same as prior period, unchanged from 0001730168-20-000164:notes:141]

[0001730168-21-000045:notes:86]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | February 2,2020 |  |  |  |  |
|  |  | (In millions) |
| Cost of products sold |  | $ | 20 |  |  | $ | 31 |  |  |  |  |  |
| Cost of subscriptions and services |  | 12 |  |  | 12 |  |  |  |  |  |
| Research and development |  | 328 |  |  | 391 |  |  |  |  |  |
| Selling, general and administrative |  | 84 |  |  | 111 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 444 |  |  | $ | 545 |  |  |  |  |  |

[0001730168-21-000045:notes:87]
As of January 31, 2021, the total unrecognized compensation cost related to unvested stock-based awards was $3,637 million, which is expected to be recognized over the remaining weighted-average service period of 3.3 years.

[0001730168-21-000045:notes:88]
[same as prior period, unchanged from 0001730168-20-000164:notes:144]

[0001730168-21-000045:notes:89]
[same as prior period, unchanged from 0001730168-20-000164:notes:145]

[0001730168-21-000045:notes:90]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 1, 2020 |  | 32 |  |  | $ | 188.35 |  |  |  |  |  |
| Granted |  | — |  | * | $ | 372.28 |  |  |  |  |  |
| Vested |  | (2) |  |  | $ | 224.81 |  |  |  |  |  |
| Forfeited |  | — |  | * | $ | 194.09 |  |  |  |  |  |
| Balance as of January 31, 2021 |  | 30 |  |  | $ | 188.32 |  |  |  |  |  |

[0001730168-21-000045:notes:91]
* Represents fewer than 1 million shares.

[0001730168-21-000045:notes:92]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended January 31, 2021 was $664 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-21-000045:notes:93]
[same as prior period, unchanged from 0001730168-20-000164:notes:148]

[0001730168-21-000045:notes:94]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 1, 2020 |  | 1 |  |  | $ | 62.35 |  |  |  |  |  |
| Exercised |  | (1) |  |  | $ | 58.32 |  |  |  |  | $ | 211 |  |
| Balance as of January 31, 2021 |  | — |  | * | $ | 69.63 |  |  | 0.4 |  | $ | 126 |  |
| Fully vested as of January 31, 2021 |  | — |  | * | $ | 69.86 |  |  | 0.3 |  | $ | 124 |  |
| Fully vested and expected to vest as of January 31, 2021 |  | — |  | * | $ | 69.63 |  |  | 0.4 |  | $ | 126 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-21-000045:notes:95]
9. Income Taxes

[0001730168-21-000045:notes:96]
The provision for income taxes was $6 million and the benefit from income taxes was $76 million for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively.

[0001730168-21-000045:notes:97]
The provision for income taxes for the fiscal quarter ended January 31, 2021 was primarily due to higher profits from continuing operations, partially offset by excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements.

[0001730168-21-000045:notes:98]
The benefit from income taxes for the fiscal quarter ended February 2, 2020 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards.

[0001730168-21-000045:notes:99]
[same as prior period, unchanged from 0001730168-20-000164:notes:157]

[0001730168-21-000045:notes:100]
The balance of gross unrecognized tax benefits was $4,806 million and $4,748 million as of January 31, 2021 and November 1, 2020, respectively. This increase was primarily due to changes in uncertain tax positions from adjustments arising from audits conducted by tax authorities.

[0001730168-21-000045:notes:101]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of January 31, 2021 and November 1, 2020, the combined amount of cumulative accrued interest and penalties was approximately $341 million and $340 million, respectively.

[0001730168-21-000045:notes:102]
As of January 31, 2021 and November 1, 2020, approximately $5,147 million and $5,088 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $233 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-21-000045:notes:103]
[same as prior period, unchanged from 0001730168-20-000164:notes:162]

[0001730168-21-000045:notes:104]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment represents components for which separate financial information is available that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-21-000045:notes:105]
[same as prior period, unchanged from 0001730168-20-000164:notes:164]

[0001730168-21-000045:notes:106]
Infrastructure software. We provide a portfolio of software solutions that enables customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of mainframe and BizOps software solutions enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments. Our cyber security solutions portfolio includes endpoint, network, information and identity security solutions. We also offer mission critical FC SAN products and related software.

[0001730168-21-000045:notes:107]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, expenses associated with selling, general and administrative activities, facilities and information technology (“IT”) expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-21-000045:notes:108]
During the fourth quarter of fiscal year 2020, we refined our allocation methodology for certain selling, general and administrative expenses to more closely align these costs with the segment benefiting from the shared expenses. Prior period segment results have been recast to conform to the current presentation.

[0001730168-21-000045:notes:109]
[same as prior period, unchanged from 0001730168-20-000164:notes:167]

[0001730168-21-000045:notes:110]
[same as prior period, unchanged from 0001730168-20-000164:notes:168]

[0001730168-21-000045:notes:111]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue in either of the fiscal quarters ended January 31, 2021 or February 2, 2020. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-21-000045:notes:112]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | January 31,2021 |  | February 2,2020 |  |  |  |  |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,908 |  |  | $ | 4,191 |  |  |  |  |  |
| Infrastructure software |  | 1,747 |  |  | 1,667 |  |  |  |  |  |
| Total net revenue |  | $ | 6,655 |  |  | $ | 5,858 |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,561 |  |  | $ | 2,043 |  |  |  |  |  |
| Infrastructure software |  | 1,219 |  |  | 1,041 |  |  |  |  |  |
| Unallocated expenses |  | (1,943) |  |  | (2,370) |  |  |  |  |  |
| Total operating income |  | $ | 1,837 |  |  | $ | 714 |  |  |  |  |  |

[0001730168-21-000045:notes:113]
[same as prior period, unchanged from 0001730168-20-000164:notes:171]

[0001730168-21-000045:notes:114]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. No customer accounted for 10% or more of our net accounts receivable balance as of January 31, 2021 or November 1, 2020.
One customer accounted for 19% and 14% of our net revenue for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. Net revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-21-000045:notes:115]
Commitments and Contingencies
Commitments

[0001730168-21-000045:notes:116]
The following table summarizes contractual obligations and commitments as of January 31, 2021 that materially changed from the end of fiscal year 2020:

[0001730168-21-000045:notes:117]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |  |  |
|  |  | (In millions) |  |  |
| 2021 (remainder) |  | $ | 1,439 |  |  | $ | 883 |  |  | $ | 173 |  |  |  |
| 2022 |  | 2,506 |  |  | 76 |  |  | 227 |  |  |  |
| 2023 |  | 1,977 |  |  | 19 |  |  | 216 |  |  |  |
| 2024 |  | 4,053 |  |  | — |  |  | 157 |  |  |  |
| 2025 |  | 4,655 |  |  | — |  |  | 63 |  |  |  |
| Thereafter |  | 42,259 |  |  | — |  |  | 239 |  |  |  |
| Total |  | $ | 56,889 |  |  | $ | 978 |  |  | $ | 1,075 |  |  |  |

[0001730168-21-000045:notes:118]
Debt Principal, Interest and Fees. Represents principal, interest and fees on our borrowings.

[0001730168-21-000045:notes:119]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-21-000045:notes:120]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-21-000045:notes:121]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 31, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,210 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of January 31, 2021 have been excluded from the contractual obligations table above.

[0001730168-21-000045:notes:122]
Standby Letters of Credit

[0001730168-21-000045:notes:123]
As of January 31, 2021 and November 1, 2020, we had standby letters of credit of $62 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-21-000045:notes:124]
Contingencies

[0001730168-21-000045:notes:125]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-21-000045:notes:126]
Lawsuits Relating to California Institute of Technology

[0001730168-21-000045:notes:127]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit.

[0001730168-21-000045:notes:128]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

[0001730168-21-000045:notes:129]
Other Matters

[0001730168-21-000045:notes:130]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-21-000045:notes:131]
Contingency Assessment

[0001730168-21-000045:notes:132]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory

[0001730168-21-000045:notes:133]
investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-21-000045:notes:134]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-21-000045:notes:135]
Other Indemnifications

[0001730168-21-000045:notes:136]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-21-000045:notes:137]
[same as prior period, unchanged from 0001730168-20-000164:notes:197]

[0001730168-21-000045:notes:138]
•During the first quarter of fiscal year 2021, we initiated cost reduction activities associated with plans to align our workforce with strategic business activities and to improve efficiencies in our operations. As a result, we recognized $75 million of restructuring expense primarily related to employee termination costs during the fiscal quarter ended January 31, 2021.

[0001730168-21-000045:notes:139]
•During the first quarter of fiscal year 2020, we initiated cost reduction activities associated with the Symantec Asset Purchase. As a result, we recognized $33 million of restructuring expense primarily related to employee termination costs during the fiscal quarter ended February 2, 2020. These restructuring activities were substantially completed at the end of fiscal year 2020.

[0001730168-21-000045:notes:140]
•During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with our acquisition of CA,  Inc. As a result, we recognized $19 million of restructuring expense primarily related to employee termination and lease and other exit costs during the fiscal quarter ended February 2, 2020. These restructuring activities were substantially completed at the end of fiscal year 2020.

[0001730168-21-000045:notes:141]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the fiscal quarter ended January 31, 2021:

[0001730168-21-000045:notes:142]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs (a) |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |
| Restructuring charges |  | 61 |  |  | 14 |  |  | 75 |  |
| Utilization |  | (52) |  |  | (14) |  |  | (66) |  |
| Balance as of January 31, 2021 (b) |  | $ | 43 |  |  | $ | — |  |  | $ | 43 |  |

[0001730168-21-000045:notes:143]
[same as prior period, unchanged from 0001730168-20-000164:notes:202]

[0001730168-21-000045:notes:144]
(a)  As of January 31, 2021, $78 million of restructured lease liabilities were included in short-term and long-term lease liabilities.

[0001730168-21-000045:notes:145]
(b) We expect the majority of the employee termination costs balance to be paid within the next twelve months.
