# AVGO MD&A — 0001730168-21-000045


## mdna

[0001730168-21-000045:mdna:1]
[same as prior period, unchanged from 0001730168-20-000164:mdna:1]

[0001730168-21-000045:mdna:2]
[same as prior period, unchanged from 0001730168-20-000164:mdna:2]

[0001730168-21-000045:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of mainframe and BizOps software solutions enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-21-000045:mdna:4]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and IP licensing. Our infrastructure software segment includes our mainframe, BizOps and cyber security solutions, and our FC SAN business.

[0001730168-21-000045:mdna:5]
During the fourth quarter of our fiscal year 2020, we refined our allocation methodology for certain selling, general and administrative expenses to more closely align these costs with the segment benefiting from the shared expenses. Prior period segment results have been recast to conform to the current presentation.

[0001730168-21-000045:mdna:6]
[same as prior period, unchanged from 0001730168-20-000164:mdna:5]

[0001730168-21-000045:mdna:7]
Highlights during the fiscal quarter ended January 31, 2021 include the following:

[0001730168-21-000045:mdna:8]
•We generated $3,113 million of cash from operations.

[0001730168-21-000045:mdna:9]
•We paid $1,543 million in cash dividends.

[0001730168-21-000045:mdna:10]
[same as prior period, unchanged from 0001730168-20-000164:mdna:10]

[0001730168-21-000045:mdna:11]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in most of our employees working remotely for an extended period of time. While we have implemented a phased-in return of employees to many of our facilities, if the spread of COVID-19 worsens significantly, we may need to further limit onsite operations or otherwise modify our business practices. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-21-000045:mdna:12]
The demand environment for our semiconductor products was consistent with our expectations for the first quarter of our fiscal year ending October 31, 2021 (“fiscal year 2021”), with continued demand for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this area, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, we continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. As a result, supply lead times are still extended and we continue to have difficulties in obtaining some necessary components and inputs in a timely manner.

[0001730168-21-000045:mdna:13]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty. For example, we are largely building semiconductor products to order, instead of based on customer forecasts. In addition, we have continued to strengthen our balance sheet, including closely managing working capital and our debt instruments.

[0001730168-21-000045:mdna:14]
[same as prior period, unchanged from 0001730168-20-000164:mdna:16]

[0001730168-21-000045:mdna:15]
[same as prior period, unchanged from 0001730168-20-000164:mdna:22]

[0001730168-21-000045:mdna:16]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of long-lived assets, intangible assets and goodwill, inventory valuation, income taxes, retirement and post-retirement benefit plan assumptions, stock-based compensation expense, and employee bonus programs.

[0001730168-21-000045:mdna:17]
There were no significant changes in our critical accounting policies during the fiscal quarter ended January 31, 2021 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2020 Annual Report on Form 10-K.

[0001730168-21-000045:mdna:18]
24

[0001730168-21-000045:mdna:19]
[same as prior period, unchanged from 0001730168-20-000164:mdna:25]

[0001730168-21-000045:mdna:20]
Fiscal Quarter Ended January 31, 2021 Compared to Fiscal Quarter Ended February 2, 2020

[0001730168-21-000045:mdna:21]
The following table sets forth our results of operations for the periods presented:

[0001730168-21-000045:mdna:22]
|  |  | Fiscal Quarter Ended |
|  |  | January 31,2021 |  | February 2,2020 |  | January 31,2021 |  | February 2,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 5,081 |  |  | $ | 4,204 |  |  | 76 | % |  | 72 | % |
| Subscriptions and services |  | 1,574 |  |  | 1,654 |  |  | 24 |  |  | 28 |  |
| Total net revenue |  | 6,655 |  |  | 5,858 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,672 |  |  | 1,459 |  |  | 25 |  |  | 25 |  |
| Cost of subscriptions and services |  | 142 |  |  | 177 |  |  | 2 |  |  | 3 |  |
| Amortization of acquisition-related intangible assets |  | 874 |  |  | 950 |  |  | 13 |  |  | 16 |  |
| Restructuring charges |  | 15 |  |  | 8 |  |  | 1 |  |  | — |  |
| Total cost of revenue |  | 2,703 |  |  | 2,594 |  |  | 41 |  |  | 44 |  |
| Gross margin |  | 3,952 |  |  | 3,264 |  |  | 59 |  |  | 56 |  |
| Research and development |  | 1,211 |  |  | 1,289 |  |  | 18 |  |  | 22 |  |
| Selling, general and administrative |  | 339 |  |  | 601 |  |  | 5 |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 603 |  |  | 7 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 71 |  |  | 57 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 2,115 |  |  | 2,550 |  |  | 31 |  |  | 44 |  |
| Operating income |  | $ | 1,837 |  |  | $ | 714 |  |  | 28 | % |  | 12 | % |

[0001730168-21-000045:mdna:23]
[same as prior period, unchanged from 0001730168-20-000164:mdna:31]

[0001730168-21-000045:mdna:24]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 19% and 14% of our net revenue for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively.

[0001730168-21-000045:mdna:25]
We believe aggregate sales to our top five end customers, through all channels, accounted for more than 35% and 30% of our net revenue for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 25% and 20% of our net revenue for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-21-000045:mdna:26]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile handsets. The ongoing COVID-19 pandemic and related challenges and uncertainties may also cause our net revenue to fluctuate significantly and adversely affect our results of operations, as discussed above. Additionally, export restrictions on one of our larger customers have had, and may continue to have, an adverse impact on our revenue.

[0001730168-21-000045:mdna:27]
25

[0001730168-21-000045:mdna:28]
[same as prior period, unchanged from 0001730168-20-000164:mdna:35]

[0001730168-21-000045:mdna:29]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | January 31, 2021 |  | February 2, 2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,908 |  |  | $ | 4,191 |  |  | $ | 717 |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,747 |  |  | 1,667 |  |  | 80 |  |  | 5 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 6,655 |  |  | $ | 5,858 |  |  | $ | 797 |  |  | 14 | % |  |  |  |  |  |  |  |  |

[0001730168-21-000045:mdna:30]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | January 31,2021 |  | February 2,2020 |  |  |  |  |
|  |  | (As a percentage of net revenue) |  |  |  |  |
| Semiconductor solutions |  | 74 | % |  | 72 | % |  |  |  |  |
| Infrastructure software |  | 26 |  |  | 28 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-21-000045:mdna:31]
Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the quarter, compared to the prior year fiscal period. Net revenue from our semiconductor solutions segment also increased due to higher demand for our networking and broadband products, partially offset by lower demand for our server storage products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions, FC SAN products and enterprise security solutions.

[0001730168-21-000045:mdna:32]
[same as prior period, unchanged from 0001730168-20-000164:mdna:40]

[0001730168-21-000045:mdna:33]
Gross margin was $3,952 million, or 59% of net revenue, for the fiscal quarter ended January 31, 2021, compared to $3,264 million, or 56% of net revenue for the fiscal quarter ended February 2, 2020. The increase in gross margin was primarily due to lower amortization of acquisition-related intangible assets, as well as improvements in our cost structure within our infrastructure software segment compared to the prior year fiscal period.

[0001730168-21-000045:mdna:34]
[same as prior period, unchanged from 0001730168-20-000164:mdna:43]

[0001730168-21-000045:mdna:35]
Research and development expense decreased $78 million, or 6%, for the fiscal quarter ended January 31, 2021, compared to the prior year fiscal period. The decrease was primarily due to lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures.

[0001730168-21-000045:mdna:36]
[same as prior period, unchanged from 0001730168-20-000164:mdna:45]

[0001730168-21-000045:mdna:37]
Selling, general and administrative expense decreased $262 million, or 44%, for the fiscal quarter ended January 31, 2021, compared to the prior year fiscal period. The decrease was primarily due to higher acquisition-related costs incurred in the first quarter of fiscal year 2020 as a result of our acquisition of the Symantec Corporation Enterprise Security business (the “Symantec Business”). The decrease was also due to lower compensation expense reflecting the full benefit of the completed Symantec Business integration.

[0001730168-21-000045:mdna:38]
[same as prior period, unchanged from 0001730168-20-000164:mdna:48]

[0001730168-21-000045:mdna:39]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $109 million for the fiscal quarter ended January 31, 2021, compared to the prior year fiscal period. The decrease was primarily due to lower amortization of certain intangible assets acquired in our acquisition of CA, Inc.

[0001730168-21-000045:mdna:40]
[same as prior period, unchanged from 0001730168-20-000164:mdna:50]

[0001730168-21-000045:mdna:41]
Restructuring, impairment and disposal charges recognized in operating expenses increased $14 million for the fiscal quarter ended January 31, 2021, compared to the prior year fiscal period. The increase was primarily due to higher employee termination costs as we continue to improve efficiencies in our operations and align our workforce with our continuing investments in the business.

[0001730168-21-000045:mdna:42]
26

[0001730168-21-000045:mdna:43]
Stock-Based Compensation Expense

[0001730168-21-000045:mdna:44]
Total stock-based compensation expense was $444 million for the fiscal quarter ended January 31, 2021 compared to $545 million for the prior year fiscal period. The $101 million decrease primarily reflects the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-21-000045:mdna:45]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of January 31, 2021.

[0001730168-21-000045:mdna:46]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeiture |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 1,140 |  |
| 2022 |  | 1,150 |  |
| 2023 |  | 769 |  |
| 2024 |  | 402 |  |
| 2025 |  | 154 |  |
| Thereafter |  | 22 |  |
| Total |  | $ | 3,637 |  |

[0001730168-21-000045:mdna:47]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-21-000045:mdna:48]
[same as prior period, unchanged from 0001730168-20-000164:mdna:52]

[0001730168-21-000045:mdna:49]
|  |  | Fiscal Quarter Ended |  |  |
| Operating Income by Segment |  | January 31,2021 |  | February 2,2020 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 2,561 |  |  | $ | 2,043 |  |  | $ | 518 |  |  | 25 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 1,219 |  |  | 1,041 |  |  | 178 |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (1,943) |  |  | (2,370) |  |  | 427 |  |  | (18) | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 1,837 |  |  | $ | 714 |  |  | $ | 1,123 |  |  | 157 | % |  |  |  |  |  |  |  |  |

[0001730168-21-000045:mdna:50]
Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in the quarter, compared to the prior year fiscal period. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and broadband products, partially offset by lower demand for our server storage products. Operating income from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions, enterprise security solutions and FC SAN products, as well as improvements in our cost structure within our infrastructure software segment.

[0001730168-21-000045:mdna:51]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased primarily due to amortization of acquisition-related intangible assets, acquisition-related costs and stock-based compensation expense.

[0001730168-21-000045:mdna:52]
[same as prior period, unchanged from 0001730168-20-000164:mdna:57]

[0001730168-21-000045:mdna:53]
Interest expense. Interest expense was $570 million and $406 million for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. The increase was primarily due to losses on extinguishment of debt related to refinancing activities.

[0001730168-21-000045:mdna:54]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $117 million and other expense, net was $4 million for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. The increase was primarily due to higher gains on investments, partially offset by lower interest income.

[0001730168-21-000045:mdna:55]
Provision for (benefit from) income taxes. The provision for income taxes was $6 million and the benefit from income taxes was $76 million for the fiscal quarters ended January 31, 2021 and February 2, 2020, respectively. The provision for income taxes for the fiscal quarter ended January 31, 2021 was primarily due to higher profits from continuing operations, partially offset by excess tax benefits from stock-based awards, and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements. The benefit from income taxes for the fiscal quarter ended February 2, 2020 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards.

[0001730168-21-000045:mdna:56]
[same as prior period, unchanged from 0001730168-20-000164:mdna:62]

[0001730168-21-000045:mdna:57]
[same as prior period, unchanged from 0001730168-20-000164:mdna:63]

[0001730168-21-000045:mdna:58]
Our primary sources of liquidity as of January 31, 2021 consisted of: (i) $9,552 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-21-000045:mdna:59]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $42,426 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect our capital expenditures for fiscal year 2021 to be slightly higher than fiscal year 2020.

[0001730168-21-000045:mdna:60]
[same as prior period, unchanged from 0001730168-20-000164:mdna:67]

[0001730168-21-000045:mdna:61]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may also seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-21-000045:mdna:62]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0001730168-21-000045:mdna:63]
[same as prior period, unchanged from 0001730168-20-000164:mdna:69]

[0001730168-21-000045:mdna:64]
Working capital increased to $7,606 million at January 31, 2021 from $5,524 million at November 1, 2020. The increase was primarily attributable to the following:

[0001730168-21-000045:mdna:65]
•Cash and cash equivalents increased to $9,552 million at January 31, 2021 from $7,618 million at November 1, 2020, primarily due to $9,904 million in proceeds from long-term borrowings and $3,113 million in net cash provided by operating activities. These increases were partially offset by $9,200 million of debt repayments and $1,543 million of dividend payments.

[0001730168-21-000045:mdna:66]
•Employee compensation and benefits decreased to $494 million at January 31, 2021 from $877 million at November 1, 2020, primarily due to timing of employee bonus plan payments.

[0001730168-21-000045:mdna:67]
28

[0001730168-21-000045:mdna:68]
•Other current assets increased to $1,272 million at January 31, 2021 from $977 million at November 1, 2020, primarily due to increases in short-term investments and prepaid taxes.

[0001730168-21-000045:mdna:69]
•Accounts receivable increased to $2,524 million at January 31, 2021 from $2,297 million at November 1, 2020, primarily due to revenue linearity.

[0001730168-21-000045:mdna:70]
[same as prior period, unchanged from 0001730168-20-000164:mdna:75]

[0001730168-21-000045:mdna:71]
•Other current liabilities increased to $4,438 million at January 31, 2021 from $3,831 million at November 1, 2020, primarily due to increases in contract liabilities and taxes payable.

[0001730168-21-000045:mdna:72]
Working capital increased to $4,370 million at February 2, 2020 from $3,018 million at November 3, 2019. The increase was attributable to the following:

[0001730168-21-000045:mdna:73]
•Cash and cash equivalents increased to $6,444 million at February 2, 2020 from $5,055 million at November 3, 2019, primarily due to $16,099 million in proceeds from borrowings and $2,322 million in net cash provided by operating activities. These increases were partially offset by our $10.7 billion acquisition of the Symantec Business (the “Symantec Asset Purchase”), $4,537 million of debt repayments, and $1,372 million of dividend payments.

[0001730168-21-000045:mdna:74]
•Accounts receivable increased to $3,651 million at February 2, 2020 from $3,259 million at November 3, 2019, primarily due to revenue linearity, partially offset by $901 million of receivables sold through factoring arrangements.

[0001730168-21-000045:mdna:75]
•Other current assets increased to $1,070 million at February 2, 2020 from $729 million at November 3, 2019, primarily due to assets acquired in the Symantec Asset Purchase and increases in prepaid taxes.

[0001730168-21-000045:mdna:76]
•Employee compensation and benefits decreased to $435 million at February 2, 2020 from $641 million at November 3, 2019, primarily due to timing of employee bonus plan payments.

[0001730168-21-000045:mdna:77]
•Current portion of long-term debt decreased to $2,311 million at February 2, 2020 from $2,787 million at November 3, 2019 due to repayment of certain debt instruments, partially offset by certain debt instruments becoming due within the next twelve months.

[0001730168-21-000045:mdna:78]
These increases in working capital were offset in part by the following:

[0001730168-21-000045:mdna:79]
•Accounts payable increased to $985 million at February 2, 2020 from $855 million at November 3, 2019, primarily due to timing of vendor payments.

[0001730168-21-000045:mdna:80]
•Other current liabilities increased to $4,008 million at February 2, 2020 from $2,616 million at November 3, 2019, primarily due to the Symantec Asset Purchase, increases in contract liabilities, taxes payable, and lease liabilities resulting from the adoption of the new lease standard, partially offset by repayments of notional pooling liabilities.

[0001730168-21-000045:mdna:81]
[same as prior period, unchanged from 0001730168-20-000164:mdna:90]

[0001730168-21-000045:mdna:82]
|  |  | Fiscal Quarter Ended |
| Cash Dividends Declared and Paid |  | January 31,2021 |  | February 2,2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.60 |  |  | $ | 3.25 |  |
| Dividends to common stockholders |  | $ | 1,468 |  |  | $ | 1,297 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | 75 |  |

[0001730168-21-000045:mdna:83]
During the fiscal quarters ended January 31, 2021 and February 2, 2020, we paid approximately $225 million and $169 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 0.5 million shares of common stock from employees in connection with such net share settlements during each of the fiscal quarters ended January 31, 2021 and February 2, 2020.

[0001730168-21-000045:mdna:84]
[same as prior period, unchanged from 0001730168-20-000164:mdna:93]

[0001730168-21-000045:mdna:85]
|  |  | Fiscal Quarter Ended |
|  |  | January 31,2021 |  | February 2,2020 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 3,113 |  |  | $ | 2,322 |  |
| Net cash used in investing activities |  | (122) |  |  | (10,987) |  |
| Net cash provided by (used in) financing activities |  | (1,057) |  |  | 10,054 |  |
| Net change in cash and cash equivalents |  | $ | 1,934 |  |  | $ | 1,389 |  |

[0001730168-21-000045:mdna:86]
[same as prior period, unchanged from 0001730168-20-000164:mdna:95]

[0001730168-21-000045:mdna:87]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $791 million increase in cash provided by operations during the fiscal quarter ended January 31, 2021 compared to the prior year fiscal period was due to higher net income adjusted for non-cash items and changes in operating assets and liabilities.

[0001730168-21-000045:mdna:88]
[same as prior period, unchanged from 0001730168-20-000164:mdna:97]

[0001730168-21-000045:mdna:89]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures. The $10,865 million decrease in cash used in investing activities during the fiscal quarter ended January 31, 2021 compared to the prior year fiscal period was primarily related to a $10,862 million decrease in cash paid for acquisitions.

[0001730168-21-000045:mdna:90]
[same as prior period, unchanged from 0001730168-20-000164:mdna:99]

[0001730168-21-000045:mdna:91]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, dividend payments and employee withholding tax payments related to net settled equity awards. The $11,111 million decrease in cash related to financing activities during the fiscal quarter ended January 31, 2021 compared to the prior year fiscal period was primarily due to a $10,858 million decrease in net proceeds from borrowings and a $171 million increase in dividend payments.

[0001730168-21-000045:mdna:92]
[same as prior period, unchanged from 0001730168-20-000164:mdna:101]

[0001730168-21-000045:mdna:93]
See Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q for additional information related to our indebtedness.

[0001730168-21-000045:mdna:94]
[same as prior period, unchanged from 0001730168-20-000164:mdna:103]

[0001730168-21-000045:mdna:95]
Pursuant to the indentures dated May 21, 2020, May 8, 2020, April 9, 2020, and April 5, 2019 (collectively, the “2020 and 2019 Indentures”), Broadcom issued $3,917 million, $8,000 million, $4,500 million, and $11,000 million aggregate principal amount of notes, respectively (collectively, the “2020 and 2019 Senior Notes”). Substantially all of the 2020 and 2019 Senior Notes have been registered with the SEC in connection with an exchange offer that completed on August 10, 2020.

[0001730168-21-000045:mdna:96]
We may redeem all or a portion of our 2020 and 2019 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the indentures governing the respective notes. In the event of a change of control triggering event, holders of our 2020 and 2019 Senior Notes will have the right to require us to purchase for cash, all or a portion of their respective notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The indentures governing the 2020 and 2019 Senior Notes also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of the Obligor Group, as defined below, to merge, consolidate or sell all or substantially all of their assets.

[0001730168-21-000045:mdna:97]
Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”), both of which are 100%-owned subsidiaries of Broadcom (Broadcom, BRCM and BTI collectively, the “Obligor Group”), fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2020 and 2019 Senior Notes. The guarantee by BRCM and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the respective indentures. The guarantee by BRCM and BTI will also be automatically and unconditionally released if at any time the aggregate principal amount of indebtedness issued, borrowed or guaranteed by BRCM and BTI constitutes no more than 20% of the aggregate principal amount of indebtedness for borrowed money of Broadcom and its subsidiaries on a consolidated basis.

[0001730168-21-000045:mdna:98]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), Broadcom Cayman Finance Limited (subsequently merged into BTI during fiscal year 2019 with BTI remaining as the surviving entity) and BRCM (BRCM and BTI collectively, the “2017 Senior Notes Co-Issuers”) issued $13,550 million and $4,000 million aggregate

[0001730168-21-000045:mdna:99]
principal amount of notes, respectively (collectively, the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-21-000045:mdna:100]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the indentures governing the respective notes. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The indentures governing the 2017 Senior Notes also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of the Obligor Group to merge, consolidate or sell all or substantially all of their assets.

[0001730168-21-000045:mdna:101]
[same as prior period, unchanged from 0001730168-20-000164:mdna:109]

[0001730168-21-000045:mdna:102]
The following tables set forth the summarized financial information of the Obligor Group on a combined basis. This summarized financial information excludes any subsidiaries that are not issuers or guarantors (the “Non-Obligor Group”). Intercompany balances and transactions between members of the Obligor Group have been eliminated.

[0001730168-21-000045:mdna:103]
| Summarized Balance Sheets |  | January 31,2021 |  | November 1,2020 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 2,350 |  |  | $ | 1,889 |  |
| Other current assets |  | 4,907 |  |  | 4,091 |  |
| Total current assets |  | $ | 7,257 |  |  | $ | 5,980 |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 8,220 |  |  | $ | 8,220 |  |
| Goodwill |  | 1,360 |  |  | 1,360 |  |
| Other long-term assets |  | 1,304 |  |  | 1,318 |  |
| Total long-term assets |  | $ | 10,884 |  |  | $ | 10,898 |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 6,965 |  |  | $ | 7,147 |  |
| Current portion of long-term debt |  | 843 |  |  | 807 |  |
| Other current liabilities |  | 488 |  |  | 601 |  |
| Total current liabilities |  | $ | 8,296 |  |  | $ | 8,555 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | $ | 40,396 |  |  | $ | 39,311 |  |
| Other long-term liabilities |  | 2,468 |  |  | 2,477 |  |
| Total long-term liabilities |  | $ | 42,864 |  |  | $ | 41,788 |  |

[0001730168-21-000045:mdna:104]
31

[0001730168-21-000045:mdna:105]
|  |  | Fiscal Quarter Ended |
| Summarized Statement of Operations |  | January 31,2021 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 418 |  |
| Intercompany gross margin |  | $ | 379 |  |
| Net loss (a) |  | $ | (519) |  |

[0001730168-21-000045:mdna:106]
[same as prior period, unchanged from 0001730168-20-000164:mdna:115]

[0001730168-21-000045:mdna:107]
(a) In addition to intercompany gross margin, there were $188 million of intercompany transactions included in net loss.

[0001730168-21-000045:mdna:108]
[same as prior period, unchanged from 0001730168-20-000164:mdna:117]

[0001730168-21-000045:mdna:109]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000045:mdna:110]
[same as prior period, unchanged from 0001730168-20-000164:mdna:119]

[0001730168-21-000045:mdna:111]
We had no material off-balance sheet arrangements at January 31, 2021 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-21-000045:mdna:112]
[same as prior period, unchanged from 0001730168-20-000164:mdna:121]

[0001730168-21-000045:mdna:113]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000045:mdna:114]
[same as prior period, unchanged from 0001730168-20-000164:mdna:123]

[0001730168-21-000045:mdna:115]
[same as prior period, unchanged from 0001730168-20-000164:mdna:124]
