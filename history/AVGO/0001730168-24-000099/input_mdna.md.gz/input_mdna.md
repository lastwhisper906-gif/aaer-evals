# AVGO MD&A — 0001730168-24-000099


## mdna

[0001730168-24-000099:mdna:1]
[same as prior period, unchanged from 0001730168-24-000080:mdna:1]

[0001730168-24-000099:mdna:2]
[same as prior period, unchanged from 0001730168-24-000080:mdna:2]

[0001730168-24-000099:mdna:3]
[same as prior period, unchanged from 0001730168-24-000080:mdna:3]

[0001730168-24-000099:mdna:4]
[same as prior period, unchanged from 0001730168-24-000080:mdna:4]

[0001730168-24-000099:mdna:5]
Our fiscal year ending November 3, 2024 (“fiscal year 2024”), is a 53-week fiscal year, with our first fiscal quarter ended February 4, 2024 containing 14 weeks compared to 13 weeks in the prior year fiscal period. The additional week resulted in higher net revenue, gross margin dollars, research and development expense, and selling general and administrative expense in the first fiscal quarter and first three fiscal quarters of fiscal year 2024, compared to the corresponding prior year fiscal periods.

[0001730168-24-000099:mdna:6]
[same as prior period, unchanged from 0001730168-24-000080:mdna:6]

[0001730168-24-000099:mdna:7]
Highlights during the fiscal quarter ended August 4, 2024 include the following:

[0001730168-24-000099:mdna:8]
•We generated $4,963 million of cash from operations.

[0001730168-24-000099:mdna:9]
•We paid $2,452 million in cash dividends.

[0001730168-24-000099:mdna:10]
•We sold the end-user computing (“EUC”) business to KKR & Co. Inc. for $3.5 billion.

[0001730168-24-000099:mdna:11]
•We issued $5.0 billion of senior unsecured notes (the “July 2024 Senior Notes”) and used the net proceeds, as well as the net proceeds from the sale of the EUC business and cash on hand, to repay the outstanding balance of $9,195 million of our unsecured term A-2 facility.

[0001730168-24-000099:mdna:12]
•We completed a ten-for-one forward stock split of our common stock. All share, equity award and per share amounts have been retroactively adjusted to reflect the stock split.

[0001730168-24-000099:mdna:13]
Acquisitions and Divestitures

[0001730168-24-000099:mdna:14]
Acquisition of VMware and Divestiture of EUC

[0001730168-24-000099:mdna:15]
On November 22, 2023, we acquired VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million. In addition, we assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding RSU awards held by non-employee directors and in-the-money VMware stock options were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000099:mdna:16]
On July 1, 2024, we sold the EUC business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments.

[0001730168-24-000099:mdna:17]
[same as prior period, unchanged from 0001730168-24-000080:mdna:14]

[0001730168-24-000099:mdna:18]
[same as prior period, unchanged from 0001730168-24-000080:mdna:15]

[0001730168-24-000099:mdna:19]
[same as prior period, unchanged from 0001730168-24-000080:mdna:16]

[0001730168-24-000099:mdna:20]
[same as prior period, unchanged from 0001730168-24-000080:mdna:17]

[0001730168-24-000099:mdna:21]
There were no significant changes in our critical accounting estimates during the three fiscal quarters ended August 4, 2024 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2023 Annual Report on Form 10-K.

[0001730168-24-000099:mdna:22]
[same as prior period, unchanged from 0001730168-24-000080:mdna:19]

[0001730168-24-000099:mdna:23]
Fiscal Quarter and Three Fiscal Quarters Ended August 4, 2024 Compared to Fiscal Quarter and Three Fiscal Quarters Ended July 30, 2023

[0001730168-24-000099:mdna:24]
[same as prior period, unchanged from 0001730168-24-000080:mdna:21]

[0001730168-24-000099:mdna:25]
|  |  | Fiscal Quarter Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 7,439 |  |  | $ | 6,917 |  |  | 57 | % |  | 78 | % |
| Subscriptions and services |  | 5,633 |  |  | 1,959 |  |  | 43 |  |  | 22 |  |
| Total net revenue |  | 13,072 |  |  | 8,876 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,434 |  |  | 2,107 |  |  | 19 |  |  | 24 |  |
| Cost of subscriptions and services |  | 699 |  |  | 165 |  |  | 5 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,525 |  |  | 439 |  |  | 12 |  |  | 5 |  |
| Restructuring charges |  | 58 |  |  | 1 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 4,716 |  |  | 2,712 |  |  | 36 |  |  | 31 |  |
| Gross margin |  | 8,356 |  |  | 6,164 |  |  | 64 |  |  | 69 |  |
| Research and development |  | 2,353 |  |  | 1,358 |  |  | 18 |  |  | 16 |  |
| Selling, general and administrative |  | 1,100 |  |  | 388 |  |  | 9 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 812 |  |  | 350 |  |  | 6 |  |  | 4 |  |
| Restructuring and other charges |  | 303 |  |  | 212 |  |  | 2 |  |  | 2 |  |
| Total operating expenses |  | 4,568 |  |  | 2,308 |  |  | 35 |  |  | 26 |  |
| Operating income |  | $ | 3,788 |  |  | $ | 3,856 |  |  | 29 | % |  | 43 | % |

[0001730168-24-000099:mdna:26]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 22,043 |  |  | $ | 20,740 |  |  | 59 | % |  | 78 | % |
| Subscriptions and services |  | 15,477 |  |  | 5,784 |  |  | 41 |  |  | 22 |  |
| Total net revenue |  | 37,520 |  |  | 26,524 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 7,023 |  |  | 6,351 |  |  | 19 |  |  | 24 |  |
| Cost of subscriptions and services |  | 2,366 |  |  | 472 |  |  | 6 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 4,421 |  |  | 1,415 |  |  | 12 |  |  | 5 |  |
| Restructuring charges |  | 203 |  |  | 3 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 14,013 |  |  | 8,241 |  |  | 37 |  |  | 31 |  |
| Gross margin |  | 23,507 |  |  | 18,283 |  |  | 63 |  |  | 69 |  |
| Research and development |  | 7,076 |  |  | 3,865 |  |  | 19 |  |  | 15 |  |
| Selling, general and administrative |  | 3,949 |  |  | 1,174 |  |  | 11 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 2,431 |  |  | 1,046 |  |  | 6 |  |  | 4 |  |
| Restructuring and other charges |  | 1,215 |  |  | 231 |  |  | 3 |  |  | 1 |  |
| Total operating expenses |  | 14,671 |  |  | 6,316 |  |  | 39 |  |  | 24 |  |
| Operating income |  | $ | 8,836 |  |  | $ | 11,967 |  |  | 24 | % |  | 45 | % |

[0001730168-24-000099:mdna:27]
29

[0001730168-24-000099:mdna:28]
[same as prior period, unchanged from 0001730168-24-000080:mdna:25]

[0001730168-24-000099:mdna:29]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one customer, which is a distributor, accounted for 26% and 27% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and 21% and 20% of our net revenue for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively.

[0001730168-24-000099:mdna:30]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% and 40% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and approximately 35% for each of the fiscal quarter and three fiscal quarters ended July 30, 2023. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-24-000099:mdna:31]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our AI and wireless products as fluctuations may be magnified by the timing of customer deployments and product launches, and seasonal variations in sales. In addition, the macroeconomic environment remains uncertain and may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-24-000099:mdna:32]
[same as prior period, unchanged from 0001730168-24-000080:mdna:30]

[0001730168-24-000099:mdna:33]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | August 4, 2024 |  | July 30, 2023 |  | $ Change |  | % Change |  | August 4, 2024 |  | July 30, 2023 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 7,274 |  |  | $ | 6,941 |  |  | $ | 333 |  |  | 5 | % |  | $ | 21,866 |  |  | $ | 20,856 |  |  | $ | 1,010 |  |  | 5 | % |
| Infrastructure software |  | 5,798 |  |  | 1,935 |  |  | 3,863 |  |  | 200 | % |  | 15,654 |  |  | 5,668 |  |  | 9,986 |  |  | 176 | % |
| Total net revenue |  | $ | 13,072 |  |  | $ | 8,876 |  |  | $ | 4,196 |  |  | 47 | % |  | $ | 37,520 |  |  | $ | 26,524 |  |  | $ | 10,996 |  |  | 41 | % |

[0001730168-24-000099:mdna:34]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 56 | % |  | 78 | % |  | 58 | % |  | 79 | % |
| Infrastructure software |  | 44 |  |  | 22 |  |  | 42 |  |  | 21 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-24-000099:mdna:35]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and three fiscal quarters ended August 4, 2024 compared to the prior year fiscal periods due to strong product demand for our networking products, primarily AI networking products, partially offset by lower demand for our broadband and server storage products. Net revenue from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended August 4, 2024 compared to the prior year fiscal periods primarily due to contributions from VMware.

[0001730168-24-000099:mdna:36]
[same as prior period, unchanged from 0001730168-24-000080:mdna:34]

[0001730168-24-000099:mdna:37]
Gross margin was $8,356 million for the fiscal quarter ended August 4, 2024 compared to $6,164 million for the fiscal quarter ended July 30, 2023, and $23,507 million for the three fiscal quarters ended August 4, 2024 compared to $18,283 million for the three fiscal quarters ended July 30, 2023. The increases were primarily due to contributions from VMware, partially offset by higher amortization of acquisition-related intangible assets from the VMware Merger.

[0001730168-24-000099:mdna:38]
As a percentage of net revenue, gross margin was 64% and 63% of net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and 69% for each of the fiscal quarter and three fiscal quarters ended July 30, 2023. The decreases were primarily due to higher amortization of acquisition-related intangible assets from the VMware Merger. In addition, gross margin contributions from our infrastructure software segment were partially offset by less favorable margin within the semiconductor solutions segment driven by product mix.

[0001730168-24-000099:mdna:39]
[same as prior period, unchanged from 0001730168-24-000080:mdna:37]

[0001730168-24-000099:mdna:40]
Research and development expense increased $995 million, or 73%, and $3,211 million, or 83%, for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, compared to the prior year fiscal periods. The increases were

[0001730168-24-000099:mdna:41]
primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increases in stock-based compensation expense were also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000099:mdna:42]
[same as prior period, unchanged from 0001730168-24-000080:mdna:39]

[0001730168-24-000099:mdna:43]
Selling, general and administrative expense increased $712 million, or 184%, and $2,775 million, or 236%, for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increases in stock-based compensation expense were also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000099:mdna:44]
[same as prior period, unchanged from 0001730168-24-000080:mdna:41]

[0001730168-24-000099:mdna:45]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $462 million, or 132%, and $1,385 million, or 132%, for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, compared to the prior year fiscal periods primarily due to higher amortization of customer-related intangible assets from the VMware Merger.

[0001730168-24-000099:mdna:46]
[same as prior period, unchanged from 0001730168-24-000080:mdna:43]

[0001730168-24-000099:mdna:47]
Restructuring and other charges recognized in operating expenses were $303 million and $1,215 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, primarily due to employee termination costs associated with the VMware Merger. We expect to incur additional restructuring and other charges in future periods as a result of the VMware Merger. Restructuring and other charges recognized in operating expenses were $212 million and $231 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively, primarily due to non-recurring charges related to IP litigation.

[0001730168-24-000099:mdna:48]
[same as prior period, unchanged from 0001730168-24-000080:mdna:45]

[0001730168-24-000099:mdna:49]
Total stock-based compensation expense was $1,381 million and $4,356 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and $629 million and $1,533 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively. The increases were primarily due to equity awards assumed and granted in connection with the VMware Merger and annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000099:mdna:50]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of August 4, 2024. The remaining weighted-average service period was 3.2 years.

[0001730168-24-000099:mdna:51]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 1,335 |  |
| 2025 |  | 4,574 |  |
| 2026 |  | 3,709 |  |
| 2027 |  | 2,719 |  |
| 2028 |  | 563 |  |
| Total |  | $ | 12,900 |  |

[0001730168-24-000099:mdna:52]
[same as prior period, unchanged from 0001730168-24-000080:mdna:49]

[0001730168-24-000099:mdna:53]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | August 4,2024 |  | July 30,2023 |  | $ Change |  | % Change |  | August 4, 2024 |  | July 30, 2023 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,042 |  |  | $ | 4,092 |  |  | $ | (50) |  |  | (1) | % |  | $ | 12,136 |  |  | $ | 12,215 |  |  | $ | (79) |  |  | (1) | % |
| Infrastructure software |  | 3,906 |  |  | 1,444 |  |  | 2,462 |  |  | 170 | % |  | 9,789 |  |  | 4,163 |  |  | 5,626 |  |  | 135 | % |
| Unallocated expenses |  | (4,160) |  |  | (1,680) |  |  | (2,480) |  |  | 148 | % |  | (13,089) |  |  | (4,411) |  |  | (8,678) |  |  | 197 | % |
| Total operating income |  | $ | 3,788 |  |  | $ | 3,856 |  |  | $ | (68) |  |  | (2) | % |  | $ | 8,836 |  |  | $ | 11,967 |  |  | $ | (3,131) |  |  | (26) | % |

[0001730168-24-000099:mdna:54]
[same as prior period, unchanged from 0001730168-24-000080:mdna:29]

[0001730168-24-000099:mdna:55]
Operating income from our semiconductor solutions segment decreased for the fiscal quarter and three fiscal quarters ended August 4, 2024 compared to the prior year fiscal periods primarily due to higher variable compensation expenses and lower gross margins driven by product mix, partially offset by higher revenue from networking products, primarily AI networking products. Higher operating income from our infrastructure software segment in the fiscal quarter and three fiscal quarters ended August 4, 2024 compared to the prior year fiscal periods was primarily due to contributions from VMware.

[0001730168-24-000099:mdna:56]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 148% and 197% for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, compared to the prior year fiscal periods primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense and restructuring and other charges. These increases were primarily due to the VMware Merger. The increase in stock-based compensation expense was also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000099:mdna:57]
[same as prior period, unchanged from 0001730168-24-000080:mdna:53]

[0001730168-24-000099:mdna:58]
Interest expense. Interest expense was $1,064 million and $3,037 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and $406 million and $1,217 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively. The increases were primarily due to interest on debt incurred for the VMware Merger.

[0001730168-24-000099:mdna:59]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $82 million and $124 million for the fiscal quarters ended August 4, 2024 and July 30, 2023, respectively. The decrease was primarily due to lower interest income as a result of a lower invested balance. Other income, net, was $354 million and $380 million for the three fiscal quarters ended August 4, 2024 and July 30, 2023, respectively. The decrease was primarily due to lower gains on investments.

[0001730168-24-000099:mdna:60]
Provision for income taxes. The provision for income taxes was $4,238 million and $4,190 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and $271 million and $572 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively. The increases were primarily due to the impact of the intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income.

[0001730168-24-000099:mdna:61]
[same as prior period, unchanged from 0001730168-24-000080:mdna:57]

[0001730168-24-000099:mdna:62]
[same as prior period, unchanged from 0001730168-24-000080:mdna:58]

[0001730168-24-000099:mdna:63]
Our primary sources of liquidity as of August 4, 2024 consisted of: (i) $9,952 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-24-000099:mdna:64]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $72,319 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. Our debt and liquidity needs increased in fiscal year 2024 as a result of completing the VMware Merger. We funded the cash portion of the consideration with net proceeds from the issuance of $30,390 million in term loans (the “2023 Term Loans”), as well as cash on hand. We also assumed $8,250 million of VMware’s outstanding senior unsecured notes. During the fiscal quarter ended August 4, 2024, we repaid the remaining outstanding balance of the term A-2 facility. We also expect capital expenditures to be higher in fiscal year 2024 as compared to fiscal year 2023.

[0001730168-24-000099:mdna:65]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-24-000099:mdna:66]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new

[0001730168-24-000099:mdna:67]
debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, the 2023 Term Loans and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-24-000099:mdna:68]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. We may also make additional prepayments of the 2023 Term Loans. The amounts involved may be material.

[0001730168-24-000099:mdna:69]
[same as prior period, unchanged from 0001730168-24-000080:mdna:65]

[0001730168-24-000099:mdna:70]
On November 22, 2023, we completed the VMware Merger. The following table presents the changes in selected balance sheet captions other than assets acquired and liabilities assumed from the VMware Merger during the three fiscal quarters ended August 4, 2024.

[0001730168-24-000099:mdna:71]
|  |  | Balances at October 29, 2023 |  | Balances Acquired and Assumed from VMware |  | Balances at August 4, 2024 |  | Non-VMware Acquisition Increase (Decrease) |
|  |  | (In millions) |
| Cash and cash equivalents |  | $ | 14,189 |  |  | $ | 6,642 |  |  | $ | 9,952 |  |  | $ | (10,879) |  |
| Trade accounts receivable, net |  | $ | 3,154 |  |  | $ | 3,571 |  |  | $ | 4,665 |  |  | $ | (2,060) |  |
| Other current assets |  | $ | 1,606 |  |  | $ | 5,963 |  |  | $ | 3,436 |  |  | $ | (4,133) |  |
| Accounts payable |  | $ | 1,210 |  |  | $ | 359 |  |  | $ | 1,757 |  |  | $ | 188 |  |
| Employee compensation and benefits |  | $ | 935 |  |  | $ | 848 |  |  | $ | 1,725 |  |  | $ | (58) |  |
| Current portion of long-term debt |  | $ | 1,608 |  |  | $ | 1,264 |  |  | $ | 3,161 |  |  | $ | 289 |  |
| Other current liabilities |  | $ | 3,652 |  |  | $ | 12,942 |  |  | $ | 12,578 |  |  | $ | (4,016) |  |

[0001730168-24-000099:mdna:72]
•Cash and cash equivalents decreased primarily due to $32,058 million paid for the VMware Merger, $7,330 million of dividend payments, $7,176 million of common stock repurchases and $4,012 million of employee withholding tax payments related to net settled equity awards, offset in part by $22,849 million in net proceeds from borrowings, $14,358 million in net cash provided by operating activities, and $3,485 million proceeds from the sale of the EUC business.

[0001730168-24-000099:mdna:73]
•Trade accounts receivable, net decreased primarily due to strong collections and additional receivables sold through factoring arrangements.

[0001730168-24-000099:mdna:74]
•Other current assets decreased primarily due to the sale of the EUC business, offset in part by an increase in contract assets.

[0001730168-24-000099:mdna:75]
•Accounts payable increased primarily due to the timing of payments and an increase in purchases.

[0001730168-24-000099:mdna:76]
•Current portion of long-term debt increased due to $1,245 million becoming due within the next twelve months, offset in part by $941 million of repayments.

[0001730168-24-000099:mdna:77]
•Other current liabilities decreased due to the sale of the EUC business as well as a decrease in contract liabilities as software revenue was recognized.

[0001730168-24-000099:mdna:78]
[same as prior period, unchanged from 0001730168-24-000080:mdna:75]

[0001730168-24-000099:mdna:79]
|  |  | Three Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 1.575 |  |  | $ | 1.380 |  |
| Dividends to common stockholders |  | $ | 7,330 |  |  | $ | 5,741 |  |

[0001730168-24-000099:mdna:80]
During the three fiscal quarters ended August 4, 2024 and July 30, 2023, we repurchased and retired approximately 67 million and 90 million shares of our common stock for $7,176 million and $5,701 million, respectively. All $20 billion under our previously authorized stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000099:mdna:81]
During the three fiscal quarters ended August 4, 2024 and July 30, 2023, we paid approximately $4,012 million and $1,407 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 30 million and 21 million shares of common stock from employees in connection with such net share settlements during the three fiscal quarters ended August 4, 2024 and July 30, 2023, respectively.

[0001730168-24-000099:mdna:82]
[same as prior period, unchanged from 0001730168-24-000080:mdna:79]

[0001730168-24-000099:mdna:83]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 14,358 |  |  | $ | 13,257 |  |
| Net cash used in investing activities |  | (22,938) |  |  | (565) |  |
| Net cash provided by (used in) financing activities |  | 4,343 |  |  | (13,053) |  |
| Net change in cash and cash equivalents |  | $ | (4,237) |  |  | $ | (361) |  |

[0001730168-24-000099:mdna:84]
[same as prior period, unchanged from 0001730168-24-000080:mdna:81]

[0001730168-24-000099:mdna:85]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,101 million increase in cash provided by operations during the three fiscal quarters ended August 4, 2024 compared to the prior year fiscal period was primarily due to contributions from VMware. The $8,987 million decrease in net income was largely driven by $11,990 million of higher non-cash adjustments including amortization of intangible assets, deferred taxes and other non-cash taxes, and stock-based compensation related to the VMware Merger.

[0001730168-24-000099:mdna:86]
[same as prior period, unchanged from 0001730168-24-000080:mdna:83]

[0001730168-24-000099:mdna:87]
Cash flows from investing activities primarily consisted of cash used for acquisitions, proceeds from the sale of a business, capital expenditures and proceeds and payments related to investments. The $22,373 million increase in cash used in investing activities during the three fiscal quarters ended August 4, 2024 compared to the prior year fiscal period was primarily due to a $25,961 million increase in cash used for acquisitions due to the VMware Merger and the acquisition of Seagate’s SoC operations, net of cash acquired, offset in part by $3,485 million proceeds from the sale of the EUC business.

[0001730168-24-000099:mdna:88]
[same as prior period, unchanged from 0001730168-24-000080:mdna:85]

[0001730168-24-000099:mdna:89]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, dividend payments, stock repurchases and employee withholding tax payments related to net settled equity awards. The $17,396 million increase in cash flows from financing activities during the three fiscal quarters ended August 4, 2024 compared to the prior year fiscal period was primarily due to $34,985 million of net proceeds from the 2023 Term Loans and the July 2024 Senior Notes, partially offset by an $11,876 million increase in payments of debt obligations, a $2,605 million increase in employee withholding tax payments related to net settled equity awards, a $1,589 million increase in dividend payments, and a $1,475 million increase in stock repurchases.
