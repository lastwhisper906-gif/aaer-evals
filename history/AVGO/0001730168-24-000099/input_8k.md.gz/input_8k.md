# AVGO 8-K — 0001730168-24-000095 filed 2024-09-05

## item codes, every 8-K on or before 2024-09-11

- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2024-09-11

- none on or before 2024-09-11

## item 2.02 — earnings release, exhibit 99.1

[0001730168-24-000095:8k_2_02:1]
EX-99.1
2
avgo-08042024x8kxex99.htm
EX-99.1

[0001730168-24-000095:8k_2_02:2]
Document

[0001730168-24-000095:8k_2_02:3]
Exhibit 99.1

[0001730168-24-000095:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2024 Financial Results and Quarterly Dividend

[0001730168-24-000095:8k_2_02:5]
•Revenue of $13,072 million for the third quarter, up 47 percent from the prior year period

[0001730168-24-000095:8k_2_02:6]
•GAAP net loss of $1,875 million for the third quarter (1); Non-GAAP net income of $6,120 million for the third quarter

[0001730168-24-000095:8k_2_02:7]
•Adjusted EBITDA of $8,223 million for the third quarter, or 63 percent of revenue

[0001730168-24-000095:8k_2_02:8]
•GAAP diluted loss per share of $0.40 for the third quarter; Non-GAAP diluted EPS of $1.24 for the third quarter

[0001730168-24-000095:8k_2_02:9]
•Cash from operations of $4,963 million for the third quarter, less capital expenditures of $172 million, resulted in $4,791 million of free cash flow, or 37 percent of revenue

[0001730168-24-000095:8k_2_02:10]
•Quarterly common stock dividend of $0.53 per share

[0001730168-24-000095:8k_2_02:11]
•Fourth quarter fiscal year 2024 revenue guidance of approximately $14.0 billion including contribution from VMware, an increase of 51 percent from the prior year period

[0001730168-24-000095:8k_2_02:12]
•Fourth quarter fiscal year 2024 Adjusted EBITDA guidance of approximately 64 percent of projected revenue (2)

[0001730168-24-000095:8k_2_02:13]
PALO ALTO, Calif. – September 5, 2024 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2024, ended August 4, 2024, provided guidance for its fourth quarter of fiscal year 2024 and announced its quarterly dividend.

[0001730168-24-000095:8k_2_02:14]
“Broadcom’s third quarter results reflect continued strength in our AI semiconductor solutions and VMware. We expect revenue from AI to be $12 billion for fiscal year 2024 driven by Ethernet networking and custom accelerators for AI data centers,” said Hock Tan, President and CEO of Broadcom Inc. “The transformation of VMware continues to progress very well. The integration of VMware is driving adjusted EBITDA margin to 64% of revenue as we exit fiscal year 2024.”

[0001730168-24-000095:8k_2_02:15]
“Consolidated revenue grew 47% year-over-year to $13.1 billion, including the contribution from VMware, and was up 4% year-over-year, excluding VMware. Adjusted EBITDA increased 42% year-over-year to $8.2 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow, excluding restructuring and integration in the quarter, was $5.3 billion, up 14% year-over-year.”

[0001730168-24-000095:8k_2_02:16]
________________________________

[0001730168-24-000095:8k_2_02:17]
(1) GAAP net loss of $1,875 million for the third quarter included a one-time discrete non-cash tax provision of $4.5 billion from the impact of an intra-group transfer of certain IP rights to the United States as a result of supply chain realignment.

[0001730168-24-000095:8k_2_02:18]
(2) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-24-000095:8k_2_02:19]
1

[0001730168-24-000095:8k_2_02:20]
Third Quarter Fiscal Year 2024 Financial Highlights

[0001730168-24-000095:8k_2_02:21]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q3 24 |  | Q3 23 |  | Change |  | Q3 24 |  | Q3 23 |  | Change |
| Net revenue |  | $ | 13,072 |  |  | $ | 8,876 |  |  | +47 | % |  | $ | 13,072 |  |  | $ | 8,876 |  |  | +47 | % |
| Net income (loss) |  | $ | (1,875) |  |  | $ | 3,303 |  |  | -$5,178 |  |  | $ | 6,120 |  |  | $ | 4,596 |  |  | +$1,524 |  |
| Earnings (loss) per common share - diluted |  | $ | (0.40) |  |  | $ | 0.77 |  |  | -$1.17 |  |  | $ | 1.24 |  |  | $ | 1.05 |  |  | +$0.19 |  |

[0001730168-24-000095:8k_2_02:22]
| (Dollars in millions) |  | Q3 24 |  | Q3 23 |  | Change |  |
| Cash flow from operations |  | $ | 4,963 |  |  | $ | 4,719 |  |  | +$244 |  |
| Adjusted EBITDA |  | $ | 8,223 |  |  | $ | 5,801 |  |  | +$2,422 |  |
| Free cash flow |  | $ | 4,791 |  |  | $ | 4,597 |  |  | +$194 |  |

[0001730168-24-000095:8k_2_02:23]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 24 |  |  |  | Q3 23 |  | Change |  |
| Semiconductor solutions |  | $ | 7,274 |  |  | 56 | % |  |  |  |  |  |  | $ | 6,941 |  |  | 78 | % |  | +5 | % |  |
| Infrastructure software |  | 5,798 |  |  | 44 |  |  |  |  |  |  |  | 1,935 |  |  | 22 |  |  | +200 | % |  |
| Total net revenue |  | $ | 13,072 |  |  | 100 | % |  |  |  |  |  |  | $ | 8,876 |  |  | 100 | % |  |  |  |  |

[0001730168-24-000095:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,952 million, compared to $9,809 million at the end of the prior quarter.

[0001730168-24-000095:8k_2_02:25]
During the third fiscal quarter, the Company generated $4,963 million in cash from operations and spent $172 million on capital expenditures. The Company paid $1,350 million of withholding taxes related to net settled equity awards that vested in the quarter (resulting in the elimination of 8.4 million shares).

[0001730168-24-000095:8k_2_02:26]
On June 28, 2024, the Company paid a cash dividend on a split adjusted basis of $0.525 per share, totaling $2,452 million.

[0001730168-24-000095:8k_2_02:27]
On July 12, 2024, the Company completed a ten-for-one forward stock split. All share and per-share amounts presented have been retroactively adjusted to reflect the stock split.

[0001730168-24-000095:8k_2_02:28]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-24-000095:8k_2_02:29]
Fourth Quarter Fiscal Year 2024 Business Outlook

[0001730168-24-000095:8k_2_02:30]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2024, ending November 3, 2024, is expected to be as follows:

[0001730168-24-000095:8k_2_02:31]
•Fourth quarter revenue guidance of approximately $14.0 billion; and

[0001730168-24-000095:8k_2_02:32]
•Fourth quarter Adjusted EBITDA guidance of approximately 64 percent of projected revenue.

[0001730168-24-000095:8k_2_02:33]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000095:8k_2_02:34]
2

[0001730168-24-000095:8k_2_02:35]
Quarterly Dividends

[0001730168-24-000095:8k_2_02:36]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.53 per share. The dividend is payable on September 30, 2024 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 19, 2024.

[0001730168-24-000095:8k_2_02:37]
Financial Results Conference Call

[0001730168-24-000095:8k_2_02:38]
Broadcom Inc. will host a conference call to review its financial results for the third quarter of fiscal year 2024 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-24-000095:8k_2_02:39]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-24-000095:8k_2_02:40]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BI2e2492b9ea69411db142832ceb22d56e. Upon registering, a link to the dial-in number and unique PIN will be emailed to the registrant.

[0001730168-24-000095:8k_2_02:41]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-24-000095:8k_2_02:42]
Non-GAAP Financial Measures

[0001730168-24-000095:8k_2_02:43]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-24-000095:8k_2_02:44]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-24-000095:8k_2_02:45]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors

[0001730168-24-000095:8k_2_02:46]
3

[0001730168-24-000095:8k_2_02:47]
should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-24-000095:8k_2_02:48]
About Broadcom

[0001730168-24-000095:8k_2_02:49]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-24-000095:8k_2_02:50]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-24-000095:8k_2_02:51]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our acquisition of VMware, Inc., including employee retention, unexpected costs, charges or expenses, and our ability to successfully integrate VMware’s business and realize the expected benefits; any acquisitions or dispositions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and resellers of our products; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of security systems; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; involvement in legal proceedings; demand for our

[0001730168-24-000095:8k_2_02:52]
4

[0001730168-24-000095:8k_2_02:53]
data center virtualization products; ability of our software products to manage and secure IT infrastructures and environments; ability to manage customer and market acceptance of our products and services; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third-party software used in our products; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs, our ability to maintain tax concessions in certain jurisdictions and potential tax liabilities as a result of acquiring VMware; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-24-000095:8k_2_02:54]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000095:8k_2_02:55]
Contact:

[0001730168-24-000095:8k_2_02:56]
Ji Yoo

[0001730168-24-000095:8k_2_02:57]
Broadcom Inc.

[0001730168-24-000095:8k_2_02:58]
Investor Relations

[0001730168-24-000095:8k_2_02:59]
650-427-6000

[0001730168-24-000095:8k_2_02:60]
investor.relations@broadcom.com

[0001730168-24-000095:8k_2_02:61]
(AVGO-Q)

[0001730168-24-000095:8k_2_02:62]
5

[0001730168-24-000095:8k_2_02:63]
BROADCOM INC.

[0001730168-24-000095:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-24-000095:8k_2_02:65]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-24-000095:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | May 5,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
| Net revenue |  | $ | 13,072 |  |  | $ | 12,487 |  |  | $ | 8,876 |  |  | $ | 37,520 |  |  | $ | 26,524 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,133 |  |  | 3,142 |  |  | 2,272 |  |  | 9,389 |  |  | 6,823 |  |
| Amortization of acquisition-related intangible assets |  | 1,525 |  |  | 1,516 |  |  | 439 |  |  | 4,421 |  |  | 1,415 |  |
| Restructuring charges |  | 58 |  |  | 53 |  |  | 1 |  |  | 203 |  |  | 3 |  |
| Total cost of revenue |  | 4,716 |  |  | 4,711 |  |  | 2,712 |  |  | 14,013 |  |  | 8,241 |  |
| Gross margin |  | 8,356 |  |  | 7,776 |  |  | 6,164 |  |  | 23,507 |  |  | 18,283 |  |
| Research and development |  | 2,353 |  |  | 2,415 |  |  | 1,358 |  |  | 7,076 |  |  | 3,865 |  |
| Selling, general and administrative |  | 1,100 |  |  | 1,277 |  |  | 388 |  |  | 3,949 |  |  | 1,174 |  |
| Amortization of acquisition-related intangible assets |  | 812 |  |  | 827 |  |  | 350 |  |  | 2,431 |  |  | 1,046 |  |
| Restructuring and other charges |  | 303 |  |  | 292 |  |  | 212 |  |  | 1,215 |  |  | 231 |  |
| Total operating expenses |  | 4,568 |  |  | 4,811 |  |  | 2,308 |  |  | 14,671 |  |  | 6,316 |  |
| Operating income |  | 3,788 |  |  | 2,965 |  |  | 3,856 |  |  | 8,836 |  |  | 11,967 |  |
| Interest expense |  | (1,064) |  |  | (1,047) |  |  | (406) |  |  | (3,037) |  |  | (1,217) |  |
| Other income, net |  | 82 |  |  | 87 |  |  | 124 |  |  | 354 |  |  | 380 |  |
| Income from continuing operations before income taxes |  | 2,806 |  |  | 2,005 |  |  | 3,574 |  |  | 6,153 |  |  | 11,130 |  |
| Provision for (benefit from) income taxes |  | 4,238 |  |  | (116) |  |  | 271 |  |  | 4,190 |  |  | 572 |  |
| Income (loss) from continuing operations |  | (1,432) |  |  | 2,121 |  |  | 3,303 |  |  | 1,963 |  |  | 10,558 |  |
| Loss from discontinued operations, net of income taxes |  | (443) |  |  | — |  |  | — |  |  | (392) |  |  | — |  |
| Net income (loss) |  | $ | (1,875) |  |  | $ | 2,121 |  |  | $ | 3,303 |  |  | $ | 1,571 |  |  | $ | 10,558 |  |
| Basic income (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | (0.31) |  |  | $ | 0.46 |  |  | $ | 0.80 |  |  | $ | 0.43 |  |  | $ | 2.54 |  |
| Loss per share from discontinued operations |  | (0.09) |  |  | — |  |  | — |  |  | (0.09) |  |  | — |  |
| Net income (loss) per share |  | $ | (0.40) |  |  | $ | 0.46 |  |  | $ | 0.80 |  |  | $ | 0.34 |  |  | $ | 2.54 |  |
| Diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | (0.31) |  |  | $ | 0.44 |  |  | $ | 0.77 |  |  | $ | 0.41 |  |  | $ | 2.47 |  |
| Loss per share from discontinued operations |  | (0.09) |  |  | — |  |  | — |  |  | (0.08) |  |  | — |  |
| Net income (loss) per share |  | $ | (0.40) |  |  | $ | 0.44 |  |  | $ | 0.77 |  |  | $ | 0.33 |  |  | $ | 2.47 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,663 |  |  | 4,645 |  |  | 4,130 |  |  | 4,606 |  |  | 4,154 |  |
| Diluted |  | 4,663 |  |  | 4,799 |  |  | 4,269 |  |  | 4,762 |  |  | 4,274 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 174 |  |  | $ | 170 |  |  | $ | 61 |  |  | $ | 505 |  |  | $ | 148 |  |
| Research and development |  | 877 |  |  | 881 |  |  | 444 |  |  | 2,621 |  |  | 1,065 |  |
| Selling, general and administrative |  | 330 |  |  | 352 |  |  | 124 |  |  | 1,230 |  |  | 320 |  |
| Total stock-based compensation expense |  | $ | 1,381 |  |  | $ | 1,403 |  |  | $ | 629 |  |  | $ | 4,356 |  |  | $ | 1,533 |  |

[0001730168-24-000095:8k_2_02:67]
BROADCOM INC.

[0001730168-24-000095:8k_2_02:68]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-24-000095:8k_2_02:69]
(IN MILLIONS)

[0001730168-24-000095:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | May 5,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
| Gross margin on GAAP basis |  | $ | 8,356 |  |  | $ | 7,776 |  |  | $ | 6,164 |  |  | $ | 23,507 |  |  | $ | 18,283 |  |
| Amortization of acquisition-related intangible assets |  | 1,525 |  |  | 1,516 |  |  | 439 |  |  | 4,421 |  |  | 1,415 |  |
| Stock-based compensation expense |  | 174 |  |  | 170 |  |  | 61 |  |  | 505 |  |  | 148 |  |
| Restructuring charges |  | 58 |  |  | 53 |  |  | 1 |  |  | 203 |  |  | 3 |  |
| Acquisition-related costs |  | — |  |  | 3 |  |  | — |  |  | 9 |  |  | — |  |
| Gross margin on non-GAAP basis |  | $ | 10,113 |  |  | $ | 9,518 |  |  | $ | 6,665 |  |  | $ | 28,645 |  |  | $ | 19,849 |  |
| Research and development on GAAP basis |  | $ | 2,353 |  |  | $ | 2,415 |  |  | $ | 1,358 |  |  | $ | 7,076 |  |  | $ | 3,865 |  |
| Stock-based compensation expense |  | 877 |  |  | 881 |  |  | 444 |  |  | 2,621 |  |  | 1,065 |  |
| Acquisition-related costs |  | 2 |  |  | — |  |  | 1 |  |  | 3 |  |  | — |  |
| Research and development on non-GAAP basis |  | $ | 1,474 |  |  | $ | 1,534 |  |  | $ | 913 |  |  | $ | 4,452 |  |  | $ | 2,800 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,100 |  |  | $ | 1,277 |  |  | $ | 388 |  |  | $ | 3,949 |  |  | $ | 1,174 |  |
| Stock-based compensation expense |  | 330 |  |  | 352 |  |  | 124 |  |  | 1,230 |  |  | 320 |  |
| Acquisition-related costs |  | 79 |  |  | 87 |  |  | 48 |  |  | 451 |  |  | 183 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 691 |  |  | $ | 838 |  |  | $ | 216 |  |  | $ | 2,268 |  |  | $ | 671 |  |
| Total operating expenses on GAAP basis |  | $ | 4,568 |  |  | $ | 4,811 |  |  | $ | 2,308 |  |  | $ | 14,671 |  |  | $ | 6,316 |  |
| Amortization of acquisition-related intangible assets |  | 812 |  |  | 827 |  |  | 350 |  |  | 2,431 |  |  | 1,046 |  |
| Stock-based compensation expense |  | 1,207 |  |  | 1,233 |  |  | 568 |  |  | 3,851 |  |  | 1,385 |  |
| Restructuring and other charges |  | 303 |  |  | 292 |  |  | 212 |  |  | 1,215 |  |  | 231 |  |
| Acquisition-related costs |  | 81 |  |  | 87 |  |  | 49 |  |  | 454 |  |  | 183 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,165 |  |  | $ | 2,372 |  |  | $ | 1,129 |  |  | $ | 6,720 |  |  | $ | 3,471 |  |
| Operating income on GAAP basis |  | $ | 3,788 |  |  | $ | 2,965 |  |  | $ | 3,856 |  |  | $ | 8,836 |  |  | $ | 11,967 |  |
| Amortization of acquisition-related intangible assets |  | 2,337 |  |  | 2,343 |  |  | 789 |  |  | 6,852 |  |  | 2,461 |  |
| Stock-based compensation expense |  | 1,381 |  |  | 1,403 |  |  | 629 |  |  | 4,356 |  |  | 1,533 |  |
| Restructuring and other charges |  | 361 |  |  | 345 |  |  | 213 |  |  | 1,418 |  |  | 234 |  |
| Acquisition-related costs |  | 81 |  |  | 90 |  |  | 49 |  |  | 463 |  |  | 183 |  |
| Operating income on non-GAAP basis |  | $ | 7,948 |  |  | $ | 7,146 |  |  | $ | 5,536 |  |  | $ | 21,925 |  |  | $ | 16,378 |  |
| Interest expense on GAAP basis |  | $ | (1,064) |  |  | $ | (1,047) |  |  | $ | (406) |  |  | $ | (3,037) |  |  | $ | (1,217) |  |
| Loss on debt extinguishment |  | 83 |  |  | 22 |  |  | — |  |  | 105 |  |  | — |  |
| Interest expense on non-GAAP basis |  | $ | (981) |  |  | $ | (1,025) |  |  | $ | (406) |  |  | $ | (2,932) |  |  | $ | (1,217) |  |
| Other income, net on GAAP basis |  | $ | 82 |  |  | $ | 87 |  |  | $ | 124 |  |  | $ | 354 |  |  | $ | 380 |  |
| (Gains) losses on investments |  | 6 |  |  | 9 |  |  | (2) |  |  | (18) |  |  | (35) |  |
| Other income, net on non-GAAP basis |  | $ | 88 |  |  | $ | 96 |  |  | $ | 122 |  |  | $ | 336 |  |  | $ | 345 |  |

[0001730168-24-000095:8k_2_02:71]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | May 5,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 4,238 |  |  | $ | (116) |  |  | $ | 271 |  |  | $ | 4,190 |  |  | $ | 572 |  |
| Non-GAAP tax reconciling adjustments (1) |  | (3,303) |  |  | 939 |  |  | 385 |  |  | (1,629) |  |  | 1,366 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 935 |  |  | $ | 823 |  |  | $ | 656 |  |  | $ | 2,561 |  |  | $ | 1,938 |  |
| Net income (loss) on GAAP basis |  | $ | (1,875) |  |  | $ | 2,121 |  |  | $ | 3,303 |  |  | $ | 1,571 |  |  | $ | 10,558 |  |
| Amortization of acquisition-related intangible assets |  | 2,337 |  |  | 2,343 |  |  | 789 |  |  | 6,852 |  |  | 2,461 |  |
| Stock-based compensation expense |  | 1,381 |  |  | 1,403 |  |  | 629 |  |  | 4,356 |  |  | 1,533 |  |
| Restructuring and other charges |  | 361 |  |  | 345 |  |  | 213 |  |  | 1,418 |  |  | 234 |  |
| Acquisition-related costs |  | 81 |  |  | 90 |  |  | 49 |  |  | 463 |  |  | 183 |  |
| Loss on debt extinguishment |  | 83 |  |  | 22 |  |  | — |  |  | 105 |  |  | — |  |
| (Gains) losses on investments |  | 6 |  |  | 9 |  |  | (2) |  |  | (18) |  |  | (35) |  |
| Non-GAAP tax reconciling adjustments (1) |  | 3,303 |  |  | (939) |  |  | (385) |  |  | 1,629 |  |  | (1,366) |  |
| Loss from discontinued operations, net of income taxes |  | 443 |  |  | — |  |  | — |  |  | 392 |  |  | — |  |
| Net income on non-GAAP basis |  | $ | 6,120 |  |  | $ | 5,394 |  |  | $ | 4,596 |  |  | $ | 16,768 |  |  | $ | 13,568 |  |
| Net income (loss) on GAAP basis |  | $ | (1,875) |  |  | $ | 2,121 |  |  | $ | 3,303 |  |  | $ | 1,571 |  |  | $ | 10,558 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,337 |  |  | 2,343 |  |  | 789 |  |  | 6,852 |  |  | 2,461 |  |
| Stock-based compensation expense |  | 1,381 |  |  | 1,403 |  |  | 629 |  |  | 4,356 |  |  | 1,533 |  |
| Restructuring and other charges |  | 361 |  |  | 345 |  |  | 213 |  |  | 1,418 |  |  | 234 |  |
| Acquisition-related costs |  | 81 |  |  | 90 |  |  | 49 |  |  | 463 |  |  | 183 |  |
| Loss on debt extinguishment |  | 83 |  |  | 22 |  |  | — |  |  | 105 |  |  | — |  |
| (Gains) losses on investments |  | 6 |  |  | 9 |  |  | (2) |  |  | (18) |  |  | (35) |  |
| Non-GAAP tax reconciling adjustments (1) |  | 3,303 |  |  | (939) |  |  | (385) |  |  | 1,629 |  |  | (1,366) |  |
| Loss from discontinued operations, net of income taxes |  | 443 |  |  | — |  |  | — |  |  | 392 |  |  | — |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 981 |  |  | 1,025 |  |  | 406 |  |  | 2,932 |  |  | 1,217 |  |
| Provision for income taxes on non-GAAP basis |  | 935 |  |  | 823 |  |  | 656 |  |  | 2,561 |  |  | 1,938 |  |
| Depreciation |  | 149 |  |  | 149 |  |  | 122 |  |  | 437 |  |  | 378 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 38 |  |  | 38 |  |  | 21 |  |  | 110 |  |  | 64 |  |
| Adjusted EBITDA |  | $ | 8,223 |  |  | $ | 7,429 |  |  | $ | 5,801 |  |  | $ | 22,808 |  |  | $ | 17,165 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,663 |  |  | 4,799 |  |  | 4,269 |  |  | 4,762 |  |  | 4,274 |  |
| Non-GAAP adjustment (2) |  | 254 |  |  | 117 |  |  | 94 |  |  | 106 |  |  | 80 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,917 |  |  | 4,916 |  |  | 4,363 |  |  | 4,868 |  |  | 4,354 |  |
| Net cash provided by operating activities |  | $ | 4,963 |  |  | $ | 4,580 |  |  | $ | 4,719 |  |  | $ | 14,358 |  |  | $ | 13,257 |  |
| Purchases of property, plant and equipment |  | (172) |  |  | (132) |  |  | (122) |  |  | (426) |  |  | (347) |  |
| Free cash flow |  | $ | 4,791 |  |  | $ | 4,448 |  |  | $ | 4,597 |  |  | $ | 13,932 |  |  | $ | 12,910 |  |

[0001730168-24-000095:8k_2_02:72]
|  |  | Fiscal Quarter Ending |
|  |  | November 3, |
| Expected average diluted share count: |  | 2024 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,824 |  |
| Non-GAAP adjustment (2) |  | 88 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,912 |  |

[0001730168-24-000095:8k_2_02:73]
| (1) Non-GAAP tax reconciling adjustments included a one-time discrete non-cash tax provision of $4.5 billion from the impact of an intra-group transfer of certain IP rights to the United States as a result of supply chain realignment for the fiscal quarter and three fiscal quarters ended August 4, 2024. |
| (2) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter ended August 4, 2024, non-GAAP adjustment included the dilutive effect of the equity awards that were antidilutive on a GAAP basis. |

[0001730168-24-000095:8k_2_02:74]
BROADCOM INC.

[0001730168-24-000095:8k_2_02:75]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-24-000095:8k_2_02:76]
(IN MILLIONS)

[0001730168-24-000095:8k_2_02:77]
|  |  | August 4,2024 |  | October 29,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,952 |  |  | $ | 14,189 |  |
| Trade accounts receivable, net |  | 4,665 |  |  | 3,154 |  |
| Inventory |  | 1,894 |  |  | 1,898 |  |
| Other current assets |  | 3,436 |  |  | 1,606 |  |
| Total current assets |  | 19,947 |  |  | 20,847 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,602 |  |  | 2,154 |  |
| Goodwill |  | 97,873 |  |  | 43,653 |  |
| Intangible assets, net |  | 43,034 |  |  | 3,867 |  |
| Other long-term assets |  | 4,510 |  |  | 2,340 |  |
| Total assets |  | $ | 167,966 |  |  | $ | 72,861 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,757 |  |  | $ | 1,210 |  |
| Employee compensation and benefits |  | 1,725 |  |  | 935 |  |
| Current portion of long-term debt |  | 3,161 |  |  | 1,608 |  |
| Other current liabilities |  | 12,578 |  |  | 3,652 |  |
| Total current liabilities |  | 19,221 |  |  | 7,405 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 66,798 |  |  | 37,621 |  |
| Other long-term liabilities |  | 16,296 |  |  | 3,847 |  |
| Total liabilities |  | 102,315 |  |  | 48,873 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 4 |  |
| Additional paid-in capital |  | 67,313 |  |  | 21,095 |  |
| Retained earnings (accumulated deficit) |  | (1,875) |  |  | 2,682 |  |
| Accumulated other comprehensive income |  | 208 |  |  | 207 |  |
| Total stockholders' equity |  | 65,651 |  |  | 23,988 |  |
| Total liabilities and equity |  | $ | 167,966 |  |  | $ | 72,861 |  |

[0001730168-24-000095:8k_2_02:78]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | May 5,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (1,875) |  |  | $ | 2,121 |  |  | $ | 3,303 |  |  | $ | 1,571 |  |  | $ | 10,558 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,375 |  |  | 2,381 |  |  | 810 |  |  | 6,962 |  |  | 2,525 |  |
| Depreciation |  | 149 |  |  | 149 |  |  | 122 |  |  | 437 |  |  | 378 |  |
| Stock-based compensation |  | 1,388 |  |  | 1,457 |  |  | 629 |  |  | 4,427 |  |  | 1,533 |  |
| Deferred taxes and other non-cash taxes |  | 3,638 |  |  | (511) |  |  | (251) |  |  | 2,833 |  |  | (1,140) |  |
| Loss on debt extinguishment |  | 83 |  |  | 22 |  |  | — |  |  | 105 |  |  | — |  |
| Non-cash interest expense |  | 115 |  |  | 119 |  |  | 33 |  |  | 336 |  |  | 98 |  |
| Other |  | 158 |  |  | 70 |  |  | — |  |  | 266 |  |  | (18) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 835 |  |  | (513) |  |  | 135 |  |  | 2,078 |  |  | 44 |  |
| Inventory |  | (52) |  |  | 82 |  |  | 44 |  |  | 16 |  |  | 83 |  |
| Accounts payable |  | 373 |  |  | (93) |  |  | 188 |  |  | 206 |  |  | (6) |  |
| Employee compensation and benefits |  | 291 |  |  | 251 |  |  | 184 |  |  | (118) |  |  | (382) |  |
| Other current assets and current liabilities |  | (1,345) |  |  | (386) |  |  | (339) |  |  | (3,913) |  |  | 66 |  |
| Other long-term assets and long-term liabilities |  | (1,170) |  |  | (569) |  |  | (139) |  |  | (848) |  |  | (482) |  |
| Net cash provided by operating activities |  | 4,963 |  |  | 4,580 |  |  | 4,719 |  |  | 14,358 |  |  | 13,257 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (2) |  |  | (560) |  |  | (17) |  |  | (25,978) |  |  | (17) |  |
| Proceeds from sale of business |  | 3,485 |  |  | — |  |  | — |  |  | 3,485 |  |  | — |  |
| Purchases of property, plant and equipment |  | (172) |  |  | (132) |  |  | (122) |  |  | (426) |  |  | (347) |  |
| Purchases of investments |  | (73) |  |  | (59) |  |  | (91) |  |  | (145) |  |  | (288) |  |
| Sales of investments |  | 5 |  |  | 42 |  |  | 74 |  |  | 136 |  |  | 74 |  |
| Other |  | 2 |  |  | 3 |  |  | 12 |  |  | (10) |  |  | 13 |  |
| Net cash provided by (used in) investing activities |  | 3,245 |  |  | (706) |  |  | (144) |  |  | (22,938) |  |  | (565) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 4,975 |  |  | — |  |  | — |  |  | 34,985 |  |  | — |  |
| Payments on debt obligations |  | (9,202) |  |  | (2,000) |  |  | — |  |  | (12,136) |  |  | (260) |  |
| Payments of dividends |  | (2,452) |  |  | (2,443) |  |  | (1,901) |  |  | (7,330) |  |  | (5,741) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | (1,707) |  |  | (7,176) |  |  | (5,701) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (1,350) |  |  | (1,548) |  |  | (460) |  |  | (4,012) |  |  | (1,407) |  |
| Issuance of common stock |  | — |  |  | 64 |  |  | — |  |  | 64 |  |  | 63 |  |
| Other |  | (36) |  |  | (2) |  |  | (5) |  |  | (52) |  |  | (7) |  |
| Net cash provided by (used in) financing activities |  | (8,065) |  |  | (5,929) |  |  | (4,073) |  |  | 4,343 |  |  | (13,053) |  |
| Net change in cash and cash equivalents |  | 143 |  |  | (2,055) |  |  | 502 |  |  | (4,237) |  |  | (361) |  |
| Cash and cash equivalents at beginning of period |  | 9,809 |  |  | 11,864 |  |  | 11,553 |  |  | 14,189 |  |  | 12,416 |  |
| Cash and cash equivalents at end of period |  | $ | 9,952 |  |  | $ | 9,809 |  |  | $ | 12,055 |  |  | $ | 9,952 |  |  | $ | 12,055 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 816 |  |  | $ | 946 |  |  | $ | 348 |  |  | $ | 2,512 |  |  | $ | 1,106 |  |
| Cash paid for income taxes |  | $ | 585 |  |  | $ | 834 |  |  | $ | 427 |  |  | $ | 2,323 |  |  | $ | 1,591 |  |
