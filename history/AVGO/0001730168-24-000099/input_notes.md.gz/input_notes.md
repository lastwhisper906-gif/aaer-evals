# AVGO notes — 0001730168-24-000099


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-24-000099:notes:1]
[same as prior period, unchanged from 0001730168-24-000080:notes:1]

[0001730168-24-000099:notes:2]
[same as prior period, unchanged from 0001730168-24-000080:notes:2]

[0001730168-24-000099:notes:3]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.

[0001730168-24-000099:notes:4]
[same as prior period, unchanged from 0001730168-24-000080:notes:4]

[0001730168-24-000099:notes:5]
[same as prior period, unchanged from 0001730168-24-000080:notes:5]

[0001730168-24-000099:notes:6]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 4, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.

[0001730168-24-000099:notes:7]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock through the filing of an amendment (“Amendment”) to our Amended and Restated Certificate of Incorporation. The Amendment proportionately increased the number of shares of our authorized common stock without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented in the accompanying condensed consolidated financial statements and notes thereto have been retroactively adjusted, where applicable, to reflect the stock split.

[0001730168-24-000099:notes:8]
[same as prior period, unchanged from 0001730168-24-000080:notes:7]

[0001730168-24-000099:notes:9]
[same as prior period, unchanged from 0001730168-24-000080:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-24-000099:notes:10]
[same as prior period, unchanged from 0001730168-24-000080:notes:9]

[0001730168-24-000099:notes:11]
[same as prior period, unchanged from 0001730168-24-000080:notes:10]

[0001730168-24-000099:notes:12]
[same as prior period, unchanged from 0001730168-24-000080:notes:11]

[0001730168-24-000099:notes:13]
[same as prior period, unchanged from 0001730168-24-000080:notes:12]

[0001730168-24-000099:notes:14]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

[0001730168-24-000099:notes:15]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |

[0001730168-24-000099:notes:16]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |

[0001730168-24-000099:notes:17]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |

[0001730168-24-000099:notes:18]
[same as prior period, unchanged from 0001730168-24-000080:notes:17]

[0001730168-24-000099:notes:19]
[same as prior period, unchanged from 0001730168-24-000080:notes:18]

[0001730168-24-000099:notes:20]
[same as prior period, unchanged from 0001730168-24-000080:notes:19]

[0001730168-24-000099:notes:21]
|  |  | August 4,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 3,658 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 15,548 |  |  | $ | 2,786 |  |

[0001730168-24-000099:notes:22]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of August 4, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of August 4, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million. The amount of revenue recognized during the three fiscal quarters ended July 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,677 million.

[0001730168-24-000099:notes:23]
[same as prior period, unchanged from 0001730168-24-000080:notes:22]

[0001730168-24-000099:notes:24]
[same as prior period, unchanged from 0001730168-24-000080:notes:23]

[0001730168-24-000099:notes:25]
Certain multi-year customer contracts in our semiconductor solutions and infrastructure software segments contain firmly committed amounts and the remaining performance obligations under these contracts as of August 4, 2024 were approximately $21.2 billion. We expect approximately 44% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-24-000099:notes:26]
[same as prior period, unchanged from 0001730168-24-000080:notes:25]

[0001730168-24-000099:notes:27]
On November 22, 2023, we completed the VMware Merger. Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash or 2.52 shares of Broadcom common stock (on a split adjusted basis). The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the VMware Merger. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million.

[0001730168-24-000099:notes:28]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 7. “Borrowings”, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-24-000099:notes:29]
[same as prior period, unchanged from 0001730168-24-000080:notes:28]

[0001730168-24-000099:notes:30]
[same as prior period, unchanged from 0001730168-24-000080:notes:29]

[0001730168-24-000099:notes:31]
[same as prior period, unchanged from 0001730168-24-000080:notes:30]

[0001730168-24-000099:notes:32]
[same as prior period, unchanged from 0001730168-24-000080:notes:31]

[0001730168-24-000099:notes:33]
The following table presents our preliminary allocation of the total purchase price, net of cash acquired, updated as of August 4, 2024:

[0001730168-24-000099:notes:34]
[same as prior period, unchanged from 0001730168-24-000080:notes:33]

[0001730168-24-000099:notes:35]
[same as prior period, unchanged from 0001730168-24-000080:notes:34]

[0001730168-24-000099:notes:36]
Assets and liabilities held-for-sale primarily included the end-user computing (“EUC”) business and certain other assets and liabilities, which were not aligned with our strategic objectives. On July 1, 2024, we sold the EUC business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-24-000099:notes:37]
Our results of continuing operations included $3,833 million and $8,609 million of net revenue attributable to VMware for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. It is impracticable to determine the effect on net income attributable to VMware as we have integrated a substantial portion of VMware into our ongoing operations. Transaction costs related to the VMware Merger of $12 million and $252 million, respectively, were primarily included in selling, general and administrative expense for the fiscal quarter and three fiscal quarters ended August 4, 2024.

[0001730168-24-000099:notes:38]
[same as prior period, unchanged from 0001730168-24-000080:notes:37]

[0001730168-24-000099:notes:39]
[same as prior period, unchanged from 0001730168-24-000080:notes:38]

[0001730168-24-000099:notes:40]
[same as prior period, unchanged from 0001730168-24-000080:notes:39]

[0001730168-24-000099:notes:41]
[same as prior period, unchanged from 0001730168-24-000080:notes:40]

[0001730168-24-000099:notes:42]
[same as prior period, unchanged from 0001730168-24-000080:notes:41]

[0001730168-24-000099:notes:43]
[same as prior period, unchanged from 0001730168-24-000080:notes:42]

[0001730168-24-000099:notes:44]
[same as prior period, unchanged from 0001730168-24-000080:notes:43]

[0001730168-24-000099:notes:45]
[same as prior period, unchanged from 0001730168-24-000080:notes:44]

[0001730168-24-000099:notes:46]
[same as prior period, unchanged from 0001730168-24-000080:notes:45]

[0001730168-24-000099:notes:47]
[same as prior period, unchanged from 0001730168-24-000080:notes:46]

[0001730168-24-000099:notes:48]
[same as prior period, unchanged from 0001730168-24-000080:notes:47]

[0001730168-24-000099:notes:49]
[same as prior period, unchanged from 0001730168-24-000080:notes:48]

[0001730168-24-000099:notes:50]
[same as prior period, unchanged from 0001730168-24-000080:notes:49]

[0001730168-24-000099:notes:51]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 13,088 |  |  | $ | 11,938 |  |  | $ | 38,118 |  |  | $ | 35,827 |  |
| Pro forma net income (loss) |  | $ | (1,819) |  |  | $ | 2,030 |  |  | $ | 2,057 |  |  | $ | 5,879 |  |

[0001730168-24-000099:notes:52]
[same as prior period, unchanged from 0001730168-24-000080:notes:51]

[0001730168-24-000099:notes:53]
[same as prior period, unchanged from 0001730168-24-000080:notes:52]

[0001730168-24-000099:notes:54]
[same as prior period, unchanged from 0001730168-24-000080:notes:53]

[0001730168-24-000099:notes:55]
[same as prior period, unchanged from 0001730168-24-000080:notes:54]

[0001730168-24-000099:notes:56]
[same as prior period, unchanged from 0001730168-24-000080:notes:55]

[0001730168-24-000099:notes:57]
[same as prior period, unchanged from 0001730168-24-000080:notes:56]

[0001730168-24-000099:notes:58]
[same as prior period, unchanged from 0001730168-24-000080:notes:57]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-24-000099:notes:59]
[same as prior period, unchanged from 0001730168-24-000080:notes:58]

[0001730168-24-000099:notes:60]
Cash equivalents included $1,791 million and $1,470 million of time deposits and $1,344 million and $1,650 million of money-market funds as of August 4, 2024 and October 29, 2023, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-24-000099:notes:61]
[same as prior period, unchanged from 0001730168-24-000080:notes:60]

[0001730168-24-000099:notes:62]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,450 million and $3,950 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and $900 million and $2,825 million during the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively.

[0001730168-24-000099:notes:63]
[same as prior period, unchanged from 0001730168-24-000080:notes:62]

[0001730168-24-000099:notes:64]
|  |  | August 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Finished goods |  | $ | 568 |  |  | $ | 676 |  |
| Work-in-process |  | 896 |  |  | 901 |  |
| Raw materials |  | 430 |  |  | 321 |  |
| Total inventory |  | $ | 1,894 |  |  | $ | 1,898 |  |

[0001730168-24-000099:notes:65]
[same as prior period, unchanged from 0001730168-24-000080:notes:67]

[0001730168-24-000099:notes:66]
On July 1, 2024, we sold the EUC business for $3.5 billion, after working capital adjustments. In connection with the sale, we agreed to provide transitional services to the buyer on a short-term basis. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-24-000099:notes:67]
The following table summarizes the selected financial information of discontinued operations:

[0001730168-24-000099:notes:68]
|  |  | Fiscal Quarter Ended August 4, 2024 |  | Three Fiscal Quarters Ended August 4, 2024 |  |  |
|  |  | (In millions) |
| Net revenue |  | $ | 178 |  |  |  |  |  |  | $ | 858 |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  | $ | (100) |  |  |  |  |  |  | $ | (31) |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | (343) |  |  |  |  |  |  | (361) |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations, net of income taxes |  | $ | (443) |  |  |  |  |  |  | $ | (392) |  |  |  |  |  |  |  |  |  |

[0001730168-24-000099:notes:69]
[same as prior period, unchanged from 0001730168-24-000080:notes:70]

[0001730168-24-000099:notes:70]
|  |  | August 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 1,557 |  |  | $ | 499 |  |
| Prepaid expenses |  | 1,070 |  |  | 743 |  |
| Other |  | 809 |  |  | 364 |  |
| Total other current assets |  | $ | 3,436 |  |  | $ | 1,606 |  |

[0001730168-24-000099:notes:71]
[same as prior period, unchanged from 0001730168-24-000080:notes:72]

[0001730168-24-000099:notes:72]
|  |  | August 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,789 |  |  | $ | 2,487 |  |
| Tax liabilities |  | 1,091 |  |  | 473 |  |
| Interest payable |  | 500 |  |  | 380 |  |
| Other |  | 1,198 |  |  | 312 |  |
| Total other current liabilities |  | $ | 12,578 |  |  | $ | 3,652 |  |

[0001730168-24-000099:notes:73]
[same as prior period, unchanged from 0001730168-24-000080:notes:74]

[0001730168-24-000099:notes:74]
|  |  | August 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 5,759 |  |  | $ | 299 |  |
| Deferred tax liabilities |  | 5,594 |  |  | 99 |  |
| Unrecognized tax benefits |  | 3,356 |  |  | 2,792 |  |
| Other |  | 1,587 |  |  | 657 |  |
| Total other long-term liabilities |  | $ | 16,296 |  |  | $ | 3,847 |  |

[0001730168-24-000099:notes:75]
[same as prior period, unchanged from 0001730168-24-000080:notes:76]

[0001730168-24-000099:notes:76]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 816 |  |  | $ | 348 |  |  | $ | 2,512 |  |  | $ | 1,106 |  |
| Cash paid for income taxes |  | $ | 585 |  |  | $ | 427 |  |  | $ | 2,323 |  |  | $ | 1,591 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-24-000099:notes:77]
[same as prior period, unchanged from 0001730168-24-000080:notes:78]

[0001730168-24-000099:notes:78]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |  |
|  |  |  |  |  |  |  |  |  |  | (In millions) |  |
| Balance as of October 29, 2023 |  |  |  |  |  |  |  |  |  | $ | 26,001 |  |  | $ | 17,652 |  |  | $ | 43,653 |  |  |
| Acquisition of VMware |  |  |  |  |  |  |  |  |  | — |  |  | 54,206 |  |  | 54,206 |  |  |
| Acquisition of Seagate’s SoC operations |  |  |  |  |  |  |  |  |  | 14 |  |  | — |  |  | 14 |  |  |
| Balance as of August 4, 2024 |  |  |  |  |  |  |  |  |  | $ | 26,015 |  |  | $ | 71,858 |  |  | $ | 97,873 |  |  |

[0001730168-24-000099:notes:79]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of August 4, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 39,657 |  |  | $ | (15,141) |  |  | $ | 24,516 |  |
| Customer contracts and related relationships |  | 22,950 |  |  | (8,217) |  |  | 14,733 |  |
| Trade names |  | 1,854 |  |  | (474) |  |  | 1,380 |  |
| Other |  | 177 |  |  | (112) |  |  | 65 |  |
| Intangible assets subject to amortization |  | 64,638 |  |  | (23,944) |  |  | 40,694 |  |
| In-process research and development |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 66,978 |  |  | $ | (23,944) |  |  | $ | 43,034 |  |
| As of October 29, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 12,938 |  |  | $ | (10,723) |  |  | $ | 2,215 |  |
| Customer contracts and related relationships |  | 7,059 |  |  | (5,753) |  |  | 1,306 |  |
| Trade names |  | 649 |  |  | (388) |  |  | 261 |  |
| Other |  | 177 |  |  | (102) |  |  | 75 |  |
| Intangible assets subject to amortization |  | 20,823 |  |  | (16,966) |  |  | 3,857 |  |
| In-process research and development |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 20,833 |  |  | $ | (16,966) |  |  | $ | 3,867 |  |

[0001730168-24-000099:notes:80]
Based on the amount of intangible assets subject to amortization as of August 4, 2024, the expected amortization expense was as follows:

[0001730168-24-000099:notes:81]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 2,451 |  |
| 2025 |  | 8,055 |  |
| 2026 |  | 7,571 |  |
| 2027 |  | 6,533 |  |
| 2028 |  | 5,443 |  |
| Thereafter |  | 10,641 |  |
| Total |  | $ | 40,694 |  |

[0001730168-24-000099:notes:82]
[same as prior period, unchanged from 0001730168-24-000080:notes:83]

[0001730168-24-000099:notes:83]
| Amortizable intangible assets: |  | August 4,2024 |
|  |  | (In years) |
| Purchased technology |  | 7 |
| Customer contracts and related relationships |  | 7 |
| Trade names |  | 12 |
| Other |  | 7 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-24-000099:notes:84]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is computed by dividing net income (loss) by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-24-000099:notes:85]
Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and employee stock purchase plan (“ESPP”) rights (collectively referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income (loss) per share.

[0001730168-24-000099:notes:86]
[same as prior period, unchanged from 0001730168-24-000080:notes:87]

[0001730168-24-000099:notes:87]
For the fiscal quarter ended August 4, 2024, diluted net income (loss) per share excluded the potentially dilutive effect of 159 million shares of weighted-average equity awards outstanding as their effect was antidilutive.

[0001730168-24-000099:notes:88]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income (loss) per share computations for the periods presented:

[0001730168-24-000099:notes:89]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | (1,432) |  |  | $ | 3,303 |  |  | $ | 1,963 |  |  | $ | 10,558 |  |
| Loss from discontinued operations, net of income taxes |  | (443) |  |  | — |  |  | (392) |  |  | — |  |
| Net income (loss) |  | $ | (1,875) |  |  | $ | 3,303 |  |  | $ | 1,571 |  |  | $ | 10,558 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,663 |  |  | 4,130 |  |  | 4,606 |  |  | 4,154 |  |
| Dilutive effect of equity awards |  | — |  |  | 139 |  |  | 156 |  |  | 120 |  |
| Weighted-average shares outstanding - diluted |  | 4,663 |  |  | 4,269 |  |  | 4,762 |  |  | 4,274 |  |

[0001730168-24-000099:notes:90]
| Basic income (loss) per share: |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | (0.31) |  |  | $ | 0.80 |  |  | $ | 0.43 |  |  | $ | 2.54 |  |
| Loss per share from discontinued operations |  | (0.09) |  |  | — |  |  | (0.09) |  |  | — |  |
| Net income (loss) per share |  | $ | (0.40) |  |  | $ | 0.80 |  |  | $ | 0.34 |  |  | $ | 2.54 |  |
| Diluted income (loss) per share: |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | (0.31) |  |  | $ | 0.77 |  |  | $ | 0.41 |  |  | $ | 2.47 |  |
| Loss per share from discontinued operations |  | (0.09) |  |  | — |  |  | (0.08) |  |  | — |  |
| Net income (loss) per share |  | $ | (0.40) |  |  | $ | 0.77 |  |  | $ | 0.33 |  |  | $ | 2.47 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-24-000099:notes:91]
Borrowings

[0001730168-24-000099:notes:92]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | $ | 1,250 |  |  | $ | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.03 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.23 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 19,195 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |

[0001730168-24-000099:notes:93]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 72,319 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,117 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 44 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 3,161 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 69,202 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 17 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,421) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,798 |  |  | $ | 37,621 |  |

[0001730168-24-000099:notes:94]
July 2024 Senior Notes

[0001730168-24-000099:notes:95]
In July 2024, we issued $1,250 million of 5.050% senior unsecured notes due July 2027, $2,250 million of 5.050% senior unsecured notes due July 2029 and $1,500 million of 5.150% senior unsecured notes due November 2031 (collectively, the “July 2024 Senior Notes”).

[0001730168-24-000099:notes:96]
We may redeem or purchase, in whole or in part, the July 2024 Senior Notes prior to their maturities, subject to a specified make-whole premium as set forth in the indenture. In the event of a change of control, note holders will have the right to require us to repurchase all or any part of the holders’ notes at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the July 2024 Senior Notes pays interest semi-annually.

[0001730168-24-000099:notes:97]
2023 Term Loans

[0001730168-24-000099:notes:98]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered an $11,195 million unsecured term A-2 facility (the "Term A-2 Loan”), an $11,195 million unsecured term A-3 facility (the “Term A-3 Loan”), and an $8,000 million unsecured term A-5 facility (the “Term A-5 Loan”, collectively, the “2023 Term Loans”).

[0001730168-24-000099:notes:99]
During the fiscal quarter ended May 5, 2024, we repaid $2,000 million of our Term A-2 Loan. During the fiscal quarter ended August 4, 2024, using the net proceeds from the July 2024 Senior Notes and the sale of the EUC business, as well as cash on hand, we repaid the remaining $9,195 million of our Term A-2 Loan. As a result, we wrote off unamortized discount and issuance costs of $83 million and $105 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, which were included in interest expense in the condensed consolidated statements of operations.

[0001730168-24-000099:notes:100]
The 2023 Term Loans bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The Term A-3 Loan and Term A-5 Loan will mature and be payable on the third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

[0001730168-24-000099:notes:101]
Assumed VMware Senior Notes

[0001730168-24-000099:notes:102]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, note holders will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.

[0001730168-24-000099:notes:103]
2021 Credit Agreement

[0001730168-24-000099:notes:104]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either August 4, 2024 or October 29, 2023.

[0001730168-24-000099:notes:105]
Commercial Paper

[0001730168-24-000099:notes:106]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either August 4, 2024 or October 29, 2023.

[0001730168-24-000099:notes:107]
Fair Value of Debt

[0001730168-24-000099:notes:108]
As of August 4, 2024, the estimated aggregate fair value of debt was $68,417 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-24-000099:notes:109]
Future Principal Payments of Debt

[0001730168-24-000099:notes:110]
The future scheduled principal payments of debt as of August 4, 2024 were as follows:

[0001730168-24-000099:notes:111]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 1,872 |  |
| 2025 |  | 1,245 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 17,332 |  |
| 2028 |  | 3,395 |  |
| Thereafter |  | 45,323 |  |
| Total |  | $ | 72,319 |  |

[0001730168-24-000099:notes:112]
As of August 4, 2024 and October 29, 2023, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-24-000099:notes:113]
Stockholders’ Equity
Stock Split

[0001730168-24-000099:notes:114]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock, proportionately increasing the number of shares of our authorized common stock from 2.9 billion to 29 billion without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented herein have been retroactively adjusted, where applicable, to reflect the stock split.

[0001730168-24-000099:notes:115]
Cash Dividends Declared and Paid

[0001730168-24-000099:notes:116]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.525 |  |  | $ | 0.460 |  |  | $ | 1.575 |  |  | $ | 1.380 |  |
| Dividends to common stockholders |  | $ | 2,452 |  |  | $ | 1,901 |  |  | $ | 7,330 |  |  | $ | 5,741 |  |

[0001730168-24-000099:notes:117]
[same as prior period, unchanged from 0001730168-24-000080:notes:112]

[0001730168-24-000099:notes:118]
We repurchased and retired approximately 67 million shares of our common stock for $7,176 million during the fiscal quarter ended February 4, 2024 which completed all $20 billion under our previously authorized stock repurchase programs prior to expiration on December 31, 2023. During the fiscal quarter and three fiscal quarters ended July 30, 2023, we repurchased and retired approximately 23 million and 90 million shares of our common stock for $1,707 million and $5,701 million, respectively.

[0001730168-24-000099:notes:119]
[same as prior period, unchanged from 0001730168-24-000080:notes:114]

[0001730168-24-000099:notes:120]
In connection with the VMware Merger, we assumed the VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan (the “2007 Plan”) and outstanding unvested RSU awards and PSU awards originally granted by VMware under the 2007 Plan that were held by continuing employees. These assumed awards were converted into approximately 46 million Broadcom RSU awards and will vest in accordance with their original terms, generally over 4 years. Under the 2007 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock, RSUs, and other stock-based or cash-based awards to employees. Equity awards granted under the 2007 Plan following the VMware Merger are expected to be on similar terms and consistent with similar grants made pursuant to our Amended and Restated Broadcom Inc. 2012 Stock Incentive Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of August 4, 2024, 59 million shares remained available for issuance under the 2007 Plan.

[0001730168-24-000099:notes:121]
[same as prior period, unchanged from 0001730168-24-000080:notes:116]

[0001730168-24-000099:notes:122]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 31 |  |  | $ | 25 |  |  | $ | 87 |  |  | $ | 63 |  |
| Cost of subscriptions and services |  | 143 |  |  | 36 |  |  | 418 |  |  | 85 |  |
| Research and development |  | 877 |  |  | 444 |  |  | 2,621 |  |  | 1,065 |  |
| Selling, general and administrative |  | 330 |  |  | 124 |  |  | 1,230 |  |  | 320 |  |
| Total stock-based compensation expense (a) |  | $ | 1,381 |  |  | $ | 629 |  |  | $ | 4,356 |  |  | $ | 1,533 |  |

[0001730168-24-000099:notes:123]
[same as prior period, unchanged from 0001730168-24-000080:notes:118]

[0001730168-24-000099:notes:124]
(a) Does not include $6 million and $142 million of stock-based compensation expense for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, which was included in loss from discontinued operations, net of income taxes in our condensed consolidated statements of operations.

[0001730168-24-000099:notes:125]
For the fiscal quarter and three fiscal quarters ended August 4, 2024, stock-based compensation expense included $285 million and $1,382 million, respectively, related to equity awards assumed in connection with the VMware Merger.

[0001730168-24-000099:notes:126]
As of August 4, 2024, the total unrecognized compensation cost related to unvested stock-based awards was $12,900 million, which is expected to be recognized over the remaining weighted-average service period of 3.2 years.

[0001730168-24-000099:notes:127]
[same as prior period, unchanged from 0001730168-24-000080:notes:122]

[0001730168-24-000099:notes:128]
[same as prior period, unchanged from 0001730168-24-000080:notes:123]

[0001730168-24-000099:notes:129]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 29, 2023 |  | 218 |  |  | $ | 38.92 |  |  |  |  |  |
| Assumed in VMware Merger |  | 46 |  |  | $ | 96.85 |  |  |  |  |  |
| Granted |  | 80 |  |  | $ | 114.99 |  |  |  |  |  |
| Vested |  | (84) |  |  | $ | 52.60 |  |  |  |  |  |
| Forfeited |  | (18) |  |  | $ | 84.87 |  |  |  |  |  |
| Balance as of August 4, 2024 |  | 242 |  |  | $ | 66.50 |  |  |  |  |  |

[0001730168-24-000099:notes:130]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended August 4, 2024 was $11,176 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-24-000099:notes:131]
Income Taxes
The provision for income taxes was $4,238 million and $4,190 million for the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, and $271 million and $572 million for the fiscal quarter and three fiscal quarters ended July 30, 2023, respectively. The increases in the provision for income taxes for the fiscal quarter and three fiscal quarters ended August 4, 2024, as compared to the prior year fiscal periods, were primarily due to the impact of an intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income. We recognized a discrete tax provision of $4,522 million during the fiscal quarter ended August 4, 2024 from the establishment of a deferred tax liability as a result of the book and tax basis difference on these transferred IP rights, partially offset by excess tax benefits from stock-based awards. 
As of August 4, 2024, we had $6,459 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $722 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations, and changes in balances related to tax positions to be taken during the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-24-000099:notes:132]
[same as prior period, unchanged from 0001730168-24-000080:notes:130]

[0001730168-24-000099:notes:133]
[same as prior period, unchanged from 0001730168-24-000080:notes:131]

[0001730168-24-000099:notes:134]
[same as prior period, unchanged from 0001730168-24-000080:notes:132]

[0001730168-24-000099:notes:135]
[same as prior period, unchanged from 0001730168-24-000080:notes:133]

[0001730168-24-000099:notes:136]
[same as prior period, unchanged from 0001730168-24-000080:notes:134]

[0001730168-24-000099:notes:137]
[same as prior period, unchanged from 0001730168-24-000080:notes:135]

[0001730168-24-000099:notes:138]
[same as prior period, unchanged from 0001730168-24-000080:notes:136]

[0001730168-24-000099:notes:139]
[same as prior period, unchanged from 0001730168-24-000080:notes:137]

[0001730168-24-000099:notes:140]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2024 |  | July 30,2023 |  | August 4,2024 |  | July 30,2023 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 7,274 |  |  | $ | 6,941 |  |  | $ | 21,866 |  |  | $ | 20,856 |  |
| Infrastructure software |  | 5,798 |  |  | 1,935 |  |  | 15,654 |  |  | 5,668 |  |
| Total net revenue |  | $ | 13,072 |  |  | $ | 8,876 |  |  | $ | 37,520 |  |  | $ | 26,524 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,042 |  |  | $ | 4,092 |  |  | $ | 12,136 |  |  | $ | 12,215 |  |
| Infrastructure software |  | 3,906 |  |  | 1,444 |  |  | 9,789 |  |  | 4,163 |  |
| Unallocated expenses |  | (4,160) |  |  | (1,680) |  |  | (13,089) |  |  | (4,411) |  |
| Total operating income |  | $ | 3,788 |  |  | $ | 3,856 |  |  | $ | 8,836 |  |  | $ | 11,967 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-24-000099:notes:141]
Commitments and Contingencies
Commitments

[0001730168-24-000099:notes:142]
The following table summarizes contractual obligations and commitments as of August 4, 2024:

[0001730168-24-000099:notes:143]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 22 |  |  | $ | 214 |  |
| 2025 |  | 271 |  |  | 413 |  |
| 2026 |  | 264 |  |  | 419 |  |
| 2027 |  | 7 |  |  | 350 |  |
| 2028 |  | 7 |  |  | 306 |  |
| Thereafter |  | — |  |  | 1,193 |  |
| Total |  | $ | 571 |  |  | $ | 2,895 |  |

[0001730168-24-000099:notes:144]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-24-000099:notes:145]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to information technology and other service agreements.

[0001730168-24-000099:notes:146]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 4, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest and penalties as of August 4, 2024 have been excluded from the table above.

[0001730168-24-000099:notes:147]
Contingencies

[0001730168-24-000099:notes:148]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-24-000099:notes:149]
Lawsuits Relating to VMware Backlog

[0001730168-24-000099:notes:150]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms pending approval by the California Court.

[0001730168-24-000099:notes:151]
Other Matters

[0001730168-24-000099:notes:152]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-24-000099:notes:153]
Contingency Assessment

[0001730168-24-000099:notes:154]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-24-000099:notes:155]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-24-000099:notes:156]
Other Indemnifications

[0001730168-24-000099:notes:157]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-24-000099:notes:158]
Restructuring and Other Charges
In connection with the VMware Merger, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized $361 million and $1,418 million of restructuring charges primarily related to employee termination costs during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses in continuing operations.

[0001730168-24-000099:notes:159]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended August 4, 2024:

[0001730168-24-000099:notes:160]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 29, 2023 |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Restructuring charges (a) |  | 1,270 |  |  | 148 |  |  | 1,418 |  |
| Utilization |  | (1,117) |  |  | (148) |  |  | (1,265) |  |
| Balance as of August 4, 2024 |  | $ | 155 |  |  | $ | — |  |  | $ | 155 |  |

[0001730168-24-000099:notes:161]
(a) Lease and impairment costs included the write-down of $82 million lease-related assets and $66 million of asset impairments and other costs.


## us-gaap:SubsequentEventsTextBlock

[0001730168-24-000099:notes:162]
Subsequent Events
Cash Dividends Declared

[0001730168-24-000099:notes:163]
On September 4, 2024, our Board of Directors declared a quarterly cash dividend of $0.53 per share on our common stock, payable on September 30, 2024 to stockholders of record on September 19, 2024.
