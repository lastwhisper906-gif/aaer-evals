# AVGO MD&A — 0001730168-24-000139


## mdna

[0001730168-24-000139:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-24-000139:mdna:2]
The following section generally discusses our financial condition and results of operations for our fiscal year ended November 3, 2024 (“fiscal year 2024”) compared to our fiscal year ended October 29, 2023 (“fiscal year 2023”). A discussion regarding our financial condition and results of operations for fiscal year 2023 compared to our fiscal year ended October 30, 2022 can be found in Part II, Item 7 of our Annual Report on Form 10-K for fiscal year 2023, filed with the Securities and Exchange Commission (the “SEC”) on December 14, 2023.

[0001730168-24-000139:mdna:3]
Overview

[0001730168-24-000139:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-24-000139:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our private and hybrid cloud, application development and delivery, software-defined edge, application networking and security, mainframe, distributed and cybersecurity solutions, and our FC SAN business.

[0001730168-24-000139:mdna:6]
Our fiscal year 2024 was a 53-week fiscal year compared to our fiscal year 2023, which was a 52-week fiscal year. The additional week in the first quarter of fiscal year 2024 resulted in higher net revenue, gross margin dollars, research and development expense, and selling general and administrative expense for fiscal year 2024, compared to the corresponding prior year fiscal period.

[0001730168-24-000139:mdna:7]
Our strategy is focused on technology leadership and category-leading semiconductor and infrastructure software solutions delivering a comprehensive suite of innovative infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through strategic acquisitions of businesses and technologies, as well as extensive internal research and development, to ensure our products retain their technology market leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-24-000139:mdna:8]
The demand for our products has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-24-000139:mdna:9]
•gain or loss of significant customers;

[0001730168-24-000139:mdna:10]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-24-000139:mdna:11]
•anticipated or actual demand for AI-related products;

[0001730168-24-000139:mdna:12]
•our distributors’ product inventory and end customer demand;

[0001730168-24-000139:mdna:13]
•the rate at which our present and future customers and end-users adopt our products and technologies in our target markets, including our AI related products, and the rate at which our customers' products that include our technology are accepted in their markets;

[0001730168-24-000139:mdna:14]
•the shift to cloud-based information technology solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our products for use in traditional enterprise data centers; and

[0001730168-24-000139:mdna:15]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-24-000139:mdna:16]
Fiscal Year Highlights

[0001730168-24-000139:mdna:17]
Highlights during fiscal year 2024 include the following:

[0001730168-24-000139:mdna:18]
•On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”), for approximately $30.8 billion in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53.4 billion.

[0001730168-24-000139:mdna:19]
•We generated $19,962 million of cash from operations.

[0001730168-24-000139:mdna:20]
•We paid $9,814 million in cash dividends.

[0001730168-24-000139:mdna:21]
•We repurchased $7,176 million of common stock.

[0001730168-24-000139:mdna:22]
•We completed a ten-for-one forward stock split of our common stock. All share, equity award and per share amounts have been retroactively adjusted to reflect the stock split.

[0001730168-24-000139:mdna:23]
Acquisitions and Divestitures

[0001730168-24-000139:mdna:24]
Acquisition of VMware and Divestiture of EUC

[0001730168-24-000139:mdna:25]
On November 22, 2023, we acquired VMware in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million. In addition, we assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding RSU awards held by non-employee directors and in-the-money VMware stock options were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000139:mdna:26]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 10. “Borrowings” included in Part II, Item 8 of this Annual Report on Form 10-K, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-24-000139:mdna:27]
On July 1, 2024, we sold VMware’s end-user computing (“EUC”) business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments.

[0001730168-24-000139:mdna:28]
Acquisition of Seagate’s SoC Operations

[0001730168-24-000139:mdna:29]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip (“SoC”) operations of Seagate Technology Holdings plc for $600 million.

[0001730168-24-000139:mdna:30]
Net Revenue

[0001730168-24-000139:mdna:31]
A majority of our net revenue is derived from sales of a broad range of semiconductor devices that are incorporated into electronic products, as well as from modules, switches and subsystems. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, deliver, automate, manage, and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms.

[0001730168-24-000139:mdna:32]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, have varied from quarter to quarter, due largely to fluctuations in end-market demand, including the effects of seasonality, which are discussed in detail in Part I, Item 1. Business under “Seasonality” of this Annual Report on Form 10-K.

[0001730168-24-000139:mdna:33]
Distributors and original equipment manufacturers (“OEMs”), or their contract manufacturers, typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive IP portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon the delivery of our products to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-24-000139:mdna:34]
37

[0001730168-24-000139:mdna:35]
Our software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. Our private cloud infrastructure suite of solutions are available directly from Broadcom, resellers and distributors, hyperscale cloud providers, value-added OEMs and VMware cloud service provider partners. VMware Cloud Foundation (“VCF”) provides license portability, which enables customers to purchase subscriptions of VCF software and move their VCF environments between on-premises data centers and supported cloud endpoints. We remain focused on strengthening relationships and increasing penetration within our existing core, mainframe, VMware, and Symantec endpoint customers and expanding the adoption of our enterprise software offerings with these customers. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-24-000139:mdna:36]
Costs and Expenses

[0001730168-24-000139:mdna:37]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense, related occupancy, computer services, equipment costs, manufacturing quality, order fulfillment, warranty adjustments, and inventory adjustments including write-downs for inventory obsolescence.

[0001730168-24-000139:mdna:38]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-24-000139:mdna:39]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-24-000139:mdna:40]
Total cost of revenue also includes amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-24-000139:mdna:41]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-24-000139:mdna:42]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs, which include direct transaction costs and integration costs, and other corporate expenses.

[0001730168-24-000139:mdna:43]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with our acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-24-000139:mdna:44]
Restructuring and other charges.  Restructuring and other charges consist primarily of non-recurring charges related to compensation costs associated with employee exit programs, IP litigation, alignment of our global manufacturing operations, rationalization of product development program costs, facility and lease abandonments, fixed asset impairment, IPR&D impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-24-000139:mdna:45]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-24-000139:mdna:46]
Other income (expense), net.  Other income (expense), net includes interest income, gains and losses on investments, foreign currency remeasurement, and other miscellaneous items.

[0001730168-24-000139:mdna:47]
Provision for income taxes.  We benefit from the tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are scheduled

[0001730168-24-000139:mdna:48]
to expire in November 2030. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday from our qualifying income earned in Malaysia, which is scheduled to expire in 2028.

[0001730168-24-000139:mdna:49]
Each tax incentive and tax holiday is subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday decreased the provision for income taxes by approximately $2,261 million and $2,104 million for fiscal years 2024 and 2023, respectively.

[0001730168-24-000139:mdna:50]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect, the benefits of the tax incentives may be adversely affected.

[0001730168-24-000139:mdna:51]
Critical Accounting Estimates

[0001730168-24-000139:mdna:52]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of goodwill and long-lived assets, and income taxes. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8 of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-24-000139:mdna:53]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-24-000139:mdna:54]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-24-000139:mdna:55]
Business combinations.  Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets include, the present value of projected cash flows regarding the projected revenues, projected expenses which include cost of revenue, research and development and selling, general and administrative expenses, technology obsolescence rate, contributory asset charges, discount rate and income tax rate for developed technology; the projected revenues, customer retention rate, customer ramp up period, discount rate and income tax rate for the customer contracts and related relationships; the projected revenues, technology obsolescence rate, expected costs to develop IPR&D into commercially viable products, discount rate and income tax rate for the IPR&D; and the projected revenues, brand asset phase-out pattern, brand asset royalty rate, discount rate and the income tax rate for the trade name. Unanticipated events and circumstances may occur which could affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-24-000139:mdna:56]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-24-000139:mdna:57]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance, including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting the financial multiples of comparable companies and applying a control premium. A reporting unit's carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-24-000139:mdna:58]
We assess the impairment of long-lived assets, including purchased IPR&D, property, plant and equipment, right-of-use assets, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment, and intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business to which the long-lived assets relate. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived assets stated on our consolidated balance sheets to reflect their estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-24-000139:mdna:59]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition.

[0001730168-24-000139:mdna:60]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax laws and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-24-000139:mdna:61]
40

[0001730168-24-000139:mdna:62]
Fiscal Year Presentation

[0001730168-24-000139:mdna:63]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year 2024 was a 53-week fiscal year. Fiscal years 2023 and 2022 each consisted of 52 weeks.

[0001730168-24-000139:mdna:64]
The financial statements included in Part II, Item 8 of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-24-000139:mdna:65]
41

[0001730168-24-000139:mdna:66]
Results of Operations

[0001730168-24-000139:mdna:67]
Fiscal Year 2024 Compared to Fiscal Year 2023

[0001730168-24-000139:mdna:68]
The following table sets forth our results of operations for the periods presented:

[0001730168-24-000139:mdna:69]
|  |  | Fiscal Year Ended |
|  |  | November 3,2024 |  | October 29,2023 |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 30,359 |  |  | $ | 27,891 |  |  | 59 | % |  | 78 | % |
| Subscriptions and services |  | 21,215 |  |  | 7,928 |  |  | 41 |  |  | 22 |  |
| Total net revenue |  | 51,574 |  |  | 35,819 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 9,797 |  |  | 8,636 |  |  | 19 |  |  | 24 |  |
| Cost of subscriptions and services |  | 2,991 |  |  | 636 |  |  | 6 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 6,023 |  |  | 1,853 |  |  | 12 |  |  | 5 |  |
| Restructuring charges |  | 254 |  |  | 4 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 19,065 |  |  | 11,129 |  |  | 37 |  |  | 31 |  |
| Gross margin |  | 32,509 |  |  | 24,690 |  |  | 63 |  |  | 69 |  |
| Research and development |  | 9,310 |  |  | 5,253 |  |  | 18 |  |  | 15 |  |
| Selling, general and administrative |  | 4,959 |  |  | 1,592 |  |  | 10 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 3,244 |  |  | 1,394 |  |  | 6 |  |  | 4 |  |
| Restructuring and other charges |  | 1,533 |  |  | 244 |  |  | 3 |  |  | 1 |  |
| Total operating expenses |  | 19,046 |  |  | 8,483 |  |  | 37 |  |  | 24 |  |
| Operating income |  | $ | 13,463 |  |  | $ | 16,207 |  |  | 26 | % |  | 45 | % |

[0001730168-24-000139:mdna:70]
Net Revenue

[0001730168-24-000139:mdna:71]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one customer, which is a distributor, accounted for 28% and 21% of our net revenue for fiscal years 2024 and 2023, respectively.

[0001730168-24-000139:mdna:72]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% and 35% of our net revenue for fiscal years 2024 and 2023, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-24-000139:mdna:73]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our products used in AI and wireless applications as fluctuations may be magnified by the timing of customer deployments and product launches, and seasonal variations in sales. In addition, the macroeconomic environment remains uncertain and may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-24-000139:mdna:74]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based primarily on the geographic shipment or delivery location specified by our distributors, OEMs, contract manufacturers, channel partners, or software customers. In fiscal years 2024 and 2023, 20% and 32%, respectively, of our net revenue came from shipments or deliveries to China (including Hong Kong). However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-24-000139:mdna:75]
42

[0001730168-24-000139:mdna:76]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-24-000139:mdna:77]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | November 3,2024 |  | October 29,2023 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 30,096 |  |  | $ | 28,182 |  |  | $ | 1,914 |  |  | 7 | % |
| Infrastructure software |  | 21,478 |  |  | 7,637 |  |  | 13,841 |  |  | 181 | % |
| Total net revenue |  | $ | 51,574 |  |  | $ | 35,819 |  |  | $ | 15,755 |  |  | 44 | % |

[0001730168-24-000139:mdna:78]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | November 3, 2024 |  | October 29, 2023 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 58 | % |  | 79 | % |
| Infrastructure software |  | 42 |  |  | 21 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-24-000139:mdna:79]
Net revenue from our semiconductor solutions segment increased due to strong product demand for our networking products, primarily AI networking products, partially offset by lower demand for our broadband and server storage products. Net revenue from our infrastructure software segment increased primarily due to contributions from VMware.

[0001730168-24-000139:mdna:80]
Gross Margin

[0001730168-24-000139:mdna:81]
Gross margin was $32,509 million for fiscal year 2024 compared to $24,690 million for fiscal year 2023. The increase was primarily due to contributions from VMware, partially offset by higher amortization of acquisition-related intangible assets from the VMware Merger.

[0001730168-24-000139:mdna:82]
As a percentage of net revenue, gross margin was 63% and 69% of net revenue for the fiscal years 2024 and 2023, respectively. The decrease was primarily due to higher amortization of acquisition-related intangible assets from the VMware Merger. In addition, gross margin contributions from our infrastructure software segment were partially offset by less favorable margin within the semiconductor solutions segment driven by product mix.

[0001730168-24-000139:mdna:83]
Research and Development Expense

[0001730168-24-000139:mdna:84]
Research and development expense increased $4,057 million, or 77%, in fiscal year 2024, compared to the prior fiscal year. The increase was primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increase in stock-based compensation expense was also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000139:mdna:85]
Selling, General and Administrative Expense

[0001730168-24-000139:mdna:86]
Selling, general and administrative expense increased $3,367 million, or 211%, in fiscal year 2024, compared to the prior fiscal year. The increase was primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increase in stock-based compensation expense was also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000139:mdna:87]
Amortization of Acquisition-Related Intangible Assets

[0001730168-24-000139:mdna:88]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $1,850 million, or 133%, in fiscal year 2024, compared to the prior fiscal year primarily due to higher amortization of customer-related intangible assets from the VMware Merger.

[0001730168-24-000139:mdna:89]
Restructuring and Other Charges

[0001730168-24-000139:mdna:90]
Restructuring and other charges recognized in operating expenses were $1,533 million and $244 million in fiscal years 2024 and 2023, respectively. The fiscal year 2024 charges primarily included employee termination costs from cost reduction activities related to the VMware Merger. The fiscal year 2023 charges primarily included non-recurring charges related to IP litigation.

[0001730168-24-000139:mdna:91]
Stock-Based Compensation Expense

[0001730168-24-000139:mdna:92]
Total stock-based compensation expense was $5,670 million and $2,171 million for fiscal years 2024 and 2023, respectively. The increase was primarily due to equity awards assumed and granted in connection with the VMware Merger and annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000139:mdna:93]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of November 3, 2024. The remaining weighted-average service period was 3.0 years.

[0001730168-24-000139:mdna:94]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2025 |  | $ | 4,429 |  |
| 2026 |  | 3,607 |  |
| 2027 |  | 2,643 |  |
| 2028 |  | 580 |  |
| Total |  | $ | 11,259 |  |

[0001730168-24-000139:mdna:95]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made on March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-24-000139:mdna:96]
Segment Operating Results

[0001730168-24-000139:mdna:97]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | November 3, 2024 |  | October 29, 2023 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 16,759 |  |  | $ | 16,486 |  |  | $ | 273 |  |  | 2 | % |
| Infrastructure software |  | 13,977 |  |  | 5,639 |  |  | 8,338 |  |  | 148 | % |
| Unallocated expenses |  | (17,273) |  |  | (5,918) |  |  | (11,355) |  |  | 192 | % |
| Total operating income |  | $ | 13,463 |  |  | $ | 16,207 |  |  | $ | (2,744) |  |  | (17) | % |

[0001730168-24-000139:mdna:98]
Operating income from our semiconductor solutions segment increased mainly driven by revenue growth from networking products, primarily AI networking products, partially offset by lower net revenue from our broadband and server storage products. Operating income from our infrastructure software segment increased primarily due to contributions from VMware.

[0001730168-24-000139:mdna:99]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 192% in fiscal year 2024, compared to the prior fiscal year, primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense and restructuring and other charges. These increases were primarily due to the VMware Merger. The increase in stock-based compensation expense was also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000139:mdna:100]
Non-Operating Income and Expenses

[0001730168-24-000139:mdna:101]
Interest expense.  Interest expense was $3,953 million and $1,622 million for fiscal years 2024 and 2023, respectively. The increase was primarily due to interest on debt incurred for the VMware Merger.

[0001730168-24-000139:mdna:102]
Other income (expense), net.  Other income (expense), net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $406 million and $512 million for fiscal years 2024 and 2023, respectively. The decrease was primarily due to lower interest income as a result of a lower invested balance.

[0001730168-24-000139:mdna:103]
44

[0001730168-24-000139:mdna:104]
Provision for income taxes.  The provision for income taxes was $3,748 million and $1,015 million for fiscal years 2024 and 2023, respectively. The increase was primarily due to the impact of a non-recurring intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in the jurisdictional mix of income.

[0001730168-24-000139:mdna:105]
Liquidity and Capital Resources

[0001730168-24-000139:mdna:106]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-24-000139:mdna:107]
Our primary sources of liquidity as of November 3, 2024 consisted of: (i) $9,348 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time.

[0001730168-24-000139:mdna:108]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $69,847 million of outstanding indebtedness, and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in the fiscal year ending November 2, 2025 as compared to fiscal year 2024. Our debt and liquidity needs increased in fiscal year 2024 as a result of completing the VMware Merger. We funded the cash portion of the consideration with net proceeds from the issuance of $30,390 million in term loans (the “2023 Term Loans”), as well as cash on hand. We also assumed $8,250 million of VMware’s outstanding senior unsecured notes. During fiscal year 2024, we made repayments of $16,795 million on our 2023 Term Loans.

[0001730168-24-000139:mdna:109]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations, indebtedness and lease obligations, see Note 14. “Commitments and Contingencies”, Note 10. “Borrowings” and Note 6. “Leases” in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-24-000139:mdna:110]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, the 2023 Term Loans and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-24-000139:mdna:111]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. We may also make additional prepayments of the 2023 Term Loans. The amounts involved may be material.

[0001730168-24-000139:mdna:112]
45

[0001730168-24-000139:mdna:113]
Working Capital

[0001730168-24-000139:mdna:114]
On November 22, 2023, we completed the VMware Merger. The following table presents the changes in selected balance sheet captions other than assets acquired and liabilities assumed from the VMware Merger during fiscal year 2024.

[0001730168-24-000139:mdna:115]
|  |  | Balances at October 29, 2023 |  | Balances Acquired and Assumed from VMware (a) |  | Balances at November 3, 2024 |  | Non-VMware Acquisition Change |
|  |  | (In millions) |
| Trade accounts receivable, net |  | $ | 3,154 |  |  | $ | 3,571 |  |  | $ | 4,416 |  |  | $ | (2,309) |  |
| Other current assets |  | $ | 1,606 |  |  | $ | 1,108 |  |  | $ | 4,071 |  |  | $ | 1,357 |  |
| Accounts payable |  | $ | 1,210 |  |  | $ | 359 |  |  | $ | 1,662 |  |  | $ | 93 |  |
| Employee compensation and benefits |  | $ | 935 |  |  | $ | 848 |  |  | $ | 1,971 |  |  | $ | 188 |  |
| Current portion of long-term debt |  | $ | 1,608 |  |  | $ | 1,264 |  |  | $ | 1,271 |  |  | $ | (1,601) |  |
| Other current liabilities |  | $ | 3,652 |  |  | $ | 11,217 |  |  | $ | 11,793 |  |  | $ | (3,076) |  |

[0001730168-24-000139:mdna:116]
_____________________________

[0001730168-24-000139:mdna:117]
(a)Excludes VMware’s EUC assets and liabilities held for sale.

[0001730168-24-000139:mdna:118]
•Trade accounts receivable, net decreased primarily due to strong collections and additional receivables sold through factoring arrangements.

[0001730168-24-000139:mdna:119]
•Other current assets increased from higher contract assets due to the timing of software revenue recognition.

[0001730168-24-000139:mdna:120]
•Current portion of long-term debt decreased primarily due to $2,813 million of repayments, offset in part by $1,245 million becoming due within the next twelve months.

[0001730168-24-000139:mdna:121]
•Other current liabilities decreased primarily from lower contract liabilities as software revenue was recognized from previous software contracts.

[0001730168-24-000139:mdna:122]
Capital Returns

[0001730168-24-000139:mdna:123]
|  |  | Fiscal Year Ended |
| Cash Dividends Declared and Paid |  | November 3, 2024 |  | October 29, 2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 2.105 |  |  | $ | 1.840 |  |
| Dividends to common stockholders |  | $ | 9,814 |  |  | $ | 7,645 |  |

[0001730168-24-000139:mdna:124]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2022, which was subsequently extended to December 31, 2023. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023. During fiscal years 2024 and 2023, we repurchased and retired approximately 67 million and 91 million shares of our common stock for $7,176 million and $5,824 million, respectively. All $20 billion of the authorized amount under these stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000139:mdna:125]
During fiscal years 2024 and 2023, we paid approximately $5,216 million and $1,861 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 38 million and 26 million shares of common stock from employees in connection with such net share settlements during fiscal years 2024 and 2023, respectively.

[0001730168-24-000139:mdna:126]
Cash Flows

[0001730168-24-000139:mdna:127]
|  |  | Fiscal Year Ended |
|  |  | November 3, 2024 |  | October 29, 2023 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 19,962 |  |  | $ | 18,085 |  |
| Net cash used in investing activities |  | (23,070) |  |  | (689) |  |
| Net cash used in financing activities |  | (1,733) |  |  | (15,623) |  |
| Net change in cash and cash equivalents |  | $ | (4,841) |  |  | $ | 1,773 |  |

[0001730168-24-000139:mdna:128]
Operating Activities

[0001730168-24-000139:mdna:129]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,877 million increase in cash provided by operations during fiscal year 2024 compared to fiscal year 2023 was primarily due to contributions from VMware. The $8,187 million decrease in net income was largely driven by $13,058 million higher non-cash adjustments including amortization of intangible assets, stock-based compensation, and deferred taxes and other non-cash taxes related to the VMware Merger.

[0001730168-24-000139:mdna:130]
Investing Activities

[0001730168-24-000139:mdna:131]
Cash flows from investing activities primarily consisted of cash used for acquisitions, proceeds from the sale of a business, capital expenditures, and proceeds and payments related to investments. The $22,381 million increase in cash used in investing activities for fiscal year 2024 compared to fiscal year 2023 was primarily due to a $25,925 million increase in cash used for acquisitions due to the VMware Merger and the acquisition of Seagate’s SoC operations, net of cash acquired, offset in part by $3,485 million proceeds from the sale of the EUC business.

[0001730168-24-000139:mdna:132]
Financing Activities

[0001730168-24-000139:mdna:133]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, dividend payments, stock repurchases, and employee withholding tax payments related to net settled equity awards. The $13,890 million increase in cash flows from financing activities for fiscal year 2024 compared to fiscal year 2023 was primarily due to $39,954 million of net proceeds from the 2023 Term Loans and the issuance of senior notes, offset in part by a $19,205 million increase in payments on debt obligations, a $3,355 million increase in employee withholding tax payments related to net settled equity awards, a $2,169 million increase in dividend payments, and a $1,352 million increase in stock repurchases.
