# AVGO notes — 0001730168-24-000139


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001730168-24-000139:notes:1]
Portions of the registrant’s definitive proxy statement for its 2025 annual meeting of stockholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. The registrant’s definitive proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-24-000139:notes:2]
Overview and Basis of Presentation 
Overview

[0001730168-24-000139:notes:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We offer thousands of products that are used in end products such as enterprise and data center networking, including artificial intelligence (“AI”) networking and connectivity, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software. See Note 13. “Segment Information” for additional information.

[0001730168-24-000139:notes:4]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The accompanying consolidated financial statements include the results of operations of VMware commencing on November 22, 2023. See Note 4. “Acquisitions” for additional information.

[0001730168-24-000139:notes:5]
Basis of Presentation

[0001730168-24-000139:notes:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year ended November 3, 2024 (“fiscal year 2024”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks. Our fiscal year ended October 29, 2023 (“fiscal year 2023”) and fiscal year ended October 30, 2022 (“fiscal year 2022”) were both 52-week fiscal years.

[0001730168-24-000139:notes:7]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany balances and transactions have been eliminated in consolidation.

[0001730168-24-000139:notes:8]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock through the filing of an amendment (“Amendment”) to our Amended and Restated Certificate of Incorporation. The Amendment proportionately increased the number of shares of our authorized common stock without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented in the accompanying consolidated financial statements and notes thereto have been retroactively adjusted, where applicable, to reflect the stock split.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-24-000139:notes:9]
Summary of Significant Accounting Policies 
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. Foreign currency assets and liabilities for monetary accounts are remeasured into U.S. dollars at current exchange rates. Non-monetary items such as inventory and property, plant and equipment, are measured and recorded at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.

[0001730168-24-000139:notes:10]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.

[0001730168-24-000139:notes:11]
Cash and cash equivalents.  We consider all highly liquid investment securities with original maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.

[0001730168-24-000139:notes:12]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the expected credit losses in our existing accounts receivable. We determine the allowance based on historical experience and current economic conditions, among other factors. Allowances for doubtful accounts were not material as of November 3, 2024 or October 29, 2023. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances as of November 3, 2024 and October 29, 2023 were $101 million and $137 million, respectively.

[0001730168-24-000139:notes:13]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-24-000139:notes:14]
Concentration of other risks.  We operate in markets that are highly competitive and rapidly changing. Significant technological changes, shifting customer needs, the emergence of competitive products with new capabilities, general economic conditions worldwide, the ability to safeguard patents and other intellectual property (“IP”) in a rapidly evolving market and reliance on third-party wafer fabricators, assembly and test subcontractors and independent distributors and other factors could affect our financial results.

[0001730168-24-000139:notes:15]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.

[0001730168-24-000139:notes:16]
Retirement benefit plans. For defined benefit pension plans, we consider various factors in determining our respective benefit obligations and net periodic benefit cost, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-24-000139:notes:17]
The key assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on a hypothetical yield curve constructed using high-quality corporate bonds selected to yield cash flows that match the expected timing and amount of the benefit payments. The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy. We evaluate these assumptions at least annually. For the non-U.S. plans, we set assumptions specific to each country. We have elected to measure defined benefit pension plan assets and liabilities as of October 31, which is the month end that is closest to our fiscal year end.

[0001730168-24-000139:notes:18]
Derivative instruments.  We use derivative financial instruments to manage exposure to foreign exchange risk and interest rate risk. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-24-000139:notes:19]
Outstanding derivatives are recognized as assets or liabilities at their fair values based on Level 2 inputs, as defined in the fair value hierarchy. For derivative instruments designated as cash flow hedges, the changes in fair value are initially recognized in other comprehensive income, net of tax in the period of change, and are subsequently reclassified and recognized in the same line item as the hedged item when either the hedged transactions affect earnings or it becomes probable that the hedged transactions will not occur.

[0001730168-24-000139:notes:20]
We use foreign exchange forward contracts to manage exposure to foreign exchange risk. These forward contracts are not designated as hedging instruments, and the changes in fair value are recognized in other income (expense), net in the period of change. We did not have any material foreign exchange forward contracts outstanding as of November 3, 2024 or October 29, 2023. The gains and losses recorded in other income (expense), net for derivative instruments not designated as hedges were not material.

[0001730168-24-000139:notes:21]
During fiscal years 2023 and 2022, we entered into treasury rate lock contracts that mature in approximately one year to hedge variability of cash flows due to changes in the benchmark interest rate of anticipated future debt issuances. These treasury rate locks were designated and accounted for as cash flow hedging instruments. In August 2023, we early settled all treasury rate lock contracts, which had a $5.5 billion notional amount, for a cumulative gain of $371 million. The cumulative gain was recorded net of tax of $44 million as a component of accumulated other comprehensive income as of October 29, 2023. The cash receipts from the settlement were included in cash flows from operating activities in the consolidated statement of cash flows during fiscal year 2023. In fiscal year 2024, upon the issuance of our $1.75 billion 4.800% senior notes due October 2034 as discussed in Note 10. “Borrowings”, $75 million out of the $371 million pre-tax cumulative gain in accumulated other comprehensive income will be amortized to interest expense through October 15, 2034 using the effective interest method. The remaining cumulative gain will be amortized to interest expense associated with future debt referencing the hedged treasury rates.

[0001730168-24-000139:notes:22]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years, or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over 3 to 10 years. We use the straight-line method of depreciation for all property, plant and equipment.

[0001730168-24-000139:notes:23]
Leases.  We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize right-of-use (“ROU”) assets and lease liabilities for operating and finance leases with terms greater than 12 months, and account for the lease and non-lease components as a single component. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0001730168-24-000139:notes:24]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three-level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-24-000139:notes:25]
The three levels of the fair value hierarchy under the guidance on fair value measurements are described below:

[0001730168-24-000139:notes:26]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date. Our Level 1 assets include cash equivalents, banker's acceptances, trading securities investments and investment funds. We measure trading securities investments and investment funds at quoted market prices as they are traded in active markets with sufficient volume and frequency of transactions.

[0001730168-24-000139:notes:27]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-24-000139:notes:28]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Level 3 assets and liabilities include investment in equity securities without readily determinable fair values, goodwill, intangible assets, and property, plant and equipment, which are measured at fair value using a discounted cash flow approach when they are impaired. Quantitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.

[0001730168-24-000139:notes:29]
Business combinations.  We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition date fair

[0001730168-24-000139:notes:30]
values, except for revenue contracts acquired, which are recognized in accordance with our revenue recognition policy. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets include the present value of projected cash flows regarding the projected revenues, projected expenses which include cost of revenue, research and development and selling, general and administrative expenses, technology obsolescence rate, contributory asset charges, discount rate and income tax rate for developed technology; the projected revenues, customer retention rate, customer ramp up period, discount rate and income tax rate for the customer contracts and related relationships; the projected revenues, technology obsolescence rate, expected costs to develop in-process research and development (“IPR&D”) into commercially viable products, discount rate and income tax rate for the IPR&D; and the projected revenues, brand asset phase-out pattern, brand asset royalty rate, discount rate and the income tax rate for the trade name. Unanticipated events and circumstances may occur which could affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-24-000139:notes:31]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-24-000139:notes:32]
Long-lived assets.  Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets, ROU assets, and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.

[0001730168-24-000139:notes:33]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the product requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-24-000139:notes:34]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-24-000139:notes:35]
Payment terms and conditions vary by contract type, and terms between invoicing and when payment is due are short-term in duration. The timing of revenue recognition and required payments can differ and payment terms are generally structured to provide the customer with predictable and dependable ways to procure our products, not to provide or receive financing from the customer.

[0001730168-24-000139:notes:36]
Nature of Products and Services

[0001730168-24-000139:notes:37]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-24-000139:notes:38]
Products.  We recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product. From time to time, certain customers agree to pay us secure supply fees in exchange for prioritized fulfillment of product orders. Such fees are included in the transaction price of the product orders and are recognized as revenue in the period that control over the products is transferred to the customer.

[0001730168-24-000139:notes:39]
Subscriptions and services.  Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

[0001730168-24-000139:notes:40]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-24-000139:notes:41]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Certain of our subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in ratable revenue recognition of software revenue over the contractual period.

[0001730168-24-000139:notes:42]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-24-000139:notes:43]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-24-000139:notes:44]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-24-000139:notes:45]
There are two main categories of NRE contracts that we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost as the services are provided. For NRE contracts that do not meet the over time criteria, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-24-000139:notes:46]
Material rights.  Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-24-000139:notes:47]
Arrangements with Multiple Performance Obligations

[0001730168-24-000139:notes:48]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-24-000139:notes:49]
Allocation of consideration.  We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-24-000139:notes:50]
Standalone selling price.  When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. When directly observable transactions are not available, our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, reasonably available data points such as costs incurred to provide the good or service, market conditions, entity-specific factors such as pricing strategies and objectives, and information about the customer.

[0001730168-24-000139:notes:51]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-24-000139:notes:52]
We also estimate the standalone selling price of our material rights. We estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-24-000139:notes:53]
Other Policies and Judgments

[0001730168-24-000139:notes:54]
Contract modifications.  We may modify contracts to offer customers additional products or services. Each of the additional products and services is generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or a combination of both based on the nature of the modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-24-000139:notes:55]
Right of return.  Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-24-000139:notes:56]
Practical expedient elected.  We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

[0001730168-24-000139:notes:57]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-24-000139:notes:58]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units (“RSUs”) using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for time-based stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”) based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-24-000139:notes:59]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-24-000139:notes:60]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-24-000139:notes:61]
Shipping and handling costs.  Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in cost of revenue for all periods presented.

[0001730168-24-000139:notes:62]
Litigation and settlement costs.  We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.

[0001730168-24-000139:notes:63]
Income taxes.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-24-000139:notes:64]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes or increase the benefit from income taxes. Likewise, if we determine that we are not able to realize all or part of our net deferred tax assets, we increase the provision for income taxes or decrease the benefit from income taxes in the period such determination is made.

[0001730168-24-000139:notes:65]
The U.S. Tax Cuts and Jobs Act enacted on December 22, 2017 (the “2017 Tax Act”) introduced significant changes to U.S. income tax law. The Global Intangible Low-Taxed Income (“GILTI”) provisions of the 2017 Tax Act require Broadcom to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. We have elected to record the impacts of GILTI during the period incurred.

[0001730168-24-000139:notes:66]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.

[0001730168-24-000139:notes:67]
Net income per share.  Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and ESPP rights (together referred to as “equity awards”), as well as convertible preferred stock. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-24-000139:notes:68]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for purchasing shares under the ESPP and the amount of compensation expense for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of convertible preferred stock is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-24-000139:notes:69]
Revenue from Contracts with Customers 
Disaggregation

[0001730168-24-000139:notes:70]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 13. “Segment Information.”

[0001730168-24-000139:notes:71]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

[0001730168-24-000139:notes:72]
|  |  | Fiscal Year 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,244 |  |  | $ | 26,219 |  |  | $ | 1,896 |  |  | $ | 30,359 |  |
| Subscriptions and services |  | 12,726 |  |  | 2,203 |  |  | 6,286 |  |  | 21,215 |  |
| Total |  | $ | 14,970 |  |  | $ | 28,422 |  |  | $ | 8,182 |  |  | $ | 51,574 |  |

[0001730168-24-000139:notes:73]
|  |  | Fiscal Year 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,601 |  |  | $ | 23,263 |  |  | $ | 2,027 |  |  | $ | 27,891 |  |
| Subscriptions and services |  | 5,678 |  |  | 657 |  |  | 1,593 |  |  | 7,928 |  |
| Total |  | $ | 8,279 |  |  | $ | 23,920 |  |  | $ | 3,620 |  |  | $ | 35,819 |  |

[0001730168-24-000139:notes:74]
|  |  | Fiscal Year 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,371 |  |  | $ | 21,761 |  |  | $ | 2,145 |  |  | $ | 26,277 |  |
| Subscriptions and services |  | 4,573 |  |  | 744 |  |  | 1,609 |  |  | 6,926 |  |
| Total |  | $ | 6,944 |  |  | $ | 22,505 |  |  | $ | 3,754 |  |  | $ | 33,203 |  |

[0001730168-24-000139:notes:75]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer (“OEM”) customers, contract manufacturers, channel partners, or software customers.

[0001730168-24-000139:notes:76]
Contract Balances

[0001730168-24-000139:notes:77]
Contract assets and contract liabilities balances were as follows:

[0001730168-24-000139:notes:78]
|  |  | November 3,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 4,402 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 14,495 |  |  | $ | 2,786 |  |

[0001730168-24-000139:notes:79]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of November 3, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of November 3, 2024, approximately 55% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during fiscal year 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,440 million. The amount of revenue recognized during fiscal year 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,915 million.

[0001730168-24-000139:notes:80]
Remaining Performance Obligations

[0001730168-24-000139:notes:81]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of IP.

[0001730168-24-000139:notes:82]
Certain multi-year customer contracts in our semiconductor solutions and infrastructure software segments contain firmly committed amounts and the remaining performance obligations under these contracts as of November 3, 2024 were approximately $20.5 billion. We expect approximately 43% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our revenue is from contracts with a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-24-000139:notes:83]
Acquisitions 
Acquisition of VMware, Inc.

[0001730168-24-000139:notes:84]
On November 22, 2023, we completed the VMware Merger. Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash or 2.52 shares of Broadcom common stock (on a split adjusted basis). The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the VMware Merger. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock with a fair value of $53,398 million.

[0001730168-24-000139:notes:85]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 10. “Borrowings”, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-24-000139:notes:86]
Purchase Consideration

[0001730168-24-000139:notes:87]
|  |  | (In millions) |
| Fair value of Broadcom common stock issued for outstanding VMware common stock |  | $ | 53,398 |  |
| Cash paid for outstanding VMware common stock |  | 30,788 |  |
| Cash paid by Broadcom to retire VMware’s term loan |  | 1,257 |  |
| Fair value of partially vested assumed VMware equity awards |  | 805 |  |
| Fair value of Broadcom common stock issued for accelerated VMware equity awards |  | 23 |  |
| Cash paid for accelerated VMware equity awards |  | 13 |  |
| Effective settlement of pre-existing relationships |  | 6 |  |
| Total purchase consideration |  | 86,290 |  |
| Less: cash acquired |  | 6,642 |  |
| Total purchase consideration, net of cash acquired |  | $ | 79,648 |  |

[0001730168-24-000139:notes:88]
We assumed all outstanding VMware RSU awards and performance stock unit (“PSU”) awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000139:notes:89]
The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-24-000139:notes:90]
|  |  | Fair Value |
|  |  | (In millions) |
| Trade accounts receivable |  | $ | 3,571 |  |
| Inventory |  | 15 |  |
| Assets held-for-sale |  | 5,206 |  |
| Other current assets |  | 757 |  |
| Property, plant and equipment |  | 531 |  |
| Goodwill |  | 54,206 |  |
| Intangible assets |  | 45,572 |  |
| Other long-term assets |  | 1,064 |  |
| Total assets acquired |  | 110,922 |  |
| Accounts payable |  | (359) |  |
| Employee compensation and benefits |  | (848) |  |
| Current portion of long-term debt |  | (1,264) |  |
| Liabilities held-for-sale |  | (1,901) |  |
| Other current liabilities |  | (11,041) |  |
| Long-term debt |  | (6,254) |  |
| Other long-term liabilities |  | (9,607) |  |
| Total liabilities assumed |  | (31,274) |  |
| Fair value of net assets acquired |  | $ | 79,648 |  |

[0001730168-24-000139:notes:91]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the VMware business. The synergies include certain cost savings, operating efficiencies and other strategic benefits projected to be achieved as a result of the VMware Merger. Goodwill is not deductible for tax purposes.

[0001730168-24-000139:notes:92]
Assets and liabilities held-for-sale primarily included the end-user computing (“EUC”) business and certain other assets and liabilities, which were not aligned with our strategic objectives. On July 1, 2024, we sold the EUC business to KKR & Co. Inc. for cash consideration of $3.5 billion, after working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-24-000139:notes:93]
Our results of continuing operations included $12,384 million of net revenue attributable to VMware for fiscal year 2024. It is impracticable to determine the effect on net income attributable to VMware as we immediately integrated VMware into our ongoing operations. Transaction costs related to the VMware Merger of $255 million were primarily included in selling, general and administrative expense for fiscal year 2024.

[0001730168-24-000139:notes:94]
Intangible Assets

[0001730168-24-000139:notes:95]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 24,156 |  |  | 8 |
| Customer contracts and related relationships |  | 15,239 |  |  | 8 |
| Trade name |  | 1,205 |  |  | 14 |
| Off-market component of customer contracts |  | 242 |  |  | 2 |
| Total identified finite-lived intangible assets |  | 40,842 |  |  |  |
| IPR&D |  | 4,730 |  |  | N/A |
| Total identified intangible assets |  | $ | 45,572 |  |  |  |

[0001730168-24-000139:notes:96]
Developed technology relates to products used for VMware cloud foundation, application management, security, application networking and security, and software-defined edge. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-24-000139:notes:97]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of VMware. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-24-000139:notes:98]
Trade name relates to the “VMware” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-24-000139:notes:99]
Off-market component of customer contracts relate to rebates and marketing development funds provided to customers prior to the VMware Merger. We valued these contracts based on their remaining unamortized balances, which approximate their fair value. The economic useful life was determined based on the remaining terms of customer contracts.

[0001730168-24-000139:notes:100]
The fair value of IPR&D was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-24-000139:notes:101]
The following table presents the details of IPR&D by category as of the date of the VMware Merger:

[0001730168-24-000139:notes:102]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |  |
|  |  | (Dollars in millions) |  |
| VMware cloud foundation July 2024 releases |  | $ | 790 |  |  | 67 | % |  | $ | 38 |  |  | 2024 | (a) |
| VMware cloud foundation March 2025 releases |  | $ | 2,900 |  |  | 58 | % |  | $ | 185 |  |  | 2025 | (b) |
| VMware cloud foundation July 2025 releases |  | $ | 750 |  |  | 43 | % |  | $ | 65 |  |  | 2025 | (c) |
| VMware cloud foundation networking and security virtualization |  | $ | 265 |  |  | 21 | % |  | $ | 59 |  |  | 2024 | (a) |
| Application networking and security |  | $ | 25 |  |  | 21 | % |  | $ | 47 |  |  | 2024 | (a) |

[0001730168-24-000139:notes:103]
____________________________

[0001730168-24-000139:notes:104]
(a) Released during fiscal year 2024.

[0001730168-24-000139:notes:105]
(b) $1,380 million of the $2,900 million was released during fiscal year 2024. The remaining balance is expected to be released during the second half of the fiscal year ending November 2, 2025 (“fiscal year 2025”).

[0001730168-24-000139:notes:106]
(c) Expected to be released during the first half of the fiscal year ending November 1, 2026.

[0001730168-24-000139:notes:107]
VMware cloud foundation is a private cloud platform that integrates compute, storage, networking, and management into a single solution and provides license portability. It enables customers to modernize infrastructure and accelerate developer productivity with greater resilience and security.

[0001730168-24-000139:notes:108]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the date of the VMware Merger.

[0001730168-24-000139:notes:109]
Unaudited Pro Forma Information

[0001730168-24-000139:notes:110]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if VMware had been acquired as of the beginning of fiscal year 2023. The unaudited pro forma information includes adjustments to amortization for intangible assets acquired, stock-based compensation expense, interest expense for acquisition financing, amortization of deferred assets and liabilities, and depreciation for property and equipment acquired. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2023 or of the results of our future operations of the combined business.

[0001730168-24-000139:notes:111]
|  |  |  | Fiscal Year |
|  |  |  | 2024 |  | 2023 |
|  |  | (In millions) |
| Pro forma net revenue |  |  | $ | 52,188 |  |  | $ | 48,227 |  |
| Pro forma net income |  |  | $ | 6,473 |  |  | $ | 8,215 |  |

[0001730168-24-000139:notes:112]
Acquisition of Seagate’s SoC Operations

[0001730168-24-000139:notes:113]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip (“SoC”) operations of Seagate Technology Holdings plc for $600 million. We acquired these assets to strengthen our portfolio of SoC products.

[0001730168-24-000139:notes:114]
The following table presents our allocation of the total purchase price. Goodwill is allocated to the semiconductor solutions segment and is deductible for tax purposes.

[0001730168-24-000139:notes:115]
|  |  | Fair Value |
|  |  | (In millions) |
| Intangible assets |  | $ | 570 |  |
| Goodwill |  | 14 |  |
| Other assets |  | 16 |
| Total assets acquired |  | $ | 600 |  |

[0001730168-24-000139:notes:116]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Customer contracts and related relationships |  | $ | 410 |  |  | 11 |
| Developed technology |  | 90 |  |  | 11 |
| Total identified finite-lived intangible assets |  | 500 |  |  |  |
| IPR&D |  | 70 |  |  | N/A |
| Total identified intangible assets |  | $ | 570 |  |  |  |

[0001730168-24-000139:notes:117]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of SoC controller products for hard disk drive applications. Customer contracts and related relationships were valued using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and related relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the useful lives of other intangible assets and the length of time remaining on the acquired contracts.

[0001730168-24-000139:notes:118]
Developed technology relates to SoC controller products for hard disk drive applications. We valued the developed technology using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the developed technology. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.
The fair value of IPR&D was determined using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue from the IPR&D.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-24-000139:notes:119]
Supplemental Financial Information 
Cash Equivalents

[0001730168-24-000139:notes:120]
Cash equivalents included $1,716 million and $1,470 million of time deposits and $1,171 million and $1,650 million of money-market funds as of November 3, 2024 and October 29, 2023, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-24-000139:notes:121]
Accounts Receivable Factoring

[0001730168-24-000139:notes:122]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $5,900 million, $3,975 million and $3,700 million during fiscal years 2024, 2023 and 2022, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the

[0001730168-24-000139:notes:123]
periods presented.

[0001730168-24-000139:notes:124]
Inventory

[0001730168-24-000139:notes:125]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Finished goods |  | $ | 504 |  |  | $ | 676 |  |
| Work-in-process |  | 970 |  |  | 901 |  |
| Raw materials |  | 286 |  |  | 321 |  |
| Total inventory |  | $ | 1,760 |  |  | $ | 1,898 |  |

[0001730168-24-000139:notes:126]
Property, Plant and Equipment, Net

[0001730168-24-000139:notes:127]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Land |  | $ | 204 |  |  | $ | 195 |  |
| Construction in progress |  | 57 |  |  | 63 |  |
| Buildings and leasehold improvements |  | 1,518 |  |  | 1,181 |  |
| Machinery and equipment |  | 5,246 |  |  | 4,739 |  |
| Total property, plant and equipment |  | 7,025 |  |  | 6,178 |  |
| Accumulated depreciation and amortization |  | (4,504) |  |  | (4,024) |  |
| Total property, plant and equipment, net |  | $ | 2,521 |  |  | $ | 2,154 |  |

[0001730168-24-000139:notes:128]
Depreciation expense was $593 million, $502 million and $529 million for fiscal years 2024, 2023 and 2022, respectively.

[0001730168-24-000139:notes:129]
Other Current Assets

[0001730168-24-000139:notes:130]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 1,916 |  |  | $ | 499 |  |
| Prepaid expenses |  | 1,391 |  |  | 743 |  |
| Other |  | 764 |  |  | 364 |  |
| Total other current assets |  | $ | 4,071 |  |  | $ | 1,606 |  |

[0001730168-24-000139:notes:131]
Other Current Liabilities

[0001730168-24-000139:notes:132]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,395 |  |  | $ | 2,487 |  |
| Tax liabilities |  | 720 |  |  | 473 |  |
| Interest payable |  | 535 |  |  | 380 |  |
| Other |  | 1,143 |  |  | 312 |  |
| Total other current liabilities |  | $ | 11,793 |  |  | $ | 3,652 |  |

[0001730168-24-000139:notes:133]
Other Long-Term Liabilities

[0001730168-24-000139:notes:134]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 5,100 |  |  | $ | 299 |  |
| Deferred tax liabilities |  | 4,703 |  |  | 99 |  |
| Unrecognized tax benefits, interest and penalties |  | 3,669 |  |  | 2,792 |  |
| Other |  | 1,503 |  |  | 657 |  |
| Total other long-term liabilities |  | $ | 14,975 |  |  | $ | 3,847 |  |

[0001730168-24-000139:notes:135]
Other Income (Expense), Net

[0001730168-24-000139:notes:136]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Interest income |  | $ | 461 |  |  | $ | 535 |  |  | $ | 100 |  |
| Other income |  | 21 |  |  | 15 |  |  | 30 |  |
| Gain (loss) on investments |  | (12) |  |  | 11 |  |  | (169) |  |
| Other expense |  | (64) |  |  | (49) |  |  | (15) |  |
| Other income (expense), net |  | $ | 406 |  |  | $ | 512 |  |  | $ | (54) |  |

[0001730168-24-000139:notes:137]
Other income and other expense include foreign exchange gains and losses, factoring fees for the sales of receivables, and other miscellaneous items.

[0001730168-24-000139:notes:138]
Discontinued Operations

[0001730168-24-000139:notes:139]
During fiscal year 2024, we sold the EUC business for $3.5 billion, after working capital adjustments. In connection with the sale, we agreed to provide transitional services to the buyer on a short-term basis. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-24-000139:notes:140]
The following table summarizes the selected financial information of discontinued operations:

[0001730168-24-000139:notes:141]
|  |  |  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |
|  |  |  | 2024 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | (In millions) |
| Net revenue |  |  |  |  |  | $ | 858 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations before income taxes |  |  |  |  |  | $ | (12) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  |  |  |  |  | (261) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss from discontinued operations, net of income taxes |  |  |  |  |  | $ | (273) |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001730168-24-000139:notes:142]
Leases
We have operating and finance leases for our facilities, land, data centers and certain equipment. Operating lease expense was $187 million, $91 million and $98 million for fiscal years 2024, 2023 and 2022, respectively. Finance lease expense was $27 million, $16 million and $18 million for fiscal years 2024, 2023 and 2022, respectively.

[0001730168-24-000139:notes:143]
Other lease information, which included the impact of VMware leases acquired on November 22, 2023, was as follows.

[0001730168-24-000139:notes:144]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Cash paid for operating leases included in operating cash flows |  | $ | 223 |  |  | $ | 90 |  |  | $ | 103 |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 1,165 |  |  | $ | 28 |  |  | $ | 16 |  |
| ROU assets obtained in exchange for finance lease liabilities |  | $ | 49 |  |  | $ | — |  |  | $ | 1 |  |
|  |  | November 3,2024 |  | October 29,2023 |  |  |
| Weighted-average remaining lease term – operating leases (In years) |  | 11 |  | 10 |  |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 2 |  | 2 |  |  |
| Weighted-average discount rate – operating leases |  | 5.31 |  | % | 3.90 |  | % |  |
| Weighted-average discount rate – finance leases |  | 3.13 |  | % | 3.09 |  | % |  |

[0001730168-24-000139:notes:145]
Supplemental balance sheet information related to leases, which included the VMware leases acquired on November 22, 2023, was as follows:

[0001730168-24-000139:notes:146]
|  |  | Classification on the Consolidated Balance Sheets |  | November 3,2024 |  | October 29,2023 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  | $ | 1,325 |  |  | $ | 463 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  | $ | 15 |  |  | $ | 22 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  | $ | 207 |  |  | $ | 60 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 1,143 |  |  | $ | 359 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  | $ | 26 |  |  | $ | 45 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 13 |  |  | $ | 4 |  |

[0001730168-24-000139:notes:147]
Future minimum lease payments under non-cancelable leases as of November 3, 2024 were as follows:

[0001730168-24-000139:notes:148]
|  |  | November 3,2024 |
|  |  | Operating Leases |  | Finance Leases |
|  |  | (In millions) |
| 2025 |  | $ | 268 |  |  | $ | 26 |  |
| 2026 |  | 194 |  |  | 8 |  |
| 2027 |  | 171 |  |  | 3 |  |
| 2028 |  | 144 |  |  | 2 |  |
| 2029 |  | 124 |  |  | 2 |  |
| Thereafter |  | 894 |  |  | — |  |
| Total undiscounted liabilities |  | 1,795 |  |  | 41 |  |
| Less: interest |  | (445) |  |  | (2) |  |
| Present value of lease liabilities |  | $ | 1,350 |  |  | $ | 39 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-24-000139:notes:149]
Goodwill and Intangible Assets 
Goodwill

[0001730168-24-000139:notes:150]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  |  |  |  |  |  |  |  |  | (In millions) |
| Balance as of October 30, 2022 |  |  |  |  |  |  |  |  |  | $ | 25,967 |  |  | $ | 17,647 |  |  | $ | 43,614 |  |
| Acquisitions |  |  |  |  |  |  |  |  |  | 34 |  |  | 5 |  |  | 39 |  |
| Balance as of October 29, 2023 |  |  |  |  |  |  |  |  |  | 26,001 |  |  | 17,652 |  |  | 43,653 |  |
| Acquisition of VMware |  |  |  |  |  |  |  |  |  | — |  |  | 54,206 |  |  | 54,206 |  |
| Acquisition of Seagate's SoC operations |  |  |  |  |  |  |  |  |  | 14 |  |  | — |  |  | 14 |  |
| Balance as of November 3, 2024 |  |  |  |  |  |  |  |  |  | $ | 26,015 |  |  | $ | 71,858 |  |  | $ | 97,873 |  |

[0001730168-24-000139:notes:151]
We completed three acquisitions in fiscal year 2023, all of which qualified as business combinations. The consideration for these acquisitions was primarily allocated to goodwill and intangible assets.

[0001730168-24-000139:notes:152]
During the fourth quarter of fiscal years 2024, 2023 and 2022, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-24-000139:notes:153]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of November 3, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 35,467 |  |  | $ | (12,551) |  |  | $ | 22,916 |  |
| Customer contracts and related relationships |  | 16,186 |  |  | (2,271) |  |  | 13,915 |  |
| Trade names |  | 1,720 |  |  | (369) |  |  | 1,351 |  |
| Other |  | 166 |  |  | (105) |  |  | 61 |  |
| Intangible assets subject to amortization |  | 53,539 |  |  | (15,296) |  |  | 38,243 |  |
| IPR&D |  | 2,340 |  |  | — |  |  | 2,340 |  |
| Total |  | $ | 55,879 |  |  | $ | (15,296) |  |  | $ | 40,583 |  |
| As of October 29, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 12,938 |  |  | $ | (10,723) |  |  | $ | 2,215 |  |
| Customer contracts and related relationships |  | 7,059 |  |  | (5,753) |  |  | 1,306 |  |
| Trade names |  | 649 |  |  | (388) |  |  | 261 |  |
| Other |  | 177 |  |  | (102) |  |  | 75 |  |
| Intangible assets subject to amortization |  | 20,823 |  |  | (16,966) |  |  | 3,857 |  |
| IPR&D |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 20,833 |  |  | $ | (16,966) |  |  | $ | 3,867 |  |

[0001730168-24-000139:notes:154]
Based on the amount of intangible assets subject to amortization at November 3, 2024, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-24-000139:notes:155]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2025 |  | $ | 8,055 |  |
| 2026 |  | 7,571 |  |
| 2027 |  | 6,533 |  |
| 2028 |  | 5,443 |  |
| 2029 |  | 4,356 |  |
| Thereafter |  | 6,285 |  |
| Total |  | $ | 38,243 |  |

[0001730168-24-000139:notes:156]
The weighted-average remaining amortization periods by intangible asset category were as follows:

[0001730168-24-000139:notes:157]
| Amortizable intangible assets: |  | November 3,2024 |
|  |  | (In years) |
| Purchased technology |  | 7 |
| Customer contracts and related relationships |  | 7 |
| Trade names |  | 12 |
| Other |  | 7 |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001730168-24-000139:notes:158]
Net Income Per Share

[0001730168-24-000139:notes:159]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 6,168 |  |  | $ | 14,082 |  |  | $ | 11,495 |  |
| Dividends on preferred stock |  | — |  |  | — |  |  | (272) |  |
| Income from continuing operations attributable to common stock |  | 6,168 |  |  | 14,082 |  |  | 11,223 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (273) |  |  | — |  |  | — |  |
| Net income attributable to common stock |  | $ | 5,895 |  |  | $ | 14,082 |  |  | $ | 11,223 |  |
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,624 |  |  | 4,149 |  |  | 4,089 |  |
| Dilutive effect of equity awards |  | 154 |  |  | 123 |  |  | 143 |  |
| Weighted-average shares outstanding - diluted |  | 4,778 |  |  | 4,272 |  |  | 4,232 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.33 |  |  | $ | 3.39 |  |  | $ | 2.74 |  |
| Loss per share from discontinued operations |  | (0.06) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 1.27 |  |  | $ | 3.39 |  |  | $ | 2.74 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.29 |  |  | $ | 3.30 |  |  | $ | 2.65 |  |
| Loss per share from discontinued operations |  | (0.06) |  |  | — |  |  | — |  |
| Net income per share |  | $ | 1.23 |  |  | $ | 3.30 |  |  | $ | 2.65 |  |


## us-gaap:EarningsPerShareTextBlock

[0001730168-24-000139:notes:160]
For fiscal year 2022, diluted net income per share excluded the potentially dilutive effect of 104 million shares of common stock issuable upon the conversion of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”) as their effect was antidilutive. All shares of our Mandatory Convertible Preferred Stock were converted into shares of our common stock before the end of fiscal year 2022.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-24-000139:notes:161]
Retirement Plans 
Defined Benefit Pension Plans

[0001730168-24-000139:notes:162]
The U.S. defined benefit pension plans primarily consist of a qualified pension plan. Benefits of the qualified pension plan are provided under an adjusted career-average-pay program, a cash-balance program or a dollar-per-month program. Benefit accruals under this plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the dollar-per-month program. We also have a frozen non-qualified supplemental pension plan in the United States that principally provides benefits based on compensation in excess of amounts that can be considered under the qualified pension plan.

[0001730168-24-000139:notes:163]
For certain non-U.S. countries, we also have defined benefit pension plans for eligible employees. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-24-000139:notes:164]
Net Periodic Benefit Cost

[0001730168-24-000139:notes:165]
|  |  | Fiscal Year |  |  |
|  |  | 2024 |  | 2023 |  | 2022 |  |  |  |  |  |  |
|  |  | (In millions) |
| Service cost |  | $ | 17 |  |  | $ | 8 |  |  | $ | 8 |  |  |  |  |  |  |  |
| Interest cost |  | 63 |  |  | 60 |  |  | 39 |  |  |  |  |  |  |  |
| Expected return on plan assets |  | (60) |  |  | (59) |  |  | (39) |  |  |  |  |  |  |  |
| Other |  | (2) |  |  | — |  |  | 1 |  |  |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 18 |  |  | $ | 9 |  |  | $ | 9 |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  | $ | (3) |  |  | $ | 20 |  |  | $ | (17) |  |  |  |  |  |  |  |

[0001730168-24-000139:notes:166]
The components of net periodic benefit cost other than the service cost are included in other income (expense), net. Service cost is recognized in operating expenses.

[0001730168-24-000139:notes:167]
Benefit Obligations and Plan Assets

[0001730168-24-000139:notes:168]
|  |  | Pension Benefits |  |  |
|  |  | November 3,2024 |  | October 29,2023 |  |  |  |  |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,105 |  |  | $ | 1,160 |  |  |  |  |  |
| Actual return on plan assets |  | 123 |  |  | 19 |  |  |  |  |  |
| Employer contributions |  | 21 |  |  | 15 |  |  |  |  |  |
| Plan participants’ contributions |  | 1 |  |  | 1 |  |  |  |  |  |
| Benefit payments |  | (108) |  |  | (94) |  |  |  |  |  |
| Plan assets acquired in VMware acquisition |  | 18 |  |  | — |  |  |  |  |  |
| Foreign currency impact |  | (2) |  |  | 4 |  |  |  |  |  |
| Fair value of plan assets — end of period |  | 1,158 |  |  | 1,105 |  |  |  |  |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,101 |  |  | 1,143 |  |  |  |  |  |
| Service cost |  | 17 |  |  | 8 |  |  |  |  |  |
| Interest cost |  | 63 |  |  | 60 |  |  |  |  |  |
| Actuarial (gain) loss |  | 65 |  |  | (22) |  |  |  |  |  |
| Plan participants’ contributions |  | 1 |  |  | 1 |  |  |  |  |  |
| Benefit payments |  | (108) |  |  | (94) |  |  |  |  |  |
| Curtailments |  | (13) |  |  | — |  |  |  |  |  |
| Benefit obligations assumed in VMware acquisition |  | 72 |  |  | — |  |  |  |  |  |
| Foreign currency impact |  | (4) |  |  | 5 |  |  |  |  |  |
| Benefit obligations — end of period |  | 1,194 |  |  | 1,101 |  |  |  |  |  |
| Overfunded (underfunded) status of benefit obligations (a) |  | $ | (36) |  |  | $ | 4 |  |  |  |  |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive loss, net of taxes |  | $ | (106) |  |  | $ | (108) |  |  |  |  |  |

[0001730168-24-000139:notes:169]
_______________________________

[0001730168-24-000139:notes:170]
(a)Substantially all amounts recognized on the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented.

[0001730168-24-000139:notes:171]
Plans with benefit obligations less than plan assets:

[0001730168-24-000139:notes:172]
|  |  | November 3,2024 |  | October 29,2023 |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 1,064 |  |  | $ | 1,022 |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 1,063 |  |  | $ | 1,022 |  |  |  |  |  |
| Fair value of plan assets |  | $ | 1,118 |  |  | $ | 1,079 |  |  |  |  |  |

[0001730168-24-000139:notes:173]
Plans with benefit obligations in excess of plan assets:

[0001730168-24-000139:notes:174]
|  |  | November 3,2024 |  | October 29,2023 |  |  |  |  |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 130 |  |  | $ | 79 |  |  |  |  |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 99 |  |  | $ | 64 |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets |  | $ | 40 |  |  | $ | 26 |  |  |  |  |  |  |  |  |  |

[0001730168-24-000139:notes:175]
The fair value of pension plan assets as of November 3, 2024 and October 29, 2023 included $229 million and $204 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-24-000139:notes:176]
The projected benefit obligations as of November 3, 2024 and October 29, 2023 included $260 million and $202 million, respectively, of obligations related to our non-U.S. pension plans. The accumulated benefit obligations as of November 3, 2024 and October 29, 2023 included $229 million and $188 million, respectively, of obligations related to our non-U.S. pension plans.

[0001730168-24-000139:notes:177]
Expected Future Benefit Payments

[0001730168-24-000139:notes:178]
| Fiscal Years: |  | Expected Benefit Payments |  |  |
|  |  | (In millions) |
| 2025 |  | $ | 99 |  |  |  |
| 2026 |  | $ | 98 |  |  |  |
| 2027 |  | $ | 97 |  |  |  |
| 2028 |  | $ | 95 |  |  |  |
| 2029 |  | $ | 95 |  |  |  |
| 2030-2034 |  | $ | 440 |  |  |  |

[0001730168-24-000139:notes:179]
Investment Policy

[0001730168-24-000139:notes:180]
Plan assets of the U.S. qualified pension plan, which represent substantially all of the plan assets, are generally invested in funds held by third-party fund managers. Our benefit plan investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has the discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-24-000139:notes:181]
The target asset allocation for the U.S. qualified pension plan reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2024 and 2023, 100% of the U.S. qualified pension plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-24-000139:notes:182]
Fair Value Measurement of Plan Assets

[0001730168-24-000139:notes:183]
|  |  | November 3, 2024 |  |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |  |  |
|  |  | (In millions) |  |  |
| Cash equivalents |  | 17 |  | (a) |  | $ | — |  |  |  |  |  | $ | 17 |  |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 83 |  | (b) |  | — |  |  |  |  |  | 83 |  |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 184 |  | (c) |  |  |  | 184 |  |  |  |
| Corporate bonds |  | — |  |  |  | 715 |  | (c) |  |  |  | 715 |  |  |  |
| Municipal bonds |  | — |  |  |  | 22 |  | (c) |  |  |  | 22 |  |  |  |
| Government bonds |  | — |  |  |  | 14 |  | (c) |  |  |  | 14 |  |  |  |
| Asset-backed securities |  | — |  |  |  | 1 |  | (c) |  |  |  | 1 |  |  |  |
| Plan assets measured by fair value hierarchy |  | $ | 100 |  |  |  | $ | 936 |  |  |  |  |  | 1,036 |  |  |  |
| Plan assets measured at net asset value |  |  |  |  |  |  |  |  |  | 122 |  | (d) |  |
| Total plan assets |  |  |  |  |  |  |  |  |  | $ | 1,158 |  |  |  |

[0001730168-24-000139:notes:184]
|  |  | October 29, 2023 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |  |
|  |  | (In millions) |  |
| Cash equivalents |  | $ | 16 |  | (a) |  | $ | — |  |  |  |  |  | $ | 16 |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 62 |  | (b) |  | — |  |  |  |  |  | 62 |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 144 |  | (c) |  |  |  | 144 |  |  |
| Corporate bonds |  | — |  |  |  | 837 |  | (c) |  |  |  | 837 |  |  |
| Municipal bonds |  | — |  |  |  | 23 |  | (c) |  |  |  | 23 |  |  |
| Government bonds |  | — |  |  |  | 21 |  | (c) |  |  |  | 21 |  |  |
| Asset-backed securities |  | — |  |  |  | 2 |  | (c) |  |  |  | 2 |  |  |
| Total plan assets |  | $ | 78 |  |  |  | $ | 1,027 |  |  |  |  |  | $ | 1,105 |  |  |

[0001730168-24-000139:notes:185]
______________________________

[0001730168-24-000139:notes:186]
(a)Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets.

[0001730168-24-000139:notes:187]
(b)These equity securities were valued based on quoted prices in active markets.

[0001730168-24-000139:notes:188]
(c)These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the assets, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals.

[0001730168-24-000139:notes:189]
(d)Plan assets measured at fair value using net asset value as a practical expedient were excluded from the fair value hierarchy.

[0001730168-24-000139:notes:190]
Assumptions

[0001730168-24-000139:notes:191]
The assumptions used to determine the benefit obligations and net periodic benefit cost for our defined benefit pension plans are presented in the table below. The expected long-term return on assets shown in the table below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes in which the pension funds are invested. Discount rates reflect the current rate at which defined benefit pension obligations could be settled based on the measurement dates of the plans, which is October 31, the month end closest to our fiscal year end. The range of assumptions reflects the different economic environments within various countries.

[0001730168-24-000139:notes:192]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit CostFiscal Year |
|  |  | November 3,2024 |  | October 29,2023 |  | 2024 |  | 2023 |  | 2022 |
| Discount rate |  | 1.75%-6.75% |  | 1.75%-7.00% |  | 1.75%-7.10% |  | 1.25%-7.25% |  | 0.75%-6.50% |
| Average increase in compensation levels |  | 2.00%-8.80% |  | 2.00%-10.00% |  | 2.00%-8.80% |  | 2.00%-10.00% |  | 2.00%-10.00% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 2.50%-7.25% |  | 2.50%-7.00% |  | 1.50%-7.25% |

[0001730168-24-000139:notes:193]
Defined Contribution Plans

[0001730168-24-000139:notes:194]
Our eligible U.S. employees participate in a company-sponsored 401(k) plan. Under the plan, we match employee contributions dollar for dollar up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2024, 2023 and 2022, we made contributions of $210 million, $100 million and $96 million, respectively, to the 401(k) plan. The increase in fiscal year 2024 was due to the VMware Merger.

[0001730168-24-000139:notes:195]
In addition, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans.


## us-gaap:DebtDisclosureTextBlock

[0001730168-24-000139:notes:196]
Borrowings

[0001730168-24-000139:notes:197]
|  |  | Effective Interest Rate |  | November 3,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | $ | 875 |  |  | $ | — |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | — |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | — |  |
| 4.800% notes due October 2034 |  | 4.38 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | 5,595 |  |  | — |  |
| SOFR plus 1.375% term loan due November 2028 |  | 6.31 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 13,595 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |

[0001730168-24-000139:notes:198]
|  |  | Effective Interest Rate |  | November 3,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | — |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 1,655 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 7,000 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 69,847 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 1,245 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 26 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 1,271 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 68,602 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 13 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,320) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,295 |  |  | $ | 37,621 |  |

[0001730168-24-000139:notes:199]
The senior notes and term loans are recorded net of discount and issuance costs, which are amortized to interest expense over the respective terms of such instruments. The effective interest rates are calculated based on contractual interest, discount and issuance costs and, if applicable, reclassification of the cumulative gain from derivatives. See Note 2. "Summary of Significant Accounting Policies" for additional information for derivative instruments.

[0001730168-24-000139:notes:200]
Senior Notes

[0001730168-24-000139:notes:201]
We issued senior unsecured notes for an aggregate principal amount of $5,000 million in October 2024 and $5,000 million in July 2024.

[0001730168-24-000139:notes:202]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes. We repaid $1,250 million of 1.000% notes upon maturity in August 2024.

[0001730168-24-000139:notes:203]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-24-000139:notes:204]
2023 Term Loans

[0001730168-24-000139:notes:205]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered an $11,195 million unsecured term A-2 facility (the "Term A-2 Loan”), an $11,195 million unsecured term A-3 facility (the “Term A-3 Loan”), and an $8,000 million unsecured term A-5 facility (the “Term A-5 Loan”, collectively, the “2023 Term Loans”).

[0001730168-24-000139:notes:206]
During fiscal year 2024, we repaid $11,195 million of our Term A-2 Loan using the net proceeds from the senior notes issued in July 2024 and the sale of the EUC business, as well as cash on hand. We also repaid $5,600 million of our Term A-3 Loan using the net proceeds from the senior notes issued in October 2024 and cash on hand. As a result of these repayments, we wrote off unamortized discount and issuance costs of $157 million, which were included in interest expense in the consolidated statement of operations.

[0001730168-24-000139:notes:207]
The 2023 Term Loans bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The Term A-3 Loan and Term A-5 Loan will mature and be payable on the third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

[0001730168-24-000139:notes:208]
2021 Credit Agreement

[0001730168-24-000139:notes:209]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under the revolving credit facility at either November 3, 2024 or October 29, 2023.

[0001730168-24-000139:notes:210]
Commercial Paper

[0001730168-24-000139:notes:211]
We have a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either November 3, 2024 or October 29, 2023.

[0001730168-24-000139:notes:212]
Fair Value of Debt

[0001730168-24-000139:notes:213]
As of November 3, 2024, the estimated aggregate fair value of our debt was $65,022 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates their fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-24-000139:notes:214]
Future Principal Payments of Debt

[0001730168-24-000139:notes:215]
The future scheduled principal payments of debt as of November 3, 2024 were as follows:

[0001730168-24-000139:notes:216]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 |  | $ | 1,245 |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 11,732 |  |
| 2028 |  | 4,270 |  |
| 2029 |  | 12,655 |  |
| Thereafter |  | 36,793 |  |
| Total |  | $ | 69,847 |  |

[0001730168-24-000139:notes:217]
As of November 3, 2024 and October 29, 2023, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-24-000139:notes:218]
Stockholders’ Equity 
Stock Split

[0001730168-24-000139:notes:219]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock, proportionately increasing the number of shares of our authorized common stock from 2.9 billion to 29 billion without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented herein have been retroactively adjusted, where applicable, to reflect the stock split.

[0001730168-24-000139:notes:220]
Cash Dividends Declared and Paid

[0001730168-24-000139:notes:221]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 2.105 |  |  | $ | 1.840 |  |  | $ | 1.640 |  |
| Dividends to common stockholders |  | $ | 9,814 |  |  | $ | 7,645 |  |  | $ | 6,733 |  |
| Dividends per share to preferred stockholders |  | $ | — |  |  | $ | — |  |  | $ | 80.00 |  |
| Dividends to preferred stockholders |  | $ | — |  |  | $ | — |  |  | $ | 299 |  |

[0001730168-24-000139:notes:222]
On September 30, 2019, we completed an offering of approximately 4 million shares of Mandatory Convertible Preferred Stock, which generated net proceeds of approximately $3,679 million and would automatically convert into shares of our common stock on September 30, 2022.

[0001730168-24-000139:notes:223]
The holders of Mandatory Convertible Preferred Stock were entitled to receive, when, as and if declared by our Board of Directors, or an authorized committee thereof, out of funds legally available for payment, cumulative dividends at the annual rate of 8.00% of the liquidation preference of $1,000 per share (equivalent to $80 annually per share), payable in cash or, subject to certain limitations, by delivery of shares of our common stock or any combination of cash and shares of our common stock, at our election.

[0001730168-24-000139:notes:224]
During fiscal year 2022, outstanding shares of our Mandatory Convertible Preferred Stock converted into an aggregate of approximately 116 million shares of our common stock at conversion rates ranging between 30.894 and 31.149 common shares per share of Mandatory Convertible Preferred Stock. We paid cash in lieu of fractional shares of common stock upon conversion.

[0001730168-24-000139:notes:225]
Stock Repurchase Programs

[0001730168-24-000139:notes:226]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2022, which was subsequently extended to December 31, 2023. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023. During fiscal years 2024, 2023 and 2022, we repurchased and retired approximately 67 million, 91 million and 117 million shares of our common stock for $7,176 million, $5,824 million and $7,000 million, respectively. All $20 billion of the authorized amount under these stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000139:notes:227]
Equity Incentive Award Plans

[0001730168-24-000139:notes:228]
2012 Plan

[0001730168-24-000139:notes:229]
In connection with the acquisition of Broadcom Corporation, we assumed its 2012 stock incentive plan and outstanding unvested RSUs that were held by its employees. During the second quarter of fiscal year 2021, our stockholders approved the amendment and restatement of the Broadcom Corporation 2012 stock incentive plan, now called the Broadcom Inc. 2012 Stock Incentive Plan (the “2012 Plan”). Under the 2012 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock awards, and RSUs to employees. No participant may be granted such awards for more than an aggregate of 40 million shares in any fiscal year. Equity awards granted generally vest over four years. The 2012 Plan reduced the number of shares available for new equity award grants to 200 million shares and removed the annual share replenishment provision provided under the Broadcom Corporation 2012 stock incentive plan. During the second quarter of fiscal year 2023, our stockholders approved the amendment and restatement of the 2012 Plan to increase the number of shares of common stock authorized for issuance by 250 million shares. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of November 3, 2024, 364 million shares remained available for issuance under the 2012 Plan.

[0001730168-24-000139:notes:230]
We may grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2024, 2023 and 2022, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 300% of the original grant on a stock split adjusted basis at vesting based upon the total stockholder return (“TSR”) on our common stock on an absolute basis and as compared to the TSR of an index group of companies. During fiscal year 2023, we also granted market-based RSUs vesting over five years, subject to satisfaction of stock price performance milestones.

[0001730168-24-000139:notes:231]
2007 Plan

[0001730168-24-000139:notes:232]
In connection with the VMware Merger, we assumed the VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan (the “2007 Plan”) and outstanding unvested RSU awards and PSU awards originally granted by VMware under the 2007 Plan that were held by continuing employees. These assumed awards were converted into approximately 46 million Broadcom RSU awards and will vest in accordance with their original terms, generally over four years. Under the 2007 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock, RSUs, and other stock-based or cash-based awards to employees. Equity awards granted under the 2007 Plan following the VMware Merger are expected to be on similar terms and consistent with similar grants made pursuant to the 2012 Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of November 3, 2024, 62 million shares remained available for issuance under the 2007 Plan.

[0001730168-24-000139:notes:233]
Employee Stock Purchase Plan

[0001730168-24-000139:notes:234]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or the end of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974.

[0001730168-24-000139:notes:235]
Stock-Based Compensation Expense

[0001730168-24-000139:notes:236]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 119 |  |  | $ | 88 |  |  | $ | 65 |  |
| Cost of subscriptions and services |  | 545 |  |  | 122 |  |  | 82 |  |
| Research and development |  | 3,460 |  |  | 1,513 |  |  | 1,048 |  |
| Selling, general and administrative |  | 1,546 |  |  | 448 |  |  | 338 |  |
| Total stock-based compensation expense(a) |  | $ | 5,670 |  |  | $ | 2,171 |  |  | $ | 1,533 |  |
| Estimated income tax benefits for stock-based compensation |  | $ | 991 |  |  | $ | 367 |  |  | $ | 255 |  |
| Excess income tax benefits for stock-based awards exercised or released |  | $ | 1,296 |  |  | $ | 507 |  |  | $ | 375 |  |

[0001730168-24-000139:notes:237]
_____________________________

[0001730168-24-000139:notes:238]
(a) Does not include stock-based compensation expense related to discontinued operations recognized during fiscal year 2024, which was included in loss from discontinued operations, net of income taxes in our consolidated statement of operations.

[0001730168-24-000139:notes:239]
Fiscal year 2024 stock-based compensation expense included $1,613 million related to equity awards assumed in connection with the VMware Merger.

[0001730168-24-000139:notes:240]
During the first quarter of fiscal year 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $356 million, $596 million and $794 million for fiscal years 2024, 2023 and 2022, respectively.

[0001730168-24-000139:notes:241]
As of November 3, 2024, the total unrecognized compensation cost related to unvested stock-based awards was $11,259 million, which is expected to be recognized over the remaining weighted-average service period of 3.0 years.

[0001730168-24-000139:notes:242]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-24-000139:notes:243]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
| Risk-free interest rate |  | 4.2 | % |  | 4.0 | % |  | 1.4 | % |
| Dividend yield |  | 1.7 | % |  | 3.3 | % |  | 2.7 | % |
| Volatility |  | 32.0 | % |  | 32.8 | % |  | 37.1 | % |
| Expected term (in years) |  | 3.6 |  | 4.8 |  | 3.4 |

[0001730168-24-000139:notes:244]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-24-000139:notes:245]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-24-000139:notes:246]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-24-000139:notes:247]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-24-000139:notes:248]
Restricted Stock Unit Awards

[0001730168-24-000139:notes:249]
A summary of time- and market-based RSU activity was as follows:

[0001730168-24-000139:notes:250]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |
|  |  | (In millions, except per share data) |
| Balance as of October 31, 2021 |  | 234 |  |  | $ | 20.04 |  |  |  |
| Granted |  | 27 |  |  | $ | 52.77 |  |  |  |
| Vested |  | (74) |  |  | $ | 22.55 |  |  |  |
| Forfeited |  | (12) |  |  | $ | 24.28 |  |  |  |
| Balance as of October 30, 2022 |  | 175 |  |  | $ | 23.85 |  |  |  |
| Granted |  | 124 |  |  | $ | 51.98 |  |  |  |
| Vested |  | (74) |  |  | $ | 26.25 |  |  |  |
| Forfeited |  | (7) |  |  | $ | 30.79 |  |  |  |
| Balance as of October 29, 2023 |  | 218 |  |  | $ | 38.92 |  |  |  |
| Assumed in VMware Merger |  | 46 |  |  | $ | 96.85 |  |  |  |
| Granted |  | 81 |  |  | $ | 115.58 |  |  |  |
| Vested |  | (107) |  |  | $ | 54.34 |  |  |  |
| Forfeited |  | (25) |  |  | $ | 88.62 |  |  |  |
| Balance as of November 3, 2024 |  | 213 |  |  | $ | 66.44 |  |  |  |

[0001730168-24-000139:notes:251]
The aggregate fair value of time- and market-based RSUs that vested in fiscal years 2024, 2023 and 2022 was $14,914 million, $5,423 million and $4,207 million, respectively, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-24-000139:notes:252]
Income Taxes 
The components of income before income taxes by U.S. and foreign jurisdictions were as follows:

[0001730168-24-000139:notes:253]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Domestic loss |  | $ | (4,851) |  |  | $ | (63) |  |  | $ | (2,020) |  |
| Foreign income |  | 14,767 |  |  | 15,160 |  |  | 14,454 |  |
| Income from continuing operations before income taxes |  | $ | 9,916 |  |  | $ | 15,097 |  |  | $ | 12,434 |  |

[0001730168-24-000139:notes:254]
The components of the provision for income taxes were as follows:

[0001730168-24-000139:notes:255]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Current tax provision: |  |  |  |  |  |  |
| Federal |  | $ | 1,030 |  |  | $ | 952 |  |  | $ | 174 |  |
| State |  | 52 |  |  | 23 |  |  | 48 |  |
| Foreign |  | 701 |  |  | 541 |  |  | 762 |  |
| Total |  | 1,783 |  |  | 1,516 |  |  | 984 |  |
| Deferred tax provision (benefit): |  |  |  |  |  |  |
| Federal |  | 1,855 |  |  | (499) |  |  | 68 |  |
| State |  | (70) |  |  | (31) |  |  | (15) |  |
| Foreign |  | 180 |  |  | 29 |  |  | (98) |  |
| Total |  | 1,965 |  |  | (501) |  |  | (45) |  |
| Total provision for income taxes |  | $ | 3,748 |  |  | $ | 1,015 |  |  | $ | 939 |  |

[0001730168-24-000139:notes:256]
The following is a reconciliation of our effective tax rate to the statutory federal tax rate:

[0001730168-24-000139:notes:257]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
| Statutory tax rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State, net of federal benefit |  | (0.1) |  |  | — |  |  | 0.2 |  |
| Foreign income taxed at different rates |  | (22.4) |  |  | (17.3) |  |  | (19.1) |  |
| Deemed inclusion of foreign earnings |  | 16.3 |  |  | 9.9 |  |  | 8.0 |  |
| Impact of non-recurring intra-group transfer of certain IP rights |  | 39.6 |  |  | — |  |  | — |  |
| Uncertain tax benefits |  | 1.8 |  |  | (1.9) |  |  | 1.6 |  |
| Excess tax benefits from stock-based compensation |  | (13.1) |  |  | (3.4) |  |  | (3.0) |  |
| Research and development credit |  | (6.0) |  |  | (1.8) |  |  | (1.4) |  |
| Other, net |  | 0.7 |  |  | 0.2 |  |  | 0.2 |  |
| Effective tax rate on income before income taxes |  | 37.8 | % |  | 6.7 | % |  | 7.5 | % |

[0001730168-24-000139:notes:258]
The increase in provision for income taxes in fiscal year 2024 compared to fiscal year 2023 was primarily due to the impact of a non-recurring intra-group transfer of certain IP rights to the United States as a result of supply chain realignment and the resulting shift in jurisdictional mix of income, partially offset by an increase in excess tax benefits from stock-based awards. The increase in provision for income taxes in fiscal year 2023 compared to fiscal year 2022 was primarily due to higher income before income taxes, partially offset by an increase in the recognition of uncertain tax benefits as a result of lapses of statutes of limitations.

[0001730168-24-000139:notes:259]
We derive the effective tax rate benefit attributed to foreign income taxed at different rates primarily from our operations in Singapore and Malaysia. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are scheduled to expire in November 2030. We have also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to decrease the provision for income taxes by approximately $2,261 million, $2,104 million and $1,821 million for fiscal years 2024, 2023 and 2022, respectively.

[0001730168-24-000139:notes:260]
Significant components of our deferred tax assets and liabilities consisted of the following:

[0001730168-24-000139:notes:261]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |
| Net operating loss, credit and other carryforwards |  | $ | 2,905 |  |  | $ | 1,809 |  |
| Capitalized research and development |  | 2,459 |  |  | 275 |  |
| Deferred revenue |  | 776 |  |  | 208 |  |
| Employee stock awards |  | 291 |  |  | 190 |  |
| Depreciation and amortization |  | 81 |  |  | 223 |  |
| Other deferred income tax assets |  | 672 |  |  | 329 |  |
| Gross deferred income tax assets |  | 7,184 |  |  | 3,034 |  |
| Less: valuation allowance |  | (2,218) |  |  | (1,789) |  |
| Deferred income tax assets |  | 4,966 |  |  | 1,245 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 8,772 |  |  | 97 |  |
| Unamortized debt discount and issuance costs |  | 420 |  |  | 302 |  |
| Foreign earnings not indefinitely reinvested |  | 105 |  |  | 86 |  |
| Other deferred income tax liabilities |  | 210 |  |  | 62 |  |
| Deferred income tax liabilities |  | 9,507 |  |  | 547 |  |
| Net deferred income tax assets (liabilities) |  | $ | (4,541) |  |  | $ | 698 |  |

[0001730168-24-000139:notes:262]
As a result of the acquisition of VMware, we established $3,642 million of net deferred tax liabilities on the excess of book basis over the tax basis of acquired assets. Our net deferred tax liabilities also increased during the year due to the non-recurring intra-group transfer of certain IP rights to the United States. The valuation allowance disclosed in the table above relates to substantially all U.S. state and foreign net operating loss carryforwards and research and development tax credits that may not be realized.

[0001730168-24-000139:notes:263]
We continue to indefinitely reinvest $1,785 million of certain accumulated foreign earnings. The unrecognized deferred income tax liability related to these earnings is estimated to be $187 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-24-000139:notes:264]
As of November 3, 2024, we had tax effected U.S. state net operating loss carryforwards of $126 million and foreign net operating loss carryforwards of $92 million, all of which expire in various years beginning in fiscal year 2025. We had $2,176 million of state research and development tax credits which begin to expire in fiscal year 2025.

[0001730168-24-000139:notes:265]
Uncertain Tax Positions

[0001730168-24-000139:notes:266]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-24-000139:notes:267]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Beginning balance |  | $ | 4,655 |  |  | $ | 5,117 |  |  | $ | 5,030 |  |
| Lapses of statutes of limitations |  | (39) |  |  | (634) |  |  | (50) |  |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | 844 |  |  | 26 |  |  | — |  |
| Decreases in balances related to tax positions taken during prior periods |  | (9) |  |  | (13) |  |  | (113) |  |
| Increases in balances related to tax positions taken during current period |  | 447 |  |  | 170 |  |  | 288 |  |
| Decreases in balances related to settlements with taxing authorities |  | (55) |  |  | (11) |  |  | (38) |  |
| Ending balance |  | $ | 5,843 |  |  | $ | 4,655 |  |  | $ | 5,117 |  |

[0001730168-24-000139:notes:268]
We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes. Accrued interest and penalties were included within other long-term liabilities. During fiscal years 2024, 2023 and 2022, we recognized interest and penalties of $144 million, $22 million and $25 million respectively, within the provision for income taxes. As of November 3, 2024 and October 29, 2023, the total accrued interest and penalties was approximately $701 million and $389 million, respectively. The increase in total accrued interest and penalties was primarily the result of the VMware acquisition in addition to the current year accrual.

[0001730168-24-000139:notes:269]
As of November 3, 2024 and October 29, 2023, approximately $6,544 million and $5,044 million, respectively, of the unrecognized tax benefits and accrued interest and penalties would, if recognized, benefit our effective income tax rate. We are subject to U.S. income tax examination for fiscal years 2018 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2005 and later. It is possible that our existing unrecognized tax benefits may change up to $3,580 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-24-000139:notes:270]
Reportable Segments

[0001730168-24-000139:notes:271]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment has separate financial information that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-24-000139:notes:272]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, service provider, and enterprise networking applications, including AI networking and connectivity. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions, custom touch controllers, and inductive charging solutions for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-24-000139:notes:273]
Infrastructure software. We provide a portfolio of software solutions that help enterprises simplify their IT environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical FC SAN products and related software.

[0001730168-24-000139:notes:274]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as marketing, general and administrative activities, facilities and IT expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-24-000139:notes:275]
Unallocated Expenses

[0001730168-24-000139:notes:276]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-24-000139:notes:277]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-24-000139:notes:278]
|  |  | Fiscal Year |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 30,096 |  |  | $ | 28,182 |  |  | $ | 25,818 |  |
| Infrastructure software |  | 21,478 |  |  | 7,637 |  |  | 7,385 |  |
| Total net revenue |  | $ | 51,574 |  |  | $ | 35,819 |  |  | $ | 33,203 |  |
| Operating income: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 16,759 |  |  | $ | 16,486 |  |  | $ | 15,075 |  |
| Infrastructure software |  | 13,977 |  |  | 5,639 |  |  | 5,219 |  |
| Unallocated expenses |  | (17,273) |  |  | (5,918) |  |  | (6,069) |  |
| Total operating income |  | $ | 13,463 |  |  | $ | 16,207 |  |  | $ | 14,225 |  |

[0001730168-24-000139:notes:279]
Geographic Information

[0001730168-24-000139:notes:280]
Net revenue by country is based primarily on the geographic shipment or delivery location as specified by the distributors, OEMs, contract manufacturers, channel partners, or software customers who purchased our products or services. For the majority of our products, title and control transfer to our customers in Penang, Malaysia. The products are then transported to the customer specific locations. Net revenue from the United States for fiscal years 2024, 2023 and 2022 was $12,887 million, $6,975 million and $5,915 million, respectively. Net revenue from China (including Hong Kong) for fiscal years 2024, 2023 and 2022 was $10,483 million, $11,533 million and $11,637 million, respectively. Net revenue from Singapore for fiscal years 2024, 2023 and 2022 was $9,559 million, $4,479 million and $4,003 million, respectively. Net revenue from other foreign countries for fiscal years 2024, 2023 and 2022 was $18,645 million, $12,832 million and $11,648 million, respectively. These geographic delivery locations are not necessarily indicative of the geographic location of our end customers or the country in which our end customers sell devices containing our products. For example, we believe a substantial portion of our products shipped or delivered to China (including Hong Kong) is included in devices sold by our end customers in the United States and Europe.

[0001730168-24-000139:notes:281]
Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-24-000139:notes:282]
|  |  | November 3,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,685 |  |  | $ | 1,371 |  |
| Taiwan |  | 365 |  |  | 341 |  |
| Other |  | 471 |  |  | 442 |  |
| Total long-lived assets |  | $ | 2,521 |  |  | $ | 2,154 |  |

[0001730168-24-000139:notes:283]
Significant Customer Information
We sell our products through our direct sales force and a select network of distributors and channel partners globally. One customer accounted for 18% and 21% of our net accounts receivable balance as of November 3, 2024 and October 29, 2023, respectively. During fiscal years 2024, 2023 and 2022, one customer accounted for 28%, 21% and 20% of our net revenue, respectively. Revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-24-000139:notes:284]
Commitments

[0001730168-24-000139:notes:285]
The following table summarizes contractual obligations and commitments as of November 3, 2024:

[0001730168-24-000139:notes:286]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  | (In millions) |
| 2025 |  | $ | 272 |  |  | $ | 486 |  |
| 2026 |  | 283 |  |  | 404 |  |
| 2027 |  | 7 |  |  | 352 |  |
| 2028 |  | 7 |  |  | 293 |  |
| 2029 |  | — |  |  | 240 |  |
| Thereafter |  | — |  |  | 997 |  |
| Total |  | $ | 569 |  |  | $ | 2,772 |  |

[0001730168-24-000139:notes:287]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-24-000139:notes:288]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-24-000139:notes:289]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 3, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,669 million of unrecognized tax benefits and accrued interest and penalties as of November 3, 2024 have been excluded from the table above.

[0001730168-24-000139:notes:290]
Contingencies

[0001730168-24-000139:notes:291]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly

[0001730168-24-000139:notes:292]
complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-24-000139:notes:293]
Lawsuits Relating to VMware Backlog

[0001730168-24-000139:notes:294]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms pending approval by the California Court.

[0001730168-24-000139:notes:295]
Other Matters

[0001730168-24-000139:notes:296]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-24-000139:notes:297]
Contingency Assessment

[0001730168-24-000139:notes:298]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-24-000139:notes:299]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our consolidated financial statements.

[0001730168-24-000139:notes:300]
Other Indemnifications

[0001730168-24-000139:notes:301]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-24-000139:notes:302]
Restructuring and Other Charges 
Restructuring Charges

[0001730168-24-000139:notes:303]
The following table summarizes the significant activities within, and components of, the restructuring liabilities:

[0001730168-24-000139:notes:304]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 31, 2021 |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Restructuring charges |  | 24 |  |  | 38 |  |  | 62 |  |
| Utilization |  | (24) |  |  | (38) |  |  | (62) |  |
| Balance as of October 30, 2022 |  | 4 |  |  | — |  |  | 4 |  |
| Restructuring charges |  | 20 |  |  | 24 |  |  | 44 |  |
| Utilization |  | (22) |  |  | (24) |  |  | (46) |  |
| Balance as of October 29, 2023 |  | 2 |  |  | — |  |  | 2 |  |
| Restructuring charges |  | 1,510 |  |  | 277 |  |  | 1,787 |  |
| Utilization |  | (1,393) |  |  | (277) |  |  | (1,670) |  |
| Balance as of November 3, 2024 |  | $ | 119 |  |  | $ | — |  |  | $ | 119 |  |

[0001730168-24-000139:notes:305]
In connection with the VMware Merger, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. Restructuring charges in fiscal year 2024 primarily related to employee termination costs. We also incurred $277 million of impairment charges primarily related to lease assets and property, plant and equipment. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses.

[0001730168-24-000139:notes:306]
During fiscal year 2023, we incurred $24 million of impairment charges primarily related to lease assets and property, plant and equipment. During fiscal year 2022, we incurred $38 million of impairment charges related to lease assets.

[0001730168-24-000139:notes:307]
As of November 3, 2024 and October 29, 2023, short-term and long-term lease liabilities included $192 million and $44 million of obligations related to restructured leases, respectively.

[0001730168-24-000139:notes:308]
Other Charges
Restructuring and other charges in our consolidated statement of operations for fiscal year 2023 included $204 million of non-recurring charges related to IP litigation


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001730168-24-000139:notes:309]
Other Charges

[0001730168-24-000139:notes:310]
Restructuring and other charges in our consolidated statement of operations for fiscal year 2023 included $204 million of non-recurring charges related to IP litigation.


## us-gaap:SubsequentEventsTextBlock

[0001730168-24-000139:notes:311]
Subsequent Events 
Cash Dividends Declared

[0001730168-24-000139:notes:312]
On December 10, 2024, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on December 31, 2024 to stockholders of record on December 23, 2024.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-24-000139:notes:313]
Schedule II — Valuation and Qualifying Accounts

[0001730168-24-000139:notes:314]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (a) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2024 |  | $ | 133 |  |  | $ | 351 |  |  | $ | (390) |  |  | $ | 94 |  |
| Fiscal year ended October 29, 2023 |  | $ | 125 |  |  | $ | 502 |  |  | $ | (494) |  |  | $ | 133 |  |
| Fiscal year ended October 30, 2022 |  | $ | 128 |  |  | $ | 484 |  |  | $ | (487) |  |  | $ | 125 |  |
| Other accounts receivable allowances (b) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2024 |  | $ | 4 |  |  | $ | 17 |  |  | $ | (10) |  |  | $ | 11 |  |
| Fiscal year ended October 29, 2023 |  | $ | 1 |  |  | $ | 5 |  |  | $ | (2) |  |  | $ | 4 |  |
| Fiscal year ended October 30, 2022 |  | $ | 2 |  |  | $ | 10 |  |  | $ | (11) |  |  | $ | 1 |  |
| Income tax valuation allowances: |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2024 |  | $ | 1,789 |  |  | $ | 3,151 |  |  | $ | (2,722) |  |  | $ | 2,218 |  |
| Fiscal year ended October 29, 2023 |  | $ | 1,777 |  |  | $ | 117 |  |  | $ | (105) |  |  | $ | 1,789 |  |
| Fiscal year ended October 30, 2022 |  | $ | 1,782 |  |  | $ | 118 |  |  | $ | (123) |  |  | $ | 1,777 |  |

[0001730168-24-000139:notes:315]
________________________________

[0001730168-24-000139:notes:316]
(a)Distributor credit allowances relate to price adjustments and other allowances.

[0001730168-24-000139:notes:317]
(b)Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001730168-24-000139:notes:318]
On September 23, 2024, Diane M. Bryant, a member of our Board of Directors, adopted a trading plan intended to satisfy Rule 10b5-1(c) under the Exchange Act (the “Trading Plan”). The Trading Plan provides for the potential sale of up to 15,000 shares of Broadcom common stock so long as the market price of Broadcom common stock satisfies certain threshold prices specified in the Trading Plan. The Trading Plan will expire on September 12, 2025, subject to early termination for certain specified events set forth in the Trading Plan.
