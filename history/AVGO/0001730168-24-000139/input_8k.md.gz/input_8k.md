# AVGO 8-K — 0001730168-24-000125 filed 2024-12-12

## item codes, every 8-K on or before 2024-12-20

- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2024-12-20

- none on or before 2024-12-20

## item 2.02 — earnings release, exhibit 99.1

[0001730168-24-000125:8k_2_02:1]
EX-99.1
2
avgo-11032024x8kxex99.htm
EX-99.1

[0001730168-24-000125:8k_2_02:2]
Document

[0001730168-24-000125:8k_2_02:3]
Exhibit 99.1

[0001730168-24-000125:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2024 Financial Results and Quarterly Dividend

[0001730168-24-000125:8k_2_02:5]
•Revenue of $14,054 million for the fourth quarter, up 51 percent from the prior year period

[0001730168-24-000125:8k_2_02:6]
•GAAP net income of $4,324 million for the fourth quarter; Non-GAAP net income of $6,965 million for the fourth quarter

[0001730168-24-000125:8k_2_02:7]
•Adjusted EBITDA of $9,089 million for the fourth quarter, or 65 percent of revenue

[0001730168-24-000125:8k_2_02:8]
•GAAP diluted EPS of $0.90 for the fourth quarter; Non-GAAP diluted EPS of $1.42 for the fourth quarter

[0001730168-24-000125:8k_2_02:9]
•Cash from operations of $5,604 million for the fourth quarter, less capital expenditures of $122 million, resulted in $5,482 million of free cash flow, or 39 percent of revenue

[0001730168-24-000125:8k_2_02:10]
•Quarterly common stock dividend increased by 11 percent from the prior quarter to $0.59 per share

[0001730168-24-000125:8k_2_02:11]
•First quarter fiscal year 2025 revenue guidance of approximately $14.6 billion, an increase of 22 percent from the prior year period

[0001730168-24-000125:8k_2_02:12]
•First quarter fiscal year 2025 Adjusted EBITDA guidance of approximately 66 percent of projected revenue (1)

[0001730168-24-000125:8k_2_02:13]
PALO ALTO, Calif. – December 12, 2024 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year ended November 3, 2024, provided guidance for its first quarter of fiscal year 2025 and announced its quarterly dividend.

[0001730168-24-000125:8k_2_02:14]
“Broadcom’s fiscal year 2024 revenue grew 44% year-over-year to a record $51.6 billion, as infrastructure software revenue grew to $21.5 billion, on the successful integration of VMware,” said Hock Tan, President and CEO of Broadcom Inc. “Semiconductor revenue was a record $30.1 billion driven by AI revenue of $12.2 billion. AI revenue which grew 220 percent year-on-year was driven by our leading AI XPUs and Ethernet networking portfolio.”

[0001730168-24-000125:8k_2_02:15]
“In fiscal year 2024 adjusted EBITDA increased 37% year-over-year to a record $31.9 billion, and free cash flow excluding restructuring was strong at $21.9 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Based on increased cash flows in fiscal year 2024, we are increasing our quarterly common stock dividend by 11% to $0.59 per share for fiscal year 2025. The target fiscal year 2025 annual common stock dividend of $2.36 per share is a record, and the fourteenth consecutive increase in annual dividends since we initiated dividends in fiscal 2011.”

[0001730168-24-000125:8k_2_02:16]
________________________________

[0001730168-24-000125:8k_2_02:17]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-24-000125:8k_2_02:18]
1

[0001730168-24-000125:8k_2_02:19]
Fourth Quarter Fiscal Year 2024 Financial Highlights

[0001730168-24-000125:8k_2_02:20]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 24 |  | Q4 23 |  | Change |  | Q4 24 |  | Q4 23 |  | Change |
| Net revenue |  | $ | 14,054 |  |  | $ | 9,295 |  |  | +51 | % |  | $ | 14,054 |  |  | $ | 9,295 |  |  | +51 | % |
| Net income |  | $ | 4,324 |  |  | $ | 3,524 |  |  | +$800 |  |  | $ | 6,965 |  |  | $ | 4,810 |  |  | +$2,155 |  |
| Earnings per common share - diluted * |  | $ | 0.90 |  |  | $ | 0.83 |  |  | +$0.07 |  |  | $ | 1.42 |  |  | $ | 1.11 |  |  | +$0.31 |  |

[0001730168-24-000125:8k_2_02:21]
| (Dollars in millions) |  | Q4 24 |  | Q4 23 |  | Change |  |
| Cash flow from operations |  | $ | 5,604 |  |  | $ | 4,828 |  |  | +$776 |  |
| Adjusted EBITDA |  | $ | 9,089 |  |  | $ | 6,048 |  |  | +$3,041 |  |
| Free cash flow |  | $ | 5,482 |  |  | $ | 4,723 |  |  | +$759 |  |

[0001730168-24-000125:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 24 |  |  |  | Q4 23 |  | Change |  |
| Semiconductor solutions |  | $ | 8,230 |  |  | 59 | % |  |  |  |  |  |  | $ | 7,326 |  |  | 79 | % |  | +12 | % |  |
| Infrastructure software |  | 5,824 |  |  | 41 |  |  |  |  |  |  |  | 1,969 |  |  | 21 |  |  | +196 | % |  |
| Total net revenue |  | $ | 14,054 |  |  | 100 | % |  |  |  |  |  |  | $ | 9,295 |  |  | 100 | % |  |  |  |  |

[0001730168-24-000125:8k_2_02:23]
* On July 12, 2024, the Company completed a ten-for-one forward stock split. All per share amounts presented reflect the stock split.

[0001730168-24-000125:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,348 million, compared to $9,952 million at the end of the prior quarter.

[0001730168-24-000125:8k_2_02:25]
During the fourth fiscal quarter, the Company generated $5,604 million in cash from operations and spent $122 million on capital expenditures. The Company paid $1,204 million of withholding taxes related to net settled equity awards that vested in the quarter (resulting in the elimination of 7.4 million shares).

[0001730168-24-000125:8k_2_02:26]
On September 30, 2024, the Company paid a cash dividend on a split adjusted basis of $0.53 per share, totaling $2,484 million.

[0001730168-24-000125:8k_2_02:27]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-24-000125:8k_2_02:28]
2

[0001730168-24-000125:8k_2_02:29]
Fiscal Year 2024 Financial Highlights

[0001730168-24-000125:8k_2_02:30]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | FY 24 |  | FY 23 |  | Change |  | FY 24 |  | FY 23 |  | Change |
| Net revenue |  | $ | 51,574 |  |  | $ | 35,819 |  |  | +44 | % |  | $ | 51,574 |  |  | $ | 35,819 |  |  | +44 | % |
| Net income |  | $ | 5,895 |  |  | $ | 14,082 |  |  | -$8,187 |  |  | $ | 23,733 |  |  | $ | 18,378 |  |  | +$5,355 |  |
| Earnings per common share - diluted * |  | $ | 1.23 |  |  | $ | 3.30 |  |  | -$2.07 |  |  | $ | 4.87 |  |  | $ | 4.22 |  |  | +$0.65 |  |

[0001730168-24-000125:8k_2_02:31]
| (Dollars in millions) |  | FY 24 |  | FY 23 |  | Change |  |
| Cash flow from operations |  | $ | 19,962 |  |  | $ | 18,085 |  |  | +$1,877 |  |
| Adjusted EBITDA |  | $ | 31,897 |  |  | $ | 23,213 |  |  | +$8,684 |  |
| Free cash flow |  | $ | 19,414 |  |  | $ | 17,633 |  |  | +$1,781 |  |

[0001730168-24-000125:8k_2_02:32]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | FY 24 |  |  |  | FY 23 |  | Change |  |
| Semiconductor solutions |  | $ | 30,096 |  |  | 58 | % |  |  |  |  |  |  | $ | 28,182 |  |  | 79 | % |  | +7 | % |  |
| Infrastructure software |  | 21,478 |  |  | 42 |  |  |  |  |  |  |  | 7,637 |  |  | 21 |  |  | +181 | % |  |
| Total net revenue |  | $ | 51,574 |  |  | 100 | % |  |  |  |  |  |  | $ | 35,819 |  |  | 100 | % |  |  |  |  |

[0001730168-24-000125:8k_2_02:33]
* On July 12, 2024, the Company completed a ten-for-one forward stock split. All per share amounts presented reflect the stock split.

[0001730168-24-000125:8k_2_02:34]
First Quarter Fiscal Year 2025 Business Outlook

[0001730168-24-000125:8k_2_02:35]
Based on current business trends and conditions, the outlook for the first quarter of fiscal year 2025, ending February 2, 2025, is expected to be as follows:

[0001730168-24-000125:8k_2_02:36]
•First quarter revenue guidance of approximately $14.6 billion; and

[0001730168-24-000125:8k_2_02:37]
•First quarter Adjusted EBITDA guidance of approximately 66 percent of projected revenue.

[0001730168-24-000125:8k_2_02:38]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000125:8k_2_02:39]
Quarterly Dividends

[0001730168-24-000125:8k_2_02:40]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.59 per share. The dividend is payable on December 31, 2024 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 23, 2024.

[0001730168-24-000125:8k_2_02:41]
Financial Results Conference Call

[0001730168-24-000125:8k_2_02:42]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter and fiscal year 2024 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-24-000125:8k_2_02:43]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-24-000125:8k_2_02:44]
3

[0001730168-24-000125:8k_2_02:45]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-24-000125:8k_2_02:46]
Non-GAAP Financial Measures

[0001730168-24-000125:8k_2_02:47]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-24-000125:8k_2_02:48]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-24-000125:8k_2_02:49]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-24-000125:8k_2_02:50]
About Broadcom

[0001730168-24-000125:8k_2_02:51]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-24-000125:8k_2_02:52]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-24-000125:8k_2_02:53]
4

[0001730168-24-000125:8k_2_02:54]
Securities Act of 1933, as amended) concerning Broadcom. These statements include, but are not limited to, statements that address our expected future business and financial performance, and other statements identified by words such as “will,” “expect,” “believe,” “anticipate,” “estimate,” “should,” “intend,” “plan,” “potential,” “predict,” “project,” “aim,” and similar words, phrases or expressions. These forward-looking statements are based on current expectations and beliefs of Broadcom’s management, current information available to Broadcom’s management, and current market trends and market conditions and involve risks and uncertainties that may cause actual results to differ materially from those contained in forward-looking statements. Accordingly, undue reliance should not be placed on such statements.

[0001730168-24-000125:8k_2_02:55]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our acquisition of VMware, Inc., including our ability to realize the expected benefits; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of security systems; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; cyclicality in the semiconductor industry or in our target markets; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; our ability to improve our manufacturing efficiency and quality; involvement in legal proceedings; ability of our software products to manage and secure IT infrastructures and environments; demand for our data center virtualization products and market acceptance of our products and services; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third-party software used in our products; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-24-000125:8k_2_02:56]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking

[0001730168-24-000125:8k_2_02:57]
5

[0001730168-24-000125:8k_2_02:58]
statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000125:8k_2_02:59]
Contact:

[0001730168-24-000125:8k_2_02:60]
Ji Yoo

[0001730168-24-000125:8k_2_02:61]
Broadcom Inc.

[0001730168-24-000125:8k_2_02:62]
Investor Relations

[0001730168-24-000125:8k_2_02:63]
650-427-6000

[0001730168-24-000125:8k_2_02:64]
investor.relations@broadcom.com

[0001730168-24-000125:8k_2_02:65]
(AVGO-Q)

[0001730168-24-000125:8k_2_02:66]
6

[0001730168-24-000125:8k_2_02:67]
BROADCOM INC.

[0001730168-24-000125:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-24-000125:8k_2_02:69]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-24-000125:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 3,2024 |  | August 4,2024 |  | October 29,2023 |  | November 3,2024 |  | October 29,2023 |
| Net revenue |  | $ | 14,054 |  |  | $ | 13,072 |  |  | $ | 9,295 |  |  | $ | 51,574 |  |  | $ | 35,819 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,399 |  |  | 3,133 |  |  | 2,449 |  |  | 12,788 |  |  | 9,272 |  |
| Amortization of acquisition-related intangible assets |  | 1,602 |  |  | 1,525 |  |  | 438 |  |  | 6,023 |  |  | 1,853 |  |
| Restructuring charges |  | 51 |  |  | 58 |  |  | 1 |  |  | 254 |  |  | 4 |  |
| Total cost of revenue |  | 5,052 |  |  | 4,716 |  |  | 2,888 |  |  | 19,065 |  |  | 11,129 |  |
| Gross margin |  | 9,002 |  |  | 8,356 |  |  | 6,407 |  |  | 32,509 |  |  | 24,690 |  |
| Research and development |  | 2,234 |  |  | 2,353 |  |  | 1,388 |  |  | 9,310 |  |  | 5,253 |  |
| Selling, general and administrative |  | 1,010 |  |  | 1,100 |  |  | 418 |  |  | 4,959 |  |  | 1,592 |  |
| Amortization of acquisition-related intangible assets |  | 813 |  |  | 812 |  |  | 348 |  |  | 3,244 |  |  | 1,394 |  |
| Restructuring and other charges |  | 318 |  |  | 303 |  |  | 13 |  |  | 1,533 |  |  | 244 |  |
| Total operating expenses |  | 4,375 |  |  | 4,568 |  |  | 2,167 |  |  | 19,046 |  |  | 8,483 |  |
| Operating income |  | 4,627 |  |  | 3,788 |  |  | 4,240 |  |  | 13,463 |  |  | 16,207 |  |
| Interest expense |  | (916) |  |  | (1,064) |  |  | (405) |  |  | (3,953) |  |  | (1,622) |  |
| Other income, net |  | 52 |  |  | 82 |  |  | 132 |  |  | 406 |  |  | 512 |  |
| Income from continuing operations before income taxes |  | 3,763 |  |  | 2,806 |  |  | 3,967 |  |  | 9,916 |  |  | 15,097 |  |
| Provision for (benefit from) income taxes |  | (442) |  |  | 4,238 |  |  | 443 |  |  | 3,748 |  |  | 1,015 |  |
| Income (loss) from continuing operations |  | 4,205 |  |  | (1,432) |  |  | 3,524 |  |  | 6,168 |  |  | 14,082 |  |
| Income (loss) from discontinued operations, net of income taxes |  | 119 |  |  | (443) |  |  | — |  |  | (273) |  |  | — |  |
| Net income (loss) |  | $ | 4,324 |  |  | $ | (1,875) |  |  | $ | 3,524 |  |  | $ | 5,895 |  |  | $ | 14,082 |  |
| Basic income (loss) per share (1): |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.89 |  |  | $ | (0.31) |  |  | $ | 0.85 |  |  | $ | 1.33 |  |  | $ | 3.39 |  |
| Income (loss) per share from discontinued operations |  | 0.03 |  |  | (0.09) |  |  | — |  |  | (0.06) |  |  | — |  |
| Net income (loss) per share |  | $ | 0.92 |  |  | $ | (0.40) |  |  | $ | 0.85 |  |  | $ | 1.27 |  |  | $ | 3.39 |  |
| Diluted income (loss) per share (1): |  |  |  |  |  |  |  |  |  |  |
| Income (loss) per share from continuing operations |  | $ | 0.87 |  |  | $ | (0.31) |  |  | $ | 0.83 |  |  | $ | 1.29 |  |  | $ | 3.30 |  |
| Income (loss) per share from discontinued operations |  | 0.03 |  |  | (0.09) |  |  | — |  |  | (0.06) |  |  | — |  |
| Net income (loss) per share |  | $ | 0.90 |  |  | $ | (0.40) |  |  | $ | 0.83 |  |  | $ | 1.23 |  |  | $ | 3.30 |  |
| Weighted-average shares used in per share calculations (1): |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,679 |  |  | 4,663 |  |  | 4,133 |  |  | 4,624 |  |  | 4,149 |  |
| Diluted |  | 4,828 |  |  | 4,663 |  |  | 4,268 |  |  | 4,778 |  |  | 4,272 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 159 |  |  | $ | 174 |  |  | $ | 62 |  |  | $ | 664 |  |  | $ | 210 |  |
| Research and development |  | 839 |  |  | 877 |  |  | 448 |  |  | 3,460 |  |  | 1,513 |  |
| Selling, general and administrative |  | 316 |  |  | 330 |  |  | 128 |  |  | 1,546 |  |  | 448 |  |
| Total stock-based compensation expense |  | $ | 1,314 |  |  | $ | 1,381 |  |  | $ | 638 |  |  | $ | 5,670 |  |  | $ | 2,171 |  |
| (1) Reflects a ten-for-one forward stock split on July 12, 2024. |

[0001730168-24-000125:8k_2_02:71]
BROADCOM INC.

[0001730168-24-000125:8k_2_02:72]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-24-000125:8k_2_02:73]
(IN MILLIONS)

[0001730168-24-000125:8k_2_02:74]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 3,2024 |  | August 4,2024 |  | October 29,2023 |  | November 3,2024 |  | October 29,2023 |
| Gross margin on GAAP basis |  | $ | 9,002 |  |  | $ | 8,356 |  |  | $ | 6,407 |  |  | $ | 32,509 |  |  | $ | 24,690 |  |
| Amortization of acquisition-related intangible assets |  | 1,602 |  |  | 1,525 |  |  | 438 |  |  | 6,023 |  |  | 1,853 |  |
| Stock-based compensation expense |  | 159 |  |  | 174 |  |  | 62 |  |  | 664 |  |  | 210 |  |
| Restructuring charges |  | 51 |  |  | 58 |  |  | 1 |  |  | 254 |  |  | 4 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |
| Gross margin on non-GAAP basis |  | $ | 10,814 |  |  | $ | 10,113 |  |  | $ | 6,908 |  |  | $ | 39,459 |  |  | $ | 26,757 |  |
| Research and development on GAAP basis |  | $ | 2,234 |  |  | $ | 2,353 |  |  | $ | 1,388 |  |  | $ | 9,310 |  |  | $ | 5,253 |  |
| Stock-based compensation expense |  | 839 |  |  | 877 |  |  | 448 |  |  | 3,460 |  |  | 1,513 |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | — |  |  | 3 |  |  | — |  |
| Research and development on non-GAAP basis |  | $ | 1,395 |  |  | $ | 1,474 |  |  | $ | 940 |  |  | $ | 5,847 |  |  | $ | 3,740 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,010 |  |  | $ | 1,100 |  |  | $ | 418 |  |  | $ | 4,959 |  |  | $ | 1,592 |  |
| Stock-based compensation expense |  | 316 |  |  | 330 |  |  | 128 |  |  | 1,546 |  |  | 448 |  |
| Acquisition-related costs |  | 86 |  |  | 79 |  |  | 69 |  |  | 537 |  |  | 252 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 608 |  |  | $ | 691 |  |  | $ | 221 |  |  | $ | 2,876 |  |  | $ | 892 |  |
| Total operating expenses on GAAP basis |  | $ | 4,375 |  |  | $ | 4,568 |  |  | $ | 2,167 |  |  | $ | 19,046 |  |  | $ | 8,483 |  |
| Amortization of acquisition-related intangible assets |  | 813 |  |  | 812 |  |  | 348 |  |  | 3,244 |  |  | 1,394 |  |
| Stock-based compensation expense |  | 1,155 |  |  | 1,207 |  |  | 576 |  |  | 5,006 |  |  | 1,961 |  |
| Restructuring and other charges |  | 318 |  |  | 303 |  |  | 13 |  |  | 1,533 |  |  | 244 |  |
| Acquisition-related costs |  | 86 |  |  | 81 |  |  | 69 |  |  | 540 |  |  | 252 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,003 |  |  | $ | 2,165 |  |  | $ | 1,161 |  |  | $ | 8,723 |  |  | $ | 4,632 |  |
| Operating income on GAAP basis |  | $ | 4,627 |  |  | $ | 3,788 |  |  | $ | 4,240 |  |  | $ | 13,463 |  |  | $ | 16,207 |  |
| Amortization of acquisition-related intangible assets |  | 2,415 |  |  | 2,337 |  |  | 786 |  |  | 9,267 |  |  | 3,247 |  |
| Stock-based compensation expense |  | 1,314 |  |  | 1,381 |  |  | 638 |  |  | 5,670 |  |  | 2,171 |  |
| Restructuring and other charges |  | 369 |  |  | 361 |  |  | 14 |  |  | 1,787 |  |  | 248 |  |
| Acquisition-related costs |  | 86 |  |  | 81 |  |  | 69 |  |  | 549 |  |  | 252 |  |
| Operating income on non-GAAP basis |  | $ | 8,811 |  |  | $ | 7,948 |  |  | $ | 5,747 |  |  | $ | 30,736 |  |  | $ | 22,125 |  |
| Interest expense on GAAP basis |  | $ | (916) |  |  | $ | (1,064) |  |  | $ | (405) |  |  | $ | (3,953) |  |  | $ | (1,622) |  |
| Loss on debt extinguishment |  | 52 |  |  | 83 |  |  | — |  |  | 157 |  |  | — |  |
| Interest expense on non-GAAP basis |  | $ | (864) |  |  | $ | (981) |  |  | $ | (405) |  |  | $ | (3,796) |  |  | $ | (1,622) |  |
| Other income, net on GAAP basis |  | $ | 52 |  |  | $ | 82 |  |  | $ | 132 |  |  | $ | 406 |  |  | $ | 512 |  |
| (Gains) losses on investments |  | 30 |  |  | 6 |  |  | 24 |  |  | 12 |  |  | (11) |  |
| Other |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Other income, net on non-GAAP basis |  | $ | 82 |  |  | $ | 88 |  |  | $ | 155 |  |  | $ | 418 |  |  | $ | 500 |  |

[0001730168-24-000125:8k_2_02:75]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 3,2024 |  | August 4,2024 |  | October 29,2023 |  | November 3,2024 |  | October 29,2023 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (442) |  |  | $ | 4,238 |  |  | $ | 443 |  |  | $ | 3,748 |  |  | $ | 1,015 |  |
| Non-GAAP tax reconciling adjustments (1) |  | 1,506 |  |  | (3,303) |  |  | 244 |  |  | (123) |  |  | 1,610 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 1,064 |  |  | $ | 935 |  |  | $ | 687 |  |  | $ | 3,625 |  |  | $ | 2,625 |  |
| Net income (loss) on GAAP basis |  | $ | 4,324 |  |  | $ | (1,875) |  |  | $ | 3,524 |  |  | $ | 5,895 |  |  | $ | 14,082 |  |
| Amortization of acquisition-related intangible assets |  | 2,415 |  |  | 2,337 |  |  | 786 |  |  | 9,267 |  |  | 3,247 |  |
| Stock-based compensation expense |  | 1,314 |  |  | 1,381 |  |  | 638 |  |  | 5,670 |  |  | 2,171 |  |
| Restructuring and other charges |  | 369 |  |  | 361 |  |  | 14 |  |  | 1,787 |  |  | 248 |  |
| Acquisition-related costs |  | 86 |  |  | 81 |  |  | 69 |  |  | 549 |  |  | 252 |  |
| Loss on debt extinguishment |  | 52 |  |  | 83 |  |  | — |  |  | 157 |  |  | — |  |
| (Gains) losses on investments |  | 30 |  |  | 6 |  |  | 24 |  |  | 12 |  |  | (11) |  |
| Other |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Non-GAAP tax reconciling adjustments (1) |  | (1,506) |  |  | 3,303 |  |  | (244) |  |  | 123 |  |  | (1,610) |  |
| (Income) loss from discontinued operations, net of income taxes |  | (119) |  |  | 443 |  |  | — |  |  | 273 |  |  | — |  |
| Net income on non-GAAP basis |  | $ | 6,965 |  |  | $ | 6,120 |  |  | $ | 4,810 |  |  | $ | 23,733 |  |  | $ | 18,378 |  |
| Net income (loss) on GAAP basis |  | $ | 4,324 |  |  | $ | (1,875) |  |  | $ | 3,524 |  |  | $ | 5,895 |  |  | $ | 14,082 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,415 |  |  | 2,337 |  |  | 786 |  |  | 9,267 |  |  | 3,247 |  |
| Stock-based compensation expense |  | 1,314 |  |  | 1,381 |  |  | 638 |  |  | 5,670 |  |  | 2,171 |  |
| Restructuring and other charges |  | 369 |  |  | 361 |  |  | 14 |  |  | 1,787 |  |  | 248 |  |
| Acquisition-related costs |  | 86 |  |  | 81 |  |  | 69 |  |  | 549 |  |  | 252 |  |
| Loss on debt extinguishment |  | 52 |  |  | 83 |  |  | — |  |  | 157 |  |  | — |  |
| (Gains) losses on investments |  | 30 |  |  | 6 |  |  | 24 |  |  | 12 |  |  | (11) |  |
| Other |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Non-GAAP tax reconciling adjustments (1) |  | (1,506) |  |  | 3,303 |  |  | (244) |  |  | 123 |  |  | (1,610) |  |
| (Income) loss from discontinued operations, net of income taxes |  | (119) |  |  | 443 |  |  | — |  |  | 273 |  |  | — |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 864 |  |  | 981 |  |  | 405 |  |  | 3,796 |  |  | 1,622 |  |
| Provision for income taxes on non-GAAP basis |  | 1,064 |  |  | 935 |  |  | 687 |  |  | 3,625 |  |  | 2,625 |  |
| Depreciation |  | 156 |  |  | 149 |  |  | 124 |  |  | 593 |  |  | 502 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 40 |  |  | 38 |  |  | 22 |  |  | 150 |  |  | 86 |  |
| Adjusted EBITDA |  | $ | 9,089 |  |  | $ | 8,223 |  |  | $ | 6,048 |  |  | $ | 31,897 |  |  | $ | 23,213 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis (2) |  | 4,828 |  |  | 4,663 |  |  | 4,268 |  |  | 4,778 |  |  | 4,272 |  |
| Non-GAAP adjustment (3) |  | 77 |  |  | 254 |  |  | 82 |  |  | 99 |  |  | 81 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,905 |  |  | 4,917 |  |  | 4,350 |  |  | 4,877 |  |  | 4,353 |  |
| Net cash provided by operating activities |  | $ | 5,604 |  |  | $ | 4,963 |  |  | $ | 4,828 |  |  | $ | 19,962 |  |  | $ | 18,085 |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (172) |  |  | (105) |  |  | (548) |  |  | (452) |  |
| Free cash flow |  | $ | 5,482 |  |  | $ | 4,791 |  |  | $ | 4,723 |  |  | $ | 19,414 |  |  | $ | 17,633 |  |

[0001730168-24-000125:8k_2_02:76]
|  |  | Fiscal Quarter Ending |
|  |  | February 2, |
| Expected average diluted share count: |  | 2025 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis (2) |  | 4,828 |  |
| Non-GAAP adjustment (3) |  | 68 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,896 |  |

[0001730168-24-000125:8k_2_02:77]
| (1) Non-GAAP tax reconciling adjustments included a one-time discrete non-cash tax provision of $4.5 billion from the impact of an intra-group transfer of certain IP rights to the United States as a result of supply chain realignment for the fiscal quarter ended August 4, 2024 and the fiscal year ended November 3, 2024. |
| (2) Reflects a ten-for-one forward stock split on July 12, 2024. |
| (3) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter ended August 4, 2024, non-GAAP adjustment included the dilutive effect of the equity awards that were antidilutive on a GAAP basis. |

[0001730168-24-000125:8k_2_02:78]
BROADCOM INC.

[0001730168-24-000125:8k_2_02:79]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-24-000125:8k_2_02:80]
(IN MILLIONS)

[0001730168-24-000125:8k_2_02:81]
|  |  | November 3,2024 |  | October 29,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,348 |  |  | $ | 14,189 |  |
| Trade accounts receivable, net |  | 4,416 |  |  | 3,154 |  |
| Inventory |  | 1,760 |  |  | 1,898 |  |
| Other current assets |  | 4,071 |  |  | 1,606 |  |
| Total current assets |  | 19,595 |  |  | 20,847 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,521 |  |  | 2,154 |  |
| Goodwill |  | 97,873 |  |  | 43,653 |  |
| Intangible assets, net |  | 40,583 |  |  | 3,867 |  |
| Other long-term assets |  | 5,073 |  |  | 2,340 |  |
| Total assets |  | $ | 165,645 |  |  | $ | 72,861 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,662 |  |  | $ | 1,210 |  |
| Employee compensation and benefits |  | 1,971 |  |  | 935 |  |
| Current portion of long-term debt |  | 1,271 |  |  | 1,608 |  |
| Other current liabilities |  | 11,793 |  |  | 3,652 |  |
| Total current liabilities |  | 16,697 |  |  | 7,405 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 66,295 |  |  | 37,621 |  |
| Other long-term liabilities |  | 14,975 |  |  | 3,847 |  |
| Total liabilities |  | 97,967 |  |  | 48,873 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 4 |  |
| Additional paid-in capital |  | 67,466 |  |  | 21,095 |  |
| Retained earnings |  | — |  |  | 2,682 |  |
| Accumulated other comprehensive income |  | 207 |  |  | 207 |  |
| Total stockholders' equity |  | 67,678 |  |  | 23,988 |  |
| Total liabilities and equity |  | $ | 165,645 |  |  | $ | 72,861 |  |

[0001730168-24-000125:8k_2_02:82]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 3,2024 |  | August 4,2024 |  | October 29,2023 |  | November 3,2024 |  | October 29,2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 4,324 |  |  | $ | (1,875) |  |  | $ | 3,524 |  |  | $ | 5,895 |  |  | $ | 14,082 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,455 |  |  | 2,375 |  |  | 808 |  |  | 9,417 |  |  | 3,333 |  |
| Depreciation |  | 156 |  |  | 149 |  |  | 124 |  |  | 593 |  |  | 502 |  |
| Stock-based compensation |  | 1,314 |  |  | 1,388 |  |  | 638 |  |  | 5,741 |  |  | 2,171 |  |
| Deferred taxes and other non-cash taxes |  | (868) |  |  | 3,638 |  |  | 639 |  |  | 1,965 |  |  | (501) |  |
| Loss on debt extinguishment |  | 52 |  |  | 83 |  |  | — |  |  | 157 |  |  | — |  |
| Non-cash interest expense |  | 91 |  |  | 115 |  |  | 34 |  |  | 427 |  |  | 132 |  |
| Other |  | 138 |  |  | 158 |  |  | 27 |  |  | 404 |  |  | 9 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 249 |  |  | 835 |  |  | (231) |  |  | 2,327 |  |  | (187) |  |
| Inventory |  | 134 |  |  | (52) |  |  | (56) |  |  | 150 |  |  | 27 |  |
| Accounts payable |  | (85) |  |  | 373 |  |  | 215 |  |  | 121 |  |  | 209 |  |
| Employee compensation and benefits |  | 196 |  |  | 291 |  |  | 103 |  |  | 78 |  |  | (279) |  |
| Other current assets and current liabilities |  | (1,410) |  |  | (1,345) |  |  | (694) |  |  | (5,323) |  |  | (628) |  |
| Other long-term assets and long-term liabilities |  | (1,142) |  |  | (1,170) |  |  | (303) |  |  | (1,990) |  |  | (785) |  |
| Net cash provided by operating activities |  | 5,604 |  |  | 4,963 |  |  | 4,828 |  |  | 19,962 |  |  | 18,085 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (2) |  |  | (36) |  |  | (25,978) |  |  | (53) |  |
| Proceeds from sale of business |  | — |  |  | 3,485 |  |  | — |  |  | 3,485 |  |  | — |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (172) |  |  | (105) |  |  | (548) |  |  | (452) |  |
| Purchases of investments |  | (30) |  |  | (73) |  |  | (58) |  |  | (175) |  |  | (346) |  |
| Sales of investments |  | 20 |  |  | 5 |  |  | 154 |  |  | 156 |  |  | 228 |  |
| Other |  | — |  |  | 2 |  |  | (79) |  |  | (10) |  |  | (66) |  |
| Net cash provided by (used in) investing activities |  | (132) |  |  | 3,245 |  |  | (124) |  |  | (23,070) |  |  | (689) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 4,969 |  |  | 4,975 |  |  | — |  |  | 39,954 |  |  | — |  |
| Payments on debt obligations |  | (7,472) |  |  | (9,202) |  |  | (143) |  |  | (19,608) |  |  | (403) |  |
| Payments of dividends |  | (2,484) |  |  | (2,452) |  |  | (1,904) |  |  | (9,814) |  |  | (7,645) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | (123) |  |  | (7,176) |  |  | (5,824) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (1,204) |  |  | (1,350) |  |  | (454) |  |  | (5,216) |  |  | (1,861) |  |
| Issuance of common stock |  | 126 |  |  | — |  |  | 59 |  |  | 190 |  |  | 122 |  |
| Other |  | (11) |  |  | (36) |  |  | (5) |  |  | (63) |  |  | (12) |  |
| Net cash used in financing activities |  | (6,076) |  |  | (8,065) |  |  | (2,570) |  |  | (1,733) |  |  | (15,623) |  |
| Net change in cash and cash equivalents |  | (604) |  |  | 143 |  |  | 2,134 |  |  | (4,841) |  |  | 1,773 |  |
| Cash and cash equivalents at beginning of period |  | 9,952 |  |  | 9,809 |  |  | 12,055 |  |  | 14,189 |  |  | 12,416 |  |
| Cash and cash equivalents at end of period |  | $ | 9,348 |  |  | $ | 9,952 |  |  | $ | 14,189 |  |  | $ | 9,348 |  |  | $ | 14,189 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 738 |  |  | $ | 816 |  |  | $ | 397 |  |  | $ | 3,250 |  |  | $ | 1,503 |  |
| Cash paid for income taxes |  | $ | 832 |  |  | $ | 585 |  |  | $ | 191 |  |  | $ | 3,155 |  |  | $ | 1,782 |  |
