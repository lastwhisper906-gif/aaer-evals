# AVGO note change history — 0001730168-24-000080 → 0001730168-24-000099


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:1]
The following table summarizes contractual obligations and commitments as of August 4, 2024:
  (was, 2024-06-13, similarity 0.9595):
[0001730168-24-000080:note_history:1]
The following table summarizes contractual obligations and commitments as of May 5, 2024:

- changed (2024-09-11):
[0001730168-24-000099:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 4, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest and penalties as of August 4, 2024 have been excluded from the table above.
  (was, 2024-06-13, similarity 0.9028):
[0001730168-24-000080:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 5, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,209 million of unrecognized tax benefits and accrued interest and penalties as of May 5, 2024 have been excluded from the table above.

- changed (2024-09-11):
[0001730168-24-000099:note_history:3]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms pending approval by the California Court.
  (was, 2024-06-13, similarity 0.8777):
[0001730168-24-000080:note_history:3]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. We cannot reasonably estimate the ultimate outcome and believe a potential loss is not probable and the range of loss is not reasonably estimable. We intend to vigorously defend against this matter.

- added (2024-09-11):
[0001730168-24-000099:note_history:4]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

- added (2024-09-11):
[0001730168-24-000099:note_history:5]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

- removed (2024-09-11):
[0001730168-24-000080:note_history:6]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

- removed (2024-09-11):
[0001730168-24-000080:note_history:7]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-09-11):
[0001730168-24-000099:note_history:8]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 544 million shares of Broadcom common stock (on a split adjusted basis) with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.

- changed (2024-09-11):
[0001730168-24-000099:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 4, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.
  (was, 2024-06-13, similarity 0.9955):
[0001730168-24-000080:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 5, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.

- added (2024-09-11):
[0001730168-24-000099:note_history:10]
On July 12, 2024, we completed a ten-for-one forward stock split of our common stock through the filing of an amendment (“Amendment”) to our Amended and Restated Certificate of Incorporation. The Amendment proportionately increased the number of shares of our authorized common stock without changing the par value of $0.001 per share. All share, equity award and per share amounts and related stockholders’ equity balances presented in the accompanying condensed consolidated financial statements and notes thereto have been retroactively adjusted, where applicable, to reflect the stock split.

- removed (2024-09-11):
[0001730168-24-000080:note_history:11]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:12]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | $ | 1,250 |  |  | $ | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.03 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.23 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 19,195 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
  (was, 2024-06-13, similarity 0.88):
[0001730168-24-000080:note_history:12]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.10 | % |  | $ | 9,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.01 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.21 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 28,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:13]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 72,319 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,117 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 44 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 3,161 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 69,202 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 17 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,421) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,798 |  |  | $ | 37,621 |  |
  (was, 2024-06-13, similarity 0.9466):
[0001730168-24-000080:note_history:13]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 76,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 52 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,426 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 74,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 21 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,578) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 71,590 |  |  | $ | 37,621 |  |

- added (2024-09-11):
[0001730168-24-000099:note_history:14]
July 2024 Senior Notes

- added (2024-09-11):
[0001730168-24-000099:note_history:15]
In July 2024, we issued $1,250 million of 5.050% senior unsecured notes due July 2027, $2,250 million of 5.050% senior unsecured notes due July 2029 and $1,500 million of 5.150% senior unsecured notes due November 2031 (collectively, the “July 2024 Senior Notes”).

- added (2024-09-11):
[0001730168-24-000099:note_history:16]
We may redeem or purchase, in whole or in part, the July 2024 Senior Notes prior to their maturities, subject to a specified make-whole premium as set forth in the indenture. In the event of a change of control, note holders will have the right to require us to repurchase all or any part of the holders’ notes at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the July 2024 Senior Notes pays interest semi-annually.

- added (2024-09-11):
[0001730168-24-000099:note_history:17]
During the fiscal quarter ended May 5, 2024, we repaid $2,000 million of our Term A-2 Loan. During the fiscal quarter ended August 4, 2024, using the net proceeds from the July 2024 Senior Notes and the sale of the EUC business, as well as cash on hand, we repaid the remaining $9,195 million of our Term A-2 Loan. As a result, we wrote off unamortized discount and issuance costs of $83 million and $105 million during the fiscal quarter and three fiscal quarters ended August 4, 2024, respectively, which were included in interest expense in the condensed consolidated statements of operations.

- added (2024-09-11):
[0001730168-24-000099:note_history:18]
The 2023 Term Loans bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The Term A-3 Loan and Term A-5 Loan will mature and be payable on the third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

- changed (2024-09-11):
[0001730168-24-000099:note_history:19]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, note holders will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.
  (was, 2024-06-13, similarity 0.9782):
[0001730168-24-000080:note_history:19]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.

- changed (2024-09-11):
[0001730168-24-000099:note_history:20]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either August 4, 2024 or October 29, 2023.
  (was, 2024-06-13, similarity 0.9703):
[0001730168-24-000080:note_history:20]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either May 5, 2024 or October 29, 2023.

- changed (2024-09-11):
[0001730168-24-000099:note_history:21]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either August 4, 2024 or October 29, 2023.
  (was, 2024-06-13, similarity 0.9946):
[0001730168-24-000080:note_history:21]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either May 5, 2024 or October 29, 2023.

- changed (2024-09-11):
[0001730168-24-000099:note_history:22]
As of August 4, 2024, the estimated aggregate fair value of debt was $68,417 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2024-06-13, similarity 0.9887):
[0001730168-24-000080:note_history:22]
As of May 5, 2024, the estimated aggregate fair value of debt was $70,754 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

- changed (2024-09-11):
[0001730168-24-000099:note_history:23]
The future scheduled principal payments of debt as of August 4, 2024 were as follows:
  (was, 2024-06-13, similarity 0.956):
[0001730168-24-000080:note_history:23]
The future scheduled principal payments of debt as of May 5, 2024 were as follows:

- changed (2024-09-11):
[0001730168-24-000099:note_history:24]
As of August 4, 2024 and October 29, 2023, we were in compliance with all debt covenants.
  (was, 2024-06-13, similarity 0.9548):
[0001730168-24-000080:note_history:24]
As of May 5, 2024 and October 29, 2023, we were in compliance with all debt covenants.

- removed (2024-09-11):
[0001730168-24-000080:note_history:25]
The term loans under the Term A-2 Loan, Term A-3 Loan and Term A-5 Loan bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The term loans will mature and be payable on the second, third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

- removed (2024-09-11):
[0001730168-24-000080:note_history:26]
During the fiscal quarter ended May 5, 2024, we made a repayment of $2.0 billion on our Term A-2 Loan.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:27]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | $ | 1,250 |  |  | $ | — |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | — |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 5,000 |  |  | — |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.03 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.23 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 19,195 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
  (was, 2024-06-13, similarity 0.88):
[0001730168-24-000080:note_history:27]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.10 | % |  | $ | 9,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.01 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.21 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 28,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:28]
|  |  | Effective Interest Rate |  | August 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | — |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 6 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 72,319 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 3,117 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 44 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 3,161 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 69,202 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 17 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,421) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 66,798 |  |  | $ | 37,621 |  |
  (was, 2024-06-13, similarity 0.9466):
[0001730168-24-000080:note_history:28]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 76,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 52 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,426 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 74,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 21 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,578) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 71,590 |  |  | $ | 37,621 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:29]
The future scheduled principal payments of debt as of August 4, 2024 were as follows:
  (was, 2024-06-13, similarity 0.956):
[0001730168-24-000080:note_history:29]
The future scheduled principal payments of debt as of May 5, 2024 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:30]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |
  (was, 2024-06-13, similarity 0.9862):
[0001730168-24-000080:note_history:30]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:31]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |
  (was, 2024-06-13, similarity 0.9923):
[0001730168-24-000080:note_history:31]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:32]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |
  (was, 2024-06-13, similarity 0.9774):
[0001730168-24-000080:note_history:32]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:33]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |
  (was, 2024-06-13, similarity 0.9833):
[0001730168-24-000080:note_history:33]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:34]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |
  (was, 2024-06-13, similarity 0.9862):
[0001730168-24-000080:note_history:34]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:35]
|  |  | Fiscal Quarter Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 656 |  |  | $ | 5,773 |  |  | $ | 488 |  |  | $ | 6,917 |  |
| Subscriptions and services |  | 1,433 |  |  | 174 |  |  | 352 |  |  | 1,959 |  |
| Total |  | $ | 2,089 |  |  | $ | 5,947 |  |  | $ | 840 |  |  | $ | 8,876 |  |
  (was, 2024-06-13, similarity 0.9923):
[0001730168-24-000080:note_history:35]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:36]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |
  (was, 2024-06-13, similarity 0.9774):
[0001730168-24-000080:note_history:36]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:37]
|  |  | Three Fiscal Quarters Ended July 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,045 |  |  | $ | 17,168 |  |  | $ | 1,527 |  |  | $ | 20,740 |  |
| Subscriptions and services |  | 4,117 |  |  | 500 |  |  | 1,167 |  |  | 5,784 |  |
| Total |  | $ | 6,162 |  |  | $ | 17,668 |  |  | $ | 2,694 |  |  | $ | 26,524 |  |
  (was, 2024-06-13, similarity 0.9833):
[0001730168-24-000080:note_history:37]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:38]
|  |  | August 4,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 3,658 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 15,548 |  |  | $ | 2,786 |  |
  (was, 2024-06-13, similarity 0.9753):
[0001730168-24-000080:note_history:38]
|  |  | May 5,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 2,430 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 16,702 |  |  | $ | 2,786 |  |

- changed (2024-09-11):
[0001730168-24-000099:note_history:39]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of August 4, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of August 4, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million. The amount of revenue recognized during the three fiscal quarters ended July 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,677 million.
  (was, 2024-06-13, similarity 0.9824):
[0001730168-24-000080:note_history:39]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of May 5, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of May 5, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,965 million. The amount of revenue recognized during the two fiscal quarters ended April 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,287 million.

- changed (2024-09-11):
[0001730168-24-000099:note_history:40]
Certain multi-year customer contracts in our semiconductor solutions and infrastructure software segments contain firmly committed amounts and the remaining performance obligations under these contracts as of August 4, 2024 were approximately $21.2 billion. We expect approximately 44% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2024-06-13, similarity 0.9373):
[0001730168-24-000080:note_history:40]
Certain multi-year customer contracts contain firmly committed amounts and the remaining performance obligations under these contracts as of May 5, 2024 were approximately $22.9 billion. We expect approximately 49% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-09-11):
[0001730168-24-000099:note_history:41]
On September 4, 2024, our Board of Directors declared a quarterly cash dividend of $0.53 per share on our common stock, payable on September 30, 2024 to stockholders of record on September 19, 2024.
  (was, 2024-06-13, similarity 0.9038):
[0001730168-24-000080:note_history:41]
On June 11, 2024, our Board of Directors declared a quarterly cash dividend of $5.25 per share on our common stock, payable on June 28, 2024 to stockholders of record on June 24, 2024.

- removed (2024-09-11):
[0001730168-24-000080:note_history:42]
Common Stock Split

- removed (2024-09-11):
[0001730168-24-000080:note_history:43]
On June 12, 2024, we announced a ten-for-one forward stock split of our common stock. The stock split will be effected through the filing of an amendment to our Amended and Restated Certificate of Incorporation. Our stockholders of record after the close of market on July 11, 2024 will receive an additional nine shares of common stock for each share held after the close of market on July 12, 2024. At market open on July 15, 2024, trading is expected to commence on a split-adjusted basis.

- removed (2024-09-11):
[0001730168-24-000080:note_history:44]
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the ten-for-one stock split as if it had been effective for all periods presented:

- removed (2024-09-11):
[0001730168-24-000080:note_history:45]
|  |  | Pro Forma (Unaudited) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,395 |  |  | $ | 7,255 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Net income |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,650 |  |  | 4,150 |  |  | 4,580 |  |  | 4,170 |  |
| Dilutive effect of equity awards |  | 150 |  |  | 120 |  |  | 150 |  |  | 110 |  |
| Weighted-average shares outstanding - diluted |  | 4,800 |  |  | 4,270 |  |  | 4,730 |  |  | 4,280 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.74 |  |  | $ | 1.74 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 1.74 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.72 |  |  | $ | 1.70 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.73 |  |  | $ | 1.70 |  |
