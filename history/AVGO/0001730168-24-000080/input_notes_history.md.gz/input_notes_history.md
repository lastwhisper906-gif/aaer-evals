# AVGO note change history — 0001730168-24-000023 → 0001730168-24-000080


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:1]
The following table summarizes contractual obligations and commitments as of May 5, 2024:
  (was, 2024-03-14, similarity 0.96):
[0001730168-24-000023:note_history:1]
The following table summarizes contractual obligations and commitments as of February 4, 2024:

- changed (2024-06-13):
[0001730168-24-000080:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 5, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,209 million of unrecognized tax benefits and accrued interest and penalties as of May 5, 2024 have been excluded from the table above.
  (was, 2024-03-14, similarity 0.9771):
[0001730168-24-000023:note_history:2]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 4, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,220 million of unrecognized tax benefits and accrued interest and penalties as of February 4, 2024 have been excluded from the table above.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.
  (was, 2024-03-14, similarity 0.9876):
[0001730168-24-000023:note_history:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- changed (2024-06-13):
[0001730168-24-000080:note_history:4]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.
  (was, 2024-03-14, similarity 0.9873):
[0001730168-24-000023:note_history:4]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisition of VMware, Inc.” for additional information.

- changed (2024-06-13):
[0001730168-24-000080:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 5, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.
  (was, 2024-03-14, similarity 0.9955):
[0001730168-24-000023:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 4, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:6]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.10 | % |  | $ | 9,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.01 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.21 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 28,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
  (was, 2024-03-14, similarity 0.9978):
[0001730168-24-000023:note_history:6]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.11 | % |  | $ | 11,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.02 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.22 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 30,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

- changed (2024-06-13):
[0001730168-24-000080:note_history:7]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 76,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 52 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,426 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 74,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 21 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,578) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 71,590 |  |  | $ | 37,621 |  |
  (was, 2024-03-14, similarity 0.9973):
[0001730168-24-000023:note_history:7]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 78,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 59 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,433 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 76,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 39 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,718) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 73,468 |  |  | $ | 37,621 |  |

- changed (2024-06-13):
[0001730168-24-000080:note_history:8]
During the fiscal quarter ended May 5, 2024, we made a repayment of $2.0 billion on our Term A-2 Loan.
  (was, 2024-03-14, similarity 0.7853):
[0001730168-24-000023:note_history:8]
On March 5, 2024, we made a repayment of $2.0 billion on our Term A-2 Loan.

- changed (2024-06-13):
[0001730168-24-000080:note_history:9]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either May 5, 2024 or October 29, 2023.
  (was, 2024-03-14, similarity 0.9691):
[0001730168-24-000023:note_history:9]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either February 4, 2024 or October 29, 2023.

- changed (2024-06-13):
[0001730168-24-000080:note_history:10]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either May 5, 2024 or October 29, 2023.
  (was, 2024-03-14, similarity 0.9946):
[0001730168-24-000023:note_history:10]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either February 4, 2024 or October 29, 2023.

- changed (2024-06-13):
[0001730168-24-000080:note_history:11]
As of May 5, 2024, the estimated aggregate fair value of debt was $70,754 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2024-03-14, similarity 0.9888):
[0001730168-24-000023:note_history:11]
As of February 4, 2024, the estimated aggregate fair value of debt was $73,590 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

- changed (2024-06-13):
[0001730168-24-000080:note_history:12]
The future scheduled principal payments of debt as of May 5, 2024 were as follows:
  (was, 2024-03-14, similarity 0.9565):
[0001730168-24-000023:note_history:12]
The future scheduled principal payments of debt as of February 4, 2024 were as follows:

- changed (2024-06-13):
[0001730168-24-000080:note_history:13]
As of May 5, 2024 and October 29, 2023, we were in compliance with all debt covenants.
  (was, 2024-03-14, similarity 0.9554):
[0001730168-24-000023:note_history:13]
As of February 4, 2024 and October 29, 2023, we were in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:14]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.10 | % |  | $ | 9,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.01 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.21 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 28,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |
  (was, 2024-03-14, similarity 0.9978):
[0001730168-24-000023:note_history:14]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.11 | % |  | $ | 11,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.02 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.22 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 30,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

- changed (2024-06-13):
[0001730168-24-000080:note_history:15]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 76,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 52 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,426 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 74,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 21 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,578) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 71,590 |  |  | $ | 37,621 |  |
  (was, 2024-03-14, similarity 0.9973):
[0001730168-24-000023:note_history:15]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 78,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 59 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,433 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 76,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 39 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,718) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 73,468 |  |  | $ | 37,621 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:16]
The future scheduled principal payments of debt as of May 5, 2024 were as follows:
  (was, 2024-03-14, similarity 0.9565):
[0001730168-24-000023:note_history:16]
The future scheduled principal payments of debt as of February 4, 2024 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-06-13):
[0001730168-24-000080:note_history:17]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:18]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:19]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:20]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

- removed (2024-06-13):
[0001730168-24-000023:note_history:21]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

- removed (2024-06-13):
[0001730168-24-000023:note_history:22]
|  |  | Fiscal Quarter Ended January 29, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 609 |  |  | $ | 5,937 |  |  | $ | 536 |  |  | $ | 7,082 |  |
| Subscriptions and services |  | 1,230 |  |  | 200 |  |  | 403 |  |  | 1,833 |  |
| Total |  | $ | 1,839 |  |  | $ | 6,137 |  |  | $ | 939 |  |  | $ | 8,915 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-06-13):
[0001730168-24-000080:note_history:23]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:24]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:25]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

- added (2024-06-13):
[0001730168-24-000080:note_history:26]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

- changed (2024-06-13):
[0001730168-24-000080:note_history:27]
|  |  | May 5,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 2,430 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 16,702 |  |  | $ | 2,786 |  |
  (was, 2024-03-14, similarity 0.9754):
[0001730168-24-000023:note_history:27]
|  |  | February 4,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 1,647 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 15,451 |  |  | $ | 2,786 |  |

- changed (2024-06-13):
[0001730168-24-000080:note_history:28]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of May 5, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of May 5, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,965 million. The amount of revenue recognized during the two fiscal quarters ended April 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,287 million.
  (was, 2024-03-14, similarity 0.9717):
[0001730168-24-000023:note_history:28]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of February 4, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of February 4, 2024, approximately 39% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,313 million. The amount of revenue recognized during the fiscal quarter ended January 29, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $1,435 million.

- changed (2024-06-13):
[0001730168-24-000080:note_history:29]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).
  (was, 2024-03-14, similarity 0.732):
[0001730168-24-000023:note_history:29]
services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- changed (2024-06-13):
[0001730168-24-000080:note_history:30]
Certain multi-year customer contracts contain firmly committed amounts and the remaining performance obligations under these contracts as of May 5, 2024 were approximately $22.9 billion. We expect approximately 49% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2024-03-14, similarity 0.9923):
[0001730168-24-000023:note_history:30]
Certain multi-year customer contracts contain firmly committed amounts and the remaining performance obligations under these contracts as of February 4, 2024 were approximately $27.7 billion. We expect approximately 44% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2024-06-13):
[0001730168-24-000023:note_history:31]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

- removed (2024-06-13):
[0001730168-24-000023:note_history:32]
|  |  | Fiscal Quarter Ended January 29, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 609 |  |  | $ | 5,937 |  |  | $ | 536 |  |  | $ | 7,082 |  |
| Subscriptions and services |  | 1,230 |  |  | 200 |  |  | 403 |  |  | 1,833 |  |
| Total |  | $ | 1,839 |  |  | $ | 6,137 |  |  | $ | 939 |  |  | $ | 8,915 |  |

- removed (2024-06-13):
[0001730168-24-000023:note_history:33]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-06-13):
[0001730168-24-000080:note_history:34]
On June 11, 2024, our Board of Directors declared a quarterly cash dividend of $5.25 per share on our common stock, payable on June 28, 2024 to stockholders of record on June 24, 2024.
  (was, 2024-03-14, similarity 0.9184):
[0001730168-24-000023:note_history:34]
On March 6, 2024, our Board of Directors declared a quarterly cash dividend of $5.25 per share on our common stock, payable on March 29, 2024 to stockholders of record on March 21, 2024.

- added (2024-06-13):
[0001730168-24-000080:note_history:35]
Common Stock Split

- added (2024-06-13):
[0001730168-24-000080:note_history:36]
On June 12, 2024, we announced a ten-for-one forward stock split of our common stock. The stock split will be effected through the filing of an amendment to our Amended and Restated Certificate of Incorporation. Our stockholders of record after the close of market on July 11, 2024 will receive an additional nine shares of common stock for each share held after the close of market on July 12, 2024. At market open on July 15, 2024, trading is expected to commence on a split-adjusted basis.

- added (2024-06-13):
[0001730168-24-000080:note_history:37]
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the ten-for-one stock split as if it had been effective for all periods presented:

- added (2024-06-13):
[0001730168-24-000080:note_history:38]
|  |  | Pro Forma (Unaudited) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,395 |  |  | $ | 7,255 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Net income |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,650 |  |  | 4,150 |  |  | 4,580 |  |  | 4,170 |  |
| Dilutive effect of equity awards |  | 150 |  |  | 120 |  |  | 150 |  |  | 110 |  |
| Weighted-average shares outstanding - diluted |  | 4,800 |  |  | 4,270 |  |  | 4,730 |  |  | 4,280 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.74 |  |  | $ | 1.74 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 1.74 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.72 |  |  | $ | 1.70 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.73 |  |  | $ | 1.70 |  |
