# AVGO notes — 0001730168-24-000080


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-24-000080:notes:1]
[same as prior period, unchanged from 0001730168-24-000023:notes:1]

[0001730168-24-000080:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-24-000080:notes:3]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisitions” for additional information.

[0001730168-24-000080:notes:4]
[same as prior period, unchanged from 0001730168-24-000023:notes:4]

[0001730168-24-000080:notes:5]
[same as prior period, unchanged from 0001730168-24-000023:notes:5]

[0001730168-24-000080:notes:6]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 5, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.

[0001730168-24-000080:notes:7]
[same as prior period, unchanged from 0001730168-24-000023:notes:7]

[0001730168-24-000080:notes:8]
[same as prior period, unchanged from 0001730168-24-000023:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-24-000080:notes:9]
[same as prior period, unchanged from 0001730168-24-000023:notes:9]

[0001730168-24-000080:notes:10]
[same as prior period, unchanged from 0001730168-24-000023:notes:10]

[0001730168-24-000080:notes:11]
[same as prior period, unchanged from 0001730168-24-000023:notes:11]

[0001730168-24-000080:notes:12]
[same as prior period, unchanged from 0001730168-24-000023:notes:12]

[0001730168-24-000080:notes:13]
|  |  | Fiscal Quarter Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 473 |  |  | $ | 6,267 |  |  | $ | 452 |  |  | $ | 7,192 |  |
| Subscriptions and services |  | 3,401 |  |  | 487 |  |  | 1,407 |  |  | 5,295 |  |
| Total |  | $ | 3,874 |  |  | $ | 6,754 |  |  | $ | 1,859 |  |  | $ | 12,487 |  |

[0001730168-24-000080:notes:14]
|  |  | Fiscal Quarter Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 780 |  |  | $ | 5,458 |  |  | $ | 503 |  |  | $ | 6,741 |  |
| Subscriptions and services |  | 1,454 |  |  | 126 |  |  | 412 |  |  | 1,992 |  |
| Total |  | $ | 2,234 |  |  | $ | 5,584 |  |  | $ | 915 |  |  | $ | 8,733 |  |

[0001730168-24-000080:notes:15]
|  |  | Two Fiscal Quarters Ended May 5, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,181 |  |  | $ | 12,458 |  |  | $ | 965 |  |  | $ | 14,604 |  |
| Subscriptions and services |  | 5,778 |  |  | 993 |  |  | 3,073 |  |  | 9,844 |  |
| Total |  | $ | 6,959 |  |  | $ | 13,451 |  |  | $ | 4,038 |  |  | $ | 24,448 |  |

[0001730168-24-000080:notes:16]
|  |  | Two Fiscal Quarters Ended April 30, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,389 |  |  | $ | 11,395 |  |  | $ | 1,039 |  |  | $ | 13,823 |  |
| Subscriptions and services |  | 2,684 |  |  | 326 |  |  | 815 |  |  | 3,825 |  |
| Total |  | $ | 4,073 |  |  | $ | 11,721 |  |  | $ | 1,854 |  |  | $ | 17,648 |  |

[0001730168-24-000080:notes:17]
[same as prior period, unchanged from 0001730168-24-000023:notes:15]

[0001730168-24-000080:notes:18]
[same as prior period, unchanged from 0001730168-24-000023:notes:16]

[0001730168-24-000080:notes:19]
[same as prior period, unchanged from 0001730168-24-000023:notes:17]

[0001730168-24-000080:notes:20]
|  |  | May 5,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 2,430 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 16,702 |  |  | $ | 2,786 |  |

[0001730168-24-000080:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of May 5, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of May 5, 2024, approximately 50% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,965 million. The amount of revenue recognized during the two fiscal quarters ended April 30, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $2,287 million.

[0001730168-24-000080:notes:22]
[same as prior period, unchanged from 0001730168-24-000023:notes:20]

[0001730168-24-000080:notes:23]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-24-000080:notes:24]
Certain multi-year customer contracts contain firmly committed amounts and the remaining performance obligations under these contracts as of May 5, 2024 were approximately $22.9 billion. We expect approximately 49% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-24-000080:notes:25]
Acquisitions
Acquisition of VMware, Inc.

[0001730168-24-000080:notes:26]
On November 22, 2023, we completed the VMware Merger. Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash or 0.2520 shares of Broadcom common stock. The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the VMware Merger. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million.

[0001730168-24-000080:notes:27]
[same as prior period, unchanged from 0001730168-24-000023:notes:25]

[0001730168-24-000080:notes:28]
[same as prior period, unchanged from 0001730168-24-000023:notes:26]

[0001730168-24-000080:notes:29]
[same as prior period, unchanged from 0001730168-24-000023:notes:27]

[0001730168-24-000080:notes:30]
[same as prior period, unchanged from 0001730168-24-000023:notes:28]

[0001730168-24-000080:notes:31]
[same as prior period, unchanged from 0001730168-24-000023:notes:29]

[0001730168-24-000080:notes:32]
The following table presents our preliminary allocation of the total purchase price, net of cash acquired, updated as of May 5, 2024:

[0001730168-24-000080:notes:33]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Trade accounts receivable |  | $ | 3,571 |  |
| Inventory |  | 15 |
| Assets held-for-sale |  | 5,206 |  |
| Other current assets |  | 757 |  |
| Property, plant and equipment |  | 531 |  |
| Goodwill |  | 54,206 |  |
| Intangible assets |  | 45,572 |  |
| Other long-term assets |  | 1,064 |  |
| Total assets acquired |  | 110,922 |  |
| Accounts payable |  | (359) |  |
| Employee compensation and benefits |  | (848) |  |
| Current portion of long-term debt |  | (1,264) |  |
| Liabilities held-for-sale |  | (1,901) |  |
| Other current liabilities |  | (11,041) |  |
| Long-term debt |  | (6,254) |  |
| Other long-term liabilities |  | (9,607) |  |
| Total liabilities assumed |  | (31,274) |  |
| Fair value of net assets acquired |  | $ | 79,648 |  |

[0001730168-24-000080:notes:34]
[same as prior period, unchanged from 0001730168-24-000023:notes:32]

[0001730168-24-000080:notes:35]
Assets and liabilities held-for-sale primarily included VMware’s end-user computing (“EUC”) business and certain other assets and liabilities, which were not aligned with our strategic objectives. We do not expect to have significant continuing involvement after disposal and have presented the results in discontinued operations. In February 2024, we signed a definitive agreement to sell EUC for approximately $3.8 billion, before working capital adjustments and estimated selling costs. The sale is expected to close in calendar year 2024, subject to customary closing conditions.

[0001730168-24-000080:notes:36]
Our results of continuing operations included $2,674 million and $4,776 million of net revenue attributable to VMware for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. It is impracticable to determine the effect on net income attributable to VMware as we have integrated a substantial portion of VMware into our ongoing operations. Transaction costs related to the VMware Merger of $20 million and $240 million, respectively, were primarily included in selling, general and administrative expense for the fiscal quarter and two fiscal quarters ended May 5, 2024.

[0001730168-24-000080:notes:37]
[same as prior period, unchanged from 0001730168-24-000023:notes:35]

[0001730168-24-000080:notes:38]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 24,156 |  |  | 8 |
| Customer contracts and related relationships |  | 15,239 |  |  | 8 |
| Trade name |  | 1,205 |  |  | 14 |
| Off-market component of customer contracts |  | 242 |  |  | 2 |
| Total identified finite-lived intangible assets |  | 40,842 |  |  |  |
| In-process research and development |  | 4,730 |  |  | N/A |
| Total identified intangible assets |  | $ | 45,572 |  |  |  |

[0001730168-24-000080:notes:39]
[same as prior period, unchanged from 0001730168-24-000023:notes:37]

[0001730168-24-000080:notes:40]
[same as prior period, unchanged from 0001730168-24-000023:notes:38]

[0001730168-24-000080:notes:41]
[same as prior period, unchanged from 0001730168-24-000023:notes:39]

[0001730168-24-000080:notes:42]
[same as prior period, unchanged from 0001730168-24-000023:notes:40]

[0001730168-24-000080:notes:43]
[same as prior period, unchanged from 0001730168-24-000023:notes:41]

[0001730168-24-000080:notes:44]
[same as prior period, unchanged from 0001730168-24-000023:notes:42]

[0001730168-24-000080:notes:45]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| VMware cloud foundation July 2024 releases |  | $ | 790 |  |  | 67 | % |  | $ | 38 |  |  | 2024 |
| VMware cloud foundation March 2025 releases |  | $ | 2,900 |  |  | 58 | % |  | $ | 185 |  |  | 2025 |
| VMware cloud foundation July 2025 releases |  | $ | 750 |  |  | 43 | % |  | $ | 65 |  |  | 2025 |
| VMware cloud foundation networking and security virtualization |  | $ | 265 |  |  | 21 | % |  | $ | 59 |  |  | 2024 |
| Application networking and security |  | $ | 25 |  |  | 21 | % |  | $ | 47 |  |  | 2024 |

[0001730168-24-000080:notes:46]
[same as prior period, unchanged from 0001730168-24-000023:notes:44]

[0001730168-24-000080:notes:47]
[same as prior period, unchanged from 0001730168-24-000023:notes:45]

[0001730168-24-000080:notes:48]
[same as prior period, unchanged from 0001730168-24-000023:notes:46]

[0001730168-24-000080:notes:49]
[same as prior period, unchanged from 0001730168-24-000023:notes:47]

[0001730168-24-000080:notes:50]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 12,507 |  |  | $ | 11,665 |  |  | $ | 25,030 |  |  | $ | 23,889 |  |
| Pro forma net income |  | $ | 2,261 |  |  | $ | 1,796 |  |  | $ | 3,876 |  |  | $ | 3,849 |  |

[0001730168-24-000080:notes:51]
Acquisition of Seagate’s SoC Operations

[0001730168-24-000080:notes:52]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip (“SoC”) operations of Seagate Technology Holdings plc for $600 million. We acquired these assets to strengthen our portfolio of SoC products.

[0001730168-24-000080:notes:53]
The following table presents our preliminary allocation of the total purchase price. Goodwill is allocated to the semiconductor solutions segment and is deductible for tax purposes.

[0001730168-24-000080:notes:54]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Intangible assets |  | $ | 570 |  |
| Goodwill |  | 14 |  |
| Other assets |  | 16 |  |
| Total assets acquired |  | $ | 600 |  |

[0001730168-24-000080:notes:55]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Customer contracts and related relationships |  | $ | 410 |  |  | 11 |
| Developed technology |  | 90 |  |  | 11 |
| Total identified finite-lived intangible assets |  | 500 |  |  |  |
| In-process research and development |  | 70 |  |  | N/A |
| Total identified intangible assets |  | $ | 570 |  |  |  |

[0001730168-24-000080:notes:56]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of SoC controller products for hard disk drive applications. Customer contracts and related relationships were valued using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the customer contracts and related relationships less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the useful lives of other intangible assets and the length of time remaining on the acquired contracts.

[0001730168-24-000080:notes:57]
Developed technology relates to SoC controller products for hard disk drive applications. We valued the developed technology using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the developed technology. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.
The fair value of IPR&D was determined using the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue from the IPR&D.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-24-000080:notes:58]
[same as prior period, unchanged from 0001730168-24-000023:notes:49]

[0001730168-24-000080:notes:59]
Cash equivalents included $1,382 million and $1,470 million of time deposits and $1,438 million and $1,650 million of money-market funds as of May 5, 2024 and October 29, 2023, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-24-000080:notes:60]
[same as prior period, unchanged from 0001730168-24-000023:notes:51]

[0001730168-24-000080:notes:61]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,250 million and $2,500 million during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, and $900 million and $1,925 million during the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively.

[0001730168-24-000080:notes:62]
[same as prior period, unchanged from 0001730168-24-000023:notes:53]

[0001730168-24-000080:notes:63]
|  |  | May 5,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Finished goods |  | $ | 569 |  |  | $ | 676 |  |
| Work-in-process |  | 866 |  |  | 901 |  |
| Raw materials |  | 407 |  |  | 321 |  |
| Total inventory |  | $ | 1,842 |  |  | $ | 1,898 |  |

[0001730168-24-000080:notes:64]
[same as prior period, unchanged from 0001730168-24-000023:notes:55]

[0001730168-24-000080:notes:65]
In connection with the VMware Merger, we classified VMware’s EUC business and certain other assets and liabilities, which were not aligned with our strategic objectives, as assets and liabilities held-for-sale. The carrying value of these assets and liabilities as of May 5, 2024 represented the fair value determined in the preliminary purchase price allocation of the VMware Merger, adjusted for operating activities since the date of the VMware Merger. As of May 5, 2024, the carrying values of these assets, net of liabilities, approximated the expected selling prices.

[0001730168-24-000080:notes:66]
|  |  | May 5, 2024 |
|  |  | EUC |  | Other |  | Total |
|  |  | (In millions) |
| Assets held-for-sale: |  |  |  |  |  |  |
| Goodwill |  | $ | 2,268 |  |  | $ | — |  |  | $ | 2,268 |  |
| Intangible assets, net |  | 2,545 |  |  | — |  |  | 2,545 |  |
| Other assets |  | 57 |  |  | 351 |  |  | 408 |  |
| Total assets held-for-sale |  | $ | 4,870 |  |  | $ | 351 |  |  | $ | 5,221 |  |
| Liabilities held-for-sale: |  | $ | 1,581 |  |  | $ | 176 |  |  | $ | 1,757 |  |

[0001730168-24-000080:notes:67]
[same as prior period, unchanged from 0001730168-24-000023:notes:58]

[0001730168-24-000080:notes:68]
[same as prior period, unchanged from 0001730168-24-000023:notes:59]

[0001730168-24-000080:notes:69]
|  |  | Fiscal Quarter Ended May 5, 2024 |  | Two Fiscal Quarters Ended May 5, 2024 |  |  |
|  |  | (In millions) |
| Net revenue |  | $ | 329 |  |  |  |  |  |  | $ | 680 |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations before income taxes |  | $ | 11 |  |  |  |  |  |  | $ | 69 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | (11) |  |  |  |  |  |  | (18) |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | $ | — |  |  |  |  |  |  | $ | 51 |  |  |  |  |  |  |  |  |  |

[0001730168-24-000080:notes:70]
[same as prior period, unchanged from 0001730168-24-000023:notes:61]

[0001730168-24-000080:notes:71]
|  |  | May 5,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Assets held-for-sale |  | $ | 5,221 |  |  | $ | — |  |
| Prepaid expenses |  | 1,742 |  |  | 743 |  |
| Other |  | 1,188 |  |  | 863 |  |
| Total other current assets |  | $ | 8,151 |  |  | $ | 1,606 |  |

[0001730168-24-000080:notes:72]
[same as prior period, unchanged from 0001730168-24-000023:notes:63]

[0001730168-24-000080:notes:73]
|  |  | May 5,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 10,519 |  |  | $ | 2,487 |  |
| Liabilities held-for-sale |  | 1,757 |  |  | — |  |
| Tax liabilities |  | 1,127 |  |  | 473 |  |
| Interest payable |  | 450 |  |  | 380 |  |
| Other |  | 1,066 |  |  | 312 |  |
| Total other current liabilities |  | $ | 14,919 |  |  | $ | 3,652 |  |

[0001730168-24-000080:notes:74]
[same as prior period, unchanged from 0001730168-24-000023:notes:65]

[0001730168-24-000080:notes:75]
|  |  | May 5,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,209 |  |  | $ | 2,792 |  |
| Contract liabilities |  | 6,183 |  |  | 299 |  |
| Deferred tax liabilities |  | 2,219 |  |  | 99 |  |
| Other |  | 1,878 |  |  | 657 |  |
| Total other long-term liabilities |  | $ | 13,489 |  |  | $ | 3,847 |  |

[0001730168-24-000080:notes:76]
[same as prior period, unchanged from 0001730168-24-000023:notes:67]

[0001730168-24-000080:notes:77]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 946 |  |  | $ | 397 |  |  | $ | 1,696 |  |  | $ | 758 |  |
| Cash paid for income taxes |  | $ | 834 |  |  | $ | 891 |  |  | $ | 1,738 |  |  | $ | 1,164 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-24-000080:notes:78]
[same as prior period, unchanged from 0001730168-24-000023:notes:69]

[0001730168-24-000080:notes:79]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |  |
|  |  |  |  |  |  |  |  |  |  | (In millions) |  |
| Balance as of October 29, 2023 |  |  |  |  |  |  |  |  |  | $ | 26,001 |  |  | $ | 17,652 |  |  | $ | 43,653 |  |  |
| Acquisition of VMware |  |  |  |  |  |  |  |  |  | — |  |  | 54,206 |  |  | 54,206 |  |  |
| Acquisition of Seagate’s SoC operations |  |  |  |  |  |  |  |  |  | 14 |  |  | — |  |  | 14 |  |  |
| Balance as of May 5, 2024 |  |  |  |  |  |  |  |  |  | $ | 26,015 |  |  | $ | 71,858 |  |  | $ | 97,873 |  |  |

[0001730168-24-000080:notes:80]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of May 5, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 37,193 |  |  | $ | (13,616) |  |  | $ | 23,577 |  |
| Customer contracts and related relationships |  | 22,950 |  |  | (7,397) |  |  | 15,553 |  |
| Trade names |  | 1,854 |  |  | (445) |  |  | 1,409 |  |
| Other |  | 177 |  |  | (109) |  |  | 68 |  |
| Intangible assets subject to amortization |  | 62,174 |  |  | (21,567) |  |  | 40,607 |  |
| In-process research and development |  | 4,800 |  |  | — |  |  | 4,800 |  |
| Total |  | $ | 66,974 |  |  | $ | (21,567) |  |  | $ | 45,407 |  |
| As of October 29, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 12,938 |  |  | $ | (10,723) |  |  | $ | 2,215 |  |
| Customer contracts and related relationships |  | 7,059 |  |  | (5,753) |  |  | 1,306 |  |
| Trade names |  | 649 |  |  | (388) |  |  | 261 |  |
| Other |  | 177 |  |  | (102) |  |  | 75 |  |
| Intangible assets subject to amortization |  | 20,823 |  |  | (16,966) |  |  | 3,857 |  |
| In-process research and development |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 20,833 |  |  | $ | (16,966) |  |  | $ | 3,867 |  |

[0001730168-24-000080:notes:81]
Based on the amount of intangible assets subject to amortization as of May 5, 2024, the expected amortization expense was as follows:

[0001730168-24-000080:notes:82]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 4,728 |  |
| 2025 |  | 7,604 |  |
| 2026 |  | 7,035 |  |
| 2027 |  | 6,065 |  |
| 2028 |  | 5,051 |  |
| Thereafter |  | 10,124 |  |
| Total |  | $ | 40,607 |  |

[0001730168-24-000080:notes:83]
[same as prior period, unchanged from 0001730168-24-000023:notes:74]

[0001730168-24-000080:notes:84]
| Amortizable intangible assets: |  | May 5,2024 |
|  |  | (In years) |
| Purchased technology |  | 7 |
| Customer contracts and related relationships |  | 7 |
| Trade names |  | 13 |
| Other |  | 7 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-24-000080:notes:85]
[same as prior period, unchanged from 0001730168-24-000023:notes:76]

[0001730168-24-000080:notes:86]
[same as prior period, unchanged from 0001730168-24-000023:notes:77]

[0001730168-24-000080:notes:87]
[same as prior period, unchanged from 0001730168-24-000023:notes:78]

[0001730168-24-000080:notes:88]
[same as prior period, unchanged from 0001730168-24-000023:notes:79]

[0001730168-24-000080:notes:89]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,395 |  |  | $ | 7,255 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Net income |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 465 |  | 415 |  | 458 |  | 417 |
| Dilutive effect of equity awards |  | 15 |  | 12 |  | 15 |  | 11 |
| Weighted-average shares outstanding - diluted |  | 480 |  | 427 |  | 473 |  | 428 |

[0001730168-24-000080:notes:90]
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.56 |  |  | $ | 8.39 |  |  | $ | 7.41 |  |  | $ | 17.40 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.11 |  |  | — |  |
| Net income per share |  | $ | 4.56 |  |  | $ | 8.39 |  |  | $ | 7.52 |  |  | $ | 17.40 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.42 |  |  | $ | 8.15 |  |  | $ | 7.18 |  |  | $ | 16.95 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.11 |  |  | — |  |
| Net income per share |  | $ | 4.42 |  |  | $ | 8.15 |  |  | $ | 7.29 |  |  | $ | 16.95 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-24-000080:notes:91]
Borrowings

[0001730168-24-000080:notes:92]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.10 | % |  | $ | 9,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.01 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.21 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 28,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

[0001730168-24-000080:notes:93]
|  |  | Effective Interest Rate |  | May 5,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 76,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 52 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,426 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 74,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 21 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,578) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 71,590 |  |  | $ | 37,621 |  |

[0001730168-24-000080:notes:94]
2023 Term Loans

[0001730168-24-000080:notes:95]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered an $11,195 million unsecured term A-2 facility (the "Term A-2 Loan”), an $11,195 million unsecured term A-3 facility (the “Term A-3 Loan”), and an $8,000 million unsecured term A-5 facility (the “Term A-5 Loan”, collectively, the “2023 Term Loans”).

[0001730168-24-000080:notes:96]
The term loans under the Term A-2 Loan, Term A-3 Loan and Term A-5 Loan bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The term loans will mature and be payable on the second, third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

[0001730168-24-000080:notes:97]
During the fiscal quarter ended May 5, 2024, we made a repayment of $2.0 billion on our Term A-2 Loan.

[0001730168-24-000080:notes:98]
Assumed VMware Senior Notes

[0001730168-24-000080:notes:99]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.

[0001730168-24-000080:notes:100]
2021 Credit Agreement

[0001730168-24-000080:notes:101]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either May 5, 2024 or October 29, 2023.

[0001730168-24-000080:notes:102]
Commercial Paper

[0001730168-24-000080:notes:103]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either May 5, 2024 or October 29, 2023.

[0001730168-24-000080:notes:104]
Fair Value of Debt

[0001730168-24-000080:notes:105]
As of May 5, 2024, the estimated aggregate fair value of debt was $70,754 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-24-000080:notes:106]
Future Principal Payments of Debt

[0001730168-24-000080:notes:107]
The future scheduled principal payments of debt as of May 5, 2024 were as follows:

[0001730168-24-000080:notes:108]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 1,879 |  |
| 2025 |  | 1,245 |  |
| 2026 |  | 12,347 |  |
| 2027 |  | 16,082 |  |
| 2028 |  | 3,395 |  |
| Thereafter |  | 41,573 |  |
| Total |  | $ | 76,521 |  |

[0001730168-24-000080:notes:109]
As of May 5, 2024 and October 29, 2023, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-24-000080:notes:110]
[same as prior period, unchanged from 0001730168-24-000023:notes:101]

[0001730168-24-000080:notes:111]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 5.25 |  |  | $ | 4.60 |  |  | $ | 10.50 |  |  | $ | 9.20 |  |
| Dividends to common stockholders |  | $ | 2,443 |  |  | $ | 1,914 |  |  | $ | 4,878 |  |  | $ | 3,840 |  |

[0001730168-24-000080:notes:112]
[same as prior period, unchanged from 0001730168-24-000023:notes:103]

[0001730168-24-000080:notes:113]
We repurchased and retired approximately 7 million shares of our common stock for $7,176 million during the fiscal quarter ended February 4, 2024 which completed all $20 billion under our previously authorized stock repurchase programs prior to expiration on December 31, 2023. During the fiscal quarter and two fiscal quarters ended April 30, 2023, we repurchased and retired approximately 5 million and 7 million shares of our common stock for $2,806 million and $3,994 million, respectively.

[0001730168-24-000080:notes:114]
[same as prior period, unchanged from 0001730168-24-000023:notes:105]

[0001730168-24-000080:notes:115]
In connection with the VMware Merger, we assumed the VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan (the “2007 Plan”) and outstanding unvested RSU awards and PSU awards originally granted by VMware under the 2007 Plan that were held by continuing employees. These assumed awards were converted into approximately 5 million Broadcom RSU awards and will vest in accordance with their original terms, generally over 4 years. Under the 2007 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock, RSUs, and other stock-based or cash-based awards to employees. Equity awards granted under the 2007 Plan following the VMware Merger are expected to be on similar terms and consistent with similar grants made pursuant to our Amended and Restated Broadcom Inc. 2012 Stock Incentive Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of May 5, 2024, 5 million shares remained available for issuance under the 2007 Plan.

[0001730168-24-000080:notes:116]
[same as prior period, unchanged from 0001730168-24-000023:notes:107]

[0001730168-24-000080:notes:117]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 28 |  |  | $ | 22 |  |  | $ | 56 |  |  | $ | 38 |  |
| Cost of subscriptions and services |  | 142 |  |  | 28 |  |  | 275 |  |  | 49 |  |
| Research and development |  | 881 |  |  | 354 |  |  | 1,744 |  |  | 621 |  |
| Selling, general and administrative |  | 352 |  |  | 109 |  |  | 900 |  |  | 196 |  |
| Total stock-based compensation expense (a) |  | $ | 1,403 |  |  | $ | 513 |  |  | $ | 2,975 |  |  | $ | 904 |  |

[0001730168-24-000080:notes:118]
[same as prior period, unchanged from 0001730168-24-000023:notes:109]

[0001730168-24-000080:notes:119]
(a) Does not include $66 million and $136 million of stock-based compensation during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statements of operations.

[0001730168-24-000080:notes:120]
For the fiscal quarter and two fiscal quarters ended May 5, 2024, stock-based compensation expense included $387 million and $1,097 million, respectively, related to equity awards assumed in connection with the VMware Merger. For the two fiscal quarters ended May 5, 2024, stock-based compensation expense related to equity awards assumed included a one-time impact from aligning the vesting dates of equity awards assumed with our RSU vesting dates, as well as expenses related to accelerated vesting of certain equity awards held by employees terminated in connection with the VMware Merger.

[0001730168-24-000080:notes:121]
As of May 5, 2024, the total unrecognized compensation cost related to unvested stock-based awards was $13,811 million, which is expected to be recognized over the remaining weighted-average service period of 3.3 years.

[0001730168-24-000080:notes:122]
[same as prior period, unchanged from 0001730168-24-000023:notes:113]

[0001730168-24-000080:notes:123]
[same as prior period, unchanged from 0001730168-24-000023:notes:114]

[0001730168-24-000080:notes:124]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 29, 2023 |  | 22 |  |  | $ | 389.21 |  |  |  |  |  |
| Assumed in VMware Merger |  | 5 |  |  | $ | 968.52 |  |  |  |  |  |
| Granted |  | 7 |  |  | $ | 1,121.01 |  |  |  |  |  |
| Vested |  | (6) |  |  | $ | 473.17 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 801.25 |  |  |  |  |  |
| Balance as of May 5, 2024 |  | 27 |  |  | $ | 654.06 |  |  |  |  |  |

[0001730168-24-000080:notes:125]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended May 5, 2024 was $7,127 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-24-000080:notes:126]
Income Taxes
The benefit from income taxes was $116 million and $48 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The benefit from income taxes was primarily due to excess tax benefits from stock-based awards and a shift in the jurisdictional mix of income and expense, partially offset by income tax expense on operations.

[0001730168-24-000080:notes:127]
The provision for income taxes was $235 million and $301 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively. The provision for income taxes was primarily driven by income before income taxes, partially offset by excess tax benefits from stock-based awards and the recognition of uncertain tax benefits as a result of lapses of statutes of limitations.

[0001730168-24-000080:notes:128]
As of May 5, 2024, we had $6,178 million of gross unrecognized tax benefits and accrued interest and penalties. It is possible that our existing unrecognized tax benefits may change up to $702 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations, and changes in balances related to tax positions to be taken during the current fiscal year.

[0001730168-24-000080:notes:129]
Subsequent to the close of the fiscal quarter ended May 5, 2024, we completed an intra-group transfer of certain IP rights to the United States through a supply chain realignment. We estimate that we will recognize a discrete tax expense of up to $4.9 billion during the fiscal quarter ending August 4, 2024 from the establishment of a deferred tax liability as a result of the book and tax basis difference on these IP rights. We are continuing to evaluate the impact of the intra-group transfer on our estimated annual effective tax rate and income tax provision.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-24-000080:notes:130]
[same as prior period, unchanged from 0001730168-24-000023:notes:121]

[0001730168-24-000080:notes:131]
[same as prior period, unchanged from 0001730168-24-000023:notes:122]

[0001730168-24-000080:notes:132]
[same as prior period, unchanged from 0001730168-24-000023:notes:123]

[0001730168-24-000080:notes:133]
Infrastructure software. We provide a portfolio of software solutions that enables customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical FC SAN products and related software.

[0001730168-24-000080:notes:134]
[same as prior period, unchanged from 0001730168-24-000023:notes:125]

[0001730168-24-000080:notes:135]
[same as prior period, unchanged from 0001730168-24-000023:notes:126]

[0001730168-24-000080:notes:136]
[same as prior period, unchanged from 0001730168-24-000023:notes:127]

[0001730168-24-000080:notes:137]
[same as prior period, unchanged from 0001730168-24-000023:notes:128]

[0001730168-24-000080:notes:138]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 7,202 |  |  | $ | 6,808 |  |  | $ | 14,592 |  |  | $ | 13,915 |  |
| Infrastructure software |  | 5,285 |  |  | 1,925 |  |  | 9,856 |  |  | 3,733 |  |
| Total net revenue |  | $ | 12,487 |  |  | $ | 8,733 |  |  | $ | 24,448 |  |  | $ | 17,648 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 3,978 |  |  | $ | 4,000 |  |  | $ | 8,094 |  |  | $ | 8,123 |  |
| Infrastructure software |  | 3,168 |  |  | 1,412 |  |  | 5,883 |  |  | 2,719 |  |
| Unallocated expenses |  | (4,181) |  |  | (1,404) |  |  | (8,929) |  |  | (2,731) |  |
| Total operating income |  | $ | 2,965 |  |  | $ | 4,008 |  |  | $ | 5,048 |  |  | $ | 8,111 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-24-000080:notes:139]
Commitments and Contingencies
Commitments

[0001730168-24-000080:notes:140]
The following table summarizes contractual obligations and commitments as of May 5, 2024:

[0001730168-24-000080:notes:141]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 209 |  |  | $ | 268 |  |
| 2025 |  | 186 |  |  | 405 |  |
| 2026 |  | 248 |  |  | 407 |  |
| 2027 |  | 7 |  |  | 338 |  |
| 2028 |  | 7 |  |  | 296 |  |
| Thereafter |  | — |  |  | 1,146 |  |
| Total |  | $ | 657 |  |  | $ | 2,860 |  |

[0001730168-24-000080:notes:142]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-24-000080:notes:143]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to information technology and other service agreements.

[0001730168-24-000080:notes:144]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 5, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,209 million of unrecognized tax benefits and accrued interest and penalties as of May 5, 2024 have been excluded from the table above.

[0001730168-24-000080:notes:145]
Contingencies

[0001730168-24-000080:notes:146]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-24-000080:notes:147]
Lawsuits Relating to VMware Backlog

[0001730168-24-000080:notes:148]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. We cannot reasonably estimate the ultimate outcome and believe a potential loss is not probable and the range of loss is not reasonably estimable. We intend to vigorously defend against this matter.

[0001730168-24-000080:notes:149]
Other Matters

[0001730168-24-000080:notes:150]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-24-000080:notes:151]
Contingency Assessment

[0001730168-24-000080:notes:152]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-24-000080:notes:153]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-24-000080:notes:154]
Other Indemnifications

[0001730168-24-000080:notes:155]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-24-000080:notes:156]
Restructuring and Other Charges
In connection with the VMware Merger, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized $345 million and $1,057 million of restructuring charges primarily related to employee termination costs during the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses in continuing operations.

[0001730168-24-000080:notes:157]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the two fiscal quarters ended May 5, 2024:

[0001730168-24-000080:notes:158]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 29, 2023 |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Restructuring charges (a)(b) |  | 976 |  |  | 81 |  |  | 1,057 |  |
| Utilization |  | (773) |  |  | (81) |  |  | (854) |  |
| Balance as of May 5, 2024 |  | $ | 205 |  |  | $ | — |  |  | $ | 205 |  |

[0001730168-24-000080:notes:159]
(a) Lease and impairment costs included the write-down of $51 million lease-related assets and $30 million of asset impairments and other costs.

[0001730168-24-000080:notes:160]
(b) Does not include $27 million of restructuring charges related to discontinued operations, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statements of operations.


## us-gaap:SubsequentEventsTextBlock

[0001730168-24-000080:notes:161]
Subsequent Events
Cash Dividends Declared

[0001730168-24-000080:notes:162]
On June 11, 2024, our Board of Directors declared a quarterly cash dividend of $5.25 per share on our common stock, payable on June 28, 2024 to stockholders of record on June 24, 2024.

[0001730168-24-000080:notes:163]
Common Stock Split

[0001730168-24-000080:notes:164]
On June 12, 2024, we announced a ten-for-one forward stock split of our common stock. The stock split will be effected through the filing of an amendment to our Amended and Restated Certificate of Incorporation. Our stockholders of record after the close of market on July 11, 2024 will receive an additional nine shares of common stock for each share held after the close of market on July 12, 2024. At market open on July 15, 2024, trading is expected to commence on a split-adjusted basis.

[0001730168-24-000080:notes:165]
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the ten-for-one stock split as if it had been effective for all periods presented:

[0001730168-24-000080:notes:166]
|  |  | Pro Forma (Unaudited) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,395 |  |  | $ | 7,255 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 51 |  |  | — |  |
| Net income |  | $ | 2,121 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,650 |  |  | 4,150 |  |  | 4,580 |  |  | 4,170 |  |
| Dilutive effect of equity awards |  | 150 |  |  | 120 |  |  | 150 |  |  | 110 |  |
| Weighted-average shares outstanding - diluted |  | 4,800 |  |  | 4,270 |  |  | 4,730 |  |  | 4,280 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.74 |  |  | $ | 1.74 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.46 |  |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 1.74 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.72 |  |  | $ | 1.70 |  |
| Income per share from discontinued operations |  | — |  |  | — |  |  | 0.01 |  |  | — |  |
| Net income per share |  | $ | 0.44 |  |  | $ | 0.82 |  |  | $ | 0.73 |  |  | $ | 1.70 |  |
