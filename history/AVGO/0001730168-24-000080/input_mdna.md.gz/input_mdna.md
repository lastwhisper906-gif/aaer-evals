# AVGO MD&A — 0001730168-24-000080


## mdna

[0001730168-24-000080:mdna:1]
[same as prior period, unchanged from 0001730168-24-000023:mdna:1]

[0001730168-24-000080:mdna:2]
[same as prior period, unchanged from 0001730168-24-000023:mdna:2]

[0001730168-24-000080:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-24-000080:mdna:4]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and IP licensing. Our infrastructure software segment includes our application development and delivery, application networking and security, mainframe, distributed, software-defined edge, private and hybrid cloud and cyber security solutions, and our FC SAN business.

[0001730168-24-000080:mdna:5]
Our fiscal year ending November 3, 2024 (“fiscal year 2024”), is a 53-week fiscal year, with our first fiscal quarter ended February 4, 2024 containing 14 weeks compared to 13 weeks in the prior year fiscal period. The additional week resulted in higher net revenue, gross margin dollars, research and development expense, and selling general and administrative expense in the first fiscal quarter and first two fiscal quarters of fiscal year 2024, compared to the corresponding prior year fiscal periods.

[0001730168-24-000080:mdna:6]
[same as prior period, unchanged from 0001730168-24-000023:mdna:6]

[0001730168-24-000080:mdna:7]
Highlights during the fiscal quarter ended May 5, 2024 include the following:

[0001730168-24-000080:mdna:8]
•We generated $4,580 million of cash from operations.

[0001730168-24-000080:mdna:9]
•We paid $2,443 million in cash dividends.

[0001730168-24-000080:mdna:10]
•We repaid $2.0 billion on our unsecured term A-2 facility.

[0001730168-24-000080:mdna:11]
Acquisitions

[0001730168-24-000080:mdna:12]
[same as prior period, unchanged from 0001730168-24-000023:mdna:13]

[0001730168-24-000080:mdna:13]
On November 22, 2023, we acquired VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. In addition, we assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding RSU awards held by non-employee directors and in-the-money VMware stock options were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000080:mdna:14]
Acquisition of Seagate’s SoC Operations

[0001730168-24-000080:mdna:15]
On April 23, 2024, we acquired certain assets related to the design, development, and manufacture of System-on-Chip (“SoC”) operations of Seagate Technology Holdings plc for $600 million. We acquired these assets to strengthen our portfolio of SoC products.

[0001730168-24-000080:mdna:16]
[same as prior period, unchanged from 0001730168-24-000023:mdna:15]

[0001730168-24-000080:mdna:17]
[same as prior period, unchanged from 0001730168-24-000023:mdna:16]

[0001730168-24-000080:mdna:18]
There were no significant changes in our critical accounting estimates during the two fiscal quarters ended May 5, 2024 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2023 Annual Report on Form 10-K.

[0001730168-24-000080:mdna:19]
[same as prior period, unchanged from 0001730168-24-000023:mdna:18]

[0001730168-24-000080:mdna:20]
Fiscal Quarter and Two Fiscal Quarters Ended May 5, 2024 Compared to Fiscal Quarter and Two Fiscal Quarters Ended April 30, 2023

[0001730168-24-000080:mdna:21]
[same as prior period, unchanged from 0001730168-24-000023:mdna:20]

[0001730168-24-000080:mdna:22]
|  |  | Fiscal Quarter Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 7,192 |  |  | $ | 6,741 |  |  | 58 | % |  | 77 | % |
| Subscriptions and services |  | 5,295 |  |  | 1,992 |  |  | 42 |  |  | 23 |  |
| Total net revenue |  | 12,487 |  |  | 8,733 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,429 |  |  | 2,019 |  |  | 19 |  |  | 23 |  |
| Cost of subscriptions and services |  | 713 |  |  | 158 |  |  | 6 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,516 |  |  | 441 |  |  | 13 |  |  | 5 |  |
| Restructuring charges |  | 53 |  |  | — |  |  | — |  |  | — |  |
| Total cost of revenue |  | 4,711 |  |  | 2,618 |  |  | 38 |  |  | 30 |  |
| Gross margin |  | 7,776 |  |  | 6,115 |  |  | 62 |  |  | 70 |  |
| Research and development |  | 2,415 |  |  | 1,312 |  |  | 19 |  |  | 15 |  |
| Selling, general and administrative |  | 1,277 |  |  | 438 |  |  | 10 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 827 |  |  | 348 |  |  | 7 |  |  | 4 |  |
| Restructuring and other charges |  | 292 |  |  | 9 |  |  | 2 |  |  | — |  |
| Total operating expenses |  | 4,811 |  |  | 2,107 |  |  | 38 |  |  | 24 |  |
| Operating income |  | $ | 2,965 |  |  | $ | 4,008 |  |  | 24 | % |  | 46 | % |

[0001730168-24-000080:mdna:23]
30

[0001730168-24-000080:mdna:24]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 14,604 |  |  | $ | 13,823 |  |  | 60 | % |  | 78 | % |
| Subscriptions and services |  | 9,844 |  |  | 3,825 |  |  | 40 |  |  | 22 |  |
| Total net revenue |  | 24,448 |  |  | 17,648 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,589 |  |  | 4,244 |  |  | 19 |  |  | 24 |  |
| Cost of subscriptions and services |  | 1,667 |  |  | 307 |  |  | 7 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 2,896 |  |  | 976 |  |  | 11 |  |  | 5 |  |
| Restructuring charges |  | 145 |  |  | 2 |  |  | 1 |  |  | — |  |
| Total cost of revenue |  | 9,297 |  |  | 5,529 |  |  | 38 |  |  | 31 |  |
| Gross margin |  | 15,151 |  |  | 12,119 |  |  | 62 |  |  | 69 |  |
| Research and development |  | 4,723 |  |  | 2,507 |  |  | 19 |  |  | 14 |  |
| Selling, general and administrative |  | 2,849 |  |  | 786 |  |  | 11 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,619 |  |  | 696 |  |  | 7 |  |  | 4 |  |
| Restructuring and other charges |  | 912 |  |  | 19 |  |  | 4 |  |  | — |  |
| Total operating expenses |  | 10,103 |  |  | 4,008 |  |  | 41 |  |  | 23 |  |
| Operating income |  | $ | 5,048 |  |  | $ | 8,111 |  |  | 21 | % |  | 46 | % |

[0001730168-24-000080:mdna:25]
[same as prior period, unchanged from 0001730168-24-000023:mdna:22]

[0001730168-24-000080:mdna:26]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one customer, which is a distributor, accounted for 29% and 28% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, and 17% and 19% of our net revenue for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively.

[0001730168-24-000080:mdna:27]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 5, 2024, and approximately 35% of our net revenue for each of the fiscal quarter and two fiscal quarters ended April 30, 2023. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-24-000080:mdna:28]
[same as prior period, unchanged from 0001730168-24-000023:mdna:25]

[0001730168-24-000080:mdna:29]
31

[0001730168-24-000080:mdna:30]
[same as prior period, unchanged from 0001730168-24-000023:mdna:26]

[0001730168-24-000080:mdna:31]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | May 5, 2024 |  | April 30, 2023 |  | $ Change |  | % Change |  | May 5, 2024 |  | April 30, 2023 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 7,202 |  |  | $ | 6,808 |  |  | $ | 394 |  |  | 6 | % |  | $ | 14,592 |  |  | $ | 13,915 |  |  | $ | 677 |  |  | 5 | % |
| Infrastructure software |  | 5,285 |  |  | 1,925 |  |  | 3,360 |  |  | 175 | % |  | 9,856 |  |  | 3,733 |  |  | 6,123 |  |  | 164 | % |
| Total net revenue |  | $ | 12,487 |  |  | $ | 8,733 |  |  | $ | 3,754 |  |  | 43 | % |  | $ | 24,448 |  |  | $ | 17,648 |  |  | $ | 6,800 |  |  | 39 | % |

[0001730168-24-000080:mdna:32]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 5,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 58 | % |  | 78 | % |  | 60 | % |  | 79 | % |
| Infrastructure software |  | 42 |  |  | 22 |  |  | 40 |  |  | 21 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-24-000080:mdna:33]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended May 5, 2024 compared to the prior year fiscal periods due to strong product demand for our networking products, including products in AI networking, partially offset by lower demand for our broadband and server storage products. Net revenue from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended May 5, 2024 compared to the prior year fiscal periods primarily due to contributions from VMware.

[0001730168-24-000080:mdna:34]
[same as prior period, unchanged from 0001730168-24-000023:mdna:30]

[0001730168-24-000080:mdna:35]
Gross margin was $7,776 million for the fiscal quarter ended May 5, 2024 compared to $6,115 million for the fiscal quarter ended April 30, 2023, and $15,151 million for the two fiscal quarters ended May 5, 2024 compared to $12,119 million for the two fiscal quarters ended April 30, 2023. The increases were primarily due to contributions from VMware, partially offset by higher amortization of acquisition-related intangible assets from the VMware Merger.

[0001730168-24-000080:mdna:36]
As a percentage of net revenue, gross margin was 62% of net revenue for each of the fiscal quarter and two fiscal quarters ended May 5, 2024, and 70% and 69% for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively. The decreases were primarily due to higher amortization of acquisition-related intangible assets from the VMware Merger. In addition, gross margin contributions from our infrastructure software segment were partially offset by less favorable margin within the semiconductor solutions segment driven by product mix.

[0001730168-24-000080:mdna:37]
[same as prior period, unchanged from 0001730168-24-000023:mdna:33]

[0001730168-24-000080:mdna:38]
Research and development expense increased $1,103 million, or 84%, and $2,216 million, or 88%, for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increases in stock-based compensation expense were also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000080:mdna:39]
[same as prior period, unchanged from 0001730168-24-000023:mdna:35]

[0001730168-24-000080:mdna:40]
Selling, general and administrative expense increased $839 million, or 192%, and $2,063 million, or 262%, for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher compensation, including higher stock-based compensation, as a result of an increase in headcount from the VMware Merger. The increases in stock-based compensation expense were also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000080:mdna:41]
[same as prior period, unchanged from 0001730168-24-000023:mdna:37]

[0001730168-24-000080:mdna:42]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $479 million, or 138%, and $923 million, or 133%, for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, compared to the prior year fiscal periods primarily due to higher amortization of customer-related intangible assets from the VMware Merger.

[0001730168-24-000080:mdna:43]
[same as prior period, unchanged from 0001730168-24-000023:mdna:39]

[0001730168-24-000080:mdna:44]
Restructuring and other charges recognized in operating expenses were $292 million and $912 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, primarily due to employee termination costs associated with the VMware Merger. We expect to incur additional restructuring and other charges in future periods as a result of the VMware Merger.

[0001730168-24-000080:mdna:45]
[same as prior period, unchanged from 0001730168-24-000023:mdna:41]

[0001730168-24-000080:mdna:46]
Total stock-based compensation expense was $1,403 million and $2,975 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, and $513 million and $904 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively. The increases were primarily due to equity awards assumed and granted in connection with the VMware Merger and annual employee equity awards granted at higher grant-date fair values. Stock-based compensation expense for the two fiscal quarters ended May 5, 2024 also included a one-time impact from aligning the vesting dates of certain assumed awards with our RSU vesting dates, as well as accelerated vesting of certain assumed awards held by employees terminated in connection with the VMware Merger.

[0001730168-24-000080:mdna:47]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of May 5, 2024. The remaining weighted-average service period was 3.3 years.

[0001730168-24-000080:mdna:48]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 2,658 |  |
| 2025 |  | 4,476 |  |
| 2026 |  | 3,598 |  |
| 2027 |  | 2,604 |  |
| 2028 |  | 475 |  |
| Total |  | $ | 13,811 |  |

[0001730168-24-000080:mdna:49]
[same as prior period, unchanged from 0001730168-24-000023:mdna:45]

[0001730168-24-000080:mdna:50]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | May 5,2024 |  | April 30,2023 |  | $ Change |  | % Change |  | May 5, 2024 |  | April 30, 2023 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 3,978 |  |  | $ | 4,000 |  |  | $ | (22) |  |  | (1) | % |  | $ | 8,094 |  |  | $ | 8,123 |  |  | $ | (29) |  |  | — | % |
| Infrastructure software |  | 3,168 |  |  | 1,412 |  |  | 1,756 |  |  | 124 | % |  | 5,883 |  |  | 2,719 |  |  | 3,164 |  |  | 116 | % |
| Unallocated expenses |  | (4,181) |  |  | (1,404) |  |  | (2,777) |  |  | 198 | % |  | (8,929) |  |  | (2,731) |  |  | (6,198) |  |  | 227 | % |
| Total operating income |  | $ | 2,965 |  |  | $ | 4,008 |  |  | $ | (1,043) |  |  | (26) | % |  | $ | 5,048 |  |  | $ | 8,111 |  |  | $ | (3,063) |  |  | (38) | % |

[0001730168-24-000080:mdna:51]
Operating income from our semiconductor solutions segment was relatively flat for the fiscal quarter ended May 5, 2024 compared to the prior year fiscal period. Higher engineering project costs and lower gross margins driven by product mix were partially offset by higher revenue from networking products. Operating income from our semiconductor solutions segment was also relatively flat for the two fiscal quarters ended May 5, 2024 compared to the prior year fiscal period. Higher compensation expense as a result of an additional week in the current year fiscal quarter and lower gross margins driven by product mix were offset by higher revenue from networking products. Higher operating income from our infrastructure software segment in the fiscal quarter and two fiscal quarters ended May 5, 2024 compared to the prior year fiscal periods was primarily due to contributions from VMware.

[0001730168-24-000080:mdna:52]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 198% and 227% for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, compared to the prior year fiscal periods primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense and restructuring and other charges. These increases were primarily due to the VMware Merger. The increase in stock-based compensation expense was also due to annual employee equity awards granted at higher grant-date fair values.

[0001730168-24-000080:mdna:53]
[same as prior period, unchanged from 0001730168-24-000023:mdna:49]

[0001730168-24-000080:mdna:54]
Interest expense. Interest expense was $1,047 million and $1,973 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively, and $405 million and $811 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively. The increases were primarily due to interest on debt incurred for the VMware Merger.

[0001730168-24-000080:mdna:55]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $87 million and $113 million for the fiscal quarters ended May 5, 2024 and April 30, 2023, respectively. The decrease was primarily due to lower interest income as a result of a lower invested balance, partially offset by higher interest rates. Other income, net, was $272 million and $256 million for the two fiscal quarters ended May 5, 2024 and April 30, 2023, respectively. The increase was primarily due to higher interest income as a result of higher interest rates, partially offset by a lower invested balance.

[0001730168-24-000080:mdna:56]
Provision for (benefit from) income taxes. The benefit from income taxes was $116 million and $48 million for the fiscal quarter and two fiscal quarters ended May 5, 2024, respectively. The benefit from income taxes was primarily due to excess tax benefits from stock-based awards and a shift in the jurisdictional mix of income and expense, partially offset by income tax expense on operations. The provision for income taxes was $235 million and $301 million for the fiscal quarter and two fiscal quarters ended April 30, 2023, respectively. The provision for income taxes was primarily driven by income before income taxes, partially offset by excess tax benefits from stock-based awards and the recognition of uncertain tax benefits as a result of lapses of statutes of limitations.

[0001730168-24-000080:mdna:57]
[same as prior period, unchanged from 0001730168-24-000023:mdna:53]

[0001730168-24-000080:mdna:58]
[same as prior period, unchanged from 0001730168-24-000023:mdna:54]

[0001730168-24-000080:mdna:59]
Our primary sources of liquidity as of May 5, 2024 consisted of: (i) $9,809 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time. In February 2024, we signed a definitive agreement to sell VMware’s end-user computing business for approximately $3.8 billion, before working capital adjustments and estimated selling costs. The sale is expected to close in calendar year 2024, subject to customary closing conditions.

[0001730168-24-000080:mdna:60]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $76,521 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. Our debt and liquidity needs increased in fiscal year 2024 as a result of completing the VMware Merger. We funded the cash portion of the consideration with net proceeds from the issuance of $30,390 million in term loans (the “2023 Term Loans”), as well as cash on hand. We also assumed $8,250 million of VMware’s outstanding senior unsecured notes. During the fiscal quarter ended May 5, 2024, we made a partial repayment of $2.0 billion on our 2023 Term Loans. We also expect capital expenditures to be higher in fiscal year 2024 as compared to fiscal year 2023.

[0001730168-24-000080:mdna:61]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-24-000080:mdna:62]
[same as prior period, unchanged from 0001730168-24-000023:mdna:58]

[0001730168-24-000080:mdna:63]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such

[0001730168-24-000080:mdna:64]
tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. We may also make additional prepayments of the 2023 Term Loans. The amounts involved may be material.

[0001730168-24-000080:mdna:65]
[same as prior period, unchanged from 0001730168-24-000023:mdna:60]

[0001730168-24-000080:mdna:66]
On November 22, 2023, we completed the VMware Merger. The following table presents the changes in selected balance sheet captions other than assets acquired and liabilities assumed from the VMware Merger during the two fiscal quarters ended May 5, 2024.

[0001730168-24-000080:mdna:67]
|  |  | Balances at October 29, 2023 |  | Balances Acquired and Assumed from VMware |  | Balances at May 5, 2024 |  | Non-VMware Acquisition Increase (Decrease) |
|  |  | (In millions) |
| Cash and cash equivalents |  | $ | 14,189 |  |  | $ | 6,642 |  |  | $ | 9,809 |  |  | $ | (11,022) |  |
| Trade accounts receivable, net |  | $ | 3,154 |  |  | $ | 3,571 |  |  | $ | 5,500 |  |  | $ | (1,225) |  |
| Assets held-for-sale |  | $ | — |  |  | $ | 5,206 |  |  | $ | 5,221 |  |  | $ | 15 |  |
| Other current assets |  | $ | 1,606 |  |  | $ | 757 |  |  | $ | 2,930 |  |  | $ | 567 |  |
| Employee compensation and benefits |  | $ | 935 |  |  | $ | 848 |  |  | $ | 1,385 |  |  | $ | (398) |  |
| Current portion of long-term debt |  | $ | 1,608 |  |  | $ | 1,264 |  |  | $ | 2,426 |  |  | $ | (446) |  |
| Liabilities held-for-sale |  | $ | — |  |  | $ | 1,901 |  |  | $ | 1,757 |  |  | $ | (144) |  |
| Other current liabilities |  | $ | 3,652 |  |  | $ | 11,041 |  |  | $ | 13,162 |  |  | $ | (1,531) |  |

[0001730168-24-000080:mdna:68]
•Cash and cash equivalents decreased primarily due to $32,058 million paid for the VMware Merger, $7,176 million of common stock repurchases, $4,878 million of dividend payments and $2,662 million of employee withholding tax payments related to net settled equity awards, offset in part by $27,076 million in net proceeds from borrowings and $9,395 million in net cash provided by operating activities.

[0001730168-24-000080:mdna:69]
[same as prior period, unchanged from 0001730168-24-000023:mdna:64]

[0001730168-24-000080:mdna:70]
[same as prior period, unchanged from 0001730168-24-000023:mdna:65]

[0001730168-24-000080:mdna:71]
[same as prior period, unchanged from 0001730168-24-000023:mdna:66]

[0001730168-24-000080:mdna:72]
[same as prior period, unchanged from 0001730168-24-000023:mdna:67]

[0001730168-24-000080:mdna:73]
[same as prior period, unchanged from 0001730168-24-000023:mdna:68]

[0001730168-24-000080:mdna:74]
[same as prior period, unchanged from 0001730168-24-000023:mdna:69]

[0001730168-24-000080:mdna:75]
[same as prior period, unchanged from 0001730168-24-000023:mdna:70]

[0001730168-24-000080:mdna:76]
|  |  | Two Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 10.50 |  |  | $ | 9.20 |  |
| Dividends to common stockholders |  | $ | 4,878 |  |  | $ | 3,840 |  |

[0001730168-24-000080:mdna:77]
During each of the two fiscal quarters ended May 5, 2024 and April 30, 2023, we repurchased and retired approximately 7 million shares of our common stock for $7,176 million and $3,994 million, respectively. All $20 billion under our previously authorized stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000080:mdna:78]
During the two fiscal quarters ended May 5, 2024 and April 30, 2023, we paid approximately $2,662 million and $947 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the two fiscal quarters ended May 5, 2024 and April 30, 2023.

[0001730168-24-000080:mdna:79]
[same as prior period, unchanged from 0001730168-24-000023:mdna:74]

[0001730168-24-000080:mdna:80]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | April 30,2023 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 9,395 |  |  | $ | 8,538 |  |
| Net cash used in investing activities |  | (26,183) |  |  | (421) |  |
| Net cash provided by (used in) financing activities |  | 12,408 |  |  | (8,980) |  |
| Net change in cash and cash equivalents |  | $ | (4,380) |  |  | $ | (863) |  |

[0001730168-24-000080:mdna:81]
[same as prior period, unchanged from 0001730168-24-000023:mdna:76]

[0001730168-24-000080:mdna:82]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $857 million increase in cash provided by operations during the two fiscal quarters ended May 5, 2024 compared to the prior year fiscal period was primarily due to contributions from VMware. The $3,809 million decrease in net income was largely driven by $5,427 million of higher non-cash adjustments including amortization of intangible assets and stock-based compensation.

[0001730168-24-000080:mdna:83]
[same as prior period, unchanged from 0001730168-24-000023:mdna:78]

[0001730168-24-000080:mdna:84]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures and proceeds and payments related to investments. The $25,762 million increase in cash used in investing activities during the two fiscal quarters ended May 5, 2024 compared to the prior year fiscal period was primarily due to $25,976 million cash paid in connection with the VMware Merger and the acquisition of Seagate’s SoC operations, net of cash acquired.

[0001730168-24-000080:mdna:85]
[same as prior period, unchanged from 0001730168-24-000023:mdna:80]

[0001730168-24-000080:mdna:86]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, stock repurchases, dividend payments and employee withholding tax payments related to net settled equity awards. The $21,388 million increase in cash flows from financing activities during the two fiscal quarters ended May 5, 2024 compared to the prior year fiscal period was primarily due to $30,010 million of net proceeds from the 2023 Term Loans, partially offset by a $3,182 million increase in stock repurchases, a $2,674 million increase in payments of debt obligations, a $1,715 million increase in employee withholding tax payments related to net settled equity awards and a $1,038 million increase in dividend payments.
