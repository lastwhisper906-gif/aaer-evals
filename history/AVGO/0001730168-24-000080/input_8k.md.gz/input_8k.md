# AVGO 8-K — 0001730168-24-000077 filed 2024-06-12

## item codes, every 8-K on or before 2024-06-13

- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2024-06-13

- none on or before 2024-06-13

## item 2.02 — earnings release, exhibit 99.1

[0001730168-24-000077:8k_2_02:1]
EX-99.1
2
avgo-05052024x8kxex99.htm
EX-99.1

[0001730168-24-000077:8k_2_02:2]
Document

[0001730168-24-000077:8k_2_02:3]
Exhibit 99.1

[0001730168-24-000077:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2024 Financial Results and Quarterly Dividend

[0001730168-24-000077:8k_2_02:5]
•Revenue of $12,487 million for the second quarter, up 43 percent from the prior year period

[0001730168-24-000077:8k_2_02:6]
•GAAP net income of $2,121 million for the second quarter; Non-GAAP net income of $5,394 million for the second quarter

[0001730168-24-000077:8k_2_02:7]
•Adjusted EBITDA of $7,429 million for the second quarter, or 59 percent of revenue

[0001730168-24-000077:8k_2_02:8]
•GAAP diluted EPS of $4.42 for the second quarter; Non-GAAP diluted EPS of $10.96 for the second quarter

[0001730168-24-000077:8k_2_02:9]
•Cash from operations of $4,580 million for the second quarter, less capital expenditures of $132 million, resulted in $4,448 million of free cash flow, or 36 percent of revenue

[0001730168-24-000077:8k_2_02:10]
•Quarterly common stock dividend of $5.25 per share

[0001730168-24-000077:8k_2_02:11]
•Fiscal 2024 annual revenue guidance of approximately $51.0 billion including contribution from VMware, an increase of 42 percent from the prior year period

[0001730168-24-000077:8k_2_02:12]
•Fiscal 2024 annual Adjusted EBITDA guidance of approximately 61 percent of projected revenue (1)

[0001730168-24-000077:8k_2_02:13]
•Ten-for-one forward stock split; trading on a split-adjusted basis is expected to commence on July 15, 2024

[0001730168-24-000077:8k_2_02:14]
PALO ALTO, Calif. – June 12, 2024 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2024, ended May 5, 2024, provided guidance for its fiscal year 2024 and announced its quarterly dividend.

[0001730168-24-000077:8k_2_02:15]
“Broadcom’s second quarter results were once again driven by AI demand and VMware. Revenue from our AI products was a record $3.1 billion during the quarter. Infrastructure software revenue accelerated as more enterprises adopted the VMware software stack to build their own private clouds,” said Hock Tan, President and CEO of Broadcom Inc. “We are raising our fiscal year 2024 guidance for consolidated revenue to $51 billion and adjusted EBITDA to 61% of revenue.”

[0001730168-24-000077:8k_2_02:16]
“Consolidated revenue grew 43% year-over-year to $12.5 billion, including the contribution from VMware, and was up 12% year-over-year, excluding VMware. Adjusted EBITDA increased 31% year-over-year to $7.4 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow, excluding restructuring and integration in the quarter, was $5.3 billion, up 18% year-over-year. Today we are announcing a ten-for-one forward stock split of Broadcom’s common stock, to make ownership of Broadcom stock more accessible to investors and employees.”

[0001730168-24-000077:8k_2_02:17]
The ten-for-one forward stock split will be effected through the filing of an amendment to Broadcom’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock. Our stockholders of record after the close of market on July 11, 2024 will receive an additional nine shares of common stock for each share held after the close of market on July 12, 2024. At market open on July 15, 2024, trading is expected to commence on a split-adjusted basis.

[0001730168-24-000077:8k_2_02:18]
________________________________

[0001730168-24-000077:8k_2_02:19]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-24-000077:8k_2_02:20]
1

[0001730168-24-000077:8k_2_02:21]
Second Quarter Fiscal Year 2024 Financial Highlights

[0001730168-24-000077:8k_2_02:22]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q2 24 |  | Q2 23 |  | Change |  | Q2 24 |  | Q2 23 |  | Change |
| Net revenue |  | $ | 12,487 |  |  | $ | 8,733 |  |  | +43 | % |  | $ | 12,487 |  |  | $ | 8,733 |  |  | +43 | % |
| Net income |  | $ | 2,121 |  |  | $ | 3,481 |  |  | -$1,360 |  |  | $ | 5,394 |  |  | $ | 4,489 |  |  | +$905 |  |
| Earnings per common share - diluted |  | $ | 4.42 |  |  | $ | 8.15 |  |  | -$3.73 |  |  | $ | 10.96 |  |  | $ | 10.32 |  |  | +$0.64 |  |

[0001730168-24-000077:8k_2_02:23]
| (Dollars in millions) |  | Q2 24 |  | Q2 23 |  | Change |  |
| Cash flow from operations |  | $ | 4,580 |  |  | $ | 4,502 |  |  | +$78 |  |
| Adjusted EBITDA |  | $ | 7,429 |  |  | $ | 5,686 |  |  | +$1,743 |  |
| Free cash flow |  | $ | 4,448 |  |  | $ | 4,380 |  |  | +$68 |  |

[0001730168-24-000077:8k_2_02:24]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q2 24 |  |  |  | Q2 23 |  | Change |  |
| Semiconductor solutions |  | $ | 7,202 |  |  | 58 | % |  |  |  |  |  |  | $ | 6,808 |  |  | 78 | % |  | +6 | % |  |
| Infrastructure software |  | 5,285 |  |  | 42 |  |  |  |  |  |  |  | 1,925 |  |  | 22 |  |  | +175 | % |  |
| Total net revenue |  | $ | 12,487 |  |  | 100 | % |  |  |  |  |  |  | $ | 8,733 |  |  | 100 | % |  |  |  |  |

[0001730168-24-000077:8k_2_02:25]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,809 million, compared to $11,864 million at the end of the prior quarter.

[0001730168-24-000077:8k_2_02:26]
During the second fiscal quarter, the Company generated $4,580 million in cash from operations and spent $132 million on capital expenditures. The Company paid $1,548 million of withholding taxes related to net settled equity awards that vested in the quarter (representing approximately 1.2 million shares withheld).

[0001730168-24-000077:8k_2_02:27]
On March 29, 2024, the Company paid a cash dividend of $5.25 per share, totaling $2,443 million.

[0001730168-24-000077:8k_2_02:28]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-24-000077:8k_2_02:29]
Fiscal Year 2024 Business Outlook

[0001730168-24-000077:8k_2_02:30]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2024, ending November 3, 2024, including the contribution from VMware, is expected to be as follows:

[0001730168-24-000077:8k_2_02:31]
•Fiscal year 2024 revenue guidance of approximately $51.0 billion; and

[0001730168-24-000077:8k_2_02:32]
•Fiscal year 2024 Adjusted EBITDA guidance of approximately 61 percent of projected revenue.

[0001730168-24-000077:8k_2_02:33]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000077:8k_2_02:34]
2

[0001730168-24-000077:8k_2_02:35]
Quarterly Dividends

[0001730168-24-000077:8k_2_02:36]
The Company’s Board of Directors has approved a quarterly cash dividend of $5.25 per share. The dividend is payable on June 28, 2024 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 24, 2024.

[0001730168-24-000077:8k_2_02:37]
Financial Results Conference Call

[0001730168-24-000077:8k_2_02:38]
Broadcom Inc. will host a conference call to review its financial results for the second quarter of fiscal year 2024 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-24-000077:8k_2_02:39]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-24-000077:8k_2_02:40]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BId8ff937a59494fdca3650de7ed2678a1. Upon registering, a link to the dial-in number and unique PIN will be emailed to the registrant.

[0001730168-24-000077:8k_2_02:41]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-24-000077:8k_2_02:42]
Non-GAAP Financial Measures

[0001730168-24-000077:8k_2_02:43]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-24-000077:8k_2_02:44]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-24-000077:8k_2_02:45]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors

[0001730168-24-000077:8k_2_02:46]
3

[0001730168-24-000077:8k_2_02:47]
should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-24-000077:8k_2_02:48]
About Broadcom

[0001730168-24-000077:8k_2_02:49]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-24-000077:8k_2_02:50]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-24-000077:8k_2_02:51]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our acquisition of VMware, Inc., including employee retention, unexpected costs, charges or expenses, and our ability to successfully integrate VMware’s business and realize the expected benefits; any acquisitions or dispositions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and resellers of our products; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of security systems; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; involvement in legal proceedings; demand for our

[0001730168-24-000077:8k_2_02:52]
4

[0001730168-24-000077:8k_2_02:53]
data center virtualization products; ability of our software products to manage and secure IT infrastructures and environments; ability to manage customer and market acceptance of our products and services; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third-party software used in our products; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs, our ability to maintain tax concessions in certain jurisdictions and potential tax liabilities as a result of acquiring VMware; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-24-000077:8k_2_02:54]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000077:8k_2_02:55]
Contact:

[0001730168-24-000077:8k_2_02:56]
Ji Yoo

[0001730168-24-000077:8k_2_02:57]
Broadcom Inc.

[0001730168-24-000077:8k_2_02:58]
Investor Relations

[0001730168-24-000077:8k_2_02:59]
650-427-6000

[0001730168-24-000077:8k_2_02:60]
investor.relations@broadcom.com

[0001730168-24-000077:8k_2_02:61]
(AVGO-Q)

[0001730168-24-000077:8k_2_02:62]
BROADCOM INC.

[0001730168-24-000077:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-24-000077:8k_2_02:64]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-24-000077:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | February 4,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
| Net revenue |  | $ | 12,487 |  |  | $ | 11,961 |  |  | $ | 8,733 |  |  | $ | 24,448 |  |  | $ | 17,648 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,142 |  |  | 3,114 |  |  | 2,177 |  |  | 6,256 |  |  | 4,551 |  |
| Amortization of acquisition-related intangible assets |  | 1,516 |  |  | 1,380 |  |  | 441 |  |  | 2,896 |  |  | 976 |  |
| Restructuring charges |  | 53 |  |  | 92 |  |  | — |  |  | 145 |  |  | 2 |  |
| Total cost of revenue |  | 4,711 |  |  | 4,586 |  |  | 2,618 |  |  | 9,297 |  |  | 5,529 |  |
| Gross margin |  | 7,776 |  |  | 7,375 |  |  | 6,115 |  |  | 15,151 |  |  | 12,119 |  |
| Research and development |  | 2,415 |  |  | 2,308 |  |  | 1,312 |  |  | 4,723 |  |  | 2,507 |  |
| Selling, general and administrative |  | 1,277 |  |  | 1,572 |  |  | 438 |  |  | 2,849 |  |  | 786 |  |
| Amortization of acquisition-related intangible assets |  | 827 |  |  | 792 |  |  | 348 |  |  | 1,619 |  |  | 696 |  |
| Restructuring and other charges |  | 292 |  |  | 620 |  |  | 9 |  |  | 912 |  |  | 19 |  |
| Total operating expenses |  | 4,811 |  |  | 5,292 |  |  | 2,107 |  |  | 10,103 |  |  | 4,008 |  |
| Operating income |  | 2,965 |  |  | 2,083 |  |  | 4,008 |  |  | 5,048 |  |  | 8,111 |  |
| Interest expense |  | (1,047) |  |  | (926) |  |  | (405) |  |  | (1,973) |  |  | (811) |  |
| Other income, net |  | 87 |  |  | 185 |  |  | 113 |  |  | 272 |  |  | 256 |  |
| Income from continuing operations before income taxes |  | 2,005 |  |  | 1,342 |  |  | 3,716 |  |  | 3,347 |  |  | 7,556 |  |
| Provision for (benefit from) income taxes |  | (116) |  |  | 68 |  |  | 235 |  |  | (48) |  |  | 301 |  |
| Income from continuing operations |  | 2,121 |  |  | 1,274 |  |  | 3,481 |  |  | 3,395 |  |  | 7,255 |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | 51 |  |  | — |  |  | 51 |  |  | — |  |
| Net income |  | $ | 2,121 |  |  | $ | 1,325 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.56 |  |  | $ | 2.82 |  |  | $ | 8.39 |  |  | $ | 7.41 |  |  | $ | 17.40 |  |
| Income per share from discontinued operations |  | — |  |  | 0.11 |  |  | — |  |  | 0.11 |  |  | — |  |
| Net income per share |  | $ | 4.56 |  |  | $ | 2.93 |  |  | $ | 8.39 |  |  | $ | 7.52 |  |  | $ | 17.40 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.42 |  |  | $ | 2.73 |  |  | $ | 8.15 |  |  | $ | 7.18 |  |  | $ | 16.95 |  |
| Income per share from discontinued operations |  | — |  |  | 0.11 |  |  | — |  |  | 0.11 |  |  | — |  |
| Net income per share |  | $ | 4.42 |  |  | $ | 2.84 |  |  | $ | 8.15 |  |  | $ | 7.29 |  |  | $ | 16.95 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 465 |  |  | 452 |  |  | 415 |  |  | 458 |  |  | 417 |  |
| Diluted |  | 480 |  |  | 467 |  |  | 427 |  |  | 473 |  |  | 428 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 170 |  |  | $ | 161 |  |  | $ | 50 |  |  | $ | 331 |  |  | $ | 87 |  |
| Research and development |  | 881 |  |  | 863 |  |  | 354 |  |  | 1,744 |  |  | 621 |  |
| Selling, general and administrative |  | 352 |  |  | 548 |  |  | 109 |  |  | 900 |  |  | 196 |  |
| Total stock-based compensation expense |  | $ | 1,403 |  |  | $ | 1,572 |  |  | $ | 513 |  |  | $ | 2,975 |  |  | $ | 904 |  |

[0001730168-24-000077:8k_2_02:66]
BROADCOM INC.

[0001730168-24-000077:8k_2_02:67]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-24-000077:8k_2_02:68]
(IN MILLIONS)

[0001730168-24-000077:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | February 4,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
| Gross margin on GAAP basis |  | $ | 7,776 |  |  | $ | 7,375 |  |  | $ | 6,115 |  |  | $ | 15,151 |  |  | $ | 12,119 |  |
| Amortization of acquisition-related intangible assets |  | 1,516 |  |  | 1,380 |  |  | 441 |  |  | 2,896 |  |  | 976 |  |
| Stock-based compensation expense |  | 170 |  |  | 161 |  |  | 50 |  |  | 331 |  |  | 87 |  |
| Restructuring charges |  | 53 |  |  | 92 |  |  | — |  |  | 145 |  |  | 2 |  |
| Acquisition-related costs |  | 3 |  |  | 6 |  |  | — |  |  | 9 |  |  | — |  |
| Gross margin on non-GAAP basis |  | $ | 9,518 |  |  | $ | 9,014 |  |  | $ | 6,606 |  |  | $ | 18,532 |  |  | $ | 13,184 |  |
| Research and development on GAAP basis |  | $ | 2,415 |  |  | $ | 2,308 |  |  | $ | 1,312 |  |  | $ | 4,723 |  |  | $ | 2,507 |  |
| Stock-based compensation expense |  | 881 |  |  | 863 |  |  | 354 |  |  | 1,744 |  |  | 621 |  |
| Acquisition-related costs |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | (1) |  |
| Research and development on non-GAAP basis |  | $ | 1,534 |  |  | $ | 1,444 |  |  | $ | 958 |  |  | $ | 2,978 |  |  | $ | 1,887 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,277 |  |  | $ | 1,572 |  |  | $ | 438 |  |  | $ | 2,849 |  |  | $ | 786 |  |
| Stock-based compensation expense |  | 352 |  |  | 548 |  |  | 109 |  |  | 900 |  |  | 196 |  |
| Acquisition-related costs |  | 87 |  |  | 285 |  |  | 93 |  |  | 372 |  |  | 135 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 838 |  |  | $ | 739 |  |  | $ | 236 |  |  | $ | 1,577 |  |  | $ | 455 |  |
| Total operating expenses on GAAP basis |  | $ | 4,811 |  |  | $ | 5,292 |  |  | $ | 2,107 |  |  | $ | 10,103 |  |  | $ | 4,008 |  |
| Amortization of acquisition-related intangible assets |  | 827 |  |  | 792 |  |  | 348 |  |  | 1,619 |  |  | 696 |  |
| Stock-based compensation expense |  | 1,233 |  |  | 1,411 |  |  | 463 |  |  | 2,644 |  |  | 817 |  |
| Restructuring and other charges |  | 292 |  |  | 620 |  |  | 9 |  |  | 912 |  |  | 19 |  |
| Acquisition-related costs |  | 87 |  |  | 286 |  |  | 93 |  |  | 373 |  |  | 134 |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,372 |  |  | $ | 2,183 |  |  | $ | 1,194 |  |  | $ | 4,555 |  |  | $ | 2,342 |  |
| Operating income on GAAP basis |  | $ | 2,965 |  |  | $ | 2,083 |  |  | $ | 4,008 |  |  | $ | 5,048 |  |  | $ | 8,111 |  |
| Amortization of acquisition-related intangible assets |  | 2,343 |  |  | 2,172 |  |  | 789 |  |  | 4,515 |  |  | 1,672 |  |
| Stock-based compensation expense |  | 1,403 |  |  | 1,572 |  |  | 513 |  |  | 2,975 |  |  | 904 |  |
| Restructuring and other charges |  | 345 |  |  | 712 |  |  | 9 |  |  | 1,057 |  |  | 21 |  |
| Acquisition-related costs |  | 90 |  |  | 292 |  |  | 93 |  |  | 382 |  |  | 134 |  |
| Operating income on non-GAAP basis |  | $ | 7,146 |  |  | $ | 6,831 |  |  | $ | 5,412 |  |  | $ | 13,977 |  |  | $ | 10,842 |  |
| Interest expense on GAAP basis |  | $ | (1,047) |  |  | $ | (926) |  |  | $ | (405) |  |  | $ | (1,973) |  |  | $ | (811) |  |
| Loss on debt extinguishment |  | 22 |  |  | — |  |  | — |  |  | 22 |  |  | — |  |
| Interest expense on non-GAAP basis |  | $ | (1,025) |  |  | $ | (926) |  |  | $ | (405) |  |  | $ | (1,951) |  |  | $ | (811) |  |
| Other income, net on GAAP basis |  | $ | 87 |  |  | $ | 185 |  |  | $ | 113 |  |  | $ | 272 |  |  | $ | 256 |  |
| (Gains) losses on investments |  | 9 |  |  | (33) |  |  | 11 |  |  | (24) |  |  | (33) |  |
| Other income, net on non-GAAP basis |  | $ | 96 |  |  | $ | 152 |  |  | $ | 124 |  |  | $ | 248 |  |  | $ | 223 |  |

[0001730168-24-000077:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | February 4,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (116) |  |  | $ | 68 |  |  | $ | 235 |  |  | $ | (48) |  |  | $ | 301 |  |
| Non-GAAP tax reconciling adjustments |  | 939 |  |  | 735 |  |  | 407 |  |  | 1,674 |  |  | 981 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 823 |  |  | $ | 803 |  |  | $ | 642 |  |  | $ | 1,626 |  |  | $ | 1,282 |  |
| Net income on GAAP basis |  | $ | 2,121 |  |  | $ | 1,325 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Amortization of acquisition-related intangible assets |  | 2,343 |  |  | 2,172 |  |  | 789 |  |  | 4,515 |  |  | 1,672 |  |
| Stock-based compensation expense |  | 1,403 |  |  | 1,572 |  |  | 513 |  |  | 2,975 |  |  | 904 |  |
| Restructuring and other charges |  | 345 |  |  | 712 |  |  | 9 |  |  | 1,057 |  |  | 21 |  |
| Acquisition-related costs |  | 90 |  |  | 292 |  |  | 93 |  |  | 382 |  |  | 134 |  |
| Loss on debt extinguishment |  | 22 |  |  | — |  |  | — |  |  | 22 |  |  | — |  |
| (Gains) losses on investments |  | 9 |  |  | (33) |  |  | 11 |  |  | (24) |  |  | (33) |  |
| Non-GAAP tax reconciling adjustments |  | (939) |  |  | (735) |  |  | (407) |  |  | (1,674) |  |  | (981) |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | (51) |  |  | — |  |  | (51) |  |  | — |  |
| Net income on non-GAAP basis |  | $ | 5,394 |  |  | $ | 5,254 |  |  | $ | 4,489 |  |  | $ | 10,648 |  |  | $ | 8,972 |  |
| Net income on GAAP basis |  | $ | 2,121 |  |  | $ | 1,325 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,343 |  |  | 2,172 |  |  | 789 |  |  | 4,515 |  |  | 1,672 |  |
| Stock-based compensation expense |  | 1,403 |  |  | 1,572 |  |  | 513 |  |  | 2,975 |  |  | 904 |  |
| Restructuring and other charges |  | 345 |  |  | 712 |  |  | 9 |  |  | 1,057 |  |  | 21 |  |
| Acquisition-related costs |  | 90 |  |  | 292 |  |  | 93 |  |  | 382 |  |  | 134 |  |
| Loss on debt extinguishment |  | 22 |  |  | — |  |  | — |  |  | 22 |  |  | — |  |
| (Gains) losses on investments |  | 9 |  |  | (33) |  |  | 11 |  |  | (24) |  |  | (33) |  |
| Non-GAAP tax reconciling adjustments |  | (939) |  |  | (735) |  |  | (407) |  |  | (1,674) |  |  | (981) |  |
| Income from discontinued operations, net of income taxes |  | — |  |  | (51) |  |  | — |  |  | (51) |  |  | — |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 1,025 |  |  | 926 |  |  | 405 |  |  | 1,951 |  |  | 811 |  |
| Provision for income taxes on non-GAAP basis |  | 823 |  |  | 803 |  |  | 642 |  |  | 1,626 |  |  | 1,282 |  |
| Depreciation |  | 149 |  |  | 139 |  |  | 129 |  |  | 288 |  |  | 256 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 38 |  |  | 34 |  |  | 21 |  |  | 72 |  |  | 43 |  |
| Adjusted EBITDA |  | $ | 7,429 |  |  | $ | 7,156 |  |  | $ | 5,686 |  |  | $ | 14,585 |  |  | $ | 11,364 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 480 |  |  | 467 |  |  | 427 |  |  | 473 |  |  | 428 |  |
| Non-GAAP adjustment (1) |  | 12 |  |  | 11 |  |  | 8 |  |  | 12 |  |  | 7 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 492 |  |  | 478 |  |  | 435 |  |  | 485 |  |  | 435 |  |
| Net cash provided by operating activities |  | $ | 4,580 |  |  | $ | 4,815 |  |  | $ | 4,502 |  |  | $ | 9,395 |  |  | $ | 8,538 |  |
| Purchases of property, plant and equipment |  | (132) |  |  | (122) |  |  | (122) |  |  | (254) |  |  | (225) |  |
| Free cash flow |  | $ | 4,448 |  |  | $ | 4,693 |  |  | $ | 4,380 |  |  | $ | 9,141 |  |  | $ | 8,313 |  |

[0001730168-24-000077:8k_2_02:71]
|  |  | Fiscal Quarter Ending |
|  |  | August 4, |
| Expected average diluted share count (2): |  | 2024 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,810 |  |
| Non-GAAP adjustment (1) |  | 110 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,920 |  |

[0001730168-24-000077:8k_2_02:72]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |
| (2) Includes the impact of a ten-for-one forward stock split of our common stock. Stockholders of record after the close of market on July 11, 2024 will receive an additional nine shares of common stock for each share held after the close of market on July 12, 2024. At market open on July 15, 2024, trading is expected to commence on a split-adjusted basis. |

[0001730168-24-000077:8k_2_02:73]
BROADCOM INC.

[0001730168-24-000077:8k_2_02:74]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-24-000077:8k_2_02:75]
(IN MILLIONS)

[0001730168-24-000077:8k_2_02:76]
|  |  | May 5,2024 |  | October 29,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,809 |  |  | $ | 14,189 |  |
| Trade accounts receivable, net |  | 5,500 |  |  | 3,154 |  |
| Inventory |  | 1,842 |  |  | 1,898 |  |
| Other current assets |  | 8,151 |  |  | 1,606 |  |
| Total current assets |  | 25,302 |  |  | 20,847 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,668 |  |  | 2,154 |  |
| Goodwill |  | 97,873 |  |  | 43,653 |  |
| Intangible assets, net |  | 45,407 |  |  | 3,867 |  |
| Other long-term assets |  | 3,961 |  |  | 2,340 |  |
| Total assets |  | $ | 175,211 |  |  | $ | 72,861 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,441 |  |  | $ | 1,210 |  |
| Employee compensation and benefits |  | 1,385 |  |  | 935 |  |
| Current portion of long-term debt |  | 2,426 |  |  | 1,608 |  |
| Other current liabilities |  | 14,919 |  |  | 3,652 |  |
| Total current liabilities |  | 20,171 |  |  | 7,405 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 71,590 |  |  | 37,621 |  |
| Other long-term liabilities |  | 13,489 |  |  | 3,847 |  |
| Total liabilities |  | 105,250 |  |  | 48,873 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 69,754 |  |  | 21,099 |  |
| Retained earnings |  | — |  |  | 2,682 |  |
| Accumulated other comprehensive income |  | 207 |  |  | 207 |  |
| Total stockholders' equity |  | 69,961 |  |  | 23,988 |  |
| Total liabilities and equity |  | $ | 175,211 |  |  | $ | 72,861 |  |

[0001730168-24-000077:8k_2_02:77]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2024 |  | February 4,2024 |  | April 30,2023 |  | May 5,2024 |  | April 30,2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,121 |  |  | $ | 1,325 |  |  | $ | 3,481 |  |  | $ | 3,446 |  |  | $ | 7,255 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,381 |  |  | 2,206 |  |  | 810 |  |  | 4,587 |  |  | 1,715 |  |
| Depreciation |  | 149 |  |  | 139 |  |  | 129 |  |  | 288 |  |  | 256 |  |
| Stock-based compensation |  | 1,457 |  |  | 1,582 |  |  | 513 |  |  | 3,039 |  |  | 904 |  |
| Deferred taxes and other non-cash taxes |  | (511) |  |  | (294) |  |  | (316) |  |  | (805) |  |  | (889) |  |
| Non-cash interest expense |  | 119 |  |  | 102 |  |  | 33 |  |  | 221 |  |  | 65 |  |
| Other |  | 92 |  |  | 38 |  |  | 21 |  |  | 130 |  |  | (18) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (513) |  |  | 1,756 |  |  | 185 |  |  | 1,243 |  |  | (91) |  |
| Inventory |  | 82 |  |  | (14) |  |  | 13 |  |  | 68 |  |  | 39 |  |
| Accounts payable |  | (93) |  |  | (74) |  |  | (114) |  |  | (167) |  |  | (194) |  |
| Employee compensation and benefits |  | 251 |  |  | (660) |  |  | 91 |  |  | (409) |  |  | (566) |  |
| Other current assets and current liabilities |  | (386) |  |  | (2,182) |  |  | (165) |  |  | (2,568) |  |  | 405 |  |
| Other long-term assets and long-term liabilities |  | (569) |  |  | 891 |  |  | (179) |  |  | 322 |  |  | (343) |  |
| Net cash provided by operating activities |  | 4,580 |  |  | 4,815 |  |  | 4,502 |  |  | 9,395 |  |  | 8,538 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (560) |  |  | (25,416) |  |  | — |  |  | (25,976) |  |  | — |  |
| Purchases of property, plant and equipment |  | (132) |  |  | (122) |  |  | (122) |  |  | (254) |  |  | (225) |  |
| Purchases of investments |  | (59) |  |  | (13) |  |  | (197) |  |  | (72) |  |  | (197) |  |
| Sales of investments |  | 42 |  |  | 89 |  |  | — |  |  | 131 |  |  | — |  |
| Other |  | 3 |  |  | (15) |  |  | 1 |  |  | (12) |  |  | 1 |  |
| Net cash used in investing activities |  | (706) |  |  | (25,477) |  |  | (318) |  |  | (26,183) |  |  | (421) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | 30,010 |  |  | — |  |  | 30,010 |  |  | — |  |
| Payments on debt obligations |  | (2,000) |  |  | (934) |  |  | — |  |  | (2,934) |  |  | (260) |  |
| Payments of dividends |  | (2,443) |  |  | (2,435) |  |  | (1,914) |  |  | (4,878) |  |  | (3,840) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | (7,176) |  |  | (2,806) |  |  | (7,176) |  |  | (3,994) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (1,548) |  |  | (1,114) |  |  | (614) |  |  | (2,662) |  |  | (947) |  |
| Issuance of common stock |  | 64 |  |  | — |  |  | 63 |  |  | 64 |  |  | 63 |  |
| Other |  | (2) |  |  | (14) |  |  | (7) |  |  | (16) |  |  | (2) |  |
| Net cash provided by (used in) financing activities |  | (5,929) |  |  | 18,337 |  |  | (5,278) |  |  | 12,408 |  |  | (8,980) |  |
| Net change in cash and cash equivalents |  | (2,055) |  |  | (2,325) |  |  | (1,094) |  |  | (4,380) |  |  | (863) |  |
| Cash and cash equivalents at beginning of period |  | 11,864 |  |  | 14,189 |  |  | 12,647 |  |  | 14,189 |  |  | 12,416 |  |
| Cash and cash equivalents at end of period |  | $ | 9,809 |  |  | $ | 11,864 |  |  | $ | 11,553 |  |  | $ | 9,809 |  |  | $ | 11,553 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 946 |  |  | $ | 750 |  |  | $ | 397 |  |  | $ | 1,696 |  |  | $ | 758 |  |
| Cash paid for income taxes |  | $ | 834 |  |  | $ | 904 |  |  | $ | 891 |  |  | $ | 1,738 |  |  | $ | 1,164 |  |
