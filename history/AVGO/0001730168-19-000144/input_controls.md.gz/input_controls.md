# AVGO 10-K controls and the auditor's report


## auditors_report

[0001730168-19-000144:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001730168-19-000144:auditors_report:2]
To the Board of Directors and Stockholders of Broadcom Inc.

[0001730168-19-000144:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001730168-19-000144:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Broadcom Inc. and its subsidiaries (the “Company”) as of November 3, 2019 and November 4, 2018, and the related consolidated statements of operations, of comprehensive income, of equity and of cash flows for each of the three years in the period ended November 3, 2019, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of November 3, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001730168-19-000144:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of November 3, 2019 and November 4, 2018, and the results of its operations and its cash flows for each of the three years in the period ended November 3, 2019 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of November 3, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001730168-19-000144:auditors_report:6]
Basis for Opinions

[0001730168-19-000144:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001730168-19-000144:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001730168-19-000144:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001730168-19-000144:auditors_report:10]
As described in Management’s Report on Internal Control Over Financial Reporting, management has excluded CA, Inc. from its assessment of internal control over financial reporting as of November 3, 2019, because it was acquired by the Company in a purchase business combination during 2019. We have also excluded CA, Inc. from our audit of internal control over financial reporting. CA, Inc. is a wholly-owned subsidiary whose total assets and total revenues excluded from management’s assessment and our audit of internal control over financial reporting represent 3% and 15%, respectively, of the related consolidated financial statement amounts as of and for the year ended November 3, 2019.

[0001730168-19-000144:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0001730168-19-000144:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and

[0001730168-19-000144:auditors_report:13]
dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001730168-19-000144:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001730168-19-000144:auditors_report:15]
Critical Audit Matters

[0001730168-19-000144:auditors_report:16]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001730168-19-000144:auditors_report:17]
Valuation of Developed Technology and Customer Contracts and Related Relationships Intangible Assets Acquired in the CA, Inc. Acquisition

[0001730168-19-000144:auditors_report:18]
As described in Notes 2 and 4 to the consolidated financial statements, the Company completed the acquisition of CA, Inc. during fiscal 2019 for net consideration of $16,094 million, of which $4,957 million of finite-lived developed technology and $4,190 million of finite-lived customer contracts and related relationships intangible assets were recorded. Management valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. Management valued the customer contracts and related relationships using the with-and-without-method under the income approach. In this method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. As disclosed by management, significant estimates and assumptions in estimating the fair value of the developed technology and the customer contracts and related relationships include future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp up period, technology obsolescence rates, and discount rates.

[0001730168-19-000144:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the valuation of the developed technology and customer contracts and relationships intangible assets acquired in the CA, Inc. acquisition is a critical audit matter are (i) there was a high degree of auditor judgment and subjectivity in applying our procedures relating to the fair value measurement of the developed technology and the customer contracts and related relationships due to the significant judgment by management when developing these estimates, (ii) significant audit effort was required in assessing the significant assumptions relating to the valuation of the developed technology and the customer contracts and related relationships, which include the revenue growth rate, the technology obsolescence rates, the customer ramp-up period, and the discount rates, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001730168-19-000144:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over management’s valuation of the developed technology and the customer contracts and related relationships and controls over development of the assumptions related to the valuation of the developed technology and the customer contracts and related relationships including the revenue growth rate, the technology obsolescence rates, the customer ramp-up period, and the discount rates. These procedures also included, among others, reading the purchase agreement and testing management’s process for determining the fair value of these intangible assets, including evaluating the appropriateness of the valuation methods, testing the completeness and accuracy of underlying data, and evaluating the reasonableness of the significant assumptions, which include the revenue growth rate, the technology obsolescence rates, the customer ramp-up period, and the discount rates. Evaluating the reasonableness of the revenue growth rate, the technology obsolescence rates, and the customer ramp-up period involved considering the past performance of the acquiree, benchmarking of peer companies and, for the revenue growth rate, industry data. Professionals with specialized skill and knowledge were used to assist us in evaluating the appropriateness of valuation methods and the reasonableness of the discount rates and the technology obsolescence rates.

[0001730168-19-000144:auditors_report:21]
Uncertain Tax Positions (“UTPs”)

[0001730168-19-000144:auditors_report:22]
As described in Notes 2 and 11 to the consolidated financial statements, the gross unrecognized tax benefits balance was $4,422 million as of November 3, 2019. As management has disclosed, management evaluates the exposure associated with various tax filing positions and accrues an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition. A tax benefit from an UTP may be recognized when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits.

[0001730168-19-000144:auditors_report:23]
The principal considerations for our determination that performing procedures relating to the UTPs is a critical audit matter are (i) there was significant judgment by management when evaluating the technical merits of these tax positions, (ii) significant auditor judgment, subjectivity, and effort was required in understanding the relevant information and evaluating the technical merits of the tax positions, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001730168-19-000144:auditors_report:24]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the identification and recognition of the income tax liability for UTPs, including controls addressing completeness of the UTPs as well as controls over the measurement of the income tax liability. These procedures also included, among others, (i) testing management’s process for identifying potential new UTPs and evaluating possible outcomes for each UTP selected for testing, and (ii) testing the calculation of the liability for UTPs by jurisdiction, including management’s assessment of the technical merits of tax positions and estimates of the amount of tax benefit expected to be sustained for each UTP selected for testing. Professionals with specialized skill and knowledge were used to assist in the evaluation of the completeness and measurement of the Company’s UTPs, including the reasonableness of management’s assessment of whether certain tax positions are more-likely-than-not of being sustained and the amount of potential benefit to be realized, and the application of relevant tax laws.

[0001730168-19-000144:auditors_report:25]
/s/ PricewaterhouseCoopers LLP

[0001730168-19-000144:auditors_report:26]
San Jose, California

[0001730168-19-000144:auditors_report:27]
December 20, 2019

[0001730168-19-000144:auditors_report:28]
We have served as the Company’s auditor since 2006.

[0001730168-19-000144:auditors_report:29]
BROADCOM INC.


## item_9a

[0001730168-19-000144:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001730168-19-000144:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001730168-19-000144:item_9a:3]
Our management, with the participation of our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), evaluated the effectiveness of Broadcom’s disclosure controls and procedures as of November 3, 2019. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to our management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the evaluation of our disclosure controls and procedures as of November 3, 2019, our CEO and CFO concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001730168-19-000144:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0001730168-19-000144:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting. Internal control over financial reporting is defined in Rules 13a-15(f) and 15d-15(f) promulgated under the Exchange Act as a process designed by, or under the supervision of, our principal executive and principal financial officers and effected by the Board, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with GAAP and includes those policies and procedures that:

[0001730168-19-000144:item_9a:6]
116

[0001730168-19-000144:item_9a:7]
| • | pertain to the maintenance of records that in reasonable detail accurately and fairly reflect the transactions and dispositions of the assets; |

[0001730168-19-000144:item_9a:8]
| • | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with GAAP, and that receipts and expenditures of us are being made only in accordance with authorizations of management and directors; and |

[0001730168-19-000144:item_9a:9]
| • | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the financial statements. |

[0001730168-19-000144:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001730168-19-000144:item_9a:11]
Our management assessed the effectiveness of our internal control over financial reporting as of November 3, 2019. In making this assessment, our management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control-Integrated Framework (2013). Based on this assessment, our management concluded that, as of November 3, 2019, our internal control over financial reporting is effective based on those criteria.

[0001730168-19-000144:item_9a:12]
Our evaluation of the effectiveness of our internal control over financial reporting as of November 3, 2019 did not include the internal controls of CA, Inc. (“CA”). We excluded CA from our assessment of internal control over financial reporting as of November 3, 2019 because it was acquired in a business combination in November 2018. CA is a subsidiary of ours whose total assets represented 3% and total revenues represented 15% of the related consolidated financial statement amounts as of and for the year ended November 3, 2019.

[0001730168-19-000144:item_9a:13]
The effectiveness of our internal control over financial reporting, as of November 3, 2019 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which is included in Part II, Item 8. of this Annual Report on Form 10-K.

[0001730168-19-000144:item_9a:14]
Changes in Internal Control over Financial Reporting

[0001730168-19-000144:item_9a:15]
No change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) occurred during the fourth quarter ended November 3, 2019 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
