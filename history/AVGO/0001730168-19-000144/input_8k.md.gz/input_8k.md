# AVGO 8-K — 0001193125-19-312797 filed 2019-12-12

## item codes, every 8-K on or before 2019-12-20

- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2019-12-20

- none on or before 2019-12-20

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-312797:8k_2_02:1]
EX-99.1
2
d845915dex991.htm
EX-99.1

[0001193125-19-312797:8k_2_02:2]
EX-99.1

[0001193125-19-312797:8k_2_02:3]
Exhibit 99.1

[0001193125-19-312797:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2019 Financial Results and Quarterly Dividends

[0001193125-19-312797:8k_2_02:5]
|  | • |  | Revenue of $5,776 million for the fourth quarter, up 6 percent from the prior year period |

[0001193125-19-312797:8k_2_02:6]
|  | • |  | Revenue of $22,597 million for the fiscal year, up 8 percent from the prior year |

[0001193125-19-312797:8k_2_02:7]
|  | • |  | GAAP net income of $847 million for the fourth quarter; Adjusted EBITDA of $3,165 million for the fourth quarter |

[0001193125-19-312797:8k_2_02:8]
|  | • |  | GAAP net income of $2,724 million for the fiscal year; Adjusted EBITDA of $12,579 million for the fiscal year |

[0001193125-19-312797:8k_2_02:9]
|  | • |  | Quarterly common stock dividend increased by 23 percent to $3.25 per share from the prior quarter |

[0001193125-19-312797:8k_2_02:10]
|  | • |  | Fiscal year 2020 revenue guidance of $25 billion plus or minus $500 million, up 11 percent from fiscal year 2019 at the midpoint of guidance |

[0001193125-19-312797:8k_2_02:11]
|  | • |  | Fiscal year 2020 Adjusted EBITDA guidance of $13.75 billion plus or minus $250 million, or 55% of revenue at the midpoint of guidance 1 |

[0001193125-19-312797:8k_2_02:12]
SAN JOSE, Calif. – December 12, 2019 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and
supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth fiscal quarter and fiscal year ended November 3, 2019, provided guidance for its fiscal year 2020 and announced quarterly dividends.
The Company completed its acquisition of the Symantec Enterprise Security business on November 4, 2019. The financial results provided below do not include any contribution from the Symantec Enterprise Security business.

[0001193125-19-312797:8k_2_02:13]
“Fiscal year 2019 concluded as expected. Our semiconductor solutions segment continued to work its way through a cyclical correction. This was more than
offset by our infrastructure software segment, which delivered healthy results benefitting from the integration and performance of our CA business,” said Hock Tan, President and CEO of Broadcom Inc. “Looking to fiscal 2020, we remain
well-positioned across our technology franchises. We continue to believe that our core semiconductor business is bottoming and will return to year over year growth in the second half of our fiscal year. In addition, we expect to benefit from the
integration of the Symantec Enterprise Security business into what is otherwise expected to be a stable infrastructure software segment in fiscal 2020.”

[0001193125-19-312797:8k_2_02:14]
“We achieved record profitability in fiscal 2019, including free cash flow of over $9 billion, despite a challenging market backdrop for our
semiconductor solutions segment. As a result, we are raising our target dividend by 23 percent to $3.25 per share per quarter for fiscal year 2020,” said Tom Krause, CFO of Broadcom Inc. “Looking ahead to next year, we expect our
adjusted EBITDA to expand by more than $1 billion, while we focus our capital returns on cash dividends, with excess cash going towards debt pay down.”

[0001193125-19-312797:8k_2_02:15]
| 1 | The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort. |

[0001193125-19-312797:8k_2_02:16]
1

[0001193125-19-312797:8k_2_02:17]
Fourth Quarter Fiscal Year 2019 GAAP Results from Continuing Operations

[0001193125-19-312797:8k_2_02:18]
Net revenue was $5,776 million, 4.7 percent higher than $5,515 million in the previous quarter and 6.1 percent higher than
$5,444 million in the same quarter last year.

[0001193125-19-312797:8k_2_02:19]
Gross margin was $3,152 million, or 54.6 percent of net revenue. This compares with gross
margin of $3,034 million, or 55.0 percent of net revenue, in the prior quarter, and gross margin of $2,935 million, or 53.9 percent of net revenue, in the same quarter last year.

[0001193125-19-312797:8k_2_02:20]
Operating expenses were $2,098 million. This compares with $2,169 million in the prior quarter and $1,283 million in the same quarter last
year.

[0001193125-19-312797:8k_2_02:21]
Operating income was $1,054 million, or 18.2 percent of net revenue. This compares with operating income of $865 million, or
15.7 percent of net revenue, in the prior quarter, and operating income of $1,652 million, or 30.3 percent of net revenue, in the same quarter last year.

[0001193125-19-312797:8k_2_02:22]
Net income was $847 million, or $1.97 per diluted share. This compares with net income of $715 million, or $1.71 per diluted share, in the prior
quarter, and net income of $1,115 million, or $2.64 per diluted share, in the same quarter last year.

[0001193125-19-312797:8k_2_02:23]
Cash from operations was $2,479 million
in the quarter. This compares with $2,419 million in the prior quarter and $2,635 million in the same quarter last year.

[0001193125-19-312797:8k_2_02:24]
| Fourth Quarter Fiscal Year 2019 GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q4 19 |  |  | Q3 19 |  |  | Q4 18 |  |  | Q/Q |  |  | Y/Y |  |
| Net revenue |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,444 |  |  |  | +5 | % |  |  | +6 | % |
| Gross margin |  |  | 54.6 | % |  |  | 55.0 | % |  |  | 53.9 | % |  |  | -40bps |  |  |  | +70bps |  |
| Operating expenses |  | $ | 2,098 |  |  | $ | 2,169 |  |  | $ | 1,283 |  |  | -$ | 71 |  |  | +$ | 815 |  |
| Operating income |  | $ | 1,054 |  |  | $ | 865 |  |  | $ | 1,652 |  |  | +$ | 189 |  |  | -$ | 598 |  |
| Net income |  | $ | 847 |  |  | $ | 715 |  |  | $ | 1,115 |  |  | +$ | 132 |  |  | -$ | 268 |  |
| Net income attributable to common stock |  | $ | 818 |  |  | $ | 715 |  |  | $ | 1,115 |  |  | +$ | 103 |  |  | -$ | 297 |  |
| Earnings per common share - diluted |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 2.64 |  |  | +$ | 0.26 |  |  | -$ | 0.67 |  |
| Cash flow from operations |  | $ | 2,479 |  |  | $ | 2,419 |  |  | $ | 2,635 |  |  | +$ | 60 |  |  | -$ | 156 |  |

[0001193125-19-312797:8k_2_02:25]
The Company’s cash and cash equivalents at the end of the fourth fiscal quarter were $5,055 million, compared to
$5,462 million at the end of the prior quarter.

[0001193125-19-312797:8k_2_02:26]
During the fourth fiscal quarter, the Company generated $2,479 million in cash from operations
and spent $587 million on share repurchases and eliminations, consisting of $433 million in repurchases of 1.5 million shares and $154 million of withholding tax payments related to net settled equity awards that vested in the
quarter (representing approximately 0.5 million shares withheld), as well as $96 million on capital expenditures.

[0001193125-19-312797:8k_2_02:27]
2

[0001193125-19-312797:8k_2_02:28]
On October 1, 2019, the Company paid a cash dividend of $2.65 per share of common stock, totaling
$1,054 million.

[0001193125-19-312797:8k_2_02:29]
Fourth Quarter Fiscal Year 2019 Non-GAAP Results From Continuing Operations

[0001193125-19-312797:8k_2_02:30]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001193125-19-312797:8k_2_02:31]
Gross margin was $4,035 million, or 69.9 percent of net revenue. This compares with gross margin of $3,916 million, or 71.0 percent of net
revenue, in the prior quarter, and $3,725 million, or 68.4 percent of net revenue, in the same quarter last year.

[0001193125-19-312797:8k_2_02:32]
Operating income was
$3,018 million, or 52.3 percent of net revenue. This compares with operating income of $2,910 million, or 52.8 percent of net revenue, in the prior quarter, and $2,862 million, or 52.5 percent of net revenue, in the
same quarter last year.

[0001193125-19-312797:8k_2_02:33]
Net income was $2,391 million, or $5.39 per diluted share. This compares with net income of $2,281 million, or $5.16
per diluted share, in the prior quarter, and net income of $2,546 million, or $5.85 per diluted share, in the same quarter last year.

[0001193125-19-312797:8k_2_02:34]
Free cash flow
from operations, defined as cash from operations less capital expenditures, was $2,383 million in the quarter. This compares with $2,307 million in the prior quarter and $2,529 million in the same quarter last year.

[0001193125-19-312797:8k_2_02:35]
| Fourth Quarter Fiscal Year 2019 Non-GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q4 19 |  |  | Q3 19 |  |  | Q4 18 |  |  | Q/Q |  |  | Y/Y |  |
| Gross margin |  |  | 69.9 | % |  |  | 71.0 | % |  |  | 68.4 | % |  |  | -110bps |  |  |  | +150bps |  |
| Operating expenses |  | $ | 1,017 |  |  | $ | 1,006 |  |  | $ | 863 |  |  | +$ | 11 |  |  | +$ | 154 |  |
| Operating income |  | $ | 3,018 |  |  | $ | 2,910 |  |  | $ | 2,862 |  |  | +$ | 108 |  |  | +$ | 156 |  |
| Net income |  | $ | 2,391 |  |  | $ | 2,281 |  |  | $ | 2,546 |  |  | +$ | 110 |  |  | -$ | 155 |  |
| Earnings per common share - diluted |  | $ | 5.39 |  |  | $ | 5.16 |  |  | $ | 5.85 |  |  | +$ | 0.23 |  |  | -$ | 0.46 |  |
| Free cash flow |  | $ | 2,383 |  |  | $ | 2,307 |  |  | $ | 2,529 |  |  | +$ | 76 |  |  | -$ | 146 |  |

[0001193125-19-312797:8k_2_02:36]
3

[0001193125-19-312797:8k_2_02:37]
Other Quarterly Data

[0001193125-19-312797:8k_2_02:38]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q4 19 |  |  | Q3 19 |  |  | Q4 18 |  |  | Q/Q |  |  | Y/Y |  |
| Semiconductor solutions |  | $ | 4,553 |  |  |  | 79 | % |  | $ | 4,353 |  |  |  | 79 | % |  | $ | 4,874 |  |  |  | 90 | % |  |  | +5 | % |  |  | -7 | % |
| Infrastructure software |  |  | 1,200 |  |  |  | 21 |  |  |  | 1,140 |  |  |  | 21 |  |  |  | 513 |  |  |  | 9 |  |  |  | +5 | % |  |  | +134 | % |
| Intellectual property licensing |  |  | 23 |  |  |  | — |  |  |  | 22 |  |  |  | — |  |  |  | 57 |  |  |  | 1 |  |  |  | +5 | % |  |  | -60 | % |
| Total net revenue |  | $ | 5,776 |  |  |  | 100 | % |  | $ | 5,515 |  |  |  | 100 | % |  | $ | 5,444 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-19-312797:8k_2_02:39]
Fiscal Year 2019 Financial Results from Continuing Operations

[0001193125-19-312797:8k_2_02:40]
Net revenue from continuing operations was $22,597 million, an increase of 8.4 percent from $20,848 million in the prior year. Gross margin was
$12,483 million, or 55.2 percent of net revenue, versus $10,733 million, or 51.5 percent of net revenue, in the prior year. Operating income was $3,444 million, or 15.2 percent of net revenue, versus
$5,135 million, or 24.6 percent of net revenue, in the prior year. Net income, which includes the impact from discontinued operations, was $2,724 million, or $6.43 per diluted share. This compares with a net income of
$12,610 million, or $28.44 per diluted share, in fiscal year 2018. Cash from operations was $9,697 million, compared to $8,880 million in the prior year.

[0001193125-19-312797:8k_2_02:41]
| Fiscal Year 2019 GAAP Results |  |  |  |  |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | 2019 |  |  | 2018 |  |  | Change |  |
| Net revenue |  | $ | 22,597 |  |  | $ | 20,848 |  |  |  | +8 | % |
| Gross margin |  |  | 55.2 | % |  |  | 51.5 | % |  |  | +370bps |  |
| Operating expenses |  | $ | 9,039 |  |  | $ | 5,598 |  |  | +$ | 3,441 |  |
| Operating income |  | $ | 3,444 |  |  | $ | 5,135 |  |  | -$ | 1,691 |  |
| Net income |  | $ | 2,724 |  |  | $ | 12,610 |  |  | -$ | 9,886 |  |
| Net income attributable to common stock |  | $ | 2,695 |  |  | $ | 12,259 |  |  | -$ | 9,564 |  |
| Earnings per common share - diluted |  | $ | 6.43 |  |  | $ | 28.44 |  |  | -$ | 22.01 |  |
| Cash flow from operations |  | $ | 9,697 |  |  | $ | 8,880 |  |  | +$ | 817 |  |

[0001193125-19-312797:8k_2_02:42]
4

[0001193125-19-312797:8k_2_02:43]
Non-GAAP gross margin was $16,055 million, or
71.0 percent of net revenue, versus $13,931 million, or 66.8 percent of net revenue, in the prior year. Non-GAAP operating income from continuing operations was $11,929 million.
This compares with $10,424 million in the prior year. Non-GAAP net income was $9,452 million, or $21.29 per diluted share. This compares with
non-GAAP net income of $9,391 million, or $20.82 per diluted share, in fiscal year 2018. Free cash flow from operations, defined as cash from operations less capital expenditures, was
$9,265 million compared to $8,245 million in the prior year.

[0001193125-19-312797:8k_2_02:44]
| Fiscal Year 2019 Non-GAAP Results |  |  |  |  |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | 2019 |  |  | 2018 |  |  | Change |  |
| Gross margin |  |  | 71.0 | % |  |  | 66.8 | % |  |  | +420bps |  |
| Operating expenses |  | $ | 4,126 |  |  | $ | 3,507 |  |  | +$ | 619 |  |
| Operating income |  | $ | 11,929 |  |  | $ | 10,424 |  |  | +$ | 1,505 |  |
| Net income |  | $ | 9,452 |  |  | $ | 9,391 |  |  | +$ | 61 |  |
| Earnings per common share - diluted |  | $ | 21.29 |  |  | $ | 20.82 |  |  | +$ | 0.47 |  |
| Free cash flow |  | $ | 9,265 |  |  | $ | 8,245 |  |  | +$ | 1,020 |  |

[0001193125-19-312797:8k_2_02:45]
Fiscal Year 2020 Business Outlook

[0001193125-19-312797:8k_2_02:46]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2020, ending November 1, 2020, including
contributions from the Symantec Enterprise Security business, is expected to be as follows:

[0001193125-19-312797:8k_2_02:47]
|  | • |  | Revenue is expected to be $25 billion plus or minus $500 million. |

[0001193125-19-312797:8k_2_02:48]
|  | • |  | Adjusted EBITDA is expected to be $13.75 billion plus or minus $250 million. |

[0001193125-19-312797:8k_2_02:49]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to
provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly
update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-312797:8k_2_02:50]
Quarterly
Dividends

[0001193125-19-312797:8k_2_02:51]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.25 per share. The common stock
dividend is payable on December 31, 2019 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 23, 2019.

[0001193125-19-312797:8k_2_02:52]
The Company’s Board of Directors also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per
share. This dividend is payable on December 31, 2019 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 15, 2019.

[0001193125-19-312797:8k_2_02:53]
5

[0001193125-19-312797:8k_2_02:54]
Financial Results Conference Call

[0001193125-19-312797:8k_2_02:55]
Broadcom Inc. will host a conference call to review its financial results for the fourth fiscal quarter and fiscal year ended November 3, 2019, and
discuss guidance for fiscal year 2020, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The
passcode is 8988706. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and
reference the passcode: 8988706. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001193125-19-312797:8k_2_02:56]
Basis of Presentation

[0001193125-19-312797:8k_2_02:57]
The Company’s financial
results include contributions from CA, Inc.’s continuing operations starting in the first quarter of fiscal year 2019. The financial results from businesses that have been classified as discontinued operations in the Company’s financial
statements are not included in the results presented above, unless otherwise stated.

[0001193125-19-312797:8k_2_02:58]
Due to the Company’s 52/53 week reporting cycle, fiscal year
2018 included an extra week in the first quarter, compared to fiscal year 2019.

[0001193125-19-312797:8k_2_02:59]
Non-GAAP Financial Measures

[0001193125-19-312797:8k_2_02:60]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses,
cash flow and other data on a non-GAAP basis. This non-GAAP information includes the effect, where applicable, of purchase accounting on revenue, and excludes
amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation
settlements, impairment on investment, debt-related costs, gains on investments, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments. Management does not believe that these
items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of
the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing
potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual. Free cash flow measures have limitations as they
omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders
have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-19-312797:8k_2_02:61]
6

[0001193125-19-312797:8k_2_02:62]
Broadcom believes this non-GAAP financial information provides
additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of
the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a
substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data
attached to this press release.

[0001193125-19-312797:8k_2_02:63]
About Broadcom Inc.

[0001193125-19-312797:8k_2_02:64]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad
range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our
solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to
www.broadcom.com.

[0001193125-19-312797:8k_2_02:65]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-19-312797:8k_2_02:66]
7

[0001193125-19-312797:8k_2_02:67]
Particular uncertainties that could materially affect future results include risks associated with: our
acquisition of Symantec Corporation’s Enterprise Security business (“Symantec Business”), including (1) potential difficulties in employee retention, (2) unexpected costs, charges or expenses, and (3) our ability to
successfully integrate the Symantec Business and achieve the anticipated benefits of the transaction; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract
manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; international political and economic conditions; any acquisitions we may make, such as delays, challenges and
expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and
synergies expected by such acquisitions, including our recent acquisition of the Symantec Business; government regulations and trade restrictions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such
debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; involvement in legal or administrative proceedings; quarterly and
annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive
performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities or other significant operations; our
ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our
ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into
satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving
customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy
and data security laws; our ability to protect against a breach of security systems; changes in accounting standards; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our
overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001193125-19-312797:8k_2_02:68]
8

[0001193125-19-312797:8k_2_02:69]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov,
discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the
estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-312797:8k_2_02:70]
Contact:

[0001193125-19-312797:8k_2_02:71]
Broadcom Inc.

[0001193125-19-312797:8k_2_02:72]
Beatrice F. Russotto

[0001193125-19-312797:8k_2_02:73]
Investor Relations

[0001193125-19-312797:8k_2_02:74]
408-433-8000

[0001193125-19-312797:8k_2_02:75]
investor.relations@broadcom.com

[0001193125-19-312797:8k_2_02:76]
9

[0001193125-19-312797:8k_2_02:77]
BROADCOM INC.

[0001193125-19-312797:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-19-312797:8k_2_02:79]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-19-312797:8k_2_02:80]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 3, |  |  | August 4, |  |  | November 4, |  |  | November 3, |  |  | November 4, |  |
|  |  | 2019 |  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net revenue |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,444 |  |  | $ | 22,597 |  |  | $ | 20,848 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,788 |  |  |  | 1,651 |  |  |  | 1,746 |  |  |  | 6,723 |  |  |  | 7,021 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 827 |  |  |  | 828 |  |  |  | 762 |  |  |  | 3,314 |  |  |  | 3,004 |  |
| Restructuring charges |  |  | 9 |  |  |  | 2 |  |  |  | 1 |  |  |  | 77 |  |  |  | 20 |  |
| Total cost of revenue |  |  | 2,624 |  |  |  | 2,481 |  |  |  | 2,509 |  |  |  | 10,114 |  |  |  | 10,115 |  |
| Gross margin |  |  | 3,152 |  |  |  | 3,034 |  |  |  | 2,935 |  |  |  | 12,483 |  |  |  | 10,733 |  |
| Research and development |  |  | 1,177 |  |  |  | 1,235 |  |  |  | 948 |  |  |  | 4,696 |  |  |  | 3,768 |  |
| Selling, general and administrative |  |  | 409 |  |  |  | 410 |  |  |  | 237 |  |  |  | 1,709 |  |  |  | 1,056 |  |
| Amortization of acquisition-related intangible assets |  |  | 474 |  |  |  | 475 |  |  |  | 67 |  |  |  | 1,898 |  |  |  | 541 |  |
| Restructuring, impairment and disposal charges |  |  | 38 |  |  |  | 49 |  |  |  | 17 |  |  |  | 736 |  |  |  | 219 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Total operating expenses |  |  | 2,098 |  |  |  | 2,169 |  |  |  | 1,283 |  |  |  | 9,039 |  |  |  | 5,598 |  |
| Operating income |  |  | 1,054 |  |  |  | 865 |  |  |  | 1,652 |  |  |  | 3,444 |  |  |  | 5,135 |  |
| Interest expense |  |  | (361 | ) |  |  | (362 | ) |  |  | (148 | ) |  |  | (1,444 | ) |  |  | (628 | ) |
| Impairment on investment |  |  | — |  |  |  | — |  |  |  | (106 | ) |  |  | — |  |  |  | (106 | ) |
| Other income, net |  |  | 54 |  |  |  | 41 |  |  |  | 24 |  |  |  | 226 |  |  |  | 144 |  |
| Income from continuing operations before income taxes |  |  | 747 |  |  |  | 544 |  |  |  | 1,422 |  |  |  | 2,226 |  |  |  | 4,545 |  |
| Provision for (benefit from) income taxes |  |  | (100 | ) |  |  | (171 | ) |  |  | 307 |  |  |  | (510 | ) |  |  | (8,084 | ) |
| Income from continuing operations |  |  | 847 |  |  |  | 715 |  |  |  | 1,115 |  |  |  | 2,736 |  |  |  | 12,629 |  |
| Loss from discontinued operations, net of income taxes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  | (19 | ) |
| Net income |  |  | 847 |  |  |  | 715 |  |  |  | 1,115 |  |  |  | 2,724 |  |  |  | 12,610 |  |
| Dividends on preferred stock (1) |  |  | 29 |  |  |  | — |  |  |  | — |  |  |  | 29 |  |  |  | — |  |
| Net income attributable to noncontrolling interest (2) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 818 |  |  | $ | 715 |  |  | $ | 1,115 |  |  | $ | 2,695 |  |  | $ | 12,259 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.06 |  |  | $ | 1.80 |  |  | $ | 2.71 |  |  | $ | 6.80 |  |  | $ | 29.37 |  |
| Loss per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |  |  | (0.04 | ) |
| Net income per share |  | $ | 2.06 |  |  | $ | 1.80 |  |  | $ | 2.71 |  |  | $ | 6.77 |  |  | $ | 29.33 |  |
| Diluted income per share attributable to common stock (3): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 2.64 |  |  | $ | 6.46 |  |  | $ | 28.48 |  |
| Loss per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |  |  | (0.04 | ) |
| Net income per share |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 2.64 |  |  | $ | 6.43 |  |  | $ | 28.44 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 397 |  |  |  | 398 |  |  |  | 412 |  |  |  | 398 |  |  |  | 418 |  |
| Diluted |  |  | 416 |  |  |  | 418 |  |  |  | 423 |  |  |  | 419 |  |  |  | 431 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 41 |  |  | $ | 47 |  |  | $ | 23 |  |  | $ | 163 |  |  | $ | 86 |  |
| Research and development |  |  | 394 |  |  |  | 456 |  |  |  | 225 |  |  |  | 1,532 |  |  |  | 855 |  |
| Selling, general and administrative |  |  | 109 |  |  |  | 129 |  |  |  | 69 |  |  |  | 490 |  |  |  | 286 |  |
| Total stock-based compensation expense |  | $ | 544 |  |  | $ | 632 |  |  | $ | 317 |  |  | $ | 2,185 |  |  | $ | 1,227 |  |

[0001193125-19-312797:8k_2_02:81]
| (1) | Net income attributable to common stock excludes dividends on Mandatory Convertible Preferred Stock issued during the fiscal quarter ended November 3, 2019. |

[0001193125-19-312797:8k_2_02:82]
| (2) | In connection with the redomiciliation to the United States on April 4, 2018, or the Redomiciliation, all outstanding exchangeable limited partnership units, or LP Units, in Broadcom Cayman L.P. were exchanged for common stock of Broadcom on a one-for-one basis and the noncontrolling interest, or NCI, was eliminated. Net income attributable to NCI prior to the Redomiciliation represented approximately 5% of net income attributable to LP Units. |

[0001193125-19-312797:8k_2_02:83]
| (3) | For the fiscal quarter and fiscal year ended November 3, 2019, diluted income per share excluded the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. For the fiscal year ended November 4, 2018, diluted income per share excluded the potentially dilutive effect of LP Units as the impact was antidilutive. There were no LP Units outstanding during any of fiscal year 2019 periods or the fiscal quarter ended November 4, 2018 due to the Redomiciliation. |

[0001193125-19-312797:8k_2_02:84]
10

[0001193125-19-312797:8k_2_02:85]
BROADCOM INC.

[0001193125-19-312797:8k_2_02:86]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-19-312797:8k_2_02:87]
(IN MILLIONS)

[0001193125-19-312797:8k_2_02:88]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 3,2019 |  |  | August 4,2019 |  |  | November 4,2018 |  |  | November 3,2019 |  |  | November 4,2018 |  |
| Net revenue on GAAP basis |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,444 |  |  | $ | 22,597 |  |  | $ | 20,848 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 14 |  |
| Net revenue on non-GAAP basis |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,448 |  |  | $ | 22,597 |  |  | $ | 20,862 |  |
| Gross margin on GAAP basis |  | $ | 3,152 |  |  | $ | 3,034 |  |  | $ | 2,935 |  |  | $ | 12,483 |  |  | $ | 10,733 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 14 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 827 |  |  |  | 828 |  |  |  | 762 |  |  |  | 3,314 |  |  |  | 3,004 |  |
| Stock-based compensation expense |  |  | 41 |  |  |  | 47 |  |  |  | 23 |  |  |  | 163 |  |  |  | 86 |  |
| Restructuring charges |  |  | 9 |  |  |  | 2 |  |  |  | 1 |  |  |  | 77 |  |  |  | 20 |  |
| Acquisition-related costs |  |  | 6 |  |  |  | 5 |  |  |  | — |  |  |  | 18 |  |  |  | 4 |  |
| Gross margin on non-GAAP basis |  | $ | 4,035 |  |  | $ | 3,916 |  |  | $ | 3,725 |  |  | $ | 16,055 |  |  | $ | 13,931 |  |
| Research and development on GAAP basis |  | $ | 1,177 |  |  | $ | 1,235 |  |  | $ | 948 |  |  | $ | 4,696 |  |  | $ | 3,768 |  |
| Stock-based compensation expense |  |  | 394 |  |  |  | 456 |  |  |  | 225 |  |  |  | 1,532 |  |  |  | 855 |  |
| Acquisition-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 5 |  |  |  | 4 |  |
| Research and development on non-GAAP basis |  | $ | 782 |  |  | $ | 778 |  |  | $ | 722 |  |  | $ | 3,159 |  |  | $ | 2,909 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 409 |  |  | $ | 410 |  |  | $ | 237 |  |  | $ | 1,709 |  |  | $ | 1,056 |  |
| Stock-based compensation expense |  |  | 109 |  |  |  | 129 |  |  |  | 69 |  |  |  | 490 |  |  |  | 286 |  |
| Acquisition-related costs |  |  | 65 |  |  |  | 53 |  |  |  | 27 |  |  |  | 252 |  |  |  | 172 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 235 |  |  | $ | 228 |  |  | $ | 141 |  |  | $ | 967 |  |  | $ | 598 |  |
| Total operating expenses on GAAP basis |  | $ | 2,098 |  |  | $ | 2,169 |  |  | $ | 1,283 |  |  | $ | 9,039 |  |  | $ | 5,598 |  |
| Amortization of acquisition-related intangible assets |  |  | 474 |  |  |  | 475 |  |  |  | 67 |  |  |  | 1,898 |  |  |  | 541 |  |
| Stock-based compensation expense |  |  | 503 |  |  |  | 585 |  |  |  | 294 |  |  |  | 2,022 |  |  |  | 1,141 |  |
| Restructuring, impairment and disposal charges |  |  | 38 |  |  |  | 49 |  |  |  | 17 |  |  |  | 736 |  |  |  | 219 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Acquisition-related costs |  |  | 66 |  |  |  | 54 |  |  |  | 28 |  |  |  | 257 |  |  |  | 176 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,017 |  |  | $ | 1,006 |  |  | $ | 863 |  |  | $ | 4,126 |  |  | $ | 3,507 |  |
| Operating income on GAAP basis |  | $ | 1,054 |  |  | $ | 865 |  |  | $ | 1,652 |  |  | $ | 3,444 |  |  | $ | 5,135 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 14 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,301 |  |  |  | 1,303 |  |  |  | 829 |  |  |  | 5,212 |  |  |  | 3,545 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 632 |  |  |  | 317 |  |  |  | 2,185 |  |  |  | 1,227 |  |
| Restructuring, impairment and disposal charges |  |  | 47 |  |  |  | 51 |  |  |  | 18 |  |  |  | 813 |  |  |  | 239 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Acquisition-related costs |  |  | 72 |  |  |  | 59 |  |  |  | 28 |  |  |  | 275 |  |  |  | 180 |  |
| Operating income on non-GAAP basis |  | $ | 3,018 |  |  | $ | 2,910 |  |  | $ | 2,862 |  |  | $ | 11,929 |  |  | $ | 10,424 |  |
| Interest expense on GAAP basis |  | $ | (361 | ) |  | $ | (362 | ) |  | $ | (148 | ) |  | $ | (1,444 | ) |  | $ | (628 | ) |
| Debt-related costs |  |  | 26 |  |  |  | 2 |  |  |  | — |  |  |  | 54 |  |  |  | 32 |  |
| Interest expense on non-GAAP basis |  | $ | (335 | ) |  | $ | (360 | ) |  | $ | (148 | ) |  | $ | (1,390 | ) |  | $ | (596 | ) |
| Other income, net on GAAP basis |  | $ | 54 |  |  | $ | 41 |  |  | $ | 24 |  |  | $ | 226 |  |  | $ | 144 |  |
| Gains on investments |  |  | (50 | ) |  |  | (28 | ) |  |  | — |  |  |  | (145 | ) |  |  | (3 | ) |
| Other income, net on non-GAAP basis |  | $ | 4 |  |  | $ | 13 |  |  | $ | 24 |  |  | $ | 81 |  |  | $ | 141 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 747 |  |  | $ | 544 |  |  | $ | 1,422 |  |  | $ | 2,226 |  |  | $ | 4,545 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 14 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,301 |  |  |  | 1,303 |  |  |  | 829 |  |  |  | 5,212 |  |  |  | 3,545 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 632 |  |  |  | 317 |  |  |  | 2,185 |  |  |  | 1,227 |  |
| Restructuring, impairment and disposal charges |  |  | 47 |  |  |  | 51 |  |  |  | 18 |  |  |  | 813 |  |  |  | 239 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Acquisition-related costs |  |  | 72 |  |  |  | 59 |  |  |  | 28 |  |  |  | 275 |  |  |  | 180 |  |
| Impairment on investment |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Debt-related costs |  |  | 26 |  |  |  | 2 |  |  |  | — |  |  |  | 54 |  |  |  | 32 |  |
| Gains on investments |  |  | (50 | ) |  |  | (28 | ) |  |  | — |  |  |  | (145 | ) |  |  | (3 | ) |
| Income before income taxes on non-GAAP basis |  | $ | 2,687 |  |  | $ | 2,563 |  |  | $ | 2,738 |  |  | $ | 10,620 |  |  | $ | 9,969 |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | (100 | ) |  | $ | (171 | ) |  | $ | 307 |  |  | $ | (510 | ) |  | $ | (8,084 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 396 |  |  |  | 453 |  |  |  | (115 | ) |  |  | 1,678 |  |  |  | 8,662 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 296 |  |  | $ | 282 |  |  | $ | 192 |  |  | $ | 1,168 |  |  | $ | 578 |  |
| Net income on GAAP basis |  | $ | 847 |  |  | $ | 715 |  |  | $ | 1,115 |  |  | $ | 2,724 |  |  | $ | 12,610 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 14 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,301 |  |  |  | 1,303 |  |  |  | 829 |  |  |  | 5,212 |  |  |  | 3,545 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 632 |  |  |  | 317 |  |  |  | 2,185 |  |  |  | 1,227 |  |
| Restructuring, impairment and disposal charges |  |  | 47 |  |  |  | 51 |  |  |  | 18 |  |  |  | 813 |  |  |  | 239 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Acquisition-related costs |  |  | 72 |  |  |  | 59 |  |  |  | 28 |  |  |  | 275 |  |  |  | 180 |  |
| Impairment on investment |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Debt-related costs |  |  | 26 |  |  |  | 2 |  |  |  | — |  |  |  | 54 |  |  |  | 32 |  |
| Gains on investments |  |  | (50 | ) |  |  | (28 | ) |  |  | — |  |  |  | (145 | ) |  |  | (3 | ) |
| Non-GAAP tax reconciling adjustments |  |  | (396 | ) |  |  | (453 | ) |  |  | 115 |  |  |  | (1,678 | ) |  |  | (8,662 | ) |
| Discontinued operations, net of income taxes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 12 |  |  |  | 19 |  |
| Net income on non-GAAP basis |  | $ | 2,391 |  |  | $ | 2,281 |  |  | $ | 2,546 |  |  | $ | 9,452 |  |  | $ | 9,391 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  |  | 416 |  |  |  | 418 |  |  |  | 423 |  |  |  | 419 |  |  |  | 431 |  |
| Non-GAAP adjustment (2) |  |  | 28 |  |  |  | 24 |  |  |  | 12 |  |  |  | 25 |  |  |  | 20 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  |  | 444 |  |  |  | 442 |  |  |  | 435 |  |  |  | 444 |  |  |  | 451 |  |
| Net income on non-GAAP basis |  | $ | 2,391 |  |  | $ | 2,281 |  |  | $ | 2,546 |  |  | $ | 9,452 |  |  | $ | 9,391 |  |
| Interest expense on non-GAAP basis |  |  | 335 |  |  |  | 360 |  |  |  | 148 |  |  |  | 1,390 |  |  |  | 596 |  |
| Provision for income taxes on non-GAAP basis |  |  | 296 |  |  |  | 282 |  |  |  | 192 |  |  |  | 1,168 |  |  |  | 578 |  |
| Depreciation |  |  | 143 |  |  |  | 141 |  |  |  | 132 |  |  |  | 569 |  |  |  | 515 |  |
| Adjusted EBITDA |  | $ | 3,165 |  |  | $ | 3,064 |  |  | $ | 3,018 |  |  | $ | 12,579 |  |  | $ | 11,080 |  |
| Net cash provided by operating activities |  | $ | 2,479 |  |  | $ | 2,419 |  |  | $ | 2,635 |  |  | $ | 9,697 |  |  | $ | 8,880 |  |
| Purchases of property, plant and equipment |  |  | (96 | ) |  |  | (112 | ) |  |  | (106 | ) |  |  | (432 | ) |  |  | (635 | ) |
| Free cash flow |  | $ | 2,383 |  |  | $ | 2,307 |  |  | $ | 2,529 |  |  | $ | 9,265 |  |  | $ | 8,245 |  |

[0001193125-19-312797:8k_2_02:89]
| (1) | Amounts represent licensing revenue not included in GAAP net revenue as a result of the effect of purchase accounting for acquisitions. |

[0001193125-19-312797:8k_2_02:90]
| (2) | Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter and fiscal year ended November 3, 2019, non-GAAP adjustment included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. For the fiscal year ended November 3, 2018, non-GAAP adjustment included the impact of LP Units that were antidilutive on a GAAP basis. |

[0001193125-19-312797:8k_2_02:91]
11

[0001193125-19-312797:8k_2_02:92]
BROADCOM INC.

[0001193125-19-312797:8k_2_02:93]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-19-312797:8k_2_02:94]
(IN MILLIONS)

[0001193125-19-312797:8k_2_02:95]
|  |  | November 3,2019 |  |  | November 4,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,055 |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  |  | 3,259 |  |  |  | 3,325 |  |
| Inventory |  |  | 874 |  |  |  | 1,124 |  |
| Other current assets |  |  | 729 |  |  |  | 366 |  |
| Total current assets |  |  | 9,917 |  |  |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,565 |  |  |  | 2,635 |  |
| Goodwill |  |  | 36,714 |  |  |  | 26,913 |  |
| Intangible assets, net |  |  | 17,554 |  |  |  | 10,762 |  |
| Other long-term assets |  |  | 743 |  |  |  | 707 |  |
| Total assets |  | $ | 67,493 |  |  | $ | 50,124 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 855 |  |  | $ | 811 |  |
| Employee compensation and benefits |  |  | 641 |  |  |  | 715 |  |
| Current portion of long-term debt |  |  | 2,787 |  |  |  | — |  |
| Other current liabilities |  |  | 2,616 |  |  |  | 812 |  |
| Total current liabilities |  |  | 6,899 |  |  |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 30,011 |  |  |  | 17,493 |  |
| Other long-term liabilities |  |  | 5,613 |  |  |  | 3,636 |  |
| Total liabilities |  |  | 42,523 |  |  |  | 23,467 |  |
| Preferred stock dividend obligation |  |  | 29 |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  |  | — |  |
| Common stock |  |  | — |  |  |  | — |  |
| Additional paid-in capital |  |  | 25,081 |  |  |  | 23,285 |  |
| Retained earnings |  |  | — |  |  |  | 3,487 |  |
| Accumulated other comprehensive loss |  |  | (140 | ) |  |  | (115 | ) |
| Total stockholders’ equity |  |  | 24,941 |  |  |  | 26,657 |  |
| Total liabilities and equity |  | $ | 67,493 |  |  | $ | 50,124 |  |

[0001193125-19-312797:8k_2_02:96]
12

[0001193125-19-312797:8k_2_02:97]
BROADCOM INC.

[0001193125-19-312797:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-19-312797:8k_2_02:99]
(IN MILLIONS)

[0001193125-19-312797:8k_2_02:100]
|  |  | Fiscal Quarter Ended |  |  | Fiscal Year Ended |  |
|  |  | November 3,2019 |  |  | August 4,2019 |  |  | November 4,2018 |  |  | November 3,2019 |  |  | November 4,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 847 |  |  | $ | 715 |  |  | $ | 1,115 |  |  | $ | 2,724 |  |  | $ | 12,610 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 1,309 |  |  |  | 1,309 |  |  |  | 836 |  |  |  | 5,239 |  |  |  | 3,566 |  |
| Depreciation |  |  | 143 |  |  |  | 141 |  |  |  | 132 |  |  |  | 569 |  |  |  | 515 |  |
| Stock-based compensation |  |  | 544 |  |  |  | 632 |  |  |  | 317 |  |  |  | 2,185 |  |  |  | 1,227 |  |
| Deferred taxes and other non-cash taxes |  |  | (226 | ) |  |  | (235 | ) |  |  | 242 |  |  |  | (934 | ) |  |  | (8,270 | ) |
| Impairment on investment |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Non-cash restructuring, impairment and disposal charges |  |  | 20 |  |  |  | 15 |  |  |  | 8 |  |  |  | 133 |  |  |  | 21 |  |
| Non-cash interest expense |  |  | 40 |  |  |  | 23 |  |  |  | 6 |  |  |  | 90 |  |  |  | 24 |  |
| Other |  |  | (44 | ) |  |  | (21 | ) |  |  | 15 |  |  |  | (125 | ) |  |  | 37 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | 285 |  |  |  | (60 | ) |  |  | (312 | ) |  |  | 486 |  |  |  | (652 | ) |
| Inventory |  |  | 217 |  |  |  | (57 | ) |  |  | 92 |  |  |  | 250 |  |  |  | 417 |  |
| Accounts payable |  |  | (147 | ) |  |  | 244 |  |  |  | 28 |  |  |  | (42 | ) |  |  | (325 | ) |
| Employee compensation and benefits |  |  | 66 |  |  |  | 104 |  |  |  | 93 |  |  |  | (294 | ) |  |  | 6 |  |
| Contributions to defined benefit pension plans |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (130 | ) |
| Other current assets and current liabilities |  |  | (398 | ) |  |  | (354 | ) |  |  | 163 |  |  |  | (283 | ) |  |  | 369 |  |
| Other long-term assets and long-term liabilities |  |  | (177 | ) |  |  | (37 | ) |  |  | (206 | ) |  |  | (301 | ) |  |  | (641 | ) |
| Net cash provided by operating activities |  |  | 2,479 |  |  |  | 2,419 |  |  |  | 2,635 |  |  |  | 9,697 |  |  |  | 8,880 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (6 | ) |  |  | (7 | ) |  |  | (16,033 | ) |  |  | (4,800 | ) |
| Business sale proceeds (repayments) |  |  | — |  |  |  | — |  |  |  | (9 | ) |  |  | 957 |  |  |  | 773 |  |
| Purchases of property, plant and equipment |  |  | (96 | ) |  |  | (112 | ) |  |  | (106 | ) |  |  | (432 | ) |  |  | (635 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 6 |  |  |  | 82 |  |  |  | 1 |  |  |  | 88 |  |  |  | 239 |  |
| Purchases of investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | (249 | ) |
| Proceeds from sales of investments |  |  | — |  |  |  | 2 |  |  |  | — |  |  |  | 5 |  |  |  | 54 |  |
| Other |  |  | 2 |  |  |  | (1 | ) |  |  | 3 |  |  |  | (2 | ) |  |  | (56 | ) |
| Net cash used in investing activities |  |  | (88 | ) |  |  | (35 | ) |  |  | (118 | ) |  |  | (15,422 | ) |  |  | (4,674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 28,793 |  |  |  | — |  |
| Repayment of debt |  |  | (4,800 | ) |  |  | — |  |  |  | (117 | ) |  |  | (16,800 | ) |  |  | (973 | ) |
| Other borrowings, net |  |  | (104 | ) |  |  | (230 | ) |  |  | — |  |  |  | 1,241 |  |  |  | — |  |
| Dividend and distribution payments |  |  | (1,054 | ) |  |  | (1,057 | ) |  |  | (723 | ) |  |  | (4,235 | ) |  |  | (2,998 | ) |
| Repurchases of common stock - repurchase program |  |  | (433 | ) |  |  | (736 | ) |  |  | (1,533 | ) |  |  | (5,435 | ) |  |  | (7,258 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  |  | (154 | ) |  |  | (241 | ) |  |  | (21 | ) |  |  | (972 | ) |  |  | (56 | ) |
| Issuance of preferred stock, net |  |  | 3,679 |  |  |  | — |  |  |  | — |  |  |  | 3,679 |  |  |  | — |  |
| Issuance of common stock |  |  | 59 |  |  |  | 11 |  |  |  | 59 |  |  |  | 253 |  |  |  | 212 |  |
| Other |  |  | 9 |  |  |  | 3 |  |  |  | (26 | ) |  |  | (36 | ) |  |  | (45 | ) |
| Net cash provided by (used in) financing activities |  |  | (2,798 | ) |  |  | (2,250 | ) |  |  | (2,361 | ) |  |  | 6,488 |  |  |  | (11,118 | ) |
| Net change in cash and cash equivalents |  |  | (407 | ) |  |  | 134 |  |  |  | 156 |  |  |  | 763 |  |  |  | (6,912 | ) |
| Cash and cash equivalents at the beginning of period |  |  | 5,462 |  |  |  | 5,328 |  |  |  | 4,136 |  |  |  | 4,292 |  |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | 5,055 |  |  | $ | 5,462 |  |  | $ | 4,292 |  |  | $ | 5,055 |  |  | $ | 4,292 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 307 |  |  | $ | 368 |  |  | $ | 2 |  |  | $ | 1,287 |  |  | $ | 547 |  |
| Cash paid for income taxes |  | $ | 123 |  |  | $ | 98 |  |  | $ | 189 |  |  | $ | 741 |  |  | $ | 512 |  |

[0001193125-19-312797:8k_2_02:101]
13

## item 5.02 — body, verbatim

[0001193125-19-312797:8k_body:1]
Item 5.02.

[0001193125-19-312797:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-19-312797:8k_body:3]
On December 10, 2019, the Board approved the Company’s Fiscal Year 2020 Annual Performance Bonus Plan for Executive Employees (the “Plan”), which is the Company’s performance-based annual cash incentive bonus plan for its executive management employees for its fiscal year ending November 1, 2020. The terms of the Plan are substantially the same as the Fiscal Year 2019 Annual Performance Bonus Plan for Executive Employees, adopted in respect of the Company’s Fiscal Year 2019, other than with regard to the applicable annual performance metrics.
