# AVGO notes — 0001730168-19-000144


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001730168-19-000144:notes:1]
Information required in response to Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the registrant’s definitive Proxy Statement for its 2020 Annual Meeting of Stockholders. Except as expressly incorporated by reference, the registrant’s Proxy Statement shall not be deemed to be a part of this Annual Report on Form 10-K. The registrant intends to file its definitive Proxy Statement within 120 days after its fiscal year ended November 3, 2019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-19-000144:notes:2]
Overview and Basis of Presentation 
Overview

[0001730168-19-000144:notes:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

[0001730168-19-000144:notes:4]
The Redomiciliation Transaction was accounted for as an exchange of equity interests among entities under common control and the historical basis of accounting was retained as if the entities had always been combined for financial reporting purposes.

[0001730168-19-000144:notes:5]
The financial statements relate to Broadcom-Singapore for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, and relate to Broadcom for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

[0001730168-19-000144:notes:6]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage, and secure applications across mainframe, distributed, mobile, and cloud platforms.

[0001730168-19-000144:notes:7]
Basis of Presentation

[0001730168-19-000144:notes:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ended on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks. Our fiscal year ended October 29, 2017 (“fiscal year 2017”) was a 52-week fiscal year.

[0001730168-19-000144:notes:9]
On November 5, 2018 (the “CA Acquisition Date”), we acquired CA, Inc. (“CA”). On November 17, 2017, we acquired Brocade Communications Systems, Inc. (“Brocade”). The accompanying consolidated financial statements include the results of operations of CA and Brocade commencing as of their respective acquisition dates. See Note 4. “Acquisitions” for additional information.

[0001730168-19-000144:notes:10]
Subsequent to our acquisition of CA (the “CA Merger”), we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property (“IP”) licensing. Prior period segment results have been recast to conform to the current presentation. See Note 12. “Segment Information” for additional information.

[0001730168-19-000144:notes:11]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted principles in the United States (“GAAP”). All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-19-000144:notes:12]
Summary of Significant Accounting Policies 
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. As such, foreign currency assets and liabilities are remeasured into U.S. dollars at current exchange rates except for non-monetary items such as inventory and property, plant and equipment, which are remeasured at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.

[0001730168-19-000144:notes:13]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates, and such differences could affect the results of operations reported in future periods.

[0001730168-19-000144:notes:14]
Cash and cash equivalents.  We consider all highly liquid investment securities with original or remaining maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.

[0001730168-19-000144:notes:15]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the amount of probable credit losses in our existing accounts receivable. We determine the allowance based on customer-specific experience and the aging of such receivables, among other factors. Allowances for doubtful accounts were not material as of November 3, 2019 or November 4, 2018. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances at November 3, 2019 and November 4, 2018 were $178 million and $161 million, respectively.

[0001730168-19-000144:notes:16]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with several financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-19-000144:notes:17]
Concentration of other risks.  We operate in markets that are highly competitive and rapidly changing. Significant technological changes, shifting customer needs, the emergence of competitive products with new capabilities, general economic conditions worldwide, the ability to safeguard patents and other intellectual property in a rapidly evolving market and reliance on assembly and test subcontractors, third-party wafer fabricators and independent distributors and other factors could affect our financial results.

[0001730168-19-000144:notes:18]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.

[0001730168-19-000144:notes:19]
Retirement benefits. Post-retirement benefit plan assets and liabilities are estimates of benefits that we expect to pay to eligible retirees. We consider various factors in determining the value of our post-retirement plan assets and liabilities, including the number of employees that we expect to receive benefits and other actuarial assumptions.

[0001730168-19-000144:notes:20]
For defined benefit pension plans, we consider various factors in determining our respective pension liabilities and net periodic benefit costs, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the retirement benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-19-000144:notes:21]
The key benefit plan assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on the results of matching expected plan benefit payments with cash flows from a hypothetical yield curve constructed with high-quality corporate bond yields. The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy.

[0001730168-19-000144:notes:22]
For the non-U.S. plans, we set assumptions specific to each country. We have elected to measure post-retirement benefit plan and defined benefit pension plan assets and liabilities as of October 31, which is the month-end that is closest to our fiscal year-ends.

[0001730168-19-000144:notes:23]
Derivative instruments.  We are subject to foreign currency risks for transactions denominated in foreign currencies, primarily the Singapore Dollar, Israeli Shekel, Euro, Japanese Yen and Indian Rupee. Therefore, we enter into foreign exchange forward contracts to manage financial exposures resulting from the changes in the exchange rates of these foreign currencies. These contracts are designated at inception as hedges of the related foreign currency exposures, which include committed and forecasted revenue and expense transactions that are denominated in currencies other than the functional currency of the subsidiary which has the exposure. We exclude time value from the measurement of effectiveness. To achieve hedge accounting, contracts must reduce the foreign currency exchange rate risk otherwise inherent in the amount and duration of the hedged exposures and comply with established risk management policies; our hedging contracts generally mature within three months. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-19-000144:notes:24]
We designate our forward contracts as either cash flow or fair value hedges. All derivatives are recognized on the consolidated balance sheets at their fair values based on Level 2 inputs as defined in the fair value hierarchy. The accounting for gains and losses resulting from changes in fair value depends on the use of the derivative and whether it is designated and qualifies for hedge accounting. For derivative instruments that are designated and qualify as fair value hedges, changes in value of the instruments are recognized in net income in the current period. Such hedges are recognized in net income and are offset by the changes in fair value of the underlying assets or liabilities being hedged. For derivative instruments that are designated and qualify as cash flow hedges, changes in the value of the effective portion of the derivative instrument are recognized in accumulated other comprehensive loss, a component of stockholders’ equity. These amounts are then reclassified and recognized in net income when either the forecasted transaction affects earnings or it becomes probable the forecasted transaction will not occur. Changes in the fair value of the ineffective portion of derivative instruments are recognized in net income in the current period, which have not been material to date. Changes in the value of derivative instruments not designated as hedges are recognized in other income, net, in our consolidated statements of operations. We did not have any outstanding foreign exchange forward contracts as of November 3, 2019 or November 4, 2018.

[0001730168-19-000144:notes:25]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years, or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over three to ten years. We use the straight-line method of depreciation for all property, plant and equipment.

[0001730168-19-000144:notes:26]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-19-000144:notes:27]
The three levels of the fair value hierarchy under the guidance for fair value measurements are described below:

[0001730168-19-000144:notes:28]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date. Our Level 1 assets include cash equivalents, banker's acceptances, trading securities investments and investment funds. We measure trading securities investments and investment funds at quoted market prices as they are traded in an active market with sufficient volume and frequency of transactions.

[0001730168-19-000144:notes:29]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-19-000144:notes:30]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Level 3 assets and liabilities include cost method investments, goodwill, intangible assets, and property, plant and equipment, which are measured at fair value using a discounted cash flow approach when they are impaired. Quantitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.

[0001730168-19-000144:notes:31]
Business combinations.  We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition date fair values. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date including our estimates for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets under the income approach include growth in future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp-up period, technology obsolescence rates, expected costs to develop in-process research and development (“IPR&D”) into commercially viable products, estimated cash flows from the projects when completed and discount rates. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-19-000144:notes:32]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-19-000144:notes:33]
Long-lived assets.  Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.

[0001730168-19-000144:notes:34]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-19-000144:notes:35]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-19-000144:notes:36]
Nature of Products and Services

[0001730168-19-000144:notes:37]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-19-000144:notes:38]
Products.  We recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

[0001730168-19-000144:notes:39]
Subscriptions and services.  Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

[0001730168-19-000144:notes:40]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-19-000144:notes:41]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

[0001730168-19-000144:notes:42]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-19-000144:notes:43]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-19-000144:notes:44]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-19-000144:notes:45]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-19-000144:notes:46]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-19-000144:notes:47]
Arrangements with Multiple Performance Obligations

[0001730168-19-000144:notes:48]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-19-000144:notes:49]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-19-000144:notes:50]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-19-000144:notes:51]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-19-000144:notes:52]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-19-000144:notes:53]
Other Policies and Judgments

[0001730168-19-000144:notes:54]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-19-000144:notes:55]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-19-000144:notes:56]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

[0001730168-19-000144:notes:57]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-19-000144:notes:58]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units (“RSUs”) using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for time-based stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”) based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-19-000144:notes:59]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-19-000144:notes:60]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-19-000144:notes:61]
Shipping and handling costs.  Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in total cost of revenue in the consolidated statements of operations for all periods presented.

[0001730168-19-000144:notes:62]
Litigation and settlement cost. We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.

[0001730168-19-000144:notes:63]
Taxes on income.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-19-000144:notes:64]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes. Likewise, if we determine that we are not able to realize all or part of our net deferred tax assets, we increase the provision for income taxes in the period such determination is made.

[0001730168-19-000144:notes:65]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.

[0001730168-19-000144:notes:66]
Net income per share. Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested RSUs and ESPP rights (together referred to as “equity awards”), as well as convertible preferred stock and LP Units. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-19-000144:notes:67]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of convertible preferred stock and LP Units is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.

[0001730168-19-000144:notes:68]
Reclassifications. Certain reclassifications have been made to the prior period consolidated balance sheet, statements of operations, statements of cash flows and statements of equity. These reclassifications have no impact on the previously reported total stockholders’ equity, net income or net cash activities.

[0001730168-19-000144:notes:69]
Recently Adopted Accounting Guidance

[0001730168-19-000144:notes:70]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board (“FASB”) guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the consolidated statements of operations presented herein.

[0001730168-19-000144:notes:71]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal year ended November 3, 2019, we also recognized $145 million of unrealized gains on equity securities within other income, net in our consolidated statements of operations.

[0001730168-19-000144:notes:72]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (“Topic 606”). We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant.

[0001730168-19-000144:notes:73]
Recent Accounting Guidance Not Yet Adopted

[0001730168-19-000144:notes:74]
In February 2016, the FASB issued guidance related to the accounting for leases, which among other things, requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”). We will adopt this guidance using the optional transition method and will not restate comparative prior periods. We are finalizing the implementation of related systems, policies, processes and internal controls to comply with this guidance. Based on our lease portfolio as of November 3, 2019, we expect the adoption of the new leasing guidance to result in recognition of operating right-of-use assets and corresponding liabilities on our consolidated balance sheet within a range of $500 million to $600 million, primarily related to real estate.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-19-000144:notes:75]
Revenue from Contracts with Customers 
Disaggregation

[0001730168-19-000144:notes:76]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 12. “Segment Information”.

[0001730168-19-000144:notes:77]
The following table presents revenue disaggregated by type of revenue and by region:

[0001730168-19-000144:notes:78]
|  |  | Fiscal Year Ended November 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,023 |  |  | $ | 14,857 |  |  | $ | 1,237 |  |  | $ | 18,117 |  |
| Subscriptions and services(a) |  | 3,126 |  |  | 374 |  |  | 980 |  |  | 4,480 |  |
| Total |  | $ | 5,149 |  |  | $ | 15,231 |  |  | $ | 2,217 |  |  | $ | 22,597 |  |

[0001730168-19-000144:notes:79]
________________________________

[0001730168-19-000144:notes:80]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

[0001730168-19-000144:notes:81]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, OEMs, contract manufacturers, channel partners, or software customers.

[0001730168-19-000144:notes:82]
Contract Balances

[0001730168-19-000144:notes:83]
Contract assets and contract liabilities balances for the periods indicated below were as follows:

[0001730168-19-000144:notes:84]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018(a) |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |

[0001730168-19-000144:notes:85]
(a) We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

[0001730168-19-000144:notes:86]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal year ended November 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $200 million.

[0001730168-19-000144:notes:87]
Remaining Performance Obligations

[0001730168-19-000144:notes:88]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

[0001730168-19-000144:notes:89]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of November 3, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

[0001730168-19-000144:notes:90]
Contract Costs

[0001730168-19-000144:notes:91]
We have applied the practical expedient to expense commission costs as incurred for costs to obtain a contract when the amortization period would have been one year or less. As a result, no commission costs are capitalized.

[0001730168-19-000144:notes:92]
We recognize an asset for costs incurred to fulfill a contract that are not within the scope of other accounting literature. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

[0001730168-19-000144:notes:93]
Topic 606 Adoption

[0001730168-19-000144:notes:94]
We applied Topic 606 using the modified retrospective method for all contracts not completed as of the date of adoption. For contracts that were modified before the effective date, we reflected the aggregate effect of all modifications when identifying the performance obligations and allocating the transaction price at transition, which did not have a material effect on the adjustment to retained earnings as of November 5, 2018.

[0001730168-19-000144:notes:95]
We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected consolidated balance sheet line items as of November 5, 2018:

[0001730168-19-000144:notes:96]
| Balance Sheet |  | Ending Balance as of November 4, 2018 |  | Adjustments Due to Topic 606 |  | Opening Balance as of November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

[0001730168-19-000144:notes:97]
Impact of New Revenue Guidance on Net Revenue

[0001730168-19-000144:notes:98]
The following table compares net revenue for the period presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the consolidated statements of operations for the fiscal year ended November 3, 2019 or in the consolidated balance sheet as of November 3, 2019 were significantly affected by the new revenue guidance.

[0001730168-19-000144:notes:99]
|  |  | Fiscal Year Ended November 3, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of Change |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 18,117 |  |  | $ | — |  |  | $ | 18,117 |  |
| Subscriptions and services |  | 4,257 |  |  | 223 |  |  | 4,480 |  |
| Total net revenue |  | $ | 22,374 |  |  | $ | 223 |  |  | $ | 22,597 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-19-000144:notes:100]
Acquisitions 
Acquisition of CA, Inc.

[0001730168-19-000144:notes:101]
On November 5, 2018, we acquired CA, which was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities. We financed the CA Merger with the net proceeds from borrowings under the Original 2019 Term Loans, as defined in Note 9. “Borrowings,” as well as with cash on hand of the combined companies.

[0001730168-19-000144:notes:102]
Purchase Consideration

[0001730168-19-000144:notes:103]
|  |  | (In millions) |
| Cash paid for outstanding CA common stock |  | $ | 18,402 |  |
| Cash paid by Broadcom to retire CA’s term loan |  | 274 |  |
| Cash paid for vested CA equity awards |  | 101 |  |
| Fair value of partially vested assumed equity awards |  | 67 |  |
| Total purchase consideration |  | 18,844 |  |
| Less: cash acquired |  | 2,750 |  |
| Total purchase consideration, net of cash acquired |  | $ | 16,094 |  |

[0001730168-19-000144:notes:104]
All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon the completion of the CA Merger. We assumed all unvested CA equity awards held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of CA employees represents a component of the total consideration as presented above and was valued based on our share price as of the CA Acquisition Date. The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-19-000144:notes:105]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,665 |  |
| Goodwill |  | 9,796 |  |
| Intangible assets |  | 12,045 |  |
| Other long-term assets |  | 240 |  |
| Total assets acquired |  | 23,746 |  |
| Current liabilities |  | (1,966 | ) |
| Long-term debt |  | (2,255 | ) |
| Other long-term liabilities |  | (3,431 | ) |
| Total liabilities assumed |  | (7,652 | ) |
| Fair value of net assets acquired |  | $ | 16,094 |  |

[0001730168-19-000144:notes:106]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the CA business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the CA Merger. Goodwill is not deductible for tax purposes.

[0001730168-19-000144:notes:107]
Current assets included assets held-for-sale related to CA’s Veracode business, which was not aligned with our strategic objectives. On December 31, 2018, we sold this business to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Current assets also included $80 million of real properties held-for-sale. During fiscal year 2019, we sold a portion of these real properties for $62 million and recognized a loss of $8 million.

[0001730168-19-000144:notes:108]
Our results of continuing operations for fiscal year 2019 included $3,377 million of net revenue attributable to CA. It was impracticable to determine the effect on net income attributable to CA as we had integrated a substantial portion of CA into our ongoing operations during the year. The results of operations of CA were included in our infrastructure software segment. Transaction costs related to the CA Merger of $73 million were included in selling, general and administrative expense for fiscal year 2019.

[0001730168-19-000144:notes:109]
Intangible Assets

[0001730168-19-000144:notes:110]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 4,957 |  |  | 6 |
| Customer contracts and related relationships |  | 4,190 |  |  | 6 |
| Order backlog |  | 2,569 |  |  | 3 |
| Trade name and other |  | 137 |  |  | 5 |
| Total identified finite-lived intangible assets |  | 11,853 |  |  |  |
| IPR&D |  | 192 |  |  | N/A |
| Total identified intangible assets |  | $ | 12,045 |  |  |  |

[0001730168-19-000144:notes:111]
Developed technology relates to products used for mission critical business tools for processes and applications, as well as products used for cloud-based planning, development, management and security tools. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-19-000144:notes:112]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of CA. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-19-000144:notes:113]
Order backlog represents business under existing contractual obligations. The fair value of backlog was determined using the multi-period excess earnings method under the income approach based on expected operating cash flows from future contractual revenue. The economic useful life was determined based on the expected life of the backlog and the cash flows over the forecast period.

[0001730168-19-000144:notes:114]
Trade name relates to the “CA” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-19-000144:notes:115]
The fair value of IPR&D was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-19-000144:notes:116]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the CA Acquisition Date.

[0001730168-19-000144:notes:117]
The following table summarizes the details of IPR&D by category as of the CA Acquisition Date:

[0001730168-19-000144:notes:118]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Completion Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Mainframe |  | $ | 178 |  |  | 67 | % |  | $ | 138 |  |  | 2019 |
| Enterprise Solutions |  | $ | 14 |  |  | 63 | % |  | $ | 12 |  |  | 2019 |

[0001730168-19-000144:notes:119]
Discount rates of 12% and 14% were applied to the projected cash flows to reflect the risk related to these mainframe and enterprise solutions IPR&D projects, respectively.

[0001730168-19-000144:notes:120]
As of November 3, 2019, these IPR&D projects are expected to be fully placed in service during the first half of fiscal year 2020.

[0001730168-19-000144:notes:121]
Unaudited Pro Forma Information

[0001730168-19-000144:notes:122]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if CA had been acquired as of the beginning of fiscal year 2018. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For fiscal year 2018, non-recurring pro forma adjustments directly attributable to the CA Merger included transaction costs of $180 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-19-000144:notes:123]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 21,697 |  |  | $ | 24,451 |  |
| Pro forma net income attributable to common stock |  | $ | 2,535 |  |  | $ | 9,783 |  |

[0001730168-19-000144:notes:124]
* Pro forma net revenue was presented under Topic 606 for fiscal year 2019 and under Topic 605 for fiscal year 2018.

[0001730168-19-000144:notes:125]
Acquisition of Brocade

[0001730168-19-000144:notes:126]
On November 17, 2017 (the “Brocade Acquisition Date”), we acquired Brocade (the “Brocade Merger”). Brocade was a supplier of networking hardware, software and services, including Fibre Channel Storage Area Network (“FC SAN”) solutions and Internet Protocol Networking (“IP Networking”) solutions. We acquired Brocade to enhance our position as a provider of enterprise storage connectivity solutions, broaden our portfolio for enterprise storage, and to increase our ability to address the evolving needs of our original equipment manufacturer (“OEM”) customers. We financed the Brocade Merger with a portion of the net proceeds from the issuance of the 2017 Senior Notes, as defined in Note 15. “Condensed Consolidating Financial Information,” as well as with cash on hand.

[0001730168-19-000144:notes:127]
|  |  | (In millions) |
| Cash paid for outstanding Brocade common stock |  | $ | 5,298 |  |
| Cash paid by Broadcom to retire Brocade’s term loan |  | 701 |  |
| Cash paid for Brocade equity awards |  | 31 |  |
| Fair value of partially vested assumed equity awards |  | 8 |  |
| Total purchase consideration |  | 6,038 |  |
| Less: cash acquired |  | 1,250 |  |
| Total purchase consideration, net of cash acquired |  | $ | 4,788 |  |

[0001730168-19-000144:notes:128]
We assumed all unvested Brocade stock options, RSUs and performance stock units (“PSUs”) held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of Brocade employees represents a component of the total consideration as presented above. All vested in-the-money Brocade stock options, after giving effect to any acceleration, were cashed out upon the completion of the Brocade Merger. RSUs and PSUs were valued based on our share price as of the Brocade Acquisition Date.

[0001730168-19-000144:notes:129]
The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-19-000144:notes:130]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,297 |  |
| Goodwill |  | 2,187 |  |
| Intangible assets |  | 3,396 |  |
| Other long-term assets |  | 82 |  |
| Total assets acquired |  | 6,962 |  |
| Current portion of long-term debt |  | (856 | ) |
| Other current liabilities |  | (374 | ) |
| Long-term debt |  | (38 | ) |
| Other long-term liabilities |  | (906 | ) |
| Total liabilities assumed |  | (2,174 | ) |
| Fair value of net assets acquired |  | $ | 4,788 |  |

[0001730168-19-000144:notes:131]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Brocade business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Brocade Merger. Goodwill is not deductible for tax purposes.

[0001730168-19-000144:notes:132]
Current assets included assets held-for-sale related to Brocade’s IP Networking business, which was not aligned with our strategic objectives. On December 1, 2017, we sold this business to ARRIS International plc (“ARRIS”) for cash consideration of $800 million, before contractual working capital adjustments. In connection with this sale, we indemnified ARRIS for $116 million of potential income tax liabilities. We provided transitional services as short-term assistance to ARRIS in assuming the operations of the purchased business. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-19-000144:notes:133]
Current assets also included assets held-for-sale for Brocade’s headquarters, which was sold for $224 million during fiscal year 2018, for no gain or loss.

[0001730168-19-000144:notes:134]
Our results of continuing operations for fiscal year 2018 included $1,780 million of net revenue attributable to Brocade. It was impracticable to determine the effect on net income attributable to Brocade as we had integrated a substantial portion of Brocade into our ongoing operations. The results of operations of Brocade were primarily included in our infrastructure software segment. Transaction costs of $29 million related to the Brocade Merger were included in selling, general and administrative expense for fiscal year 2018.

[0001730168-19-000144:notes:135]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,925 |  |  | 10 |
| Customer contracts and related relationships |  | 255 |  |  | 11 |
| Trade name and other |  | 61 |  |  | 6 |
| Total identified finite-lived intangible assets |  | 3,241 |  |  |  |
| IPR&D |  | 155 |  |  | N/A |
| Total identified intangible assets |  | $ | 3,396 |  |  |  |

[0001730168-19-000144:notes:136]
Developed technology relates to products for FC SAN applications. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-19-000144:notes:137]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Brocade. Customer contracts and related relationships were valued using the distributor method and the with-and-without-method under the income approach. The distributor method determines the fair value by measuring the economic profits generated by an intermediary, which in our case represented OEM customers. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. In both instances, the economic useful life was determined based on historical customer turnover rates.

[0001730168-19-000144:notes:138]
Trade name relates to the “Brocade” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-19-000144:notes:139]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Brocade Acquisition Date.

[0001730168-19-000144:notes:140]
The following table summarizes the details of IPR&D by category at the Brocade Acquisition Date:

[0001730168-19-000144:notes:141]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Completion Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Directors |  | $ | 64 |  |  | 72 | % |  | $ | 45 |  |  | 2019 |
| Switches |  | $ | 50 |  |  | 81 | % |  | $ | 21 |  |  | 2018 |
| Embedded |  | $ | 31 |  |  | 74 | % |  | $ | 22 |  |  | 2019 |
| Networking software |  | $ | 10 |  |  | 73 | % |  | $ | 27 |  |  | 2018 |

[0001730168-19-000144:notes:142]
A discount rate of 11% was applied to the projected cash flows to reflect the risk related to these IPR&D projects. The discount rate represented a premium of 1% over the weighted-average cost of capital to reflect the higher risk and uncertainty of the cash flows for IPR&D relative to the overall businesses.

[0001730168-19-000144:notes:143]
As of November 3, 2019, these IPR&D projects were substantially complete and placed in service.

[0001730168-19-000144:notes:144]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if Brocade had been acquired as of the beginning of fiscal year 2017. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2017 or of the results of our future operations of the combined business.

[0001730168-19-000144:notes:145]
|  |  | Fiscal Year |
|  |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 20,978 |  |  | $ | 19,441 |  |
| Pro forma net income attributable to common stock |  | $ | 12,408 |  |  | $ | 986 |  |

[0001730168-19-000144:notes:146]
* Pro forma net revenue was presented under Topic 605 for fiscal years 2018 and 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-19-000144:notes:147]
Supplemental Financial Information 
Cash Equivalents

[0001730168-19-000144:notes:148]
Cash equivalents included $850 million and $1,406 million of time deposits as of November 3, 2019 and November 4, 2018, respectively. As of November 3, 2019 and November 4, 2018, cash equivalents also included $649 million and $202 million, respectively, of money-market funds. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-19-000144:notes:149]
Accounts Receivable Factoring

[0001730168-19-000144:notes:150]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring agreements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring agreements were $1,151 million and $362 million during fiscal years 2019 and 2018, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any period presented.

[0001730168-19-000144:notes:151]
Inventory

[0001730168-19-000144:notes:152]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Finished goods |  | $ | 339 |  |  | $ | 483 |  |
| Work-in-process |  | 414 |  |  | 505 |  |
| Raw materials |  | 121 |  |  | 136 |  |
| Total inventory |  | $ | 874 |  |  | $ | 1,124 |  |

[0001730168-19-000144:notes:153]
Property, Plant and Equipment, Net

[0001730168-19-000144:notes:154]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Land |  | $ | 189 |  |  | $ | 189 |  |
| Construction in progress |  | 85 |  |  | 67 |  |
| Buildings and leasehold improvements |  | 1,078 |  |  | 1,016 |  |
| Machinery and equipment |  | 3,544 |  |  | 3,257 |  |
| Total property, plant and equipment |  | 4,896 |  |  | 4,529 |  |
| Accumulated depreciation and amortization |  | (2,331 | ) |  | (1,894 | ) |
| Total property, plant and equipment, net |  | $ | 2,565 |  |  | $ | 2,635 |  |

[0001730168-19-000144:notes:155]
Depreciation expense was $569 million, $515 million and $451 million for fiscal years 2019, 2018 and 2017, respectively.

[0001730168-19-000144:notes:156]
As of November 3, 2019 and November 4, 2018, we had $35 million and $22 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable and other current liabilities. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the consolidated statements of cash flows in the period in which they are paid.

[0001730168-19-000144:notes:157]
Other Current Assets

[0001730168-19-000144:notes:158]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 302 |  |  | $ | 243 |  |
| Other (miscellaneous) |  | 427 |  |  | 123 |  |
| Total other current assets |  | $ | 729 |  |  | $ | 366 |  |

[0001730168-19-000144:notes:159]
Other Current Liabilities

[0001730168-19-000144:notes:160]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 1,501 |  |  | $ | 164 |  |
| Tax liabilities |  | 229 |  |  | 162 |  |
| Interest payable |  | 214 |  |  | 165 |  |
| Accrued rebates |  | 95 |  |  | 161 |  |
| Other (miscellaneous) |  | 577 |  |  | 160 |  |
| Total other current liabilities |  | $ | 2,616 |  |  | $ | 812 |  |

[0001730168-19-000144:notes:161]
Other Long-Term Liabilities

[0001730168-19-000144:notes:162]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Unrecognized tax benefits (a) (b) |  | $ | 3,269 |  |  | $ | 3,088 |  |
| Tax indemnification liability |  | 116 |  |  | 116 |  |
| Other (miscellaneous) |  | 2,228 |  |  | 432 |  |
| Total other long-term liabilities |  | $ | 5,613 |  |  | $ | 3,636 |  |

[0001730168-19-000144:notes:163]
(a) Refer to Note 11. “Income Taxes” for additional information regarding these balances.

[0001730168-19-000144:notes:164]
(b) Includes accrued interest and penalties.

[0001730168-19-000144:notes:165]
Other Income, Net

[0001730168-19-000144:notes:166]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Gain (loss) on investment |  | $ | 145 |  |  | $ | 3 |  |  | $ | (1 | ) |
| Interest income |  | 98 |  |  | 114 |  |  | 44 |  |
| Other income |  | 18 |  |  | 27 |  |  | 55 |  |
| Other expense |  | (35 | ) |  | — |  |  | (24 | ) |
| Other income, net |  | $ | 226 |  |  | $ | 144 |  |  | $ | 74 |  |

[0001730168-19-000144:notes:167]
Other income includes gains (losses) on foreign currency remeasurement and other miscellaneous items.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-19-000144:notes:168]
Goodwill and Intangible Assets 
Goodwill

[0001730168-19-000144:notes:169]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of October 29, 2017 |  | $ | 17,622 |  |  | $ | 5,945 |  |  | $ | 995 |  |  | $ | 144 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 24,706 |  |
| Acquisitions |  | 83 |  |  | — |  |  | 2,117 |  |  | 7 |  |  | — |  |  | — |  |  | — |  |  | 2,207 |  |
| Balance as of November 4, 2018 |  | 17,705 |  |  | 5,945 |  |  | 3,112 |  |  | 151 |  |  | — |  |  | — |  |  | — |  |  | 26,913 |  |
| Reallocation due to change in segments |  | (17,705 | ) |  | (5,945 | ) |  | (3,112 | ) |  | (151 | ) |  | 25,924 |  |  | 980 |  |  | 9 |  |  | — |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | 9,796 |  |  | — |  |  | 9,801 |  |
| Balance as of November 3, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25,929 |  |  | $ | 10,776 |  |  | $ | 9 |  |  | $ | 36,714 |  |

[0001730168-19-000144:notes:170]
During the first quarter of fiscal year 2019, we changed our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. As a result, we have reassigned the goodwill balance to reflect our new segment structure using a relative fair value allocation approach. Under this approach, the fair value of each segment was determined using a combination of the income approach and the market approach, and was compared to the fair value of the total business immediately prior to the reorganization to arrive at the reassigned goodwill balance.

[0001730168-19-000144:notes:171]
During the fourth quarter of fiscal years 2019, 2018 and 2017, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-19-000144:notes:172]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of November 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,935 |  |  | $ | (10,113 | ) |  | $ | 10,822 |  |
| Customer contracts and related relationships |  | 5,978 |  |  | (1,787 | ) |  | 4,191 |  |
| Order backlog |  | 2,569 |  |  | (908 | ) |  | 1,661 |  |
| Trade names |  | 712 |  |  | (247 | ) |  | 465 |  |
| Other |  | 241 |  |  | (89 | ) |  | 152 |  |
| Intangible assets subject to amortization |  | 30,435 |  |  | (13,144 | ) |  | 17,291 |  |
| IPR&D |  | 263 |  |  | — |  |  | 263 |  |
| Total |  | $ | 30,698 |  |  | $ | (13,144 | ) |  | $ | 17,554 |  |
| As of November 4, 2018: |  |  |  |  |  |  |
| Purchased technology |  | $ | 15,806 |  |  | $ | (6,816 | ) |  | $ | 8,990 |  |
| Customer contracts and related relationships |  | 1,792 |  |  | (878 | ) |  | 914 |  |
| Trade names |  | 578 |  |  | (170 | ) |  | 408 |  |
| Other |  | 239 |  |  | (53 | ) |  | 186 |  |
| Intangible assets subject to amortization |  | 18,415 |  |  | (7,917 | ) |  | 10,498 |  |
| IPR&D |  | 264 |  |  | — |  |  | 264 |  |
| Total |  | $ | 18,679 |  |  | $ | (7,917 | ) |  | $ | 10,762 |  |

[0001730168-19-000144:notes:173]
Based on the amount of intangible assets subject to amortization at November 3, 2019, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-19-000144:notes:174]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2020 |  | $ | 5,054 |  |
| 2021 |  | 4,151 |  |
| 2022 |  | 3,180 |  |
| 2023 |  | 2,172 |  |
| 2024 |  | 1,490 |  |
| Thereafter |  | 1,244 |  |
| Total |  | $ | 17,291 |  |

[0001730168-19-000144:notes:175]
The weighted-average amortization periods remaining by intangible asset category were as follows:

[0001730168-19-000144:notes:176]
| Amortizable intangible assets: |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In years) |
| Purchased technology |  | 5 |  | 6 |
| Customer contracts and related relationships |  | 5 |  | 5 |
| Order backlog |  | 3 |  | N/A |
| Trade names |  | 10 |  | 12 |
| Other |  | 10 |  | 10 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-19-000144:notes:177]
Net Income Per Share

[0001730168-19-000144:notes:178]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,736 |  |  | $ | 12,629 |  |  | $ | 1,790 |  |
| Less: Dividends on preferred stock |  | 29 |  |  | — |  |  | — |  |
| Income from continuing operations attributable to noncontrolling interest |  | — |  |  | 352 |  |  | 92 |  |
| Income from continuing operations attributable to common stock |  | 2,707 |  |  | 12,277 |  |  | 1,698 |  |
| Loss from discontinued operations, net of income taxes |  | (12 | ) |  | (19 | ) |  | (6 | ) |
| Less: Loss from discontinued operations, net of income taxes, attributable to noncontrolling interest |  | — |  |  | (1 | ) |  | — |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (12 | ) |  | (18 | ) |  | (6 | ) |
| Net income attributable to common stock |  | $ | 2,695 |  |  | $ | 12,259 |  |  | $ | 1,692 |  |

[0001730168-19-000144:notes:179]
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 398 |  |  | 418 |  |  | 405 |  |
| Dilutive effect of equity awards |  | 21 |  |  | 13 |  |  | 16 |  |
| Weighted-average shares outstanding - diluted |  | 419 |  |  | 431 |  |  | 421 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 6.80 |  |  | $ | 29.37 |  |  | $ | 4.19 |  |
| Loss per share from discontinued operations |  | (0.03 | ) |  | (0.04 | ) |  | (0.01 | ) |
| Net income per share |  | $ | 6.77 |  |  | $ | 29.33 |  |  | $ | 4.18 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 6.46 |  |  | $ | 28.48 |  |  | $ | 4.03 |  |
| Loss per share from discontinued operations |  | (0.03 | ) |  | (0.04 | ) |  | (0.01 | ) |
| Net income per share |  | $ | 6.43 |  |  | $ | 28.44 |  |  | $ | 4.02 |  |
| Potentially dilutive shares excluded from the calculation of diluted income per share because their effect would have been antidilutive: |  |  |  |  |  |  |
| Preferred Stock (a) |  | 1 |  |  | — |  |  | — |  |
| LP Units (b) |  | — |  |  | 9 |  |  | 22 |  |

[0001730168-19-000144:notes:180]
(a) Represents common stock shares issuable upon the conversion of Mandatory Convertible Preferred Stock, as defined in Note 10. “Stockholders’ Equity.”
(b) Represents common stock shares issuable upon the exchange of LP Units prior to the effective time of the Mandatory Exchange (refer to Note 10. “Stockholders’ Equity” for additional information).


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-19-000144:notes:181]
Retirement Plans and Post-Retirement Benefits 
Pension and Post-Retirement Benefit Plans

[0001730168-19-000144:notes:182]
Defined Benefit Plans.  The U.S. defined benefit pension plans include a management plan and a represented plan. Benefits under the management plan are provided under either an adjusted career-average-pay program or a cash-balance program. Benefits under the represented plan are based on a dollar-per-month formula. Benefit accruals under the management plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the represented plan. We also have a non-qualified supplemental pension plan in the United States that principally provides benefits based on compensation in excess of amounts that can be considered under the management plan. Effective December 31, 2018, the represented plan was merged into the management plan. The plan merger did not impact any of the respective plan provisions for either management or represented plan participants. We also have pension plans covering certain non-U.S. employees.

[0001730168-19-000144:notes:183]
Post-Retirement Benefit Plans.  Certain of our U.S. employees who meet the retirement eligibility requirements as of their termination dates, may receive post-retirement medical benefits under our retiree medical account program. Eligible employees receive a medical benefit spending account of $55,000 upon retirement to pay premiums for medical coverage through the maximum age of 75 as retiree.

[0001730168-19-000144:notes:184]
Our group life insurance plan offers post-retirement life insurance coverage for certain U.S. employees.

[0001730168-19-000144:notes:185]
Non-U.S Retirement Benefit Plans.  We have defined benefit plans for certain employees in Austria, France, Germany, India, Israel, Italy, Japan and Taiwan. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-19-000144:notes:186]
Net Periodic Benefit (Income) Cost

[0001730168-19-000144:notes:187]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | Fiscal Year |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Service cost |  | $ | 10 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost |  | 58 |  |  | 51 |  |  | 53 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets |  | (59 | ) |  | (51 | ) |  | (65 | ) |  | (3 | ) |  | (4 | ) |  | (4 | ) |
| Other |  | 1 |  |  | 1 |  |  | 1 |  |  | (1 | ) |  | — |  |  | — |  |
| Net periodic benefit (income) cost |  | $ | 10 |  |  | $ | 5 |  |  | $ | (7 | ) |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (1 | ) |
| Net actuarial (gain) loss |  | $ | 13 |  |  | $ | 14 |  |  | $ | (60 | ) |  | $ | 11 |  |  | $ | (3 | ) |  | $ | (3 | ) |

[0001730168-19-000144:notes:188]
The components of net periodic benefit (income) costs other than the service cost are included in other income, net in our consolidated statements of operations.

[0001730168-19-000144:notes:189]
Funded Status

[0001730168-19-000144:notes:190]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 3, 2019 |  | November 4, 2018 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,394 |  |  | $ | 1,426 |  |  | $ | 81 |  |  | $ | 83 |  |
| Actual return on plan assets |  | 232 |  |  | (65 | ) |  | 6 |  |  | — |  |
| Employer contributions |  | 15 |  |  | 130 |  |  | 1 |  |  | — |  |
| Payments from plan assets |  | (94 | ) |  | (93 | ) |  | (3 | ) |  | (2 | ) |
| Foreign currency impact |  | (8 | ) |  | (4 | ) |  | — |  |  | — |  |
| Fair value of plan assets — end of period |  | 1,539 |  |  | 1,394 |  |  | 85 |  |  | 81 |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,364 |  |  | 1,508 |  |  | 74 |  |  | 80 |  |
| Service cost |  | 10 |  |  | 4 |  |  | — |  |  | — |  |
| Interest cost |  | 58 |  |  | 51 |  |  | 3 |  |  | 3 |  |
| Actuarial (gain) loss |  | 186 |  |  | (102 | ) |  | 14 |  |  | (7 | ) |
| Benefit payments |  | (94 | ) |  | (93 | ) |  | (3 | ) |  | (2 | ) |
| Plan amendment |  | — |  |  | 3 |  |  | — |  |  | — |  |
| Benefit obligations assumed in an acquisition |  | 37 |  |  | — |  |  | 5 |  |  | — |  |
| Foreign currency impact |  | (8 | ) |  | (7 | ) |  | — |  |  | — |  |
| Benefit obligations — end of period |  | 1,553 |  |  | 1,364 |  |  | 93 |  |  | 74 |  |
| Overfunded (underfunded) status of benefit obligations (a) |  | $ | (14 | ) |  | $ | 30 |  |  | $ | (8 | ) |  | $ | 7 |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive loss, net of taxes |  | $ | (125 | ) |  | $ | (110 | ) |  | $ | (15 | ) |  | $ | (5 | ) |

[0001730168-19-000144:notes:191]
_________________________________

[0001730168-19-000144:notes:192]
| (a) | Substantially all amounts recognized in the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented. |

[0001730168-19-000144:notes:193]
Plans with benefit obligations in excess of plan assets:

[0001730168-19-000144:notes:194]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 3, 2019 |  | November 4, 2018 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 92 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 80 |  |  | $ | 546 |  |  | $ | 16 |  |  | $ | 14 |  |
| Fair value of plan assets |  | $ | 32 |  |  | $ | 528 |  |  | $ | — |  |  | $ | — |  |

[0001730168-19-000144:notes:195]
Plans with benefit obligations less than plan assets:

[0001730168-19-000144:notes:196]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 3, 2019 |  | November 4, 2018 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 1,461 |  |  | $ | 813 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 1,460 |  |  | $ | 812 |  |  | $ | 77 |  |  | $ | 60 |  |
| Fair value of plan assets |  | $ | 1,507 |  |  | $ | 866 |  |  | $ | 85 |  |  | $ | 81 |  |

[0001730168-19-000144:notes:197]
The fair value of pension plan assets at November 3, 2019 and November 4, 2018 included $151 million and $147 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-19-000144:notes:198]
The projected benefit obligations as of November 3, 2019 and November 4, 2018 included $184 million and $129 million, respectively, of obligations related to our non-U.S. plans. The accumulated benefit obligations as of November 3, 2019 and November 4, 2018 included $171 million and $122 million, respectively, of obligations related to our non-U.S. plans.

[0001730168-19-000144:notes:199]
Expected Future Benefit Payments

[0001730168-19-000144:notes:200]
| Fiscal Years: |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | (In millions) |
| 2020 |  | $ | 93 |  |  | $ | 6 |  |
| 2021 |  | $ | 92 |  |  | $ | 4 |  |
| 2022 |  | $ | 92 |  |  | $ | 4 |  |
| 2023 |  | $ | 92 |  |  | $ | 4 |  |
| 2024 |  | $ | 93 |  |  | $ | 4 |  |
| 2025-2029 |  | $ | 449 |  |  | $ | 23 |  |

[0001730168-19-000144:notes:201]
Defined Benefit Plan Investment Policy

[0001730168-19-000144:notes:202]
Plan assets of the funded defined benefit pension plans are invested in funds held by third-party fund managers or are deposited into government-managed accounts in which we have no active involvement in and no control over investment strategy, other than establishing broad investment guidelines and parameters.

[0001730168-19-000144:notes:203]
Our plan’s investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-19-000144:notes:204]
The target asset allocation for U.S. plans reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plans. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2019 and 2018, 100% of U. S. plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-19-000144:notes:205]
Fair Value Measurement of Plan Assets

[0001730168-19-000144:notes:206]
|  |  | November 3, 2019 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 34 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 34 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 21 |  | (b) |  | — |  |  |  | — |  |  | 21 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 82 |  | (c) |  | — |  |  | 82 |  |
| Corporate bonds |  | — |  |  |  | 1,372 |  | (c) |  | — |  |  | 1,372 |  |
| Municipal bonds |  | — |  |  |  | 19 |  | (c) |  | — |  |  | 19 |  |
| Government bonds |  | — |  |  |  | 10 |  | (c) |  | — |  |  | 10 |  |
| Asset-backed securities |  | — |  |  |  | 1 |  | (c) |  | — |  |  | 1 |  |
| Total plan assets |  | $ | 55 |  |  |  | $ | 1,484 |  |  |  | $ | — |  |  | $ | 1,539 |  |

[0001730168-19-000144:notes:207]
|  |  | November 4, 2018 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 36 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 36 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 19 |  | (b) |  | — |  |  |  | — |  |  | 19 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 80 |  | (c) |  | — |  |  | 80 |  |
| Corporate bonds |  | — |  |  |  | 1,229 |  | (c) |  | — |  |  | 1,229 |  |
| Municipal bonds |  | — |  |  |  | 17 |  | (c) |  | — |  |  | 17 |  |
| Government bonds |  | — |  |  |  | 13 |  | (c) |  | — |  |  | 13 |  |
| Total plan assets |  | $ | 55 |  |  |  | $ | 1,339 |  |  |  | $ | — |  |  | $ | 1,394 |  |

[0001730168-19-000144:notes:208]
| (a) | Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets. |

[0001730168-19-000144:notes:209]
| (b) | These equity securities were valued based on quoted prices in active markets. |

[0001730168-19-000144:notes:210]
| (c) | These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the asset, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals. |

[0001730168-19-000144:notes:211]
Post-Retirement Benefit Plan Investment Policy

[0001730168-19-000144:notes:212]
Our overall investment strategy for the group life insurance plan is to allocate assets in a manner that seeks to both maximize the safety of promised benefits and minimize the cost of funding those benefits. The target asset allocation for plan assets reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. We set the overall portfolio allocation and use an investment manager that directs the investment of funds consistent with that allocation. The investment manager invests the plan assets in index funds that it manages. For both fiscal years 2019 and 2018, 100% of plan assets were allocated to commingled funds that invested in fixed income, in line with the target allocation.

[0001730168-19-000144:notes:213]
Assumptions

[0001730168-19-000144:notes:214]
The assumptions used to determine the benefit obligations and net periodic benefit (income) cost from our defined benefit and post-retirement benefit plans are presented in the table below. The expected long-term return on assets shown in the table below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes (both historical and forecasted) in which we expect the pension and post-retirement funds to be invested. Discount rates reflect the current rate at which defined benefit and post-retirement benefit obligations could be settled based on the measurement dates of the plans, which in each case is our fiscal year end. The range of assumptions that are used for defined benefit pension plans reflects the different economic environments within various countries.

[0001730168-19-000144:notes:215]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 3, 2019 |  | November 4, 2018 |  | 2019 |  | 2018 |  | 2017 |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 0.47%-7.00% |  | 0.50%-8.00% |  | 0.50%-8.00% |  | 0.50%-7.00% |  | 0.50%-7.00% |
| Average increase in compensation levels |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 1.80%-10.00% |  | 2.00%-11.00% |  | 2.00%-9.15% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 1.50%-7.75% |  | 1.50%-7.50% |  | 0.25%-8.00% |

[0001730168-19-000144:notes:216]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 3, 2019 |  | November 4, 2018 |  | 2019 |  | 2018 |  | 2017 |
| Post-retirement benefits plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 2.80%-3.20% |  | 4.30%-4.60% |  | 4.12%-4.60% |  | 3.40%-3.80% |  | 3.30%-3.90% |
| Average increase in compensation levels |  | 3.00% |  | 3.00% |  | 3.00% |  | 3.00% |  | 3.50% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 4.80% |  | 4.80% |  | 4.40% |

[0001730168-19-000144:notes:217]
|  |  | Assumed Health Care Cost Trend Rate Used to Measure the Expected Cost of Benefits as of |
|  |  | November 3, 2019 |  | November 4, 2018 |
| Health care cost trend rate assumed for next year |  | 4.50%-7.40% |  | 6.70% |
| Rate to which the health care cost trend rate is assumed to decline (ultimate health care cost trend rate) |  | 3.50%-4.50% |  | 3.50% |
| Year that the rate reaches the ultimate health care cost trend rate |  | 2031 |  | 2031 |

[0001730168-19-000144:notes:218]
A one percentage point increase or decrease in the assumed health care cost trend rates would not have had a material effect on the accumulated post-retirement benefit obligations or service and interest cost components of the net periodic benefit cost for any periods presented.

[0001730168-19-000144:notes:219]
Defined Contribution Plans

[0001730168-19-000144:notes:220]
Our eligible U.S. employees participate in company-sponsored 401(k) plans. Under these plans, we provide matching contributions to employees up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2019, 2018 and 2017, we made contributions of $89 million, $73 million and $61 million, respectively, to the 401(k) plans.

[0001730168-19-000144:notes:221]
In addition, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans.


## us-gaap:DebtDisclosureTextBlock

[0001730168-19-000144:notes:222]
Borrowings

[0001730168-19-000144:notes:223]
|  |  | Effective Interest Rate |  | November 3, 2019 |  | November 4, 2018 |
|  |  |  |  | (In millions) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.362 | % |  | 800 |  |  | — |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.452 | % |  | 800 |  |  | — |  |
|  |  |  |  | 1,600 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 1,850 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 2.547 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 33,059 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (261 | ) |  | (116 | ) |
| Total debt |  |  |  | $ | 32,798 |  |  | $ | 17,493 |  |

[0001730168-19-000144:notes:224]
(a) Represents the weighted average interest rate on outstanding commercial paper as of November 3, 2019.

[0001730168-19-000144:notes:225]
2019 Senior Notes

[0001730168-19-000144:notes:226]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our 2019 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes is amortized to interest expense over the respective terms of these borrowings.

[0001730168-19-000144:notes:227]
2019 Term Loans

[0001730168-19-000144:notes:228]
On November 5, 2018, in connection with the CA Merger, we entered into a credit agreement (the “Original 2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “Original 2019 Term Loans”. Interest on our Original 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the Original 2019 Credit Agreement were guaranteed on an unsecured basis by BRCM, Broadcom Cayman Finance Limited (“Cayman Finance”) and BTI. The Original 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility. In April 2019, we used the net proceeds of $11 billion from the 2019 Senior Notes and net proceeds of $1 billion from Commercial Paper (defined below) to reduce the outstanding amount of our Original 2019 Term Loans from $18 billion to $6 billion. As a result of repaying the Original 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense in the consolidated statements of operations. The remaining unamortized discount and debt issuance costs balance on the Original 2019 Term Loans will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

[0001730168-19-000144:notes:229]
In May 2019, we entered into a new credit agreement (the “2019 Credit Agreement”), which provides for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility, collectively referred to as the “2019 Term Loans”. The 2019 Credit Agreement has substantially the same terms and conditions as the Original 2019 Credit Agreement, except for the maturity dates of the facilities. The 2019 Term Loans replaced the remaining $6 billion Original 2019 Term Loans, which were terminated in connection with, and as a condition to, entering into the 2019 Credit Agreement. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM, Cayman Finance and BTI.

[0001730168-19-000144:notes:230]
In October 2019, we fully repaid our unsecured term A-3 facility of $2 billion and repaid $1.2 billion of each of our unsecured term A-5 and A-7 facilities under the 2019 Credit Agreement, using net proceeds from our Mandatory Convertible Preferred Stock offering as defined in Note 10. “Stockholders’ Equity,” as well as with cash on hand. As a result, we wrote off $22 million of debt issuance costs and unamortized discounts, which were included in interest expense in the consolidated statements of operations.

[0001730168-19-000144:notes:231]
Revolving Facility

[0001730168-19-000144:notes:232]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The Revolving Facility replaced the revolving credit facility of the same amount under the Original 2019 Credit Agreement. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on November 3, 2019.

[0001730168-19-000144:notes:233]
Commercial Paper

[0001730168-19-000144:notes:234]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As of November 3, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term.

[0001730168-19-000144:notes:235]
2017 Senior Notes

[0001730168-19-000144:notes:236]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, or together with BRCM referred to as the “Subsidiary Issuers”, issued of $17,550 million senior unsecured notes (the “2017 Senior Notes”). Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom-Singapore and the Partnership, subject to certain release conditions described in the indenture governing the 2017 Senior Notes (the “2017 Indentures”). On April 9, 2018, Broadcom (“Parent Guarantor”) became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. At that time, Broadcom-Singapore, a guarantor at the issuance of the 2017 Senior Notes, became an indirect wholly-owned subsidiary of Broadcom and a subsidiary guarantor (“Subsidiary Guarantor”), together with Parent Guarantor referred to as the “Guarantors”. In addition, the Partnership was released from its guarantee of the 2017 Senior Notes under each of the 2017 Indentures in accordance with their terms. Each series of 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year.

[0001730168-19-000144:notes:237]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest.

[0001730168-19-000144:notes:238]
During fiscal year 2018, substantially all of the 2017 Senior Notes were tendered and exchanged for notes registered with the U.S. Securities and Exchange Commission (“SEC”), with substantially identical terms.

[0001730168-19-000144:notes:239]
Assumed CA Senior Notes

[0001730168-19-000144:notes:240]
In connection with the CA Merger, we assumed $2.25 billion in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the related indenture. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holder’s notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

[0001730168-19-000144:notes:241]
In October 2019, we fully repaid our 3.600% notes due August 2020 of $400 million. As a result of this payoff, we wrote off $1 million of unamortized premium and incurred a make-whole premium of $5 million, which were included in interest expense in the consolidated statements of operations.

[0001730168-19-000144:notes:242]
Assumed Brocade Debt

[0001730168-19-000144:notes:243]
As a result of the Brocade Merger, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes due 2020, or the Assumed Brocade Convertible Notes. The Brocade Merger was a “fundamental change” as well as a “make-whole fundamental change” as defined under the terms of the indenture governing the Assumed Brocade Convertible Notes. Accordingly, the holders of the Assumed Brocade Convertible Notes received the right to require us to repurchase their notes for cash. During fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. The remaining outstanding Assumed Brocade Convertible Notes are convertible into cash at a conversion rate of $812 for each $1,000 of principal.

[0001730168-19-000144:notes:244]
We also assumed $300 million of Brocade’s 4.625% senior unsecured notes due 2023. In January 2018, we redeemed all of these outstanding notes for a total payment of $308 million.

[0001730168-19-000144:notes:245]
Fair Value of Debt

[0001730168-19-000144:notes:246]
As of November 3, 2019, the estimated aggregate fair value of our debt was $33,652 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 Term Loans approximated their carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-19-000144:notes:247]
Future Principal Payments of Debt

[0001730168-19-000144:notes:248]
The future scheduled principal payments of debt as of November 3, 2019 were as follows:

[0001730168-19-000144:notes:249]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 |  | $ | 4,537 |  |
| 2021 |  | 2,750 |  |
| 2022 |  | 5,509 |  |
| 2023 |  | 1,250 |  |
| 2024 |  | 5,307 |  |
| Thereafter |  | 13,706 |  |
| Total |  | $ | 33,059 |  |

[0001730168-19-000144:notes:250]
As of November 3, 2019 and November 4, 2018, we accrued interest payable of $214 million and $165 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-19-000144:notes:251]
Stockholders’ Equity 
Mandatory Convertible Preferred Stock Offering

[0001730168-19-000144:notes:252]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (the “Mandatory Convertible Preferred Stock”), including certain additional shares sold pursuant to the underwriters' option, which generated net proceeds of approximately $3,679 million. We used the net proceeds of this offering to repay a portion of the outstanding borrowings under our existing term loan facilities.

[0001730168-19-000144:notes:253]
The holders of Mandatory Convertible Preferred Stock are entitled to receive, when, as and if declared by our Board of Directors, or an authorized committee thereof, out of funds legally available for payment, cumulative dividends at the annual rate of 8.00% of the liquidation preference of $1,000 per share (equivalent to $80 annually per share), payable in cash or, subject to certain limitations, by delivery of shares of our common stock or any combination of cash and shares of our common stock, at our election; provided, however, that any undeclared and unpaid dividends will continue to accumulate.

[0001730168-19-000144:notes:254]
Subject to limited exceptions, no dividends may be declared or paid on shares of our common stock, unless all accumulated dividends have been paid or set aside for payment on all outstanding shares of our Mandatory Convertible Preferred Stock for all past completed dividend periods. In the event of our voluntary or involuntary liquidation, dissolution or winding-up, no distribution of our assets may be made to holders of our common stock until we have paid to holders of our Mandatory Convertible Preferred Stock a liquidation preference equal to $1,000 per share plus accumulated and unpaid dividends.

[0001730168-19-000144:notes:255]
Unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert on the mandatory conversion date, which is expected to be September 30, 2022, into between 3.0303 and 3.5422 shares of our common stock, depending on the applicable market value of our common stock upon conversion and subject to customary anti-dilution adjustments. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the minimum conversion rate of 3.0303, subject to anti-dilution adjustments and certain exceptions.

[0001730168-19-000144:notes:256]
The Mandatory Convertible Preferred Stock will not be redeemable at our election before the mandatory conversion date. The holders of the Mandatory Convertible Preferred Stock will not have any voting rights, with limited exceptions.

[0001730168-19-000144:notes:257]
During the fourth quarter of fiscal year 2019, we recognized $29 million of earned preferred stock dividends and presented it as temporary equity in our consolidated balance sheet as of November 3, 2019.

[0001730168-19-000144:notes:258]
Redomiciliation Transaction

[0001730168-19-000144:notes:259]
For the period prior to the Redomiciliation Transaction, our stockholders’ equity reflected Broadcom-Singapore’s outstanding ordinary shares. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom common stock and Broadcom-Singapore became a wholly-owned subsidiary of Broadcom.

[0001730168-19-000144:notes:260]
In conjunction with the Redomiciliation Transaction and pursuant to the Mandatory Exchange, all outstanding LP Units held by the limited partners were mandatorily exchanged for approximately 22 million newly issued shares of Broadcom common stock on a one-for-one basis. As a result, all limited partners of the Partnership became common stockholders of Broadcom. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange.

[0001730168-19-000144:notes:261]
Noncontrolling Interest

[0001730168-19-000144:notes:262]
Immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income attributable to our common stock in our consolidated statements of operations excluded the noncontrolling interest’s proportionate share of our results prior to the Redomiciliation Transaction. In addition, we presented the proportionate share of equity attributable to the noncontrolling interest as a separate component of total equity within our consolidated statements of equity for the periods prior to the Redomiciliation Transaction.

[0001730168-19-000144:notes:263]
Dividends and Distributions

[0001730168-19-000144:notes:264]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 10.60 |  |  | $ | 7.00 |  |  | $ | 4.08 |  |
| Cash dividends declared and paid to common stockholders |  | $ | 4,235 |  |  | $ | 2,921 |  |  | $ | 1,653 |  |
| Cash distributions declared and paid to limited partners |  | $ | — |  |  | $ | 77 |  |  | $ | 92 |  |

[0001730168-19-000144:notes:265]
Stock Repurchase Program

[0001730168-19-000144:notes:266]
Pursuant to an $18 billion stock repurchase program authorized by our Board of Directors, we repurchased and retired approximately 21 million and 32 million shares of our common stock for $5,435 million and $7,258 million during fiscal years 2019 and 2018, respectively. This authorization ended on November 3, 2019.

[0001730168-19-000144:notes:267]
Equity Incentive Award Plans

[0001730168-19-000144:notes:268]
Stock-based incentive awards are provided to employees and directors under the terms of various Broadcom equity incentive plans.

[0001730168-19-000144:notes:269]
2009 Plan

[0001730168-19-000144:notes:270]
In July 2009, our Board of Directors adopted, and our stockholders approved, the Avago Technologies Limited 2009 Equity Incentive Award Plan (the “2009 Plan”) to authorize the grant of options, stock appreciation rights, RSUs, dividend equivalents, performance awards, and other stock-based awards. A total of 20 million shares of common stock were initially reserved for issuance under the 2009 Plan, subject to annual increases starting in fiscal year 2012. The amount of the annual increase was equal to the least of (a) 6 million shares, (b) 3% of the common stock outstanding on the last day of the immediately preceding fiscal year and (c) such smaller number of common stock as determined by our Board. However, no more than 90 million shares of common stock may be issued upon the exercise of equity awards issued under the 2009 Plan. The 2009 Plan became effective on July 27, 2009.

[0001730168-19-000144:notes:271]
Options issued to employees under the 2009 Plan prior to March 2011 generally expire ten years following the date of grant. Since March 2011, options issued to employees under the 2009 Plan generally expire seven years after the date of grant. Options awarded to non-employees under this plan generally expire after five years. Options issued to both employees and non-employees under the 2009 Plan generally vested over a period of four years from the date of grant and were granted with an exercise price equal to the fair market value on the date of grant. Any stock options cancelled or forfeited after July 27, 2009 under the equity incentive plans adopted prior to the 2009 Plan became available for issuance under the 2009 Plan. RSU awards granted to employees under the 2009 Plan generally vest annually over four years.

[0001730168-19-000144:notes:272]
The 2009 Plan expired in July 2019.

[0001730168-19-000144:notes:273]
2003 Plan

[0001730168-19-000144:notes:274]
In connection with the acquisition of LSI Corporation (“LSI”), we assumed the LSI 2003 Equity Incentive Plan (the “2003 Plan”) and outstanding unvested stock options and RSUs originally granted by LSI under the 2003 Plan that were held by continuing employees. Under the 2003 Plan, we may grant to former employees of LSI and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options covering more than 4 million shares or more than an aggregate of 1 million shares of restricted stock and RSUs in any fiscal year. Equity awards granted under the 2003 Plan following the LSI acquisition are expected to be on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 3, 2019, 3 million shares remained available for issuance under the 2003 Plan.

[0001730168-19-000144:notes:275]
2012 Plan

[0001730168-19-000144:notes:276]
In connection with the acquisition of BRCM, we assumed the BRCM 2012 Stock Incentive Plan (the “2012 Plan”) and outstanding unvested RSUs originally granted by BRCM under the 2012 Plan that were held by continuing employees. Under the 2012 Plan, we may grant to former employees of BRCM and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options, restricted stock or RSUs, covering more than an aggregate of 4 million shares in any fiscal year. Equity awards granted under the 2012 Plan following the acquisition of BRCM are on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 3, 2019, 82 million shares remained available for issuance under the 2012 Plan. The number of shares available for issuance under the 2012 Plan is subject to an annual increase of 12 million shares.

[0001730168-19-000144:notes:277]
We also grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2019, 2018 and 2017, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 450% of the original grant at vesting based upon the total stockholder return (“TSR”) on our common stock as compared to the TSR of an index group of companies.

[0001730168-19-000144:notes:278]
Amendment to the RSU Vesting Schedule

[0001730168-19-000144:notes:279]
During fiscal year 2019, the Compensation Committee of our Board of Directors approved an amendment to the vesting of time-based RSUs (other than those assumed in an acquisition), held by approximately 16,500 employees below the vice president level, from an annual vesting cycle to a quarterly vesting cycle.

[0001730168-19-000144:notes:280]
Employee Stock Purchase Plan

[0001730168-19-000144:notes:281]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or ending of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of Employee Retirement Income Security Act of 1974.

[0001730168-19-000144:notes:282]
Stock-Based Compensation Expense

[0001730168-19-000144:notes:283]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 120 |  |  | $ | 77 |  |  | $ | 64 |  |
| Cost of subscriptions and services |  | 43 |  |  | 9 |  |  | — |  |
| Research and development |  | 1,532 |  |  | 855 |  |  | 636 |  |
| Selling, general and administrative |  | 490 |  |  | 286 |  |  | 220 |  |
| Total stock-based compensation expense (a) |  | $ | 2,185 |  |  | $ | 1,227 |  |  | $ | 920 |  |
| Estimated income tax benefits for stock-based compensation |  | $ | 400 |  |  | $ | 195 |  |  | $ | 249 |  |
| Income tax benefits for stock-based awards exercised or released |  | $ | 232 |  |  | $ | 181 |  |  | $ | 273 |  |

[0001730168-19-000144:notes:284]
| (a) | Does not include stock-based compensation related to discontinued operations recognized during fiscal year 2017, which was included in loss from discontinued operations, net of income taxes in our consolidated statements of operations. |

[0001730168-19-000144:notes:285]
We have assumed an annualized forfeiture rate for RSUs of 5%. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated.

[0001730168-19-000144:notes:286]
During the first quarter of fiscal year 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $890 million for fiscal year 2019, including $133 million of Multi-Year Equity Awards granted to employees acquired in the CA Merger.

[0001730168-19-000144:notes:287]
In connection with the amendment to the vesting of certain time-based RSUs from an annual cycle to a quarterly cycle, we recognized approximately $140 million in incremental compensation cost during fiscal year 2019.

[0001730168-19-000144:notes:288]
For fiscal year 2019, stock-based compensation expense included $83 million related to equity awards assumed in connection with the CA Merger. In addition to stock-based compensation expense presented above, in fiscal year 2019, we recognized $75 million in restructuring charges for accelerated vesting of assumed equity awards held by employees terminated in connection with the CA Merger.

[0001730168-19-000144:notes:289]
As of November 3, 2019, the total unrecognized compensation cost related to unvested stock-based awards was $5,641 million, which is expected to be recognized over the remaining weighted-average service period of 4.1 years.

[0001730168-19-000144:notes:290]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-19-000144:notes:291]
|  |  | Market-Based Awards |
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
| Risk-free interest rate |  | 2.7 | % |  | 2.4 | % |  | 1.7 | % |
| Dividend yield |  | 4.4 | % |  | 2.6 | % |  | 1.8 | % |
| Volatility |  | 33.0 | % |  | 32.5 | % |  | 32.3 | % |
| Expected term (in years) |  | 4.0 |  |  | 4.0 |  |  | 4.0 |  |

[0001730168-19-000144:notes:292]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-19-000144:notes:293]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-19-000144:notes:294]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-19-000144:notes:295]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-19-000144:notes:296]
Restricted Stock Unit Awards

[0001730168-19-000144:notes:297]
A summary of time- and market-based RSU activity is as follows:

[0001730168-19-000144:notes:298]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of October 30, 2016 |  | 17 |  |  | $ | 130.71 |  |
| Granted |  | 8 |  |  | $ | 199.33 |  |
| Vested |  | (5 | ) |  | $ | 126.81 |  |
| Forfeited |  | (2 | ) |  | $ | 142.78 |  |
| Balance as of October 29, 2017 |  | 18 |  |  | $ | 163.42 |  |
| Granted |  | 7 |  |  | $ | 239.48 |  |
| Vested |  | (6 | ) |  | $ | 155.78 |  |
| Forfeited |  | (1 | ) |  | $ | 175.46 |  |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |
| Assumed in CA Merger |  | 1 |  |  | $ | 206.14 |  |
| Granted |  | 33 |  |  | $ | 183.64 |  |
| Vested |  | (10 | ) |  | $ | 192.28 |  |
| Forfeited |  | (2 | ) |  | $ | 182.80 |  |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |

[0001730168-19-000144:notes:299]
The aggregate fair value of time- and market-based RSUs that vested in fiscal years 2019, 2018 and 2017 was $2,958 million, $1,516 million and $1,172 million, respectively, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-19-000144:notes:300]
Stock Option Awards

[0001730168-19-000144:notes:301]
A summary of time- and market-based stock option activity is as follows:

[0001730168-19-000144:notes:302]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of October 30, 2016 |  | 15 |  |  | $ | 48.77 |  |  |  |  |  |
| Exercised |  | (4 | ) |  | $ | 45.48 |  |  |  |  | $ | 682 |  |
| Cancelled |  | (1 | ) |  | $ | 66.08 |  |  |  |  |  |
| Balance as of October 29, 2017 |  | 10 |  |  | $ | 49.54 |  |  |  |  |  |
| Exercised |  | (2 | ) |  | $ | 47.41 |  |  |  |  | $ | 534 |  |
| Cancelled |  | — |  | * | $ | 72.37 |  |  |  |  |  |
| Balance as of November 4, 2018 |  | 8 |  |  | $ | 50.14 |  |  |  |  |  |
| Exercised |  | (4 | ) |  | $ | 47.88 |  |  |  |  | $ | 761 |  |
| Cancelled |  | — |  | * | $ | 49.00 |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  | 1.11 |  | $ | 1,077 |  |
| Fully vested as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  | 1.11 |  | $ | 1,077 |  |

[0001730168-19-000144:notes:303]
* Represents fewer than 0.5 million shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-19-000144:notes:304]
Components of Income from Continuing Operations Before Income Taxes

[0001730168-19-000144:notes:305]
As a result of the Redomiciliation Transaction on April 4, 2018, the following references to domestic activities represent the U.S. for fiscal years 2019 and 2018 and Singapore for fiscal year 2017. The following table presents the components of income from continuing operations before income taxes for financial reporting purposes:

[0001730168-19-000144:notes:306]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Domestic income (loss) |  | $ | (4,116 | ) |  | $ | (705 | ) |  | $ | 2,102 |  |
| Foreign income (loss) |  | 6,342 |  |  | 5,250 |  |  | (277 | ) |
| Income from continuing operations before income taxes |  | $ | 2,226 |  |  | $ | 4,545 |  |  | $ | 1,825 |  |

[0001730168-19-000144:notes:307]
Components of Provision for (Benefit from) Income Taxes

[0001730168-19-000144:notes:308]
The benefit from income taxes in fiscal year 2019 was primarily due to $232 million of excess tax benefits from stock-based awards that vested or were exercised during the period, $131 million from the recognition of gross unrecognized tax benefits as a result of audit settlements and lapses of statutes of limitations net of increases in balances related to tax positions taken during the current year, $80 million of benefit from deferred tax remeasurement in state and foreign jurisdictions, $66 million of benefit related to internal reorganizations, and $54 million of benefit from the partial release of our valuation allowance as a result of the CA Merger, partly offset by $113 million of expense from a change in estimate of our fiscal year 2018 benefit as a result of proposed U.S. Treasury regulations issued in fiscal year 2019 related to the 2017 Tax Reform Act.

[0001730168-19-000144:notes:309]
The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations. Several provisions of the 2017 Tax Reform Act became effective for us for the first time in fiscal year 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000144:notes:310]
On December 22, 2017, the SEC issued Staff Accounting Bulletin No. 118. This guidance allowed registrants a “measurement period,” not to exceed one year from the date of enactment, to complete their accounting for the tax effects of the 2017 Tax Reform Act. We relied on this guidance to refine our estimates of the impact of the 2017 Tax Reform Act during the measurement period. The measurement period ended during our fiscal quarter ended February 3, 2019, and no adjustments were recorded. As a result, we consider our accounting for the tax effects of the 2017 Tax Reform Act to be complete based on our interpretation of the law and subsequently issued guidance. However, it is expected that the U.S. Treasury will continue to issue regulations and other guidance on the application of certain provisions of the 2017 Tax Reform Act that may impact our interpretation of the rules and our calculation of the tax impact of the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017 or other provisions of the 2017 Tax Reform Act.

[0001730168-19-000144:notes:311]
In connection with the CA Merger in November 2018, we established $2,434 million of net deferred tax liabilities on the excess of the book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that had not been indefinitely reinvested, partially offset by acquired tax attributes.

[0001730168-19-000144:notes:312]
The benefit from income taxes in fiscal year 2018 was primarily due to income tax benefits recognized from the enactment of the 2017 Tax Reform Act and the Redomiciliation Transaction. As a result of the 2017 Tax Reform Act, we recorded a total provisional benefit of $7,278 million in fiscal year 2018. This provisional benefit included $7,212 million related to the Transition Tax, which was primarily due to a reduction of $10,457 million in our federal deferred income tax liabilities on accumulated non-U.S. earnings, partially offset by $2,133 million of federal provisional long-term Transaction Tax payable and $1,112 million of unrecognized federal tax benefits related to the Transition Tax. The provisional benefit also included $66 million related to the remeasurement of certain deferred tax assets and liabilities, which were based on the tax rates at which they were expected to be reversed in the future as a result of the 2017 Tax Reform Act.

[0001730168-19-000144:notes:313]
The impact of the Redomiciliation Transaction and the related internal reorganizations included tax benefits of $1,162 million in fiscal year 2018 from the remeasurement of withholding taxes on undistributed earnings, partially offset by a $167 million tax provision on foreign earnings and profits subject to U.S. tax.

[0001730168-19-000144:notes:314]
The income tax provision for fiscal year 2017 was primarily due to profit before tax and a discrete expense of $76 million resulting from entity reorganizations partially offset by the recognition of $273 million of excess tax benefits from stock-based awards that vested or were exercised during fiscal year 2017 and, to a lesser extent, the recognition of previously unrecognized tax benefits primarily as a result of audit settlements.

[0001730168-19-000144:notes:315]
We have obtained several tax incentives from the Singapore Economic Development Board, an agency of the Government of Singapore, which provide that qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax. Each tax incentive was separate and distinct from the others, and may be granted, withheld, extended, modified, truncated, complied with or terminated independently without any effect on the other incentives. Subject to our compliance with the conditions specified in these incentives and legislative developments, the Singapore tax incentive is presently expected to expire in November 2025.

[0001730168-19-000144:notes:316]
We have also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with the conditions specified, we will lose the related tax benefits and we could be required to refund previously realized material tax benefits.

[0001730168-19-000144:notes:317]
Before taking into consideration the effects of the 2017 Tax Reform Act and other indirect tax impact, the effect of these tax incentives and tax holiday was to increase the benefit from income taxes by approximately $923 million and $590 million and increase diluted net income per share by $2.20 and $1.37 for fiscal years 2019 and 2018, respectively. For fiscal year 2017, the effect of these tax incentives and tax holiday was to reduce the overall provision for income taxes by approximately $237 million and reduce diluted net loss per share by $0.56.

[0001730168-19-000144:notes:318]
During fiscal year 2019, we reevaluated our indefinite reinvestment assertion with regards to certain accumulated foreign earnings and concluded that we intend to indefinitely reinvest $2,677 million of such earnings as a result of interpretive guidance issued by the IRS. The amount of unrecognized deferred income tax liability indefinitely related to these earnings is estimated to be $281 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-19-000144:notes:319]
As a result of the Redomiciliation Transaction on April 4, 2018, the following references to current tax expense (benefit from) federal and state represent the U.S. for fiscal years 2019 and 2018 and Singapore for fiscal year 2017. Significant components of the provision for (benefit from) income taxes are as follows:

[0001730168-19-000144:notes:320]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Current tax expense (benefit from): |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (49 | ) |  | $ | 255 |  |  | $ | 112 |  |
| State |  | (16 | ) |  | 38 |  |  | — |  |
| Foreign |  | 342 |  |  | 171 |  |  | 158 |  |
|  |  | 277 |  |  | 464 |  |  | 270 |  |
| Deferred tax expense (benefit from): |  |  |  |  |  |  |  |  |  |
| Federal |  | (497 | ) |  | (8,666 | ) |  | (1 | ) |
| State |  | (113 | ) |  | (103 | ) |  | — |  |
| Foreign |  | (177 | ) |  | 221 |  |  | (234 | ) |
|  |  | (787 | ) |  | (8,548 | ) |  | (235 | ) |
| Total provision for (benefit from) income taxes |  | $ | (510 | ) |  | $ | (8,084 | ) |  | $ | 35 |  |

[0001730168-19-000144:notes:321]
Rate Reconciliation

[0001730168-19-000144:notes:322]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
| Statutory tax rate |  | 21.0 | % |  | 21.0 | % |  | 17.0 | % |
| State, net of federal benefit |  | (4.6 | ) |  | (1.1 | ) |  | — |  |
| 2017 Tax reform |  | 5.1 |  |  | (159.0 | ) |  | — |  |
| Redomiciliation transaction withholding tax remeasurement |  | — |  |  | (25.6 | ) |  | — |  |
| Foreign income taxed at different rates |  | (52.5 | ) |  | (16.3 | ) |  | (0.8 | ) |
| Excess tax benefits from stock-based compensation |  | (10.4 | ) |  | (4.0 | ) |  | — |  |
| Research and development credit |  | (7.6 | ) |  | (2.9 | ) |  | — |  |
| Deemed inclusion of foreign earnings |  | 25.9 |  |  | 4.7 |  |  | — |  |
| Tax holidays and concessions |  | — |  |  | — |  |  | (13.0 | ) |
| Other, net |  | 0.2 |  |  | 5.3 |  |  | (1.3 | ) |
| Effective tax rate on income before income taxes |  | (22.9 | )% |  | (177.9 | )% |  | 1.9 | % |

[0001730168-19-000144:notes:323]
Summary of Deferred Income Taxes

[0001730168-19-000144:notes:324]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |  |  |
| Net operating loss, credit and other carryforwards |  | $ | 1,733 |  |  | $ | 1,421 |  |
| Deferred revenue |  | 316 |  |  | — |  |
| Employee stock awards |  | 218 |  |  | 159 |  |
| Other deferred income tax assets |  | 313 |  |  | 226 |  |
| Gross deferred income tax assets |  | 2,580 |  |  | 1,806 |  |
| Less valuation allowance |  | (1,563 | ) |  | (1,347 | ) |
| Deferred income tax assets |  | 1,017 |  |  | 459 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 2,360 |  |  | 316 |  |
| Foreign earnings not indefinitely reinvested |  | 138 |  |  | 16 |  |
| Other deferred income tax liabilities |  | — |  |  | 12 |  |
| Deferred income tax liabilities |  | 2,498 |  |  | 344 |  |
| Net deferred income tax assets (liabilities) |  | $ | (1,481 | ) |  | $ | 115 |  |

[0001730168-19-000144:notes:325]
Deferred income taxes reflect the net effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and their basis for income tax purposes and the tax effects of net operating losses and tax credit carryforwards. The increase in deferred income tax liabilities for depreciation and amortization is primarily due to the CA Merger.

[0001730168-19-000144:notes:326]
The following table presents net deferred income tax assets (liabilities) as reflected on the consolidated balance sheets:

[0001730168-19-000144:notes:327]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Other long-term assets |  | $ | 50 |  |  | $ | 284 |  |
| Other long-term liabilities |  | (1,531 | ) |  | (169 | ) |
| Net long-term income tax assets (liabilities) |  | $ | (1,481 | ) |  | $ | 115 |  |

[0001730168-19-000144:notes:328]
The increase in the valuation allowance to $1,563 million in fiscal year 2019 from $1,347 million in fiscal year 2018 was primarily due to the CA Merger, foreign deferred tax assets arising from foreign credits, and losses not expected to be realized.

[0001730168-19-000144:notes:329]
As of November 3, 2019, we had U.S. federal net operating loss carryforwards of $123 million, U.S. state net operating loss carryforwards of $2,813 million and other foreign net operating loss carryforwards of $1,157 million. U.S. federal and state net operating loss carryforwards begin to expire in fiscal year 2020. The other foreign net operating losses expire in various fiscal years beginning 2020. As of November 3, 2019, we had $252 million and $1,653 million of U.S. federal and state research and development tax credits, respectively, which if not utilized, begin to expire in fiscal year 2020.

[0001730168-19-000144:notes:330]
The U.S. Tax Reform Act of 1986 limits the use of net operating loss and tax credit carryforwards in the case of an “ownership change” of a corporation or separate return loss year limitations. Any ownership changes, as defined, may restrict utilization of carryforwards. As of November 3, 2019, we had approximately $123 million of federal net operating loss carryforwards in the U.S. subject to an annual limitation. We do not expect these limitations to result in any permanent loss of our tax benefits.

[0001730168-19-000144:notes:331]
Uncertain Tax Positions

[0001730168-19-000144:notes:332]
Gross unrecognized tax benefits increased by $392 million during fiscal year 2019, resulting in gross unrecognized tax benefits of $4,422 million as of November 3, 2019.

[0001730168-19-000144:notes:333]
Gross unrecognized tax benefits increased by $1,774 million during fiscal year 2018, resulting in gross unrecognized tax benefits of $4,030 million as of November 4, 2018. The increase in gross unrecognized tax benefits was primarily due to the recognition of unrecognized tax positions of $1,112 million related to the Transition Tax, offset by a reduction of our federal deferred income tax liabilities on accumulated non-U.S. earnings. The increase in gross unrecognized tax benefits was also due to the Redomiciliation Transaction, and to a lesser extent, the Brocade Merger.

[0001730168-19-000144:notes:334]
Gross unrecognized tax benefits increased by $273 million during fiscal year 2017, resulting in gross unrecognized tax benefits of $2,256 million as of October 29, 2017. The increase in gross unrecognized tax benefits was primarily a result of restructuring activities in fiscal year 2017. During fiscal year 2017, we recognized $121 million of previously unrecognized tax benefits as a result of the audit settlement with taxing authorities, and $12 million as a result of the expiration of the statute of limitations for certain audit periods.

[0001730168-19-000144:notes:335]
We recognize interest and penalties related to unrecognized tax benefits within provision for income taxes in the accompanying consolidated statements of operations. Accrued interest and penalties were included within other long-term liabilities on the consolidated balance sheets. As of November 3, 2019 and November 4, 2018, the combined amount of cumulative accrued interest and penalties was approximately $303 million and $190 million, respectively. The increase in cumulative accrued interest and penalties was primarily a result of the CA Merger.

[0001730168-19-000144:notes:336]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-19-000144:notes:337]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Beginning balance |  | $ | 4,030 |  |  | $ | 2,256 |  |  | $ | 1,983 |  |
| Lapses of statutes of limitations |  | (36 | ) |  | (20 | ) |  | (12 | ) |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | 467 |  |  | 361 |  |  | 47 |  |
| Decreases in balances related to tax positions taken during prior periods |  | (270 | ) |  | (289 | ) |  | (32 | ) |
| Increases in balances related to tax positions taken during current period |  | 460 |  |  | 1,726 |  |  | 391 |  |
| Decreases in balances related to settlement with taxing authorities |  | (229 | ) |  | (4 | ) |  | (121 | ) |
| Ending balance |  | $ | 4,422 |  |  | $ | 4,030 |  |  | $ | 2,256 |  |

[0001730168-19-000144:notes:338]
A portion of our unrecognized tax benefits will affect our effective tax rate if they are recognized upon favorable resolution of the uncertain tax positions. As of November 3, 2019 and November 4, 2018, approximately $4,725 million and $4,220 million of the unrecognized tax benefits including accrued interest and penalties would affect our effective tax rate, respectively.

[0001730168-19-000144:notes:339]
Decreases in balances related to tax positions taken during prior periods and settlement with taxing authorities related to the settlement of income tax audits in various jurisdictions during fiscal year 2019.

[0001730168-19-000144:notes:340]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $154 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-19-000144:notes:341]
Reportable Segments

[0001730168-19-000144:notes:342]
As a result of the CA Merger, which closed on November 5, 2018, we updated our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. Each segment represents a component for which separate financial information is available that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-19-000144:notes:343]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, telecom, enterprise and embedded networking applications. We provide a broad variety of RF semiconductor devices, wireless connectivity solutions and custom touch controllers for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets.

[0001730168-19-000144:notes:344]
Infrastructure software. We provide a portfolio of mainframe, enterprise and storage area networking solutions, which enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments, and to reduce the cost and complexity of managing business information within a shared data storage environment.

[0001730168-19-000144:notes:345]
IP licensing. We license a portion of our broad IP portfolio.

[0001730168-19-000144:notes:346]
Our CODM assesses the performance of each segment and allocates resources to those segments based on net revenue and operating results and does not evaluate our segments using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, in addition to expenses associated with selling, general and administrative activities for the business, which are allocated primarily based on revenue, while facilities expenses are allocated primarily based on site-specific headcount.

[0001730168-19-000144:notes:347]
Unallocated Expenses

[0001730168-19-000144:notes:348]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, charges related to inventory step-up to fair value, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs also include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-19-000144:notes:349]
Depreciation expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-19-000144:notes:350]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 17,368 |  |  | $ | 18,934 |  |  | $ | 17,491 |  |
| Infrastructure software |  | 5,156 |  |  | 1,780 |  |  | — |  |
| IP licensing |  | 73 |  |  | 134 |  |  | 145 |  |
| Total net revenue |  | $ | 22,597 |  |  | $ | 20,848 |  |  | $ | 17,636 |  |
| Operating income (loss): |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 8,150 |  |  | $ | 9,090 |  |  | $ | 7,900 |  |
| Infrastructure software |  | 3,781 |  |  | 1,250 |  |  | — |  |
| IP licensing |  | (2 | ) |  | 70 |  |  | 70 |  |
| Unallocated expenses |  | (8,485 | ) |  | (5,275 | ) |  | (5,599 | ) |
| Total operating income |  | $ | 3,444 |  |  | $ | 5,135 |  |  | $ | 2,371 |  |

[0001730168-19-000144:notes:351]
Geographic Information

[0001730168-19-000144:notes:352]
Net revenue by country is based on the geographic shipment or delivery location as specified by the distributors, OEMs, contract manufacturers, channel partners, or software customers who purchased our products or services. For the majority of our products, title and control transfer to our customers in Penang, Malaysia. The products are then transported to the customer specific locations. Net revenue from the United States for fiscal years 2019, 2018, and 2017 was $4,235 million, $2,697 million and $1,266 million, respectively. Net revenue from China (including Hong Kong) for fiscal years 2019, 2018 and 2017 was $8,056 million, $10,305 million and $9,460 million, respectively. Net revenue from Singapore for fiscal year 2019 was $2,507 million (amounts were below 10% for fiscal years 2018 and 2017). Net revenue from other foreign countries for fiscal years 2019, 2018 and 2017 was $7,799 million, $7,846 million and $6,910 million, respectively. These geographic delivery locations are not necessarily indicative of the geographic location of our end customers or the country in which our end customers sell devices containing our products. For example, we believe a substantial portion of our products shipped or delivered to China (including Hong Kong) is included in devices sold by our end customers in the United States and Europe.

[0001730168-19-000144:notes:353]
Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-19-000144:notes:354]
|  |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,763 |  |  | $ | 1,859 |  |
| Taiwan |  | 258 |  |  | 264 |  |
| Other |  | 544 |  |  | 512 |  |
| Total long-lived assets |  | $ | 2,565 |  |  | $ | 2,635 |  |

[0001730168-19-000144:notes:355]
Significant Customer Information

[0001730168-19-000144:notes:356]
We sell our products through our direct sales force and a select network of distributors globally. One customer accounted for 24% of our net accounts receivable balance at November 3, 2019 compared with two customers which accounted for 20% and 14% of our net accounts receivable balance at November 4, 2018. During fiscal year 2019, one customer accounted for 17% of our net revenue. Revenue from this customer was included in our semiconductor solutions segment. During fiscal year 2018, no direct customers represented more than 10% of our net revenue. During fiscal year 2017, one customer represented 14% of our net revenue. The majority of the revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-19-000144:notes:357]
Commitments

[0001730168-19-000144:notes:358]
The following table summarizes contractual obligations and commitments as of November 3, 2019:

[0001730168-19-000144:notes:359]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |  |  |
| Debt principal, interest and fees |  | $ | 39,038 |  |  | $ | 5,628 |  |  | $ | 3,748 |  |  | $ | 6,415 |  |  | $ | 2,025 |  |  | $ | 5,996 |  |  | $ | 15,226 |  |
| Purchase commitments |  | 716 |  |  | 652 |  |  | 64 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 197 |  |  | 133 |  |  | 31 |  |  | 19 |  |  | 14 |  |  | — |  |  | — |  |
| Operating lease obligations |  | 800 |  |  | 115 |  |  | 99 |  |  | 80 |  |  | 69 |  |  | 47 |  |  | 390 |  |
| Total |  | $ | 40,751 |  |  | $ | 6,528 |  |  | $ | 3,942 |  |  | $ | 6,514 |  |  | $ | 2,108 |  |  | $ | 6,043 |  |  | $ | 15,616 |  |

[0001730168-19-000144:notes:360]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal year ended November 3, 2019.

[0001730168-19-000144:notes:361]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding

[0001730168-19-000144:notes:362]
purchase orders for capital expenditures in connection with internal fabrication facility expansion and construction of our new

[0001730168-19-000144:notes:363]
campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore,

[0001730168-19-000144:notes:364]
cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-19-000144:notes:365]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-19-000144:notes:366]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $244 million, $233 million and $253 million for fiscal years 2019, 2018 and 2017, respectively.

[0001730168-19-000144:notes:367]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 3, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authority. Therefore, $3,269 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our consolidated balance sheet as of November 3, 2019 have been excluded from the contractual obligations table above.

[0001730168-19-000144:notes:368]
Standby Letters of Credit

[0001730168-19-000144:notes:369]
As of November 3, 2019 and November 4, 2018, we had standby letters of credit of $62 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-19-000144:notes:370]
Contingencies

[0001730168-19-000144:notes:371]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-19-000144:notes:372]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-19-000144:notes:373]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiffs voluntarily dismissed AT Wireless from this action. On October 7, 2019, the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint, which are set to be heard on February 4, 2020. We believe these claims are all without merit and intend to vigorously defend these actions.

[0001730168-19-000144:notes:374]
Other Matters

[0001730168-19-000144:notes:375]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-19-000144:notes:376]
Contingency Assessment

[0001730168-19-000144:notes:377]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-19-000144:notes:378]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our consolidated financial statements.

[0001730168-19-000144:notes:379]
Other Indemnifications

[0001730168-19-000144:notes:380]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-19-000144:notes:381]
Restructuring Charges

[0001730168-19-000144:notes:382]
The following is a summary of significant restructuring expense recognized in continuing operations, primarily in operating expenses:

[0001730168-19-000144:notes:383]
| • | During fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $740 million of restructuring expense primarily related to employee termination and lease and other exit costs during fiscal year 2019. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020. |

[0001730168-19-000144:notes:384]
| • | During fiscal year 2018, we initiated cost reduction activities associated with the Brocade Merger. As a result, we recognized $2 million and $176 million of restructuring expense in fiscal years 2019 and 2018, respectively. These charges primarily related to employee termination costs. We have substantially completed the restructuring activities related to the acquisition of Brocade. |

[0001730168-19-000144:notes:385]
| • | In connection with cost reduction activities associated with the acquisition of BRCM, we recognized $4 million, $50 million and $124 million of restructuring expense in fiscal years 2019, 2018 and 2017, respectively. These restructuring expenses primarily related to lease and other exit costs for fiscal years 2019 and 2018 and employee termination costs for fiscal year 2017. We have substantially completed the restructuring activities related to the acquisition of BRCM. |

[0001730168-19-000144:notes:386]
|  |  | Employee Termination Costs |  | Lease and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 30, 2016 |  | $ | 116 |  |  | $ | 35 |  |  | $ | 151 |  |
| Restructuring charges (a) |  | 86 |  |  | 43 |  |  | 129 |  |
| Utilization |  | (174 | ) |  | (61 | ) |  | (235 | ) |
| Balance as of October 29, 2017 |  | 28 |  |  | 17 |  |  | 45 |  |
| Restructuring charges (a) |  | 153 |  |  | 75 |  |  | 228 |  |
| Utilization |  | (165 | ) |  | (86 | ) |  | (251 | ) |
| Balance as of November 4, 2018 |  | 16 |  |  | 6 |  |  | 22 |  |
| Liabilities assumed from CA |  | 29 |  |  | 38 |  |  | 67 |  |
| Restructuring charges |  | 586 |  |  | 160 |  |  | 746 |  |
| Utilization |  | (562 | ) |  | (165 | ) |  | (727 | ) |
| Balance as of November 3, 2019 (b) |  | $ | 69 |  |  | $ | 39 |  |  | $ | 108 |  |

[0001730168-19-000144:notes:387]
| (a) | Included $2 million and $5 million of restructuring charges related to discontinued operations recognized during fiscal years 2018 and 2017, respectively, which was included in loss from discontinued operations in our consolidated statements of operations. |

[0001730168-19-000144:notes:388]
| (b) | The majority of the employee termination costs balance is expected to be paid within the first half of fiscal year 2020. The majority of the leases and other exit costs balance is expected to be paid through the fiscal year ending November 2, 2025. |

[0001730168-19-000144:notes:389]
Impairment and Disposal Charges

[0001730168-19-000144:notes:390]
During fiscal year 2019, impairment and disposal charges of $67 million primarily related to property, plant and equipment. During fiscal year 2018, impairment and disposal charges of $13 million primarily related to leasehold improvements. During fiscal year 2017, impairment and disposal charges of $56 million related to property, plant and equipment and IPR&D projects acquired in the BRCM acquisition.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-19-000144:notes:391]
As of November 4, 2018, the 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom and Broadcom-Singapore. Substantially all of the 2017 Senior Notes have been registered with the SEC. During fiscal year 2019, we liquidated Broadcom-Singapore and de-registered the Partnership. BTI, a 100%-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with BRCM, Cayman Finance and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes as Subsidiary Guarantor under each of their respective indentures in accordance with their terms. On May 15, 2019, Cayman Finance was merged into BTI, with BTI remaining as the surviving entity. In connection with this merger, BTI remains a guarantor and became a co-issuer of the 2017 Senior Notes.

[0001730168-19-000144:notes:392]
Accordingly, we updated the guarantor structure, which resulted in the following revised column headings:

[0001730168-19-000144:notes:393]
| • | Parent Guarantor (Broadcom) |

[0001730168-19-000144:notes:394]
| • | Subsidiary Issuers (BTI and BRCM) |

[0001730168-19-000144:notes:395]
| • | Non-Guarantor Subsidiaries (our other subsidiaries) |

[0001730168-19-000144:notes:396]
We have applied the impacts of the change in guarantors and issuers retrospectively to all periods presented.

[0001730168-19-000144:notes:397]
The following tables set forth the condensed consolidating financial information for the Parent Guarantor, the Subsidiary Issuers, and the Non-Guarantor Subsidiaries for the periods presented. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor, the Subsidiary Issuers and the Non-Guarantor Subsidiaries are reflected in the Eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.

[0001730168-19-000144:notes:398]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | November 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 374 |  |  | $ | 613 |  |  | $ | 4,068 |  |  | $ | — |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,259 |  |  | — |  |  | 3,259 |  |
| Inventory |  | — |  |  | — |  |  | 874 |  |  | — |  |  | 874 |  |
| Intercompany receivable |  | 59 |  |  | 439 |  |  | 35 |  |  | (533 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 10,576 |  |  | 9,188 |  |  | (19,764 | ) |  | — |  |
| Other current assets |  | 58 |  |  | 37 |  |  | 634 |  |  | — |  |  | 729 |  |
| Total current assets |  | 491 |  |  | 11,665 |  |  | 18,058 |  |  | (20,297 | ) |  | 9,917 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 759 |  |  | 1,806 |  |  | — |  |  | 2,565 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 35,354 |  |  | — |  |  | 36,714 |  |
| Intangible assets, net |  | — |  |  | 76 |  |  | 17,478 |  |  | — |  |  | 17,554 |  |
| Investment in subsidiaries |  | 51,558 |  |  | 45,981 |  |  | — |  |  | (97,539 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 932 |  |  | (932 | ) |  | — |  |
| Other long-term assets |  | 25 |  |  | 95 |  |  | 623 |  |  | — |  |  | 743 |  |
| Total assets |  | $ | 52,074 |  |  | $ | 59,936 |  |  | $ | 74,251 |  |  | $ | (118,768 | ) |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 24 |  |  | $ | 38 |  |  | $ | 793 |  |  | $ | — |  |  | $ | 855 |  |
| Employee compensation and benefits |  | — |  |  | 179 |  |  | 462 |  |  | — |  |  | 641 |  |
| Current portion of long-term debt |  | — |  |  | 2,750 |  |  | 37 |  |  | — |  |  | 2,787 |  |
| Intercompany payable |  | 32 |  |  | 4 |  |  | 497 |  |  | (533 | ) |  | — |  |
| Intercompany loan payable |  | 13,709 |  |  | 4,935 |  |  | 1,120 |  |  | (19,764 | ) |  | — |  |
| Other current liabilities |  | 25 |  |  | 186 |  |  | 2,405 |  |  | — |  |  | 2,616 |  |
| Total current liabilities |  | 13,790 |  |  | 8,092 |  |  | 5,314 |  |  | (20,297 | ) |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 13,440 |  |  | 14,731 |  |  | 1,840 |  |  | — |  |  | 30,011 |  |
| Deferred tax liabilities |  | (126 | ) | (a) | (295 | ) | (a) | 1,952 |  |  | — |  |  | 1,531 |  |
| Intercompany loan payable, long-term |  | — |  |  | 932 |  |  | — |  |  | (932 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | 2,422 |  |  | 847 |  |  | — |  |  | 3,269 |  |
| Other long-term liabilities |  | — |  |  | 107 |  |  | 706 |  |  | — |  |  | 813 |  |
| Total liabilities |  | 27,104 |  |  | 25,989 |  |  | 10,659 |  |  | (21,229 | ) |  | 42,523 |  |
| Preferred stock dividend obligation |  | 29 |  |  | — |  |  | — |  |  | — |  |  | 29 |  |
| Total stockholders’ equity |  | 24,941 |  |  | 33,947 |  |  | 63,592 |  |  | (97,539 | ) |  | 24,941 |  |
| Total liabilities and equity |  | $ | 52,074 |  |  | $ | 59,936 |  |  | $ | 74,251 |  |  | $ | (118,768 | ) |  | $ | 67,493 |  |

[0001730168-19-000144:notes:399]
(a) Amount represents net deferred tax assets that are offset by net deferred tax liabilities on a consolidated basis.

[0001730168-19-000144:notes:400]
|  |  | Condensed Consolidating Balance Sheets |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | 2,461 |  |  | $ | 1,831 |  |  | $ | — |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | 3,325 |  |  | — |  |  | 3,325 |  |
| Inventory |  | — |  |  | — |  |  | 1,124 |  |  | — |  |  | 1,124 |  |
| Intercompany receivable |  | 56 |  |  | 182 |  |  | 67 |  |  | (305 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | 9,780 |  |  | 4,713 |  |  | (14,493 | ) |  | — |  |
| Other current assets |  | 52 |  |  | 37 |  |  | 277 |  |  | — |  |  | 366 |  |
| Total current assets |  | 108 |  |  | 12,460 |  |  | 11,337 |  |  | (14,798 | ) |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | 772 |  |  | 1,863 |  |  | — |  |  | 2,635 |  |
| Goodwill |  | — |  |  | 1,360 |  |  | 25,553 |  |  | — |  |  | 26,913 |  |
| Intangible assets, net |  | — |  |  | 84 |  |  | 10,678 |  |  | — |  |  | 10,762 |  |
| Investment in subsidiaries |  | 35,268 |  |  | 46,742 |  |  | — |  |  | (82,010 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | 991 |  |  | (991 | ) |  | — |  |
| Other long-term assets |  | — |  |  | 250 |  |  | 457 |  |  | — |  |  | 707 |  |
| Total assets |  | $ | 35,376 |  |  | $ | 61,668 |  |  | $ | 50,879 |  |  | $ | (97,799 | ) |  | $ | 50,124 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 19 |  |  | $ | 44 |  |  | $ | 748 |  |  | $ | — |  |  | $ | 811 |  |
| Employee compensation and benefits |  | — |  |  | 272 |  |  | 443 |  |  | — |  |  | 715 |  |
| Intercompany payable |  | 9 |  |  | 58 |  |  | 238 |  |  | (305 | ) |  | — |  |
| Intercompany loan payable |  | 8,691 |  |  | 4,713 |  |  | 1,089 |  |  | (14,493 | ) |  | — |  |
| Other current liabilities |  | — |  |  | 219 |  |  | 593 |  |  | — |  |  | 812 |  |
| Total current liabilities |  | 8,719 |  |  | 5,306 |  |  | 3,111 |  |  | (14,798 | ) |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | 17,456 |  |  | 37 |  |  | — |  |  | 17,493 |  |
| Deferred tax liabilities |  | — |  |  | (47 | ) | (a) | 216 |  |  | — |  |  | 169 |  |
| Intercompany loan payable, long-term |  | — |  |  | 991 |  |  | — |  |  | (991 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | 2,563 |  |  | 525 |  |  | — |  |  | 3,088 |  |
| Other long-term liabilities |  | — |  |  | 131 |  |  | 248 |  |  | — |  |  | 379 |  |
| Total liabilities |  | 8,719 |  |  | 26,400 |  |  | 4,137 |  |  | (15,789 | ) |  | 23,467 |  |
| Total stockholders’ equity |  | 26,657 |  |  | 35,268 |  |  | 46,742 |  |  | (82,010 | ) |  | 26,657 |  |
| Total liabilities and equity |  | $ | 35,376 |  |  | $ | 61,668 |  |  | $ | 50,879 |  |  | $ | (97,799 | ) |  | $ | 50,124 |  |

[0001730168-19-000144:notes:401]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Year Ended |
|  |  | November 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 18,117 |  |  | $ | — |  |  | $ | 18,117 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 4,480 |  |  | — |  |  | 4,480 |  |
| Intercompany revenue |  | — |  |  | 1,573 |  |  | — |  |  | (1,573 | ) |  | — |  |
| Total net revenue |  | — |  |  | 1,573 |  |  | 22,597 |  |  | (1,573 | ) |  | 22,597 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 138 |  |  | 6,070 |  |  | — |  |  | 6,208 |  |
| Cost of subscriptions and services |  | — |  |  | 15 |  |  | 500 |  |  | — |  |  | 515 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 122 |  |  | (122 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 3,314 |  |  | — |  |  | 3,314 |  |
| Restructuring charges |  | — |  |  | (7 | ) |  | 84 |  |  | — |  |  | 77 |  |
| Total cost of revenue |  | — |  |  | 146 |  |  | 10,090 |  |  | (122 | ) |  | 10,114 |  |
| Gross margin |  | — |  |  | 1,427 |  |  | 12,507 |  |  | (1,451 | ) |  | 12,483 |  |
| Research and development |  | — |  |  | 1,885 |  |  | 2,811 |  |  | — |  |  | 4,696 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 1,451 |  |  | (1,451 | ) |  | — |  |
| Selling, general and administrative |  | 129 |  |  | 324 |  |  | 1,256 |  |  | — |  |  | 1,709 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 1,898 |  |  | — |  |  | 1,898 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 17 |  |  | 719 |  |  | — |  |  | 736 |  |
| Total operating expenses |  | 129 |  |  | 2,226 |  |  | 8,135 |  |  | (1,451 | ) |  | 9,039 |  |
| Operating income (loss) |  | (129 | ) |  | (799 | ) |  | 4,372 |  |  | — |  |  | 3,444 |  |
| Interest expense |  | (753 | ) |  | (591 | ) |  | (100 | ) |  | — |  |  | (1,444 | ) |
| Intercompany interest expense |  | (369 | ) |  | (162 | ) |  | (35 | ) |  | 566 |  |  | — |  |
| Other income, net |  | 3 |  |  | 25 |  |  | 198 |  |  | — |  |  | 226 |  |
| Intercompany interest income |  | — |  |  | 308 |  |  | 258 |  |  | (566 | ) |  | — |  |
| Intercompany other income (expense), net |  | 893 |  |  | — |  |  | (893 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (355 | ) |  | (1,219 | ) |  | 3,800 |  |  | — |  |  | 2,226 |  |
| Provision for (benefit from) income taxes |  | (277 | ) |  | 136 |  |  | (369 | ) |  | — |  |  | (510 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (78 | ) |  | (1,355 | ) |  | 4,169 |  |  | — |  |  | 2,736 |  |
| Earnings in subsidiaries |  | 2,802 |  |  | 5,299 |  |  | — |  |  | (8,101 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 2,724 |  |  | 3,944 |  |  | 4,169 |  |  | (8,101 | ) |  | 2,736 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Net income |  | $ | 2,724 |  |  | $ | 3,944 |  |  | $ | 4,157 |  |  | $ | (8,101 | ) |  | $ | 2,724 |  |
| Net income |  | $ | 2,724 |  |  | $ | 3,944 |  |  | $ | 4,157 |  |  | $ | (8,101 | ) |  | $ | 2,724 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | (24 | ) |
| Other comprehensive loss |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | (24 | ) |
| Comprehensive income |  | $ | 2,724 |  |  | $ | 3,944 |  |  | $ | 4,133 |  |  | $ | (8,101 | ) |  | $ | 2,700 |  |

[0001730168-19-000144:notes:402]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Year Ended |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | 19,754 |  |  | $ | — |  |  | $ | 19,754 |  |
| Subscriptions and services |  | — |  |  | — |  |  | 1,094 |  |  | — |  |  | 1,094 |  |
| Intercompany revenue |  | — |  |  | 1,924 |  |  | — |  |  | (1,924 | ) |  | — |  |
| Total net revenue |  | — |  |  | 1,924 |  |  | 20,848 |  |  | (1,924 | ) |  | 20,848 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 120 |  |  | 6,804 |  |  | — |  |  | 6,924 |  |
| Cost of subscriptions and services |  | — |  |  | 12 |  |  | 85 |  |  | — |  |  | 97 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | 126 |  |  | (126 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 3,004 |  |  | — |  |  | 3,004 |  |
| Restructuring charges |  | — |  |  | 1 |  |  | 19 |  |  | — |  |  | 20 |  |
| Total cost of revenue |  | — |  |  | 133 |  |  | 10,108 |  |  | (126 | ) |  | 10,115 |  |
| Gross margin |  | — |  |  | 1,791 |  |  | 10,740 |  |  | (1,798 | ) |  | 10,733 |  |
| Research and development |  | — |  |  | 1,651 |  |  | 2,117 |  |  | — |  |  | 3,768 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | 1,798 |  |  | (1,798 | ) |  | — |  |
| Selling, general and administrative |  | 31 |  |  | 297 |  |  | 728 |  |  | — |  |  | 1,056 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | 541 |  |  | — |  |  | 541 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 53 |  |  | 166 |  |  | — |  |  | 219 |  |
| Litigation settlements |  | — |  |  | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Total operating expenses |  | 31 |  |  | 2,015 |  |  | 5,350 |  |  | (1,798 | ) |  | 5,598 |  |
| Operating income (loss) |  | (31 | ) |  | (224 | ) |  | 5,390 |  |  | — |  |  | 5,135 |  |
| Interest expense |  | — |  |  | (626 | ) |  | (2 | ) |  | — |  |  | (628 | ) |
| Intercompany interest expense |  | (67 | ) |  | (199 | ) |  | (1,449 | ) |  | 1,715 |  |  | — |  |
| Impairment on investment |  | — |  |  | — |  |  | (106 | ) |  | — |  |  | (106 | ) |
| Other income, net |  | — |  |  | 88 |  |  | 56 |  |  | — |  |  | 144 |  |
| Intercompany interest income |  | — |  |  | 1,516 |  |  | 199 |  |  | (1,715 | ) |  | — |  |
| Intercompany other income (expense), net |  | 111 |  |  | (56 | ) |  | (55 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | 13 |  |  | 499 |  |  | 4,033 |  |  | — |  |  | 4,545 |  |
| Provision for (benefit from) income taxes |  | 44 |  |  | (7,878 | ) |  | (250 | ) |  | — |  |  | (8,084 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (31 | ) |  | 8,377 |  |  | 4,283 |  |  | — |  |  | 12,629 |  |
| Earnings in subsidiaries |  | 12,290 |  |  | 4,266 |  |  | — |  |  | (16,556 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 12,259 |  |  | 12,643 |  |  | 4,283 |  |  | (16,556 | ) |  | 12,629 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (2 | ) |  | (17 | ) |  | — |  |  | (19 | ) |
| Net income |  | 12,259 |  |  | 12,641 |  |  | 4,266 |  |  | (16,556 | ) |  | 12,610 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 12,259 |  |  | $ | 12,290 |  |  | $ | 4,266 |  |  | $ | (16,556 | ) |  | $ | 12,259 |  |
| Net income |  | $ | 12,259 |  |  | $ | 12,641 |  |  | $ | 4,266 |  |  | $ | (16,556 | ) |  | $ | 12,610 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Other comprehensive loss |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Comprehensive income |  | 12,259 |  |  | 12,641 |  |  | 4,258 |  |  | (16,556 | ) |  | 12,602 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | 351 |  |
| Comprehensive income attributable to Broadcom Inc. stockholders |  | $ | 12,259 |  |  | $ | 12,290 |  |  | $ | 4,258 |  |  | $ | (16,556 | ) |  | $ | 12,251 |  |

[0001730168-19-000144:notes:403]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Year Ended |
|  |  | October 29, 2017 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | 71 |  |  | $ | 16,962 |  |  | $ | — |  |  | $ | 17,033 |  |
| Subscriptions and services |  | — |  |  | 2 |  |  | 601 |  |  | — |  |  | 603 |  |
| Intercompany revenue |  | — |  |  | 2,046 |  |  | 8 |  |  | (2,054 | ) |  | — |  |
| Total net revenue |  | — |  |  | 2,119 |  |  | 17,571 |  |  | (2,054 | ) |  | 17,636 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | 142 |  |  | 6,407 |  |  | — |  |  | 6,549 |  |
| Cost of subscriptions and services |  | — |  |  | 12 |  |  | 32 |  |  | — |  |  | 44 |  |
| Intercompany cost of products sold |  | — |  |  | (12 | ) |  | 174 |  |  | (162 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | 7 |  |  | 2,504 |  |  | — |  |  | 2,511 |  |
| Restructuring charges |  | — |  |  | 5 |  |  | 14 |  |  | — |  |  | 19 |  |
| Total cost of revenue |  | — |  |  | 154 |  |  | 9,135 |  |  | (162 | ) |  | 9,127 |  |
| Gross margin |  | — |  |  | 1,965 |  |  | 8,436 |  |  | (1,892 | ) |  | 8,509 |  |
| Research and development |  | — |  |  | 1,490 |  |  | 1,812 |  |  | — |  |  | 3,302 |  |
| Intercompany operating expense |  | — |  |  | (66 | ) |  | 1,958 |  |  | (1,892 | ) |  | — |  |
| Selling, general and administrative |  | — |  |  | 339 |  |  | 450 |  |  | — |  |  | 789 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | 7 |  |  | 1,757 |  |  | — |  |  | 1,764 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | 54 |  |  | 107 |  |  | — |  |  | 161 |  |
| Litigation settlements |  | — |  |  | — |  |  | 122 |  |  | — |  |  | 122 |  |
| Total operating expenses |  | — |  |  | 1,824 |  |  | 6,206 |  |  | (1,892 | ) |  | 6,138 |  |
| Operating income |  | — |  |  | 141 |  |  | 2,230 |  |  | — |  |  | 2,371 |  |
| Interest expense |  | — |  |  | (411 | ) |  | (43 | ) |  | — |  |  | (454 | ) |
| Intercompany interest expense |  | — |  |  | (274 | ) |  | (1,425 | ) |  | 1,699 |  |  | — |  |
| Loss on extinguishment of debt |  | — |  |  | (59 | ) |  | (107 | ) |  | — |  |  | (166 | ) |
| Other income, net |  | — |  |  | 30 |  |  | 44 |  |  | — |  |  | 74 |  |
| Intercompany interest income |  | — |  |  | 1,425 |  |  | 274 |  |  | (1,699 | ) |  | — |  |
| Intercompany other income (expense), net |  | — |  |  | (589 | ) |  | 589 |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes and earnings in subsidiaries |  | — |  |  | 263 |  |  | 1,562 |  |  | — |  |  | 1,825 |  |
| Provision for (benefit from) income taxes |  | — |  |  | 67 |  |  | (32 | ) |  | — |  |  | 35 |  |
| Income from continuing operations before earnings in subsidiaries |  | — |  |  | 196 |  |  | 1,594 |  |  | — |  |  | 1,790 |  |
| Earnings in subsidiaries |  | 1,692 |  |  | 1,601 |  |  | — |  |  | (3,293 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 1,692 |  |  | 1,797 |  |  | 1,594 |  |  | (3,293 | ) |  | 1,790 |  |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | (13 | ) |  | 7 |  |  | — |  |  | (6 | ) |
| Net income |  | 1,692 |  |  | 1,784 |  |  | 1,601 |  |  | (3,293 | ) |  | 1,784 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Net income attributable to common stock |  | $ | 1,692 |  |  | $ | 1,692 |  |  | $ | 1,601 |  |  | $ | (3,293 | ) |  | $ | 1,692 |  |
| Net income |  | $ | 1,692 |  |  | $ | 1,784 |  |  | $ | 1,601 |  |  | $ | (3,293 | ) |  | $ | 1,784 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |  |  |
| Change in actuarial loss and prior service costs associated with defined benefit pension plans and post-retirement benefit plans |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Other comprehensive income |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Comprehensive income |  | 1,692 |  |  | 1,784 |  |  | 1,644 |  |  | (3,293 | ) |  | 1,827 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Comprehensive income attributable to Broadcom Inc. stockholders |  | $ | 1,692 |  |  | $ | 1,692 |  |  | $ | 1,644 |  |  | $ | (3,293 | ) |  | $ | 1,735 |  |

[0001730168-19-000144:notes:404]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | November 3, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,724 |  |  | $ | 3,944 |  |  | $ | 4,157 |  |  | $ | (8,101 | ) |  | $ | 2,724 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (3,264 | ) |  | (4,571 | ) |  | 6,707 |  |  | 8,101 |  |  | 6,973 |  |
| Net cash provided by (used in) operating activities |  | (540 | ) |  | (627 | ) |  | 10,864 |  |  | — |  |  | 9,697 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | 1,375 |  |  | (796 | ) |  | (9,210 | ) |  | 8,631 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | (17,865 | ) |  | — |  |  | 1,832 |  |  | — |  |  | (16,033 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 957 |  |  | — |  |  | 957 |  |
| Purchases of property, plant and equipment |  | — |  |  | (165 | ) |  | (297 | ) |  | 30 |  |  | (432 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 30 |  |  | 88 |  |  | (30 | ) |  | 88 |  |
| Purchases of investments |  | (5 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Proceeds from sales of investments |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Other |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net cash used in investing activities |  | (16,495 | ) |  | (931 | ) |  | (6,627 | ) |  | 8,631 |  |  | (15,422 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Net intercompany borrowings |  | 9,818 |  |  | 156 |  |  | (1,343 | ) |  | (8,631 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 28,793 |  |  | — |  |  | — |  |  | — |  |  | 28,793 |  |
| Repayment of debt |  | (16,400 | ) |  | — |  |  | (400 | ) |  | — |  |  | (16,800 | ) |
| Other borrowings |  | 986 |  |  | — |  |  | 255 |  |  | — |  |  | 1,241 |  |
| Dividend and distribution payments on common stock and exchangeable limited partnership units |  | (4,235 | ) |  | — |  |  | — |  |  | — |  |  | (4,235 | ) |
| Repurchases of common stock - repurchase program |  | (5,435 | ) |  | — |  |  | — |  |  | — |  |  | (5,435 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (446 | ) |  | (526 | ) |  | — |  |  | (972 | ) |
| Issuance of preferred stock, net |  | 3,679 |  |  | — |  |  | — |  |  | — |  |  | 3,679 |  |
| Issuance of common stock |  | 253 |  |  | — |  |  | — |  |  | — |  |  | 253 |  |
| Other |  | (50 | ) |  | — |  |  | 14 |  |  | — |  |  | (36 | ) |
| Net cash provided by (used in) financing activities |  | 17,409 |  |  | (290 | ) |  | (2,000 | ) |  | (8,631 | ) |  | 6,488 |  |
| Net change in cash and cash equivalents |  | 374 |  |  | (1,848 | ) |  | 2,237 |  |  | — |  |  | 763 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | 2,461 |  |  | 1,831 |  |  | — |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 374 |  |  | $ | 613 |  |  | $ | 4,068 |  |  | $ | — |  |  | $ | 5,055 |  |

[0001730168-19-000144:notes:405]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,259 |  |  | $ | 12,641 |  |  | $ | 4,266 |  |  | $ | (16,556 | ) |  | $ | 12,610 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (12,323 | ) |  | (12,893 | ) |  | 4,701 |  |  | 16,785 |  |  | (3,730 | ) |
| Net cash provided by (used in) operating activities |  | (64 | ) |  | (252 | ) |  | 8,967 |  |  | 229 |  |  | 8,880 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | (9,099 | ) |  | (3,002 | ) |  | 12,101 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | — |  |  | 1,521 |  |  | (1,521 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | 2,637 |  |  | (261 | ) |  | (2,376 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (4,800 | ) |  | — |  |  | (4,800 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 773 |  |  | — |  |  | 773 |  |
| Purchases of property, plant and equipment |  | — |  |  | (196 | ) |  | (497 | ) |  | 58 |  |  | (635 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 55 |  |  | 242 |  |  | (58 | ) |  | 239 |  |
| Purchases of investments |  | — |  |  | (50 | ) |  | (199 | ) |  | — |  |  | (249 | ) |
| Proceeds from sales of investments |  | — |  |  | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Other |  | — |  |  | (50 | ) |  | (6 | ) |  | — |  |  | (56 | ) |
| Net cash used in investing activities |  | — |  |  | (6,649 | ) |  | (6,229 | ) |  | 8,204 |  |  | (4,674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | 3,231 |  |  | 9,099 |  |  | (12,330 | ) |  | — |  |
| Net intercompany borrowings |  | 8,690 |  |  | 261 |  |  | (11,327 | ) |  | 2,376 |  |  | — |  |
| Repayment of debt |  | — |  |  | (117 | ) |  | (856 | ) |  | — |  |  | (973 | ) |
| Dividend and distribution payments on common stock and exchangeable limited partnership units |  | (1,477 | ) |  | (1,521 | ) |  | (1,521 | ) |  | 1,521 |  |  | (2,998 | ) |
| Repurchases of common stock - repurchase program |  | (7,258 | ) |  | — |  |  | — |  |  | — |  |  | (7,258 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | (20 | ) |  | (36 | ) |  | — |  |  | (56 | ) |
| Issuance of common stock |  | 109 |  |  | — |  |  | 103 |  |  | — |  |  | 212 |  |
| Other |  | — |  |  | (27 | ) |  | (18 | ) |  | — |  |  | (45 | ) |
| Net cash provided by (used in) financing activities |  | 64 |  |  | 1,807 |  |  | (4,556 | ) |  | (8,433 | ) |  | (11,118 | ) |
| Net change in cash and cash equivalents |  | — |  |  | (5,094 | ) |  | (1,818 | ) |  | — |  |  | (6,912 | ) |
| Cash and cash equivalents at the beginning of period |  | — |  |  | 7,555 |  |  | 3,649 |  |  | — |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 2,461 |  |  | $ | 1,831 |  |  | $ | — |  |  | $ | 4,292 |  |

[0001730168-19-000144:notes:406]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Fiscal Year Ended |
|  |  | October 29, 2017 |
|  |  | Parent Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (in millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,692 |  |  | $ | 1,784 |  |  | $ | 1,601 |  |  | $ | (3,293 | ) |  | $ | 1,784 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  | (1,692 | ) |  | 924 |  |  | 2,077 |  |  | 3,458 |  |  | 4,767 |  |
| Net cash provided by operating activities |  | — |  |  | 2,708 |  |  | 3,678 |  |  | 165 |  |  | 6,551 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | — |  |  | (40 | ) |  | 40 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | — |  |  | 1,834 |  |  | (1,834 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | (286 | ) |  | 5,835 |  |  | (5,549 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Purchases of property, plant and equipment |  | — |  |  | (254 | ) |  | (841 | ) |  | 26 |  |  | (1,069 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 25 |  |  | 442 |  |  | (26 | ) |  | 441 |  |
| Purchases of investments |  | — |  |  | (200 | ) |  | (7 | ) |  | — |  |  | (207 | ) |
| Proceeds from maturities of investments |  | — |  |  | 200 |  |  | — |  |  | — |  |  | 200 |  |
| Other |  | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net cash provided by (used in) investing activities |  | — |  |  | (515 | ) |  | 7,184 |  |  | (7,343 | ) |  | (674 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | 205 |  |  | — |  |  | (205 | ) |  | — |  |
| Net intercompany borrowings |  | — |  |  | (5,797 | ) |  | 248 |  |  | 5,549 |  |  | — |  |
| Proceeds from long-term borrowings |  | — |  |  | 17,426 |  |  | — |  |  | — |  |  | 17,426 |  |
| Repayment of debt |  | — |  |  | (5,704 | ) |  | (7,964 | ) |  | — |  |  | (13,668 | ) |
| Dividend and distribution payments on common stock and exchangeable limited partnership units |  | — |  |  | (1,834 | ) |  | (1,745 | ) |  | 1,834 |  |  | (1,745 | ) |
| Issuance of common stock |  | — |  |  | — |  |  | 257 |  |  | — |  |  | 257 |  |
| Other |  | — |  |  | (26 | ) |  | (14 | ) |  | — |  |  | (40 | ) |
| Net cash provided by (used in) financing activities |  | — |  |  | 4,270 |  |  | (9,218 | ) |  | 7,178 |  |  | 2,230 |  |
| Net change in cash and cash equivalents |  | — |  |  | 6,463 |  |  | 1,644 |  |  | — |  |  | 8,107 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | 1,092 |  |  | 2,005 |  |  | — |  |  | 3,097 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | 7,555 |  |  | $ | 3,649 |  |  | $ | — |  |  | $ | 11,204 |  |


## us-gaap:SubsequentEventsTextBlock

[0001730168-19-000144:notes:407]
Acquisition of Symantec Corporation’s Enterprise Security Business

[0001730168-19-000144:notes:408]
On November 4, 2019, we completed the purchase and assumption of certain assets and certain liabilities, respectively, of Symantec Corporation’s Enterprise Security business for approximately $10.7 billion in cash (the “Symantec Asset Purchase”).

[0001730168-19-000144:notes:409]
We expect to account for the Symantec Asset Purchase as a business combination and are currently evaluating the purchase price allocation. It is not practicable to disclose the preliminary purchase price allocation or unaudited pro forma combined financial information for this transaction, given the short period of time between the acquisition date and the issuance of these consolidated financial statements.

[0001730168-19-000144:notes:410]
2020 Term Loans

[0001730168-19-000144:notes:411]
In connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility due November 2022 and a $7,750 million unsecured term A-5 facility due November 2024, collectively referred to as the “2020 Term Loans”. The 2020 Credit Agreement has substantially the same representations and warranties, covenants and events of default as the 2019 Credit Agreement. On November 4, 2019, we used $12 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase and related working capital needs. On December 2, 2019, we refinanced our 5.375% notes due December 2019 using $750 million of net proceeds from the 2020 Term Loans. The remaining net proceeds from the 2020 Term Loans of $2,750 million are available to refinance our 2.375% notes due January 2020.

[0001730168-19-000144:notes:412]
Principal payments of 2.50% of the original aggregate principal amount borrowed on our 2020 Term Loans are due quarterly beginning in March 2020 with the remaining principal due upon the respective maturity dates of our 2020 Term Loans. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by our subsidiaries, BRCM and BTI.

[0001730168-19-000144:notes:413]
Preferred Stock Cash Dividends Declared

[0001730168-19-000144:notes:414]
On December 10, 2019, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on December 31, 2019 to stockholders of record on December 15, 2019.

[0001730168-19-000144:notes:415]
Common Stock Cash Dividends Declared

[0001730168-19-000144:notes:416]
On December 10, 2019, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on December 31, 2019 to stockholders of record on December 23, 2019.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001730168-19-000144:notes:417]
Supplementary Financial Data — Quarterly Data (Unaudited)

[0001730168-19-000144:notes:418]
|  |  | Fiscal Quarter Ended |
|  |  | November 3, 2019 (1) |  | August 4, 2019 (2) |  | May 5, 2019 (3) |  | February 3, 2019 (4) |  | November 4, 2018 (5) |  | August 5, 2018 (6) |  | May 6, 2018 (7) |  | February 4, 2018 (8) |
|  |  | (In millions, except per share data) |
| Total net revenue (9) |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,789 |  |  | $ | 5,444 |  |  | $ | 5,063 |  |  | $ | 5,014 |  |  | $ | 5,327 |  |
| Gross margin |  | $ | 3,152 |  |  | $ | 3,034 |  |  | $ | 3,089 |  |  | $ | 3,208 |  |  | $ | 2,935 |  |  | $ | 2,619 |  |  | $ | 2,551 |  |  | $ | 2,628 |  |
| Operating income |  | $ | 1,054 |  |  | $ | 865 |  |  | $ | 970 |  |  | $ | 555 |  |  | $ | 1,652 |  |  | $ | 1,339 |  |  | $ | 1,201 |  |  | $ | 943 |  |
| Income from continuing operations |  | $ | 847 |  |  | $ | 715 |  |  | $ | 693 |  |  | $ | 481 |  |  | $ | 1,115 |  |  | $ | 1,197 |  |  | $ | 3,736 |  |  | $ | 6,581 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (2 | ) |  | (10 | ) |  | — |  |  | (1 | ) |  | (3 | ) |  | (15 | ) |
| Net income |  | 847 |  |  | 715 |  |  | 691 |  |  | 471 |  |  | 1,115 |  |  | 1,196 |  |  | 3,733 |  |  | 6,566 |  |
| Dividends on preferred stock |  | 29 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income attributable to noncontrolling interest |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | 336 |  |
| Net income attributable to common stock |  | $ | 818 |  |  | $ | 715 |  |  | $ | 691 |  |  | $ | 471 |  |  | $ | 1,115 |  |  | $ | 1,196 |  |  | $ | 3,718 |  |  | $ | 6,230 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 1.15 |  |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 8.34 |  |  | $ | 14.66 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | (0.03 | ) |  | — |  |  | — |  |  | (0.01 | ) |  | (0.04 | ) |
| Net income per share |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 1.12 |  |  | $ | 2.64 |  |  | $ | 2.71 |  |  | $ | 8.33 |  |  | $ | 14.62 |  |
| Dividends declared and paid per share |  | $ | 2.65 |  |  | $ | 2.65 |  |  | $ | 2.65 |  |  | $ | 2.65 |  |  | $ | 1.75 |  |  | $ | 1.75 |  |  | $ | 1.75 |  |  | $ | 1.75 |  |
| Dividends declared and paid per share-full year |  | $ | 10.60 |  |  |  |  |  |  |  |  | $ | 7.00 |  |  |  |  |  |  |  |

[0001730168-19-000144:notes:419]
| (1) | Includes amortization of acquisition-related intangible assets of $1,301 million. |

[0001730168-19-000144:notes:420]
| (2) | Includes amortization of acquisition-related intangible assets of $1,303 million. |

[0001730168-19-000144:notes:421]
| (3) | Includes amortization of acquisition-related intangible assets of $1,299 million. |

[0001730168-19-000144:notes:422]
| (4) | Includes the results of CA beginning with the fiscal quarter ended February 3, 2019 in connection with the completion of the CA Merger on November 5, 2018. Also includes amortization of acquisition-related intangible assets of $1,309 million and restructuring, impairment and disposal charges of $629 million. |

[0001730168-19-000144:notes:423]
| (5) | Includes amortization of acquisition-related intangible assets of $829 million and impairment on investment of $106 million. |

[0001730168-19-000144:notes:424]
| (6) | Includes amortization of acquisition-related intangible assets of $830 million. |

[0001730168-19-000144:notes:425]
| (7) | Includes amortization of acquisition-related intangible assets of $832 million. |

[0001730168-19-000144:notes:426]
| (8) | Includes the results of Brocade beginning with the fiscal quarter ended February 4, 2018 in connection with the completion of the Brocade Merger on November 17, 2017. Also includes amortization of acquisition-related intangible assets of $1,054 million, a purchase accounting effect on inventory charge of $70 million and restructuring, impairment and disposal charges of $145 million. |

[0001730168-19-000144:notes:427]
(9)

[0001730168-19-000144:notes:428]
At the beginning of fiscal year 2019, we adopted Topic 606. Periods prior to fiscal year 2019 are presented in accordance with Accounting Standards Codification 605, Revenue Recognition. Refer to Note 3. “Revenue from Contracts with Customers” included in Part II, Item 8. for additional information on our adoption of Topic 606.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-19-000144:notes:429]
Schedule II — Valuation and Qualifying Accounts

[0001730168-19-000144:notes:430]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (1) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2019 |  | $ | 151 |  |  | $ | 705 |  |  | $ | (703 | ) |  | $ | 153 |  |
| Fiscal year ended November 4, 2018 |  | $ | 177 |  |  | $ | 882 |  |  | $ | (908 | ) |  | $ | 151 |  |
| Fiscal year ended October 29, 2017 |  | $ | 252 |  |  | $ | 1,176 |  |  | $ | (1,251 | ) |  | $ | 177 |  |
| Other accounts receivable allowances (2) |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2019 |  | $ | 12 |  |  | $ | 99 |  |  | $ | (73 | ) |  | $ | 38 |  |
| Fiscal year ended November 4, 2018 |  | $ | 31 |  |  | $ | 116 |  |  | $ | (135 | ) |  | $ | 12 |  |
| Fiscal year ended October 29, 2017 |  | $ | 40 |  |  | $ | 49 |  |  | $ | (58 | ) |  | $ | 31 |  |
| Income tax valuation allowances |  |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended November 3, 2019 |  | $ | 1,347 |  |  | $ | 283 |  |  | $ | (68 | ) |  | $ | 1,562 |  |
| Fiscal year ended November 4, 2018 |  | $ | 1,447 |  |  | $ | 314 |  |  | $ | (414 | ) |  | $ | 1,347 |  |
| Fiscal year ended October 29, 2017 |  | $ | 1,003 |  |  | $ | 460 |  |  | $ | (16 | ) |  | $ | 1,447 |  |

[0001730168-19-000144:notes:431]
_______________________________________

[0001730168-19-000144:notes:432]
| (1) | Distributor credit allowances relate to price adjustments and other allowances. |

[0001730168-19-000144:notes:433]
(2)

[0001730168-19-000144:notes:434]
Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts.
