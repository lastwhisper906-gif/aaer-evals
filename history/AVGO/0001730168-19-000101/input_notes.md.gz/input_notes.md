# AVGO notes — 0001730168-19-000101


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-19-000101:notes:1]
Overview, Basis of Presentation and Significant Accounting Policies
Overview

[0001730168-19-000101:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

[0001730168-19-000101:notes:3]
[same as prior period, unchanged from 0001730168-19-000036:notes:141]

[0001730168-19-000101:notes:4]
The financial statements relate to Broadcom-Singapore for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, and relate to Broadcom for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

[0001730168-19-000101:notes:5]
[same as prior period, unchanged from 0001730168-19-000036:notes:143]

[0001730168-19-000101:notes:6]
On November 5, 2018, we acquired CA, Inc. (“CA”) for $16.1 billion, net of cash acquired (the “CA Merger”). CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018 (the “CA Acquisition Date”). See Note 3. “Acquisitions” for additional information.

[0001730168-19-000101:notes:7]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property (“IP”) licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

[0001730168-19-000101:notes:8]
[same as prior period, unchanged from 0001730168-19-000036:notes:146]

[0001730168-19-000101:notes:9]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.

[0001730168-19-000101:notes:10]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 5, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.

[0001730168-19-000101:notes:11]
[same as prior period, unchanged from 0001730168-19-000036:notes:148]

[0001730168-19-000101:notes:12]
[same as prior period, unchanged from 0001730168-19-000036:notes:149]

[0001730168-19-000101:notes:13]
[same as prior period, unchanged from 0001730168-19-000036:notes:150]

[0001730168-19-000101:notes:14]
Recently Adopted Accounting Guidance

[0001730168-19-000101:notes:15]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board (“FASB”) guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.

[0001730168-19-000101:notes:16]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and two fiscal quarters ended May 5, 2019, we also recognized $40 million and $67 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.

[0001730168-19-000101:notes:17]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (“Topic 606”). We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. “Revenue from Contracts with Customers” for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

[0001730168-19-000101:notes:18]
Recent Accounting Guidance Not Yet Adopted

[0001730168-19-000101:notes:19]
In February 2016, the FASB issued guidance related to the accounting for leases, which among other things, requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. This guidance will be effective for the first quarter of our fiscal year 2020. The new guidance is required to be applied using a modified retrospective approach. We are evaluating the impact this guidance will have on our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-19-000101:notes:20]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-19-000101:notes:21]
Nature of Products and Services

[0001730168-19-000101:notes:22]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-19-000101:notes:23]
Products. Under Topic 606, we recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

[0001730168-19-000101:notes:24]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

[0001730168-19-000101:notes:25]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-19-000101:notes:26]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. Our CA-related subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in a ratable revenue recognition of software revenue over the contractual period.

[0001730168-19-000101:notes:27]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-19-000101:notes:28]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-19-000101:notes:29]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-19-000101:notes:30]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-19-000101:notes:31]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-19-000101:notes:32]
Arrangements with Multiple Performance Obligations

[0001730168-19-000101:notes:33]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-19-000101:notes:34]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-19-000101:notes:35]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-19-000101:notes:36]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-19-000101:notes:37]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-19-000101:notes:38]
Other Policies and Judgments

[0001730168-19-000101:notes:39]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services are generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or on a combination of both based on the nature of modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-19-000101:notes:40]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-19-000101:notes:41]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications in accordance with Topic 606. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

[0001730168-19-000101:notes:42]
[same as prior period, unchanged from 0001730168-19-000036:notes:187]

[0001730168-19-000101:notes:43]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. “Segment Information”.

[0001730168-19-000101:notes:44]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

[0001730168-19-000101:notes:45]
|  |  | Fiscal Quarter Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services* |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

[0001730168-19-000101:notes:46]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services* |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

[0001730168-19-000101:notes:47]
________________________________

[0001730168-19-000101:notes:48]
* Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

[0001730168-19-000101:notes:49]
[same as prior period, unchanged from 0001730168-19-000036:notes:189]

[0001730168-19-000101:notes:50]
Contract assets and contract liabilities balances for the periods indicated below were as follows:

[0001730168-19-000101:notes:51]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |

[0001730168-19-000101:notes:52]
* We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

[0001730168-19-000101:notes:53]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $144 million.

[0001730168-19-000101:notes:54]
[same as prior period, unchanged from 0001730168-19-000036:notes:191]

[0001730168-19-000101:notes:55]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

[0001730168-19-000101:notes:56]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 5, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

[0001730168-19-000101:notes:57]
[same as prior period, unchanged from 0001730168-19-000036:notes:194]

[0001730168-19-000101:notes:58]
[same as prior period, unchanged from 0001730168-19-000036:notes:195]

[0001730168-19-000101:notes:59]
When costs are incurred to fulfill a contract that are not within the scope of another accounting literature, we recognize an asset. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

[0001730168-19-000101:notes:60]
Topic 606 Adoption

[0001730168-19-000101:notes:61]
[same as prior period, unchanged from 0001730168-19-000036:notes:199]

[0001730168-19-000101:notes:62]
We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:

[0001730168-19-000101:notes:63]
| Balance Sheet |  | Ending Balance as of November 4, 2018 |  | Adjustments Due to Topic 606 |  | Opening Balance as of November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

[0001730168-19-000101:notes:64]
[same as prior period, unchanged from 0001730168-19-000036:notes:203]

[0001730168-19-000101:notes:65]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and two fiscal quarters ended May 5, 2019 or in the condensed consolidated balance sheet as of May 5, 2019 were significantly affected by the new revenue guidance.

[0001730168-19-000101:notes:66]
|  |  | Fiscal Quarter Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,418 |  |  | $ | — |  |  | $ | 4,418 |  |
| Subscriptions and services |  | 1,040 |  |  | 59 |  |  | 1,099 |  |
| Total net revenue |  | $ | 5,458 |  |  | $ | 59 |  |  | $ | 5,517 |  |

[0001730168-19-000101:notes:67]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 9,057 |  |  | $ | — |  |  | $ | 9,057 |  |
| Subscriptions and services |  | 2,046 |  |  | 203 |  |  | 2,249 |  |
| Total net revenue |  | $ | 11,103 |  |  | $ | 203 |  |  | $ | 11,306 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-19-000101:notes:68]
Acquisitions
Acquisition of CA, Inc.

[0001730168-19-000101:notes:69]
On November 5, 2018, we acquired CA, which was a leading provider of information technology management software and solutions. We acquired CA to enhance our infrastructure software capabilities. We financed the CA Merger with the net proceeds from borrowings under the 2019 Term Loans, as defined in Note 7. “Borrowings,” as well as with cash on hand of the combined companies.

[0001730168-19-000101:notes:70]
[same as prior period, unchanged from 0001730168-19-000036:notes:36]

[0001730168-19-000101:notes:71]
[same as prior period, unchanged from 0001730168-19-000036:notes:37]

[0001730168-19-000101:notes:72]
All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon the completion of the CA Merger. We assumed all unvested CA equity awards held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of CA employees represents a component of the total consideration as presented above and was valued based on our share price as of the CA Acquisition Date.

[0001730168-19-000101:notes:73]
[same as prior period, unchanged from 0001730168-19-000036:notes:39]

[0001730168-19-000101:notes:74]
[same as prior period, unchanged from 0001730168-19-000036:notes:40]

[0001730168-19-000101:notes:75]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,669 |  |
| Goodwill |  | 9,749 |  |
| Intangible assets |  | 12,045 |  |
| Other long-term assets |  | 245 |  |
| Total assets acquired |  | 23,708 |  |
| Other current liabilities |  | (1,966 | ) |
| Long-term debt |  | (2,255 | ) |
| Other long-term liabilities |  | (3,393 | ) |
| Total liabilities assumed |  | (7,614 | ) |
| Fair value of net assets acquired |  | $ | 16,094 |  |

[0001730168-19-000101:notes:76]
[same as prior period, unchanged from 0001730168-19-000036:notes:42]

[0001730168-19-000101:notes:77]
Current assets included assets held-for-sale related to CA’s Veracode business, which was not aligned with our strategic objectives. On December 31, 2018, we sold this business to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Current assets also included $80 million of real properties held-for-sale.

[0001730168-19-000101:notes:78]
Revenue attributable to CA has been included in our infrastructure software segment. Transaction costs related to the CA Merger of $11 million and $73 million, respectively, were included in selling, general and administrative expense for the fiscal quarter and two fiscal quarters ended May 5, 2019.

[0001730168-19-000101:notes:79]
[same as prior period, unchanged from 0001730168-19-000036:notes:45]

[0001730168-19-000101:notes:80]
[same as prior period, unchanged from 0001730168-19-000036:notes:46]

[0001730168-19-000101:notes:81]
[same as prior period, unchanged from 0001730168-19-000036:notes:47]

[0001730168-19-000101:notes:82]
[same as prior period, unchanged from 0001730168-19-000036:notes:48]

[0001730168-19-000101:notes:83]
[same as prior period, unchanged from 0001730168-19-000036:notes:49]

[0001730168-19-000101:notes:84]
[same as prior period, unchanged from 0001730168-19-000036:notes:50]

[0001730168-19-000101:notes:85]
The fair value of in-process research and development (“IPR&D”) was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-19-000101:notes:86]
[same as prior period, unchanged from 0001730168-19-000036:notes:52]

[0001730168-19-000101:notes:87]
The following table summarizes the details of IPR&D by category as of the CA Acquisition Date:

[0001730168-19-000101:notes:88]
[same as prior period, unchanged from 0001730168-19-000036:notes:54]

[0001730168-19-000101:notes:89]
[same as prior period, unchanged from 0001730168-19-000036:notes:55]

[0001730168-19-000101:notes:90]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if CA had been acquired as of the beginning of fiscal year 2018. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the two fiscal quarters ended May 6, 2018, non-recurring pro forma adjustments directly attributable to the CA Merger included acquisition costs of $180 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-19-000101:notes:91]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,289 |  |  | $ | 5,917 |  |  | $ | 10,850 |  |  | $ | 12,083 |  |
| Pro forma net income attributable to common stock |  | $ | 558 |  |  | $ | 3,320 |  |  | $ | 1,353 |  |  | $ | 8,095 |  |

[0001730168-19-000101:notes:92]
* Pro forma net revenue was presented under Topic 606 for fiscal year 2019 periods and under Topic 605 for fiscal year 2018 periods.

[0001730168-19-000101:notes:93]
[same as prior period, unchanged from 0001730168-19-000036:notes:57]

[0001730168-19-000101:notes:94]
On November 17, 2017, we acquired Brocade Communications Systems, Inc. (“Brocade”). Brocade was a supplier of networking hardware, software and services, including Fibre Channel Storage Area Network solutions and Internet Protocol Networking solutions. We acquired Brocade to enhance our position as a provider of enterprise storage connectivity solutions, to broaden our portfolio for enterprise storage, and to increase our ability to address the evolving needs of our original equipment manufacturer (“OEM”) customers.

[0001730168-19-000101:notes:95]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if Brocade had been acquired as of the beginning of our fiscal year ended October 29, 2017 (“fiscal year 2017”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2017 or of the results of our future operations of the combined business.

[0001730168-19-000101:notes:96]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 6, 2018 |  | May 6, 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 5,017 |  |  | $ | 10,464 |  |
| Pro forma net income attributable to common stock |  | $ | 3,744 |  |  | $ | 10,077 |  |

[0001730168-19-000101:notes:97]
* Pro forma net revenue was presented under Topic 605 for fiscal year 2018 periods.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-19-000101:notes:98]
Supplemental Financial Information
Cash Equivalents

[0001730168-19-000101:notes:99]
Cash equivalents included $739 million and $1,406 million of time deposits as of May 5, 2019 and November 4, 2018, respectively. As of May 5, 2019 and November 4, 2018, cash equivalents also included $768 million and $202 million of money-market funds, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-19-000101:notes:100]
Accounts Receivable Factoring

[0001730168-19-000101:notes:101]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring agreements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring agreements were $90 million during both the fiscal quarter and two fiscal quarters ended May 5, 2019, and $57 million during both the fiscal quarter and two fiscal quarters ended May 6, 2018. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any period presented.

[0001730168-19-000101:notes:102]
[same as prior period, unchanged from 0001730168-19-000036:notes:13]

[0001730168-19-000101:notes:103]
|  |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Finished goods |  | $ | 369 |  |  | $ | 483 |  |
| Work-in-process |  | 538 |  |  | 505 |  |
| Raw materials |  | 127 |  |  | 136 |  |
| Total inventory |  | $ | 1,034 |  |  | $ | 1,124 |  |

[0001730168-19-000101:notes:104]
[same as prior period, unchanged from 0001730168-19-000036:notes:15]

[0001730168-19-000101:notes:105]
|  |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 395 |  |  | $ | 243 |  |
| Other (miscellaneous) |  | 436 |  |  | 123 |  |
| Total other current assets |  | $ | 831 |  |  | $ | 366 |  |

[0001730168-19-000101:notes:106]
[same as prior period, unchanged from 0001730168-19-000036:notes:17]

[0001730168-19-000101:notes:107]
|  |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 2,028 |  |  | $ | 164 |  |
| Notional pooling liabilities |  | 596 |  |  | — |  |
| Tax liabilities |  | 290 |  |  | 162 |  |
| Other (miscellaneous) |  | 815 |  |  | 486 |  |
| Total other current liabilities |  | $ | 3,729 |  |  | $ | 812 |  |

[0001730168-19-000101:notes:108]
[same as prior period, unchanged from 0001730168-19-000036:notes:19]

[0001730168-19-000101:notes:109]
[same as prior period, unchanged from 0001730168-19-000036:notes:20]

[0001730168-19-000101:notes:110]
|  |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Unrecognized tax benefits (a) (b) |  | $ | 3,356 |  |  | $ | 3,088 |  |
| Deferred tax liabilities (a) |  | 1,871 |  |  | 169 |  |
| Contract liabilities |  | 442 |  |  | 66 |  |
| Other (miscellaneous) |  | 561 |  |  | 313 |  |
| Total other long-term liabilities |  | $ | 6,230 |  |  | $ | 3,636 |  |

[0001730168-19-000101:notes:111]
[same as prior period, unchanged from 0001730168-19-000036:notes:23]

[0001730168-19-000101:notes:112]
[same as prior period, unchanged from 0001730168-19-000036:notes:24]

[0001730168-19-000101:notes:113]
[same as prior period, unchanged from 0001730168-19-000036:notes:25]

[0001730168-19-000101:notes:114]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 189 |  |  | $ | 1 |  |  | $ | 612 |  |  | $ | 233 |  |
| Cash paid for income taxes |  | $ | 425 |  |  | $ | 87 |  |  | $ | 520 |  |  | $ | 196 |  |

[0001730168-19-000101:notes:115]
As of May 5, 2019 and November 4, 2018, we had $35 million and $22 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-19-000101:notes:116]
Goodwill and Intangible Assets
Goodwill

[0001730168-19-000101:notes:117]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 17,705 |  |  | $ | 5,945 |  |  | $ | 3,112 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26,913 |  |
| Reallocation due to change in segments |  | (17,705 | ) |  | (5,945 | ) |  | (3,112 | ) |  | (151 | ) |  | 25,924 |  |  | 980 |  |  | 9 |  |  | — |  |
| CA Merger |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9,749 |  |  | — |  |  | 9,749 |  |
| Balance as of May 5, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25,924 |  |  | $ | 10,729 |  |  | $ | 9 |  |  | $ | 36,662 |  |

[0001730168-19-000101:notes:118]
[same as prior period, unchanged from 0001730168-19-000036:notes:115]

[0001730168-19-000101:notes:119]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of May 5, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,846 |  |  | $ | (8,465 | ) |  | $ | 12,381 |  |
| Customer contracts and related relationships |  | 5,982 |  |  | (1,335 | ) |  | 4,647 |  |
| Order backlog |  | 2,569 |  |  | (454 | ) |  | 2,115 |  |
| Trade names |  | 712 |  |  | (208 | ) |  | 504 |  |
| Other |  | 243 |  |  | (72 | ) |  | 171 |  |
| Intangible assets subject to amortization |  | 30,352 |  |  | (10,534 | ) |  | 19,818 |  |
| IPR&D |  | 370 |  |  | — |  |  | 370 |  |
| Total |  | $ | 30,722 |  |  | $ | (10,534 | ) |  | $ | 20,188 |  |
| As of November 4, 2018: |  |  |  |  |  |  |
| Purchased technology |  | $ | 15,806 |  |  | $ | (6,816 | ) |  | $ | 8,990 |  |
| Customer contracts and related relationships |  | 1,792 |  |  | (878 | ) |  | 914 |  |
| Trade names |  | 578 |  |  | (170 | ) |  | 408 |  |
| Other |  | 239 |  |  | (53 | ) |  | 186 |  |
| Intangible assets subject to amortization |  | 18,415 |  |  | (7,917 | ) |  | 10,498 |  |
| IPR&D |  | 264 |  |  | — |  |  | 264 |  |
| Total |  | $ | 18,679 |  |  | $ | (7,917 | ) |  | $ | 10,762 |  |

[0001730168-19-000101:notes:120]
Based on the amount of intangible assets subject to amortization at May 5, 2019, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-19-000101:notes:121]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 2,618 |  |
| 2020 |  | 5,039 |  |
| 2021 |  | 4,135 |  |
| 2022 |  | 3,165 |  |
| 2023 |  | 2,160 |  |
| Thereafter |  | 2,701 |  |
| Total |  | $ | 19,818 |  |

[0001730168-19-000101:notes:122]
[same as prior period, unchanged from 0001730168-19-000036:notes:118]

[0001730168-19-000101:notes:123]
| Amortizable intangible assets: |  | May 5, 2019 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 5 |
| Order backlog |  | 3 |
| Trade names |  | 10 |
| Other |  | 10 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-19-000101:notes:124]
Net Income Per Share
Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-19-000101:notes:125]
Diluted shares outstanding include the dilutive effect of in-the-money stock options, unvested restricted stock units (“RSUs”), and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), collectively referred to as “equity awards”. Diluted shares outstanding also included shares issuable upon the exchange of LP Units for the fiscal year 2018 periods presented prior to the effective time of Mandatory Exchange.

[0001730168-19-000101:notes:126]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0001730168-19-000101:notes:127]
The dilutive effect of LP Units was calculated using the if-converted method. The if-converted method assumed that the LP Units were converted at the beginning of the reporting period and included net income attributable to noncontrolling interest for the fiscal year 2018 periods presented.

[0001730168-19-000101:notes:128]
[same as prior period, unchanged from 0001730168-19-000036:notes:109]

[0001730168-19-000101:notes:129]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions, except per share data) |
| Numerator - Basic: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 693 |  |  | $ | 3,736 |  |  | $ | 1,174 |  |  | $ | 10,317 |  |
| Less: Income from continuing operations attributable to noncontrolling interest |  | — |  |  | 15 |  |  | — |  |  | 352 |  |
| Income from continuing operations attributable to common stock |  | 693 |  |  | 3,721 |  |  | 1,174 |  |  | 9,965 |  |
| Loss from discontinued operations, net of income taxes |  | (2 | ) |  | (3 | ) |  | (12 | ) |  | (18 | ) |
| Less: Loss from discontinued operations, net of income taxes, attributable to noncontrolling interest |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (2 | ) |  | (3 | ) |  | (12 | ) |  | (17 | ) |
| Net income attributable to common stock |  | $ | 691 |  |  | $ | 3,718 |  |  | $ | 1,162 |  |  | $ | 9,948 |  |
| Numerator - Diluted: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 693 |  |  | $ | 3,736 |  |  | $ | 1,174 |  |  | $ | 10,317 |  |
| Loss from discontinued operations, net of income taxes |  | (2 | ) |  | (3 | ) |  | (12 | ) |  | (18 | ) |
| Net income |  | $ | 691 |  |  | $ | 3,733 |  |  | $ | 1,162 |  |  | $ | 10,299 |  |

[0001730168-19-000101:notes:130]
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 397 |  |  | 421 |  |  | 399 |  |  | 415 |  |
| Dilutive effect of equity awards |  | 25 |  |  | 13 |  |  | 21 |  |  | 15 |  |
| Exchange of noncontrolling interest |  | — |  |  | 14 |  |  | — |  |  | 18 |  |
| Weighted-average shares outstanding - diluted |  | 422 |  |  | 448 |  |  | 420 |  |  | 448 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.75 |  |  | $ | 8.84 |  |  | $ | 2.94 |  |  | $ | 24.01 |  |
| Loss per share from discontinued operations |  | (0.01 | ) |  | (0.01 | ) |  | (0.03 | ) |  | (0.04 | ) |
| Net income per share |  | $ | 1.74 |  |  | $ | 8.83 |  |  | $ | 2.91 |  |  | $ | 23.97 |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.64 |  |  | $ | 8.34 |  |  | $ | 2.80 |  |  | $ | 23.03 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01 | ) |  | (0.03 | ) |  | (0.04 | ) |
| Net income per share |  | $ | 1.64 |  |  | $ | 8.33 |  |  | $ | 2.77 |  |  | $ | 22.99 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-19-000101:notes:131]
Borrowings

[0001730168-19-000101:notes:132]
|  |  | Effective Interest Rate |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through November 2023 |  | 3.852 | % |  | 6,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 0.289 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (311 | ) |  | (116 | ) |
| Total Debt |  |  |  | $ | 37,548 |  |  | $ | 17,493 |  |

[0001730168-19-000101:notes:133]
(a) Represents the weighted average interest rate on outstanding commercial paper as of May 5, 2019.

[0001730168-19-000101:notes:134]
Fiscal Year 2019 Financing Arrangements

[0001730168-19-000101:notes:135]
In connection with the CA Merger, we entered into a credit agreement (the “2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “2019 Term Loans”. Interest on our 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the 2019 Credit Agreement were guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”), Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee having been provided by Broadcom-Singapore  pending its voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019).

[0001730168-19-000101:notes:136]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we were permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on May 5, 2019.

[0001730168-19-000101:notes:137]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and Broadcom Technologies Inc. Each series of our 2019 Senior Notes pay interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase.

[0001730168-19-000101:notes:138]
In February 2019, we also established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available for general corporate purposes under the Revolving Facility. As of May 5, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they were supported by the Revolving Facility. These borrowings are now supported by our new revolving credit facility discussed below. As such, we have recorded Commercial Paper, net of discount, as long-term debt.

[0001730168-19-000101:notes:139]
We used the net proceeds from the 2019 Senior Notes and Commercial Paper to repay $12 billion of our 2019 Term Loans, including all of our term A-3 facility. As a result of our repayment of the 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense on the condensed consolidated statements of operations. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes and Commercial Paper is amortized to interest expense over the respective terms of these borrowings. The unamortized discount and debt issuance costs balance on the 2019 Term Loans as of the modification date will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

[0001730168-19-000101:notes:140]
On May 7, 2019, we entered into a new credit agreement, which provides for a $5 billion unsecured revolving credit facility, a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility. This new credit agreement has substantially the same terms and conditions as the 2019 Credit Agreement, other than with respect to the maturity date of the facilities. The proceeds of the term A-3, A-5 and A-7 facilities were used to refinance the $6 billion of existing term loans outstanding under the 2019 Credit Agreement, which was terminated in connection with, and as a condition to, entering into the May 7, 2019 credit agreement. Our obligations under this new credit agreement are guaranteed on an unsecured basis by BRCM and Broadcom Technologies Inc.

[0001730168-19-000101:notes:141]
2017 Senior Notes

[0001730168-19-000101:notes:142]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the “Subsidiary Issuers,” issued $17,550 million of senior unsecured notes (the “2017 Senior Notes”). The 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom (“Parent Guarantor”) and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc. (“Subsidiary Guarantor”), a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes

[0001730168-19-000101:notes:143]
under each of their respective indentures in accordance with their terms. On May 15, 2019, Broadcom Cayman Finance Limited was merged into the Subsidiary Guarantor, with the Subsidiary Guarantor as the surviving entity.

[0001730168-19-000101:notes:144]
Assumed CA Senior Notes

[0001730168-19-000101:notes:145]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

[0001730168-19-000101:notes:146]
Fair Value of Debt

[0001730168-19-000101:notes:147]
As of May 5, 2019, the estimated aggregate fair value of debt was $37,331 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our term A-5 facility approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-19-000101:notes:148]
Future Principal Payments of Debt

[0001730168-19-000101:notes:149]
The future scheduled principal payments of debt as of May 5, 2019 were as follows:

[0001730168-19-000101:notes:150]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 1,000 |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 3,650 |  |
| 2022 |  | 6,409 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 20,713 |  |
| Total |  | $ | 37,859 |  |

[0001730168-19-000101:notes:151]
As of May 5, 2019 and November 4, 2018, we accrued interest payable of $244 million and $165 million, respectively and were in compliance with all debt covenants.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001730168-19-000101:notes:152]
Stockholders’ Equity
Redomiciliation Transaction

[0001730168-19-000101:notes:153]
For the period prior to the Redomiciliation Transaction, our stockholders’ equity reflected Broadcom-Singapore’s outstanding ordinary shares. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom common stock and Broadcom-Singapore became a wholly-owned subsidiary of Broadcom.

[0001730168-19-000101:notes:154]
In conjunction with the Redomiciliation Transaction and pursuant to the Mandatory Exchange, all outstanding LP Units held by the limited partners were mandatorily exchanged for approximately 22 million newly issued shares of Broadcom common stock on a one-for-one basis. As a result, all limited partners of the Partnership became common stockholders of Broadcom. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange.

[0001730168-19-000101:notes:155]
[same as prior period, unchanged from 0001730168-19-000036:notes:230]

[0001730168-19-000101:notes:156]
Immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income attributable to our common stock in our condensed consolidated statements of operations excluded the noncontrolling interest’s proportionate share of the results for the fiscal quarter and two fiscal quarters ended May 6, 2018. In addition, we presented the proportionate share of equity attributable to the noncontrolling interest as a separate component of total equity within our condensed consolidated statements of equity for the periods prior to the Redomiciliation Transaction.

[0001730168-19-000101:notes:157]
[same as prior period, unchanged from 0001730168-19-000036:notes:232]

[0001730168-19-000101:notes:158]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 2.65 |  |  | $ | 1.75 |  |  | $ | 5.30 |  |  | $ | 3.50 |  |
| Cash dividends paid to stockholders |  | $ | 1,057 |  |  | $ | 727 |  |  | $ | 2,124 |  |  | $ | 1,444 |  |
| Cash distributions paid to limited partners |  | $ | — |  |  | $ | 39 |  |  | $ | — |  |  | $ | 77 |  |

[0001730168-19-000101:notes:159]
[same as prior period, unchanged from 0001730168-19-000036:notes:233]

[0001730168-19-000101:notes:160]
In December 2018, our Board of Directors increased our previously authorized $12 billion stock repurchase program to a total of $18 billion. This authorization covers repurchases through November 3, 2019, the end of our fiscal year 2019. During the fiscal quarter and two fiscal quarters ended May 5, 2019, we repurchased and retired approximately 3 million and 17 million shares of our common stock for $830 million and $4,266 million, respectively, under this stock repurchase program. During both the fiscal quarter and two fiscal quarters ended May 6, 2018, we repurchased and retired approximately 2 million shares of our common stock for $347 million under this stock repurchase program. As of May 5, 2019, $6,476 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000101:notes:161]
[same as prior period, unchanged from 0001730168-19-000036:notes:235]

[0001730168-19-000101:notes:162]
[same as prior period, unchanged from 0001730168-19-000036:notes:236]

[0001730168-19-000101:notes:163]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 29 |  |  | $ | 19 |  |  | $ | 55 |  |  | $ | 37 |  |
| Cost of subscriptions and services |  | 12 |  |  | 2 |  |  | 20 |  |  | 4 |  |
| Research and development |  | 371 |  |  | 205 |  |  | 682 |  |  | 408 |  |
| Selling, general and administrative |  | 132 |  |  | 70 |  |  | 252 |  |  | 146 |  |
| Total stock-based compensation expense |  | $ | 544 |  |  | $ | 296 |  |  | $ | 1,009 |  |  | $ | 595 |  |

[0001730168-19-000101:notes:164]
During the fiscal quarter ended February 3, 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $218 million and $325 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, including $32 million and $49 million of Multi-Year Equity Awards granted to employees acquired in the CA Merger, respectively.

[0001730168-19-000101:notes:165]
For the fiscal quarter and two fiscal quarters ended May 5, 2019, stock-based compensation expense included $23 million and $60 million, respectively, related to equity awards assumed in connection with the CA Merger. In addition to stock-based compensation expense presented above, for the two fiscal quarters ended May 5, 2019, we recognized $75 million in restructuring charges for accelerated vesting of assumed equity awards held by employees terminated in connection with the CA Merger.

[0001730168-19-000101:notes:166]
As of May 5, 2019, the total unrecognized compensation cost related to unvested stock-based awards was $6,238 million, which is expected to be recognized over the remaining weighted-average service period of 4.4 years.

[0001730168-19-000101:notes:167]
[same as prior period, unchanged from 0001730168-19-000036:notes:240]

[0001730168-19-000101:notes:168]
A summary of time- and market-based RSU activity is as follows:

[0001730168-19-000101:notes:169]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |
|  |  | (In millions, except per share data) |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |
| Assumed in CA Merger |  | 1 |  |  | $ | 206.14 |  |
| Granted |  | 32 |  |  | $ | 177.72 |  |
| Vested |  | (6 | ) |  | $ | 188.30 |  |
| Forfeited |  | (1 | ) |  | $ | 175.01 |  |
| Balance as of May 5, 2019 |  | 44 |  |  | $ | 184.63 |  |

[0001730168-19-000101:notes:170]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended May 5, 2019 was $1,794 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-19-000101:notes:171]
A summary of time- and market-based stock option activity is as follows:

[0001730168-19-000101:notes:172]
|  |  | Number of OptionsOutstanding |  |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of November 4, 2018 |  | 8 |  |  |  | $ | 50.14 |  |  |  |  |  |
| Exercised |  | (3 | ) |  |  | $ | 48.45 |  |  |  |  | $ | 642 |  |
| Cancelled |  | — |  | * |  | $ | 44.84 |  |  |  |  |  |
| Balance as of May 5, 2019 |  | 5 |  |  |  | $ | 51.11 |  |  | 1.59 |  | $ | 1,296 |  |
| Fully vested as of May 5, 2019 |  | 5 |  |  |  | $ | 51.11 |  |  | 1.59 |  | $ | 1,296 |  |

[0001730168-19-000101:notes:173]
* Represents fewer than 0.5 million shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-19-000101:notes:174]
Income Taxes
For the fiscal quarter and two fiscal quarters ended May 5, 2019, our benefit from income taxes was $36 million and $239 million, respectively, compared to $2,637 million and $8,423 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively.

[0001730168-19-000101:notes:175]
The benefit for the fiscal quarter ended May 5, 2019 was primarily due to $137 million of excess tax benefits from stock-based awards that vested or were exercised during the period, partially offset by $113 million of expense from a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”).

[0001730168-19-000101:notes:176]
The benefit from income taxes for the corresponding 2018 fiscal quarter included the impact of the Redomiciliation Transaction and related internal reorganizations. This impact included tax benefits from the reduction of $1,063 million in unrecognized federal tax benefits related to a one-time transition tax (the “Transition Tax”), $431 million in the Transition Tax payable and $1,162 million from the remeasurement of withholding taxes on undistributed earnings, partially offset by a $91 million tax provision on foreign earnings and profits subject to U.S. tax.

[0001730168-19-000101:notes:177]
The benefit for the two fiscal quarters ended May 5, 2019 was primarily due to $172 million of excess tax benefits from stock-based awards that vested or were exercised during the period, the recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, and the partial release of $54 million of our valuation allowance as a result of the CA Merger, partially offset by $113 million of expense from a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the 2017 Tax Reform Act.

[0001730168-19-000101:notes:178]
On December 22, 2017, the SEC issued Staff Accounting Bulletin No. 118. This guidance allowed registrants a “measurement period,” not to exceed one year from the date of enactment, to complete their accounting for the tax effects of the 2017 Tax Reform Act. We relied on this guidance to refine our estimates of the impact of the 2017 Tax Reform Act during the measurement period. The measurement period ended during our fiscal quarter ended February 3, 2019, and no adjustments were recorded. As a result, we consider our accounting for the tax effects of the 2017 Tax Reform Act to be complete based on our interpretation of the law and subsequently issued guidance. However, it is expected that the U.S. Treasury will continue to issue regulations and other guidance on the application of certain provisions of the 2017 Tax Reform Act that may impact our interpretation of the rules and our calculation of the tax impact of the Transition Tax or other provisions of the 2017 Tax Reform Act. We recorded income tax expense of $113 million during the fiscal quarter ended May 5, 2019 as a result of the issuance of such regulations during the period.

[0001730168-19-000101:notes:179]
The two fiscal quarters ended May 5, 2019 also included the impact of several provisions of the 2017 Tax Reform Act that take effect for us for the first time in fiscal year 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000101:notes:180]
In connection with CA Merger in November 2018, we established $2,369 million of net deferred tax liabilities on the excess of the book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that had not been indefinitely reinvested, partially offset by acquired tax attributes. The net deferred tax liabilities are based upon certain assumptions underlying our preliminary purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes may be required, provided we are within the measurement period.

[0001730168-19-000101:notes:181]
The benefit from income taxes for the corresponding 2018 fiscal period was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017.

[0001730168-19-000101:notes:182]
As a result of the 2017 Tax Reform Act, we recorded a total provisional benefit of $7,303 million during the two fiscal quarters ended May 6, 2018. This provisional benefit included $91 million related to the remeasurement of certain deferred tax assets and liabilities, which was based on the tax rates at which they were expected to be reversed in the future. The provisional benefit also included $7,212 million related to the Transition Tax, which was primarily due to a reduction of $10,392 million in our federal deferred income tax liabilities on accumulated non-U.S. earnings, partially offset by $2,116 million of federal provisional long-term Transition Tax payable and $1,116 million of unrecognized federal tax benefits related to the Transition Tax.

[0001730168-19-000101:notes:183]
We also recognized an income tax benefit for $127 million and $155 million of excess tax benefits from stock-based awards that vested or were exercised during the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively.

[0001730168-19-000101:notes:184]
[same as prior period, unchanged from 0001730168-19-000036:notes:127]

[0001730168-19-000101:notes:185]
The balance of gross unrecognized tax benefits was $4,107 million and $4,030 million as of May 5, 2019 and November 4, 2018, respectively. This increase was primarily due to the recognition of uncertain tax positions related to the CA Merger, which were initially estimated as of the CA Acquisition Date, offset by audit settlements and lapses of statutes of limitations. We continue to reevaluate these items with any adjustments to our preliminary estimates recognized, provided we are within the measurement period and we continue to collect information in order to determine their estimated values.

[0001730168-19-000101:notes:186]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of May 5, 2019 and November 4, 2018, the combined amount of cumulative accrued interest and penalties was approximately $307 million and $190 million, respectively.

[0001730168-19-000101:notes:187]
As of May 5, 2019 and November 4, 2018, approximately $4,414 million and $4,220 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-19-000101:notes:188]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $123 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-19-000101:notes:189]
Segment Information
Reportable Segments

[0001730168-19-000101:notes:190]
As a result of the CA Merger, which closed on November 5, 2018, we updated our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. Each segment represents components for which separate financial information is available that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-19-000101:notes:191]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, telecom, enterprise and embedded networking applications. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions and custom touch controllers for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets.

[0001730168-19-000101:notes:192]
[same as prior period, unchanged from 0001730168-19-000036:notes:217]

[0001730168-19-000101:notes:193]
IP licensing. We license a portion of our broad IP portfolio.

[0001730168-19-000101:notes:194]
[same as prior period, unchanged from 0001730168-19-000036:notes:219]

[0001730168-19-000101:notes:195]
[same as prior period, unchanged from 0001730168-19-000036:notes:220]

[0001730168-19-000101:notes:196]
[same as prior period, unchanged from 0001730168-19-000036:notes:221]

[0001730168-19-000101:notes:197]
[same as prior period, unchanged from 0001730168-19-000036:notes:222]

[0001730168-19-000101:notes:198]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,088 |  |  | $ | 4,537 |  |  | $ | 8,462 |  |  | $ | 9,492 |  |
| Infrastructure software |  | 1,413 |  |  | 447 |  |  | 2,816 |  |  | 775 |  |
| IP licensing |  | 16 |  |  | 30 |  |  | 28 |  |  | 74 |  |
| Total net revenue |  | $ | 5,517 |  |  | $ | 5,014 |  |  | $ | 11,306 |  |  | $ | 10,341 |  |
| Operating income (loss): |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 1,900 |  |  | $ | 2,127 |  |  | $ | 3,937 |  |  | $ | 4,452 |  |
| Infrastructure software |  | 1,050 |  |  | 310 |  |  | 2,070 |  |  | 526 |  |
| IP licensing |  | (1 | ) |  | 15 |  |  | (6 | ) |  | 41 |  |
| Unallocated expenses |  | (1,979 | ) |  | (1,251 | ) |  | (4,476 | ) |  | (2,875 | ) |
| Total operating income |  | $ | 970 |  |  | $ | 1,201 |  |  | $ | 1,525 |  |  | $ | 2,144 |  |

[0001730168-19-000101:notes:199]
[same as prior period, unchanged from 0001730168-19-000036:notes:223]

[0001730168-19-000101:notes:200]
We sell our products through our direct sales force and a select network of distributors globally. Two customers accounted for 15% and 12% of our net accounts receivable balance at May 5, 2019, and 20% and 14% of our net accounts receivable balance at November 4, 2018.

[0001730168-19-000101:notes:201]
One customer accounted for 14% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 5, 2019. Net revenue from this customer was included in our semiconductor solutions segment. A second customer accounted for 11% and 10% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Net revenue from this customer was primarily included in our infrastructure software segment.

[0001730168-19-000101:notes:202]
No customer accounted for 10% or more of our net revenue for the fiscal quarter ended May 6, 2018. During the two fiscal quarters ended May 6, 2018, one customer accounted for 12% of our net revenue. The majority of the revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-19-000101:notes:203]
Commitments and Contingencies
Commitments

[0001730168-19-000101:notes:204]
The following table summarizes contractual obligations and commitments as of May 5, 2019 that materially changed from the end of fiscal year 2018:

[0001730168-19-000101:notes:205]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2019 (remainder) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 44,996 |  |  | $ | 1,677 |  |  | $ | 5,214 |  |  | $ | 4,792 |  |  | $ | 7,441 |  |  | $ | 3,036 |  |  | $ | 22,836 |  |
| Purchase commitments |  | 877 |  |  | 780 |  |  | 64 |  |  | 33 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 222 |  |  | 97 |  |  | 92 |  |  | 21 |  |  | 7 |  |  | 5 |  |  | — |  |
| Operating lease obligations |  | 806 |  |  | 62 |  |  | 108 |  |  | 90 |  |  | 60 |  |  | 52 |  |  | 434 |  |
| Total |  | $ | 46,901 |  |  | $ | 2,616 |  |  | $ | 5,478 |  |  | $ | 4,936 |  |  | $ | 7,508 |  |  | $ | 3,093 |  |  | $ | 23,270 |  |

[0001730168-19-000101:notes:206]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on borrowings under the 2019 Senior Notes, Commercial Paper, term A-5 facility, Revolving Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our term A-5 facility, which was subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 5, 2019.

[0001730168-19-000101:notes:207]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including

[0001730168-19-000101:notes:208]
fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

[0001730168-19-000101:notes:209]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-19-000101:notes:210]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $59 million and $126 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Rent expense was $56 million and $127 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively.

[0001730168-19-000101:notes:211]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 5, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 5, 2019 have been excluded from the contractual obligations table above.

[0001730168-19-000101:notes:212]
Standby Letters of Credit

[0001730168-19-000101:notes:213]
As of May 5, 2019 and November 4, 2018, we had standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-19-000101:notes:214]
Contingencies

[0001730168-19-000101:notes:215]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-19-000101:notes:216]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-19-000101:notes:217]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth

[0001730168-19-000101:notes:218]
Circuit Court remanded the case back to the U.S. Central District Court. We believe these claims are all without merit and intend to vigorously defend these actions.

[0001730168-19-000101:notes:219]
Other Matters

[0001730168-19-000101:notes:220]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-19-000101:notes:221]
Contingency Assessment

[0001730168-19-000101:notes:222]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-19-000101:notes:223]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-19-000101:notes:224]
Other Indemnifications

[0001730168-19-000101:notes:225]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001730168-19-000101:notes:226]
Restructuring, Impairment and Disposal Charges
Restructuring Charges

[0001730168-19-000101:notes:227]
[same as prior period, unchanged from 0001730168-19-000036:notes:153]

[0001730168-19-000101:notes:228]
| • | During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $81 million and $675 million of restructuring expense primarily related to employee termination and lease and other exit costs during the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. |

[0001730168-19-000101:notes:229]
| • | During the first quarter of fiscal year 2018, we initiated cost reduction activities associated with the acquisition of Brocade. As a result, we recognized $2 million of restructuring expense during the two fiscal quarters ended May 5, 2019 and $35 million and $143 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively, primarily related to employee termination costs. |

[0001730168-19-000101:notes:230]
| • | We initiated cost reduction activities associated with the acquisition of BRCM and recognized $3 million of restructuring expense during the two fiscal quarters ended May 5, 2019 and $14 million and $45 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. These restructuring expenses primarily related to employee termination costs for the two fiscal quarters ended May 5, 2019 and lease and other exit costs for the fiscal quarter and two fiscal quarters ended May 6, 2018. We have substantially completed the restructuring activities related to the acquisition of BRCM. |

[0001730168-19-000101:notes:231]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 16 |  |  | $ | 6 |  |  | $ | 22 |  |
| Liabilities assumed from CA |  | 29 |  |  | 38 |  |  | 67 |  |
| Restructuring charges |  | 546 |  |  | 134 |  |  | 680 |  |
| Utilization |  | (418 | ) |  | (101 | ) |  | (519 | ) |
| Balance as of May 5, 2019 (a) |  | $ | 173 |  |  | $ | 77 |  |  | $ | 250 |  |

[0001730168-19-000101:notes:232]
[same as prior period, unchanged from 0001730168-19-000036:notes:158]

[0001730168-19-000101:notes:233]
(a) The majority of the employee termination costs balance is expected to be paid in fiscal year 2019. The majority of the leases and other exit costs balance is expected to be paid through fiscal year 2023.

[0001730168-19-000101:notes:234]
Impairment and Disposal Charges
During the fiscal quarter and two fiscal quarters ended May 5, 2019, we incurred impairment and disposal charges of $5 million and $35 million, respectively. During the fiscal quarter and two fiscal quarters ended May 6, 2018, we incurred impairment and disposal charges of $6 million and $12 million, respectively. These charges were primarily related to impairment of property, plant and equipment.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001730168-19-000101:notes:235]
Condensed Consolidating Financial Information
The following information sets forth the condensed consolidating financial information for the Parent Guarantor, the Subsidiary Guarantor, the Subsidiary Issuers, and our other subsidiaries (collectively, the “Non-Guarantor Subsidiaries”) for the periods presented in these condensed consolidated financial statements. Investments in subsidiaries are accounted for under the equity method; accordingly, entries necessary to consolidate the Parent Guarantor, the Subsidiary Guarantor, the Subsidiary Issuers and the Non-Guarantor Subsidiaries are reflected in the eliminations column. In the opinion of management, separate complete financial statements of the Subsidiary Issuers would not provide additional material information that would be useful in assessing their financial composition.

[0001730168-19-000101:notes:236]
[same as prior period, unchanged from 0001730168-19-000036:notes:84]

[0001730168-19-000101:notes:237]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | May 5, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 301 |  |  | $ | — |  |  | $ | 890 |  |  | $ | 4,137 |  |  | $ | — |  |  | $ | 5,328 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 3,484 |  |  | — |  |  | 3,484 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,034 |  |  | — |  |  | 1,034 |  |
| Intercompany receivable |  | 457 |  |  | — |  |  | 761 |  |  | 297 |  |  | (1,515 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | — |  |  | 10,088 |  |  | 8,289 |  |  | (18,377 | ) |  | — |  |
| Other current assets |  | 131 |  |  | — |  |  | 59 |  |  | 641 |  |  | — |  |  | 831 |  |
| Total current assets |  | 889 |  |  | — |  |  | 11,798 |  |  | 17,882 |  |  | (19,892 | ) |  | 10,677 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 768 |  |  | 1,886 |  |  | — |  |  | 2,654 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 35,302 |  |  | — |  |  | 36,662 |  |
| Intangible assets, net |  | — |  |  | — |  |  | 81 |  |  | 20,107 |  |  | — |  |  | 20,188 |  |
| Investment in subsidiaries |  | 51,867 |  |  | 34,273 |  |  | 45,921 |  |  | — |  |  | (132,061 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | — |  |  | 925 |  |  | (925 | ) |  | — |  |
| Other long-term assets |  | 29 |  |  | — |  |  | 58 |  |  | 648 |  |  | — |  |  | 735 |  |
| Total assets |  | $ | 52,785 |  |  | $ | 34,273 |  |  | $ | 59,986 |  |  | $ | 76,750 |  |  | $ | (152,878 | ) |  | $ | 70,916 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 27 |  |  | $ | — |  |  | $ | 48 |  |  | $ | 684 |  |  | $ | — |  |  | $ | 759 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 103 |  |  | 375 |  |  | — |  |  | 478 |  |
| Current portion of long-term debt |  | — |  |  | — |  |  | 2,750 |  |  | 787 |  |  | — |  |  | 3,537 |  |
| Intercompany payable |  | 296 |  |  | — |  |  | 97 |  |  | 1,122 |  |  | (1,515 | ) |  | — |  |
| Intercompany loan payable |  | 12,513 |  |  | — |  |  | 4,710 |  |  | 1,154 |  |  | (18,377 | ) |  | — |  |
| Other current liabilities |  | 51 |  |  | — |  |  | 177 |  |  | 3,501 |  |  | — |  |  | 3,729 |  |
| Total current liabilities |  | 12,887 |  |  | — |  |  | 7,885 |  |  | 7,623 |  |  | (19,892 | ) |  | 8,503 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | 17,793 |  |  | — |  |  | 14,718 |  |  | 1,500 |  |  | — |  |  | 34,011 |  |
| Deferred tax liabilities |  | — |  |  | 12 |  |  | (348 | ) |  | 2,207 |  |  | — |  |  | 1,871 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | 925 |  |  | — |  |  | (925 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 2,314 |  |  | 1,042 |  |  | — |  |  | 3,356 |  |
| Other long-term liabilities |  | (67 | ) |  | 53 |  |  | 218 |  |  | 799 |  |  | — |  |  | 1,003 |  |
| Total liabilities |  | 30,613 |  |  | 65 |  |  | 25,712 |  |  | 13,171 |  |  | (20,817 | ) |  | 48,744 |  |
| Total stockholders’ equity |  | 22,172 |  |  | 34,208 |  |  | 34,274 |  |  | 63,579 |  |  | (132,061 | ) |  | 22,172 |  |
| Total liabilities and stockholders’ equity |  | $ | 52,785 |  |  | $ | 34,273 |  |  | $ | 59,986 |  |  | $ | 76,750 |  |  | $ | (152,878 | ) |  | $ | 70,916 |  |

[0001730168-19-000101:notes:238]
|  |  | Condensed Consolidating Balance Sheet |
|  |  | November 4, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | — |  |  | $ | — |  |  | $ | 2,461 |  |  | $ | 1,831 |  |  | $ | — |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  | — |  |  | — |  |  | — |  |  | 3,325 |  |  | — |  |  | 3,325 |  |
| Inventory |  | — |  |  | — |  |  | — |  |  | 1,124 |  |  | — |  |  | 1,124 |  |
| Intercompany receivable |  | 56 |  |  | — |  |  | 182 |  |  | 67 |  |  | (305 | ) |  | — |  |
| Intercompany loan receivable |  | — |  |  | — |  |  | 9,780 |  |  | 4,713 |  |  | (14,493 | ) |  | — |  |
| Other current assets |  | 52 |  |  | — |  |  | 37 |  |  | 277 |  |  | — |  |  | 366 |  |
| Total current assets |  | 108 |  |  | — |  |  | 12,460 |  |  | 11,337 |  |  | (14,798 | ) |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | — |  |  | — |  |  | 772 |  |  | 1,863 |  |  | — |  |  | 2,635 |  |
| Goodwill |  | — |  |  | — |  |  | 1,360 |  |  | 25,553 |  |  | — |  |  | 26,913 |  |
| Intangible assets, net |  | — |  |  | — |  |  | 84 |  |  | 10,678 |  |  | — |  |  | 10,762 |  |
| Investment in subsidiaries |  | 35,268 |  |  | 35,268 |  |  | 46,745 |  |  | — |  |  | (117,281 | ) |  | — |  |
| Intercompany loan receivable, long-term |  | — |  |  | — |  |  | — |  |  | 991 |  |  | (991 | ) |  | — |  |
| Other long-term assets |  | — |  |  | — |  |  | 250 |  |  | 457 |  |  | — |  |  | 707 |  |
| Total assets |  | $ | 35,376 |  |  | $ | 35,268 |  |  | $ | 61,671 |  |  | $ | 50,879 |  |  | $ | (133,070 | ) |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 19 |  |  | $ | — |  |  | $ | 44 |  |  | $ | 748 |  |  | $ | — |  |  | $ | 811 |  |
| Employee compensation and benefits |  | — |  |  | — |  |  | 272 |  |  | 443 |  |  | — |  |  | 715 |  |
| Intercompany payable |  | 9 |  |  | — |  |  | 58 |  |  | 238 |  |  | (305 | ) |  | — |  |
| Intercompany loan payable |  | 8,691 |  |  | — |  |  | 4,713 |  |  | 1,089 |  |  | (14,493 | ) |  | — |  |
| Other current liabilities |  | — |  |  | — |  |  | 219 |  |  | 593 |  |  | — |  |  | 812 |  |
| Total current liabilities |  | 8,719 |  |  | — |  |  | 5,306 |  |  | 3,111 |  |  | (14,798 | ) |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | — |  |  | — |  |  | 17,456 |  |  | 37 |  |  | — |  |  | 17,493 |  |
| Deferred tax liabilities |  | — |  |  | — |  |  | (47 | ) |  | 216 |  |  | — |  |  | 169 |  |
| Intercompany loan payable, long-term |  | — |  |  | — |  |  | 991 |  |  | — |  |  | (991 | ) |  | — |  |
| Unrecognized tax benefits |  | — |  |  | — |  |  | 2,563 |  |  | 525 |  |  | — |  |  | 3,088 |  |
| Other long-term liabilities |  | — |  |  | — |  |  | 131 |  |  | 248 |  |  | — |  |  | 379 |  |
| Total liabilities |  | 8,719 |  |  | — |  |  | 26,400 |  |  | 4,137 |  |  | (15,789 | ) |  | 23,467 |  |
| Total stockholders’ equity |  | 26,657 |  |  | 35,268 |  |  | 35,271 |  |  | 46,742 |  |  | (117,281 | ) |  | 26,657 |  |
| Total liabilities and stockholders’ equity |  | $ | 35,376 |  |  | $ | 35,268 |  |  | $ | 61,671 |  |  | $ | 50,879 |  |  | $ | (133,070 | ) |  | $ | 50,124 |  |

[0001730168-19-000101:notes:239]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | May 5, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,418 |  |  | $ | — |  |  | $ | 4,418 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 1,099 |  |  | — |  |  | 1,099 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 420 |  |  | — |  |  | (420 | ) |  | — |  |
| Total net revenue |  | — |  |  | — |  |  | 420 |  |  | 5,517 |  |  | (420 | ) |  | 5,517 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 35 |  |  | 1,422 |  |  | — |  |  | 1,457 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 4 |  |  | 131 |  |  | — |  |  | 135 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 35 |  |  | (35 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 826 |  |  | — |  |  | 826 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 39 |  |  | 2,424 |  |  | (35 | ) |  | 2,428 |  |
| Gross margin |  | — |  |  | — |  |  | 381 |  |  | 3,093 |  |  | (385 | ) |  | 3,089 |  |
| Research and development |  | — |  |  | — |  |  | 463 |  |  | 688 |  |  | — |  |  | 1,151 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 385 |  |  | (385 | ) |  | — |  |
| Selling, general and administrative |  | 19 |  |  | — |  |  | 82 |  |  | 318 |  |  | — |  |  | 419 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 473 |  |  | — |  |  | 473 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 1 |  |  | 75 |  |  | — |  |  | 76 |  |
| Total operating expenses |  | 19 |  |  | — |  |  | 546 |  |  | 1,939 |  |  | (385 | ) |  | 2,119 |  |
| Operating income (loss) |  | (19 | ) |  | — |  |  | (165 | ) |  | 1,154 |  |  | — |  |  | 970 |  |
| Interest expense |  | (201 | ) |  | — |  |  | (147 | ) |  | (28 | ) |  | — |  |  | (376 | ) |
| Intercompany interest expense |  | (106 | ) |  | — |  |  | (42 | ) |  | (9 | ) |  | 157 |  |  | — |  |
| Other income, net |  | 1 |  |  | — |  |  | 7 |  |  | 55 |  |  | — |  |  | 63 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 81 |  |  | 76 |  |  | (157 | ) |  | — |  |
| Intercompany other income (expense), net |  | 527 |  |  | — |  |  | — |  |  | (527 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | 202 |  |  | — |  |  | (266 | ) |  | 721 |  |  | — |  |  | 657 |  |
| Provision for (benefit from) income taxes |  | (59 | ) |  | 41 |  |  | (75 | ) |  | 57 |  |  | — |  |  | (36 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | 261 |  |  | (41 | ) |  | (191 | ) |  | 664 |  |  | — |  |  | 693 |  |
| Earnings in subsidiaries |  | 430 |  |  | 589 |  |  | 781 |  |  | — |  |  | (1,800 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 691 |  |  | 548 |  |  | 590 |  |  | 664 |  |  | (1,800 | ) |  | 693 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income |  | $ | 691 |  |  | $ | 548 |  |  | $ | 590 |  |  | $ | 662 |  |  | $ | (1,800 | ) |  | $ | 691 |  |
| Comprehensive income |  | $ | 691 |  |  | $ | 548 |  |  | $ | 590 |  |  | $ | 662 |  |  | $ | (1,800 | ) |  | $ | 691 |  |

[0001730168-19-000101:notes:240]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Fiscal Quarter Ended |
|  |  | May 6, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,749 |  |  | $ | — |  |  | $ | 4,749 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 265 |  |  | — |  |  | 265 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 566 |  |  | — |  |  | (566 | ) |  | — |  |
| Total net revenue |  | — |  |  | — |  |  | 566 |  |  | 5,014 |  |  | (566 | ) |  | 5,014 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 32 |  |  | 1,640 |  |  | — |  |  | 1,672 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 3 |  |  | 21 |  |  | — |  |  | 24 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 37 |  |  | (37 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 765 |  |  | — |  |  | 765 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 35 |  |  | 2,465 |  |  | (37 | ) |  | 2,463 |  |
| Gross margin |  | — |  |  | — |  |  | 531 |  |  | 2,549 |  |  | (529 | ) |  | 2,551 |  |
| Research and development |  | — |  |  | — |  |  | 407 |  |  | 529 |  |  | — |  |  | 936 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 529 |  |  | (529 | ) |  | — |  |
| Selling, general and administrative |  | 2 |  |  | — |  |  | 72 |  |  | 220 |  |  | — |  |  | 294 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 11 |  |  | 42 |  |  | — |  |  | 53 |  |
| Total operating expenses |  | 2 |  |  | — |  |  | 490 |  |  | 1,387 |  |  | (529 | ) |  | 1,350 |  |
| Operating income (loss) |  | (2 | ) |  | — |  |  | 41 |  |  | 1,162 |  |  | — |  |  | 1,201 |  |
| Interest expense |  | — |  |  | — |  |  | (148 | ) |  | — |  |  | — |  |  | (148 | ) |
| Intercompany interest expense |  | — |  |  | — |  |  | (81 | ) |  | (519 | ) |  | 600 |  |  | — |  |
| Other income, net |  | — |  |  | — |  |  | 28 |  |  | 18 |  |  | — |  |  | 46 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 519 |  |  | 81 |  |  | (600 | ) |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (2 | ) |  | — |  |  | 359 |  |  | 742 |  |  | — |  |  | 1,099 |  |
| Benefit from income taxes |  | — |  |  | — |  |  | (2,521 | ) |  | (116 | ) |  | — |  |  | (2,637 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (2 | ) |  | — |  |  | 2,880 |  |  | 858 |  |  | — |  |  | 3,736 |  |
| Earnings in subsidiaries |  | 3,720 |  |  | 3,735 |  |  | 855 |  |  | — |  |  | (8,310 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 3,718 |  |  | 3,735 |  |  | 3,735 |  |  | 858 |  |  | (8,310 | ) |  | 3,736 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (2 | ) |  | (1 | ) |  | — |  |  | (3 | ) |
| Net income |  | 3,718 |  |  | 3,735 |  |  | 3,733 |  |  | 857 |  |  | (8,310 | ) |  | 3,733 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |
| Net income attributable to common stock |  | $ | 3,718 |  |  | $ | 3,720 |  |  | $ | 3,733 |  |  | $ | 857 |  |  | $ | (8,310 | ) |  | $ | 3,718 |  |
| Net income |  | $ | 3,718 |  |  | $ | 3,735 |  |  | $ | 3,733 |  |  | $ | 857 |  |  | $ | (8,310 | ) |  | $ | 3,733 |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | (9 | ) |  | 1 |  |  | — |  |  | (8 | ) |
| Comprehensive income |  | 3,718 |  |  | 3,735 |  |  | 3,724 |  |  | 858 |  |  | (8,310 | ) |  | 3,725 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 15 |  |  | — |  |  | — |  |  | — |  |  | 15 |  |
| Comprehensive income attributable to common stock |  | $ | 3,718 |  |  | $ | 3,720 |  |  | $ | 3,724 |  |  | $ | 858 |  |  | $ | (8,310 | ) |  | $ | 3,710 |  |

[0001730168-19-000101:notes:241]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,057 |  |  | $ | — |  |  | $ | 9,057 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 2,249 |  |  | — |  |  | 2,249 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 817 |  |  | — |  |  | (817 | ) |  | — |  |
| Total net revenue |  | — |  |  | — |  |  | 817 |  |  | 11,306 |  |  | (817 | ) |  | 11,306 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 66 |  |  | 2,945 |  |  | — |  |  | 3,011 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 7 |  |  | 266 |  |  | — |  |  | 273 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 58 |  |  | (58 | ) |  | — |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 1,659 |  |  | — |  |  | 1,659 |  |
| Restructuring charges |  | — |  |  | — |  |  | (7 | ) |  | 73 |  |  | — |  |  | 66 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 66 |  |  | 5,001 |  |  | (58 | ) |  | 5,009 |  |
| Gross margin |  | — |  |  | — |  |  | 751 |  |  | 6,305 |  |  | (759 | ) |  | 6,297 |  |
| Research and development |  | — |  |  | — |  |  | 910 |  |  | 1,374 |  |  | — |  |  | 2,284 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 759 |  |  | (759 | ) |  | — |  |
| Selling, general and administrative |  | 71 |  |  | — |  |  | 163 |  |  | 656 |  |  | — |  |  | 890 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 949 |  |  | — |  |  | 949 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 9 |  |  | 640 |  |  | — |  |  | 649 |  |
| Total operating expenses |  | 71 |  |  | — |  |  | 1,082 |  |  | 4,378 |  |  | (759 | ) |  | 4,772 |  |
| Operating income (loss) |  | (71 | ) |  | — |  |  | (331 | ) |  | 1,927 |  |  | — |  |  | 1,525 |  |
| Interest expense |  | (376 | ) |  | — |  |  | (295 | ) |  | (50 | ) |  | — |  |  | (721 | ) |
| Intercompany interest expense |  | (192 | ) |  | — |  |  | (83 | ) |  | (17 | ) |  | 292 |  |  | — |  |
| Other income, net |  | — |  |  | — |  |  | 16 |  |  | 115 |  |  | — |  |  | 131 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 160 |  |  | 132 |  |  | (292 | ) |  | — |  |
| Intercompany other income (expense), net |  | 604 |  |  | — |  |  | — |  |  | (604 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (35 | ) |  | — |  |  | (533 | ) |  | 1,503 |  |  | — |  |  | 935 |  |
| Provision for (benefit from) income taxes |  | (83 | ) |  | 65 |  |  | (252 | ) |  | 31 |  |  | — |  |  | (239 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | 48 |  |  | (65 | ) |  | (281 | ) |  | 1,472 |  |  | — |  |  | 1,174 |  |
| Earnings in subsidiaries |  | 1,114 |  |  | 2,068 |  |  | 2,350 |  |  | — |  |  | (5,532 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 1,162 |  |  | 2,003 |  |  | 2,069 |  |  | 1,472 |  |  | (5,532 | ) |  | 1,174 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Net income |  | $ | 1,162 |  |  | $ | 2,003 |  |  | $ | 2,069 |  |  | $ | 1,460 |  |  | $ | (5,532 | ) |  | $ | 1,162 |  |
| Comprehensive income |  | $ | 1,162 |  |  | $ | 2,003 |  |  | $ | 2,069 |  |  | $ | 1,460 |  |  | $ | (5,532 | ) |  | $ | 1,162 |  |

[0001730168-19-000101:notes:242]
|  |  | Condensed Consolidating Statements of Operations and Comprehensive Income |
|  |  | Two Fiscal Quarters Ended |
|  |  | May 6, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,857 |  |  | $ | — |  |  | $ | 9,857 |  |
| Subscriptions and services |  | — |  |  | — |  |  | — |  |  | 484 |  |  | — |  |  | 484 |  |
| Intercompany revenue |  | — |  |  | — |  |  | 1,150 |  |  | — |  |  | (1,150 | ) |  | — |  |
| Total net revenue |  | — |  |  | — |  |  | 1,150 |  |  | 10,341 |  |  | (1,150 | ) |  | 10,341 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of products sold |  | — |  |  | — |  |  | 61 |  |  | 3,487 |  |  | — |  |  | 3,548 |  |
| Cost of subscriptions and services |  | — |  |  | — |  |  | 6 |  |  | 41 |  |  | — |  |  | 47 |  |
| Intercompany cost of products sold |  | — |  |  | — |  |  | — |  |  | 71 |  |  | (71 | ) |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 1,480 |  |  | — |  |  | 1,480 |  |
| Restructuring charges |  | — |  |  | — |  |  | 2 |  |  | 15 |  |  | — |  |  | 17 |  |
| Total cost of revenue |  | — |  |  | — |  |  | 69 |  |  | 5,164 |  |  | (71 | ) |  | 5,162 |  |
| Gross margin |  | — |  |  | — |  |  | 1,081 |  |  | 5,177 |  |  | (1,079 | ) |  | 5,179 |  |
| Research and development |  | — |  |  | — |  |  | 813 |  |  | 1,048 |  |  | — |  |  | 1,861 |  |
| Intercompany operating expense |  | — |  |  | — |  |  | — |  |  | 1,079 |  |  | (1,079 | ) |  | — |  |
| Selling, general and administrative |  | 2 |  |  | — |  |  | 157 |  |  | 426 |  |  | — |  |  | 585 |  |
| Amortization of acquisition-related intangible assets |  | — |  |  | — |  |  | — |  |  | 406 |  |  | — |  |  | 406 |  |
| Restructuring, impairment and disposal charges |  | — |  |  | — |  |  | 44 |  |  | 139 |  |  | — |  |  | 183 |  |
| Total operating expenses |  | 2 |  |  | — |  |  | 1,014 |  |  | 3,098 |  |  | (1,079 | ) |  | 3,035 |  |
| Operating income (loss) |  | (2 | ) |  | — |  |  | 67 |  |  | 2,079 |  |  | — |  |  | 2,144 |  |
| Interest expense |  | — |  |  | — |  |  | (329 | ) |  | (2 | ) |  | — |  |  | (331 | ) |
| Intercompany interest expense |  | — |  |  | — |  |  | (140 | ) |  | (1,093 | ) |  | 1,233 |  |  | — |  |
| Other income, net |  | — |  |  | — |  |  | 47 |  |  | 34 |  |  | — |  |  | 81 |  |
| Intercompany interest income |  | — |  |  | — |  |  | 1,093 |  |  | 140 |  |  | (1,233 | ) |  | — |  |
| Intercompany other income (expense), net |  | — |  |  | — |  |  | (57 | ) |  | 57 |  |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes and earnings in subsidiaries |  | (2 | ) |  | — |  |  | 681 |  |  | 1,215 |  |  | — |  |  | 1,894 |  |
| Benefit from income taxes |  | — |  |  | — |  |  | (7,981 | ) |  | (442 | ) |  | — |  |  | (8,423 | ) |
| Income (loss) from continuing operations before earnings in subsidiaries |  | (2 | ) |  | — |  |  | 8,662 |  |  | 1,657 |  |  | — |  |  | 10,317 |  |
| Earnings in subsidiaries |  | 9,950 |  |  | 10,301 |  |  | 1,493 |  |  | — |  |  | (21,744 | ) |  | — |  |
| Income from continuing operations and earnings in subsidiaries |  | 9,948 |  |  | 10,301 |  |  | 10,155 |  |  | 1,657 |  |  | (21,744 | ) |  | 10,317 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (2 | ) |  | (16 | ) |  | — |  |  | (18 | ) |
| Net income |  | 9,948 |  |  | 10,301 |  |  | 10,153 |  |  | 1,641 |  |  | (21,744 | ) |  | 10,299 |  |
| Net income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | — |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 9,948 |  |  | $ | 9,950 |  |  | $ | 10,153 |  |  | $ | 1,641 |  |  | $ | (21,744 | ) |  | $ | 9,948 |  |
| Net income |  | $ | 9,948 |  |  | $ | 10,301 |  |  | $ | 10,153 |  |  | $ | 1,641 |  |  | $ | (21,744 | ) |  | $ | 10,299 |  |
| Other comprehensive income |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Comprehensive income |  | 9,948 |  |  | 10,301 |  |  | 10,153 |  |  | 1,642 |  |  | (21,744 | ) |  | 10,300 |  |
| Comprehensive income attributable to noncontrolling interest |  | — |  |  | 351 |  |  | — |  |  | — |  |  | — |  |  | 351 |  |
| Comprehensive income attributable to common stock |  | $ | 9,948 |  |  | $ | 9,950 |  |  | $ | 10,153 |  |  | $ | 1,642 |  |  | $ | (21,744 | ) |  | $ | 9,949 |  |

[0001730168-19-000101:notes:243]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,162 |  |  | $ | 2,003 |  |  | $ | 2,069 |  |  | $ | 1,460 |  |  | $ | (5,532 | ) |  | $ | 1,162 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (1,378 | ) |  | (2,003 | ) |  | (2,895 | ) |  | 4,381 |  |  | 5,532 |  |  | 3,637 |  |
| Net cash provided by (used in) operating activities |  | (216 | ) |  | — |  |  | (826 | ) |  | 5,841 |  |  | — |  |  | 4,799 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net change in intercompany loans |  | 800 |  |  | — |  |  | (309 | ) |  | (5,737 | ) |  | 5,246 |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | (17,865 | ) |  | — |  |  | — |  |  | 1,838 |  |  | — |  |  | (16,027 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 957 |  |  | — |  |  | 957 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (86 | ) |  | (146 | ) |  | 8 |  |  | (224 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 8 |  |  | — |  |  | (8 | ) |  | — |  |
| Purchases of investments |  | (5 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Proceeds from sales of investments |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Other |  | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net cash used in investing activities |  | (17,070 | ) |  | — |  |  | (387 | ) |  | (3,088 | ) |  | 5,246 |  |  | (15,299 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Dividend and distribution payments |  | (2,124 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,124 | ) |
| Net intercompany borrowings |  | 6,050 |  |  | — |  |  | (68 | ) |  | (736 | ) |  | (5,246 | ) |  | — |  |
| Proceeds from long-term borrowings |  | 28,793 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 28,793 |  |
| Repayment of debt |  | (12,000 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (12,000 | ) |
| Other borrowings |  | 997 |  |  | — |  |  | — |  |  | 578 |  |  | — |  |  | 1,575 |  |
| Payment of debt issuance costs |  | (46 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (46 | ) |
| Repurchases of common stock - repurchase program |  | (4,266 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (4,266 | ) |
| Issuance of common stock |  | 183 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 183 |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | — |  |  | (290 | ) |  | (287 | ) |  | — |  |  | (577 | ) |
| Other |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net cash provided by (used in) financing activities |  | 17,587 |  |  | — |  |  | (358 | ) |  | (447 | ) |  | (5,246 | ) |  | 11,536 |  |
| Net change in cash and cash equivalents |  | 301 |  |  | — |  |  | (1,571 | ) |  | 2,306 |  |  | — |  |  | 1,036 |  |
| Cash and cash equivalents at beginning of period |  | — |  |  | — |  |  | 2,461 |  |  | 1,831 |  |  | — |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 301 |  |  | $ | — |  |  | $ | 890 |  |  | $ | 4,137 |  |  | $ | — |  |  | $ | 5,328 |  |

[0001730168-19-000101:notes:244]
|  |  | Condensed Consolidating Statements of Cash Flows |
|  |  | Two Fiscal Quarters Ended |
|  |  | May 6, 2018 |
|  |  | Parent Guarantor |  | Subsidiary Guarantor |  | Subsidiary Issuers |  | Non-Guarantor Subsidiaries |  | Eliminations |  | Consolidated Totals |
|  |  | (In millions) |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,948 |  |  | $ | 10,301 |  |  | $ | 10,153 |  |  | $ | 1,641 |  |  | $ | (21,744 | ) |  | $ | 10,299 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  | (9,611 | ) |  | (10,301 | ) |  | (10,518 | ) |  | 2,156 |  |  | 21,973 |  |  | (6,301 | ) |
| Net cash provided by (used in) operating activities |  | 337 |  |  | — |  |  | (365 | ) |  | 3,797 |  |  | 229 |  |  | 3,998 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions paid |  | — |  |  | — |  |  | (9,099 | ) |  | (3,002 | ) |  | 12,101 |  |  | — |  |
| Distributions received from subsidiaries |  | — |  |  | — |  |  | — |  |  | 1,521 |  |  | (1,521 | ) |  | — |  |
| Net change in intercompany loans |  | — |  |  | — |  |  | 8,346 |  |  | 2,154 |  |  | (10,500 | ) |  | — |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (4,786 | ) |  | — |  |  | (4,786 | ) |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | — |  |  | 782 |  |  | — |  |  | 782 |  |
| Purchases of property, plant and equipment |  | — |  |  | — |  |  | (114 | ) |  | (295 | ) |  | — |  |  | (409 | ) |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | — |  |  | 1 |  |  | 237 |  |  | — |  |  | 238 |  |
| Purchases of investments |  | — |  |  | — |  |  | (50 | ) |  | (199 | ) |  | — |  |  | (249 | ) |
| Proceeds from sales of investments |  | — |  |  | — |  |  | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Other |  | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Net cash used in investing activities |  | — |  |  | — |  |  | (862 | ) |  | (3,600 | ) |  | 80 |  |  | (4,382 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Intercompany contributions received |  | — |  |  | — |  |  | 3,231 |  |  | 9,099 |  |  | (12,330 | ) |  | — |  |
| Net intercompany borrowings |  | — |  |  | — |  |  | (2,125 | ) |  | (8,375 | ) |  | 10,500 |  |  | — |  |
| Repayment of debt |  | — |  |  | — |  |  | — |  |  | (856 | ) |  | — |  |  | (856 | ) |
| Dividend and distribution payments |  | — |  |  | — |  |  | (1,521 | ) |  | (1,521 | ) |  | 1,521 |  |  | (1,521 | ) |
| Repurchases of common stock - repurchase program |  | (347 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (347 | ) |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Issuance of common stock |  | 10 |  |  | — |  |  | — |  |  | 104 |  |  | — |  |  | 114 |  |
| Other |  | — |  |  | — |  |  | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Net cash used in financing activities |  | (337 | ) |  | — |  |  | (415 | ) |  | (1,572 | ) |  | (309 | ) |  | (2,633 | ) |
| Net change in cash and cash equivalents |  | — |  |  | — |  |  | (1,642 | ) |  | (1,375 | ) |  | — |  |  | (3,017 | ) |
| Cash and cash equivalents at beginning of period |  | — |  |  | — |  |  | 7,555 |  |  | 3,649 |  |  | — |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | — |  |  | $ | — |  |  | $ | 5,913 |  |  | $ | 2,274 |  |  | $ | — |  |  | $ | 8,187 |  |


## us-gaap:SubsequentEventsTextBlock

[0001730168-19-000101:notes:245]
Subsequent Event
Cash Dividends Declared

[0001730168-19-000101:notes:246]
On June 12, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on July 2, 2019 to stockholders of record at the close of business on June 24, 2019.
