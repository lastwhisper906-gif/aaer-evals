# AVGO MD&A — 0001730168-19-000101


## mdna

[0001730168-19-000101:mdna:1]
[same as prior period, unchanged from 0001730168-19-000036:mdna:1]

[0001730168-19-000101:mdna:2]
[same as prior period, unchanged from 0001730168-19-000036:mdna:2]

[0001730168-19-000101:mdna:3]
[same as prior period, unchanged from 0001730168-19-000036:mdna:3]

[0001730168-19-000101:mdna:4]
Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year, with our first fiscal quarter containing 13 weeks compared to 14 weeks in the first quarter of fiscal year 2018.

[0001730168-19-000101:mdna:5]
Subsequent to the acquisition of CA, Inc. (“CA”), we changed our organizational structure resulting in three reportable segments: semiconductor solutions, infrastructure software and IP licensing. Our semiconductor solutions segment includes all of our product lines, except for those related to our fibre channel storage area networking (“FC SAN”) products. Our infrastructure software segment includes our FC SAN products and the CA mainframe and enterprise software solutions. Our IP licensing segment includes the results of our IP licensing business. Prior period segment results have been recast to conform to the current presentation.

[0001730168-19-000101:mdna:6]
Quarterly Developments and Highlights

[0001730168-19-000101:mdna:7]
Highlights during the second fiscal quarter ended May 5, 2019 include the following:

[0001730168-19-000101:mdna:8]
| • | We generated $2,667 million of cash from operations. |

[0001730168-19-000101:mdna:9]
| • | We paid $1,057 million for cash dividends, $830 million to repurchase shares of our common stock under our stock repurchase program and $500 million in employee withholding taxes related to net share settled equity awards. |

[0001730168-19-000101:mdna:10]
41

[0001730168-19-000101:mdna:11]
| • | We issued $11 billion of senior unsecured notes (the “2019 Senior Notes”) and established a $2 billion commercial paper program (“Commercial Paper”) to support general corporate purposes. As of May 5, 2019, we had $1 billion of Commercial Paper outstanding. The combined net proceeds were used to repay $12 billion of the $18 billion unsecured term loan facilities (the “2019 Term Loans”). See Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q for more details. |

[0001730168-19-000101:mdna:12]
[same as prior period, unchanged from 0001730168-19-000036:mdna:13]

[0001730168-19-000101:mdna:13]
[same as prior period, unchanged from 0001730168-19-000036:mdna:14]

[0001730168-19-000101:mdna:14]
On November 5, 2018, we completed the acquisition of CA for aggregate consideration of approximately $18.8 billion (the “CA Merger”) in exchange for all shares of CA common stock issued and outstanding immediately prior to the CA Merger. In addition, we assumed all outstanding unvested CA equity awards held by continuing employees. All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon completion of the CA Merger. We financed the CA Merger with proceeds of $18 billion from the 2019 Term Loans, as well as cash on hand of the combined companies.

[0001730168-19-000101:mdna:15]
[same as prior period, unchanged from 0001730168-19-000036:mdna:16]

[0001730168-19-000101:mdna:16]
On December 31, 2018, we sold Veracode, Inc. (“Veracode”), a wholly-owned subsidiary of CA and provider of application security testing solutions, to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments.

[0001730168-19-000101:mdna:17]
[same as prior period, unchanged from 0001730168-19-000036:mdna:18]

[0001730168-19-000101:mdna:18]
[same as prior period, unchanged from 0001730168-19-000036:mdna:19]

[0001730168-19-000101:mdna:19]
Refer to Note 2. “Revenue from Contracts with Customers” in Part I, Item 1 of this Form 10-Q for updates on critical accounting estimates related to revenue recognition. There were no other significant changes in our critical accounting policies during the two fiscal quarters ended May 5, 2019 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2018 Annual Report on Form 10-K.

[0001730168-19-000101:mdna:20]
42

[0001730168-19-000101:mdna:21]
[same as prior period, unchanged from 0001730168-19-000036:mdna:21]

[0001730168-19-000101:mdna:22]
Fiscal Quarter and Two Fiscal Quarters Ended May 5, 2019 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 6, 2018

[0001730168-19-000101:mdna:23]
The following tables set forth our results of operations for the periods presented:

[0001730168-19-000101:mdna:24]
|  |  | Fiscal Quarter Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |  | (As a percentage of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,418 |  |  | $ | 4,749 |  |  | 80 | % |  | 95 | % |
| Subscriptions and services |  | 1,099 |  |  | 265 |  |  | 20 |  |  | 5 |  |
| Total net revenue |  | 5,517 |  |  | 5,014 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,457 |  |  | 1,672 |  |  | 27 |  |  | 34 |  |
| Cost of subscriptions and services |  | 135 |  |  | 24 |  |  | 2 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 826 |  |  | 765 |  |  | 15 |  |  | 15 |  |
| Restructuring charges |  | 10 |  |  | 2 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,428 |  |  | 2,463 |  |  | 44 |  |  | 49 |  |
| Gross margin |  | 3,089 |  |  | 2,551 |  |  | 56 |  |  | 51 |  |
| Research and development |  | 1,151 |  |  | 936 |  |  | 21 |  |  | 19 |  |
| Selling, general and administrative |  | 419 |  |  | 294 |  |  | 8 |  |  | 6 |  |
| Amortization of acquisition-related intangible assets |  | 473 |  |  | 67 |  |  | 8 |  |  | 1 |  |
| Restructuring, impairment and disposal charges |  | 76 |  |  | 53 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 2,119 |  |  | 1,350 |  |  | 38 |  |  | 27 |  |
| Operating income |  | $ | 970 |  |  | $ | 1,201 |  |  | 18 | % |  | 24 | % |

[0001730168-19-000101:mdna:25]
43

[0001730168-19-000101:mdna:26]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
|  |  | ($ in millions) |  | (As a % of total net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 9,057 |  |  | $ | 9,857 |  |  | 80 | % |  | 95 | % |
| Subscriptions and services |  | 2,249 |  |  | 484 |  |  | 20 |  |  | 5 |  |
| Total net revenue |  | 11,306 |  |  | 10,341 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 3,011 |  |  | 3,548 |  |  | 27 |  |  | 35 |  |
| Cost of subscriptions and services |  | 273 |  |  | 47 |  |  | 2 |  |  | — |  |
| Purchase accounting effect on inventory |  | — |  |  | 70 |  |  | — |  |  | 1 |  |
| Amortization of acquisition-related intangible assets |  | 1,659 |  |  | 1,480 |  |  | 15 |  |  | 14 |  |
| Restructuring charges |  | 66 |  |  | 17 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,009 |  |  | 5,162 |  |  | 44 |  |  | 50 |  |
| Gross margin |  | 6,297 |  |  | 5,179 |  |  | 56 |  |  | 50 |  |
| Research and development |  | 2,284 |  |  | 1,861 |  |  | 20 |  |  | 18 |  |
| Selling, general and administrative |  | 890 |  |  | 585 |  |  | 8 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 949 |  |  | 406 |  |  | 8 |  |  | 4 |  |
| Restructuring, impairment and disposal charges |  | 649 |  |  | 183 |  |  | 6 |  |  | 2 |  |
| Total operating expenses |  | 4,772 |  |  | 3,035 |  |  | 42 |  |  | 29 |  |
| Operating income |  | $ | 1,525 |  |  | $ | 2,144 |  |  | 14 | % |  | 21 | % |

[0001730168-19-000101:mdna:27]
[same as prior period, unchanged from 0001730168-19-000036:mdna:25]

[0001730168-19-000101:mdna:28]
Historically, a relatively small number of customers has accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics and Tech Data Corporation, both of which are distributors, accounted for 14% and 11%, respectively, of our net revenue for the fiscal quarter ended May 5, 2019 and 14% and 10%, respectively, of our net revenue for the two fiscal quarters ended May 5, 2019. No customer accounted for 10% or more of our net revenue for the fiscal quarter ended May 6, 2018. Foxconn Technology Group companies (including Hon Hai Precision Industries), contract manufacturers, accounted for 12% of our net revenue for the two fiscal quarters ended May 6, 2018. We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 32% and 36% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, and approximately 38% and 43% of our net revenue for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 13% and 17% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, and approximately 17% and 25% for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-19-000101:mdna:29]
[same as prior period, unchanged from 0001730168-19-000036:mdna:28]

[0001730168-19-000101:mdna:30]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 5, 2019 |  | May 6, 2018 |  | $ Change |  | % Change |  | May 5, 2019 |  | May 6, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 4,088 |  |  | $ | 4,537 |  |  | $ | (449 | ) |  | (10 | )% |  | $ | 8,462 |  |  | $ | 9,492 |  |  | $ | (1,030 | ) |  | (11 | )% |
| Infrastructure software |  | 1,413 |  |  | 447 |  |  | 966 |  |  | 216 | % |  | 2,816 |  |  | 775 |  |  | 2,041 |  |  | 263 | % |
| IP licensing |  | 16 |  |  | 30 |  |  | (14 | ) |  | (47 | )% |  | 28 |  |  | 74 |  |  | (46 | ) |  | (62 | )% |
| Total net revenue |  | $ | 5,517 |  |  | $ | 5,014 |  |  | $ | 503 |  |  | 10 | % |  | $ | 11,306 |  |  | $ | 10,341 |  |  | $ | 965 |  |  | 9 | % |

[0001730168-19-000101:mdna:31]
44

[0001730168-19-000101:mdna:32]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| % of Net Revenue by Segment |  | May 5, 2019 |  | May 6, 2018 |  | May 5, 2019 |  | May 6, 2018 |
| Semiconductor solutions |  | 74 | % |  | 90 | % |  | 75 | % |  | 92 | % |
| Infrastructure software |  | 26 |  |  | 9 |  |  | 25 |  |  | 7 |  |
| IP licensing |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-19-000101:mdna:33]
Fiscal quarter ended May 5, 2019 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to lower demand for our wireless content in mobile handsets, as well as lower demand for our standard networking, server storage connectivity, optocoupler and broadband products. These decreases were partially offset by higher demand for our set-top box products. Net revenue from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as higher demand for our FC SAN products. Net revenue from our IP licensing segment decreased primarily due to lower IP licensing volume.

[0001730168-19-000101:mdna:34]
Two fiscal quarters ended May 5, 2019 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to lower demand for our wireless content in mobile handsets, as well as lower demand for our server storage connectivity, optocoupler and broadband products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. These decreases were partially offset by higher demand in the first fiscal quarter for our standard networking and solid-state drive controller products. We expect the effects of export restrictions on one of our largest customers to adversely impact our revenue in the second half of fiscal year 2019. Net revenue from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as higher demand for our FC SAN products. Net revenue from our IP licensing segment decreased primarily due to lower IP licensing volume.

[0001730168-19-000101:mdna:35]
[same as prior period, unchanged from 0001730168-19-000036:mdna:32]

[0001730168-19-000101:mdna:36]
Gross margin was $3,089 million for the fiscal quarter ended May 5, 2019 compared to $2,551 million for the fiscal quarter ended May 6, 2018. Gross margin was $6,297 million for the two fiscal quarters ended May 5, 2019 compared to $5,179 million for the two fiscal quarters ended May 6, 2018. As a percentage of net revenue, gross margin was 56% and 51% for the fiscal quarters ended May 5, 2019 and May 6, 2018, respectively, and 56% and 50% for the two fiscal quarters ended May 5, 2019 and May 6, 2018, respectively.

[0001730168-19-000101:mdna:37]
The increases in gross margin were primarily due to contributions from our CA mainframe and enterprise software products, favorable gross margin impact from our FC SAN products and favorable product mix within our semiconductor solutions segment. These increases were partially offset by higher amortization of acquisition-related intangible assets as a result of the CA Merger. The increase in gross margin for the two fiscal quarters ended May 5, 2019 was also partially offset by higher restructuring charges as a result of the CA Merger.

[0001730168-19-000101:mdna:38]
[same as prior period, unchanged from 0001730168-19-000036:mdna:34]

[0001730168-19-000101:mdna:39]
Research and development expense increased $215 million, or 23%, and $423 million, or 23%, for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to the prior year fiscal periods. These increases were primarily due to the acquisition of CA and higher stock-based compensation expense. The increases in stock-based compensation expense were primarily due to the issuance of multi-year equity grants of time- and market-based restricted stock units (the “Multi-Year Equity Awards”) in the first quarter of fiscal year 2019 and assumed CA equity awards. Our stock-based compensation expense for the fiscal year 2019 periods included employee equity awards with higher grant-date fair values than those in the corresponding fiscal year 2018 periods, which also contributed to the increase.

[0001730168-19-000101:mdna:40]
[same as prior period, unchanged from 0001730168-19-000036:mdna:36]

[0001730168-19-000101:mdna:41]
Selling, general and administrative expense increased $125 million, or 43%, and $305 million, or 52%, for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to the prior year fiscal periods. These increases were primarily due to the acquisition of CA and stock-based compensation expense. The increases in stock-based compensation expense were primarily due to the issuance of the Multi-Year Equity Awards and assumed CA equity awards. Our stock-based compensation expense for the fiscal year 2019 periods included employee equity awards with higher grant-date fair values than those in the corresponding fiscal year 2018 periods, which also contributed to the increase.

[0001730168-19-000101:mdna:42]
[same as prior period, unchanged from 0001730168-19-000036:mdna:38]

[0001730168-19-000101:mdna:43]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $406 million and $543 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to amortization of intangible assets acquired in the CA Merger.

[0001730168-19-000101:mdna:44]
[same as prior period, unchanged from 0001730168-19-000036:mdna:40]

[0001730168-19-000101:mdna:45]
Restructuring, impairment and disposal charges recognized in operating expenses increased $23 million and $466 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to employee termination costs, as well as lease and other exit costs resulting from the CA Merger. We expect to incur additional restructuring charges in future periods as a result of the CA Merger. See Note 12. “Restructuring, Impairment and Disposal Charges” in Part I, Item 1 of this Form 10-Q for more details.

[0001730168-19-000101:mdna:46]
[same as prior period, unchanged from 0001730168-19-000036:mdna:42]

[0001730168-19-000101:mdna:47]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Operating Income (Loss) by Segment |  | May 5, 2019 |  | May 6, 2018 |  | $ Change |  | % Change |  | May 5, 2019 |  | May 6, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 1,900 |  |  | $ | 2,127 |  |  | $ | (227 | ) |  | (11 | )% |  | $ | 3,937 |  |  | $ | 4,452 |  |  | $ | (515 | ) |  | (12 | )% |
| Infrastructure software |  | 1,050 |  |  | 310 |  |  | 740 |  |  | 239 | % |  | 2,070 |  |  | 526 |  |  | 1,544 |  |  | 294 | % |
| IP licensing |  | (1 | ) |  | 15 |  |  | (16 | ) |  | (107 | )% |  | (6 | ) |  | 41 |  |  | (47 | ) |  | (115 | )% |
| Unallocated expenses |  | (1,979 | ) |  | (1,251 | ) |  | (728 | ) |  | 58 | % |  | (4,476 | ) |  | (2,875 | ) |  | (1,601 | ) |  | 56 | % |
| Total operating income |  | $ | 970 |  |  | $ | 1,201 |  |  | $ | (231 | ) |  | (19 | )% |  | $ | 1,525 |  |  | $ | 2,144 |  |  | $ | (619 | ) |  | (29 | )% |

[0001730168-19-000101:mdna:48]
Fiscal quarter ended May 5, 2019 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand in our wireless content in mobile handsets, as well as lower demand for our server storage connectivity, standard networking and optocoupler products. These decreases were partially offset by higher demand for our set-top box products. Operating income from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as an increase in demand for our FC SAN products. Operating loss from our IP licensing segment was primarily due to lower IP licensing volume.

[0001730168-19-000101:mdna:49]
Two fiscal quarters ended May 5, 2019 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand in our wireless content in mobile handsets, as well as lower demand for our server storage connectivity, optocoupler and broadband products. Additionally, in the first quarter of fiscal year 2018, we experienced a later than typical new mobile handset ramp with a major customer, which resulted in higher shipments in that quarter. These decreases were partially offset by higher demand in the first fiscal quarter for our standard networking and solid-state drive products. Operating income from our infrastructure software segment increased primarily due to contributions from our CA mainframe and enterprise software products, as well as an increase in demand for our FC SAN products. Operating loss from our IP licensing segment was primarily due to lower IP licensing volume.

[0001730168-19-000101:mdna:50]
Unallocated expenses include amortization of acquisition-related intangible assets; restructuring, impairment and disposal charges; stock-based compensation expense; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 58% and 56% for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense and restructuring, impairment and disposal charges. These increases were primarily due to the CA Merger and the issuance of the Multi-Year Equity Awards.

[0001730168-19-000101:mdna:51]
[same as prior period, unchanged from 0001730168-19-000036:mdna:46]

[0001730168-19-000101:mdna:52]
Interest expense. Interest expense was $376 million and $721 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, compared to $148 million and $331 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. These increases were primarily due to interest on the debt we incurred to finance the CA Merger in the first quarter of fiscal year 2019, as well as expenses incurred related to debt modification in the second quarter of fiscal year 2019.

[0001730168-19-000101:mdna:53]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $63 million and $131 million for the fiscal quarter and

[0001730168-19-000101:mdna:54]
two fiscal quarters ended May 5, 2019 compared to $46 million and $81 million for the fiscal quarter and two fiscal quarters ended May 6, 2018. These increases were primarily due to increases in unrealized gains on investments.

[0001730168-19-000101:mdna:55]
Benefit from income taxes. For the fiscal quarter and two fiscal quarters ended May 5, 2019, our benefit from income taxes was $36 million and $239 million, respectively, compared to a benefit from income taxes of $2,637 million and $8,423 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. The decreases were primarily due to tax effects of a change in law, resulting from the enactment of the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”) in the prior year fiscal periods.

[0001730168-19-000101:mdna:56]
The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 5, 2019, was primarily due to excess tax benefits from stock-based awards that vested or were exercised during the period. The current year fiscal periods also include the impact of several provisions of the 2017 Tax Reform Act that take effect for us for the first time in fiscal year 2019, including a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We have elected to account for GILTI as a period cost rather than on a deferred basis.

[0001730168-19-000101:mdna:57]
Additionally, for the two fiscal quarters ended May 5, 2019, our benefit from income taxes was due to recognition of gross uncertain tax benefits as a result of audit settlements, lapses of statutes of limitations and a partial release of our valuation allowance resulting from the CA Merger.

[0001730168-19-000101:mdna:58]
The benefit from income taxes for the corresponding prior year fiscal periods was principally a result of provisional income tax benefits realized from the enactment of the 2017 Tax Reform Act, signed into law on December 22, 2017. The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including, but not limited to, a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, the transition of U.S. international taxation from a worldwide tax system to a participation exemption regime, and the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations as of December 31, 2017.

[0001730168-19-000101:mdna:59]
[same as prior period, unchanged from 0001730168-19-000036:mdna:52]

[0001730168-19-000101:mdna:60]
[same as prior period, unchanged from 0001730168-19-000036:mdna:53]

[0001730168-19-000101:mdna:61]
Our primary sources of liquidity as of May 5, 2019 consisted of: (i) $5,328 million in cash and cash equivalents, (ii) cash we expect to generate from operations, (iii) available capacity under our $5 billion revolving credit facility (the “Revolving Facility”), and (iv) available capacity under our $2 billion commercial paper program. In addition, we may also generate cash from the sale of assets from time to time.

[0001730168-19-000101:mdna:62]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) stock repurchases, if any, (v) cash dividend payments (if and when declared by our Board of Directors), (vi) interest and principal payments related to outstanding indebtedness and (vii) payment of income taxes, including taxes resulting from the intercompany transfer of IP. Beginning in April 2018, we settle withholding tax amounts due upon vesting of compensatory equity awards using cash on hand, and withhold from the grant recipient that number of shares having a value equivalent to the withholding tax amount (“Tax Shares”). This net settlement method reduces the dilutive effects of such awards as they vest. Previously, Tax Shares were issued and mandatorily sold into the market, and the cash proceeds were used to pay such withholding tax amounts. This change results in an increased use of our cash as our outstanding equity awards vest. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-19-000101:mdna:63]
We expect our capital expenditures for fiscal year 2019 will be lower than fiscal year 2018. We believe that our cash and cash equivalents on hand and cash flows from operations, combined with current borrowing availability under the Revolving Facility and our commercial paper program, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-19-000101:mdna:64]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may also seek to obtain new

[0001730168-19-000101:mdna:65]
47

[0001730168-19-000101:mdna:66]
debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-19-000101:mdna:67]
[same as prior period, unchanged from 0001730168-19-000036:mdna:58]

[0001730168-19-000101:mdna:68]
Working capital decreased to $2,174 million at May 5, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-19-000101:mdna:69]
| • | Current portion of long-term debt increased by $3,537 million due to certain debt instruments becoming due within the next twelve months. |

[0001730168-19-000101:mdna:70]
| • | Other current liabilities increased to $3,729 million at May 5, 2019 from $812 million at November 4, 2018, primarily due to liabilities assumed in the CA Merger and increases in contract liabilities from adoption of Accounting Standard Codification Topic 606 (“Topic 606”), notional pooling liabilities, restructuring reserves, and interest payable. |

[0001730168-19-000101:mdna:71]
| • | Inventory decreased to $1,034 million at May 5, 2019 from $1,124 million at November 4, 2018 primarily due to consumption to support customer shipments. |

[0001730168-19-000101:mdna:72]
[same as prior period, unchanged from 0001730168-19-000036:mdna:62]

[0001730168-19-000101:mdna:73]
| • | Cash and cash equivalents increased to $5,328 million at May 5, 2019 from $4,292 million at November 4, 2018, primarily due to $30,368 million in proceeds from borrowings, $4,799 million in net cash provided by operating activities and $957 million in proceeds from the sale of Veracode, partially offset by $16,027 million paid for the CA Merger, $12 billion of debt repayments, $4,266 million of common stock repurchases and $2,124 million of dividend payments. |

[0001730168-19-000101:mdna:74]
| • | Other current assets increased to $831 million at May 5, 2019 from $366 million at November 4, 2018, primarily due to assets acquired in the CA Merger and increases in taxes receivable, other receivables and contract assets from Topic 606 adoption. |

[0001730168-19-000101:mdna:75]
| • | Accounts receivable increased to $3,484 million at May 5, 2019 from $3,325 million at November 4, 2018 primarily due to revenue linearity and an increase due to the CA Merger. |

[0001730168-19-000101:mdna:76]
| • | Employee compensation and benefits liabilities decreased to $478 million at May 5, 2019 from $715 million at November 4, 2018 primarily due to the timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger. |

[0001730168-19-000101:mdna:77]
Working capital decreased to $10,350 million at May 6, 2018 from $13,294 million at October 29, 2017. The decrease was attributable to the following:

[0001730168-19-000101:mdna:78]
| • | Our cash and cash equivalents decreased to $8,187 million at May 6, 2018 from $11,204 million at October 29, 2017, due to $4,786 million paid primarily for the acquisition of Brocade Communications Systems, Inc. (“Brocade”), $1,521 million of dividend and distribution payments and $856 million of debt repayments, partially offset by $3,998 million in net cash provided by operating activities and $782 million in proceeds from sales of businesses. |

[0001730168-19-000101:mdna:79]
| • | Other current assets decreased to $303 million at May 6, 2018 from $724 million at October 29, 2017, primarily due to a utilization of prepaid taxes and collections of other receivables. |

[0001730168-19-000101:mdna:80]
| • | Inventory decreased to $1,235 million at May 6, 2018 from $1,447 million at October 29, 2017, primarily due to the timing of a major customer's new handset ramp. |

[0001730168-19-000101:mdna:81]
[same as prior period, unchanged from 0001730168-19-000036:mdna:73]

[0001730168-19-000101:mdna:82]
| • | Employee compensation and benefits liabilities decreased to $417 million at May 6, 2018 from $626 million at October 29, 2017, primarily due to timing of employee bonus plan payments, partially offset by increases due to the acquisition of Brocade. |

[0001730168-19-000101:mdna:83]
| • | Accounts payable decreased to $836 million at May 6, 2018 from $1,105 million at October 29, 2017, primarily due to the timing of vendor payments, partially offset by increases due to the acquisition of Brocade. |

[0001730168-19-000101:mdna:84]
| • | Accounts receivable increased to $2,749 million at May 6, 2018 from $2,448 million at October 29, 2017, primarily due to revenue linearity and an increase due to the acquisition of Brocade. |

[0001730168-19-000101:mdna:85]
[same as prior period, unchanged from 0001730168-19-000036:mdna:76]

[0001730168-19-000101:mdna:86]
[same as prior period, unchanged from 0001730168-19-000036:mdna:77]

[0001730168-19-000101:mdna:87]
During the two fiscal quarters ended May 5, 2019, we repurchased and retired approximately 17 million shares of our common stock at a weighted average price of $253.32 under this stock repurchase program. As of May 5, 2019, $6,476 million of the current authorization remained available under our stock repurchase program.

[0001730168-19-000101:mdna:88]
[same as prior period, unchanged from 0001730168-19-000036:mdna:79]

[0001730168-19-000101:mdna:89]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions, except per share data) |
| Cash dividends and distributions declared and paid per share/unit |  | $ | 5.30 |  |  | $ | 3.50 |  |
| Cash dividends and distributions paid |  | $ | 2,124 |  |  | $ | 1,521 |  |
| Stock repurchases |  | $ | 4,266 |  |  | $ | 347 |  |

[0001730168-19-000101:mdna:90]
In addition, during the two fiscal quarters ended May 5, 2019, we paid $577 million in employee withholding taxes due upon the vesting of, and related to net settled equity awards. We withheld approximately 2 million shares from employees in connection with such net share settlement.

[0001730168-19-000101:mdna:91]
[same as prior period, unchanged from 0001730168-19-000036:mdna:82]

[0001730168-19-000101:mdna:92]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 5, 2019 |  | May 6, 2018 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 4,799 |  |  | $ | 3,998 |  |
| Net cash used in investing activities |  | (15,299 | ) |  | (4,382 | ) |
| Net cash provided by (used in) financing activities |  | 11,536 |  |  | (2,633 | ) |
| Net change in cash and cash equivalents |  | $ | 1,036 |  |  | $ | (3,017 | ) |

[0001730168-19-000101:mdna:93]
[same as prior period, unchanged from 0001730168-19-000036:mdna:84]

[0001730168-19-000101:mdna:94]
Cash provided by operating activities primarily consisted of net income adjusted for certain non-cash items and changes in assets and liabilities. The $801 million increase in cash provided by operations during the two fiscal quarters ended May 5, 2019 compared to the two fiscal quarters ended May 6, 2018 was due to the impact of net income and changes in assets and liabilities, partially offset by adjustments for non-cash items. Net income in each period reflects significant non-cash benefits from income taxes. For the two fiscal quarters ended May 5, 2019, the non-cash income tax benefit of $473 million principally resulted from the recognition of uncertain tax benefits due to audit settlements and lapses of statutes of limitations as well as the release of a portion of our valuation allowance as a result of the CA Merger. The non-cash income tax benefit for the two fiscal quarters ended May 6, 2018 principally resulted from the enactment of the 2017 Tax Reform Act. These non-cash benefits are included in the deferred taxes and other non-cash taxes line in the condensed consolidated statement of cash flows. Other non-cash adjustments to net income during the two fiscal quarters ended May 5, 2019, as compared to the two fiscal quarters ended May 6, 2018, primarily included increases in amortization of intangible assets, stock-based compensation and restructuring charges. In addition, cash provided by operating activities in each period was affected by changes in working capital, as discussed above.

[0001730168-19-000101:mdna:95]
[same as prior period, unchanged from 0001730168-19-000036:mdna:86]

[0001730168-19-000101:mdna:96]
Cash used in investing activities primarily consisted of cash used for acquisitions, capital expenditures and investments, partially offset by proceeds from sales of businesses and assets. The $10,917 million increase in cash used in investing

[0001730168-19-000101:mdna:97]
49

[0001730168-19-000101:mdna:98]
activities during the two fiscal quarters ended May 5, 2019 compared to the two fiscal quarters ended May 6, 2018 was primarily related to $16,027 million paid for the CA Merger in the two fiscal quarters ended May 5, 2019 compared to $4,786 million paid for the acquisition of Brocade in the two fiscal quarters ended May 6, 2018, partially offset by a decrease of $185 million in capital expenditures and an increase of $175 million in proceeds from sales of businesses.

[0001730168-19-000101:mdna:99]
[same as prior period, unchanged from 0001730168-19-000036:mdna:88]

[0001730168-19-000101:mdna:100]
Cash from financing activities primarily consisted of net proceeds and payments related to our long-term-debt, dividend and distribution payments, stock repurchases, and the issuance of common stock pursuant to our employee equity incentive award plans. The $14,169 million increase in cash provided by financing activities during the two fiscal quarters ended May 5, 2019 compared to the two fiscal quarters ended May 6, 2018 was primarily due to an increase of $19,224 million in net proceeds from borrowings, partially offset by an increase of $4,494 million in common stock repurchases and an increase of $603 million of dividend payments.

[0001730168-19-000101:mdna:101]
[same as prior period, unchanged from 0001730168-19-000036:mdna:90]

[0001730168-19-000101:mdna:102]
[same as prior period, unchanged from 0001730168-19-000036:mdna:98]

[0001730168-19-000101:mdna:103]
[same as prior period, unchanged from 0001730168-19-000036:mdna:99]

[0001730168-19-000101:mdna:104]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000101:mdna:105]
[same as prior period, unchanged from 0001730168-19-000036:mdna:101]

[0001730168-19-000101:mdna:106]
We had no material off-balance sheet arrangements at May 5, 2019 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-19-000101:mdna:107]
[same as prior period, unchanged from 0001730168-19-000036:mdna:103]

[0001730168-19-000101:mdna:108]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-19-000101:mdna:109]
[same as prior period, unchanged from 0001730168-19-000036:mdna:105]

[0001730168-19-000101:mdna:110]
[same as prior period, unchanged from 0001730168-19-000036:mdna:106]
