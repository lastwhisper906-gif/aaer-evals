# AVGO 8-K — 0001193125-19-172516 filed 2019-06-13

## item codes, every 8-K on or before 2019-06-14

- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2019-06-14

- none on or before 2019-06-14

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-172516:8k_2_02:1]
EX-99.1
2
d763344dex991.htm
EX-99.1

[0001193125-19-172516:8k_2_02:2]
EX-99.1

[0001193125-19-172516:8k_2_02:3]
Exhibit 99.1

[0001193125-19-172516:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2019 Financial Results, Quarterly Dividend and Updated Guidance

[0001193125-19-172516:8k_2_02:5]
|  | • |  | Revenue of $5,517 million for the quarter, up 10 percent from the prior year period |

[0001193125-19-172516:8k_2_02:6]
|  | • |  | GAAP diluted EPS of $1.64; Non-GAAP diluted EPS of $5.21 |

[0001193125-19-172516:8k_2_02:7]
|  | • |  | GAAP operating profit margin of 18%; Non-GAAP operating profit margin of 53% |

[0001193125-19-172516:8k_2_02:8]
|  | • |  | $2,542 million of free cash flow, defined as cash from operations of $2,667 million less capital expenditures of $125 million, up 20 percent from the prior year period |

[0001193125-19-172516:8k_2_02:9]
|  | • |  | Quarterly dividend of $2.65 per share |

[0001193125-19-172516:8k_2_02:10]
|  | • |  | Repurchased and eliminated 4.7 million shares for $1,330 million |

[0001193125-19-172516:8k_2_02:11]
|  | • |  | Updating fiscal year 2019 guidance, including revenue outlook of $22.5 billion; $17.5 billion from semiconductor solutions and $5 billion from infrastructure software |

[0001193125-19-172516:8k_2_02:12]
SAN JOSE, Calif. – June 13, 2019 - Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies
semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2019, ended May 5, 2019, announced a quarterly dividend and updated guidance for its fiscal year 2019.

[0001193125-19-172516:8k_2_02:13]
“We executed according to plan in the second quarter with tailwinds from networking offsetting the anticipated headwinds from wireless.” said Hock
Tan, President and CEO of Broadcom Inc. “We currently see a broad-based slowdown in the demand environment, which we believe is driven by continued geopolitical uncertainties, as well as the effects of export restrictions on one of our largest
customers. As a result, our customers are actively reducing their inventory levels, and we are taking a conservative stance for the rest of the year. We remain well-positioned across our various semiconductor and software businesses and are
confident this portfolio of franchises will continue to drive sustained long-term revenue growth and increasing free cash flow.”

[0001193125-19-172516:8k_2_02:14]
“We achieved
record free cash flow of $2.5 billion growing 20% year over year in the second quarter.” said Tom Krause, CFO of Broadcom Inc. “Despite the challenging market backdrop and updated revenue outlook, we still expect to grow free cash
flow by a double-digit percentage for the year. In addition, we remain focused on completing a total of $8 billion of share repurchases and eliminations in fiscal 2019.”

[0001193125-19-172516:8k_2_02:15]
Second Quarter Fiscal Year 2019 GAAP Results from Continuing Operations

[0001193125-19-172516:8k_2_02:16]
Net revenue was $5,517 million, a decrease of 4.7 percent from $5,789 million in the previous quarter and an increase of 10.0 percent from
$5,014 million in the same quarter last year.

[0001193125-19-172516:8k_2_02:17]
1

[0001193125-19-172516:8k_2_02:18]
Gross margin was $3,089 million, or 56.0 percent of net revenue. This compares with gross margin
of $3,208 million, or 55.4 percent of net revenue, in the prior quarter, and gross margin of $2,551 million, or 50.9 percent of net revenue, in the same quarter last year.

[0001193125-19-172516:8k_2_02:19]
Operating expenses were $2,119 million. This compares with $2,653 million in the prior quarter and $1,350 million in the same quarter last
year.

[0001193125-19-172516:8k_2_02:20]
Operating income was $970 million, or 17.6 percent of net revenue. This compares with operating income of $555 million, or
9.6 percent of net revenue, in the prior quarter, and operating income of $1,201 million, or 24.0 percent of net revenue, in the same quarter last year.

[0001193125-19-172516:8k_2_02:21]
Net income, which includes the impact of discontinued operations, was $691 million, or $1.64 per diluted share. This compares with net income of
$471 million, or $1.12 per diluted share, in the prior quarter, and net income of $3,733 million, or $8.33 per diluted share, in the same quarter last year.

[0001193125-19-172516:8k_2_02:22]
Cash from operations was $2,667 million in the quarter, compared to $2,313 million in the same quarter last year.

[0001193125-19-172516:8k_2_02:23]
| Second Quarter Fiscal Year 2019 GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q2 19 |  |  | Q1 19 |  |  | Q2 18 |  |  | Q/Q |  |  | Y/Y |  |
| Net revenue |  | $ | 5,517 |  |  | $ | 5,789 |  |  | $ | 5,014 |  |  |  | -4.7 | % |  |  | +10.0 | % |
| Gross margin |  |  | 56.0 | % |  |  | 55.4 | % |  |  | 50.9 | % |  |  | +60bps |  |  |  | +510bps |  |
| Operating expenses |  | $ | 2,119 |  |  | $ | 2,653 |  |  | $ | 1,350 |  |  | -$ | 534 |  |  | +$ | 769 |  |
| Net income |  | $ | 691 |  |  | $ | 471 |  |  | $ | 3,733 |  |  | +$ | 220 |  |  | -$ | 3,042 |  |
| Net income attributable to noncontrolling interest |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | -$ | 15 |  |
| Net income attributable to common stock |  | $ | 691 |  |  | $ | 471 |  |  | $ | 3,718 |  |  | +$ | 220 |  |  | -$ | 3,027 |  |
| Earnings per share - diluted |  | $ | 1.64 |  |  | $ | 1.12 |  |  | $ | 8.33 |  |  | +$ | 0.52 |  |  | -$ | 6.69 |  |

[0001193125-19-172516:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the second fiscal quarter were $5,328 million, compared to
$5,093 million at the end of the prior quarter.

[0001193125-19-172516:8k_2_02:25]
During the second fiscal quarter the Company generated $2,667 million in cash from operations
and spent $1,330 million on share repurchases and eliminations consisting of $830 million in repurchases of 2.9 million shares and $500 million on withholding tax payments related to net settled equity awards that vested in the
quarter (representing approximately 1.8 million shares withheld), as well as $125 million on capital expenditures.

[0001193125-19-172516:8k_2_02:26]
On March 29, 2019, the
Company paid a cash dividend of $2.65 per share of common stock, totaling $1,057 million.

[0001193125-19-172516:8k_2_02:27]
2

[0001193125-19-172516:8k_2_02:28]
Second Quarter Fiscal Year 2019 Non-GAAP Results From Continuing
Operations

[0001193125-19-172516:8k_2_02:29]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001193125-19-172516:8k_2_02:30]
Gross margin from continuing operations was $3,971 million, or 72.0 percent of net revenue. This compares with gross margin from continuing
operations of $4,133 million, or 71.4 percent of net revenue, in the prior quarter, and $3,342 million, or 66.6 percent of net revenue, in the same quarter last year.

[0001193125-19-172516:8k_2_02:31]
Operating income from continuing operations was $2,949 million, or 53.5 percent of net revenue. This compares with operating income from continuing
operations of $3,052 million, or 52.7 percent of net revenue, in the prior quarter, and $2,455 million, or 48.9 percent of net revenue, in the same quarter last year.

[0001193125-19-172516:8k_2_02:32]
Net income from continuing operations was $2,334 million, or $5.21 per diluted share. This compares with net income of $2,446 million, or $5.55 per
diluted share, in the prior quarter, and net income of $2,243 million, or $4.88 per diluted share, in the same quarter last year.

[0001193125-19-172516:8k_2_02:33]
Free cash flow
from operations, defined as cash from operations less capital expenditures, was $2,542 million in the quarter, compared to $2,124 million in the same quarter last year.

[0001193125-19-172516:8k_2_02:34]
| Second Quarter Fiscal Year 2019 Non-GAAP Results |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions, except per share data) |  | Q2 19 |  |  | Q1 19 |  |  | Q2 18 |  |  | Q/Q |  |  | Y/Y |  |
| Gross margin |  |  | 72.0 | % |  |  | 71.4 | % |  |  | 66.6 | % |  |  | +60bps |  |  |  | +540bps |  |
| Operating expenses |  | $ | 1,022 |  |  | $ | 1,081 |  |  | $ | 887 |  |  | -$ | 59 |  |  | +$ | 135 |  |
| Net income |  | $ | 2,334 |  |  | $ | 2,446 |  |  | $ | 2,243 |  |  | -$ | 112 |  |  | +$ | 91 |  |
| Earnings per share - diluted |  | $ | 5.21 |  |  | $ | 5.55 |  |  | $ | 4.88 |  |  | -$ | 0.34 |  |  | +$ | 0.33 |  |

[0001193125-19-172516:8k_2_02:35]
Other Quarterly Data

[0001193125-19-172516:8k_2_02:36]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Change |  |
| (Dollars in millions) |  | Q2 19 |  |  | Q1 19 |  |  | Q2 18 |  |  | Q/Q |  |  | Y/Y |  |
| Semiconductor solutions |  | $ | 4,088 |  |  |  | 74 | % |  | $ | 4,374 |  |  |  | 76 | % |  | $ | 4,537 |  |  |  | 90 | % |  |  | -7 | % |  |  | -10 | % |
| Infrastructure software |  |  | 1,413 |  |  |  | 26 |  |  |  | 1,403 |  |  |  | 24 |  |  |  | 447 |  |  |  | 9 |  |  |  | 1 | % |  |  | 216 | % |
| Intellectual property licensing |  |  | 16 |  |  |  | — |  |  |  | 12 |  |  |  | — |  |  |  | 30 |  |  |  | 1 |  |  |  | 33 | % |  |  | -47 | % |
| Total net revenue |  | $ | 5,517 |  |  |  | 100 | % |  | $ | 5,789 |  |  |  | 100 | % |  | $ | 5,014 |  |  |  | 100 | % |  |  |  |  |  |  |  |  |

[0001193125-19-172516:8k_2_02:37]
3

[0001193125-19-172516:8k_2_02:38]
Fiscal Year 2019 Business Outlook

[0001193125-19-172516:8k_2_02:39]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2019, ending November 3, 2019, including
contributions from CA, is expected to be as follows:

[0001193125-19-172516:8k_2_02:40]
|  |  | GAAP |  |  | Reconciling Items |  |  | Non-GAAP |  |
| Net revenue |  | $ | 22,500M |  |  |  | — |  |  | $ | 22,500M |  |
| Operating margin |  |  | 14.75 | % |  | $ | 8,470M |  |  |  | 52.50 | % |
| Net interest expense and other |  | $ | 1,300M |  |  |  | — |  |  | $ | 1,300M |  |
| Provision for (benefit from) income taxes |  |  | -9 | % |  |  | 20 | % |  |  | 11 | % |

[0001193125-19-172516:8k_2_02:41]
|  | • |  | Non-GAAP operating margin excludes $5,210 million of amortization of acquisition-related intangible assets, $2.2 billion of stock-based compensation expense, $820 million of restructuring charges, and $240 million of acquisition-related costs; and |

[0001193125-19-172516:8k_2_02:42]
|  | • |  | Non-GAAP tax provision is 20% higher than GAAP due to the tax effects of the projected reconciling items noted above. |

[0001193125-19-172516:8k_2_02:43]
Capital expenditures for the fiscal year are expected to be approximately
$500 million. For the fiscal year, depreciation is expected to be approximately $600 million and total intangible amortization is expected to be approximately $5,235 million.

[0001193125-19-172516:8k_2_02:44]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. Among other things, this guidance
is based on an initial estimate of purchase accounting adjustments and allocations for CA, Inc., all of which may be revised during the remainder of the measurement period (which will not exceed 12 months from the CA acquisition). The guidance
excludes the impact of any future mergers, acquisitions, divestiture and stock repurchase activity that may occur during fiscal year 2019. Actual results will vary from the guidance and the variations may be material. The Company undertakes no
intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-172516:8k_2_02:45]
Quarterly Dividend

[0001193125-19-172516:8k_2_02:46]
The Company’s Board of Directors
has approved a quarterly cash dividend of $2.65 per share.

[0001193125-19-172516:8k_2_02:47]
The dividend is payable on July 2, 2019 to stockholders of record at the close of
business (5:00 p.m.) Eastern Time on June 24, 2019.

[0001193125-19-172516:8k_2_02:48]
Financial Results Conference Call

[0001193125-19-172516:8k_2_02:49]
Broadcom Inc. will host a conference call to review its financial results for the second quarter of fiscal year 2019, ended May 5, 2019, and discuss
guidance for fiscal year 2019, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The
passcode is 3044229. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and
reference the passcode: 3044229. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001193125-19-172516:8k_2_02:50]
Basis of Presentation

[0001193125-19-172516:8k_2_02:51]
Broadcom Inc. is the successor to
Broadcom Limited for financial reporting purposes effective as of the close of trading on April 4, 2018. Information provided for fiscal periods beginning with the fiscal quarter ended May 6, 2018, relates to Broadcom Inc. and for prior
fiscal periods relates to Broadcom Limited. Unless the context otherwise requires, references in this press release to “Broadcom,” “the Company,” “we,” “our,” “us” and similar terms are to Broadcom
Inc. and, prior to that time, are to our predecessor, Broadcom Limited.

[0001193125-19-172516:8k_2_02:52]
The Company’s financial results include contributions from CA, Inc.’s
continuing operations starting in the first quarter of fiscal year 2019. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented
above, unless otherwise stated.

[0001193125-19-172516:8k_2_02:53]
Due to the Company’s 52/53 week reporting cycle, fiscal year 2018 included an extra week in the first quarter,
compared to fiscal year 2019.

[0001193125-19-172516:8k_2_02:54]
Non-GAAP Financial Measures

[0001193125-19-172516:8k_2_02:55]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash
flow and other data on a non-GAAP basis. This non-GAAP information includes the effect, where applicable, of purchase accounting on revenue, and excludes amortization of
acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements,
impairment on investment, debt-related costs, gain (loss) on extinguishment of debt, gains on investments, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments. Management does
not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core
operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning,
evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items
from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual. Free cash flow measures
have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as
implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-19-172516:8k_2_02:56]
5

[0001193125-19-172516:8k_2_02:57]
Broadcom believes this non-GAAP financial information provides
additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of
the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a
substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data
attached to this press release.

[0001193125-19-172516:8k_2_02:58]
About Broadcom Inc.

[0001193125-19-172516:8k_2_02:59]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad
range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our
solutions include data center networking and storage, enterprise and mainframe software focused on automation, monitoring and security, smartphone components, telecoms and factory automation.

[0001193125-19-172516:8k_2_02:60]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-19-172516:8k_2_02:61]
6

[0001193125-19-172516:8k_2_02:62]
Particular uncertainties that could materially affect future results include risks associated with: our
acquisition of CA, including (1) potential difficulties in employee retention, (2) unexpected costs, charges or expenses, and (3) our ability to successfully integrate CA’s business and achieve the anticipated benefits of the
transaction; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; any other acquisitions we may make, including
integrating acquired companies with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; global economic conditions and concerns; government regulations and trade
restrictions; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence
on and risks associated with distributors of our products; dependence on senior management and our ability to attract and retain qualified personnel; international political and economic conditions; our dependency on a limited number of suppliers;
quarterly and annual fluctuations in operating results; the amount and frequency of our stock repurchases; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins
with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities or other significant operations; our ability to improve our manufacturing efficiency and quality;
involvement in legal or administrative proceedings; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to
protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software
license agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty
and indemnification claims; our ability to sell to new types of customers and to keep pace with technological advances; market acceptance of the end products into which our products are designed; our ability to protect against a breach of security
systems; changes in accounting standards; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in
certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001193125-19-172516:8k_2_02:63]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may
affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made
in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-19-172516:8k_2_02:64]
7

[0001193125-19-172516:8k_2_02:65]
| Contact: Broadcom Inc. Beatrice F. Russotto Investor Relations 408-433-8000 investor.relations@broadcom.com |  |  |

[0001193125-19-172516:8k_2_02:66]
8

[0001193125-19-172516:8k_2_02:67]
BROADCOM INC.

[0001193125-19-172516:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-19-172516:8k_2_02:69]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-19-172516:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 5, |  |  | February 3, |  |  | May 6, |  |  | May 5, |  |  | May 6, |  |
|  |  | 2019 |  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net revenue |  | $ | 5,517 |  |  | $ | 5,789 |  |  | $ | 5,014 |  |  | $ | 11,306 |  |  | $ | 10,341 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,592 |  |  |  | 1,692 |  |  |  | 1,696 |  |  |  | 3,284 |  |  |  | 3,595 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 826 |  |  |  | 833 |  |  |  | 765 |  |  |  | 1,659 |  |  |  | 1,480 |  |
| Restructuring charges |  |  | 10 |  |  |  | 56 |  |  |  | 2 |  |  |  | 66 |  |  |  | 17 |  |
| Total cost of revenue |  |  | 2,428 |  |  |  | 2,581 |  |  |  | 2,463 |  |  |  | 5,009 |  |  |  | 5,162 |  |
| Gross margin |  |  | 3,089 |  |  |  | 3,208 |  |  |  | 2,551 |  |  |  | 6,297 |  |  |  | 5,179 |  |
| Research and development |  |  | 1,151 |  |  |  | 1,133 |  |  |  | 936 |  |  |  | 2,284 |  |  |  | 1,861 |  |
| Selling, general and administrative |  |  | 419 |  |  |  | 471 |  |  |  | 294 |  |  |  | 890 |  |  |  | 585 |  |
| Amortization of acquisition-related intangible assets |  |  | 473 |  |  |  | 476 |  |  |  | 67 |  |  |  | 949 |  |  |  | 406 |  |
| Restructuring, impairment and disposal charges |  |  | 76 |  |  |  | 573 |  |  |  | 53 |  |  |  | 649 |  |  |  | 183 |  |
| Total operating expenses |  |  | 2,119 |  |  |  | 2,653 |  |  |  | 1,350 |  |  |  | 4,772 |  |  |  | 3,035 |  |
| Operating income |  |  | 970 |  |  |  | 555 |  |  |  | 1,201 |  |  |  | 1,525 |  |  |  | 2,144 |  |
| Interest expense |  |  | (376 | ) |  |  | (345 | ) |  |  | (148 | ) |  |  | (721 | ) |  |  | (331 | ) |
| Other income, net |  |  | 63 |  |  |  | 68 |  |  |  | 46 |  |  |  | 131 |  |  |  | 81 |  |
| Income from continuing operations before income taxes |  |  | 657 |  |  |  | 278 |  |  |  | 1,099 |  |  |  | 935 |  |  |  | 1,894 |  |
| Benefit from income taxes |  |  | (36 | ) |  |  | (203 | ) |  |  | (2,637 | ) |  |  | (239 | ) |  |  | (8,423 | ) |
| Income from continuing operations |  |  | 693 |  |  |  | 481 |  |  |  | 3,736 |  |  |  | 1,174 |  |  |  | 10,317 |  |
| Loss from discontinued operations, net of income taxes |  |  | (2 | ) |  |  | (10 | ) |  |  | (3 | ) |  |  | (12 | ) |  |  | (18 | ) |
| Net income |  |  | 691 |  |  |  | 471 |  |  |  | 3,733 |  |  |  | 1,162 |  |  |  | 10,299 |  |
| Net income attributable to noncontrolling interest (1) |  |  | — |  |  |  | — |  |  |  | 15 |  |  |  | — |  |  |  | 351 |  |
| Net income attributable to common stock |  | $ | 691 |  |  | $ | 471 |  |  | $ | 3,718 |  |  | $ | 1,162 |  |  | $ | 9,948 |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.75 |  |  | $ | 1.20 |  |  | $ | 8.84 |  |  | $ | 2.94 |  |  | $ | 24.01 |  |
| Loss per share from discontinued operations |  |  | (0.01 | ) |  |  | (0.03 | ) |  |  | (0.01 | ) |  |  | (0.03 | ) |  |  | (0.04 | ) |
| Net income per share |  | $ | 1.74 |  |  | $ | 1.17 |  |  | $ | 8.83 |  |  | $ | 2.91 |  |  | $ | 23.97 |  |
| Diluted income per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.64 |  |  | $ | 1.15 |  |  | $ | 8.34 |  |  | $ | 2.80 |  |  | $ | 23.03 |  |
| Loss per share from discontinued operations |  |  | — |  |  |  | (0.03 | ) |  |  | (0.01 | ) |  |  | (0.03 | ) |  |  | (0.04 | ) |
| Net income per share |  | $ | 1.64 |  |  | $ | 1.12 |  |  | $ | 8.33 |  |  | $ | 2.77 |  |  | $ | 22.99 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 397 |  |  |  | 401 |  |  |  | 421 |  |  |  | 399 |  |  |  | 415 |  |
| Diluted |  |  | 422 |  |  |  | 419 |  |  |  | 448 |  |  |  | 420 |  |  |  | 448 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 41 |  |  | $ | 34 |  |  | $ | 21 |  |  | $ | 75 |  |  | $ | 41 |  |
| Research and development |  |  | 371 |  |  |  | 311 |  |  |  | 205 |  |  |  | 682 |  |  |  | 408 |  |
| Selling, general and administrative |  |  | 132 |  |  |  | 120 |  |  |  | 70 |  |  |  | 252 |  |  |  | 146 |  |
| Total stock-based compensation expense |  | $ | 544 |  |  | $ | 465 |  |  | $ | 296 |  |  | $ | 1,009 |  |  | $ | 595 |  |

[0001193125-19-172516:8k_2_02:71]
| (1) | In connection with the redomiciliation to the United States on April 4, 2018, or the Redomiciliation, all outstanding exchangeable limited partnership units, or LP Units, in Broadcom Cayman L.P. were exchanged for common stock of Broadcom on a one-for-one basis and the noncontrolling interest, or NCI, was eliminated. Net income attributable to NCI prior to the Redomiciliation represents approximately 5% of net income attributable to LP Units. |

[0001193125-19-172516:8k_2_02:72]
| (2) | There were no LP Units outstanding during the fiscal quarters ended May 5, 2019, February 3, 2019, or two fiscal quarters ended May 5, 2019 due to the Redomiciliation. The diluted income per share calculations include approximately 14 million and 18 million LP Units for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively. |

[0001193125-19-172516:8k_2_02:73]
BROADCOM INC.

[0001193125-19-172516:8k_2_02:74]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-19-172516:8k_2_02:75]
(IN MILLIONS)

[0001193125-19-172516:8k_2_02:76]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 5,2019 |  |  | February 3,2019 |  |  | May 6,2018 |  |  | May 5,2019 |  |  | May 6,2018 |  |
| Net revenue on GAAP basis |  | $ | 5,517 |  |  | $ | 5,789 |  |  | $ | 5,014 |  |  | $ | 11,306 |  |  | $ | 10,341 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |
| Net revenue on non-GAAP basis |  | $ | 5,517 |  |  | $ | 5,789 |  |  | $ | 5,017 |  |  | $ | 11,306 |  |  | $ | 10,348 |  |
| Gross margin on GAAP basis |  | $ | 3,089 |  |  | $ | 3,208 |  |  | $ | 2,551 |  |  | $ | 6,297 |  |  | $ | 5,179 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 826 |  |  |  | 833 |  |  |  | 765 |  |  |  | 1,659 |  |  |  | 1,480 |  |
| Stock-based compensation expense |  |  | 41 |  |  |  | 34 |  |  |  | 21 |  |  |  | 75 |  |  |  | 41 |  |
| Restructuring charges |  |  | 10 |  |  |  | 56 |  |  |  | 2 |  |  |  | 66 |  |  |  | 17 |  |
| Acquisition-related costs |  |  | 5 |  |  |  | 2 |  |  |  | — |  |  |  | 7 |  |  |  | 2 |  |
| Gross margin on non-GAAP basis |  | $ | 3,971 |  |  | $ | 4,133 |  |  | $ | 3,342 |  |  | $ | 8,104 |  |  | $ | 6,796 |  |
| Research and development on GAAP basis |  | $ | 1,151 |  |  | $ | 1,133 |  |  | $ | 936 |  |  | $ | 2,284 |  |  | $ | 1,861 |  |
| Stock-based compensation expense |  |  | 371 |  |  |  | 311 |  |  |  | 205 |  |  |  | 682 |  |  |  | 408 |  |
| Acquisition-related costs |  |  | 1 |  |  |  | 2 |  |  |  | — |  |  |  | 3 |  |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 779 |  |  | $ | 820 |  |  | $ | 731 |  |  | $ | 1,599 |  |  | $ | 1,450 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 419 |  |  | $ | 471 |  |  | $ | 294 |  |  | $ | 890 |  |  | $ | 585 |  |
| Stock-based compensation expense |  |  | 132 |  |  |  | 120 |  |  |  | 70 |  |  |  | 252 |  |  |  | 146 |  |
| Acquisition-related costs |  |  | 44 |  |  |  | 90 |  |  |  | 68 |  |  |  | 134 |  |  |  | 119 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 243 |  |  | $ | 261 |  |  | $ | 156 |  |  | $ | 504 |  |  | $ | 320 |  |
| Total operating expenses on GAAP basis |  | $ | 2,119 |  |  | $ | 2,653 |  |  | $ | 1,350 |  |  | $ | 4,772 |  |  | $ | 3,035 |  |
| Amortization of acquisition-related intangible assets |  |  | 473 |  |  |  | 476 |  |  |  | 67 |  |  |  | 949 |  |  |  | 406 |  |
| Stock-based compensation expense |  |  | 503 |  |  |  | 431 |  |  |  | 275 |  |  |  | 934 |  |  |  | 554 |  |
| Restructuring, impairment and disposal charges |  |  | 76 |  |  |  | 573 |  |  |  | 53 |  |  |  | 649 |  |  |  | 183 |  |
| Acquisition-related costs |  |  | 45 |  |  |  | 92 |  |  |  | 68 |  |  |  | 137 |  |  |  | 122 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,022 |  |  | $ | 1,081 |  |  | $ | 887 |  |  | $ | 2,103 |  |  | $ | 1,770 |  |
| Operating income on GAAP basis |  | $ | 970 |  |  | $ | 555 |  |  | $ | 1,201 |  |  | $ | 1,525 |  |  | $ | 2,144 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,299 |  |  |  | 1,309 |  |  |  | 832 |  |  |  | 2,608 |  |  |  | 1,886 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 465 |  |  |  | 296 |  |  |  | 1,009 |  |  |  | 595 |  |
| Restructuring, impairment and disposal charges |  |  | 86 |  |  |  | 629 |  |  |  | 55 |  |  |  | 715 |  |  |  | 200 |  |
| Acquisition-related costs |  |  | 50 |  |  |  | 94 |  |  |  | 68 |  |  |  | 144 |  |  |  | 124 |  |
| Operating income on non-GAAP basis |  | $ | 2,949 |  |  | $ | 3,052 |  |  | $ | 2,455 |  |  | $ | 6,001 |  |  | $ | 5,026 |  |
| Interest expense on GAAP basis |  | $ | (376 | ) |  | $ | (345 | ) |  | $ | (148 | ) |  | $ | (721 | ) |  | $ | (331 | ) |
| Debt-related costs |  |  | 26 |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  | 32 |  |
| Interest expense on non-GAAP basis |  | $ | (350 | ) |  | $ | (345 | ) |  | $ | (148 | ) |  | $ | (695 | ) |  | $ | (299 | ) |
| Other income, net on GAAP basis |  | $ | 63 |  |  | $ | 68 |  |  | $ | 46 |  |  | $ | 131 |  |  | $ | 81 |  |
| Gains on investments |  |  | (40 | ) |  |  | (27 | ) |  |  | (4 | ) |  |  | (67 | ) |  |  | (4 | ) |
| Other income, net on non-GAAP basis |  | $ | 23 |  |  | $ | 41 |  |  | $ | 42 |  |  | $ | 64 |  |  | $ | 77 |  |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 657 |  |  | $ | 278 |  |  | $ | 1,099 |  |  | $ | 935 |  |  | $ | 1,894 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,299 |  |  |  | 1,309 |  |  |  | 832 |  |  |  | 2,608 |  |  |  | 1,886 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 465 |  |  |  | 296 |  |  |  | 1,009 |  |  |  | 595 |  |
| Restructuring, impairment and disposal charges |  |  | 86 |  |  |  | 629 |  |  |  | 55 |  |  |  | 715 |  |  |  | 200 |  |
| Acquisition-related costs |  |  | 50 |  |  |  | 94 |  |  |  | 68 |  |  |  | 144 |  |  |  | 124 |  |
| Debt-related costs |  |  | 26 |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  | 32 |  |
| Gains on investments |  |  | (40 | ) |  |  | (27 | ) |  |  | (4 | ) |  |  | (67 | ) |  |  | (4 | ) |
| Income before income taxes on non-GAAP basis |  | $ | 2,622 |  |  | $ | 2,748 |  |  | $ | 2,349 |  |  | $ | 5,370 |  |  | $ | 4,804 |  |
| Benefit from income taxes on GAAP basis |  | $ | (36 | ) |  | $ | (203 | ) |  | $ | (2,637 | ) |  | $ | (239 | ) |  | $ | (8,423 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 324 |  |  |  | 505 |  |  |  | 2,743 |  |  |  | 829 |  |  |  | 8,639 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 288 |  |  | $ | 302 |  |  | $ | 106 |  |  | $ | 590 |  |  | $ | 216 |  |
| Net income on GAAP basis |  | $ | 691 |  |  | $ | 471 |  |  | $ | 3,733 |  |  | $ | 1,162 |  |  | $ | 10,299 |  |
| Acquisition-related purchase accounting revenue adjustment (1) |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |
| Purchase accounting effect on inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,299 |  |  |  | 1,309 |  |  |  | 832 |  |  |  | 2,608 |  |  |  | 1,886 |  |
| Stock-based compensation expense |  |  | 544 |  |  |  | 465 |  |  |  | 296 |  |  |  | 1,009 |  |  |  | 595 |  |
| Restructuring, impairment and disposal charges |  |  | 86 |  |  |  | 629 |  |  |  | 55 |  |  |  | 715 |  |  |  | 200 |  |
| Acquisition-related costs |  |  | 50 |  |  |  | 94 |  |  |  | 68 |  |  |  | 144 |  |  |  | 124 |  |
| Debt-related costs |  |  | 26 |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  | 32 |  |
| Gains on investments |  |  | (40 | ) |  |  | (27 | ) |  |  | (4 | ) |  |  | (67 | ) |  |  | (4 | ) |
| Non-GAAP tax reconciling adjustments |  |  | (324 | ) |  |  | (505 | ) |  |  | (2,743 | ) |  |  | (829 | ) |  |  | (8,639 | ) |
| Discontinued operations, net of income taxes |  |  | 2 |  |  |  | 10 |  |  |  | 3 |  |  |  | 12 |  |  |  | 18 |  |
| Net income on non-GAAP basis |  | $ | 2,334 |  |  | $ | 2,446 |  |  | $ | 2,243 |  |  | $ | 4,780 |  |  | $ | 4,588 |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 422 |  |  |  | 419 |  |  |  | 448 |  |  |  | 420 |  |  |  | 448 |  |
| Non-GAAP adjustment (2) |  |  | 26 |  |  |  | 22 |  |  |  | 12 |  |  |  | 25 |  |  |  | 11 |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 448 |  |  |  | 441 |  |  |  | 460 |  |  |  | 445 |  |  |  | 459 |  |
| Net income on non-GAAP basis |  | $ | 2,334 |  |  | $ | 2,446 |  |  | $ | 2,243 |  |  | $ | 4,780 |  |  | $ | 4,588 |  |
| Interest expense on non-GAAP basis |  |  | 350 |  |  |  | 345 |  |  |  | 148 |  |  |  | 695 |  |  |  | 299 |  |
| Provision for income taxes on non-GAAP basis |  |  | 288 |  |  |  | 302 |  |  |  | 106 |  |  |  | 590 |  |  |  | 216 |  |
| Depreciation |  |  | 142 |  |  |  | 143 |  |  |  | 128 |  |  |  | 285 |  |  |  | 254 |  |
| Adjusted EBITDA |  | $ | 3,114 |  |  | $ | 3,236 |  |  | $ | 2,625 |  |  | $ | 6,350 |  |  | $ | 5,357 |  |
| Net cash provided by operating activities |  | $ | 2,667 |  |  | $ | 2,132 |  |  | $ | 2,313 |  |  | $ | 4,799 |  |  | $ | 3,998 |  |
| Purchases of property, plant and equipment |  |  | (125 | ) |  |  | (99 | ) |  |  | (189 | ) |  |  | (224 | ) |  |  | (409 | ) |
| Free cash flow |  | $ | 2,542 |  |  | $ | 2,033 |  |  | $ | 2,124 |  |  | $ | 4,575 |  |  | $ | 3,589 |  |
|  |  | Fiscal Quarter Ending |  |  |  |  |  |  |  |  |  |  |
| Expected fully diluted share count: |  | August 4,2019 |  |  | November 3,2019 |  |  |  |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis |  |  | 419 |  |  |  | 420 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustment (2) |  |  | 25 |  |  |  | 23 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  |  | 444 |  |  |  | 443 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001193125-19-172516:8k_2_02:77]
| (1) | Amounts represent licensing revenue not included in GAAP net revenue as a result of the effect of purchase accounting for acquisitions. |

[0001193125-19-172516:8k_2_02:78]
| (2) | Non-GAAP adjustment for number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |

[0001193125-19-172516:8k_2_02:79]
BROADCOM INC.

[0001193125-19-172516:8k_2_02:80]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-19-172516:8k_2_02:81]
(IN MILLIONS)

[0001193125-19-172516:8k_2_02:82]
|  |  | May 5,2019 |  |  | November 4,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 5,328 |  |  | $ | 4,292 |  |
| Trade accounts receivable, net |  |  | 3,484 |  |  |  | 3,325 |  |
| Inventory |  |  | 1,034 |  |  |  | 1,124 |  |
| Other current assets |  |  | 831 |  |  |  | 366 |  |
| Total current assets |  |  | 10,677 |  |  |  | 9,107 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,654 |  |  |  | 2,635 |  |
| Goodwill |  |  | 36,662 |  |  |  | 26,913 |  |
| Intangible assets, net |  |  | 20,188 |  |  |  | 10,762 |  |
| Other long-term assets |  |  | 735 |  |  |  | 707 |  |
| Total assets |  | $ | 70,916 |  |  | $ | 50,124 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 759 |  |  | $ | 811 |  |
| Employee compensation and benefits |  |  | 478 |  |  |  | 715 |  |
| Current portion of long-term debt |  |  | 3,537 |  |  |  | — |  |
| Other current liabilities |  |  | 3,729 |  |  |  | 812 |  |
| Total current liabilities |  |  | 8,503 |  |  |  | 2,338 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 34,011 |  |  |  | 17,493 |  |
| Other long-term liabilities |  |  | 6,230 |  |  |  | 3,636 |  |
| Total liabilities |  |  | 48,744 |  |  |  | 23,467 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock and additional paid-in capital |  |  | 22,288 |  |  |  | 23,285 |  |
| Retained earnings |  |  | — |  |  |  | 3,487 |  |
| Accumulated other comprehensive loss |  |  | (116 | ) |  |  | (115 | ) |
| Total stockholders’ equity |  |  | 22,172 |  |  |  | 26,657 |  |
| Total liabilities and stockholders’ equity |  | $ | 70,916 |  |  | $ | 50,124 |  |

[0001193125-19-172516:8k_2_02:83]
BROADCOM INC.

[0001193125-19-172516:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-19-172516:8k_2_02:85]
(IN MILLIONS)

[0001193125-19-172516:8k_2_02:86]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 5,2019 |  |  | February 3,2019 |  |  | May 6,2018 |  |  | May 5,2019 |  |  | May 6,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 691 |  |  | $ | 471 |  |  | $ | 3,733 |  |  | $ | 1,162 |  |  | $ | 10,299 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 1,305 |  |  |  | 1,316 |  |  |  | 836 |  |  |  | 2,621 |  |  |  | 1,894 |  |
| Depreciation |  |  | 142 |  |  |  | 143 |  |  |  | 128 |  |  |  | 285 |  |  |  | 254 |  |
| Stock-based compensation |  |  | 544 |  |  |  | 465 |  |  |  | 296 |  |  |  | 1,009 |  |  |  | 595 |  |
| Deferred taxes and other non-cash taxes |  |  | (94 | ) |  |  | (379 | ) |  |  | (2,702 | ) |  |  | (473 | ) |  |  | (8,534 | ) |
| Non-cash restructuring, impairment and disposal charges |  |  | 6 |  |  |  | 92 |  |  |  | 5 |  |  |  | 98 |  |  |  | 10 |  |
| Non-cash interest expense |  |  | 14 |  |  |  | 13 |  |  |  | 6 |  |  |  | 27 |  |  |  | 12 |  |
| Other |  |  | (39 | ) |  |  | (21 | ) |  |  | 14 |  |  |  | (60 | ) |  |  | 17 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | 193 |  |  |  | 68 |  |  |  | (277 | ) |  |  | 261 |  |  |  | (78 | ) |
| Inventory |  |  | 40 |  |  |  | 50 |  |  |  | 56 |  |  |  | 90 |  |  |  | 306 |  |
| Accounts payable |  |  | 30 |  |  |  | (169 | ) |  |  | 91 |  |  |  | (139 | ) |  |  | (312 | ) |
| Employee compensation and benefits |  |  | (6 | ) |  |  | (458 | ) |  |  | 84 |  |  |  | (464 | ) |  |  | (292 | ) |
| Contributions to defined benefit pension plans |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (129 | ) |
| Other current assets and current liabilities |  |  | (37 | ) |  |  | 506 |  |  |  | 70 |  |  |  | 469 |  |  |  | 354 |  |
| Other long-term assets and long-term liabilities |  |  | (122 | ) |  |  | 35 |  |  |  | (27 | ) |  |  | (87 | ) |  |  | (398 | ) |
| Net cash provided by operating activities |  |  | 2,667 |  |  |  | 2,132 |  |  |  | 2,313 |  |  |  | 4,799 |  |  |  | 3,998 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (16,027 | ) |  |  | — |  |  |  | (16,027 | ) |  |  | (4,786 | ) |
| Proceeds from sales of businesses |  |  | — |  |  |  | 957 |  |  |  | — |  |  |  | 957 |  |  |  | 782 |  |
| Purchases of property, plant and equipment |  |  | (125 | ) |  |  | (99 | ) |  |  | (189 | ) |  |  | (224 | ) |  |  | (409 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 238 |  |
| Purchases of investments |  |  | (5 | ) |  |  | — |  |  |  | (5 | ) |  |  | (5 | ) |  |  | (249 | ) |
| Proceeds from sales of investments |  |  | 3 |  |  |  | — |  |  |  | 54 |  |  |  | 3 |  |  |  | 54 |  |
| Other |  |  | 21 |  |  |  | (24 | ) |  |  | (16 | ) |  |  | (3 | ) |  |  | (12 | ) |
| Net cash used in investing activities |  |  | (106 | ) |  |  | (15,193 | ) |  |  | (155 | ) |  |  | (15,299 | ) |  |  | (4,382 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | 10,897 |  |  |  | 17,896 |  |  |  | — |  |  |  | 28,793 |  |  |  | — |  |
| Repayment of debt |  |  | (12,000 | ) |  |  | — |  |  |  | — |  |  |  | (12,000 | ) |  |  | (856 | ) |
| Payment of debt issuance costs |  |  | — |  |  |  | (46 | ) |  |  | — |  |  |  | (46 | ) |  |  | — |  |
| Other borrowings |  |  | 1,044 |  |  |  | 531 |  |  |  | — |  |  |  | 1,575 |  |  |  | — |  |
| Dividend and distribution payments |  |  | (1,057 | ) |  |  | (1,067 | ) |  |  | (766 | ) |  |  | (2,124 | ) |  |  | (1,521 | ) |
| Repurchases of common stock—repurchase program |  |  | (830 | ) |  |  | (3,436 | ) |  |  | (347 | ) |  |  | (4,266 | ) |  |  | (347 | ) |
| Shares repurchased for tax witholdings on vesting of equity awards |  |  | (500 | ) |  |  | (77 | ) |  |  | (2 | ) |  |  | (577 | ) |  |  | (2 | ) |
| Issuance of common stock |  |  | 121 |  |  |  | 62 |  |  |  | 80 |  |  |  | 183 |  |  |  | 114 |  |
| Other |  |  | (1 | ) |  |  | (1 | ) |  |  | (12 | ) |  |  | (2 | ) |  |  | (21 | ) |
| Net cash provided by (used in) financing activities |  |  | (2,326 | ) |  |  | 13,862 |  |  |  | (1,047 | ) |  |  | 11,536 |  |  |  | (2,633 | ) |
| Net change in cash and cash equivalents |  |  | 235 |  |  |  | 801 |  |  |  | 1,111 |  |  |  | 1,036 |  |  |  | (3,017 | ) |
| Cash and cash equivalents at the beginning of period |  |  | 5,093 |  |  |  | 4,292 |  |  |  | 7,076 |  |  |  | 4,292 |  |  |  | 11,204 |  |
| Cash and cash equivalents at end of period |  | $ | 5,328 |  |  | $ | 5,093 |  |  | $ | 8,187 |  |  | $ | 5,328 |  |  | $ | 8,187 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 189 |  |  | $ | 423 |  |  | $ | 1 |  |  | $ | 612 |  |  | $ | 233 |  |
| Cash paid for income taxes |  | $ | 425 |  |  | $ | 95 |  |  | $ | 87 |  |  | $ | 520 |  |  | $ | 196 |  |

## item 5.02 — body, verbatim

[0001193125-19-172516:8k_body:1]
Item 5.02.

[0001193125-19-172516:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers;
Compensatory Arrangements of Certain Officers.

[0001193125-19-172516:8k_body:3]
New Director Appointment

[0001193125-19-172516:8k_body:4]
Effective June 11, 2019, the Company’s Board of Directors (the “Board”) appointed Justine F. Page as an independent
director of the Company.

[0001193125-19-172516:8k_body:5]
Ms. Page served as the Chief Financial Officer, Vice President of Finance, Treasurer, and Secretary of
Integrated Circuit Systems, Inc., from May 1999 to September 2005 when ICS merged with Integrated Device Technologies, Inc., following which Ms. Page retired. She joined ICS in 1993, holding titles including Director of Finance and
Administration and Assistant Treasurer. From June 2008 until April 2017, Ms. Page served on the board of our predecessors, including Avago Technologies and Broadcom Limited, and served as chairperson of its Audit Committee and a member of its
Nominating and Corporate Governance Committee. Ms. Page also served as a director and chairperson of the audit committee of SunEdison Semiconductor Limited from May 2014 until December 2016, and served as a director of Techwell, Inc. from
January 2006 until July 2010, where she also served as the chairperson of the audit committee. Ms. Page holds a B.A. degree in accounting from Immaculata College and a Master of Taxation degree from Villanova University. Ms. Page’s
qualifications to serve on our Board include her career in senior financial management positions with, and on the board of directors of, semiconductor companies, and her education and training as an accounting professional.

[0001193125-19-172516:8k_body:6]
Ms. Page will participate in the non-employee director compensation arrangements generally
applicable to all of the Company’s non-employee directors. Under the terms of those arrangements, as currently in effect, Ms. Page received an initial restricted stock unit award with a value of
$183,333 on June 11, 2019, her first date of service as a director, which will vest in full on the earlier of (i) the first anniversary of the grant date and (ii) the date on which the Company’s annual meeting of stockholders
immediately following the grant date is held, subject to her continuing service on the vesting date. The number of shares subject to this award was determined by dividing the value of the award by the average of the Company’s per share closing
market prices, as quoted on the Nasdaq Global Select Market, over the 30 calendar days immediately preceding June 11, 2019. In addition, Ms. Page will be entitled to receive the annual cash and equity compensation payable to other non-employee directors of the Company. Details regarding the Company’s non-employee director compensation program are set forth in the Company’s Proxy Statement
related to its 2019 Annual Meeting of Stockholders, filed with the Securities and Exchange Commission on February 19, 2019.

[0001193125-19-172516:8k_body:7]
Committee Changes

[0001193125-19-172516:8k_body:8]
Effective June 11, 2019, the Board appointed Ms. Page as the Chairman of the Audit Committee and as a member of the
Executive Committee. In connection with Ms. Page’s appointment to the Audit Committee, Peter Marks stepped down from the Audit Committee and the Board appointed Mr. Marks as a member of the Compensation Committee.
