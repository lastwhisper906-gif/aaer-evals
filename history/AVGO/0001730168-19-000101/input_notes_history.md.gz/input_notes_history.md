# AVGO note change history — 0001730168-19-000036 → 0001730168-19-000101


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:1]
Commitments and Contingencies
Commitments
  (was, 2019-03-15, similarity 0.8286):
[0001730168-19-000036:note_history:1]
Commitments and Contingencies

- changed (2019-06-14):
[0001730168-19-000101:note_history:2]
The following table summarizes contractual obligations and commitments as of May 5, 2019 that materially changed from the end of fiscal year 2018:
  (was, 2019-03-15, similarity 0.9753):
[0001730168-19-000036:note_history:2]
The following table summarizes contractual obligations and commitments as of February 3, 2019 that materially changed from the end of fiscal year 2018:

- added (2019-06-14):
[0001730168-19-000101:note_history:3]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on borrowings under the 2019 Senior Notes, Commercial Paper, term A-5 facility, Revolving Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our term A-5 facility, which was subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 5, 2019.

- added (2019-06-14):
[0001730168-19-000101:note_history:4]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including

- added (2019-06-14):
[0001730168-19-000101:note_history:5]
fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

- changed (2019-06-14):
[0001730168-19-000101:note_history:6]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $59 million and $126 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Rent expense was $56 million and $127 million for the fiscal quarter and two fiscal quarters ended May 6, 2018, respectively.
  (was, 2019-03-15, similarity 0.7034):
[0001730168-19-000036:note_history:6]
Operating Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable operating leases. Rent expense was $67 million and $71 million for the fiscal quarters ended February 3, 2019 and February 4, 2018, respectively.

- changed (2019-06-14):
[0001730168-19-000101:note_history:7]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 5, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,356 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 5, 2019 have been excluded from the contractual obligations table above.
  (was, 2019-03-15, similarity 0.9816):
[0001730168-19-000036:note_history:7]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 3, 2019, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,250 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 3, 2019 have been excluded from the contractual obligations table above.

- changed (2019-06-14):
[0001730168-19-000101:note_history:8]
As of May 5, 2019 and November 4, 2018, we had standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.
  (was, 2019-03-15, similarity 0.8425):
[0001730168-19-000036:note_history:8]
As of February 3, 2019 and November 4, 2018, we had outstanding obligations relating to standby letters of credit of $68 million and $14 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees. The fair values of the letters of credit approximate the contract amounts.

- added (2019-06-14):
[0001730168-19-000101:note_history:9]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”). On January 4, 2019, the U.S. Supreme Court granted certiorari. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth

- added (2019-06-14):
[0001730168-19-000101:note_history:10]
Circuit Court remanded the case back to the U.S. Central District Court. We believe these claims are all without merit and intend to vigorously defend these actions.

- added (2019-06-14):
[0001730168-19-000101:note_history:11]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

- added (2019-06-14):
[0001730168-19-000101:note_history:12]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

- removed (2019-06-14):
[0001730168-19-000036:note_history:13]
Commitments

- removed (2019-06-14):
[0001730168-19-000036:note_history:14]
Debt Principal, Interest and Fees. Represents principal and estimated interest on borrowings under the 2019 Term Loans, Revolver Facility, 2017 Senior Notes, the Assumed CA Senior Notes, the Assumed BRCM Senior Notes, and the Assumed Brocade Convertible Notes. For our 2019 Term Loans, which are subject to a floating interest rate, the estimated interest was based on the interest rate in place during the last month of the fiscal quarter ended February 3, 2019.

- removed (2019-06-14):
[0001730168-19-000036:note_history:15]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with internal fabrication facility expansion and construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

- removed (2019-06-14):
[0001730168-19-000036:note_history:16]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation, or Emulex, its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit, or the Ninth Circuit Court, on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court. On January 4, 2019, the United States Supreme Court granted certiorari. On February 19, 2019, the Defendants-Appellees (as Petitioners in the United States Supreme Court) filed their opening brief. The Plaintiff-Appellant’s brief is to be filed by March 21, 2019 and oral arguments are scheduled for April 15, 2019. We believe these claims are all without merit and intend to vigorously defend these actions.

- removed (2019-06-14):
[0001730168-19-000036:note_history:17]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, taken individually or as a whole, will have a material adverse effect on our financial condition, results of operations or cash flows. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

- removed (2019-06-14):
[0001730168-19-000036:note_history:18]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our results of operations, financial position or cash flows.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:19]
Overview, Basis of Presentation and Significant Accounting Policies
Overview
  (was, 2019-03-15, similarity 0.9371):
[0001730168-19-000036:note_history:19]
Overview, Basis of Presentation and Significant Accounting Policies

- added (2019-06-14):
[0001730168-19-000101:note_history:20]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

- changed (2019-06-14):
[0001730168-19-000101:note_history:21]
The financial statements relate to Broadcom-Singapore for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, and relate to Broadcom for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.
  (was, 2019-03-15, similarity 0.766):
[0001730168-19-000036:note_history:21]
The financial statements for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, relate to Broadcom-Singapore and relate to Broadcom Inc. for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom Inc. and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

- changed (2019-06-14):
[0001730168-19-000101:note_history:22]
On November 5, 2018, we acquired CA, Inc. (“CA”) for $16.1 billion, net of cash acquired (the “CA Merger”). CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018 (the “CA Acquisition Date”). See Note 3. “Acquisitions” for additional information.
  (was, 2019-03-15, similarity 0.7951):
[0001730168-19-000036:note_history:22]
On November 5, 2018, we acquired CA, Inc., or CA, for $16.1 billion, net of cash acquired, or the CA Merger. CA was a leading provider of information technology management software and solutions. The results of operations of CA are included in the unaudited condensed consolidated financial statements commencing as of November 5, 2018, or the CA Acquisition Date. See Note 3. “Acquisitions” for additional information.

- added (2019-06-14):
[0001730168-19-000101:note_history:23]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property (“IP”) licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

- changed (2019-06-14):
[0001730168-19-000101:note_history:24]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019 (“fiscal year 2019”) is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ended on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.
  (was, 2019-03-15, similarity 0.9242):
[0001730168-19-000036:note_history:24]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2019, or fiscal year 2019, is a 52-week fiscal year. The first quarter of our fiscal year 2019 ended on February 3, 2019, the second quarter ends on May 5, 2019 and the third quarter ends on August 4, 2019. Our fiscal year ended November 4, 2018, or fiscal year 2018, was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.

- changed (2019-06-14):
[0001730168-19-000101:note_history:25]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission (“SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 5, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.
  (was, 2019-03-15, similarity 0.9405):
[0001730168-19-000036:note_history:25]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and our subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States, or GAAP, for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 4, 2018 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2018 as filed with the Securities and Exchange Commission, or SEC, but do not include all disclosures required by GAAP. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 3, 2019 are not necessarily indicative of the results that may be expected for fiscal year 2019, or for any other future period.

- changed (2019-06-14):
[0001730168-19-000101:note_history:26]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board (“FASB”) guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.
  (was, 2019-03-15, similarity 0.9934):
[0001730168-19-000036:note_history:26]
In the first quarter of fiscal year 2019, we adopted the Financial Accounting Standards Board, or FASB, guidance issued in March 2017 that requires an employer to present the service cost component of net periodic benefit cost in the same income statement line item as other employee compensation costs arising from services rendered during the period. Other components of the net periodic benefit cost are presented separately from the service cost component. We adopted the guidance using a permitted practical expedient that uses the amounts disclosed in the pension and other post-retirement benefit plans note for the prior comparative periods as the estimation basis for applying the retrospective presentation requirements. The adoption did not have a material impact on the condensed consolidated statements of operations presented herein.

- changed (2019-06-14):
[0001730168-19-000101:note_history:27]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at cost less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter and two fiscal quarters ended May 5, 2019, we also recognized $40 million and $67 million, respectively, of unrealized gains on equity securities within other income, net in our condensed consolidated statements of operations.
  (was, 2019-03-15, similarity 0.8837):
[0001730168-19-000036:note_history:27]
In the first quarter of fiscal year 2019, we adopted the guidance issued in January 2016 that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. This guidance requires the remeasurement of equity investments not accounted for under the equity method to be measured at fair value and any changes in fair value recognized in net income. The guidance allows for election of a measurement alternative for equity securities without readily determinable fair values to be measured at costs less impairment, adjusted for observable price changes. We adopted this guidance using the modified retrospective method for our marketable equity securities and a prospective approach for non-marketable equity securities using the measurement alternative. Upon adoption, we recognized an $8 million increase to retained earnings and a $1 million increase to accumulated other comprehensive loss. During the fiscal quarter ended February 3, 2019, we also recognized $27 million of unrealized gains on equity securities within other income, net in our condensed consolidated statement of operations.

- added (2019-06-14):
[0001730168-19-000101:note_history:28]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (“Topic 606”). We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. “Revenue from Contracts with Customers” for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.

- removed (2019-06-14):
[0001730168-19-000036:note_history:29]
Overview

- removed (2019-06-14):
[0001730168-19-000036:note_history:30]
Broadcom Inc., or Broadcom, a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company, or Broadcom-Singapore. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom Inc. common stock, or the Redomiciliation Transaction. As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom Inc. In addition, all outstanding exchangeable limited partnership units, or LP Units, of Broadcom Cayman L.P., or the Partnership, were mandatorily exchanged, or the Mandatory Exchange, for newly issued shares of Broadcom Inc. common stock and all limited partners of the Partnership became common stockholders of Broadcom Inc. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

- removed (2019-06-14):
[0001730168-19-000036:note_history:31]
Subsequent to the CA Merger, we changed our organizational structure, resulting in three reportable segments: semiconductor solutions, infrastructure software and intellectual property, or IP, licensing. Prior period segment results have been recast to conform to the current presentation. See Note 10. “Segment Information” for additional information.

- removed (2019-06-14):
[0001730168-19-000036:note_history:32]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, or Topic 606. We adopted Topic 606 effective November 5, 2018 using the modified retrospective method. Reporting periods prior to the adoption of the new revenue standard are presented in accordance with Accounting Standards Codification 605, Revenue Recognition, or Topic 605, while reporting periods after adoption are presented in accordance with the new revenue standard. The cumulative effect adjustment as of November 5, 2018 to retained earnings was not significant. See Note 2. "Revenue from Contracts with Customers" for further information related to adoption of the new revenue standard, including our updated revenue accounting policies and accounting policies for costs to obtain and fulfill a contract with a customer. Refer to our Annual Report on Form 10-K for our accounting policies in accordance with Topic 605.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:33]
The future scheduled principal payments of debt as of May 5, 2019 were as follows:
  (was, 2019-03-15, similarity 0.9383):
[0001730168-19-000036:note_history:33]
The future scheduled principal payments for debt as of February 3, 2019 were as follows:

- changed (2019-06-14):
[0001730168-19-000101:note_history:34]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 1,000 |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 3,650 |  |
| 2022 |  | 6,409 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 20,713 |  |
| Total |  | $ | 37,859 |  |
  (was, 2019-03-15, similarity 0.9952):
[0001730168-19-000036:note_history:34]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | — |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 1,650 |  |
| 2022 |  | 13,909 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 16,213 |  |
| Total |  | $ | 37,859 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:35]
|  |  | Effective Interest Rate |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through November 2023 |  | 3.852 | % |  | 6,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 0.289 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (311 | ) |  | (116 | ) |
| Total Debt |  |  |  | $ | 37,548 |  |  | $ | 17,493 |  |
  (was, 2019-03-15, similarity 0.838):
[0001730168-19-000036:note_history:35]
|  |  | Effective Interest Rate |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2021 |  | 3.853 | % |  | $ | 9,000 |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due September 2021 to November 2023 |  | 3.892 | % |  | 9,000 |  |  | — |  |
|  |  |  |  | 18,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount, premium and unamortized debt issuance costs |  |  |  | (218 | ) |  | (116 | ) |
| Total carrying value of debt |  |  |  | $ | 37,641 |  |  | $ | 17,493 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:36]
________________________________

- added (2019-06-14):
[0001730168-19-000101:note_history:37]
(a) Represents the weighted average interest rate on outstanding commercial paper as of May 5, 2019.

- added (2019-06-14):
[0001730168-19-000101:note_history:38]
Fiscal Year 2019 Financing Arrangements

- changed (2019-06-14):
[0001730168-19-000101:note_history:39]
In connection with the CA Merger, we entered into a credit agreement (the “2019 Credit Agreement”), which provided for a $9 billion unsecured term A-3 facility and a $9 billion unsecured term A-5 facility, collectively referred to as the “2019 Term Loans”. Interest on our 2019 Term Loans was based on a floating rate and was payable monthly. Our obligations under the 2019 Credit Agreement were guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”), Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee having been provided by Broadcom-Singapore  pending its voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019).
  (was, 2019-03-15, similarity 0.7837):
[0001730168-19-000036:note_history:39]
In connection with the CA Merger, we entered into a credit agreement, or the 2019 Credit Agreement, which provides for a $9,000 million unsecured term A-3 facility and a $9,000 million unsecured term A-5 facility, collectively referred to as the 2019 Term Loans. Interest on our 2019 Term Loans is based on a floating rate and is payable monthly. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation, or BRCM, Broadcom Cayman Finance Limited and Broadcom Technologies Inc., with a residual guarantee being provided by Broadcom-Singapore until its pending voluntary liquidation (commenced in the fiscal quarter ended February 3, 2019) is finalized.

- changed (2019-06-14):
[0001730168-19-000101:note_history:40]
The 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we were permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on May 5, 2019.
  (was, 2019-03-15, similarity 0.7915):
[0001730168-19-000036:note_history:40]
The 2019 Credit Agreement also provides for a five-year $5,000 million unsecured revolving credit facility, or the Revolving Facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit reduces the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we may borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) November 2023 or (b) the date of termination in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. We had no borrowings outstanding under the Revolving Facility on February 3, 2019.

- added (2019-06-14):
[0001730168-19-000101:note_history:41]
In April 2019, we issued $11 billion in aggregate principal amount of senior unsecured notes (“2019 Senior Notes”). The 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and Broadcom Technologies Inc. Each series of our 2019 Senior Notes pay interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part any of the 2019 Senior Notes at a price equal to 100% of the principal amount of the applicable 2019 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the 2019 Senior Notes, plus accrued and unpaid interest, if any, to the date of repurchase.

- added (2019-06-14):
[0001730168-19-000101:note_history:42]
In February 2019, we also established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available for general corporate purposes under the Revolving Facility. As of May 5, 2019, we had $1 billion of Commercial Paper outstanding with maturities generally less than sixty days. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they were supported by the Revolving Facility. These borrowings are now supported by our new revolving credit facility discussed below. As such, we have recorded Commercial Paper, net of discount, as long-term debt.

- added (2019-06-14):
[0001730168-19-000101:note_history:43]
We used the net proceeds from the 2019 Senior Notes and Commercial Paper to repay $12 billion of our 2019 Term Loans, including all of our term A-3 facility. As a result of our repayment of the 2019 Term Loans, we wrote off $26 million of debt issuance costs, which were included in interest expense on the condensed consolidated statements of operations. The 2019 Senior Notes are recorded as long-term debt, net of discount. The discount associated with the 2019 Senior Notes and Commercial Paper is amortized to interest expense over the respective terms of these borrowings. The unamortized discount and debt issuance costs balance on the 2019 Term Loans as of the modification date will be amortized to interest expense over the respective terms of the 2019 Senior Notes and Commercial Paper.

- added (2019-06-14):
[0001730168-19-000101:note_history:44]
On May 7, 2019, we entered into a new credit agreement, which provides for a $5 billion unsecured revolving credit facility, a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility. This new credit agreement has substantially the same terms and conditions as the 2019 Credit Agreement, other than with respect to the maturity date of the facilities. The proceeds of the term A-3, A-5 and A-7 facilities were used to refinance the $6 billion of existing term loans outstanding under the 2019 Credit Agreement, which was terminated in connection with, and as a condition to, entering into the May 7, 2019 credit agreement. Our obligations under this new credit agreement are guaranteed on an unsecured basis by BRCM and Broadcom Technologies Inc.

- changed (2019-06-14):
[0001730168-19-000101:note_history:45]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the “Subsidiary Issuers,” issued $17,550 million of senior unsecured notes (the “2017 Senior Notes”). The 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom (“Parent Guarantor”) and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc. (“Subsidiary Guarantor”), a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes
  (was, 2019-03-15, similarity 0.8818):
[0001730168-19-000036:note_history:45]
During fiscal year 2017, BRCM and Broadcom Cayman Finance Limited, collectively referred to as the Subsidiary Issuers, issued $17,550 million of senior unsecured notes, or the 2017 Senior Notes. Our 2017 Senior Notes were fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom, or Parent Guarantor, and Broadcom-Singapore. During the fiscal quarter ended February 3, 2019, Broadcom-Singapore was placed in voluntary liquidation in Singapore. Broadcom Technologies Inc., or Subsidiary Guarantor, a wholly-owned subsidiary of Broadcom, became a guarantor of the 2017 Senior Notes and entered into supplemental indentures with the Subsidiary Issuers and the trustee of the 2017 Senior Notes. As a result, Broadcom-Singapore was released from its guarantee of the 2017 Senior Notes under each of their respective indentures in accordance with their terms.

- added (2019-06-14):
[0001730168-19-000101:note_history:46]
under each of their respective indentures in accordance with their terms. On May 15, 2019, Broadcom Cayman Finance Limited was merged into the Subsidiary Guarantor, with the Subsidiary Guarantor as the surviving entity.

- changed (2019-06-14):
[0001730168-19-000101:note_history:47]
Assumed CA Senior Notes
  (was, 2019-03-15, similarity 0.7302):
[0001730168-19-000036:note_history:47]
2019 Term Loans and Assumed CA Senior Notes

- added (2019-06-14):
[0001730168-19-000101:note_history:48]
In connection with the CA Merger, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- added (2019-06-14):
[0001730168-19-000101:note_history:49]
As of May 5, 2019, the estimated aggregate fair value of debt was $37,331 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our term A-5 facility approximated its carrying value due to its floating interest rate and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2019-06-14):
[0001730168-19-000101:note_history:50]
The future scheduled principal payments of debt as of May 5, 2019 were as follows:
  (was, 2019-03-15, similarity 0.9383):
[0001730168-19-000036:note_history:50]
The future scheduled principal payments for debt as of February 3, 2019 were as follows:

- changed (2019-06-14):
[0001730168-19-000101:note_history:51]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | 1,000 |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 3,650 |  |
| 2022 |  | 6,409 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 20,713 |  |
| Total |  | $ | 37,859 |  |
  (was, 2019-03-15, similarity 0.9952):
[0001730168-19-000036:note_history:51]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2019 (remainder) |  | $ | — |  |
| 2020 |  | 3,937 |  |
| 2021 |  | 1,650 |  |
| 2022 |  | 13,909 |  |
| 2023 |  | 2,150 |  |
| Thereafter |  | 16,213 |  |
| Total |  | $ | 37,859 |  |

- changed (2019-06-14):
[0001730168-19-000101:note_history:52]
As of May 5, 2019 and November 4, 2018, we accrued interest payable of $244 million and $165 million, respectively and were in compliance with all debt covenants.
  (was, 2019-03-15, similarity 0.9769):
[0001730168-19-000036:note_history:52]
As of February 3, 2019 and November 4, 2018, we accrued interest payable of $104 million and $165 million, respectively and were in compliance with all debt covenants.

- removed (2019-06-14):
[0001730168-19-000036:note_history:53]
Additionally, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes, or the Assumed CA Senior Notes. CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture governing the Assumed CA Senior Notes. In the event of a change in control, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest, if any, to the date of repurchase (subject to the right of holders of record on the relevant interest payment date to receive interest due). Each series of the Assumed CA Senior Notes pays interest semi-annually.

- removed (2019-06-14):
[0001730168-19-000036:note_history:54]
As of February 3, 2019, the estimated aggregate fair value of debt was $37,021 million and was primarily classified as Level 2. The fair value of our 2019 Term Loans is determined using inputs based on discounted cash flow models with observable market inputs and takes into consideration variables such as interest rate changes, comparable instruments, and credit-rating changes. The fair values of the Assumed CA Senior Notes and 2017 Senior Notes are determined using quoted prices from less active markets.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:55]
|  |  | Effective Interest Rate |  | May 5, 2019 |  | November 4, 2018 |
|  |  | (In millions, except percentages) |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.607 | % |  | $ | 2,000 |  |  | $ | — |  |
| 3.125% notes due October 2022 |  | 3.527 | % |  | 1,500 |  |  | — |  |
| 3.625% notes due October 2024 |  | 3.980 | % |  | 2,000 |  |  | — |  |
| 4.250% notes due April 2026 |  | 4.544 | % |  | 2,500 |  |  | — |  |
| 4.750% notes due April 2029 |  | 4.953 | % |  | 3,000 |  |  | — |  |
|  |  |  |  | 11,000 |  |  | — |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through November 2023 |  | 3.852 | % |  | 6,000 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Commercial Paper |  |  |  |  |  |  |
| Commercial paper |  | 0.289 | % | (a) | 1,000 |  |  | — |  |
|  |  |  |  | 1,000 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.585% - 4.546% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount/premium and unamortized debt issuance costs |  |  |  | (311 | ) |  | (116 | ) |
| Total Debt |  |  |  | $ | 37,548 |  |  | $ | 17,493 |  |
  (was, 2019-03-15, similarity 0.838):
[0001730168-19-000036:note_history:55]
|  |  | Effective Interest Rate |  | February 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2021 |  | 3.853 | % |  | $ | 9,000 |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due September 2021 to November 2023 |  | 3.892 | % |  | 9,000 |  |  | — |  |
|  |  |  |  | 18,000 |  |  | — |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  | 2.615 | % |  | 2,750 |  |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.406 | % |  | 750 |  |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.214 | % |  | 3,500 |  |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.781 | % |  | 1,000 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.744 | % |  | 2,500 |  |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.234 | % |  | 1,000 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.018 | % |  | 4,800 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.596 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 17,550 |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  | 3.433 | % |  | 750 |  |  | — |  |
| 3.600% notes due August 2020 |  | 3.540 | % |  | 400 |  |  | — |  |
| 3.600% notes due August 2022 |  | 4.071 | % |  | 500 |  |  | — |  |
| 4.500% notes due August 2023 |  | 4.099 | % |  | 250 |  |  | — |  |
| 4.700% notes due March 2027 |  | 5.153 | % |  | 350 |  |  | — |  |
|  |  |  |  | 2,250 |  |  | — |  |
| Assumed Brocade Convertible Notes - fixed rate |  |  |  |  |  |  |
| 1.375% convertible notes due January 2020 |  | 0.628 | % |  | 37 |  |  | 37 |  |
|  |  |  |  | 37 |  |  | 37 |  |
| Assumed BRCM Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.50% - 4.50% notes due August 2022 - August 2034 |  | 2.50% - 4.50% |  |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 37,859 |  |  | 17,609 |  |
| Less: Unaccreted discount, premium and unamortized debt issuance costs |  |  |  | (218 | ) |  | (116 | ) |
| Total carrying value of debt |  |  |  | $ | 37,641 |  |  | $ | 17,493 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:56]
________________________________

- added (2019-06-14):
[0001730168-19-000101:note_history:57]
(a) Represents the weighted average interest rate on outstanding commercial paper as of May 5, 2019.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:58]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:
  (was, 2019-03-15, similarity 0.8454):
[0001730168-19-000036:note_history:58]
The following table presents revenue disaggregated by type of revenue and by region.

- changed (2019-06-14):
[0001730168-19-000101:note_history:59]
|  |  | Fiscal Quarter Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services* |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |
  (was, 2019-03-15, similarity 0.9394):
[0001730168-19-000036:note_history:59]
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services* |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:60]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services* |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:61]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.
  (was, 2019-03-15, similarity 0.9639):
[0001730168-19-000036:note_history:61]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering, or NRE, arrangements.

- changed (2019-06-14):
[0001730168-19-000101:note_history:62]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.
  (was, 2019-03-15, similarity 0.997):
[0001730168-19-000036:note_history:62]
There are two main categories of NRE contracts which we enter into with our customers; (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (cost-to-cost) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- changed (2019-06-14):
[0001730168-19-000101:note_history:63]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.
  (was, 2019-03-15, similarity 0.9862):
[0001730168-19-000036:note_history:63]
Material rights. Contracts with customers may also include material rights which are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- removed (2019-06-14):
[0001730168-19-000036:note_history:64]
Warranty. We provide only assurance-type warranties on our products to our customers. As a result, we accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

- removed (2019-06-14):
[0001730168-19-000036:note_history:65]
Significant financing component. Payment terms and conditions vary by contract, although terms generally include a requirement of payment within a specified period. In certain arrangements, we receive payment from a customer either before or after the performance obligation has been satisfied. The timing difference between the payment and satisfaction of performance obligations for the vast majority of our contracts is one year or less; therefore, for those contracts, we apply a practical expedient and do not consider the effects of the time value of money.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:66]
Revenue from Contracts with Customers 
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.
  (was, 2019-03-15, similarity 0.963):
[0001730168-19-000036:note_history:66]
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

- changed (2019-06-14):
[0001730168-19-000101:note_history:67]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.
  (was, 2019-03-15, similarity 0.9639):
[0001730168-19-000036:note_history:67]
Subscriptions and services. Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering, or NRE, arrangements.

- changed (2019-06-14):
[0001730168-19-000101:note_history:68]
There are two main categories of NRE contracts which we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.
  (was, 2019-03-15, similarity 0.997):
[0001730168-19-000036:note_history:68]
There are two main categories of NRE contracts which we enter into with our customers; (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria under Topic 606. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (cost-to-cost) as the services are provided. For NRE contracts that do not meet the over time criteria under Topic 606, revenue is recognized at a point in time when the NRE services are complete.

- changed (2019-06-14):
[0001730168-19-000101:note_history:69]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.
  (was, 2019-03-15, similarity 0.9862):
[0001730168-19-000036:note_history:69]
Material rights. Contracts with customers may also include material rights which are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

- changed (2019-06-14):
[0001730168-19-000101:note_history:70]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. “Segment Information”.
  (was, 2019-03-15, similarity 0.949):
[0001730168-19-000036:note_history:70]
We have considered 1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker, or the CODM, as defined by the authoritative guidance on segment reporting, in evaluating financial performance and 2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. "Segment Information".

- changed (2019-06-14):
[0001730168-19-000101:note_history:71]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:
  (was, 2019-03-15, similarity 0.8454):
[0001730168-19-000036:note_history:71]
The following table presents revenue disaggregated by type of revenue and by region.

- changed (2019-06-14):
[0001730168-19-000101:note_history:72]
|  |  | Fiscal Quarter Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services* |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |
  (was, 2019-03-15, similarity 0.9394):
[0001730168-19-000036:note_history:72]
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services* |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:73]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services* |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- changed (2019-06-14):
[0001730168-19-000101:note_history:74]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |
  (was, 2019-03-15, similarity 0.9806):
[0001730168-19-000036:note_history:74]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 5, 2018* |  | $ | 18 |  |  | $ | 272 |  |
| Closing balance February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

- changed (2019-06-14):
[0001730168-19-000101:note_history:75]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $144 million.
  (was, 2019-03-15, similarity 0.9183):
[0001730168-19-000036:note_history:75]
The difference in the opening and closing balances of our contract assets and contract liabilities primarily results from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognized contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.

- changed (2019-06-14):
[0001730168-19-000101:note_history:76]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property.
  (was, 2019-03-15, similarity 0.6805):
[0001730168-19-000036:note_history:76]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include CA contracts where the customer is not committed. The customer is not considered committed where they are able to terminate for convenience without payment of a substantive penalty and this has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts which have an original duration of one year or less nor have we included contract with sales-based and usage-based royalties promised in exchange for a license of intellectual property.

- changed (2019-06-14):
[0001730168-19-000101:note_history:77]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 5, 2019 was not significant. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.
  (was, 2019-03-15, similarity 0.9882):
[0001730168-19-000036:note_history:77]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 3, 2019 was not significant. Since our customers generally may not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- added (2019-06-14):
[0001730168-19-000101:note_history:78]
When costs are incurred to fulfill a contract that are not within the scope of another accounting literature, we recognize an asset. We have not incurred any such costs and, as a result, no costs to fulfill a contract have been capitalized.

- added (2019-06-14):
[0001730168-19-000101:note_history:79]
Topic 606 Adoption

- changed (2019-06-14):
[0001730168-19-000101:note_history:80]
We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:
  (was, 2019-03-15, similarity 0.6908):
[0001730168-19-000036:note_history:80]
We adopted Topic 606 using the modified retrospective method. The cumulative effect of applying the new guidance to all contracts with customers that were not completed by November 4, 2018 was recorded as an adjustment to retained earnings as of adoption on November 5, 2018. We adopted Topic 606 immediately prior to the CA Merger. Accordingly, the adoption adjustments presented below excluded CA. As a result of applying the modified retrospective method, the following adjustments were made to selected condensed consolidated balance sheet line items as of November 5, 2018:

- changed (2019-06-14):
[0001730168-19-000101:note_history:81]
| Balance Sheet |  | Ending Balance as of November 4, 2018 |  | Adjustments Due to Topic 606 |  | Opening Balance as of November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |
  (was, 2019-03-15, similarity 0.9575):
[0001730168-19-000036:note_history:81]
| Balance Sheet |  | November 4, 2018 |  | Adjustments Due to Topic 606 |  | November 5, 2018 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |  |  |
| Trade accounts receivable, net |  | $ | 3,325 |  |  | $ | 11 |  |  | $ | 3,336 |  |
| Other current assets |  | $ | 366 |  |  | $ | 10 |  |  | $ | 376 |  |
| Other long-term assets |  | $ | 707 |  |  | $ | 20 |  |  | $ | 727 |  |
| LIABILITIES |  |  |  |  |  |  |
| Other current liabilities |  | $ | 812 |  |  | $ | 35 |  |  | $ | 847 |  |
| Other long-term liabilities |  | $ | 3,636 |  |  | $ | 6 |  |  | $ | 3,642 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:82]
The following tables compare net revenue for the periods presented to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statements of operations for the fiscal quarter and two fiscal quarters ended May 5, 2019 or in the condensed consolidated balance sheet as of May 5, 2019 were significantly affected by the new revenue guidance.

- changed (2019-06-14):
[0001730168-19-000101:note_history:83]
|  |  | Fiscal Quarter Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,418 |  |  | $ | — |  |  | $ | 4,418 |  |
| Subscriptions and services |  | 1,040 |  |  | 59 |  |  | 1,099 |  |
| Total net revenue |  | $ | 5,458 |  |  | $ | 59 |  |  | $ | 5,517 |  |
  (was, 2019-03-15, similarity 0.884):
[0001730168-19-000036:note_history:83]
|  |  | Fiscal Quarter Ended February 3, 2019 |
| Statement of Operations |  | Proforma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 4,639 |  |  | $ | — |  |  | $ | 4,639 |  |
| Subscriptions and services |  | 1,006 |  |  | 144 |  |  | 1,150 |  |
| Total net revenue |  | $ | 5,645 |  |  | $ | 144 |  |  | $ | 5,789 |  |

- added (2019-06-14):
[0001730168-19-000101:note_history:84]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |
| Statement of Operations |  | Pro forma as if the previous accounting was in effect |  | Effect of ChangeHigher/(Lower) |  | As Reported |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Products |  | $ | 9,057 |  |  | $ | — |  |  | $ | 9,057 |  |
| Subscriptions and services |  | 2,046 |  |  | 203 |  |  | 2,249 |  |
| Total net revenue |  | $ | 11,103 |  |  | $ | 203 |  |  | $ | 11,306 |  |

- removed (2019-06-14):
[0001730168-19-000036:note_history:85]
Revenue from Contracts with Customers

- removed (2019-06-14):
[0001730168-19-000036:note_history:86]
Warranty. We provide only assurance-type warranties on our products to our customers. As a result, we accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the products requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

- removed (2019-06-14):
[0001730168-19-000036:note_history:87]
Significant financing component. Payment terms and conditions vary by contract, although terms generally include a requirement of payment within a specified period. In certain arrangements, we receive payment from a customer either before or after the performance obligation has been satisfied. The timing difference between the payment and satisfaction of performance obligations for the vast majority of our contracts is one year or less; therefore, for those contracts, we apply a practical expedient and do not consider the effects of the time value of money.

- removed (2019-06-14):
[0001730168-19-000036:note_history:88]
We have a policy to recognize an asset from the costs incurred to fulfill a contract that are not within the scope of another accounting literature. We have not incurred any costs to fulfill a contract that fall within the guidance and, as a result, no costs to fulfill a contract have been capitalized.

- removed (2019-06-14):
[0001730168-19-000036:note_history:89]
Changes in Accounting Policies

- removed (2019-06-14):
[0001730168-19-000036:note_history:90]
Except for the changes below, we have consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements. We adopted Topic 606 with an initial application date of November 5, 2018. As a result, we have changed our accounting policy for revenue recognition as detailed above.

- removed (2019-06-14):
[0001730168-19-000036:note_history:91]
Financial Statement Impact of Adopting Topic 606

- removed (2019-06-14):
[0001730168-19-000036:note_history:92]
The following table compares net revenue for the fiscal quarter ended February 3, 2019 to the pro forma amounts had the previous guidance been in effect. No other amounts in the condensed consolidated statement of operations for the fiscal quarter ended February 3, 2019 or in the condensed consolidated balance sheet as of February 3, 2019 were significantly affected by the new revenue guidance.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-06-14):
[0001730168-19-000101:note_history:93]
Subsequent Event
Cash Dividends Declared
  (was, 2019-03-15, similarity 0.7302):
[0001730168-19-000036:note_history:93]
Cash Dividends Declared

- changed (2019-06-14):
[0001730168-19-000101:note_history:94]
On June 12, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on July 2, 2019 to stockholders of record at the close of business on June 24, 2019.
  (was, 2019-03-15, similarity 0.9159):
[0001730168-19-000036:note_history:94]
On March 13, 2019, our Board of Directors declared a cash dividend of $2.65 per share, payable on March 29, 2019 to stockholders of record at the close of business on March 21, 2019.

- removed (2019-06-14):
[0001730168-19-000036:note_history:95]
Subsequent Event
