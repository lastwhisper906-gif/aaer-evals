# AVGO MD&A — 0001730168-20-000164


## mdna

[0001730168-20-000164:mdna:1]
[same as prior period, unchanged from 0001730168-20-000109:mdna:1]

[0001730168-20-000164:mdna:2]
[same as prior period, unchanged from 0001730168-20-000109:mdna:2]

[0001730168-20-000164:mdna:3]
[same as prior period, unchanged from 0001730168-20-000109:mdna:3]

[0001730168-20-000164:mdna:4]
[same as prior period, unchanged from 0001730168-20-000109:mdna:4]

[0001730168-20-000164:mdna:5]
[same as prior period, unchanged from 0001730168-20-000109:mdna:5]

[0001730168-20-000164:mdna:6]
Highlights during the third fiscal quarter ended August 2, 2020 include the following:

[0001730168-20-000164:mdna:7]
•We generated $3,178 million of cash from operations.

[0001730168-20-000164:mdna:8]
•We paid $1,386 million in cash dividends.

[0001730168-20-000164:mdna:9]
•We refinanced certain debt, reducing our total debt by $1.9 billion.

[0001730168-20-000164:mdna:10]
[same as prior period, unchanged from 0001730168-20-000109:mdna:12]

[0001730168-20-000164:mdna:11]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in most of our employees working remotely for an extended period of time, earlier this year. While we are currently implementing a phased-in return of employees to many of our facilities, if the spread

[0001730168-20-000164:mdna:12]
[same as prior period, unchanged from 0001730168-20-000109:mdna:24]

[0001730168-20-000164:mdna:13]
of COVID-19 worsens significantly, we may need to further limit onsite operations or otherwise modify our business practices. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-20-000164:mdna:14]
The demand environment for our semiconductor products was consistent with our expectations for our third quarter of fiscal year 2020, with continued demand for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this area, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, we continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. As a result, supply lead times are still extended and we continue to have difficulties in obtaining some necessary components and inputs in a timely manner. However, the disruptions in our outsourced assembly and test capacity that we experienced previously, as a result of COVID-19 related shutdowns, have now largely resolved.

[0001730168-20-000164:mdna:15]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty. For example, we are largely building semiconductor products to order, instead of based on customer forecasts, and continue to reduce semiconductor inventory in our distribution channels. In addition, during the third fiscal quarter, we continued to strengthen our balance sheet, including closely managing working capital and refinancing and extending the maturities of many of our debt instruments.

[0001730168-20-000164:mdna:16]
Overall, in light of the changing nature and continuing uncertainty around the COVID-19 pandemic, our ability to predict the impact of COVID-19 on our business in future periods remains limited. The effects of the pandemic on our business are unlikely to be fully realized, or reflected in our financial results, until future periods.

[0001730168-20-000164:mdna:17]
[same as prior period, unchanged from 0001730168-20-000109:mdna:17]

[0001730168-20-000164:mdna:18]
[same as prior period, unchanged from 0001730168-20-000109:mdna:18]

[0001730168-20-000164:mdna:19]
[same as prior period, unchanged from 0001730168-20-000109:mdna:19]

[0001730168-20-000164:mdna:20]
[same as prior period, unchanged from 0001730168-20-000109:mdna:20]

[0001730168-20-000164:mdna:21]
[same as prior period, unchanged from 0001730168-20-000109:mdna:21]

[0001730168-20-000164:mdna:22]
[same as prior period, unchanged from 0001730168-20-000109:mdna:25]

[0001730168-20-000164:mdna:23]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgements about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgements by management. Those policies include revenue recognition, business combinations, valuation of long-lived assets, intangible assets and goodwill, inventory valuation, income taxes, retirement and post-retirement benefit plan assumptions, stock-based compensation, and employee bonus programs.

[0001730168-20-000164:mdna:24]
There were no significant changes in our critical accounting policies during the three fiscal quarters ended August 2, 2020 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2019 Annual Report on Form 10-K.

[0001730168-20-000164:mdna:25]
[same as prior period, unchanged from 0001730168-20-000109:mdna:28]

[0001730168-20-000164:mdna:26]
Fiscal Quarter and Three Fiscal Quarters Ended August 2, 2020 Compared to Fiscal Quarter and Three Fiscal Quarters Ended August 4, 2019

[0001730168-20-000164:mdna:27]
[same as prior period, unchanged from 0001730168-20-000109:mdna:30]

[0001730168-20-000164:mdna:28]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |  | (As a percentage of total net revenue) |  |  |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,125 |  |  | $ | 4,413 |  |  | 71 | % |  | 80 | % |
| Subscriptions and services |  | 1,696 |  |  | 1,102 |  |  | 29 |  |  | 20 |  |
| Total net revenue |  | 5,821 |  |  | 5,515 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,383 |  |  | 1,519 |  |  | 24 |  |  | 28 |  |
| Cost of subscriptions and services |  | 154 |  |  | 132 |  |  | 3 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 953 |  |  | 828 |  |  | 16 |  |  | 15 |  |
| Restructuring charges |  | 15 |  |  | 2 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,505 |  |  | 2,481 |  |  | 43 |  |  | 45 |  |
| Gross margin |  | 3,316 |  |  | 3,034 |  |  | 57 |  |  | 55 |  |
| Research and development |  | 1,228 |  |  | 1,235 |  |  | 21 |  |  | 22 |  |
| Selling, general and administrative |  | 428 |  |  | 410 |  |  | 8 |  |  | 7 |  |
| Amortization of acquisition-related intangible assets |  | 600 |  |  | 475 |  |  | 10 |  |  | 9 |  |
| Restructuring, impairment and disposal charges |  | 52 |  |  | 49 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 2,308 |  |  | 2,169 |  |  | 40 |  |  | 39 |  |
| Operating income |  | $ | 1,008 |  |  | $ | 865 |  |  | 17 | % |  | 16 | % |

[0001730168-20-000164:mdna:29]
[same as prior period, unchanged from 0001730168-20-000109:mdna:37]

[0001730168-20-000164:mdna:30]
|  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |  | (As a percentage of total net revenue) |  |  |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 12,582 |  |  | $ | 13,470 |  |  | 72 | % |  | 80 | % |
| Subscriptions and services |  | 4,839 |  |  | 3,351 |  |  | 28 |  |  | 20 |  |
| Total net revenue |  | 17,421 |  |  | 16,821 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,290 |  |  | 4,530 |  |  | 25 |  |  | 27 |  |
| Cost of subscriptions and services |  | 475 |  |  | 405 |  |  | 3 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 2,857 |  |  | 2,487 |  |  | 16 |  |  | 15 |  |
| Restructuring charges |  | 30 |  |  | 68 |  |  | — |  |  | 1 |  |
| Total cost of revenue |  | 7,652 |  |  | 7,490 |  |  | 44 |  |  | 45 |  |
| Gross margin |  | 9,769 |  |  | 9,331 |  |  | 56 |  |  | 55 |  |
| Research and development |  | 3,786 |  |  | 3,519 |  |  | 22 |  |  | 21 |  |
| Selling, general and administrative |  | 1,530 |  |  | 1,300 |  |  | 9 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 1,802 |  |  | 1,424 |  |  | 10 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 163 |  |  | 698 |  |  | 1 |  |  | 4 |  |
| Total operating expenses |  | 7,281 |  |  | 6,941 |  |  | 42 |  |  | 41 |  |
| Operating income |  | $ | 2,488 |  |  | $ | 2,390 |  |  | 14 | % |  | 14 | % |

[0001730168-20-000164:mdna:31]
[same as prior period, unchanged from 0001730168-20-000109:mdna:33]

[0001730168-20-000164:mdna:32]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. No customer accounted for 10% or more of our net revenue for the fiscal quarter ended August 2, 2020. Direct sales to WT Microelectronics, a distributor, accounted for 12% of our net revenue for the three fiscal quarters ended August 2, 2020, and 16% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively.

[0001730168-20-000164:mdna:33]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 25% and 30% of our net revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, and approximately 35% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 4, 2019. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 10% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, and approximately 20% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 4, 2019. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-20-000164:mdna:34]
[same as prior period, unchanged from 0001730168-20-000109:mdna:36]

[0001730168-20-000164:mdna:35]
[same as prior period, unchanged from 0001730168-20-000109:mdna:38]

[0001730168-20-000164:mdna:36]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |
| Net Revenue by Segment |  | August 2,2020 |  | August 4,2019 |  | $ Change |  | % Change |  | August 2, 2020 |  | August 4, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,219 |  |  | $ | 4,375 |  |  | $ | (156) |  |  | (4) | % |  | $ | 12,437 |  |  | $ | 12,865 |  |  | $ | (428) |  |  | (3) | % |
| Infrastructure software |  | 1,602 |  |  | 1,140 |  |  | 462 |  |  | 41 | % |  | 4,984 |  |  | 3,956 |  |  | 1,028 |  |  | 26 | % |
| Total net revenue |  | $ | 5,821 |  |  | $ | 5,515 |  |  | $ | 306 |  |  | 6 | % |  | $ | 17,421 |  |  | $ | 16,821 |  |  | $ | 600 |  |  | 4 | % |

[0001730168-20-000164:mdna:37]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
| % of Net Revenue by Segment |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
| Semiconductor solutions |  | 72 | % |  | 79 | % |  | 71 | % |  | 76 | % |
| Infrastructure software |  | 28 |  |  | 21 |  |  | 29 |  |  | 24 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-20-000164:mdna:38]
Fiscal quarter ended August 2, 2020 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to delays in the production ramp of a new mobile handset by a major customer, which resulted in lower shipments in the fiscal quarter ended August 2, 2020. This decrease was partially offset by higher demand for our networking products. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions and higher demand for our mainframe and enterprise software solutions.

[0001730168-20-000164:mdna:39]
Three fiscal quarters ended August 2, 2020 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to delays in the production ramp of a new mobile handset by a major customer, which resulted in lower shipments, as well as lower demand for our broadband products. These decreases were partially offset by higher demand for our storage products. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, as well as an increase in demand for our mainframe and enterprise software solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000164:mdna:40]
[same as prior period, unchanged from 0001730168-20-000109:mdna:43]

[0001730168-20-000164:mdna:41]
Gross margin was $3,316 million for the fiscal quarter ended August 2, 2020 compared to $3,034 million for the fiscal quarter ended August 4, 2019 and was $9,769 million for the three fiscal quarters ended August 2, 2020 compared to $9,331 million for the three fiscal quarters ended August 4, 2019. As a percentage of net revenue, gross margin was 57% and 55% of net revenue for the fiscal quarters ended August 2, 2020 and August 4, 2019, respectively, and 56% and 55% of net revenue for the three fiscal quarters ended August 2, 2020 and August 4, 2019, respectively.

[0001730168-20-000164:mdna:42]
The increases in gross margin were primarily due to contributions from our Symantec enterprise security solutions, as well as favorable product mix in our semiconductor solutions products, compared to the corresponding prior fiscal year periods.

[0001730168-20-000164:mdna:43]
[same as prior period, unchanged from 0001730168-20-000109:mdna:46]

[0001730168-20-000164:mdna:44]
Research and development expense decreased $7 million, or 1%, and increased $267 million, or 8% for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to the prior year fiscal periods. The decrease for the fiscal quarter ended August 2, 2020 was due primarily to lower stock-based compensation expense, partially offset by an increase due to the Symantec Asset Purchase. The increase for the three fiscal quarters ended August 2, 2020 was primarily due to the Symantec Asset Purchase, partially offset by lower stock-based compensation expense. The decreases in stock-based compensation expense were primarily due to the full vesting of certain equity awards, as well as a one-time impact of the change from annual to quarterly vesting of certain equity awards included in the prior year fiscal periods. Additionally, the decrease for the three fiscal quarters ended August 2, 2020 was partially offset by the recognition of three full quarters of expense for the multi-year equity grants of restricted stock units issued during the first quarter of fiscal year 2019.

[0001730168-20-000164:mdna:45]
[same as prior period, unchanged from 0001730168-20-000109:mdna:48]

[0001730168-20-000164:mdna:46]
Selling, general and administrative expense increased $18 million, or 4%, and $230 million, or 18%, for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to the Symantec Asset Purchase and associated acquisition-related costs and litigation settlements, partially

[0001730168-20-000164:mdna:47]
offset by decreases in stock-based compensation expense and benefits from restructuring actions that we initiated following the acquisition of CA, Inc. (“CA Merger”). The decreases in stock-based compensation expense were primarily due to the full vesting of certain equity awards, including equity awards assumed from the CA Merger. The decrease in stock-based compensation expense for the fiscal quarter ended August 2, 2020 was also due to a one-time impact of the change from annual to quarterly vesting of certain equity awards included in the prior year fiscal period.

[0001730168-20-000164:mdna:48]
[same as prior period, unchanged from 0001730168-20-000109:mdna:50]

[0001730168-20-000164:mdna:49]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $125 million and $378 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to intangible assets acquired in the Symantec Asset Purchase.

[0001730168-20-000164:mdna:50]
[same as prior period, unchanged from 0001730168-20-000109:mdna:52]

[0001730168-20-000164:mdna:51]
Restructuring, impairment and disposal charges recognized in operating expenses increased $3 million and decreased $535 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to the prior year fiscal periods. The increase for the fiscal quarter ended August 2, 2020 was primarily due to employee termination costs resulting from the Symantec Asset Purchase. The decrease for the three fiscal quarters ended August 2, 2020 was primarily due to higher employee termination costs, as well as lease and other exit costs, resulting from the CA Merger in the prior year fiscal period.

[0001730168-20-000164:mdna:52]
[same as prior period, unchanged from 0001730168-20-000109:mdna:54]

[0001730168-20-000164:mdna:53]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |  |  |
| Operating Income by Segment |  | August 2,2020 |  | August 4,2019 |  | $ Change |  | % Change |  | August 2, 2020 |  | August 4, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,045 |  |  | $ | 2,081 |  |  | $ | (36) |  |  | (2) | % |  | $ | 5,864 |  |  | $ | 6,012 |  |  | $ | (148) |  |  | (2) | % |
| Infrastructure software |  | 1,136 |  |  | 829 |  |  | 307 |  |  | 37 | % |  | 3,432 |  |  | 2,899 |  |  | 533 |  |  | 18 | % |
| Unallocated expenses |  | (2,173) |  |  | (2,045) |  |  | (128) |  |  | 6 | % |  | (6,808) |  |  | (6,521) |  |  | (287) |  |  | 4 | % |
| Total operating income |  | $ | 1,008 |  |  | $ | 865 |  |  | $ | 143 |  |  | 17 | % |  | $ | 2,488 |  |  | $ | 2,390 |  |  | $ | 98 |  |  | 4 | % |

[0001730168-20-000164:mdna:54]
Fiscal quarter ended August 2, 2020 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to delays in the production ramp of a new mobile handset by a major customer, which resulted in lower shipments. This decrease was partially offset by higher demand for our networking products. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions.

[0001730168-20-000164:mdna:55]
Three fiscal quarters ended August 2, 2020 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to less favorable product mix for certain networking products, delays in the production ramp of a new mobile handset by a major customer, which resulted in lower shipments, and a decrease in demand for our broadband products. These decreases were partially offset by higher demand for our storage products. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000164:mdna:56]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 6% and 4% for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher amortization of acquisition-related intangible assets and acquisition-related costs, partially offset by lower stock-based compensation expense. Additionally, for the three fiscal quarters ended August 2, 2020, the increase in unallocated expenses was partially offset by lower restructuring, impairment and disposal charges.

[0001730168-20-000164:mdna:57]
[same as prior period, unchanged from 0001730168-20-000109:mdna:59]

[0001730168-20-000164:mdna:58]
Interest expense. Interest expense was $464 million and $1,357 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, and $362 million and $1,083 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. The increases were primarily due to interest on the debt we incurred to finance the Symantec Asset Purchase, as well as losses on extinguishment of debt related to the repayment of certain term loans in the fiscal quarter ended August 2, 2020. Additionally, for the three fiscal quarters ended August 2, 2020, we incurred losses on extinguishment of debt related to the repurchase of certain senior notes.

[0001730168-20-000164:mdna:59]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $49 million and $175 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, as compared to $41 million and $172 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. The increases were primarily due to a $23 million gain on sale of business, partially offset by decreases in interest income. Other income, net for the three fiscal quarters ended August 2, 2020 also included a $116 million one-time gain from the lapse of a tax indemnification arrangement, partially offset by a decrease in gains on investments and foreign currency remeasurement.

[0001730168-20-000164:mdna:60]
Benefit from income taxes. The benefit from income taxes was $96 million and $331 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, and $171 million and $410 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 2, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards that vested or were exercised during the periods.

[0001730168-20-000164:mdna:61]
The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 4, 2019 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities, internal reorganizations and excess tax benefits from stock-based awards that vested or were exercised during the period. Additionally, the benefit from income taxes for the three fiscal quarters ended August 4, 2019 included the recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, and the partial release of our valuation allowance as a result of the CA Merger, partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”).

[0001730168-20-000164:mdna:62]
[same as prior period, unchanged from 0001730168-20-000109:mdna:65]

[0001730168-20-000164:mdna:63]
[same as prior period, unchanged from 0001730168-20-000109:mdna:66]

[0001730168-20-000164:mdna:64]
Our primary sources of liquidity as of August 2, 2020 consisted of: (i) $8,857 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-20-000164:mdna:65]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $44,498 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-20-000164:mdna:66]
[same as prior period, unchanged from 0001730168-20-000109:mdna:69]

[0001730168-20-000164:mdna:67]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-20-000164:mdna:68]
[same as prior period, unchanged from 0001730168-20-000109:mdna:71]

[0001730168-20-000164:mdna:69]
[same as prior period, unchanged from 0001730168-20-000109:mdna:72]

[0001730168-20-000164:mdna:70]
Working capital increased to $6,979 million at August 2, 2020 from $3,018 million at November 3, 2019. The increase was primarily attributable to the following:

[0001730168-20-000164:mdna:71]
•Cash and cash equivalents increased to $8,857 million at August 2, 2020 from $5,055 million at November 3, 2019, primarily due to $27,802 million in proceeds from long-term borrowings and $8,713 million in net cash provided by operating activities. These increases were partially offset by $17,099 million of debt repayments, $10,700 million paid for the Symantec Asset Purchase and $4,139 million of dividend payments.

[0001730168-20-000164:mdna:72]
•Inventory increased to $1,081 million at August 2, 2020 from $874 million at November 3, 2019, primarily due to timing of customer product ramps.

[0001730168-20-000164:mdna:73]
•Other current assets increased to $1,059 million at August 2, 2020 from $729 million at November 3, 2019, primarily due to increases in prepaid taxes and short-term investments.

[0001730168-20-000164:mdna:74]
•Current portion of long-term debt decreased to $822 million at August 2, 2020 from $2,787 million at November 3, 2019 primarily due to repayment of certain debt, partially offset by additional amounts coming due within twelve months.

[0001730168-20-000164:mdna:75]
[same as prior period, unchanged from 0001730168-20-000109:mdna:78]

[0001730168-20-000164:mdna:76]
•Accounts receivable decreased to $2,684 million at August 4, 2019 from $3,259 million at November 3, 2019, primarily due to revenue linearity and $552 million of additional receivables sold through factoring arrangements.

[0001730168-20-000164:mdna:77]
•Accounts payable increased to $1,092 million at August 2, 2020 from $855 million at November 3, 2019, primarily due to timing of vendor payments.

[0001730168-20-000164:mdna:78]
•Other current liabilities increased to $4,056 million at August 2, 2020 from $2,616 million at November 3, 2019, primarily due to increases in contract liabilities, interest payable, lease liabilities resulting from the adoption of Accounting Standard Codification Topic 842, and taxes payable, partially offset by repayments of notional pooling liabilities.

[0001730168-20-000164:mdna:79]
Working capital decreased to $2,616 million at August 4, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-20-000164:mdna:80]
[same as prior period, unchanged from 0001730168-20-000109:mdna:82]

[0001730168-20-000164:mdna:81]
•Other current liabilities increased to $3,174 million at August 4, 2019 from $812 million at November 4, 2018, primarily due to liabilities assumed in the CA Merger and increases in contract liabilities from adoption of Accounting Standard Codification Topic 606 (“Topic 606”), notional pooling liabilities, restructuring reserves, and interest payable.

[0001730168-20-000164:mdna:82]
•Accounts payable increased to $996 million at August 4, 2019 from $811 million at November 4, 2018, primarily due to timing of vendor payments and increases due to the CA Merger.

[0001730168-20-000164:mdna:83]
•Inventory decreased to $1,091 million at August 4, 2019 from $1,124 million at November 4, 2018, primarily due to consumption to support customer shipments.

[0001730168-20-000164:mdna:84]
[same as prior period, unchanged from 0001730168-20-000109:mdna:85]

[0001730168-20-000164:mdna:85]
•Cash and cash equivalents increased to $5,462 million at August 4, 2019 from $4,292 million at November 4, 2018, primarily due to $30,138 million in proceeds from borrowings, $7,218 million in net cash provided by operating activities and $957 million in proceeds from the sale of Veracode, Inc., a wholly-owned subsidiary acquired in the CA Merger, partially offset by $16,027 million paid for the CA Merger, $12 billion of debt repayments, $5,002 million of common stock repurchases and $3,181 million of dividend payments.

[0001730168-20-000164:mdna:86]
•Other current assets increased to $806 million at August 4, 2019 from $366 million at November 4, 2018, primarily due to assets acquired in the CA Merger and increases in contract assets from adoption of Topic 606 and prepaid taxes.

[0001730168-20-000164:mdna:87]
•Accounts receivable increased to $3,539 million at August 4, 2019 from $3,325 million at November 4, 2018, primarily due to revenue linearity and an increase due to the CA Merger, partially offset by $375 million of receivables sold through factoring arrangements.

[0001730168-20-000164:mdna:88]
•Employee compensation and benefits decreased to $575 million at August 4, 2019 from $715 million at November 4, 2018, primarily due to timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger.

[0001730168-20-000164:mdna:89]
37

[0001730168-20-000164:mdna:90]
[same as prior period, unchanged from 0001730168-20-000109:mdna:90]

[0001730168-20-000164:mdna:91]
|  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions, except per share data) |  |  |
| Dividends per share to common stockholders |  | $ | 9.75 |  |  | $ | 7.95 |  |
| Dividends to common stockholders |  | $ | 3,915 |  |  | $ | 3,181 |  |
| Dividends per share to preferred stockholders |  | $ | 60.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 224 |  |  | $ | — |  |
| Stock repurchases |  | $ | — |  |  | $ | 5,002 |  |

[0001730168-20-000164:mdna:92]
In addition, during the three fiscal quarters ended August 2, 2020 and August 4, 2019, we paid approximately $580 million and $818 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million and 3 million shares of common stock from employees in connection with such net share settlements during the three fiscal quarters ended August 2, 2020 and August 4, 2019, respectively.

[0001730168-20-000164:mdna:93]
[same as prior period, unchanged from 0001730168-20-000109:mdna:93]

[0001730168-20-000164:mdna:94]
|  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |
| Net cash provided by operating activities |  | $ | 8,713 |  |  | $ | 7,218 |  |
| Net cash used in investing activities |  | (11,009) |  |  | (15,334) |  |
| Net cash provided by financing activities |  | 6,098 |  |  | 9,286 |  |
| Net change in cash and cash equivalents |  | $ | 3,802 |  |  | $ | 1,170 |  |

[0001730168-20-000164:mdna:95]
[same as prior period, unchanged from 0001730168-20-000109:mdna:95]

[0001730168-20-000164:mdna:96]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,495 million increase in cash provided by operations during the three fiscal quarters ended August 2, 2020 compared to the prior year fiscal period was due to cash flows from net income adjusted for non-cash items and an increase in the net change in operating assets and liabilities as discussed in large part under Working Capital above.

[0001730168-20-000164:mdna:97]
[same as prior period, unchanged from 0001730168-20-000109:mdna:97]

[0001730168-20-000164:mdna:98]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures and proceeds from sales of businesses. The $4,325 million decrease in cash used in investing activities during the three fiscal quarters ended August 2, 2020 compared to the prior year fiscal period was primarily related to a $5,161 million decrease in cash paid for acquisitions in the fiscal year 2020 period, offset in part by $739 million less in proceeds received from sales of businesses in the fiscal year 2020 period.

[0001730168-20-000164:mdna:99]
[same as prior period, unchanged from 0001730168-20-000109:mdna:99]

[0001730168-20-000164:mdna:100]
Cash flows from financing activities primarily consisted of net proceeds and payments related to our long-term borrowings, dividend payments and stock repurchases. The $3,188 million decrease in cash provided by financing activities during the three fiscal quarters ended August 2, 2020 compared to the prior year fiscal period was primarily due to a $7,435 million decrease in net proceeds from borrowings as a result of debt repayments and a $958 million increase in dividend payments, partially offset by the absence of repurchases of common stock under our repurchase program, which ended in fiscal year 2019, as compared to $5,002 million of repurchases in the fiscal year 2019 period.

[0001730168-20-000164:mdna:101]
[same as prior period, unchanged from 0001730168-20-000109:mdna:101]

[0001730168-20-000164:mdna:102]
[same as prior period, unchanged from 0001730168-20-000109:mdna:102]

[0001730168-20-000164:mdna:103]
[same as prior period, unchanged from 0001730168-20-000109:mdna:103]

[0001730168-20-000164:mdna:104]
Pursuant to the indentures dated May 21, 2020, May 8, 2020, April 9, 2020, and April 5, 2019 (collectively, the “2020 and 2019 Indentures”), Broadcom issued $3,917 million, $8,000 million, $4,500 million, and $11,000 million aggregate principal amount of notes, respectively (collectively, the “2020 and 2019 Senior Notes”). Substantially all of the 2020 and 2019 Senior Notes have been registered with the SEC in connection with an exchange offer that closed on August 10, 2020.

[0001730168-20-000164:mdna:105]
We may redeem all or a portion of our 2020 and 2019 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the indentures governing the respective notes. In the event of a change of control triggering event, holders of our 2020 and 2019 Senior Notes will have the right to require us to purchase for cash, all or a portion of their respective notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2020 and 2019 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of the Obligor Group, as defined below, to merge, consolidate or sell all or substantially all of their assets.

[0001730168-20-000164:mdna:106]
Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”), 100%-owned subsidiaries of Broadcom (Broadcom, BRCM and BTI collectively, the “Obligor Group”), fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2020 and 2019 Senior Notes. The guarantee by BRCM and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the respective indentures. The guarantee by BRCM and BTI will also be automatically and unconditionally released if at any time the aggregate principal amount of indebtedness issued, borrowed or guaranteed by BRCM and BTI constitutes no more than 20% of the aggregate principal amount of indebtedness for borrowed money of Broadcom and its subsidiaries on a consolidated basis.

[0001730168-20-000164:mdna:107]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), BRCM and Broadcom Cayman Finance Limited (“Cayman Finance,” a 100%-owned subsidiary of Broadcom, together with BRCM, the “2017 Senior Notes Co-Issuers”) issued $13,550 million and $4,000 million aggregate principal amount of notes, respectively (collectively, the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-20-000164:mdna:108]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom and the 2017 Senior Notes Co-Issuers to merge, consolidate or sell all or substantially all of their assets.

[0001730168-20-000164:mdna:109]
Broadcom and BTI fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2017 Senior Notes. Because the guarantees are not secured, they are effectively subordinated to any existing and future secured indebtedness of the guarantors to the extent of the value of the collateral securing that indebtedness. The guarantee by Broadcom and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the 2017 Indentures. The guarantee by Broadcom (1) will also be automatically and unconditionally released at such time as: (A) the 2017 Senior Notes Co-Issuers, in their sole discretion, determine that such guarantee is no longer required by Rule 3-10(a), as applicable, of Regulation S-X to except the 2017 Senior Notes Co-Issuers’ financial statements from being required to be filed pursuant to Rule 3-10(a) of Regulation S-X or otherwise facilitate a reduction in its financial reporting obligations or (B) either of the 2017 Senior Notes Co-Issuers becomes subject to Section 13 or 15(d) of the Exchange Act and (2) may, at the election of the 2017 Senior Notes Co-Issuers, be unconditionally released at such time as Broadcom is eligible to suspend its reporting obligation under the Exchange Act.

[0001730168-20-000164:mdna:110]
During fiscal year 2019, Cayman Finance was merged into BTI, with BTI remaining as the surviving entity. In connection with this merger, BTI remains a guarantor and became a co-issuer of the 2017 Senior Notes.

[0001730168-20-000164:mdna:111]
[same as prior period, unchanged from 0001730168-20-000109:mdna:108]

[0001730168-20-000164:mdna:112]
39

[0001730168-20-000164:mdna:113]
| Summarized Balance Sheets |  | August 2,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 2,123 |  |  | $ | 1,617 |  |
| Other current assets |  | 5,287 |  |  | 1,082 |  |
| Total current assets |  | $ | 7,410 |  |  | $ | 2,699 |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 8,220 |  |  | $ | — |  |
| Goodwill |  | 1,360 |  |  | 1,360 |  |
| Other long-term assets |  | 1,251 |  |  | 955 |  |
| Total long-term assets |  | $ | 10,831 |  |  | $ | 2,315 |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 6,106 |  |  | $ | 9,223 |  |
| Current portion of long-term debt |  | 807 |  |  | 2,750 |  |
| Other current liabilities |  | 313 |  |  | 452 |  |
| Total current liabilities |  | $ | 7,226 |  |  | $ | 12,425 |  |
| Long-term liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group, long-term |  | $ | 932 |  |  | $ | 932 |  |
| Long-term debt |  | 42,274 |  |  | 28,171 |  |
| Other long-term liabilities |  | 2,511 |  |  | 2,108 |  |
| Total long-term liabilities |  | $ | 45,717 |  |  | $ | 31,211 |  |

[0001730168-20-000164:mdna:114]
|  |  | Three Fiscal Quarters Ended |
| Summarized Statement of Operations |  | August 2,2020 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 1,268 |  |
| Gross margin |  | $ | 1,154 |  |
| Loss from continuing operations (a) |  | $ | (1,349) |  |
| Net loss |  | $ | (1,349) |  |

[0001730168-20-000164:mdna:115]
[same as prior period, unchanged from 0001730168-20-000109:mdna:112]

[0001730168-20-000164:mdna:116]
(a) Included $486 million of net income from the Non-Obligor Group related to intercompany transactions.

[0001730168-20-000164:mdna:117]
[same as prior period, unchanged from 0001730168-20-000109:mdna:114]

[0001730168-20-000164:mdna:118]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000164:mdna:119]
[same as prior period, unchanged from 0001730168-20-000109:mdna:116]

[0001730168-20-000164:mdna:120]
We had no material off-balance sheet arrangements at August 2, 2020 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-20-000164:mdna:121]
[same as prior period, unchanged from 0001730168-20-000109:mdna:118]

[0001730168-20-000164:mdna:122]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000164:mdna:123]
[same as prior period, unchanged from 0001730168-20-000109:mdna:120]

[0001730168-20-000164:mdna:124]
[same as prior period, unchanged from 0001730168-20-000109:mdna:121]

[0001730168-20-000164:mdna:125]
40
