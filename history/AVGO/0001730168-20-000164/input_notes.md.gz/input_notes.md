# AVGO notes — 0001730168-20-000164


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-20-000164:notes:1]
[same as prior period, unchanged from 0001730168-20-000109:notes:1]

[0001730168-20-000164:notes:2]
[same as prior period, unchanged from 0001730168-20-000109:notes:2]

[0001730168-20-000164:notes:3]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing on the acquisition date.

[0001730168-20-000164:notes:4]
[same as prior period, unchanged from 0001730168-20-000109:notes:4]

[0001730168-20-000164:notes:5]
[same as prior period, unchanged from 0001730168-20-000109:notes:5]

[0001730168-20-000164:notes:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ended on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

[0001730168-20-000164:notes:7]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

[0001730168-20-000164:notes:8]
[same as prior period, unchanged from 0001730168-20-000109:notes:8]

[0001730168-20-000164:notes:9]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgement and carry a higher degree of variability and volatility, and may change materially in future periods.

[0001730168-20-000164:notes:10]
[same as prior period, unchanged from 0001730168-20-000109:notes:10]

[0001730168-20-000164:notes:11]
Recent Accounting Guidance

[0001730168-20-000164:notes:12]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for 
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. This guidance had no impact on our contracts as of August 2, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-20-000164:notes:13]
[same as prior period, unchanged from 0001730168-20-000109:notes:16]

[0001730168-20-000164:notes:14]
[same as prior period, unchanged from 0001730168-20-000109:notes:17]

[0001730168-20-000164:notes:15]
[same as prior period, unchanged from 0001730168-20-000109:notes:18]

[0001730168-20-000164:notes:16]
[same as prior period, unchanged from 0001730168-20-000109:notes:19]

[0001730168-20-000164:notes:17]
|  |  | Fiscal Quarter Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

[0001730168-20-000164:notes:18]
|  |  | Fiscal Quarter Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |

[0001730168-20-000164:notes:19]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |

[0001730168-20-000164:notes:20]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |

[0001730168-20-000164:notes:21]
[same as prior period, unchanged from 0001730168-20-000109:notes:24]

[0001730168-20-000164:notes:22]
[same as prior period, unchanged from 0001730168-20-000109:notes:25]

[0001730168-20-000164:notes:23]
Although we recognize revenue for the majority of our semiconductor products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.

[0001730168-20-000164:notes:24]
[same as prior period, unchanged from 0001730168-20-000109:notes:27]

[0001730168-20-000164:notes:25]
[same as prior period, unchanged from 0001730168-20-000109:notes:28]

[0001730168-20-000164:notes:26]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of August 2, 2020 (a) |  | $ | 158 |  |  | $ | 3,463 |  |

[0001730168-20-000164:notes:27]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of August 2, 2020.

[0001730168-20-000164:notes:28]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |

[0001730168-20-000164:notes:29]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balances do not include contract assets or contract liabilities associated with CA.

[0001730168-20-000164:notes:30]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.

[0001730168-20-000164:notes:31]
[same as prior period, unchanged from 0001730168-20-000109:notes:35]

[0001730168-20-000164:notes:32]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to

[0001730168-20-000164:notes:33]
not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-20-000164:notes:34]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 2, 2020 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-20-000164:notes:35]
[same as prior period, unchanged from 0001730168-20-000109:notes:38]

[0001730168-20-000164:notes:36]
[same as prior period, unchanged from 0001730168-20-000109:notes:39]

[0001730168-20-000164:notes:37]
[same as prior period, unchanged from 0001730168-20-000109:notes:40]

[0001730168-20-000164:notes:38]
[same as prior period, unchanged from 0001730168-20-000109:notes:41]

[0001730168-20-000164:notes:39]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 273 |  |
| Goodwill |  | 6,638 |  |
| Intangible assets |  | 5,411 |  |
| Other long-term assets |  | 92 |  |
| Total assets acquired |  | 12,414 |  |
| Current liabilities |  | (1,127) |  |
| Other long-term liabilities |  | (587) |  |
| Total liabilities assumed |  | (1,714) |  |
| Fair value of net assets acquired |  | $ | 10,700 |  |

[0001730168-20-000164:notes:40]
[same as prior period, unchanged from 0001730168-20-000109:notes:43]

[0001730168-20-000164:notes:41]
[same as prior period, unchanged from 0001730168-20-000109:notes:44]

[0001730168-20-000164:notes:42]
Revenue attributable to the Symantec Business has been included in our infrastructure software segment. Transaction costs related to the Symantec Asset Purchase of $110 million were included in selling, general and administrative expense for the three fiscal quarters ended August 2, 2020.

[0001730168-20-000164:notes:43]
[same as prior period, unchanged from 0001730168-20-000109:notes:46]

[0001730168-20-000164:notes:44]
[same as prior period, unchanged from 0001730168-20-000109:notes:47]

[0001730168-20-000164:notes:45]
[same as prior period, unchanged from 0001730168-20-000109:notes:48]

[0001730168-20-000164:notes:46]
[same as prior period, unchanged from 0001730168-20-000109:notes:49]

[0001730168-20-000164:notes:47]
[same as prior period, unchanged from 0001730168-20-000109:notes:50]

[0001730168-20-000164:notes:48]
[same as prior period, unchanged from 0001730168-20-000109:notes:51]

[0001730168-20-000164:notes:49]
[same as prior period, unchanged from 0001730168-20-000109:notes:52]

[0001730168-20-000164:notes:50]
[same as prior period, unchanged from 0001730168-20-000109:notes:53]

[0001730168-20-000164:notes:51]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if we had completed the Symantec Asset Purchase as of the beginning of fiscal year 2019. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the three fiscal quarters ended August 4, 2019, non-recurring pro forma adjustments directly attributable to the Symantec Asset Purchase included transaction costs of $136 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-20-000164:notes:52]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Pro forma net revenue |  | $ | 5,687 |  |  | $ | 5,873 |  |  | $ | 16,894 |  |  | $ | 18,133 |  |
| Pro forma net income attributable to common stock |  | $ | 549 |  |  | $ | 344 |  |  | $ | 1,181 |  |  | $ | 786 |  |

[0001730168-20-000164:notes:53]
[same as prior period, unchanged from 0001730168-20-000109:notes:56]

[0001730168-20-000164:notes:54]
[same as prior period, unchanged from 0001730168-20-000109:notes:57]

[0001730168-20-000164:notes:55]
[same as prior period, unchanged from 0001730168-20-000109:notes:58]

[0001730168-20-000164:notes:56]
[same as prior period, unchanged from 0001730168-20-000109:notes:59]

[0001730168-20-000164:notes:57]
[same as prior period, unchanged from 0001730168-20-000109:notes:60]

[0001730168-20-000164:notes:58]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 4,2019 |  | August 4,2019 |
|  |  | (In millions) |  |  |
| Pro forma net revenue |  | $ | 5,287 |  |  | $ | 16,137 |  |
| Pro forma net income attributable to common stock |  | $ | 542 |  |  | $ | 1,895 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-20-000164:notes:59]
[same as prior period, unchanged from 0001730168-20-000109:notes:62]

[0001730168-20-000164:notes:60]
Cash equivalents included $1,858 million and $850 million of time deposits and $1,531 million and $649 million of money-market funds as of August 2, 2020 and November 3, 2019, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-20-000164:notes:61]
[same as prior period, unchanged from 0001730168-20-000109:notes:64]

[0001730168-20-000164:notes:62]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $927 million and $2,754 million during the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, and $375 million and $465 million during the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any of the periods presented.

[0001730168-20-000164:notes:63]
[same as prior period, unchanged from 0001730168-20-000109:notes:66]

[0001730168-20-000164:notes:64]
|  |  | August 2,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Finished goods |  | $ | 372 |  |  | $ | 339 |  |
| Work-in-process |  | 517 |  |  | 414 |  |
| Raw materials |  | 192 |  |  | 121 |  |
| Total inventory |  | $ | 1,081 |  |  | $ | 874 |  |

[0001730168-20-000164:notes:65]
[same as prior period, unchanged from 0001730168-20-000109:notes:68]

[0001730168-20-000164:notes:66]
|  |  | August 2,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Prepaid expenses |  | $ | 433 |  |  | $ | 302 |  |
| Other (miscellaneous) |  | 626 |  |  | 427 |  |
| Total other current assets |  | $ | 1,059 |  |  | $ | 729 |  |

[0001730168-20-000164:notes:67]
[same as prior period, unchanged from 0001730168-20-000109:notes:70]

[0001730168-20-000164:notes:68]
|  |  | August 2,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Contract liabilities |  | $ | 2,793 |  |  | $ | 1,501 |  |
| Tax liabilities |  | 387 |  |  | 229 |  |
| Other (miscellaneous) |  | 876 |  |  | 886 |  |
| Total other current liabilities |  | $ | 4,056 |  |  | $ | 2,616 |  |

[0001730168-20-000164:notes:69]
[same as prior period, unchanged from 0001730168-20-000109:notes:72]

[0001730168-20-000164:notes:70]
|  |  | August 2,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Unrecognized tax benefits |  | $ | 3,307 |  |  | $ | 3,269 |  |
| Contract liabilities |  | 670 |  |  | 307 |  |
| Other (miscellaneous) |  | 1,833 |  |  | 2,037 |  |
| Total other long-term liabilities |  | $ | 5,810 |  |  | $ | 5,613 |  |

[0001730168-20-000164:notes:71]
[same as prior period, unchanged from 0001730168-20-000109:notes:74]

[0001730168-20-000164:notes:72]
Other income, net for the three fiscal quarters ended August 2, 2020 included a $116 million one-time gain from the lapse of a tax indemnification arrangement.

[0001730168-20-000164:notes:73]
[same as prior period, unchanged from 0001730168-20-000109:notes:76]

[0001730168-20-000164:notes:74]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |  |  |
|  |  | (In millions) |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 269 |  |  | $ | 368 |  |  | $ | 1,025 |  |  | $ | 980 |  |  |  |
| Cash paid for income taxes |  | $ | 44 |  |  | $ | 98 |  |  | $ | 299 |  |  | $ | 618 |  |  |  |

[0001730168-20-000164:notes:75]
As of August 2, 2020 and August 4, 2019, $37 million and $30 million, respectively, of unpaid purchases of property, plant and equipment were included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001730168-20-000164:notes:76]
[same as prior period, unchanged from 0001730168-20-000109:notes:79]

[0001730168-20-000164:notes:77]
We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize ROU assets and lease liabilities for operating and finance leases with terms greater than 12 months. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease

[0001730168-20-000164:notes:78]
commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective-interest method over the lease term.

[0001730168-20-000164:notes:79]
We entered into operating and finance leases for our facilities, data centers and certain equipment. For the fiscal quarter and three fiscal quarters ended August 2, 2020, we recorded $27 million and $78 million of operating lease expense, respectively, and $4 million and $9 million of finance lease expense, respectively. For the fiscal quarter and three fiscal quarters ended August 4, 2019, rent expense was $61 million and $187 million, respectively.

[0001730168-20-000164:notes:80]
[same as prior period, unchanged from 0001730168-20-000109:notes:83]

[0001730168-20-000164:notes:81]
|  |  | Three Fiscal Quarters Ended |  |
|  |  | August 2,2020 |  |
|  |  | (In millions) |  |
| Cash paid for operating leases included in operating cash flows |  | $ | 92 |  |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 674 |  |  |
| ROU assets obtained in exchange for finance lease liabilities |  | $ | 74 |  |  |
|  |  | August 2,2020 |  |
| Weighted-average remaining lease term – operating leases (In years) |  | 10 |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 4 |  |
| Weighted-average discount rate – operating leases |  | 3.79 |  | % |
| Weighted-average discount rate – finance leases |  | 3.33 |  | % |

[0001730168-20-000164:notes:82]
[same as prior period, unchanged from 0001730168-20-000109:notes:85]

[0001730168-20-000164:notes:83]
|  |  | Classification on the Condensed Consolidated Balance Sheet |  | August 2,2020 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  | $ | 606 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  | $ | 65 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  | $ | 100 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 546 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  | $ | 15 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 52 |  |

[0001730168-20-000164:notes:84]
[same as prior period, unchanged from 0001730168-20-000109:notes:87]

[0001730168-20-000164:notes:85]
|  |  | August 2,2020 |  |  |
|  |  | Operating Leases |  | Finance Leases |
|  |  | (In millions) |  |  |
| 2020 (remainder) |  | $ | 30 |  |  | $ | 4 |  |
| 2021 |  | 117 |  |  | 17 |  |
| 2022 |  | 94 |  |  | 17 |  |
| 2023 |  | 83 |  |  | 17 |  |
| 2024 |  | 64 |  |  | 17 |  |
| Thereafter |  | 409 |  |  | — |  |
| Total undiscounted liabilities |  | 797 |  |  | 72 |  |
| Less: interest |  | 151 |  |  | 5 |  |
| Present value of lease liabilities |  | $ | 646 |  |  | $ | 67 |  |

[0001730168-20-000164:notes:86]
[same as prior period, unchanged from 0001730168-20-000109:notes:89]

[0001730168-20-000164:notes:87]
[same as prior period, unchanged from 0001730168-20-000109:notes:90]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-20-000164:notes:88]
[same as prior period, unchanged from 0001730168-20-000109:notes:91]

[0001730168-20-000164:notes:89]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  |  |  |  |  |  |  |  |  | (In millions) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  |  |  |  |  |  |  |  |  | $ | 25,929 |  |  | $ | 10,776 |  |  | $ | 9 |  |  | $ | 36,714 |  |
| Reallocation due to change in segments |  |  |  |  |  |  |  |  |  | 9 |  |  | — |  |  | (9) |  |  | — |  |
| Acquisitions |  |  |  |  |  |  |  |  |  | 35 |  |  | 6,712 |  |  | — |  |  | 6,747 |  |
| Sale of business |  |  |  |  |  |  |  |  |  | (14) |  |  | — |  |  | — |  |  | (14) |  |
| Balance as of August 2, 2020 |  |  |  |  |  |  |  |  |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | — |  |  | $ | 43,447 |  |

[0001730168-20-000164:notes:90]
[same as prior period, unchanged from 0001730168-20-000109:notes:93]

[0001730168-20-000164:notes:91]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |  |  |  |  |
| As of August 2, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,119 |  |  | $ | (12,965) |  |  | $ | 11,154 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (2,832) |  |  | 5,557 |  |

[0001730168-20-000164:notes:92]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |  |  |  |  |
| Order backlog |  | 2,579 |  |  | (1,604) |  |  | 975 |  |
| Trade names |  | 797 |  |  | (302) |  |  | 495 |  |
| Other |  | 260 |  |  | (109) |  |  | 151 |  |
| Intangible assets subject to amortization |  | 36,144 |  |  | (17,812) |  |  | 18,332 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,169 |  |  | $ | (17,812) |  |  | $ | 18,357 |  |
| As of November 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,935 |  |  | $ | (10,113) |  |  | $ | 10,822 |  |
| Customer contracts and related relationships |  | 5,978 |  |  | (1,787) |  |  | 4,191 |  |
| Order backlog |  | 2,569 |  |  | (908) |  |  | 1,661 |  |
| Trade names |  | 712 |  |  | (247) |  |  | 465 |  |
| Other |  | 241 |  |  | (89) |  |  | 152 |  |
| Intangible assets subject to amortization |  | 30,435 |  |  | (13,144) |  |  | 17,291 |  |
| In-process research and development |  | 263 |  |  | — |  |  | 263 |  |
| Total |  | $ | 30,698 |  |  | $ | (13,144) |  |  | $ | 17,554 |  |

[0001730168-20-000164:notes:93]
Based on the amount of intangible assets subject to amortization at August 2, 2020, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-20-000164:notes:94]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 1,568 |  |
| 2021 |  | 5,417 |  |
| 2022 |  | 4,374 |  |
| 2023 |  | 3,237 |  |
| 2024 |  | 2,365 |  |
| Thereafter |  | 1,371 |  |
| Total |  | $ | 18,332 |  |

[0001730168-20-000164:notes:95]
[same as prior period, unchanged from 0001730168-20-000109:notes:98]

[0001730168-20-000164:notes:96]
| Amortizable intangible assets: |  | August 2,2020 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 4 |
| Order backlog |  | 2 |
| Trade names |  | 9 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-20-000164:notes:97]
[same as prior period, unchanged from 0001730168-20-000109:notes:100]

[0001730168-20-000164:notes:98]
[same as prior period, unchanged from 0001730168-20-000109:notes:101]

[0001730168-20-000164:notes:99]
[same as prior period, unchanged from 0001730168-20-000109:notes:102]

[0001730168-20-000164:notes:100]
For each of the fiscal quarter and three fiscal quarters ended August 2, 2020, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-20-000164:notes:101]
[same as prior period, unchanged from 0001730168-20-000109:notes:104]

[0001730168-20-000164:notes:102]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 689 |  |  | $ | 715 |  |  | $ | 1,637 |  |  | $ | 1,889 |  |
| Dividends on preferred stock |  | (74) |  |  | — |  |  | (223) |  |  | — |  |
| Income from continuing operations attributable to common stock |  | 615 |  |  | 715 |  |  | 1,414 |  |  | 1,889 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (1) |  |  | — |  |  | (1) |  |  | (12) |  |
| Net income attributable to common stock |  | $ | 614 |  |  | $ | 715 |  |  | $ | 1,413 |  |  | $ | 1,877 |  |

[0001730168-20-000164:notes:103]
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 403 |  |  | 398 |  |  | 401 |  |  | 399 |  |
| Dilutive effect of equity awards |  | 19 |  |  | 20 |  |  | 19 |  |  | 21 |  |
| Weighted-average shares outstanding - diluted |  | 422 |  |  | 418 |  |  | 420 |  |  | 420 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.53 |  |  | $ | 1.80 |  |  | $ | 3.53 |  |  | $ | 4.73 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | — |  |  | (0.01) |  |  | (0.03) |  |
| Net income per share |  | $ | 1.52 |  |  | $ | 1.80 |  |  | $ | 3.52 |  |  | $ | 4.70 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.46 |  |  | $ | 1.71 |  |  | $ | 3.37 |  |  | $ | 4.50 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | — |  |  | (0.01) |  |  | (0.03) |  |
| Net income per share |  | $ | 1.45 |  |  | $ | 1.71 |  |  | $ | 3.36 |  |  | $ | 4.47 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-20-000164:notes:104]
Borrowings

[0001730168-20-000164:notes:105]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.56 | % |  | 4,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.58 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

[0001730168-20-000164:notes:106]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%-4.55% |  | 22 |  |  | 2.59%-4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 44,498 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  | (542) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 43,956 |  |  |  |  | $ | 32,798 |  |

[0001730168-20-000164:notes:107]
________________________________________________________________

[0001730168-20-000164:notes:108]
(a) Represents the weighted average interest rate on outstanding commercial paper.

[0001730168-20-000164:notes:109]
As of August 2, 2020, $15 million of short-term and $52 million of long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

[0001730168-20-000164:notes:110]
June 2020 Senior Notes

[0001730168-20-000164:notes:111]
On June 4, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024, for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “June 2020 Senior Notes”). As a result of this exchange, we incurred premiums of $177 million. The June 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). We may, at our option, redeem or purchase, in whole or in part, any of the June 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the June 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the June 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000164:notes:112]
May 2020 Senior Notes

[0001730168-20-000164:notes:113]
On May 8, 2020, we issued $8 billion of senior unsecured notes, which consisted of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the May 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000164:notes:114]
The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, as defined below, were used to repay an aggregate of $5,424 million of term loans outstanding under the November 2019 Credit Agreement, as defined below, consisting of repayments of $2,712 million of each of our unsecured term A-3 and A-5 facilities, and $3 billion of borrowings outstanding under the Revolving Facility, as defined below.

[0001730168-20-000164:notes:115]
April 2020 Senior Notes

[0001730168-20-000164:notes:116]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus

[0001730168-20-000164:notes:117]
accrued and unpaid interest. As of August 2, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000164:notes:118]
Pursuant to a cash tender offer that we completed on April 23, 2020, we repurchased $2,361 million of our 3.000% notes due January 2022, $1,274 million of our 3.125% notes due April 2021 and $351 million of our 2.200% notes due January 2021 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense in the condensed consolidated statements of operations.

[0001730168-20-000164:notes:119]
November 2019 Term Loans

[0001730168-20-000164:notes:120]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “November 2019 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the November 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. During the fiscal quarter ended May 3, 2020, we repaid $194 million of each of our unsecured term A-3 and A-5 facilities.

[0001730168-20-000164:notes:121]
During the fiscal quarter ended August 2, 2020, as discussed above, we used the net proceeds from the May 2020 Senior Notes and the remaining net proceeds from the April 2020 Senior Notes to repay a portion of our November 2019 Term Loans. Additionally, we made repayments with cash on hand. In total, we repaid an aggregate of $6,224 million of our November 2019 Term Loans, consisting of repayments of $2,737 million and $3,487 million of our unsecured term A-3 and A-5 facilities, respectively, and wrote off $44 million of unamortized discount and issuance costs. As a result of these repayments, all remaining principal payments are due more than one year after August 2, 2020 and were included in long-term debt.

[0001730168-20-000164:notes:122]
May 2019 Term Loans

[0001730168-20-000164:notes:123]
In January 2020, we repaid an aggregate of $1 billion of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities (collectively, the “May 2019 Term Loans”) under the credit agreement entered into in May 2019 (the “May 2019 Credit Agreement”). In July 2020, we repaid an aggregate of $600 million of the May 2019 Term Loans, representing the outstanding balance of the May 2019 Term Loans.

[0001730168-20-000164:notes:124]
The May 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the May 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the May 2019 Credit Agreement in accordance with the terms thereof. On May 8, 2020, using net proceeds from the May 2020 Senior Notes and April 2020 Senior Notes, we repaid $3 billion of borrowings outstanding under the Revolving Facility. As of August 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

[0001730168-20-000164:notes:125]
Commercial Paper

[0001730168-20-000164:notes:126]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of August 2, 2020, we had no Commercial Paper outstanding. We had $1 billion of Commercial Paper outstanding as of November 3, 2019 with maturities generally less than three months. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we record Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

[0001730168-20-000164:notes:127]
Exchange Offer

[0001730168-20-000164:notes:128]
In connection with the issuance of the June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes (collectively, the “2020 Senior Notes”) and $11 billion of senior unsecured notes in April 2019 (the “April 2019 Senior Notes”), we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the SEC, and cause to be declared effective, a registration statement with respect to an offer to exchange (the “Exchange Offer”) each series of the 2020 Senior Notes and April 2019 Senior Notes for notes that are registered with the SEC (the “Registered Notes”), with substantially identical terms. On July 6, 2020, we launched the Exchange Offer, which expired on August 7, 2020. Substantially all of our 2020 Senior Notes and April 2019 Senior Notes were tendered and exchanged for the corresponding Registered Notes in the Exchange Offer.

[0001730168-20-000164:notes:129]
Fair Value of Debt

[0001730168-20-000164:notes:130]
As of August 2, 2020, the estimated aggregate fair value of debt was $48,483 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-20-000164:notes:131]
Future Principal Payments of Debt

[0001730168-20-000164:notes:132]
The future scheduled principal payments of debt as of August 2, 2020 were as follows:

[0001730168-20-000164:notes:133]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 6,069 |  |
| 2024 |  | 3,403 |  |
| Thereafter |  | 32,392 |  |
| Total |  | $ | 44,498 |  |

[0001730168-20-000164:notes:134]
As of August 2, 2020 and November 3, 2019, we accrued interest payable of $306 million and $214 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-20-000164:notes:135]
[same as prior period, unchanged from 0001730168-20-000109:notes:132]

[0001730168-20-000164:notes:136]
[same as prior period, unchanged from 0001730168-20-000109:notes:133]

[0001730168-20-000164:notes:137]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of August 2, 2020, the minimum conversion rate was 3.0516 and the maximum conversion rate was 3.5670.

[0001730168-20-000164:notes:138]
We recognized $28 million and $29 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets as of August 2, 2020 and November 3, 2019, respectively.

[0001730168-20-000164:notes:139]
[same as prior period, unchanged from 0001730168-20-000109:notes:136]

[0001730168-20-000164:notes:140]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Dividends per share to common stockholders |  | $ | 3.25 |  |  | $ | 2.65 |  |  | $ | 9.75 |  |  | $ | 7.95 |  |
| Dividends to common stockholders |  | $ | 1,312 |  |  | $ | 1,057 |  |  | $ | 3,915 |  |  | $ | 3,181 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | — |  |  | $ | 60.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 74 |  |  | $ | — |  |  | $ | 224 |  |  | $ | — |  |

[0001730168-20-000164:notes:141]
[same as prior period, unchanged from 0001730168-20-000109:notes:138]

[0001730168-20-000164:notes:142]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Cost of products sold |  | $ | 26 |  |  | $ | 34 |  |  | $ | 84 |  |  | $ | 89 |  |
| Cost of subscriptions and services |  | 11 |  |  | 13 |  |  | 37 |  |  | 33 |  |
| Research and development |  | 337 |  |  | 456 |  |  | 1,101 |  |  | 1,138 |  |
| Selling, general and administrative |  | 91 |  |  | 129 |  |  | 305 |  |  | 381 |  |
| Total stock-based compensation expense |  | $ | 465 |  |  | $ | 632 |  |  | $ | 1,527 |  |  | $ | 1,641 |  |

[0001730168-20-000164:notes:143]
As of August 2, 2020, the total unrecognized compensation cost related to unvested stock-based awards was $4,534 million, which is expected to be recognized over the remaining weighted-average service period of 3.6 years.

[0001730168-20-000164:notes:144]
[same as prior period, unchanged from 0001730168-20-000109:notes:141]

[0001730168-20-000164:notes:145]
[same as prior period, unchanged from 0001730168-20-000109:notes:142]

[0001730168-20-000164:notes:146]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |  |  |  |  |
| Granted |  | 2 |  |  | $ | 250.82 |  |  |  |  |  |
| Vested |  | (6) |  |  | $ | 207.57 |  |  |  |  |  |
| Forfeited |  | (2) |  |  | $ | 197.88 |  |  |  |  |  |
| Balance as of August 2, 2020 |  | 34 |  |  | $ | 189.99 |  |  |  |  |  |

[0001730168-20-000164:notes:147]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended August 2, 2020 was $1,670 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-20-000164:notes:148]
[same as prior period, unchanged from 0001730168-20-000109:notes:145]

[0001730168-20-000164:notes:149]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  |  |  |  |
| Exercised |  | (2) |  |  | $ | 48.01 |  |  |  |  | $ | 629 |  |
| Balance as of August 2, 2020 |  | 2 |  |  | $ | 56.97 |  |  | 0.5 |  | $ | 489 |  |
| Fully vested as of August 2, 2020 |  | 2 |  |  | $ | 56.98 |  |  | 0.5 |  | $ | 488 |  |
| Fully vested and expected to vest as of August 2, 2020 |  | 2 |  |  | $ | 56.97 |  |  | 0.5 |  | $ | 489 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-20-000164:notes:150]
[same as prior period, unchanged from 0001730168-20-000109:notes:147]

[0001730168-20-000164:notes:151]
The benefit from income taxes was $96 million and $331 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively, compared to $171 million and $410 million for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively.

[0001730168-20-000164:notes:152]
The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 2, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards that vested or were exercised during the periods.

[0001730168-20-000164:notes:153]
[same as prior period, unchanged from 0001730168-20-000109:notes:150]

[0001730168-20-000164:notes:154]
The benefit from income taxes for the fiscal quarter ended August 4, 2019 was primarily due to the remeasurement of certain foreign deferred tax assets and liabilities, internal reorganizations and excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-20-000164:notes:155]
The benefit from income taxes for the three fiscal quarters ended August 4, 2019 was primarily due to excess tax benefits from stock-based awards that vested or were exercised during the period, recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, deferred tax remeasurement in a foreign jurisdiction, internal reorganizations, and the partial release of our valuation allowance as a result of the CA Merger, partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act.

[0001730168-20-000164:notes:156]
[same as prior period, unchanged from 0001730168-20-000109:notes:153]

[0001730168-20-000164:notes:157]
[same as prior period, unchanged from 0001730168-20-000109:notes:154]

[0001730168-20-000164:notes:158]
The balance of gross unrecognized tax benefits was $4,643 million and $4,422 million as of August 2, 2020 and November 3, 2019, respectively. This increase was primarily due to changes in uncertain tax positions from adjustments arising from audits conducted by tax authorities.

[0001730168-20-000164:notes:159]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of August 2, 2020 and November 3, 2019, the combined amount of cumulative accrued interest and penalties was approximately $336 million and $303 million, respectively.

[0001730168-20-000164:notes:160]
As of August 2, 2020 and November 3, 2019, approximately $4,979 million and $4,725 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-20-000164:notes:161]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our 
existing unrecognized tax benefits may change up to $263 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-20-000164:notes:162]
[same as prior period, unchanged from 0001730168-20-000109:notes:159]

[0001730168-20-000164:notes:163]
[same as prior period, unchanged from 0001730168-20-000109:notes:160]

[0001730168-20-000164:notes:164]
[same as prior period, unchanged from 0001730168-20-000109:notes:161]

[0001730168-20-000164:notes:165]
[same as prior period, unchanged from 0001730168-20-000109:notes:162]

[0001730168-20-000164:notes:166]
[same as prior period, unchanged from 0001730168-20-000109:notes:163]

[0001730168-20-000164:notes:167]
[same as prior period, unchanged from 0001730168-20-000109:notes:164]

[0001730168-20-000164:notes:168]
[same as prior period, unchanged from 0001730168-20-000109:notes:165]

[0001730168-20-000164:notes:169]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020 and August 4, 2019. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-20-000164:notes:170]
|  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,219 |  |  | $ | 4,375 |  |  | $ | 12,437 |  |  | $ | 12,865 |  |
| Infrastructure software |  | 1,602 |  |  | 1,140 |  |  | 4,984 |  |  | 3,956 |  |
| Total net revenue |  | $ | 5,821 |  |  | $ | 5,515 |  |  | $ | 17,421 |  |  | $ | 16,821 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,045 |  |  | $ | 2,081 |  |  | $ | 5,864 |  |  | $ | 6,012 |  |
| Infrastructure software |  | 1,136 |  |  | 829 |  |  | 3,432 |  |  | 2,899 |  |
| Unallocated expenses |  | (2,173) |  |  | (2,045) |  |  | (6,808) |  |  | (6,521) |  |
| Total operating income |  | $ | 1,008 |  |  | $ | 865 |  |  | $ | 2,488 |  |  | $ | 2,390 |  |

[0001730168-20-000164:notes:171]
[same as prior period, unchanged from 0001730168-20-000109:notes:168]

[0001730168-20-000164:notes:172]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. No customer accounted for 10% or more of our net accounts receivable balance as of August 2, 2020, while one customer accounted for 24% of our net accounts receivable balance as of November 3, 2019.
No customer accounted for 10% or more of our net revenue for the fiscal quarter ended August 2, 2020. One customer accounted for 12% of our net revenue for the three fiscal quarters ended August 2, 2020, and 16% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively. Net revenue from this customer was primarily included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-20-000164:notes:173]
Commitments and Contingencies
Commitments

[0001730168-20-000164:notes:174]
The following table summarizes contractual obligations and commitments as of August 2, 2020 that materially changed from the end of fiscal year 2019:

[0001730168-20-000164:notes:175]
|  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt principal, interest and fees |  | $ | 54,772 |  |  | $ | 375 |  |  | $ | 2,327 |  |  | $ | 3,314 |  |  | $ | 7,440 |  |  | $ | 4,705 |  |  | $ | 36,611 |  |
| Purchase commitments |  | 1,034 |  |  | 820 |  |  | 163 |  |  | 51 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 1,098 |  |  | 122 |  |  | 196 |  |  | 183 |  |  | 172 |  |  | 126 |  |  | 299 |  |
| Total |  | $ | 56,904 |  |  | $ | 1,317 |  |  | $ | 2,686 |  |  | $ | 3,548 |  |  | $ | 7,612 |  |  | $ | 4,831 |  |  | $ | 36,910 |  |

[0001730168-20-000164:notes:176]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 2, 2020.

[0001730168-20-000164:notes:177]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-20-000164:notes:178]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-20-000164:notes:179]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,307 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 2, 2020 have been excluded from the contractual obligations table above.

[0001730168-20-000164:notes:180]
Standby Letters of Credit

[0001730168-20-000164:notes:181]
As of August 2, 2020 and November 3, 2019, we had standby letters of credit of $63 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-20-000164:notes:182]
Contingencies

[0001730168-20-000164:notes:183]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-20-000164:notes:184]
Lawsuits Relating to California Institute of Technology

[0001730168-20-000164:notes:185]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgement interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgement, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgement interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

[0001730168-20-000164:notes:186]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgement and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

[0001730168-20-000164:notes:187]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-20-000164:notes:188]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and

[0001730168-20-000164:notes:189]
approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

[0001730168-20-000164:notes:190]
Other Matters

[0001730168-20-000164:notes:191]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-20-000164:notes:192]
Contingency Assessment

[0001730168-20-000164:notes:193]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-20-000164:notes:194]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-20-000164:notes:195]
Other Indemnifications

[0001730168-20-000164:notes:196]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgement for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-20-000164:notes:197]
[same as prior period, unchanged from 0001730168-20-000109:notes:194]

[0001730168-20-000164:notes:198]
•During the first quarter of fiscal year 2020, we initiated cost reduction activities associated with the Symantec Asset Purchase. As a result, we recognized $61 million and $151 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020.

[0001730168-20-000164:notes:199]
•During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $22 million of restructuring expense during the three fiscal quarters ended August 2, 2020, and $35 million and $710 million during the fiscal quarter and three fiscal quarters ended August 4, 2019, respectively, primarily related to employee termination and lease and other exit costs. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020.

[0001730168-20-000164:notes:200]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended August 2, 2020:

[0001730168-20-000164:notes:201]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |  |  |  |  |
| Balance as of November 3, 2019 |  | $ | 69 |  |  | $ | 39 |  |  | $ | 108 |  |
| Restructuring charges (a) |  | 165 |  |  | 34 |  |  | 199 |  |
| Utilization |  | (130) |  |  | (37) |  |  | (167) |  |
| Effect of adoption of Topic 842 (b) |  | — |  |  | (36) |  |  | (36) |  |
| Balance as of August 2, 2020 (c) |  | $ | 104 |  |  | $ | — |  |  | $ | 104 |  |

[0001730168-20-000164:notes:202]
[same as prior period, unchanged from 0001730168-20-000109:notes:199]

[0001730168-20-000164:notes:203]
(a) Included $19 million of restructuring expense related to discontinued operations recognized during the three fiscal quarters ended August 2, 2020, which was included in loss from discontinued operations.

[0001730168-20-000164:notes:204]
[same as prior period, unchanged from 0001730168-20-000109:notes:201]

[0001730168-20-000164:notes:205]
(c) The majority of the employee termination costs balance is expected to be paid within the next six months.


## us-gaap:SubsequentEventsTextBlock

[0001730168-20-000164:notes:206]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-20-000164:notes:207]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2020 to stockholders of record on September 15, 2020.

[0001730168-20-000164:notes:208]
Common Stock Cash Dividends Declared

[0001730168-20-000164:notes:209]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on September 30, 2020 to stockholders of record on September 22, 2020.
