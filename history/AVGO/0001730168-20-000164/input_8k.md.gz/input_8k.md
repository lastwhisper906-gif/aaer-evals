# AVGO 8-K — 0001730168-20-000154 filed 2020-09-03

## item codes, every 8-K on or before 2020-09-11

- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2020-09-11

- none on or before 2020-09-11

## item 2.02 — earnings release, exhibit 99.1

[0001730168-20-000154:8k_2_02:1]
EX-99.1
2
avgo-08022020x8kxex99.htm
EX-99.1

[0001730168-20-000154:8k_2_02:2]
Document

[0001730168-20-000154:8k_2_02:3]
Exhibit 99.1

[0001730168-20-000154:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2020 Financial Results and Quarterly Dividends

[0001730168-20-000154:8k_2_02:5]
•Revenue of $5,821 million; GAAP net income of $688 million; Adjusted EBITDA of $3,342 million

[0001730168-20-000154:8k_2_02:6]
•GAAP diluted EPS of $1.45; Non-GAAP diluted EPS of $5.40

[0001730168-20-000154:8k_2_02:7]
•$3,073 million of free cash flow from operations, defined as cash from operations of $3,178 million less capital expenditures of $105 million

[0001730168-20-000154:8k_2_02:8]
•Quarterly common stock dividend of $3.25 per share

[0001730168-20-000154:8k_2_02:9]
•Fourth quarter revenue guidance of $6.4 billion plus or minus $150 million

[0001730168-20-000154:8k_2_02:10]
•Fourth quarter Adjusted EBITDA guidance of $3,744 million plus or minus $75 million, or 58.5% of revenue at the midpoint of guidance 1

[0001730168-20-000154:8k_2_02:11]
SAN JOSE, Calif. – September 3, 2020 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2020, ended August 2, 2020, provided guidance for the fourth quarter of its fiscal year 2020 and announced its quarterly dividends.

[0001730168-20-000154:8k_2_02:12]
“We delivered third quarter revenue results in-line with our expectations, driven by healthy demand from cloud and telecom customers, which more than offset the expected reset in wireless,” said Hock Tan, President and CEO of Broadcom Inc. “Our outlook for the fourth quarter reflects a strong anticipated ramp in wireless, as well as the continuing surge in demand for networking from cloud and telecom customers, more than offsetting expected softness in enterprise.”

[0001730168-20-000154:8k_2_02:13]
“We generated record free cash flow of over $3 billion, which represented 33 percent growth on a year on year basis, and reduced total debt by $1.9 billion in the quarter,” said Tom Krause, CFO of Broadcom Inc. “Looking ahead, our cash flow outlook remains robust and we plan to pay down an additional $3 billion in debt in the fourth quarter.”

[0001730168-20-000154:8k_2_02:14]
________________________________

[0001730168-20-000154:8k_2_02:15]
1 The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-20-000154:8k_2_02:16]
1

[0001730168-20-000154:8k_2_02:17]
Third Quarter Fiscal Year 2020 Financial Highlights

[0001730168-20-000154:8k_2_02:18]
|  |  | GAAP |  |  |  |  |  |  | Non-GAAP |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | Q3 20 |  | Q3 19 |  | Change |  |  | Q3 20 |  | Q3 19 |  | Change |  |
| Net revenue |  | $ | 5,821 |  |  | $ | 5,515 |  |  | +6 | % |  | $ | 5,821 |  |  | $ | 5,515 |  |  | +6 | % |
| Net income |  | $ | 688 |  |  | $ | 715 |  |  | -$27 |  |  | $ | 2,435 |  |  | $ | 2,281 |  |  | +$154 |  |
| Earnings per common share - diluted |  | $ | 1.45 |  |  | $ | 1.71 |  |  | -$0.26 |  |  | $ | 5.40 |  |  | $ | 5.16 |  |  | +$0.24 |  |

[0001730168-20-000154:8k_2_02:19]
| (Dollars in millions) |  | Q3 20 |  | Q3 19 |  | Change |
| Cash flow from operations |  | $ | 3,178 |  |  | $ | 2,419 |  |  | +$759 |
| Adjusted EBITDA |  | $ | 3,342 |  |  | $ | 3,064 |  |  | +$278 |
| Free cash flow |  | $ | 3,073 |  |  | $ | 2,307 |  |  | +$766 |

[0001730168-20-000154:8k_2_02:20]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 20 |  |  |  |  | Q3 19 |  |  |  |  | Change |  |
| Semiconductor solutions |  | $ | 4,219 |  |  | 72 | % |  | $ | 4,375 |  |  | 79 | % |  | -4 | % |
| Infrastructure software |  | 1,602 |  |  | 28 |  |  | 1,140 |  |  | 21 |  |  | +41 | % |
| Total net revenue |  | $ | 5,821 |  |  | 100 | % |  | $ | 5,515 |  |  | 100 | % |  |  |  |

[0001730168-20-000154:8k_2_02:21]
The Company’s cash and cash equivalents at the end of the third fiscal quarter were $8,857 million, compared to $9,207 million at the end of the prior quarter.

[0001730168-20-000154:8k_2_02:22]
During the third fiscal quarter, the Company generated $3,178 million in cash from operations and spent $105 million on capital expenditures.

[0001730168-20-000154:8k_2_02:23]
On June 30, 2020, the Company paid a cash dividend of $3.25 per share of common stock, totaling $1,312 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $74 million.

[0001730168-20-000154:8k_2_02:24]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-20-000154:8k_2_02:25]
Fourth Quarter Fiscal Year 2020 Business Outlook

[0001730168-20-000154:8k_2_02:26]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2020, ending November 1, 2020, is expected to be as follows:

[0001730168-20-000154:8k_2_02:27]
•Fourth quarter revenue guidance of $6.4 billion plus or minus $150 million; and

[0001730168-20-000154:8k_2_02:28]
•Fourth quarter Adjusted EBITDA of $3,744 million plus or minus $75 million, or 58.5% of revenue at the midpoint of guidance.

[0001730168-20-000154:8k_2_02:29]
2

[0001730168-20-000154:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000154:8k_2_02:31]
Broadcom Inc. will be presenting to investors at Deutsche Bank’s Virtual Technology Conference on September 15, 2020.

[0001730168-20-000154:8k_2_02:32]
Quarterly Dividends

[0001730168-20-000154:8k_2_02:33]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.25 per share. The common stock dividend is payable on September 30, 2020 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 22, 2020.

[0001730168-20-000154:8k_2_02:34]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on September 30, 2020 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 15, 2020.

[0001730168-20-000154:8k_2_02:35]
Financial Results Conference Call

[0001730168-20-000154:8k_2_02:36]
Broadcom Inc. will host a conference call to review its financial results for the third quarter of fiscal year 2020, ended August 2, 2020, and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 8878889. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 8878889. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001730168-20-000154:8k_2_02:37]
Basis of Presentation

[0001730168-20-000154:8k_2_02:38]
The Company’s financial results include contributions from the Symantec enterprise security business’ continuing operations starting in the first quarter of fiscal year 2020. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented above, unless otherwise stated.

[0001730168-20-000154:8k_2_02:39]
Non-GAAP Financial Measures

[0001730168-20-000154:8k_2_02:40]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gain from lapse of indemnification, gains (losses) on investments, gain from sale of business, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments.

[0001730168-20-000154:8k_2_02:41]
3

[0001730168-20-000154:8k_2_02:42]
Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual. Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-20-000154:8k_2_02:43]
Broadcom believes this non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release.

[0001730168-20-000154:8k_2_02:44]
About Broadcom Inc.

[0001730168-20-000154:8k_2_02:45]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to www.broadcom.com.

[0001730168-20-000154:8k_2_02:46]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-20-000154:8k_2_02:47]
4

[0001730168-20-000154:8k_2_02:48]
Particular uncertainties that could materially affect future results include risks associated with:  the COVID-19 pandemic, which has, and will likely continue to, negatively impact the global economy and disrupt normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; international political and economic conditions; government regulations, trade restrictions and trade tensions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; changes in accounting standards; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-20-000154:8k_2_02:49]
5

[0001730168-20-000154:8k_2_02:50]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000154:8k_2_02:51]
Contact:

[0001730168-20-000154:8k_2_02:52]
Broadcom Inc.

[0001730168-20-000154:8k_2_02:53]
Beatrice F. Russotto

[0001730168-20-000154:8k_2_02:54]
Investor Relations

[0001730168-20-000154:8k_2_02:55]
408-433-8000

[0001730168-20-000154:8k_2_02:56]
investor.relations@broadcom.com

[0001730168-20-000154:8k_2_02:57]
6

[0001730168-20-000154:8k_2_02:58]
BROADCOM INC.

[0001730168-20-000154:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-20-000154:8k_2_02:60]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-20-000154:8k_2_02:61]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | May 3,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
| Net revenue |  | $ | 5,821 |  |  | $ | 5,742 |  |  | $ | 5,515 |  |  | $ | 17,421 |  |  | $ | 16,821 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,537 |  |  | 1,592 |  |  | 1,651 |  |  | 4,765 |  |  | 4,935 |  |
| Amortization of acquisition-related intangible assets |  | 953 |  |  | 954 |  |  | 828 |  |  | 2,857 |  |  | 2,487 |  |
| Restructuring charges |  | 15 |  |  | 7 |  |  | 2 |  |  | 30 |  |  | 68 |  |
| Total cost of revenue |  | 2,505 |  |  | 2,553 |  |  | 2,481 |  |  | 7,652 |  |  | 7,490 |  |
| Gross margin |  | 3,316 |  |  | 3,189 |  |  | 3,034 |  |  | 9,769 |  |  | 9,331 |  |
| Research and development |  | 1,228 |  |  | 1,269 |  |  | 1,235 |  |  | 3,786 |  |  | 3,519 |  |
| Selling, general and administrative |  | 428 |  |  | 501 |  |  | 410 |  |  | 1,530 |  |  | 1,300 |  |
| Amortization of acquisition-related intangible assets |  | 600 |  |  | 599 |  |  | 475 |  |  | 1,802 |  |  | 1,424 |  |
| Restructuring, impairment and disposal charges |  | 52 |  |  | 54 |  |  | 49 |  |  | 163 |  |  | 698 |  |
| Total operating expenses |  | 2,308 |  |  | 2,423 |  |  | 2,169 |  |  | 7,281 |  |  | 6,941 |  |
| Operating income |  | 1,008 |  |  | 766 |  |  | 865 |  |  | 2,488 |  |  | 2,390 |  |
| Interest expense |  | (464) |  |  | (487) |  |  | (362) |  |  | (1,357) |  |  | (1,083) |  |
| Other income, net |  | 49 |  |  | 130 |  |  | 41 |  |  | 175 |  |  | 172 |  |
| Income from continuing operations before income taxes |  | 593 |  |  | 409 |  |  | 544 |  |  | 1,306 |  |  | 1,479 |  |
| Benefit from income taxes |  | (96) |  |  | (159) |  |  | (171) |  |  | (331) |  |  | (410) |  |
| Income from continuing operations |  | 689 |  |  | 568 |  |  | 715 |  |  | 1,637 |  |  | 1,889 |  |
| Loss from discontinued operations, net of income taxes |  | (1) |  |  | (5) |  |  | — |  |  | (1) |  |  | (12) |  |
| Net income |  | 688 |  |  | 563 |  |  | 715 |  |  | 1,636 |  |  | 1,877 |  |
| Dividends on preferred stock (1) |  | (74) |  |  | (75) |  |  | — |  |  | (223) |  |  | — |  |
| Net income attributable to common stock |  | $ | 614 |  |  | $ | 488 |  |  | $ | 715 |  |  | $ | 1,413 |  |  | $ | 1,877 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.53 |  |  | $ | 1.23 |  |  | $ | 1.80 |  |  | $ | 3.53 |  |  | $ | 4.73 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | (0.03) |  |
| Net income per share |  | $ | 1.52 |  |  | $ | 1.22 |  |  | $ | 1.80 |  |  | $ | 3.52 |  |  | $ | 4.70 |  |
| Diluted income per share attributable to common stock (2): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.46 |  |  | $ | 1.18 |  |  | $ | 1.71 |  |  | $ | 3.37 |  |  | $ | 4.50 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | (0.03) |  |
| Net income per share |  | $ | 1.45 |  |  | $ | 1.17 |  |  | $ | 1.71 |  |  | $ | 3.36 |  |  | $ | 4.47 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 403 |  |  | 401 |  |  | 398 |  |  | 401 |  |  | 399 |  |
| Diluted |  | 422 |  |  | 417 |  |  | 418 |  |  | 420 |  |  | 420 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 37 |  |  | $ | 41 |  |  | $ | 47 |  |  | $ | 121 |  |  | $ | 122 |  |
| Research and development |  | 337 |  |  | 373 |  |  | 456 |  |  | 1,101 |  |  | 1,138 |  |
| Selling, general and administrative |  | 91 |  |  | 103 |  |  | 129 |  |  | 305 |  |  | 381 |  |
| Total stock-based compensation expense |  | $ | 465 |  |  | $ | 517 |  |  | $ | 632 |  |  | $ | 1,527 |  |  | $ | 1,641 |  |
| (1) For the fiscal quarter and three fiscal quarters ended August 2, 2020 and the fiscal quarter ended May 3, 2020, net income attributable to common stock excludes dividends on Mandatory Convertible Preferred Stock issued during the fiscal quarter ended November 3, 2019. |  |  |  |  |  |  |  |  |  |  |
| (2) For the fiscal quarter and three fiscal quarters ended August 2, 2020 and the fiscal quarter ended May 3, 2020, diluted income per share excluded the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |  |  |  |  |  |  |  |  |  |  |

[0001730168-20-000154:8k_2_02:62]
BROADCOM INC.

[0001730168-20-000154:8k_2_02:63]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-20-000154:8k_2_02:64]
(IN MILLIONS)

[0001730168-20-000154:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | May 3,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
| Gross margin on GAAP basis |  | $ | 3,316 |  |  | $ | 3,189 |  |  | $ | 3,034 |  |  | $ | 9,769 |  |  | $ | 9,331 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 953 |  |  | 954 |  |  | 828 |  |  | 2,857 |  |  | 2,487 |  |
| Stock-based compensation expense |  | 37 |  |  | 41 |  |  | 47 |  |  | 121 |  |  | 122 |  |
| Restructuring charges |  | 15 |  |  | 7 |  |  | 2 |  |  | 30 |  |  | 68 |  |
| Acquisition-related costs |  | — |  |  | 5 |  |  | 5 |  |  | 6 |  |  | 12 |  |
| Gross margin on non-GAAP basis |  | $ | 4,321 |  |  | $ | 4,196 |  |  | $ | 3,916 |  |  | $ | 12,794 |  |  | $ | 12,020 |  |
| Research and development on GAAP basis |  | $ | 1,228 |  |  | $ | 1,269 |  |  | $ | 1,235 |  |  | $ | 3,786 |  |  | $ | 3,519 |  |
| Stock-based compensation expense |  | 337 |  |  | 373 |  |  | 456 |  |  | 1,101 |  |  | 1,138 |  |
| Acquisition-related costs |  | 1 |  |  | 5 |  |  | 1 |  |  | 13 |  |  | 4 |  |
| Research and development on non-GAAP basis |  | $ | 890 |  |  | $ | 891 |  |  | $ | 778 |  |  | $ | 2,672 |  |  | $ | 2,377 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 428 |  |  | $ | 501 |  |  | $ | 410 |  |  | $ | 1,530 |  |  | $ | 1,300 |  |
| Stock-based compensation expense |  | 91 |  |  | 103 |  |  | 129 |  |  | 305 |  |  | 381 |  |
| Acquisition-related costs |  | 66 |  |  | 95 |  |  | 53 |  |  | 336 |  |  | 187 |  |
| Litigation settlements |  | 21 |  |  | 29 |  |  | — |  |  | 63 |  |  | — |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 250 |  |  | $ | 274 |  |  | $ | 228 |  |  | $ | 826 |  |  | $ | 732 |  |
| Total operating expenses on GAAP basis |  | $ | 2,308 |  |  | $ | 2,423 |  |  | $ | 2,169 |  |  | $ | 7,281 |  |  | $ | 6,941 |  |
| Amortization of acquisition-related intangible assets |  | 600 |  |  | 599 |  |  | 475 |  |  | 1,802 |  |  | 1,424 |  |
| Stock-based compensation expense |  | 428 |  |  | 476 |  |  | 585 |  |  | 1,406 |  |  | 1,519 |  |
| Restructuring, impairment and disposal charges |  | 52 |  |  | 54 |  |  | 49 |  |  | 163 |  |  | 698 |  |
| Litigation settlements |  | 21 |  |  | 29 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 67 |  |  | 100 |  |  | 54 |  |  | 349 |  |  | 191 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,140 |  |  | $ | 1,165 |  |  | $ | 1,006 |  |  | $ | 3,498 |  |  | $ | 3,109 |  |
| Operating income on GAAP basis |  | $ | 1,008 |  |  | $ | 766 |  |  | $ | 865 |  |  | $ | 2,488 |  |  | $ | 2,390 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,303 |  |  | 4,659 |  |  | 3,911 |  |
| Stock-based compensation expense |  | 465 |  |  | 517 |  |  | 632 |  |  | 1,527 |  |  | 1,641 |  |
| Restructuring, impairment and disposal charges |  | 67 |  |  | 61 |  |  | 51 |  |  | 193 |  |  | 766 |  |
| Litigation settlements |  | 21 |  |  | 29 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 67 |  |  | 105 |  |  | 59 |  |  | 355 |  |  | 203 |  |
| Operating income on non-GAAP basis |  | $ | 3,181 |  |  | $ | 3,031 |  |  | $ | 2,910 |  |  | $ | 9,296 |  |  | $ | 8,911 |  |
| Interest expense on GAAP basis |  | $ | (464) |  |  | $ | (487) |  |  | $ | (362) |  |  | $ | (1,357) |  |  | $ | (1,083) |  |
| Loss on debt extinguishment |  | 55 |  |  | 93 |  |  | 2 |  |  | 153 |  |  | 28 |  |
| Interest expense on non-GAAP basis |  | $ | (409) |  |  | $ | (394) |  |  | $ | (360) |  |  | $ | (1,204) |  |  | $ | (1,055) |  |
| Other income, net on GAAP basis |  | $ | 49 |  |  | $ | 130 |  |  | $ | 41 |  |  | $ | 175 |  |  | $ | 172 |  |
| Gain from lapse of indemnification |  | — |  |  | (116) |  |  | — |  |  | (116) |  |  | — |  |
| Gains on investments |  | (31) |  |  | (8) |  |  | (28) |  |  | (21) |  |  | (95) |  |
| Gain from sale of business |  | (23) |  |  | — |  |  | — |  |  | (23) |  |  | — |  |
| Acquisition-related gain |  | — |  |  | (3) |  |  | — |  |  | (7) |  |  | — |  |
| Other income (loss), net on non-GAAP basis |  | $ | (5) |  |  | $ | 3 |  |  | $ | 13 |  |  | $ | 8 |  |  | $ | 77 |  |

[0001730168-20-000154:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | May 3,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 593 |  |  | $ | 409 |  |  | $ | 544 |  |  | $ | 1,306 |  |  | $ | 1,479 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,303 |  |  | 4,659 |  |  | 3,911 |  |
| Stock-based compensation expense |  | 465 |  |  | 517 |  |  | 632 |  |  | 1,527 |  |  | 1,641 |  |
| Restructuring, impairment and disposal charges |  | 67 |  |  | 61 |  |  | 51 |  |  | 193 |  |  | 766 |  |
| Litigation settlements |  | 21 |  |  | 29 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 67 |  |  | 102 |  |  | 59 |  |  | 348 |  |  | 203 |  |
| Loss on debt extinguishment |  | 55 |  |  | 93 |  |  | 2 |  |  | 153 |  |  | 28 |  |
| Gain from lapse of indemnification |  | — |  |  | (116) |  |  | — |  |  | (116) |  |  | — |  |
| Gains on investments |  | (31) |  |  | (8) |  |  | (28) |  |  | (21) |  |  | (95) |  |
| Gain from sale of business |  | (23) |  |  | — |  |  | — |  |  | (23) |  |  | — |  |
| Income before income taxes on non-GAAP basis |  | $ | 2,767 |  |  | $ | 2,640 |  |  | $ | 2,563 |  |  | $ | 8,100 |  |  | $ | 7,933 |  |
| Benefit from income taxes on GAAP basis |  | $ | (96) |  |  | $ | (159) |  |  | $ | (171) |  |  | $ | (331) |  |  | $ | (410) |  |
| Non-GAAP tax reconciling adjustments |  | 428 |  |  | 476 |  |  | 453 |  |  | 1,303 |  |  | 1,282 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 332 |  |  | $ | 317 |  |  | $ | 282 |  |  | $ | 972 |  |  | $ | 872 |  |
| Net income on GAAP basis |  | $ | 688 |  |  | $ | 563 |  |  | $ | 715 |  |  | $ | 1,636 |  |  | $ | 1,877 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,303 |  |  | 4,659 |  |  | 3,911 |  |
| Stock-based compensation expense |  | 465 |  |  | 517 |  |  | 632 |  |  | 1,527 |  |  | 1,641 |  |
| Restructuring, impairment and disposal charges |  | 67 |  |  | 61 |  |  | 51 |  |  | 193 |  |  | 766 |  |
| Litigation settlements |  | 21 |  |  | 29 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 67 |  |  | 102 |  |  | 59 |  |  | 348 |  |  | 203 |  |
| Loss on debt extinguishment |  | 55 |  |  | 93 |  |  | 2 |  |  | 153 |  |  | 28 |  |
| Gain from lapse of indemnification |  | — |  |  | (116) |  |  | — |  |  | (116) |  |  | — |  |
| Gains on investments |  | (31) |  |  | (8) |  |  | (28) |  |  | (21) |  |  | (95) |  |
| Gain from sale of business |  | (23) |  |  | — |  |  | — |  |  | (23) |  |  | — |  |
| Non-GAAP tax reconciling adjustments |  | (428) |  |  | (476) |  |  | (453) |  |  | (1,303) |  |  | (1,282) |  |
| Discontinued operations, net of income taxes |  | 1 |  |  | 5 |  |  | — |  |  | 1 |  |  | 12 |  |
| Net income on non-GAAP basis |  | $ | 2,435 |  |  | $ | 2,323 |  |  | $ | 2,281 |  |  | $ | 7,128 |  |  | $ | 7,061 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 422 |  |  | 417 |  |  | 418 |  |  | 420 |  |  | 420 |  |
| Non-GAAP adjustment (1) |  | 29 |  |  | 35 |  |  | 24 |  |  | 32 |  |  | 24 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 451 |  |  | 452 |  |  | 442 |  |  | 452 |  |  | 444 |  |
| Net income on non-GAAP basis |  | $ | 2,435 |  |  | $ | 2,323 |  |  | $ | 2,281 |  |  | $ | 7,128 |  |  | $ | 7,061 |  |
| Interest expense on non-GAAP basis |  | 409 |  |  | 394 |  |  | 360 |  |  | 1,204 |  |  | 1,055 |  |
| Provision for income taxes on non-GAAP basis |  | 332 |  |  | 317 |  |  | 282 |  |  | 972 |  |  | 872 |  |
| Depreciation |  | 138 |  |  | 147 |  |  | 141 |  |  | 431 |  | 426 |
| Amortization of purchased intangibles and right-of-use assets |  | 28 |  | 28 |  | — |  |  | 81 |  | — |  |
| Adjusted EBITDA |  | $ | 3,342 |  |  | $ | 3,209 |  |  | $ | 3,064 |  |  | $ | 9,816 |  |  | $ | 9,414 |  |
| Net cash provided by operating activities |  | $ | 3,178 |  |  | $ | 3,213 |  |  | $ | 2,419 |  |  | $ | 8,713 |  |  | $ | 7,218 |  |
| Purchases of property, plant and equipment |  | (105) |  |  | (148) |  |  | (112) |  |  | (361) |  |  | (336) |  |
| Free cash flow |  | $ | 3,073 |  |  | $ | 3,065 |  |  | $ | 2,307 |  |  | $ | 8,352 |  |  | $ | 6,882 |  |

[0001730168-20-000154:8k_2_02:67]
|  |  | Fiscal Quarter Ending |
|  |  | November 1, |
| Expected average diluted share count: |  | 2020 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 424 |  |
| Non-GAAP adjustment (1) |  | 27 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 451 |  |

[0001730168-20-000154:8k_2_02:68]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter and three fiscal quarters ended August 2, 2020 and the fiscal quarter ended May 3, 2020, the non-GAAP adjustment included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. For the fiscal quarter ending November 1, 2020, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |  |  |  |  |  |  |  |  |  |  |

[0001730168-20-000154:8k_2_02:69]
BROADCOM INC.

[0001730168-20-000154:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-20-000154:8k_2_02:71]
(IN MILLIONS)

[0001730168-20-000154:8k_2_02:72]
|  |  | August 2,2020 |  | November 3,2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,857 |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  | 2,684 |  |  | 3,259 |  |
| Inventory |  | 1,081 |  |  | 874 |  |
| Other current assets |  | 1,059 |  |  | 729 |  |
| Total current assets |  | 13,681 |  |  | 9,917 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,567 |  |  | 2,565 |  |
| Goodwill |  | 43,447 |  |  | 36,714 |  |
| Intangible assets, net |  | 18,357 |  |  | 17,554 |  |
| Other long-term assets |  | 1,246 |  |  | 743 |  |
| Total assets |  | $ | 79,298 |  |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,092 |  |  | $ | 855 |  |
| Employee compensation and benefits |  | 732 |  |  | 641 |  |
| Current portion of long-term debt |  | 822 |  |  | 2,787 |  |
| Other current liabilities |  | 4,056 |  |  | 2,616 |  |
| Total current liabilities |  | 6,702 |  |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 43,201 |  |  | 30,011 |  |
| Other long-term liabilities |  | 5,810 |  |  | 5,613 |  |
| Total liabilities |  | 55,713 |  |  | 42,523 |  |
| Preferred stock dividend obligation |  | 28 |  |  | 29 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 23,688 |  |  | 25,081 |  |
| Retained earnings |  | — |  |  | — |  |
| Accumulated other comprehensive loss |  | (131) |  |  | (140) |  |
| Total stockholders' equity |  | 23,557 |  |  | 24,941 |  |
| Total liabilities and equity |  | $ | 79,298 |  |  | $ | 67,493 |  |

[0001730168-20-000154:8k_2_02:73]
| BROADCOM INC. |  |  |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |  |  |  |  |  |  |  |  |  |
| (IN MILLIONS) |  |  |  |  |  |  |  |  |  |  |
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |
|  |  | August 2,2020 |  | May 3,2020 |  | August 4,2019 |  | August 2,2020 |  | August 4,2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 688 |  |  | $ | 563 |  |  | $ | 715 |  |  | $ | 1,636 |  |  | $ | 1,877 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,581 |  |  | 1,583 |  |  | 1,309 |  |  | 4,746 |  |  | 3,930 |  |
| Depreciation |  | 138 |  |  | 147 |  |  | 141 |  |  | 431 |  |  | 426 |  |
| Stock-based compensation |  | 465 |  |  | 517 |  |  | 632 |  |  | 1,527 |  |  | 1,641 |  |
| Deferred taxes and other non-cash taxes |  | (436) |  |  | (175) |  |  | (235) |  |  | (683) |  |  | (708) |  |
| Loss on debt extinguishment |  | 55 |  |  | 93 |  |  | 2 |  |  | 153 |  |  | 2 |  |
| Non-cash restructuring, impairment and disposal charges |  | 15 |  |  | 6 |  |  | 15 |  |  | 32 |  |  | 113 |  |
| Non-cash interest expense |  | 22 |  |  | 31 |  |  | 23 |  |  | 83 |  |  | 50 |  |
| Other |  | (54) |  |  | (8) |  |  | (23) |  |  | (43) |  |  | (83) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 542 |  |  | 440 |  |  | (60) |  |  | 590 |  |  | 201 |  |
| Inventory |  | (128) |  |  | (10) |  |  | (57) |  |  | (98) |  |  | 33 |  |
| Accounts payable |  | (123) |  |  | 233 |  |  | 244 |  |  | 227 |  |  | 105 |  |
| Employee compensation and benefits |  | 231 |  |  | 61 |  |  | 104 |  |  | 75 |  |  | (360) |  |
| Other current assets and current liabilities |  | (2) |  |  | 118 |  |  | (354) |  |  | 462 |  |  | 115 |  |
| Other long-term assets and long-term liabilities |  | 184 |  |  | (386) |  |  | (37) |  |  | (425) |  |  | (124) |  |
| Net cash provided by operating activities |  | 3,178 |  |  | 3,213 |  |  | 2,419 |  |  | 8,713 |  |  | 7,218 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (2) |  |  | — |  |  | (6) |  |  | (10,872) |  |  | (16,033) |  |
| Proceeds from sales of businesses |  | 50 |  |  | 168 |  |  | — |  |  | 218 |  |  | 957 |  |
| Purchases of property, plant and equipment |  | (105) |  |  | (148) |  |  | (112) |  |  | (361) |  |  | (336) |  |
| Proceeds from disposals of property, plant and equipment |  | 10 |  |  | — |  |  | 82 |  |  | 10 |  |  | 82 |  |
| Other |  | 1 |  |  | 4 |  |  | 1 |  |  | (4) |  |  | (4) |  |
| Net cash provided by (used in) investing activities |  | (46) |  |  | 24 |  |  | (35) |  |  | (11,009) |  |  | (15,334) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 7,953 |  |  | 4,468 |  |  | — |  |  | 27,802 |  |  | 28,793 |  |
| Repayment of debt |  | (6,825) |  |  | (4,452) |  |  | — |  |  | (15,814) |  |  | (12,000) |  |
| Other borrowings, net |  | (3,028) |  |  | 1,025 |  |  | (230) |  |  | (1,285) |  |  | 1,345 |  |
| Payment of dividends |  | (1,386) |  |  | (1,381) |  |  | (1,057) |  |  | (4,139) |  |  | (3,181) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | (736) |  |  | — |  |  | (5,002) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (192) |  |  | (219) |  |  | (241) |  |  | (580) |  |  | (818) |  |
| Issuance of common stock |  | 46 |  |  | 91 |  |  | 11 |  |  | 174 |  |  | 194 |  |
| Other |  | (50) |  |  | (6) |  |  | 3 |  |  | (60) |  |  | (45) |  |
| Net cash provided by (used in) financing activities |  | (3,482) |  |  | (474) |  |  | (2,250) |  |  | 6,098 |  |  | 9,286 |  |
| Net change in cash and cash equivalents |  | (350) |  |  | 2,763 |  |  | 134 |  |  | 3,802 |  |  | 1,170 |  |
| Cash and cash equivalents at the beginning of period |  | 9,207 |  |  | 6,444 |  |  | 5,328 |  |  | 5,055 |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 8,857 |  |  | $ | 9,207 |  |  | $ | 5,462 |  |  | $ | 8,857 |  |  | $ | 5,462 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 269 |  |  | $ | 375 |  |  | $ | 368 |  |  | $ | 1,025 |  |  | $ | 980 |  |
| Cash paid for income taxes |  | $ | 44 |  |  | $ | 124 |  |  | $ | 98 |  |  | $ | 299 |  |  | $ | 618 |  |
