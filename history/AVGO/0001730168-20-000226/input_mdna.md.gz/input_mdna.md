# AVGO MD&A — 0001730168-20-000226


## mdna

[0001730168-20-000226:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-20-000226:mdna:2]
Overview

[0001730168-20-000226:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-20-000226:mdna:4]
During the first quarter of our fiscal year ended November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. In addition, during the fourth quarter of our fiscal year 2020, we refined our allocation methodology for certain selling, general and administrative expenses to more closely align these costs with the segment benefiting from the shared expenses. Prior period segment results have been recast to conform to the current presentation.

[0001730168-20-000226:mdna:5]
Our strategy is to combine best-of-breed technology leadership in semiconductor and infrastructure software solutions, with unmatched scale, on a common sales and administrative platform to deliver a comprehensive suite of infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through responsibly financed acquisitions of category-leading businesses and technologies, as well as investing extensively in research and development, to ensure our products retain their technology leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-20-000226:mdna:6]
The demand for our products has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-20-000226:mdna:7]
•gain or loss of significant customers;

[0001730168-20-000226:mdna:8]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-20-000226:mdna:9]
•our distributors’ product inventory and end customer demand;

[0001730168-20-000226:mdna:10]
•the rate at which our present and future customers and end-users adopt our products and technologies in our target markets, and the rate at which our customers' products that include our technology are accepted in their markets;

[0001730168-20-000226:mdna:11]
•the shift to cloud-based IT solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our products for use in traditional enterprise data centers; and

[0001730168-20-000226:mdna:12]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-20-000226:mdna:13]
Our fiscal year 2020 and our fiscal year ended November 3, 2019 (“fiscal year 2019”) were 52-week fiscal years compared to our fiscal year ended November 4, 2018 (“fiscal year 2018”), which was a 53-week fiscal year.

[0001730168-20-000226:mdna:14]
COVID-19 Update

[0001730168-20-000226:mdna:15]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in most of our employees working remotely for an extended periods of time. While we have implemented a phased-in return of employees to many of our facilities, if the spread of COVID-19 worsens significantly, we may need to further limit onsite operations or otherwise modify our business practices. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-20-000226:mdna:16]
The demand environment for our semiconductor products was consistent with our expectations for our fourth quarter of fiscal year 2020, with continued demand for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this area, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, we continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. As a result, supply lead times are still extended and we continue to have difficulties in obtaining some necessary components and inputs in a timely manner. However, the disruptions in our outsourced assembly and test capacity that we experienced previously, as a result of COVID-19 related shutdowns, have now largely resolved.

[0001730168-20-000226:mdna:17]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty. For example, we are largely building semiconductor products to order, instead of based on customer forecasts. In addition, during the fourth fiscal quarter, we continued to strengthen our balance sheet, including closely managing working capital and reducing our total debt outstanding.

[0001730168-20-000226:mdna:18]
Overall, in light of the changing nature and continuing uncertainty around the COVID-19 pandemic, our ability to predict the impact of COVID-19 on our business in future periods remains limited. The effects of the pandemic on our business are unlikely to be fully realized, or reflected in our financial results, until future periods.

[0001730168-20-000226:mdna:19]
Fiscal Year Highlights

[0001730168-20-000226:mdna:20]
Highlights during fiscal year 2020 include the following:

[0001730168-20-000226:mdna:21]
•We acquired the Symantec Corporation Enterprise Security business (the “Symantec Business”).

[0001730168-20-000226:mdna:22]
•We generated $12,061 million of cash from operations.

[0001730168-20-000226:mdna:23]
•We paid $5,534 million in cash dividends.

[0001730168-20-000226:mdna:24]
Acquisitions and Divestitures

[0001730168-20-000226:mdna:25]
The discussion and analysis in this section and the accompanying consolidated financial statements include the results of operations of acquired companies commencing on their respective acquisition dates.

[0001730168-20-000226:mdna:26]
Acquisition of Symantec Corporation’s Enterprise Security Business

[0001730168-20-000226:mdna:27]
On November 4, 2019, we completed the purchase and assumption of certain assets and certain liabilities, respectively, of the Symantec Business for $10.7 billion in cash (the “Symantec Asset Purchase”). We financed this acquisition with the net proceeds from the borrowings under the November 2019 Term Loans, as defined in Note 10. “Borrowings” included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-20-000226:mdna:28]
Acquisition of CA, Inc.

[0001730168-20-000226:mdna:29]
On November 5, 2018, we acquired CA, Inc. (“CA”) for $18.8 billion in aggregate cash purchase consideration and assumed $2.25 billion of outstanding unsecured bonds (the “CA Merger”). We financed the CA Merger with $18 billion of term loans, as well as cash on hand of the combined companies. We also assumed all eligible unvested CA equity awards in the transaction. On December 31, 2018, we sold Veracode, Inc. (“Veracode”), a subsidiary of CA and provider of application security testing solutions, to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments.

[0001730168-20-000226:mdna:30]
Acquisition of Brocade Communications Systems, Inc.

[0001730168-20-000226:mdna:31]
On November 17, 2017, we acquired Brocade Communications Systems, Inc. (“Brocade”) for $6.0 billion in cash, including retirement of their term loan debt, which we financed using the net proceeds from the issuance of our senior unsecured notes, issued in October 2017, as well as cash on hand. We also assumed all eligible unvested Brocade equity awards in the transaction. On December 1, 2017, we sold certain Brocade business for an aggregate of $800 million in cash.

[0001730168-20-000226:mdna:32]
Net Revenue

[0001730168-20-000226:mdna:33]
A majority of our net revenue is derived from sales of a broad range of semiconductor devices that are incorporated into electronic products, as well as from modules, switches and subsystems. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, automate, manage, and secure applications across mainframe, distributed, mobile, and cloud platforms.

[0001730168-20-000226:mdna:34]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, has varied from quarter to quarter, due largely to fluctuations in end-market demand, including the effects of seasonality, which are discussed in detail in Part I, Item 1. Business under “Seasonality” of this Annual Report on Form 10-K.

[0001730168-20-000226:mdna:35]
Original equipment manufacturers (“OEMs”), or their contract manufacturers, and distributors typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We also sell our products to a wide variety of OEMs or their contract manufacturers. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive intellectual property (“IP”) portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon delivery of product to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-20-000226:mdna:36]
Our traditional software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-20-000226:mdna:37]
Costs and Expenses

[0001730168-20-000226:mdna:38]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense; related occupancy; computer services; equipment costs; manufacturing quality; order fulfillment; warranty adjustments; inventory adjustments, including write-downs for inventory obsolescence; and acquisition costs, which include direct transaction costs and acquisition-related costs.

[0001730168-20-000226:mdna:39]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-20-000226:mdna:40]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-20-000226:mdna:41]
Total cost of revenue also includes the purchase accounting effect on inventory, amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-20-000226:mdna:42]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-20-000226:mdna:43]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs and other corporate expenses.

[0001730168-20-000226:mdna:44]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are being amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with the acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-20-000226:mdna:45]
Restructuring, impairment and disposal charges. Restructuring, impairment and disposal charges consist primarily of compensation costs associated with employee exit programs, alignment of our global manufacturing operations, rationalizing product development program costs, facility and lease abandonments, fixed asset impairment, IPR&D impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-20-000226:mdna:46]
38

[0001730168-20-000226:mdna:47]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-20-000226:mdna:48]
Other income, net.  Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement, and other miscellaneous items.

[0001730168-20-000226:mdna:49]
Provision for (benefit from) income taxes.  We have structured our operations to maximize the benefit from tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax. Subject to our compliance with the conditions specified in these incentives and legislative developments, these Singapore tax incentives are presently expected to expire in November 2025. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028.

[0001730168-20-000226:mdna:50]
Each tax incentive and tax holiday is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act (“2017 Tax Reform Act”) and other indirect tax impacts, the effect of these tax incentives and tax holiday was to increase the benefit from income taxes by approximately $833 million, $923 million and $590 million for fiscal years 2020, 2019 and 2018, respectively.

[0001730168-20-000226:mdna:51]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect or if these tax incentives are substantially modified or rescinded we could suffer material adverse tax and other financial consequences, which would increase our expenses, reduce our profitability and adversely affect our cash flows. In addition, taxable income in any jurisdiction is dependent upon acceptance of our operational practices and intercompany transfer pricing by local tax authorities as being on an arm’s length basis. Due to inconsistencies in application of the arm’s length standard among taxing authorities, as well as lack of adequate treaty-based protection, transfer pricing challenges by tax authorities could, if successful, substantially increase our income tax expense.

[0001730168-20-000226:mdna:52]
The 2017 Tax Reform Act made significant changes to the U.S. Internal Revenue Code, including (1) a decrease in the U.S. corporate tax rate from 35% to 21% effective for tax years beginning after December 31, 2017, (2) the accrual of U.S. income tax on foreign earnings when earned, allowing certain foreign dividends to then be tax-exempt, rather than deferring such income tax payments until the foreign earnings are repatriated into the U.S., and (3) the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations (the “Transition Tax”). Following the enactment of the 2017 Tax Reform Act, the Securities and Exchange Commission (“SEC”), issued guidance for situations when there is insufficient information to complete the accounting for certain income tax effects of the 2017 Tax Reform Act. Based on our interpretation of the 2017 Tax Reform Act and the SEC’s guidance, we recognized an income tax benefit of $7,278 million during fiscal year 2018. During fiscal year 2019 we recorded an income tax provision of $113 million from a change in estimate of our fiscal year 2018 benefit as a result of proposed U.S. Treasury regulations issued in fiscal year 2019 related to the 2017 Tax Reform Act. We also recognized an income tax benefit of $1,162 million in fiscal year 2018 primarily as a result of our redomiciliation to the United States in April 2018.

[0001730168-20-000226:mdna:53]
Critical Accounting Estimates

[0001730168-20-000226:mdna:54]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of long-lived assets, intangible assets and goodwill, inventory valuation, income taxes, retirement and post-retirement benefit plan assumptions, stock-based compensation and employee bonus programs. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-20-000226:mdna:55]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the

[0001730168-20-000226:mdna:56]
contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-20-000226:mdna:57]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-20-000226:mdna:58]
Our contracts may contain more than one of our products and services, each of which is separately accounted for as a distinct performance obligation. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-20-000226:mdna:59]
We also estimate the standalone selling price of our material rights. Our estimate of the value of the customer’s option to purchase or receive additional products or services at a discounted price includes estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-20-000226:mdna:60]
Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-20-000226:mdna:61]
Business combinations.  Accounting for business combinations requires management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain of the intangible assets we have acquired include, but are not limited to, future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp-up period, technology obsolescence rates, expected costs to develop IPR&D into commercially viable products, estimated cash flows from the projects when completed, and discount rates. The discount rates used to discount expected future cash flows to present value are typically derived from a weighted-average cost of capital analysis and adjusted to reflect inherent risks. Unanticipated events and circumstances may occur that could affect either the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-20-000226:mdna:62]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-20-000226:mdna:63]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The

[0001730168-20-000226:mdna:64]
40

[0001730168-20-000226:mdna:65]
income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting financial multiples of comparable companies and applies a control premium. A reporting unit's carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-20-000226:mdna:66]
We assess the impairment of long-lived assets including purchased IPR&D, property, plant and equipment, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment and other intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business that the long-lived asset relates to. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived asset stated on our consolidated balance sheets to reflect its estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-20-000226:mdna:67]
Inventory valuation.  We regularly review inventory quantities on hand and record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. Demand for our products can fluctuate significantly from period to period. A significant decrease in demand could result in an increase in the amount of excess inventory quantities on hand. In addition, our industry is characterized by rapid technological change, frequent new product development and rapid product obsolescence that could result in an increase in the amount of obsolete inventory quantities on hand. Additionally, our estimates of future product demand may prove to be inaccurate, which may cause us to understate or overstate both the provision required for excess and obsolete inventory and cost of products sold. Therefore, although we make every effort to ensure the accuracy of our forecasts of future product demand, any significant unanticipated changes in demand or technological developments could have a significant impact on the value of our inventory and our results of operations.

[0001730168-20-000226:mdna:68]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. If we determine that a valuation allowance is required, such adjustment to the deferred tax assets would increase our tax expense in the period in which such determination is made. Conversely, if we determine that a valuation allowance exceeds our requirement, such adjustment to the deferred tax assets would decrease tax expense in the period in which such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more likely than not threshold for recognition.

[0001730168-20-000226:mdna:69]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax law and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-20-000226:mdna:70]
41

[0001730168-20-000226:mdna:71]
Retirement and post-retirement benefit plan assumptions.  Retirement and post-retirement benefit plan costs represent obligations that will ultimately be settled sometime in the future and therefore, are subject to estimation. Pension accounting is intended to reflect the recognition of future retirement and post-retirement benefit plan costs over the employees' average expected future service to us, based on the terms of the plans and investment and funding decisions. To estimate the impact of these future payments and our decisions concerning funding of these obligations, we are required to make assumptions using actuarial concepts within the framework of GAAP. One assumption is the discount rate used to calculate the estimated costs. Other assumptions include the expected long-term return on plan assets, expected future salary increases, the health care cost trend rate, expected future increases to benefit payments, expected retirement dates, employee turnover, retiree mortality rates, and portfolio composition. We evaluate these assumptions at least annually.

[0001730168-20-000226:mdna:72]
For our U.S. and non-U.S. plans, we use October 31, the month end closest to our fiscal year end, as the annual discount rate measurement date to determine the present value of future benefit payments. The U.S. discount rates are based on the results of matching expected plan benefit payments with cash flows from a hypothetical yield curve constructed with high-quality corporate bond yields. The discount rate for non-U.S. plans was based either on published rates for government bonds or use of a hypothetical yield curve constructed with high-quality corporate bond yields, depending on the availability of sufficient quantities of quality corporate bonds. Lower discount rates increase present values of the pension liabilities and subsequent year pension expense; higher discount rates decrease present values of the pension liabilities and subsequent year pension expense.

[0001730168-20-000226:mdna:73]
The U. S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy.

[0001730168-20-000226:mdna:74]
Actuarial assumptions are based on our best estimates and judgment. Material changes may occur in retirement benefit costs in the future if these assumptions differ from actual events or experiences. We performed a sensitivity analysis on the discount rate, which is the key assumption in calculating the U.S. pension and post-retirement benefit obligations. Each change of 25 basis points in the discount rate assumption would have had an estimated $40 million impact on the benefit obligations as of the fiscal year 2020 measurement date. Each change of 25 basis points in the discount rate assumption or expected rate of return assumption would not have a material impact on annual net retirement benefit costs for the fiscal year ending October 31, 2021 (“fiscal year 2021”).

[0001730168-20-000226:mdna:75]
Stock-based compensation expense.  Stock-based compensation expense consists of expense for restricted stock units (“RSUs”) and stock options granted to employees and non-employees or assumed from acquisitions as well as expense associated with Broadcom employee stock purchase plan (“ESPP”). We recognize compensation expense for time-based stock options and ESPP rights based on the estimated grant-date fair value method required under the authoritative guidance using the Black-Scholes valuation model.

[0001730168-20-000226:mdna:76]
Certain equity awards include both time-based and market-based conditions and are accounted for as market-based awards. The fair value of these market-based awards is estimated on the date of grant using a Monte Carlo simulation model.

[0001730168-20-000226:mdna:77]
Employee Bonus Programs.  Our employee bonus programs, which are overseen by our Compensation Committee, or our Board, in the case of our Chief Executive Officer, provide for variable compensation based on the attainment of overall corporate annual targets and functional performance metrics. In the first fiscal quarter of the year, if management determines that it is probable that the targets and metrics will be achieved and the amounts can be reasonably estimated, a variable, proportional compensation accrual is recognized based on an assumed 100% achievement of the targets and metrics. The bonus payout levels can be greater if attainment of metrics and targets is greater than 100% and a portion of the payouts may not occur if a minimum floor of performance is not achieved. In subsequent quarters, we monitor and accrue for variable compensation expense based on our actual progress toward the achievement of the annual targets and metrics. The actual achievement of target metrics at the end of the fiscal year, which is subject to approval by our Compensation Committee, may result in the actual variable compensation amounts being significantly higher or lower than the relevant estimated amounts accrued in earlier quarters, which would result in a corresponding adjustment in the fourth fiscal quarter.

[0001730168-20-000226:mdna:78]
Fiscal Year Presentation

[0001730168-20-000226:mdna:79]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal years 2020 and 2019 consisted of 52 weeks. Fiscal year 2018 consisted of 53 weeks.

[0001730168-20-000226:mdna:80]
The financial statements included in Part II, Item 8. of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-20-000226:mdna:81]
Results of Operations

[0001730168-20-000226:mdna:82]
Fiscal Year 2020 Compared to Fiscal Year 2019

[0001730168-20-000226:mdna:83]
The following table sets forth our results of operations for the periods presented:

[0001730168-20-000226:mdna:84]
|  |  | Fiscal Year Ended |
|  |  | November 1,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 17,435 |  |  | $ | 18,117 |  |  | 73 | % |  | 80 | % |
| Subscriptions and services |  | 6,453 |  |  | 4,480 |  |  | 27 |  |  | 20 |  |
| Total net revenue |  | 23,888 |  |  | 22,597 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 5,892 |  |  | 6,208 |  |  | 25 |  |  | 28 |  |
| Cost of subscriptions and services |  | 626 |  |  | 515 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 3,819 |  |  | 3,314 |  |  | 16 |  |  | 15 |  |
| Restructuring charges |  | 35 |  |  | 77 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 10,372 |  |  | 10,114 |  |  | 43 |  |  | 45 |  |
| Gross margin |  | 13,516 |  |  | 12,483 |  |  | 57 |  |  | 55 |  |
| Research and development |  | 4,968 |  |  | 4,696 |  |  | 21 |  |  | 21 |  |
| Selling, general and administrative |  | 1,935 |  |  | 1,709 |  |  | 8 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 2,401 |  |  | 1,898 |  |  | 10 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 198 |  |  | 736 |  |  | 1 |  |  | 3 |  |
| Total operating expenses |  | 9,502 |  |  | 9,039 |  |  | 40 |  |  | 40 |  |
| Operating income |  | $ | 4,014 |  |  | $ | 3,444 |  |  | 17 | % |  | 15 | % |

[0001730168-20-000226:mdna:85]
Net Revenue

[0001730168-20-000226:mdna:86]
Historically, a relatively small number of customers has accounted for a significant portion of our net revenue. Sales of products to distributors accounted for 42% and 46% of our net revenue for fiscal years 2020 and 2019, respectively. Direct sales to WT Microelectronics, a distributor, accounted for 13% and 17% of our net revenue for fiscal years 2020 and 2019, respectively. We believe our aggregate sales to our top five end customers through all channels accounted for more than 30% of our net revenue for each of our fiscal years 2020 and 2019. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 15% and 20% of our net revenue for fiscal years 2020 and 2019, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-20-000226:mdna:87]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile handsets. In addition, the ongoing COVID-19 pandemic and related challenges and uncertainties may also cause our net revenue to fluctuate significantly and adversely affect our results of operations, as discussed above. Additionally, if export restrictions on one of our larger customers continue, revenue in future periods may continue to be adversely impacted.

[0001730168-20-000226:mdna:88]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based on the geographic shipment or delivery location specified by distributors, OEMs, contract manufacturers, channel partners, or software customers. In each of fiscal years 2020 and 2019, approximately 35% of our net revenue came from shipments or deliveries to China (including Hong Kong), compared to approximately 50% for fiscal year 2018. However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-20-000226:mdna:89]
43

[0001730168-20-000226:mdna:90]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-20-000226:mdna:91]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | November 1,2020 |  | November 3,2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 17,267 |  |  | $ | 17,441 |  |  | $ | (174) |  |  | (1) | % |
| Infrastructure software |  | 6,621 |  |  | 5,156 |  |  | 1,465 |  |  | 28 | % |
| Total net revenue |  | $ | 23,888 |  |  | $ | 22,597 |  |  | $ | 1,291 |  |  | 6 | % |

[0001730168-20-000226:mdna:92]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | November 1, 2020 |  | November 3, 2019 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 72 | % |  | 77 | % |
| Infrastructure software |  | 28 |  |  | 23 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-20-000226:mdna:93]
Our total net revenue increased primarily due to contributions from the Symantec enterprise security solutions in fiscal year 2020 compared to the prior fiscal year. Net revenue from our semiconductor solutions segment decreased primarily due to delays in the production ramp of a new mobile handset by a major customer that resulted in lower than expected shipments in the year, partially offset by higher demand for our networking and storage products. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions.

[0001730168-20-000226:mdna:94]
Gross Margin

[0001730168-20-000226:mdna:95]
Gross margin was $13,516 million, or 57% of net revenue, for fiscal year 2020, compared to $12,483 million, or 55% of our net revenue, for fiscal year 2019. The increase was primarily due to contributions from our Symantec enterprise security solutions, as well as favorable product mix within our semiconductor solutions segment, compared to the corresponding prior fiscal year.

[0001730168-20-000226:mdna:96]
Research and Development Expense

[0001730168-20-000226:mdna:97]
Research and development expense increased $272 million, or 6%, in fiscal year 2020, compared to the prior fiscal year. The increase was primarily due to our acquisition of the Symantec Business, partially offset by a decrease in stock-based compensation expense resulting from restructuring actions.

[0001730168-20-000226:mdna:98]
Selling, General and Administrative Expense

[0001730168-20-000226:mdna:99]
Selling, general and administrative expense increased $226 million, or 13%, in fiscal year 2020, compared to the prior fiscal year. The increase was primarily due to our acquisition of the Symantec Business and associated acquisition-related costs, partially offset by a decrease in compensation expense, including stock-based compensation, resulting from restructuring actions.

[0001730168-20-000226:mdna:100]
Amortization of Acquisition-Related Intangible Assets

[0001730168-20-000226:mdna:101]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $503 million, or 27%, in fiscal year 2020, compared to the prior fiscal year. The increase was primarily due to the addition of amortization of intangible assets as a result of our acquisition of the Symantec Business.

[0001730168-20-000226:mdna:102]
Restructuring, Impairment and Disposal Charges

[0001730168-20-000226:mdna:103]
Restructuring, impairment and disposal charges included in operating expenses decreased $538 million, or 73%, in fiscal year 2020, compared to the prior fiscal year. The decrease was primarily due to higher employee termination costs, as well as lease and other exit costs resulting from the CA Merger, in the prior fiscal year.

[0001730168-20-000226:mdna:104]
Segment Operating Results

[0001730168-20-000226:mdna:105]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income (Loss) |  | November 1, 2020 |  | November 3, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 8,576 |  |  | $ | 8,538 |  |  | $ | 38 |  |  | — | % |
| Infrastructure software |  | 4,363 |  |  | 3,391 |  |  | 972 |  |  | 29 | % |
| Unallocated expenses |  | (8,925) |  |  | (8,485) |  |  | (440) |  |  | 5 | % |
| Total operating income |  | $ | 4,014 |  |  | $ | 3,444 |  |  | $ | 570 |  |  | 17 | % |

[0001730168-20-000226:mdna:106]
Operating income from our semiconductor solutions segment increased slightly, primarily due to higher demand for storage products, largely offset by delays in the production ramp of a new mobile handset by a major customer, which resulted in lower than expected shipments in the year. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions.

[0001730168-20-000226:mdna:107]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 5% in fiscal year 2020, compared to the prior year fiscal period, primarily due to higher amortization of acquisition-related intangible assets and acquisition-related costs, partially offset by lower restructuring, impairment and disposal charges and stock-based compensation expense.

[0001730168-20-000226:mdna:108]
Non-Operating Income and Expenses

[0001730168-20-000226:mdna:109]
Interest expense.  Interest expense was $1,777 million and $1,444 million for fiscal years 2020 and 2019, respectively. The increase was primarily due to the increase in debt associated with the financing of our acquisition of the Symantec Business, as well as losses on extinguishment of debt related to refinancing activities during fiscal year 2020.

[0001730168-20-000226:mdna:110]
Other income, net.  Other income, net, which includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items, was $206 million and $226 million for fiscal years 2020 and 2019, respectively. The decrease was primarily due to lower gains on investments, partially offset by a $116 million one-time gain from the lapse of a tax indemnification arrangement.

[0001730168-20-000226:mdna:111]
Benefit from income taxes.  Benefit from income taxes was $518 million and $510 million for fiscal years 2020 and 2019, respectively. The benefit from income taxes in fiscal year 2020 was primarily due to the jurisdictional mix of income and expense, the recognition of gross uncertain tax benefits as a result of lapses of statues of limitations, the remeasurement of certain foreign deferred tax assets and liabilities, and excess benefit from stock-based awards. The benefit from income taxes in fiscal year 2019 was primarily due to excess tax benefits from stock-based awards, the recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, deferred tax remeasurement in state and foreign jurisdictions, internal reorganizations, and the partial release of our valuation allowance as a result of the CA Merger. This was partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the 2017 Tax Reform Act.

[0001730168-20-000226:mdna:112]
45

[0001730168-20-000226:mdna:113]
Fiscal Year 2019 Compared to Fiscal Year 2018

[0001730168-20-000226:mdna:114]
The following table sets forth our results of operations for the periods presented:

[0001730168-20-000226:mdna:115]
|  |  | Fiscal Year Ended |
| Statements of Operations Data: |  | November 3, 2019 |  | November 4, 2018 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 18,117 |  |  | $ | 19,754 |  |  | 80 | % |  | 95 | % |
| Subscriptions and services |  | 4,480 |  |  | 1,094 |  |  | 20 |  |  | 5 |  |
| Total net revenue |  | 22,597 |  |  | 20,848 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 6,208 |  |  | 6,924 |  |  | 28 |  |  | 33 |  |
| Cost of subscriptions and services |  | 515 |  |  | 97 |  |  | 2 |  |  | 1 |  |
| Purchase accounting effect on inventory |  | — |  |  | 70 |  |  | — |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 3,314 |  |  | 3,004 |  |  | 15 |  |  | 14 |  |
| Restructuring charges |  | 77 |  |  | 20 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 10,114 |  |  | 10,115 |  |  | 45 |  |  | 48 |  |
| Gross margin |  | 12,483 |  |  | 10,733 |  |  | 55 |  |  | 52 |  |
| Research and development |  | 4,696 |  |  | 3,768 |  |  | 21 |  |  | 18 |  |
| Selling, general and administrative |  | 1,709 |  |  | 1,056 |  |  | 8 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,898 |  |  | 541 |  |  | 8 |  |  | 3 |  |
| Restructuring, impairment and disposal charges |  | 736 |  |  | 219 |  |  | 3 |  |  | 1 |  |
| Litigation settlements |  | — |  |  | 14 |  |  | — |  |  | — |  |
| Total operating expenses |  | 9,039 |  |  | 5,598 |  |  | 40 |  |  | 27 |  |
| Operating income |  | $ | 3,444 |  |  | $ | 5,135 |  |  | 15 | % |  | 25 | % |

[0001730168-20-000226:mdna:116]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-20-000226:mdna:117]
Net Revenue

[0001730168-20-000226:mdna:118]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | November 3, 2019 |  | November 4, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 17,441 |  |  | $ | 19,068 |  |  | $ | (1,627) |  |  | (9) | % |
| Infrastructure software |  | 5,156 |  |  | 1,780 |  |  | 3,376 |  |  | 190 | % |
| Total net revenue |  | $ | 22,597 |  |  | $ | 20,848 |  |  | $ | 1,749 |  |  | 8 | % |

[0001730168-20-000226:mdna:119]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 77 | % |  | 92 | % |
| Infrastructure software |  | 23 |  |  | 8 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-20-000226:mdna:120]
Our total net revenue increased primarily due to the CA Merger in fiscal year 2019. Net revenue from our semiconductor solutions segment decreased due to lower demand for our wireless content in mobile handsets, as well as lower demand for our broadband, optocoupler, set-top box and server storage connectivity products. Fiscal year 2018 semiconductor solutions revenue benefited from a later than typical new mobile handset ramp with a major customer in the first quarter, which resulted in higher shipments in that quarter, as well as an extra week in the fiscal year as compared to fiscal year 2019. Net

[0001730168-20-000226:mdna:121]
46

[0001730168-20-000226:mdna:122]
revenue from our infrastructure software segment increased primarily due to contributions from our mainframe and enterprise software solutions.

[0001730168-20-000226:mdna:123]
Gross Margin

[0001730168-20-000226:mdna:124]
Gross margin was $12,483 million, or 55% of net revenue, for fiscal year 2019 compared to $10,733 million, or 52% of net revenue, for fiscal year 2018. The increase in gross margin was primarily due to contributions from our mainframe and enterprise software solutions and favorable product mix within our semiconductor solutions segment, compared to the prior fiscal year, partially offset by higher amortization of acquisition-related intangible assets and restructuring charges as a result of the CA Merger and higher stock-based compensation expense.

[0001730168-20-000226:mdna:125]
Research and Development Expense

[0001730168-20-000226:mdna:126]
Research and development expense increased $928 million, or 25%, in fiscal year 2019, compared to the prior fiscal year. Research and development expense as a percentage of net revenue was 21% and 18% for fiscal years 2019 and 2018, respectively. The increase was primarily due to the CA Merger and higher stock-based compensation expense, offset by lower variable employee compensation expense. Stock-based compensation expense increased primarily due to the issuance of the multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in the first quarter of fiscal year 2019, the impact of the change from annual to quarterly vesting of equity awards and the assumed CA equity awards. Our stock-based compensation expense for fiscal year 2019 included employee equity awards granted at higher grant-date fair values than those granted in prior years, which also contributed to the increase.

[0001730168-20-000226:mdna:127]
Selling, General and Administrative Expense

[0001730168-20-000226:mdna:128]
Selling, general and administrative expense increased $653 million, or 62%, in fiscal year 2019, compared to the prior fiscal year. Selling, general and administrative expense as a percentage of net revenue was 8% and 5% for fiscal years 2019 and 2018, respectively. The increase was primarily due to the CA Merger and higher stock-based compensation expense. Stock-based compensation expense increased primarily due to the issuance of the Multi-Year Equity Awards, the impact of the change from annual to quarterly vesting of equity awards and the assumed CA equity awards.

[0001730168-20-000226:mdna:129]
Amortization of Acquisition-Related Intangible Assets

[0001730168-20-000226:mdna:130]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $1,357 million, or 251%, in fiscal year 2019, compared to the prior fiscal year. The increase was primarily due to the addition of amortization of intangible assets acquired in the CA Merger.

[0001730168-20-000226:mdna:131]
Restructuring, Impairment and Disposal Charges

[0001730168-20-000226:mdna:132]
Restructuring, impairment and disposal charges included in operating expenses increased $517 million, or 236%, in fiscal year 2019, compared to the prior fiscal year. The increase was primarily due to employee termination costs, as well as lease and other exit costs resulting from the CA Merger.

[0001730168-20-000226:mdna:133]
Segment Operating Results

[0001730168-20-000226:mdna:134]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | November 3, 2019 |  | November 4, 2018 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 8,538 |  |  | $ | 9,253 |  |  | $ | (715) |  |  | (8) | % |
| Infrastructure software |  | 3,391 |  |  | 1,157 |  |  | 2,234 |  |  | 193 | % |
| Unallocated expenses |  | (8,485) |  |  | (5,275) |  |  | (3,210) |  |  | 61 | % |
| Total operating income |  | $ | 3,444 |  |  | $ | 5,135 |  |  | $ | (1,691) |  |  | (33) | % |

[0001730168-20-000226:mdna:135]
Operating income from our semiconductor solutions segment decreased primarily due to lower demand for our wireless content in mobile handsets, as well as lower demand for our optocoupler, broadband, server storage connectivity and set-top box products. Fiscal year 2018 semiconductor solutions operating income benefited from a later than typical new mobile handset ramp with a major customer in the first quarter, which resulted in higher shipments in that quarter, as well as an extra week in the fiscal year as compared to fiscal year 2019. Operating income from our infrastructure software segment increased primarily due to contributions from our mainframe and enterprise software solutions.

[0001730168-20-000226:mdna:136]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 61% in fiscal year 2019, compared to the prior fiscal year, primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense, and restructuring, impairment and disposal charges primarily related to the CA Merger.

[0001730168-20-000226:mdna:137]
Non-Operating Income and Expenses

[0001730168-20-000226:mdna:138]
Interest expense.  Interest expense was $1,444 million and $628 million for fiscal years 2019 and 2018, respectively. Interest expense was higher in fiscal year 2019 primarily due to interest on the debt we incurred to finance the CA Merger in the first quarter of fiscal year 2019.

[0001730168-20-000226:mdna:139]
Other income, net.  Other income, net was $226 million and $144 million in fiscal years 2019 and 2018, respectively. The increase was primarily due to an increase in unrealized gains on investments partially offset by losses on foreign currency remeasurement.

[0001730168-20-000226:mdna:140]
Benefit from income taxes.  Benefit from income taxes was $510 million and $8,084 million for fiscal years 2019 and 2018, respectively. The benefit from income taxes in fiscal year 2019 was primarily due to excess benefit from stock-based awards, the recognition of gross unrecognized tax benefits as a result of audit settlements and lapses of statutes of limitations net of increases in balances related to tax positions taken during the current year, benefit from deferred tax measurement in state and foreign jurisdictions, benefit related to internal reorganizations, and benefit from the partial release of our valuation allowance as a result of the CA Merger, partially offset from a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the 2017 Tax Reform Act. The benefit from income taxes in fiscal year 2018 was primarily due to income tax benefits recognized from the enactment of the 2017 Tax Reform Act and as a result of our redomiciliation to the United States on April 4, 2018.

[0001730168-20-000226:mdna:141]
Liquidity and Capital Resources

[0001730168-20-000226:mdna:142]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-20-000226:mdna:143]
Our primary sources of liquidity as of November 1, 2020 consisted of: (i) $7,618 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-20-000226:mdna:144]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-20-000226:mdna:145]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. We expect a slight increase in capital expenditures in fiscal year 2021 as compared to fiscal year 2020.

[0001730168-20-000226:mdna:146]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, outstanding term loans and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-20-000226:mdna:147]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0001730168-20-000226:mdna:148]
48

[0001730168-20-000226:mdna:149]
Working Capital

[0001730168-20-000226:mdna:150]
Working capital increased to $5,524 million at November 1, 2020 from $3,018 million at November 3, 2019. The increase was attributable to the following:

[0001730168-20-000226:mdna:151]
•Cash and cash equivalents increased to $7,618 million at November 1, 2020 from $5,055 million at November 3, 2019, primarily due to $27,802 million in proceeds from long-term borrowings, $12,061 million in net cash provided by operating activities, and $218 million in proceeds from the sales of businesses, partially offset by $20,099 million of debt repayments, $10,700 million paid for the Symantec Asset Purchase, $5,534 million of dividend payments and $765 million in payments of employee withholding taxes related to net share settled equity awards. See the “Cash Flows” section below for further details.

[0001730168-20-000226:mdna:152]
•Current portion of long-term debt decreased $1,960 million primarily due to repayment of certain debt, partially offset by additional amounts coming due within twelve months.

[0001730168-20-000226:mdna:153]
•Other current assets increased to $977 million at November 1, 2020 from $729 million at November 3, 2019, primarily due to increases in prepaid taxes and short-term investments.

[0001730168-20-000226:mdna:154]
•Inventory increased to $1,003 million at November 1, 2020 from $874 million at November 3, 2019, primarily due to timing of customer product ramps.

[0001730168-20-000226:mdna:155]
These increases in working capital were offset in part by the following:

[0001730168-20-000226:mdna:156]
•Other current liabilities increased to $3,831 million at November 1, 2020 from $2,616 million at November 3, 2019, primarily due to increases in contract liabilities, interest payable, taxes payable, and lease liabilities resulting from the adoption of Accounting Standard Codification Topic 842 (“Topic 842”), partially offset by repayments of notional pooling liabilities.

[0001730168-20-000226:mdna:157]
•Accounts receivable decreased to $2,297 million at November 1, 2020 from $3,259 million at November 3, 2019, primarily due to revenue linearity and additional receivables sold through factoring arrangements.

[0001730168-20-000226:mdna:158]
•Employee compensation and benefits increased to $877 million at November 1, 2020 from $641 million at November 3, 2019, primarily due to the employee bonus plan.

[0001730168-20-000226:mdna:159]
Working capital decreased to $3,018 million at November 3, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-20-000226:mdna:160]
•Accounts receivable decreased to $3,259 million at November 3, 2019 from $3,325 million at November 4, 2018, primarily due to a higher volume of trade accounts receivable factoring, partially offset by higher revenue.

[0001730168-20-000226:mdna:161]
•Inventory decreased to $874 million at November 3, 2019 from $1,124 million at November 4, 2018, primarily due to our continued focus on inventory management.

[0001730168-20-000226:mdna:162]
•Current portion of long-term debt increased $2,787 million primarily due to certain unsecured senior notes becoming due within the next twelve months.

[0001730168-20-000226:mdna:163]
•Other current liabilities increased to $2,616 million at November 3, 2019 from $812 million at November 4, 2018, primarily due to the CA Merger and increases in contract liabilities from the adoption of Topic 606, notional pooling liabilities, restructuring reserves, taxes payable and interest payable.

[0001730168-20-000226:mdna:164]
These decreases in working capital were offset in part by the following:

[0001730168-20-000226:mdna:165]
•Cash and cash equivalents increased to $5,055 million at November 3, 2019 from $4,292 million at November 4, 2018 primarily due to $30,034 million in proceeds from long-term borrowings, $9,697 million in net cash provided by operating activities, $3,679 million of Mandatory Convertible Preferred Stock issuance proceeds and $957 million in proceeds from sale of Veracode, partially offset by $16,800 million of debt repayments, $16,027 million paid for the CA Merger, $5,435 million of common stock repurchases, $4,235 million of dividend payments, and $972 million in payments of employee withholding taxes related to net share settled equity awards. See the “Cash Flows” section below for further details.

[0001730168-20-000226:mdna:166]
•Other current assets increased to $729 million at November 3, 2019 from $366 million at November 4, 2018, primarily due to assets acquired in the CA Merger and increases in contract assets from adoption of Topic 606 and prepaid taxes.

[0001730168-20-000226:mdna:167]
Capital Returns

[0001730168-20-000226:mdna:168]
|  |  | Fiscal Year Ended |
| Cash Dividends and Distributions Declared and Paid |  | November 1, 2020 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions, except per share/unit data) |
| Dividends per share to common stockholders |  | $ | 13.00 |  |  | $ | 10.60 |  |  | $ | 7.00 |  |
| Dividends to common stockholders |  | $ | 5,235 |  |  | $ | 4,235 |  |  | $ | 2,921 |  |
| Dividends per share to preferred stockholders |  | $ | 80.00 |  |  | $ | — |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 299 |  |  | $ | — |  |  | $ | — |  |
| Distributions per unit to limited partners |  | $ | — |  |  | $ | — |  |  | $ | 3.50 |  |
| Distributions to limited partners |  | $ | — |  |  | $ | — |  |  | $ | 77 |  |
| Stock repurchases |  | $ | — |  |  | $ | 5,435 |  |  | $ | 7,258 |  |

[0001730168-20-000226:mdna:169]
During fiscal years 2020, 2019 and 2018, we paid approximately $765 million, $972 million and $56 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 3 million, 4 million and 0.2 million shares of common stock from employees in connection with such net share settlements in fiscal years 2020, 2019 and 2018, respectively.

[0001730168-20-000226:mdna:170]
Pursuant to an $18 billion stock repurchase program previously authorized by our Board of Directors, we repurchased and retired approximately 21 million and 32 million shares of our common stock at a weighted average price of $258.52 and $227.60 during fiscal years 2019 and 2018, respectively. This authorization ended on November 3, 2019.

[0001730168-20-000226:mdna:171]
Cash Flows

[0001730168-20-000226:mdna:172]
|  |  | Fiscal Year Ended |
|  |  | November 1, 2020 |  | November 3, 2019 |  | November 4, 2018 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 12,061 |  |  | $ | 9,697 |  |  | $ | 8,880 |  |
| Net cash used in investing activities |  | (11,109) |  |  | (15,422) |  |  | (4,674) |  |
| Net cash provided by (used in) financing activities |  | 1,611 |  |  | 6,488 |  |  | (11,118) |  |
| Net change in cash and cash equivalents |  | $ | 2,563 |  |  | $ | 763 |  |  | $ | (6,912) |  |

[0001730168-20-000226:mdna:173]
Operating Activities

[0001730168-20-000226:mdna:174]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $2,364 million increase in cash provided by operations during fiscal year 2020 compared to fiscal year 2019 was due to higher cash flows from net income adjusted for non-cash items and changes in the operating assets and liabilities.

[0001730168-20-000226:mdna:175]
The $817 million increase in cash provided by operations during fiscal year 2019 compared to fiscal year 2018 was primarily due to changes in operating assets and liabilities. Cash flows from net income adjusted for non-cash items were relatively flat as higher net income in fiscal year 2018 reflected a significant non-cash income tax benefit, principally resulting from the enactment of the 2017 Tax Reform Act and the impact from our redomiciliation to the United States in fiscal year 2018.

[0001730168-20-000226:mdna:176]
Investing Activities

[0001730168-20-000226:mdna:177]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures and investments, and proceeds from sales of businesses and assets. The $4,313 million decrease in cash used in investing activities for fiscal year 2020 compared to fiscal year 2019 was primarily related to a $5,161 million decrease in cash paid for acquisitions, partially offset by $739 million less in proceeds received from sales of businesses.

[0001730168-20-000226:mdna:178]
The $10,748 million increase in cash used in investing activities for fiscal year 2019 compared to fiscal year 2018 was primarily related to $16,027 million paid for the CA Merger in fiscal year 2019, partially offset by proceeds from sales of businesses as well as lower capital expenditures.

[0001730168-20-000226:mdna:179]
Financing Activities

[0001730168-20-000226:mdna:180]
Cash flows from financing activities primarily consisted of net proceeds and payments related to our long-term borrowings, dividend and distribution payments, stock repurchases and the issuances of stock. The $4,877 million decrease in cash provided by financing activities for fiscal year 2020 compared to fiscal year 2019 was primarily due to a $5,531 million decrease in net proceeds from borrowings as a result of debt repayments, the absence of preferred stock issuance which generated $3,679 million net proceeds in fiscal year 2019 and a $1,299 million increase in dividend payments, partially offset by the absence of repurchases of common stock under our repurchase program, which ended in fiscal year 2019, as compared to $5,435 million of repurchases in fiscal year 2019.

[0001730168-20-000226:mdna:181]
The $17,606 million increase in cash related to financing activities for fiscal year 2019 compared to fiscal year 2018 was primarily due to a $14,207 million increase in net proceeds from borrowings, net proceeds of $3,679 million from issuance of preferred stock and a $1,823 million decrease in common stock repurchases under our repurchase program, partially offset by a $1,237 million increase in dividend and distribution payments and a $916 million increase in employee withholding tax payments related to net settled equity awards.

[0001730168-20-000226:mdna:182]
Indebtedness

[0001730168-20-000226:mdna:183]
See Note 10. “Borrowings” included in Part II, Item 8. of this Annual Report on Form 10-K.

[0001730168-20-000226:mdna:184]
Summarized Obligor Group Financial Information

[0001730168-20-000226:mdna:185]
Pursuant to the indentures dated May 21, 2020, May 8, 2020, April 9, 2020, and April 5, 2019 (collectively, the “2020 and 2019 Indentures”), Broadcom issued $3,917 million, $8,000 million, $4,500 million, and $11,000 million aggregate principal amount of notes, respectively (collectively, the “2020 and 2019 Senior Notes”). Substantially all of the 2020 and 2019 Senior Notes have been registered with the SEC in connection with an exchange offer that completed on August 10, 2020.

[0001730168-20-000226:mdna:186]
We may redeem all or a portion of our 2020 and 2019 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the indentures governing the respective notes. In the event of a change of control triggering event, holders of our 2020 and 2019 Senior Notes will have the right to require us to purchase for cash, all or a portion of their respective notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2020 and 2019 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of the Obligor Group, as defined below, to merge, consolidate or sell all or substantially all of their assets.

[0001730168-20-000226:mdna:187]
Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”), 100%-owned subsidiaries of Broadcom (Broadcom, BRCM and BTI collectively, the “Obligor Group”), fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2020 and 2019 Senior Notes. The guarantee by BRCM and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the respective indentures. The guarantee by BRCM and BTI will also be automatically and unconditionally released if at any time the aggregate principal amount of indebtedness issued, borrowed or guaranteed by BRCM and BTI constitutes no more than 20% of the aggregate principal amount of indebtedness for borrowed money of Broadcom and its subsidiaries on a consolidated basis.

[0001730168-20-000226:mdna:188]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), Broadcom Cayman Finance Limited (subsequently merged into BTI during fiscal year 2019 with BTI remaining as the surviving entity) and BRCM (BRCM and BTI collectively, the “2017 Senior Notes Co-Issuers”) issued $13,550 million and $4,000 million aggregate principal amount of notes, respectively (collectively, the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-20-000226:mdna:189]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom and the 2017 Senior Notes Co-Issuers to merge, consolidate or sell all or substantially all of their assets.

[0001730168-20-000226:mdna:190]
Broadcom and BTI fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2017 Senior Notes. Because the guarantees are not secured, they are effectively subordinated to any existing and future secured indebtedness of the guarantors to the extent of the value of the collateral securing that indebtedness. The guarantee by Broadcom and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the 2017 Indentures. The guarantee by Broadcom (1) will also be automatically and unconditionally released at such time as: (A) the 2017 Senior

[0001730168-20-000226:mdna:191]
Notes Co-Issuers, in their sole discretion, determine that such guarantee is no longer required by Rule 3-10(a), as applicable, of Regulation S-X to except the 2017 Senior Notes Co-Issuers’ financial statements from being required to be filed pursuant to Rule 3-10(a) of Regulation S-X or otherwise facilitate a reduction in its financial reporting obligations or (B) either of the 2017 Senior Notes Co-Issuers becomes subject to Section 13 or 15(d) of the Exchange Act and (2) may, at the election of the 2017 Senior Notes Co-Issuers, be unconditionally released at such time as Broadcom is eligible to suspend its reporting obligation under the Exchange Act.

[0001730168-20-000226:mdna:192]
The following tables set forth the summarized financial information of the Obligor Group on a combined basis. This summarized financial information excludes any subsidiaries that are not issuers or guarantors (the “Non-Obligor Group”). Intercompany balances and transactions between members of the Obligor Group have been eliminated.

[0001730168-20-000226:mdna:193]
| Summarized Balance Sheets |  | November 1,2020 |  |  |
|  |  | (In millions) |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 1,889 |  |  |  |
| Other current assets |  | 4,091 |  |  |  |
| Total current assets |  | $ | 5,980 |  |  |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 8,220 |  |  |  |
| Goodwill |  | 1,360 |  |  |  |
| Other long-term assets |  | 1,318 |  |  |  |
| Total long-term assets |  | $ | 10,898 |  |  |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 7,147 |  |  |  |
| Current portion of long-term debt |  | 807 |  |  |  |
| Other current liabilities |  | 601 |  |  |  |
| Total current liabilities |  | $ | 8,555 |  |  |  |
| Long-term liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group, long-term |  | $ | — |  |  |  |
| Long-term debt |  | 39,311 |  |  |  |
| Other long-term liabilities |  | 2,477 |  |  |  |
| Total long-term liabilities |  | $ | 41,788 |  |  |  |

[0001730168-20-000226:mdna:194]
|  |  | Fiscal Year Ended |
| Summarized Statement of Operations |  | November 1,2020 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 1,683 |  |
| Gross margin |  | $ | 1,524 |  |
| Loss from continuing operations (a) |  | $ | (1,985) |  |
| Net loss |  | $ | (1,985) |  |

[0001730168-20-000226:mdna:195]
_________________________________

[0001730168-20-000226:mdna:196]
(a) Included $706 million of net income from the Non-Obligor Group related to intercompany transactions.

[0001730168-20-000226:mdna:197]
52

[0001730168-20-000226:mdna:198]
Contractual Commitments

[0001730168-20-000226:mdna:199]
|  |  |  |  | Payments Due by Period |
|  |  | Total |  | Less than 1 year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 51,307 |  |  | $ | 2,286 |  |  | $ | 7,708 |  |  | $ | 13,122 |  |  | $ | 28,191 |  |
| Purchase commitments |  | 966 |  |  | 894 |  |  | 72 |  |  | — |  |  | — |  |
| Other contractual commitments |  | 1,137 |  |  | 248 |  |  | 430 |  |  | 220 |  |  | 239 |  |
| Operating lease and finance lease obligations |  | 845 |  |  | 141 |  |  | 212 |  |  | 136 |  |  | 356 |  |
| Total |  | $ | 54,255 |  |  | $ | 3,569 |  |  | $ | 8,422 |  |  | $ | 13,478 |  |  | $ | 28,786 |  |

[0001730168-20-000226:mdna:200]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal year ended November 1, 2020.

[0001730168-20-000226:mdna:201]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-20-000226:mdna:202]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

[0001730168-20-000226:mdna:203]
Operating Lease and Finance Lease Obligations. Represents real property and equipment leased from third parties under non-cancelable leasing arrangements.

[0001730168-20-000226:mdna:204]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 1, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authority. Therefore, $3,185 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our consolidated balance sheet as of November 1, 2020 have been excluded from the contractual obligations table above.

[0001730168-20-000226:mdna:205]
Off-Balance Sheet Arrangements

[0001730168-20-000226:mdna:206]
We had no material off-balance sheet arrangements at November 1, 2020 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-20-000226:mdna:207]
Indemnifications

[0001730168-20-000226:mdna:208]
See Note 14. “Commitments and Contingencies” in Part II, Item 8 of this Form 10-K.

[0001730168-20-000226:mdna:209]
Accounting Changes and Recent Accounting Standards

[0001730168-20-000226:mdna:210]
For a description of accounting changes and recent accounting standards, including the expected dates of adoption and estimated effects, if any, in our consolidated financial statements, see Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K.
