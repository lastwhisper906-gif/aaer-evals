# AVGO notes — 0001730168-20-000226


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001730168-20-000226:notes:1]
Information required in response to Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the registrant’s definitive Proxy Statement for its 2021 Annual Meeting of Stockholders. Except as expressly incorporated by reference, the registrant’s Proxy Statement shall not be deemed to be a part of this Annual Report on Form 10-K. The registrant intends to file its definitive Proxy Statement within 120 days after its fiscal year ended November 1, 2020


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-20-000226:notes:2]
Overview and Basis of Presentation 
Overview

[0001730168-20-000226:notes:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is the successor to Broadcom Limited (now Broadcom Pte. Ltd.), a Singapore company (“Broadcom-Singapore”). On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged for newly issued shares of Broadcom common stock (the “Redomiciliation Transaction”). As a result, Broadcom-Singapore became a wholly-owned subsidiary of Broadcom. In addition, all outstanding exchangeable limited partnership units (“LP Units”) of Broadcom Cayman L.P. (the “Partnership”) were mandatorily exchanged (the “Mandatory Exchange”) for newly issued shares of Broadcom common stock and all limited partners of the Partnership became common stockholders of Broadcom. Also, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange. The limited partners no longer hold a noncontrolling interest and we deregistered the Partnership.

[0001730168-20-000226:notes:4]
The Redomiciliation Transaction was accounted for as an exchange of equity interests among entities under common control and the historical basis of accounting was retained as if the entities had always been combined for financial reporting purposes.

[0001730168-20-000226:notes:5]
The financial statements relate to Broadcom-Singapore for periods prior to April 4, 2018, the effective date of the Redomiciliation Transaction, and relate to Broadcom for periods after April 4, 2018. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our” and “us” mean Broadcom and its consolidated subsidiaries from and after the effective time of the Redomiciliation Transaction and, prior to that time, to our predecessor, Broadcom-Singapore.

[0001730168-20-000226:notes:6]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. We offer a cyber security solutions portfolio, including endpoint, network, information and identity security solutions. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-20-000226:notes:7]
Basis of Presentation

[0001730168-20-000226:notes:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ended on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was a 52-week fiscal year. Our fiscal year ended November 4, 2018 (“fiscal year 2018”) was a 53-week fiscal year, with the first fiscal quarter containing 14 weeks.

[0001730168-20-000226:notes:9]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”). On November 5, 2018, we acquired CA, Inc. (“CA”). On November 17, 2017, we acquired Brocade Communications Systems, Inc. (“Brocade”). The accompanying consolidated financial statements include the results of operations of Symantec Business, CA and Brocade commencing as of their respective acquisition dates. See Note 4. “Acquisitions” for additional information.

[0001730168-20-000226:notes:10]
Certain reclassifications have been made to the consolidated statement of cash flows for fiscal year 2019. These reclassifications have no impact on previously reported operating, investing or financing cash flows. During the first quarter of fiscal year 2020, we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Reclassifications have also been made to segment operating income. Segment results from prior years have been recast to conform to the current presentation. See Note 13. “Segment Information” for additional information. These reclassifications have no impact on previously reported consolidated operating income.

[0001730168-20-000226:notes:11]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted principles in the United States (“GAAP”). All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-20-000226:notes:12]
Summary of Significant Accounting Policies 
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. As such, foreign currency assets and liabilities are remeasured into U.S. dollars at current exchange rates except for non-monetary items such as inventory and property, plant and equipment, which are remeasured at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.

[0001730168-20-000226:notes:13]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

[0001730168-20-000226:notes:14]
Cash and cash equivalents.  We consider all highly liquid investment securities with original or remaining maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.

[0001730168-20-000226:notes:15]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the amount of probable credit losses in our existing accounts receivable. We determine the allowance based on customer-specific experience and the aging of such receivables, among other factors. Allowances for doubtful accounts were not material as of November 1, 2020 or November 3, 2019. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances as of November 1, 2020 and November 3, 2019 were $174 million and $178 million, respectively.

[0001730168-20-000226:notes:16]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with several financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-20-000226:notes:17]
Concentration of other risks.  We operate in markets that are highly competitive and rapidly changing. Significant technological changes, shifting customer needs, the emergence of competitive products with new capabilities, general economic conditions worldwide, the ability to safeguard patents and other intellectual property in a rapidly evolving market and reliance on assembly and test subcontractors, third-party wafer fabricators and independent distributors and other factors could affect our financial results.

[0001730168-20-000226:notes:18]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.

[0001730168-20-000226:notes:19]
Retirement benefits. For defined benefit pension plans, we consider various factors in determining our respective pension liabilities and net periodic benefit costs, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the retirement benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-20-000226:notes:20]
Post-retirement benefit plan assets and liabilities are estimates of benefits that we expect to pay to eligible retirees. We consider various factors in determining the value of our post-retirement benefit plan assets and liabilities, including the number of employees that we expect to receive benefits and other actuarial assumptions.

[0001730168-20-000226:notes:21]
The key benefit plan assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on the results of matching expected plan benefit payments with cash flows from a hypothetical yield curve constructed with high-quality corporate bond yields. The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy. For the non-U.S. plans, we

[0001730168-20-000226:notes:22]
set assumptions specific to each country. We have elected to measure defined benefit pension plan and post-retirement benefit plan assets and liabilities as of October 31, which is the month end that is closest to our fiscal year end.

[0001730168-20-000226:notes:23]
Derivative instruments.  We use derivative financial instruments, primarily foreign exchange forward contracts, to manage exposure to foreign exchange risk. Our forward contracts generally mature within three months. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-20-000226:notes:24]
Outstanding derivatives are recognized as either assets or liabilities at their fair values based on Level 2 inputs as defined in the fair value hierarchy. The accounting for gains and losses resulting from changes in fair value depends on the use of the derivative and its hedging designation. For derivative instruments designated as fair value hedges, the changes in fair value are recognized in other income, net in the periods of change, and are offset by the changes in fair value of the hedged items. For derivative instruments designated as cash flow hedges, the changes in fair value of the effective portion are initially recognized in other comprehensive income (loss), net of tax in the period of change, and are subsequently reclassified and recognized in other income, net when either the hedged transactions affect earnings or it becomes probable that the hedged transactions will not occur. The changes in the fair value of the ineffective portion of the derivative instruments are recognized in other income, net in the period of change, which have not been material to date. For derivative instruments not designated as hedges, the changes in fair value are recognized in other income, net in the period of change. We did not have any outstanding derivative instruments as of November 1, 2020 or November 3, 2019.

[0001730168-20-000226:notes:25]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years, or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over three to ten years. We use the straight-line method of depreciation for all property, plant and equipment.

[0001730168-20-000226:notes:26]
Leases. We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize right-of-use (“ROU”) assets and lease liabilities for operating and finance leases with terms greater than 12 months. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective-interest method over the lease term.

[0001730168-20-000226:notes:27]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-20-000226:notes:28]
The three levels of the fair value hierarchy under the guidance for fair value measurements are described below:

[0001730168-20-000226:notes:29]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date. Our Level 1 assets include cash equivalents, banker's acceptances, trading securities investments and investment funds. We measure trading securities investments and investment funds at quoted market prices as they are traded in active markets with sufficient volume and frequency of transactions.

[0001730168-20-000226:notes:30]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-20-000226:notes:31]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Level 3 assets and liabilities include investment in equity securities without readily determinable fair values, goodwill, intangible assets, and property, plant and equipment, which are measured at fair value using a discounted cash flow approach when they are impaired. Quantitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit

[0001730168-20-000226:notes:32]
rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.

[0001730168-20-000226:notes:33]
Business combinations.  We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition date fair values. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date including our estimates for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets under the income approach include growth in future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp-up period, technology obsolescence rates, expected costs to develop in-process research and development (“IPR&D”) into commercially viable products, estimated cash flows from the projects when completed and discount rates. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-20-000226:notes:34]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-20-000226:notes:35]
Long-lived assets.  Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.

[0001730168-20-000226:notes:36]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the product requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-20-000226:notes:37]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-20-000226:notes:38]
Nature of Products and Services

[0001730168-20-000226:notes:39]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-20-000226:notes:40]
Products.  We recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product.

[0001730168-20-000226:notes:41]
Subscriptions and services.  Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of intellectual property (“IP”), and non-recurring engineering (“NRE”) arrangements.

[0001730168-20-000226:notes:42]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-20-000226:notes:43]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. The majority of our subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in ratable revenue recognition of software revenue over the contractual period.

[0001730168-20-000226:notes:44]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-20-000226:notes:45]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-20-000226:notes:46]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-20-000226:notes:47]
There are two main categories of NRE contracts that we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost (“cost-to-cost”) as the services are provided. For NRE contracts that do not meet the over time criteria, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-20-000226:notes:48]
Material rights. Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-20-000226:notes:49]
Arrangements with Multiple Performance Obligations

[0001730168-20-000226:notes:50]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-20-000226:notes:51]
Allocation of consideration. We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-20-000226:notes:52]
Standalone selling price. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-20-000226:notes:53]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-20-000226:notes:54]
We also estimate the standalone selling price of our material rights. Lastly, we estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-20-000226:notes:55]
Other Policies and Judgments

[0001730168-20-000226:notes:56]
Contract modifications. We may modify contracts to offer customers additional products or services. Each of the additional products and services is generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or a combination of both based on the nature of the modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-20-000226:notes:57]
Right of return. Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-20-000226:notes:58]
Transition practical expedient elected. We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

[0001730168-20-000226:notes:59]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-20-000226:notes:60]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units (“RSUs”) using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for time-based stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”) based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-20-000226:notes:61]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-20-000226:notes:62]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-20-000226:notes:63]
Shipping and handling costs. Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in cost of revenue for all periods presented.

[0001730168-20-000226:notes:64]
Litigation and settlement cost. We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.

[0001730168-20-000226:notes:65]
Taxes on income.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-20-000226:notes:66]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes or increase the benefit from income taxes. Likewise, if we determine that we are not able to realize all or part of our net deferred tax assets, we increase the provision for income taxes or decrease the benefit from income taxes in the period such determination is made.

[0001730168-20-000226:notes:67]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.

[0001730168-20-000226:notes:68]
Net income per share. Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Diluted shares outstanding include the dilutive effect of unvested RSUs, in-the-money stock options, and ESPP rights (together referred to as “equity awards”), as well as convertible preferred stock and LP Units. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-20-000226:notes:69]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of convertible preferred stock and LP Units is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.

[0001730168-20-000226:notes:70]
Recent Accounting Guidance

[0001730168-20-000226:notes:71]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. We elected practical expedients which allowed us to account for the lease and non-lease components as a single component. In addition, we elected not to reassess whether any expired or existing contracts contain leases and the corresponding lease classification and initial direct costs. The practical expedients were applied across our lease portfolios. Upon adoption, we recorded net ROU assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the consolidated statement of operations and the consolidated statement of cash flows. See Note 6. “Leases” for further information.

[0001730168-20-000226:notes:72]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. This guidance had no impact on our contracts, hedging relationships and other transactions as of November 1, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-20-000226:notes:73]
Revenue from Contracts with Customers 
Disaggregation

[0001730168-20-000226:notes:74]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 13. “Segment Information”.

[0001730168-20-000226:notes:75]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

[0001730168-20-000226:notes:76]
|  |  | Fiscal Year Ended November 1, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,775 |  |  | $ | 14,442 |  |  | $ | 1,218 |  |  | $ | 17,435 |  |
| Subscriptions and services(a) |  | 4,059 |  |  | 881 |  |  | 1,513 |  |  | 6,453 |  |
| Total |  | $ | 5,834 |  |  | $ | 15,323 |  |  | $ | 2,731 |  |  | $ | 23,888 |  |

[0001730168-20-000226:notes:77]
|  |  | Fiscal Year Ended November 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,023 |  |  | $ | 14,857 |  |  | $ | 1,237 |  |  | $ | 18,117 |  |
| Subscriptions and services(a) |  | 3,126 |  |  | 374 |  |  | 980 |  |  | 4,480 |  |
| Total |  | $ | 5,149 |  |  | $ | 15,231 |  |  | $ | 2,217 |  |  | $ | 22,597 |  |

[0001730168-20-000226:notes:78]
________________________________

[0001730168-20-000226:notes:79]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

[0001730168-20-000226:notes:80]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by our distributors, original equipment manufacturer (“OEM”) customers, contract manufacturers, channel partners, or software customers.

[0001730168-20-000226:notes:81]
Contract Balances

[0001730168-20-000226:notes:82]
Contract assets and contract liabilities balances were as follows:

[0001730168-20-000226:notes:83]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Opening balance November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Closing balance November 1, 2020 (a) |  | $ | 158 |  |  | $ | 3,443 |  |

[0001730168-20-000226:notes:84]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of November 1, 2020.

[0001730168-20-000226:notes:85]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during fiscal year 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,450 million. The amount of revenue recognized during fiscal year 2019 that was included in the contract liabilities balance as of November 5, 2018, the beginning of our fiscal year 2019, was $200 million.

[0001730168-20-000226:notes:86]
Remaining Performance Obligations

[0001730168-20-000226:notes:87]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of IP.

[0001730168-20-000226:notes:88]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of November 1, 2020 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-20-000226:notes:89]
Acquisitions 
Acquisition of the Symantec Corporation Enterprise Security Business

[0001730168-20-000226:notes:90]
On November 4, 2019 (the “Symantec Acquisition Date”), we completed the purchase of the Symantec Business, which was an established leader in cyber security, for $10.7 billion in cash (the “Symantec Asset Purchase”). We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications. We financed this acquisition with the net proceeds from borrowings under the November 2019 Term Loans, as defined in Note 10. “Borrowings”.

[0001730168-20-000226:notes:91]
The following table presents our allocation of the total purchase price:

[0001730168-20-000226:notes:92]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 273 |  |
| Goodwill |  | 6,638 |  |
| Intangible assets |  | 5,411 |  |
| Other long-term assets |  | 92 |  |
| Total assets acquired |  | 12,414 |  |
| Current liabilities |  | (1,127) |  |
| Other long-term liabilities |  | (587) |  |
| Total liabilities assumed |  | (1,714) |  |
| Fair value of net assets acquired |  | $ | 10,700 |  |

[0001730168-20-000226:notes:93]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Symantec Business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Symantec Asset Purchase. Substantially all goodwill is deductible for tax purposes.

[0001730168-20-000226:notes:94]
Current assets and current liabilities included amounts held-for-sale related to the acquired Symantec Cyber Security Services (“CSS”) business. The CSS business was not aligned with our acquisition-date strategic objectives and was sold on April 30, 2020. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-20-000226:notes:95]
Our results of continuing operations for fiscal year 2020 included $1,610 million of net revenue attributable to the Symantec Business. It was impracticable to determine the effect on net income attributable to the Symantec Business as we had integrated the Symantec Business into our ongoing operations during the year. The results of operations of the Symantec Business were included in our infrastructure software segment. Transaction costs related to the Symantec Asset Purchase of $110 million were included in selling, general and administrative expense for fiscal year 2020.

[0001730168-20-000226:notes:96]
Intangible Assets

[0001730168-20-000226:notes:97]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,900 |  |  | 5 |
| Customer contracts and related relationships |  | 2,410 |  |  | 5 |
| Trade name |  | 90 |  |  | 6 |
| Order backlog |  | 11 |  |  | 3 |
| Total identified finite-lived intangible assets |  | $ | 5,411 |  |  |  |

[0001730168-20-000226:notes:98]
Developed technology relates to products used for cyber security solutions, including data loss prevention, endpoint protection, and web, email and cloud security solutions. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-20-000226:notes:99]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of the Symantec Business. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-20-000226:notes:100]
Trade name relates to the “Symantec” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-20-000226:notes:101]
Order backlog represents business under existing contractual obligations. The fair value of backlog was determined using the multi-period excess earnings method under the income approach based on expected operating cash flows from future contractual revenue. The economic useful life was determined based on the expected life of the backlog and the cash flows over the forecast period.

[0001730168-20-000226:notes:102]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Symantec Acquisition Date.

[0001730168-20-000226:notes:103]
Unaudited Pro Forma Information

[0001730168-20-000226:notes:104]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if we had completed the Symantec Asset Purchase as of the beginning of fiscal year 2019. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the fiscal year 2019, non-recurring pro forma adjustments directly attributable to the Symantec Asset Purchase included transaction costs of $136 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-20-000226:notes:105]
|  |  |  | Fiscal Year |
|  |  |  | 2020 |  | 2019 |
|  |  | (In millions) |
| Pro forma net revenue |  |  | $ | 23,264 |  |  | $ | 24,227 |  |
| Pro forma net income attributable to common stock |  |  | $ | 2,368 |  |  | $ | 1,265 |  |

[0001730168-20-000226:notes:106]
Other Acquisitions

[0001730168-20-000226:notes:107]
During the fiscal year ended November 1, 2020, we also completed three other acquisitions qualifying as business combinations for total consideration of $201 million, of which $109 million was allocated to goodwill and $46 million was allocated to intangible assets.

[0001730168-20-000226:notes:108]
Acquisition of CA, Inc.

[0001730168-20-000226:notes:109]
On November 5, 2018 (the “CA Acquisition Date”), we completed our acquisition of CA (the “CA Merger”), which was a leading provider of information technology (“IT”) management software and solutions. We acquired CA to enhance our infrastructure software capabilities. We financed the CA Merger with the net proceeds from $18 billion of term loans, as well as with cash on hand of the combined companies.

[0001730168-20-000226:notes:110]
Purchase Consideration

[0001730168-20-000226:notes:111]
|  |  | (In millions) |
| Cash paid for outstanding CA common stock |  | $ | 18,402 |  |
| Cash paid by Broadcom to retire CA’s term loan |  | 274 |  |
| Cash paid for vested CA equity awards |  | 101 |  |
| Fair value of partially vested assumed equity awards |  | 67 |  |
| Total purchase consideration |  | 18,844 |  |
| Less: cash acquired |  | (2,750) |  |
| Total purchase consideration, net of cash acquired |  | $ | 16,094 |  |

[0001730168-20-000226:notes:112]
All vested in-the-money CA stock options, after giving effect to any acceleration, and all outstanding deferred stock units were cashed out upon the completion of the CA Merger. We assumed all unvested CA equity awards held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of CA employees represents a component of the total consideration as presented above and was valued based on our share price as of the CA Acquisition Date.

[0001730168-20-000226:notes:113]
The following table presents our allocation of the total purchase price, net of cash acquired:

[0001730168-20-000226:notes:114]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,665 |  |
| Goodwill |  | 9,796 |  |
| Intangible assets |  | 12,045 |  |
| Other long-term assets |  | 240 |  |
| Total assets acquired |  | 23,746 |  |
| Current liabilities |  | (1,966) |  |
| Long-term debt |  | (2,255) |  |
| Other long-term liabilities |  | (3,431) |  |
| Total liabilities assumed |  | (7,652) |  |
| Fair value of net assets acquired |  | $ | 16,094 |  |

[0001730168-20-000226:notes:115]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the CA business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the CA Merger. Goodwill is not deductible for tax purposes.

[0001730168-20-000226:notes:116]
Current assets included assets held-for-sale related to CA’s Veracode business, which was not aligned with our strategic objectives. On December 31, 2018, we sold this business to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments. We do not have any material continuing involvement with this business and have presented its results in discontinued operations. Current assets also included $80 million of real properties held-for-sale. During fiscal year 2019, we sold a portion of these real properties for $62 million and recognized a loss of $8 million.

[0001730168-20-000226:notes:117]
Our results of continuing operations for fiscal year 2019 included $3,377 million of net revenue attributable to CA. It was impracticable to determine the effect on net income attributable to CA as we had integrated a substantial portion of CA into our ongoing operations during the year. The results of operations of CA were included in our infrastructure software segment. Transaction costs related to the CA Merger of $73 million were included in selling, general and administrative expense for fiscal year 2019.

[0001730168-20-000226:notes:118]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 4,957 |  |  | 6 |
| Customer contracts and related relationships |  | 4,190 |  |  | 6 |
| Order backlog |  | 2,569 |  |  | 3 |
| Trade name and other |  | 137 |  |  | 5 |
| Total identified finite-lived intangible assets |  | 11,853 |  |  |  |
| IPR&D |  | 192 |  |  | N/A |
| Total identified intangible assets |  | $ | 12,045 |  |  |  |

[0001730168-20-000226:notes:119]
Developed technology relates to products used for mission critical business tools for processes and applications, as well as products used for cloud-based planning, development, management and security tools. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-20-000226:notes:120]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of CA. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-20-000226:notes:121]
Trade name relates to the “CA” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-20-000226:notes:122]
The fair value of IPR&D was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-20-000226:notes:123]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the CA Acquisition Date.

[0001730168-20-000226:notes:124]
The following table summarizes the details of IPR&D by category as of the CA Acquisition Date:

[0001730168-20-000226:notes:125]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Completion Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Mainframe |  | $ | 178 |  |  | 67 | % |  | $ | 138 |  |  | 2019 |
| Enterprise Solutions |  | $ | 14 |  |  | 63 | % |  | $ | 12 |  |  | 2019 |

[0001730168-20-000226:notes:126]
Discount rates of 12% and 14% were applied to the projected cash flows to reflect the risk related to these mainframe and enterprise solutions IPR&D projects, respectively.

[0001730168-20-000226:notes:127]
During fiscal year 2020, these IPR&D projects were completed and placed in service.

[0001730168-20-000226:notes:128]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if CA had been acquired as of the beginning of fiscal year 2018. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For fiscal year 2018, non-recurring pro forma adjustments directly attributable to the CA Merger included transaction costs of $180 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-20-000226:notes:129]
|  |  | Fiscal Year |
|  |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 21,697 |  |  | $ | 24,451 |  |
| Pro forma net income attributable to common stock |  | $ | 2,535 |  |  | $ | 9,783 |  |

[0001730168-20-000226:notes:130]
* Pro forma net revenue was presented under ASU 2014-09, Revenue from Contracts with Customers, for fiscal year 2019 and under Accounting Standards Codification 605, Revenue Recognition (“Topic 605”), for fiscal year 2018.

[0001730168-20-000226:notes:131]
Acquisition of Brocade

[0001730168-20-000226:notes:132]
On November 17, 2017 (the “Brocade Acquisition Date”), we acquired Brocade (the “Brocade Merger”). Brocade was a supplier of networking hardware, software and services, including FC SAN products and Internet Protocol Networking (“IP Networking”) solutions. We acquired Brocade to enhance our position as a provider of enterprise storage connectivity solutions, broaden our portfolio for enterprise storage, and to increase our ability to address the evolving needs of our OEM customers. We financed the Brocade Merger with a portion of the net proceeds from the issuance of the 2017 Senior Notes, as defined in Note 10. “Borrowings” as well as with cash on hand.

[0001730168-20-000226:notes:133]
|  |  | (In millions) |
| Cash paid for outstanding Brocade common stock |  | $ | 5,298 |  |
| Cash paid by Broadcom to retire Brocade’s term loan |  | 701 |  |
| Cash paid for Brocade equity awards |  | 31 |  |
| Fair value of partially vested assumed equity awards |  | 8 |  |
| Total purchase consideration |  | 6,038 |  |
| Less: cash acquired |  | (1,250) |  |
| Total purchase consideration, net of cash acquired |  | $ | 4,788 |  |

[0001730168-20-000226:notes:134]
We assumed all unvested Brocade stock options, RSUs and performance stock units (“PSUs”) held by continuing employees. The portion of the fair value of partially vested equity awards associated with prior service of Brocade employees represents a component of the total consideration as presented above. All vested in-the-money Brocade stock options, after giving effect to any acceleration, were cashed out upon the completion of the Brocade Merger. RSUs and PSUs were valued based on our share price as of the Brocade Acquisition Date.

[0001730168-20-000226:notes:135]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 1,297 |  |
| Goodwill |  | 2,187 |  |
| Intangible assets |  | 3,396 |  |
| Other long-term assets |  | 82 |  |
| Total assets acquired |  | 6,962 |  |
| Current portion of long-term debt |  | (856) |  |
| Other current liabilities |  | (374) |  |
| Long-term debt |  | (38) |  |
| Other long-term liabilities |  | (906) |  |
| Total liabilities assumed |  | (2,174) |  |
| Fair value of net assets acquired |  | $ | 4,788 |  |

[0001730168-20-000226:notes:136]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Brocade business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved as a result of the Brocade Merger. Goodwill is not deductible for tax purposes.

[0001730168-20-000226:notes:137]
Current assets included assets held-for-sale related to Brocade’s IP Networking business, which was not aligned with our strategic objectives. On December 1, 2017, we sold this business to ARRIS International plc (“ARRIS”) for cash consideration of $800 million, before contractual working capital adjustments. In connection with this sale, we indemnified ARRIS for $116 million of potential income tax liabilities. We provided transitional services as short-term assistance to ARRIS in assuming the operations of the purchased business. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-20-000226:notes:138]
Current assets also included assets held-for-sale for Brocade’s headquarters, which was sold for $224 million during fiscal year 2018, for no gain or loss.

[0001730168-20-000226:notes:139]
Our results of continuing operations for fiscal year 2018 included $1,780 million of net revenue attributable to Brocade. It was impracticable to determine the effect on net income attributable to Brocade as we had integrated a substantial portion of Brocade into our ongoing operations. The results of operations of Brocade were primarily included in our infrastructure software segment. Transaction costs of $29 million related to the Brocade Merger were included in selling, general and administrative expense for fiscal year 2018.

[0001730168-20-000226:notes:140]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,925 |  |  | 10 |
| Customer contracts and related relationships |  | 255 |  |  | 11 |
| Trade name and other |  | 61 |  |  | 6 |
| Total identified finite-lived intangible assets |  | 3,241 |  |  |  |
| IPR&D |  | 155 |  |  | N/A |
| Total identified intangible assets |  | $ | 3,396 |  |  |  |

[0001730168-20-000226:notes:141]
Developed technology relates to products for FC SAN applications. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-20-000226:notes:142]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Brocade. Customer contracts and related relationships were valued using the distributor method and the with-and-without-method under the income approach. The distributor method determines the fair value by measuring the economic profits generated by an intermediary, which in our case represented OEM customers. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. In both instances, the economic useful life was determined based on historical customer turnover rates.

[0001730168-20-000226:notes:143]
Trade name relates to the “Brocade” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-20-000226:notes:144]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Brocade Acquisition Date.

[0001730168-20-000226:notes:145]
The following table summarizes the details of IPR&D by category at the Brocade Acquisition Date:

[0001730168-20-000226:notes:146]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Completion Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| Directors |  | $ | 64 |  |  | 72 | % |  | $ | 45 |  |  | 2019 |
| Switches |  | $ | 50 |  |  | 81 | % |  | $ | 21 |  |  | 2018 |
| Embedded |  | $ | 31 |  |  | 74 | % |  | $ | 22 |  |  | 2019 |
| Networking software |  | $ | 10 |  |  | 73 | % |  | $ | 27 |  |  | 2018 |

[0001730168-20-000226:notes:147]
A discount rate of 11% was applied to the projected cash flows to reflect the risk related to these IPR&D projects. The discount rate represented a premium of 1% over the weighted-average cost of capital to reflect the higher risk and uncertainty of the cash flows for IPR&D relative to the overall businesses.

[0001730168-20-000226:notes:148]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if Brocade had been acquired as of the beginning of fiscal year 2017. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, the purchase accounting effect on inventory acquired, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2017 or of the results of our future operations of the combined business.

[0001730168-20-000226:notes:149]
|  |  | Fiscal Year |
|  |  | 2018 |
|  |  | (In millions) |
| Pro forma net revenue* |  | $ | 20,978 |  |
| Pro forma net income attributable to common stock |  | $ | 12,408 |  |

[0001730168-20-000226:notes:150]
* Pro forma net revenue was presented under Topic 605 for fiscal year 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-20-000226:notes:151]
Supplemental Financial Information 
Cash Equivalents

[0001730168-20-000226:notes:152]
Cash equivalents included $2,471 million and $850 million of time deposits and $790 million and $649 million of money-market funds as of November 1, 2020 and November 3, 2019, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-20-000226:notes:153]
Accounts Receivable Factoring

[0001730168-20-000226:notes:154]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $3,723 million, $1,151 million and $362 million during fiscal years 2020, 2019 and 2018, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any period presented.

[0001730168-20-000226:notes:155]
Inventory

[0001730168-20-000226:notes:156]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Finished goods |  | $ | 323 |  |  | $ | 339 |  |
| Work-in-process |  | 558 |  |  | 414 |  |
| Raw materials |  | 122 |  |  | 121 |  |
| Total inventory |  | $ | 1,003 |  |  | $ | 874 |  |

[0001730168-20-000226:notes:157]
Property, Plant and Equipment, Net

[0001730168-20-000226:notes:158]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Land |  | $ | 194 |  |  | $ | 189 |  |
| Construction in progress |  | 113 |  |  | 85 |  |
| Buildings and leasehold improvements |  | 1,133 |  |  | 1,078 |  |
| Machinery and equipment |  | 3,891 |  |  | 3,544 |  |
| Total property, plant and equipment |  | 5,331 |  |  | 4,896 |  |
| Accumulated depreciation and amortization |  | (2,822) |  |  | (2,331) |  |
| Total property, plant and equipment, net |  | $ | 2,509 |  |  | $ | 2,565 |  |

[0001730168-20-000226:notes:159]
Depreciation expense was $570 million, $569 million and $515 million for fiscal years 2020, 2019, and 2018, respectively.

[0001730168-20-000226:notes:160]
As of November 1, 2020 and November 3, 2019, $27 million and $35 million, respectively, of unpaid purchases of property, plant and equipment were included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the consolidated statements of cash flows in the period in which they are paid.

[0001730168-20-000226:notes:161]
Other Current Assets

[0001730168-20-000226:notes:162]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 387 |  |  | $ | 302 |  |
| Other (miscellaneous) |  | 590 |  |  | 427 |  |
| Total other current assets |  | $ | 977 |  |  | $ | 729 |  |

[0001730168-20-000226:notes:163]
Other Current Liabilities

[0001730168-20-000226:notes:164]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 2,620 |  |  | $ | 1,501 |  |
| Tax liabilities |  | 440 |  |  | 229 |  |
| Other (miscellaneous) |  | 771 |  |  | 886 |  |
| Total other current liabilities |  | $ | 3,831 |  |  | $ | 2,616 |  |

[0001730168-20-000226:notes:165]
Other Long-Term Liabilities

[0001730168-20-000226:notes:166]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,185 |  |  | $ | 3,269 |  |
| Contract liabilities |  | 823 |  |  | 307 |  |
| Other (miscellaneous) |  | 1,418 |  |  | 2,037 |  |
| Total other long-term liabilities |  | $ | 5,426 |  |  | $ | 5,613 |  |

[0001730168-20-000226:notes:167]
Other Income, Net

[0001730168-20-000226:notes:168]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Gain from lapse of indemnification |  | $ | 116 |  |  | $ | — |  |  | $ | — |  |
| Other income |  | 56 |  |  | 18 |  |  | 27 |  |
| Interest income |  | 53 |  |  | 98 |  |  | 114 |  |
| Gains on investments |  | 31 |  |  | 145 |  |  | 3 |  |
| Other expense |  | (50) |  |  | (35) |  |  | — |  |
| Other income, net |  | $ | 206 |  |  | $ | 226 |  |  | $ | 144 |  |

[0001730168-20-000226:notes:169]
Other income includes gains on sales of businesses and other miscellaneous items.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001730168-20-000226:notes:170]
We have entered into operating and finance leases for our facilities, data centers and certain equipment. Operating lease expense was $106 million, $244 million and $233 million for fiscal years 2020, 2019 and 2018, respectively. Finance lease expense was $14 million for fiscal year 2020.
Other information related to leases was as follows:

[0001730168-20-000226:notes:171]
|  |  | Fiscal Year Ended |
|  |  | November 1,2020 |
|  |  | (In millions) |
| Cash paid for operating leases included in operating cash flows |  | $ | 125 |  |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 682 |  |  |
| ROU assets obtained in exchange for finance lease liabilities |  | $ | 74 |  |  |
|  |  | November 1,2020 |
| Weighted-average remaining lease term – operating leases (In years) |  | 10 |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 4 |  |
| Weighted-average discount rate – operating leases |  | 3.80 |  | % |
| Weighted-average discount rate – finance leases |  | 3.33 |  | % |

[0001730168-20-000226:notes:172]
Supplemental balance sheet information related to leases was as follows:

[0001730168-20-000226:notes:173]
|  |  | Classification on the Consolidated Balance Sheet |  | November 1,2020 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  | $ | 589 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  | $ | 62 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  | $ | 100 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 527 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  | $ | 20 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 48 |  |

[0001730168-20-000226:notes:174]
The maturities of lease liabilities were as follows:

[0001730168-20-000226:notes:175]
|  |  | November 1,2020 |
|  |  | Operating Leases |  | Finance Leases |
|  |  | (In millions) |
| 2021 |  | $ | 120 |  |  | $ | 21 |  |
| 2022 |  | 94 |  |  | 17 |  |
| 2023 |  | 84 |  |  | 17 |  |
| 2024 |  | 65 |  |  | 17 |  |
| 2025 |  | 54 |  |  | — |  |
| Thereafter |  | 356 |  |  | — |  |
| Total undiscounted liabilities |  | 773 |  |  | 72 |  |
| Less: interest |  | (146) |  |  | (4) |  |
| Present value of lease liabilities |  | $ | 627 |  |  | $ | 68 |  |

[0001730168-20-000226:notes:176]
As of November 3, 2019, future minimum lease payments under non-cancelable lease liabilities prior to our adoption of Topic 842 were as follows:

[0001730168-20-000226:notes:177]
|  |  | November 3,2019 |
|  |  | (In millions) |
| 2020 |  | $ | 115 |  |
| 2021 |  | 99 |  |
| 2022 |  | 80 |  |
| 2023 |  | 69 |  |
| 2024 |  | 47 |  |
| Thereafter |  | 390 |  |
| Total minimum lease payments |  | $ | 800 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-20-000226:notes:178]
Goodwill and Intangible Assets 
Goodwill

[0001730168-20-000226:notes:179]
|  |  | Wired Infrastructure |  | Wireless Communications |  | Enterprise Storage |  | Industrial & Other |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  | (In millions) |
| Balance as of November 4, 2018 |  | $ | 17,705 |  |  | $ | 5,945 |  |  | $ | 3,112 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 26,913 |  |
| Reallocation due to change in segments |  | (17,705) |  |  | (5,945) |  |  | (3,112) |  |  | (151) |  |  | 25,924 |  |  | 980 |  |  | 9 |  |  | — |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | 9,796 |  |  | — |  |  | 9,801 |  |
| Balance as of November 3, 2019 |  | — |  |  | — |  |  | — |  |  | — |  |  | 25,929 |  |  | 10,776 |  |  | 9 |  |  | 36,714 |  |
| Reallocation due to change in segments |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | (9) |  |  | — |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |  | 35 |  |  | 6,712 |  |  | — |  |  | 6,747 |  |
| Sale of business |  | — |  |  | — |  |  | — |  |  | — |  |  | (14) |  |  | — |  |  | — |  |  | (14) |  |
| Balance as of November 1, 2020 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | — |  |  | $ | 43,447 |  |

[0001730168-20-000226:notes:180]
In fiscal years 2020 and 2019, we reassigned goodwill balances among our reportable segments to reflect changes in our segment structure. The fair value of each segment, generally determined using a combination of the income approach and the market approach, is compared to our total fair value immediately prior to the reorganization to reassign goodwill.

[0001730168-20-000226:notes:181]
During the fourth quarter of fiscal years 2020, 2019, and 2018, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-20-000226:notes:182]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of November 1, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,119 |  |  | $ | (13,925) |  |  | $ | 10,194 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (3,179) |  |  | 5,210 |  |
| Order backlog |  | 2,579 |  |  | (1,836) |  |  | 743 |  |
| Trade names |  | 797 |  |  | (322) |  |  | 475 |  |
| Other |  | 252 |  |  | (117) |  |  | 135 |  |
| Intangible assets subject to amortization |  | 36,136 |  |  | (19,379) |  |  | 16,757 |  |
| IPR&D |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,161 |  |  | $ | (19,379) |  |  | $ | 16,782 |  |
| As of November 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,935 |  |  | $ | (10,113) |  |  | $ | 10,822 |  |
| Customer contracts and related relationships |  | 5,978 |  |  | (1,787) |  |  | 4,191 |  |
| Order backlog |  | 2,569 |  |  | (908) |  |  | 1,661 |  |
| Trade names |  | 712 |  |  | (247) |  |  | 465 |  |
| Other |  | 241 |  |  | (89) |  |  | 152 |  |
| Intangible assets subject to amortization |  | 30,435 |  |  | (13,144) |  |  | 17,291 |  |
| IPR&D |  | 263 |  |  | — |  |  | 263 |  |
| Total |  | $ | 30,698 |  |  | $ | (13,144) |  |  | $ | 17,554 |  |

[0001730168-20-000226:notes:183]
Based on the amount of intangible assets subject to amortization at November 1, 2020, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-20-000226:notes:184]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2021 |  | $ | 5,418 |  |
| 2022 |  | 4,366 |  |
| 2023 |  | 3,236 |  |
| 2024 |  | 2,365 |  |
| 2025 |  | 654 |  |
| Thereafter |  | 718 |  |
| Total |  | $ | 16,757 |  |

[0001730168-20-000226:notes:185]
The weighted-average amortization periods remaining by intangible asset category were as follows:

[0001730168-20-000226:notes:186]
| Amortizable intangible assets: |  | November 1,2020 |  | November 3,2019 |
|  |  | (In years) |
| Purchased technology |  | 5 |  | 5 |
| Customer contracts and related relationships |  | 4 |  | 5 |
| Order backlog |  | 2 |  | 3 |
| Trade names |  | 9 |  | 10 |
| Other |  | 10 |  | 10 |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001730168-20-000226:notes:187]
Net Income Per Share

[0001730168-20-000226:notes:188]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 2,961 |  |  | $ | 2,736 |  |  | $ | 12,629 |  |
| Dividends on preferred stock |  | (297) |  |  | (29) |  |  | — |  |
| Income from continuing operations attributable to noncontrolling interest |  | — |  |  | — |  |  | (352) |  |
| Income from continuing operations attributable to common stock |  | 2,664 |  |  | 2,707 |  |  | 12,277 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock (a) |  | (1) |  |  | (12) |  |  | (18) |  |
| Net income attributable to common stock |  | $ | 2,663 |  |  | $ | 2,695 |  |  | $ | 12,259 |  |

[0001730168-20-000226:notes:189]
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 402 |  |  | 398 |  |  | 418 |  |
| Dilutive effect of equity awards |  | 19 |  |  | 21 |  |  | 13 |  |
| Weighted-average shares outstanding - diluted |  | 421 |  |  | 419 |  |  | 431 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 6.62 |  |  | $ | 6.80 |  |  | $ | 29.37 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.03) |  |  | (0.04) |  |
| Net income per share |  | $ | 6.62 |  |  | $ | 6.77 |  |  | $ | 29.33 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 6.33 |  |  | $ | 6.46 |  |  | $ | 28.48 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.03) |  |  | (0.04) |  |
| Net income per share |  | $ | 6.33 |  |  | $ | 6.43 |  |  | $ | 28.44 |  |
| Potentially dilutive shares excluded from the calculation of diluted income per share because their effect would have been antidilutive: |  |  |  |  |  |  |
| Preferred Stock (b) |  | 12 |  |  | 1 |  |  | — |  |
| LP Units (c) |  | — |  |  | — |  |  | 9 |  |

[0001730168-20-000226:notes:190]
(a) Fiscal year 2018 excludes $1 million of loss from discontinued operations, net of income taxes, attributable to noncontrolling interest.

[0001730168-20-000226:notes:191]
(b) Represents common stock shares issuable upon the conversion of Mandatory Convertible Preferred Stock, as defined in Note 11. “Stockholders’ Equity.”
(c) Represents common stock shares issuable upon the exchange of LP Units prior to the effective time of the Mandatory Exchange (refer to Note 11. “Stockholders’ Equity” for additional information).


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-20-000226:notes:192]
Retirement Plans and Post-Retirement Benefits 
Pension and Post-Retirement Benefit Plans

[0001730168-20-000226:notes:193]
Defined Benefit Pension Plans.  The U.S. defined benefit pension plans primarily consist of a qualified pension plan. Benefits of the qualified pension plan are provided under an adjusted career-average-pay program, a cash-balance program or a dollar-per-month program. Benefit accruals under this plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the dollar-per-month program. We also have a non-qualified supplemental pension plan in the United States that principally provides benefits based on compensation in excess of amounts that can be considered under the qualified pension plan.

[0001730168-20-000226:notes:194]
We also have defined benefit pension plans for certain employees in Austria, France, Germany, India, Israel, Italy, Japan and Taiwan. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-20-000226:notes:195]
Post-Retirement Benefit Plans.  Certain of our U.S. employees who meet the retirement eligibility requirements as of their termination dates, may receive post-retirement medical benefits under our retiree medical account program. Majority of the eligible employees receive a medical benefit spending account of $55,000 upon retirement to pay premiums for medical coverage through the maximum age of 75 as a retiree.

[0001730168-20-000226:notes:196]
Our group life insurance plan offers post-retirement life insurance coverage for certain U.S. employees.

[0001730168-20-000226:notes:197]
Net Periodic Benefit (Income) Cost

[0001730168-20-000226:notes:198]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | Fiscal Year |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Service cost |  | $ | 12 |  |  | $ | 10 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost |  | 45 |  |  | 58 |  |  | 51 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets |  | (46) |  |  | (59) |  |  | (51) |  |  | (3) |  |  | (3) |  |  | (4) |  |
| Other |  | (3) |  |  | 1 |  |  | 1 |  |  | 1 |  |  | (1) |  |  | — |  |
| Net periodic benefit (income) cost |  | $ | 8 |  |  | $ | 10 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | (1) |  |  | $ | (1) |  |
| Net actuarial (gain) loss |  | $ | (28) |  |  | $ | 13 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 11 |  |  | $ | (3) |  |

[0001730168-20-000226:notes:199]
The components of net periodic benefit (income) cost other than the service cost are included in other income, net.

[0001730168-20-000226:notes:200]
Funded Status

[0001730168-20-000226:notes:201]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 1,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,539 |  |  | $ | 1,394 |  |  | $ | 85 |  |  | $ | 81 |  |
| Actual return on plan assets |  | 129 |  |  | 232 |  |  | 5 |  |  | 6 |  |
| Employer contributions |  | 13 |  |  | 15 |  |  | 1 |  |  | 1 |  |
| Payments from plan assets |  | (96) |  |  | (94) |  |  | (3) |  |  | (3) |  |
| Foreign currency impact |  | 8 |  |  | (8) |  |  | — |  |  | — |  |
| Fair value of plan assets — end of period |  | 1,593 |  |  | 1,539 |  |  | 88 |  |  | 85 |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,553 |  |  | 1,364 |  |  | 93 |  |  | 74 |  |
| Service cost |  | 12 |  |  | 10 |  |  | — |  |  | — |  |
| Interest cost |  | 45 |  |  | 58 |  |  | 3 |  |  | 3 |  |
| Actuarial loss |  | 61 |  |  | 186 |  |  | 2 |  |  | 14 |  |
| Benefit payments |  | (96) |  |  | (94) |  |  | (3) |  |  | (3) |  |
| Curtailments |  | (6) |  |  | — |  |  | — |  |  | — |  |
| Benefit obligations assumed in an acquisition |  | 10 |  |  | 37 |  |  | — |  |  | 5 |  |
| Foreign currency impact |  | 9 |  |  | (8) |  |  | — |  |  | — |  |
| Benefit obligations — end of period |  | 1,588 |  |  | 1,553 |  |  | 95 |  |  | 93 |  |
| Overfunded (underfunded) status of benefit obligations (a) |  | $ | 5 |  |  | $ | (14) |  |  | $ | (7) |  |  | $ | (8) |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive loss, net of taxes |  | $ | (94) |  |  | $ | (125) |  |  | $ | (14) |  |  | $ | (15) |  |

[0001730168-20-000226:notes:202]
_________________________________

[0001730168-20-000226:notes:203]
(a)Substantially all amounts recognized in the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented.

[0001730168-20-000226:notes:204]
Plans with benefit obligations in excess of plan assets:

[0001730168-20-000226:notes:205]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 1,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 82 |  |  | $ | 92 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 68 |  |  | $ | 80 |  |  | $ | 15 |  |  | $ | 16 |  |
| Fair value of plan assets |  | $ | 11 |  |  | $ | 32 |  |  | $ | — |  |  | $ | — |  |

[0001730168-20-000226:notes:206]
Plans with benefit obligations less than plan assets:

[0001730168-20-000226:notes:207]
|  |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | November 1,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 1,506 |  |  | $ | 1,461 |  |  | $ | — |  |  | $ | — |  |
| Accumulated benefit obligations |  | $ | 1,505 |  |  | $ | 1,460 |  |  | $ | 80 |  |  | $ | 77 |  |
| Fair value of plan assets |  | $ | 1,582 |  |  | $ | 1,507 |  |  | $ | 88 |  |  | $ | 85 |  |

[0001730168-20-000226:notes:208]
The fair value of pension plan assets as of November 1, 2020 and November 3, 2019 included $160 million and $151 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-20-000226:notes:209]
The projected benefit obligations as of November 1, 2020 and November 3, 2019 included $206 million and $184 million, respectively, of obligations related to our non-U.S. pension plans. The accumulated benefit obligations as of November 1, 2020 and November 3, 2019 included $190 million and $171 million, respectively, of obligations related to our non-U.S. pension plans.

[0001730168-20-000226:notes:210]
Expected Future Benefit Payments

[0001730168-20-000226:notes:211]
| Fiscal Years: |  | Pension Benefits |  | Post-Retirement Benefits |
|  |  | (In millions) |
| 2021 |  | $ | 94 |  |  | $ | 8 |  |
| 2022 |  | $ | 93 |  |  | $ | 4 |  |
| 2023 |  | $ | 93 |  |  | $ | 4 |  |
| 2024 |  | $ | 93 |  |  | $ | 4 |  |
| 2025 |  | $ | 93 |  |  | $ | 4 |  |
| 2026-2030 |  | $ | 451 |  |  | $ | 23 |  |

[0001730168-20-000226:notes:212]
Defined Benefit Pension Plan Investment Policy

[0001730168-20-000226:notes:213]
Plan assets of the funded defined benefit pension plans are generally invested in funds held by third-party fund managers. Our benefit plan investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has the discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-20-000226:notes:214]
Substantially all of the plan assets are for the U.S. qualified pension plan. The target asset allocation for this plan reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2020 and 2019, 100% of the U. S. qualified pension plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-20-000226:notes:215]
Fair Value Measurement of Defined Benefit Pension Plan Assets

[0001730168-20-000226:notes:216]
|  |  | November 1, 2020 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |  |
|  |  | (In millions) |  |
| Cash equivalents |  | $ | 42 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 42 |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 26 |  | (b) |  | — |  |  |  | — |  |  | 26 |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 158 |  | (c) |  | — |  |  | 158 |  |  |
| Corporate bonds |  | — |  |  |  | 1,307 |  | (c) |  | — |  |  | 1,307 |  |  |
| Municipal bonds |  | — |  |  |  | 22 |  | (c) |  | — |  |  | 22 |  |  |
| Government bonds |  | — |  |  |  | 36 |  | (c) |  | — |  |  | 36 |  |  |
| Asset-backed securities |  | — |  |  |  | 2 |  | (c) |  | — |  |  | 2 |  |  |
| Total plan assets |  | $ | 68 |  |  |  | $ | 1,525 |  |  |  | $ | — |  |  | $ | 1,593 |  |  |

[0001730168-20-000226:notes:217]
|  |  | November 3, 2019 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 34 |  | (a) |  | $ | — |  |  |  | $ | — |  |  | $ | 34 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 21 |  | (b) |  | — |  |  |  | — |  |  | 21 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 82 |  | (c) |  | — |  |  | 82 |  |
| Corporate bonds |  | — |  |  |  | 1,372 |  | (c) |  | — |  |  | 1,372 |  |
| Municipal bonds |  | — |  |  |  | 19 |  | (c) |  | — |  |  | 19 |  |
| Government bonds |  | — |  |  |  | 10 |  | (c) |  | — |  |  | 10 |  |
| Asset-backed securities |  | — |  |  |  | 1 |  | (c) |  | — |  |  | 1 |  |
| Total plan assets |  | $ | 55 |  |  |  | $ | 1,484 |  |  |  | $ | — |  |  | $ | 1,539 |  |

[0001730168-20-000226:notes:218]
(a)Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets.

[0001730168-20-000226:notes:219]
(b)These equity securities were valued based on quoted prices in active markets.

[0001730168-20-000226:notes:220]
(c)These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the assets, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals.

[0001730168-20-000226:notes:221]
Post-Retirement Benefit Plan Investment Policy

[0001730168-20-000226:notes:222]
Our overall investment strategy for the group life insurance plan is to allocate assets in a manner that seeks to both maximize the safety of promised benefits and minimize the cost of funding those benefits. The target asset allocation for plan assets reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. We set the overall portfolio allocation and use an investment manager that directs the investment of funds consistent with that allocation. The investment manager invests the plan assets in index funds that it manages. For both fiscal years 2020 and 2019, 100% of plan assets were allocated to

[0001730168-20-000226:notes:223]
commingled funds that invested in fixed income, in line with the target allocation. The fair value of the commingled funds are measured using net asset value per share as a practical expedient.

[0001730168-20-000226:notes:224]
Assumptions

[0001730168-20-000226:notes:225]
The assumptions used to determine the benefit obligations and net periodic benefit (income) cost from our defined benefit pension plans and post-retirement benefit plans are presented in the tables below. The expected long-term return on assets shown in the tables below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes (both historical and forecasted) in which we expect the pension and post-retirement funds to be invested. Discount rates reflect the current rate at which defined benefit pension and post-retirement benefit obligations could be settled based on the measurement dates of the plans, which is October 31, the month end closest to our fiscal year end. The range of assumptions that are used for defined benefit pension plans reflects the different economic environments within various countries.

[0001730168-20-000226:notes:226]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 1,2020 |  | November 3,2019 |  | 2020 |  | 2019 |  | 2018 |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 0.61%-6.54% |  | 0.47%-7.00% |  | 0.47%-7.00% |  | 0.50%-8.00% |  | 0.50%-7.00% |
| Average increase in compensation levels |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 1.80%-10.00% |  | 2.00%-11.00% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 1.50%-7.80% |  | 1.50%-7.75% |  | 1.50%-7.50% |

[0001730168-20-000226:notes:227]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit (Income) CostFiscal Year |
|  |  | November 1,2020 |  | November 3,2019 |  | 2020 |  | 2019 |  | 2018 |
| Post-retirement benefit plans: |  |  |  |  |  |  |  |  |  |  |
| Discount rate |  | 2.10%-2.90% |  | 2.80%-3.20% |  | 2.80%-3.20% |  | 4.12%-4.60% |  | 3.40%-3.80% |
| Average increase in compensation levels |  | 3.00% |  | 3.00% |  | 3.00% |  | 3.00% |  | 3.00% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 3.20% |  | 4.80% |  | 4.80% |

[0001730168-20-000226:notes:228]
|  |  | Assumed Health Care Cost Trend Rate Used to Measure the Expected Cost of Benefits as of |
|  |  | November 1,2020 |  | November 3,2019 |
| Health care cost trend rate assumed for next year |  | 7.25% |  | 4.50%-7.40% |
| Rate to which the health care cost trend rate is assumed to decline (ultimate health care cost trend rate) |  | 4.50% |  | 3.50%-4.50% |
| Year that the rate reaches the ultimate health care cost trend rate |  | 2029 |  | 2031 |

[0001730168-20-000226:notes:229]
A one percentage point increase or decrease in the assumed health care cost trend rates would not have had a material effect on the accumulated post-retirement benefit obligations or service and interest cost components of the net periodic benefit cost for any periods presented.

[0001730168-20-000226:notes:230]
Defined Contribution Plans

[0001730168-20-000226:notes:231]
Our eligible U.S. employees participate in a company-sponsored 401(k) plan. Under the plan, we provide matching contributions to employees up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2020, 2019 and 2018, we made contributions of $99 million, $89 million and $73 million, respectively, to the 401(k) plan.

[0001730168-20-000226:notes:232]
In addition, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans.


## us-gaap:DebtDisclosureTextBlock

[0001730168-20-000226:notes:233]
Borrowings

[0001730168-20-000226:notes:234]
|  |  | November 1, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | 1,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

[0001730168-20-000226:notes:235]
|  |  | November 1, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500%- 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  | 22 |  |  | 2.59%- 4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,498 |  |  |  |  | 33,059 |  |
| Less: unamortized discount and issuance costs |  |  |  | (504) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 40,994 |  |  |  |  | $ | 32,798 |  |

[0001730168-20-000226:notes:236]
(a) Represents the weighted average interest rate on outstanding commercial paper.

[0001730168-20-000226:notes:237]
As of November 1, 2020, $20 million of short-term and $48 million of long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively.

[0001730168-20-000226:notes:238]
June 2020 Senior Notes

[0001730168-20-000226:notes:239]
On June 4, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024, for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “June 2020 Senior Notes”). As a result of this exchange, we incurred premiums of $177 million. The June 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). We may redeem or purchase, in whole or in part, any of the June 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the June 2020 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. The June 2020 Senior Notes are recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000226:notes:240]
May 2020 Senior Notes

[0001730168-20-000226:notes:241]
On May 8, 2020, we issued $8 billion of senior unsecured notes (the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. The May 2020 Senior Notes are recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000226:notes:242]
The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, as defined below, were used to repay an aggregate of $5,424 million of term loans outstanding under the November 2019 Credit Agreement, as defined below, consisting of repayments of $2,712 million of each of our unsecured term A-3 and A-5 facilities and $3 billion of borrowings outstanding under the Revolving Facility, as defined below.

[0001730168-20-000226:notes:243]
April 2020 Senior Notes

[0001730168-20-000226:notes:244]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. The April 2020 Senior Notes are recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000226:notes:245]
Pursuant to a cash tender offer that we completed on April 23, 2020, we repurchased $2,361 million of our 3.000% notes due January 2022, $1,274 million of our 3.125% notes due April 2021 and $351 million of our 2.200% notes due January 2021 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense.

[0001730168-20-000226:notes:246]
November 2019 Term Loans

[0001730168-20-000226:notes:247]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “November 2019 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate. We used net proceeds from the November 2019 Term Loans to fund the $10.7 billion Symantec Asset Purchase and to repay $750 million principal amount of 5.375% notes due December 2019 and $2,750 million principal amount of 2.375% notes due January 2020, on their respective maturity dates. Our obligations under the November 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. During the fiscal year ended November 1, 2020, we repaid an aggregate of $9,612 million of our November 2019 Term Loans, consisting of repayments of $5,931 million and $3,681 million of our unsecured term A-3 and A-5 facilities, respectively, and wrote off $60 million of unamortized discount and issuance costs. As a result of these repayments, all remaining principal payments are due more than one year after November 1, 2020 and were included in long-term debt.

[0001730168-20-000226:notes:248]
May 2019 Term Loans

[0001730168-20-000226:notes:249]
In May 2019, we entered into a credit agreement (the “May 2019 Credit Agreement”), which provided for a $2 billion unsecured term A-3 facility, a $2 billion unsecured term A-5 facility and a $2 billion unsecured term A-7 facility (collectively, the “May 2019 Term Loans”). Interest on our May 2019 Term Loans is based on a floating rate. Our obligations under the May 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM, BTI and Broadcom Cayman Finance Limited (“Cayman Finance”), which subsequently merged into BTI during fiscal year 2019 with BTI remaining as the surviving entity.

[0001730168-20-000226:notes:250]
During fiscal year 2019, we fully repaid our unsecured term A-3 facility of $2 billion and repaid $1.2 billion of each of our unsecured term A-5 and A-7 facilities under the May 2019 Credit Agreement. As a result, we wrote off $22 million of discount and issuance costs, which is included in interest expense. During fiscal year 2020, we repaid an aggregate of $1.6 billion of the May 2019 Term Loans, representing the outstanding balance of the May 2019 Term Loans.

[0001730168-20-000226:notes:251]
The May 2019 Credit Agreement also provided for a five-year $5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the May 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) May 2024 or (b) the date of termination in whole of the revolving lenders’ commitments under the May 2019 Credit Agreement in accordance with the terms thereof. As of November 1, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

[0001730168-20-000226:notes:252]
April 2019 Senior Notes

[0001730168-20-000226:notes:253]
In April 2019, we issued $11 billion of senior unsecured notes (“April 2019 Senior Notes”). The April 2019 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may redeem or purchase, in whole or in part, any of the April 2019 Senior Notes prior to their respective maturities, subject to a make-whole premium determined in accordance with the indenture governing the April 2019 Senior Notes, plus accrued and unpaid interest. The April 2019 Senior Notes are recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000226:notes:254]
Exchange Offer

[0001730168-20-000226:notes:255]
In connection with the issuance of the June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes (collectively, the “2020 Senior Notes”) and the April 2019 Senior Notes, we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the SEC, and cause to be declared effective, a registration statement with respect to an offer to exchange (the “Exchange Offer”) each series of the 2020 Senior Notes and April 2019 Senior Notes for notes that are registered with the U.S. Securities and Exchange Commission (the “SEC”) (the “Registered Notes”), with substantially identical terms. On July 6, 2020, we launched the Exchange Offer, which completed on August 10, 2020. Substantially all of our 2020 Senior Notes and April 2019 Senior Notes were tendered and exchanged for the corresponding Registered Notes in the Exchange Offer.

[0001730168-20-000226:notes:256]
Commercial Paper

[0001730168-20-000226:notes:257]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in an aggregate principal amount of up to $2 billion outstanding at any time with

[0001730168-20-000226:notes:258]
maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The Revolving Facility supports our commercial paper program. Outstanding Commercial Paper borrowings reduce the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. We intend to continuously replace our Commercial Paper upon maturity with newly issued commercial paper. In addition, we have the ability to finance the Commercial Paper borrowings on a long-term basis as they are supported by the Revolving Facility. We have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. As of November 1, 2020, we had no Commercial Paper outstanding. We had $1 billion of Commercial Paper outstanding as of November 3, 2019 with maturities generally less than sixty days.

[0001730168-20-000226:notes:259]
2017 Senior Notes

[0001730168-20-000226:notes:260]
During the fiscal year ended October 29, 2017, BRCM and Cayman Finance issued $17,550 million of senior unsecured notes (the “2017 Senior Notes”). Our 2017 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom and BTI. We may redeem or purchase, in whole or in part, any of the 2017 Senior Notes prior to their respective maturities, subject to a make-whole premium determined in accordance with the indenture governing the 2017 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-20-000226:notes:261]
During fiscal year 2018, substantially all of the 2017 Senior Notes were tendered and exchanged for notes registered with the SEC, with substantially identical terms.

[0001730168-20-000226:notes:262]
Assumed CA Senior Notes

[0001730168-20-000226:notes:263]
In connection with our acquisition of CA, we assumed $2,250 million in aggregate principal amount of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth with the indenture governing the Assumed CA Senior Notes. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. During fiscal year 2019, we fully repaid $400 million of our 3.600% notes due August 2020.

[0001730168-20-000226:notes:264]
Assumed Brocade Convertible Notes

[0001730168-20-000226:notes:265]
As a result of our acquisition of Brocade, we assumed $575 million in aggregate principal amount of Brocade’s 1.375% convertible senior unsecured notes (the “Assumed Brocade Convertible Notes”). During fiscal year 2018, we repurchased $537 million in aggregate principal amount for $548 million at a conversion rate of $1,018 for each $1,000 of principal surrendered for conversion. We fully repaid the remaining $37 million of the Assumed Brocade Convertible Notes during fiscal year 2020.

[0001730168-20-000226:notes:266]
Fair Value of Debt

[0001730168-20-000226:notes:267]
As of November 1, 2020, the estimated aggregate fair value of our debt was $45,274 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans approximated the carrying value due to their floating interest rates and consistency in our credit ratings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-20-000226:notes:268]
Future Principal Payments of Debt

[0001730168-20-000226:notes:269]
The future scheduled principal payments of debt as of November 1, 2020 were as follows:

[0001730168-20-000226:notes:270]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 |  | $ | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 3,069 |  |
| 2024 |  | 3,403 |  |
| 2025 |  | 7,319 |  |
| Thereafter |  | 25,073 |  |
| Total |  | $ | 41,498 |  |

[0001730168-20-000226:notes:271]
As of November 1, 2020 and November 3, 2019, we accrued interest payable of $304 million and $214 million, respectively, and were in compliance with all debt covenants


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001730168-20-000226:notes:272]
As of November 1, 2020 and November 3, 2019, we accrued interest payable of $304 million and $214 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-20-000226:notes:273]
Stockholders’ Equity 
Mandatory Convertible Preferred Stock Offering

[0001730168-20-000226:notes:274]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”), which generated net proceeds of approximately $3,679 million.

[0001730168-20-000226:notes:275]
The holders of Mandatory Convertible Preferred Stock are entitled to receive, when, as and if declared by our Board of Directors, or an authorized committee thereof, out of funds legally available for payment, cumulative dividends at the annual rate of 8.00% of the liquidation preference of $1,000 per share (equivalent to $80 annually per share), payable in cash or, subject to certain limitations, by delivery of shares of our common stock or any combination of cash and shares of our common stock, at our election; provided, however, that any undeclared and unpaid dividends will continue to accumulate.

[0001730168-20-000226:notes:276]
Subject to limited exceptions, no dividends may be declared or paid on shares of our common stock, unless all accumulated dividends have been paid or set aside for payment on all outstanding shares of our Mandatory Convertible Preferred Stock for all past completed dividend periods. In the event of our voluntary or involuntary liquidation, dissolution or winding-up, no distribution of our assets may be made to holders of our common stock until we have paid to holders of our Mandatory Convertible Preferred Stock a liquidation preference equal to $1,000 per share plus accumulated and unpaid dividends.

[0001730168-20-000226:notes:277]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of November 1, 2020, the minimum conversion rate was 3.0567 and the maximum conversion rate was 3.5729.

[0001730168-20-000226:notes:278]
We recognized $27 million and $29 million of accrued preferred stock dividends, which were presented as temporary equity in our consolidated balance sheets as of November 1, 2020 and November 3, 2019, respectively.

[0001730168-20-000226:notes:279]
Redomiciliation Transaction

[0001730168-20-000226:notes:280]
For the period prior to the Redomiciliation Transaction, our stockholders’ equity reflected Broadcom-Singapore’s outstanding ordinary shares. On April 4, 2018, all Broadcom-Singapore outstanding ordinary shares were exchanged on a one-for-one basis for newly issued shares of Broadcom common stock and Broadcom-Singapore became a wholly-owned subsidiary of Broadcom.

[0001730168-20-000226:notes:281]
In conjunction with the Redomiciliation Transaction and pursuant to the Mandatory Exchange, all outstanding LP Units held by the limited partners were mandatorily exchanged for approximately 22 million newly issued shares of Broadcom common stock on a one-for-one basis. As a result, all limited partners of the Partnership became common stockholders of Broadcom. In addition, all related outstanding special preference shares of Broadcom-Singapore were automatically redeemed upon the Mandatory Exchange.

[0001730168-20-000226:notes:282]
Noncontrolling Interest

[0001730168-20-000226:notes:283]
Immediately prior to the Redomiciliation Transaction, the limited partners held a noncontrolling interest of approximately 5% in the Partnership through their ownership of LP Units. Accordingly, net income attributable to our common stock in our consolidated statement of operations for fiscal year 2018 excluded the noncontrolling interest’s proportionate share of our results prior to the Redomiciliation Transaction. In addition, we presented the proportionate share of equity attributable to the noncontrolling interest as a separate component of total equity within our consolidated statements of equity for the period prior to the Redomiciliation Transaction.

[0001730168-20-000226:notes:284]
Cash Dividends and Distributions Declared and Paid

[0001730168-20-000226:notes:285]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions, except per share/unit data) |
| Dividends per share to common stockholders |  | $ | 13.00 |  |  | $ | 10.60 |  |  | $ | 7.00 |  |
| Dividends to common stockholders |  | $ | 5,235 |  |  | $ | 4,235 |  |  | $ | 2,921 |  |
| Dividends per share to preferred stockholders |  | $ | 80.00 |  |  | $ | — |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 299 |  |  | $ | — |  |  | $ | — |  |
| Distributions per unit to limited partners |  | $ | — |  |  | $ | — |  |  | $ | 3.50 |  |
| Distributions to limited partners |  | $ | — |  |  | $ | — |  |  | $ | 77 |  |

[0001730168-20-000226:notes:286]
Stock Repurchase Program

[0001730168-20-000226:notes:287]
Pursuant to an $18 billion stock repurchase program previously authorized by our Board of Directors, we repurchased and retired approximately 21 million and 32 million shares of our common stock for $5,435 million and $7,258 million during fiscal years 2019 and 2018, respectively. This authorization ended on November 3, 2019.

[0001730168-20-000226:notes:288]
Equity Incentive Award Plans

[0001730168-20-000226:notes:289]
Stock-based incentive awards are provided to employees and directors under the terms of various Broadcom equity incentive plans.

[0001730168-20-000226:notes:290]
2009 Plan

[0001730168-20-000226:notes:291]
In July 2009, our Board of Directors adopted, and our stockholders approved, the Avago Technologies Limited 2009 Equity Incentive Award Plan (the “2009 Plan”) to authorize the grant of options, stock appreciation rights, RSUs, dividend equivalents, performance awards, and other stock-based awards. A total of 20 million shares of common stock were initially reserved for issuance under the 2009 Plan, subject to annual increases starting in fiscal year 2012. The amount of the annual increase was equal to the least of (a) 6 million shares, (b) 3% of the common stock outstanding on the last day of the immediately preceding fiscal year and (c) such smaller number of common stock as determined by our Board. However, no more than 90 million shares of common stock may be issued upon the exercise of equity awards issued under the 2009 Plan. The 2009 Plan became effective on July 27, 2009.

[0001730168-20-000226:notes:292]
Options issued to employees under the 2009 Plan prior to March 2011 generally expire ten years following the date of grant. Since March 2011, options issued to employees under the 2009 Plan generally expire seven years after the date of grant. Options awarded to non-employees under this plan generally expire after five years. Options issued to both employees and non-employees under the 2009 Plan generally vested over a period of four years from the date of grant and were granted with an exercise price equal to the fair market value on the date of grant. Any stock options cancelled or forfeited after July 27, 2009 under the equity incentive plans adopted prior to the 2009 Plan became available for issuance under the 2009 Plan. RSU awards granted to employees under the 2009 Plan generally vest annually over four years.

[0001730168-20-000226:notes:293]
The 2009 Plan expired in July 2019.

[0001730168-20-000226:notes:294]
2003 Plan

[0001730168-20-000226:notes:295]
In connection with the acquisition of LSI Corporation (“LSI”), we assumed the LSI 2003 Equity Incentive Plan (the “2003 Plan”) and outstanding unvested stock options and RSUs originally granted by LSI under the 2003 Plan that were held by continuing employees. Under the 2003 Plan, we may grant to former employees of LSI and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options covering more than 4 million shares or more than an aggregate of 1 million shares of restricted stock and RSUs in any fiscal year. Equity awards granted under the 2003 Plan following the LSI acquisition are on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 1, 2020, 3 million shares remained available for issuance under the 2003 Plan.

[0001730168-20-000226:notes:296]
2012 Plan

[0001730168-20-000226:notes:297]
In connection with the acquisition of BRCM, we assumed the BRCM 2012 Stock Incentive Plan (the “2012 Plan”) and outstanding unvested RSUs originally granted by BRCM under the 2012 Plan that were held by continuing employees. Under the 2012 Plan, we may grant to former employees of BRCM and other employees who were not employees of Broadcom at the time of the acquisition restricted stock awards, RSUs, stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant. No participant may be granted stock options, restricted stock or

[0001730168-20-000226:notes:298]
RSUs, covering more than an aggregate of 4 million shares in any fiscal year. Equity awards granted under the 2012 Plan following the acquisition of BRCM are on similar terms and consistent with similar grants made pursuant to the 2009 Plan. As of November 1, 2020, 95 million shares remained available for issuance under the 2012 Plan. The number of shares available for issuance under the 2012 Plan is subject to an annual increase of 12 million shares.

[0001730168-20-000226:notes:299]
We also grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2020, 2019 and 2018, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 200% of the original grant at vesting based upon the total stockholder return (“TSR”) on our common stock as compared to the TSR of an index group of companies.

[0001730168-20-000226:notes:300]
Amendment to the RSU Vesting Schedule

[0001730168-20-000226:notes:301]
During fiscal year 2019, the Compensation Committee of our Board of Directors approved an amendment to the vesting of time-based RSUs (other than those assumed in an acquisition), held by approximately 16,500 employees below the vice president level, from an annual vesting cycle to a quarterly vesting cycle.

[0001730168-20-000226:notes:302]
Employee Stock Purchase Plan

[0001730168-20-000226:notes:303]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or the end of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974.

[0001730168-20-000226:notes:304]
Stock-Based Compensation Expense

[0001730168-20-000226:notes:305]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 109 |  |  | $ | 120 |  |  | $ | 77 |  |
| Cost of subscriptions and services |  | 50 |  |  | 43 |  |  | 9 |  |
| Research and development |  | 1,419 |  |  | 1,532 |  |  | 855 |  |
| Selling, general and administrative |  | 398 |  |  | 490 |  |  | 286 |  |
| Total stock-based compensation expense (a) |  | $ | 1,976 |  |  | $ | 2,185 |  |  | $ | 1,227 |  |
| Estimated income tax benefits for stock-based compensation |  | $ | 345 |  |  | $ | 400 |  |  | $ | 195 |  |
| Income tax benefits for stock-based awards exercised or released |  | $ | 147 |  |  | $ | 232 |  |  | $ | 181 |  |

[0001730168-20-000226:notes:306]
_______________________________________________________

[0001730168-20-000226:notes:307]
(a)Fiscal year 2019 stock-based compensation expense does not include $75 million restructuring charges for accelerated vesting of assumed equity awards held by employees terminated in connection with the CA Merger.

[0001730168-20-000226:notes:308]
We have assumed an annualized forfeiture rate for RSUs of 5%. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated.

[0001730168-20-000226:notes:309]
During the first quarter of fiscal year 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $902 million and $890 million for fiscal years 2020 and 2019, respectively.

[0001730168-20-000226:notes:310]
In connection with the amendment to the vesting of certain time-based RSUs from an annual cycle to a quarterly cycle, we recognized approximately $140 million in incremental compensation cost during fiscal year 2019.

[0001730168-20-000226:notes:311]
As of November 1, 2020, the total unrecognized compensation cost related to unvested stock-based awards was $4,021 million, which is expected to be recognized over the remaining weighted-average service period of 3.4 years.

[0001730168-20-000226:notes:312]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-20-000226:notes:313]
|  |  | Market-Based Awards |
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
| Risk-free interest rate |  | 1.2 | % |  | 2.7 | % |  | 2.4 | % |
| Dividend yield |  | 4.7 | % |  | 4.4 | % |  | 2.6 | % |
| Volatility |  | 31.2 | % |  | 33.0 | % |  | 32.5 | % |
| Expected term (in years) |  | 4.0 |  | 4.0 |  | 4.0 |

[0001730168-20-000226:notes:314]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-20-000226:notes:315]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-20-000226:notes:316]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-20-000226:notes:317]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-20-000226:notes:318]
Restricted Stock Unit Awards

[0001730168-20-000226:notes:319]
A summary of time- and market-based RSU activity is as follows:

[0001730168-20-000226:notes:320]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |
|  |  | (In millions, except per share data) |
| Balance as of October 29, 2017 |  | 18 |  |  | $ | 163.42 |  |  |  |
| Granted |  | 7 |  |  | $ | 239.48 |  |  |  |
| Vested |  | (6) |  |  | $ | 155.78 |  |  |  |
| Forfeited |  | (1) |  |  | $ | 175.46 |  |  |  |
| Balance as of November 4, 2018 |  | 18 |  |  | $ | 195.50 |  |  |  |
| Assumed in CA Merger |  | 1 |  |  | $ | 206.14 |  |  |  |
| Granted |  | 33 |  |  | $ | 183.64 |  |  |  |
| Vested |  | (10) |  |  | $ | 192.28 |  |  |  |
| Forfeited |  | (2) |  |  | $ | 182.80 |  |  |  |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |  |  |
| Granted |  | 3 |  |  | $ | 252.36 |  |  |  |
| Vested |  | (8) |  |  | $ | 210.84 |  |  |  |
| Forfeited |  | (3) |  |  | $ | 198.17 |  |  |  |
| Balance as of November 1, 2020 |  | 32 |  |  | $ | 188.35 |  |  |  |

[0001730168-20-000226:notes:321]
The aggregate fair value of time- and market-based RSUs that vested in fiscal years 2020, 2019 and 2018 was $2,254 million, $2,958 million and $1,516 million, respectively, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-20-000226:notes:322]
Stock Option Awards

[0001730168-20-000226:notes:323]
A summary of time- and market-based stock option activity is as follows:

[0001730168-20-000226:notes:324]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |
| Balance as of October 29, 2017 |  | 10 |  |  | $ | 49.54 |  |  |  |  |  |
| Exercised |  | (2) |  |  | $ | 47.41 |  |  |  |  | $ | 534 |  |
| Cancelled |  | — |  | * | $ | 72.37 |  |  |  |  |  |
| Balance as of November 4, 2018 |  | 8 |  |  | $ | 50.14 |  |  |  |  |  |
| Exercised |  | (4) |  |  | $ | 47.88 |  |  |  |  | $ | 761 |  |
| Cancelled |  | — |  | * | $ | 49.00 |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  |  |  |  |
| Exercised |  | (3) |  |  | $ | 49.05 |  |  |  |  | $ | 917 |  |
| Balance as of November 1, 2020 |  | 1 |  |  | $ | 62.35 |  |  | 0.4 |  | $ | 266 |  |
| Fully vested as of November 1, 2020 |  | 1 |  |  | $ | 62.39 |  |  | 0.4 |  | $ | 264 |  |
| Fully vested and expected to vest as of November 1, 2020 |  | 1 |  |  | $ | 62.35 |  |  | 0.4 |  | $ | 266 |  |

[0001730168-20-000226:notes:325]
* Represents fewer than 0.5 million shares.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-20-000226:notes:326]
Income Taxes 
Components of Income from Continuing Operations Before Income Taxes

[0001730168-20-000226:notes:327]
The following table presents the components of income from continuing operations before income taxes for financial reporting purposes:

[0001730168-20-000226:notes:328]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Domestic loss |  | $ | (4,221) |  |  | $ | (4,116) |  |  | $ | (705) |  |
| Foreign income |  | 6,664 |  |  | 6,342 |  |  | 5,250 |  |
| Income from continuing operations before income taxes |  | $ | 2,443 |  |  | $ | 2,226 |  |  | $ | 4,545 |  |

[0001730168-20-000226:notes:329]
Components of Benefit from Income Taxes

[0001730168-20-000226:notes:330]
The benefit from income taxes in fiscal year 2020 was primarily due to jurisdictional mix of income and expense, the recognition of gross uncertain tax benefits as a result of lapses of statutes of limitations, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards.

[0001730168-20-000226:notes:331]
The benefit from income taxes in fiscal year 2019 was primarily due to excess tax benefits from stock-based awards, the recognition of gross unrecognized tax benefits as a result of audit settlements and lapses of statutes of limitations net of increases in balances related to tax positions taken during the year, deferred tax remeasurement in state and foreign jurisdictions, internal reorganizations, and the partial release of our valuation allowance as a result of the CA Merger, partly offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act (“2017 Tax Reform Act”).

[0001730168-20-000226:notes:332]
The benefit from income taxes in the fiscal year 2018 was primarily due to income tax benefits recognized from the enactment of the 2017 Tax Reform Act and as a result of our redomiciliation to the United States on April 4, 2018.

[0001730168-20-000226:notes:333]
We have obtained several tax incentives from the Singapore Economic Development Board which provide that qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax. Each tax incentive is separate and distinct from the others and may be granted, withheld, extended, modified, truncated, complied with, or terminated independently without any effect on the other incentives. Subject to our compliance with the conditions specified in these incentives and legislative developments, the Singapore tax incentive is scheduled to expire in November 2025.

[0001730168-20-000226:notes:334]
We have also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such conditions specified, we will lose the related tax benefits and we could be required to refund previously realized material tax benefits.

[0001730168-20-000226:notes:335]
Before taking into consideration the effects of the 2017 Tax Reform Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to increase the benefit from income taxes by approximately $833 million, $923 million and $590 million for fiscal years 2020, 2019 and 2018, respectively.

[0001730168-20-000226:notes:336]
Significant components of benefit from income taxes are as follows:

[0001730168-20-000226:notes:337]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Current tax expense (benefit from): |  |  |  |  |  |  |
| Federal |  | $ | 7 |  |  | $ | (49) |  |  | $ | 255 |  |
| State |  | 51 |  |  | (16) |  |  | 38 |  |
| Foreign |  | 506 |  |  | 342 |  |  | 171 |  |
|  |  | 564 |  |  | 277 |  |  | 464 |  |
| Deferred tax expense (benefit from): |  |  |  |  |  |  |
| Federal |  | (627) |  |  | (497) |  |  | (8,666) |  |
| State |  | (161) |  |  | (113) |  |  | (103) |  |
| Foreign |  | (294) |  |  | (177) |  |  | 221 |  |
|  |  | (1,082) |  |  | (787) |  |  | (8,548) |  |
| Total benefit from income taxes |  | $ | (518) |  |  | $ | (510) |  |  | $ | (8,084) |  |

[0001730168-20-000226:notes:338]
Rate Reconciliation

[0001730168-20-000226:notes:339]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
| Statutory tax rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State, net of federal benefit |  | (3.6) |  |  | (4.6) |  |  | (1.1) |  |
| 2017 Tax Reform Act |  | — |  |  | 5.1 |  |  | (159.0) |  |
| Redomiciliation transaction withholding tax remeasurement |  | — |  |  | — |  |  | (25.6) |  |
| Foreign income taxed at different rates |  | (48.6) |  |  | (52.5) |  |  | (16.3) |  |
| Deemed inclusion of foreign earnings |  | 21.8 |  |  | 25.9 |  |  | 4.7 |  |
| Deferred taxes on unremitted foreign earnings |  | (1.1) |  |  | 1.9 |  |  | 0.4 |  |
| Excess tax benefits from stock-based compensation |  | (6.0) |  |  | (10.4) |  |  | (4.0) |  |
| Research and development credit |  | (4.3) |  |  | (7.6) |  |  | (2.9) |  |
| Other, net |  | (0.4) |  |  | (1.7) |  |  | 4.9 |  |
| Effective tax rate on income before income taxes |  | (21.2) | % |  | (22.9) | % |  | (177.9) | % |

[0001730168-20-000226:notes:340]
Summary of Deferred Income Taxes

[0001730168-20-000226:notes:341]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |
| Net operating loss, credit and other carryforwards |  | $ | 1,773 |  |  | $ | 1,733 |  |
| Deferred revenue |  | 529 |  |  | 316 |  |
| Employee stock awards |  | 273 |  |  | 218 |  |
| Other deferred income tax assets |  | 392 |  |  | 313 |  |
| Gross deferred income tax assets |  | 2,967 |  |  | 2,580 |  |
| Less: valuation allowance |  | (1,707) |  |  | (1,563) |  |
| Deferred income tax assets |  | 1,260 |  |  | 1,017 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 1,477 |  |  | 2,360 |  |
| Foreign earnings not indefinitely reinvested |  | 112 |  |  | 138 |  |
| Deferred income tax liabilities |  | 1,589 |  |  | 2,498 |  |
| Net deferred income tax liabilities |  | $ | (329) |  |  | $ | (1,481) |  |

[0001730168-20-000226:notes:342]
Deferred income taxes reflect the net effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and their basis for income tax purposes and the tax effects of net operating losses and tax credit carryforwards. The decrease in net deferred income tax liabilities was primarily a result of the amortization of acquisition-related intangible assets included in the consolidated statement of operations.

[0001730168-20-000226:notes:343]
In connection with the Symantec Asset Purchase in November 2019, we established $28 million of net deferred tax assets primarily as a result of the difference in book basis and tax basis related to acquired assets. In connection with the CA Merger in November 2018, we established $2,434 million of net deferred tax liabilities on the excess of the book basis over the tax basis of acquired identified intangible assets and investments in certain foreign subsidiaries that had not been indefinitely reinvested, partially offset by acquired tax attributes.

[0001730168-20-000226:notes:344]
We continue to indefinitely reinvest $2,677 million of certain accumulated foreign earnings. The unrecognized deferred income tax liability related to these earnings is estimated to be $281 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-20-000226:notes:345]
The following table presents net deferred income tax assets (liabilities) as reflected on the consolidated balance sheets:

[0001730168-20-000226:notes:346]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Other long-term assets |  | $ | 240 |  |  | $ | 50 |  |
| Other long-term liabilities |  | (569) |  |  | (1,531) |  |
| Net long-term income tax liabilities |  | $ | (329) |  |  | $ | (1,481) |  |

[0001730168-20-000226:notes:347]
The increase in the valuation allowance to $1,707 million in fiscal year 2020 from $1,563 million in fiscal year 2019 was primarily due to federal and state deferred tax assets arising from credits and net operating loss carryforwards not expected to be realized.

[0001730168-20-000226:notes:348]
As of November 1, 2020, we had U.S. federal net operating loss carryforwards of $67 million, U.S. state net operating loss carryforwards of $2,951 million and other foreign net operating loss carryforwards of $1,126 million. U.S. federal and state net operating loss carryforwards begin to expire in our fiscal year ending October 31, 2021 (“fiscal year 2021”). The other foreign net operating losses expire in various fiscal years beginning 2021. As of November 1, 2020, we had $301 million and $1,759 million of U.S. federal and state research and development tax credits, respectively, which if not utilized, begin to expire in fiscal year 2021.

[0001730168-20-000226:notes:349]
The U.S. Tax Reform Act of 1986 limits the use of net operating loss and tax credit carryforwards in the case of an “ownership change” of a corporation or separate return loss year limitations. Any ownership changes, as defined, may restrict the utilization of carryforwards. As of November 1, 2020, we had approximately $67 million of federal net operating loss carryforwards in the U.S. subject to an annual limitation. We do not expect these limitations to result in any permanent loss of our tax benefits.

[0001730168-20-000226:notes:350]
Uncertain Tax Positions

[0001730168-20-000226:notes:351]
Gross unrecognized tax benefits increased by $326 million during fiscal year 2020, resulting in gross unrecognized tax benefits of $4,748 million as of November 1, 2020.

[0001730168-20-000226:notes:352]
Gross unrecognized tax benefits increased by $392 million during fiscal year 2019, resulting in gross unrecognized tax benefits of $4,422 million as of November 3, 2019.

[0001730168-20-000226:notes:353]
Gross unrecognized tax benefits increased by $1,774 million during fiscal year 2018, resulting in gross unrecognized tax benefits of $4,030 million as of November 4, 2018. The increase in gross unrecognized tax benefits was primarily due to the recognition of unrecognized tax positions of $1,112 million related to the transition tax on the mandatory deemed repatriation of accumulated non-U.S. earnings of U.S. controlled foreign corporations, offset by a reduction of our federal deferred income tax liabilities on accumulated non-U.S. earnings. The increase in gross unrecognized tax benefits was also as a result of our redomiciliation to the United States on April 4, 2018, and to a lesser extent, the Brocade Merger.

[0001730168-20-000226:notes:354]
We recognize interest and penalties related to unrecognized tax benefits within the benefit from income taxes. Accrued interest and penalties were included within other long-term liabilities. During fiscal years 2020 and 2018, we recognized interest and penalties of $37 million and $59 million, respectively, within the benefit from income taxes. There was no amount recognized during fiscal year 2019. As of November 1, 2020 and November 3, 2019, the combined amount of cumulative accrued interest and penalties was approximately $340 million and $303 million, respectively.

[0001730168-20-000226:notes:355]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-20-000226:notes:356]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Beginning balance |  | $ | 4,422 |  |  | $ | 4,030 |  |  | $ | 2,256 |  |
| Lapses of statutes of limitations |  | (95) |  |  | (36) |  |  | (20) |  |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | 98 |  |  | 467 |  |  | 361 |  |
| Decreases in balances related to tax positions taken during prior periods |  | (14) |  |  | (270) |  |  | (289) |  |
| Increases in balances related to tax positions taken during current period |  | 379 |  |  | 460 |  |  | 1,726 |  |
| Decreases in balances related to settlements with taxing authorities |  | (42) |  |  | (229) |  |  | (4) |  |
| Ending balance |  | $ | 4,748 |  |  | $ | 4,422 |  |  | $ | 4,030 |  |

[0001730168-20-000226:notes:357]
A portion of our unrecognized tax benefits will affect our effective tax rate if they are recognized upon favorable resolution of the uncertain tax positions. As of November 1, 2020 and November 3, 2019, approximately $5,088 million and $4,725 million of the unrecognized tax benefits and accrued interest and penalties would affect our effective tax rate, respectively.

[0001730168-20-000226:notes:358]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $261 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-20-000226:notes:359]
Reportable Segments

[0001730168-20-000226:notes:360]
During the first quarter of fiscal year 2020, we updated our organizational structure resulting in two reportable segments: semiconductor solutions and infrastructure software. Each segment represents a component for which separate financial information is available that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-20-000226:notes:361]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, telecom, enterprise and embedded networking applications. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions and custom touch controllers for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-20-000226:notes:362]
Infrastructure software. We provide a portfolio of mainframe, enterprise and storage area networking solutions, which enables customers to leverage the benefits of agility, automation, insights, resiliency and security in managing business processes and technology investments, and to reduce the cost and complexity of managing business information within a shared storage environment. We also offer a cyber security solutions portfolio, including data loss prevention, endpoint protection, and web, email and cloud security solutions.

[0001730168-20-000226:notes:363]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, expenses associated with selling, general and administrative activities, facilities and information technology expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-20-000226:notes:364]
During the fourth quarter of our fiscal year 2020, we refined our allocation methodology for certain selling, general and administrative expenses to more closely align these costs with the segment benefiting from the shared expenses. Prior period segment results have been recast to conform to the current presentation.

[0001730168-20-000226:notes:365]
Unallocated Expenses

[0001730168-20-000226:notes:366]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, charges related to inventory step-up to fair value, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs also include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-20-000226:notes:367]
Depreciation expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-20-000226:notes:368]
|  |  | Fiscal Year |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 17,267 |  |  | $ | 17,441 |  |  | $ | 19,068 |  |
| Infrastructure software |  | 6,621 |  |  | 5,156 |  |  | 1,780 |  |
| Total net revenue |  | $ | 23,888 |  |  | $ | 22,597 |  |  | $ | 20,848 |  |
| Operating income: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 8,576 |  |  | $ | 8,538 |  |  | $ | 9,253 |  |
| Infrastructure software |  | 4,363 |  |  | 3,391 |  |  | 1,157 |  |
| Unallocated expenses |  | (8,925) |  |  | (8,485) |  |  | (5,275) |  |
| Total operating income |  | $ | 4,014 |  |  | $ | 3,444 |  |  | $ | 5,135 |  |

[0001730168-20-000226:notes:369]
Geographic Information

[0001730168-20-000226:notes:370]
Net revenue by country is based on the geographic shipment or delivery location as specified by the distributors, OEMs, contract manufacturers, channel partners, or software customers who purchased our products or services. For the majority of our products, title and control transfer to our customers in Penang, Malaysia. The products are then transported to the customer specific locations. Net revenue from the United States for fiscal years 2020, 2019 and 2018 was $4,778 million, $4,235 million and $2,697 million, respectively. Net revenue from China (including Hong Kong) for fiscal years 2020, 2019 and 2018 was $7,808 million, $8,056 million and $10,305 million, respectively. Net revenue from Singapore for fiscal year 2019 was $2,507 million (amounts were less than 10% for fiscal years 2020 and 2018). Net revenue from other foreign countries for fiscal years 2020, 2019 and 2018 was $11,302 million, $7,799 million and $7,846 million, respectively. These geographic delivery locations are not necessarily indicative of the geographic location of our end customers or the country in which our end customers sell devices containing our products. For example, we believe a substantial portion of our products shipped or delivered to China (including Hong Kong) is included in devices sold by our end customers in the United States and Europe.

[0001730168-20-000226:notes:371]
Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-20-000226:notes:372]
|  |  | November 1,2020 |  | November 3,2019 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,659 |  |  | $ | 1,763 |  |
| Taiwan |  | 285 |  |  | 258 |  |
| Other |  | 565 |  |  | 544 |  |
| Total long-lived assets |  | $ | 2,509 |  |  | $ | 2,565 |  |

[0001730168-20-000226:notes:373]
Significant Customer Information
We sell our products through our direct sales force and a select network of distributors and channel partners globally. No customer accounted for 10% or more of our net accounts receivable balance at November 1, 2020 compared with one customer which accounted for 24% of our net accounts receivable balance at November 3, 2019. During fiscal years 2020 and 2019, one customer accounted for 13% and 17% of our net revenue, respectively. Revenue from this customer was included in our semiconductor solutions segment. During fiscal year 2018, no customer accounted for 10% or more of our net revenue.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-20-000226:notes:374]
Commitments

[0001730168-20-000226:notes:375]
The following table summarizes contractual obligations and commitments as of November 1, 2020:

[0001730168-20-000226:notes:376]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2021 |  | $ | 894 |  |  | $ | 248 |  |
| 2022 |  | 72 |  |  | 221 |  |
| 2023 |  | — |  |  | 209 |  |
| 2024 |  | — |  |  | 157 |  |
| 2025 |  | — |  |  | 63 |  |
| Thereafter |  | — |  |  | 239 |  |
| Total |  | $ | 966 |  |  | $ | 1,137 |  |

[0001730168-20-000226:notes:377]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-20-000226:notes:378]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-20-000226:notes:379]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at November 1, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,185 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities as of November 1, 2020 have been excluded from the contractual obligations table above.

[0001730168-20-000226:notes:380]
Standby Letters of Credit

[0001730168-20-000226:notes:381]
As of November 1, 2020 and November 3, 2019, we had standby letters of credit of $65 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-20-000226:notes:382]
Contingencies

[0001730168-20-000226:notes:383]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant

[0001730168-20-000226:notes:384]
funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-20-000226:notes:385]
Lawsuits Relating to California Institute of Technology

[0001730168-20-000226:notes:386]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit.

[0001730168-20-000226:notes:387]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

[0001730168-20-000226:notes:388]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-20-000226:notes:389]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit

[0001730168-20-000226:notes:390]
Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

[0001730168-20-000226:notes:391]
Other Matters

[0001730168-20-000226:notes:392]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-20-000226:notes:393]
Contingency Assessment

[0001730168-20-000226:notes:394]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-20-000226:notes:395]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our consolidated financial statements.

[0001730168-20-000226:notes:396]
Other Indemnifications

[0001730168-20-000226:notes:397]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-20-000226:notes:398]
Restructuring, Impairment and Disposal Charges 
Restructuring Charges

[0001730168-20-000226:notes:399]
The following is a summary of significant restructuring expense recognized primarily in operating expenses:

[0001730168-20-000226:notes:400]
•During fiscal year 2020, we initiated cost reduction activities associated with the Symantec Asset Purchase. As a result, we recognized $174 million of restructuring expense primarily related to employee termination costs. We have substantially completed the restructuring activities related to the Symantec Asset Purchase.

[0001730168-20-000226:notes:401]
•During fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $28 million and $740 million of restructuring expense primarily related to employee termination and lease and other exit costs during fiscal year 2020 and fiscal year 2019, respectively. We have substantially completed the restructuring activities related to the CA Merger.

[0001730168-20-000226:notes:402]
The following table summarizes the significant activities within, and components of, the restructuring liabilities:

[0001730168-20-000226:notes:403]
|  |  | Employee Termination Costs |  | Lease and Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 29, 2017 |  | $ | 28 |  |  | $ | 17 |  |  | $ | 45 |  |
| Restructuring charges(a) |  | 153 |  |  | 75 |  |  | 228 |  |
| Utilization |  | (165) |  |  | (86) |  |  | (251) |  |
| Balance as of November 4, 2018 |  | 16 |  |  | 6 |  |  | 22 |  |
| Liabilities assumed from CA |  | 29 |  |  | 38 |  |  | 67 |  |
| Restructuring charges |  | 586 |  |  | 160 |  |  | 746 |  |
| Utilization |  | (562) |  |  | (165) |  |  | (727) |  |
| Balance as of November 3, 2019 |  | 69 |  |  | 39 |  |  | 108 |  |
| Restructuring charges(a) |  | 186 |  |  | 47 |  |  | 233 |  |
| Utilization |  | (221) |  |  | (50) |  |  | (271) |  |
| Effect of adoption of Topic 842(b) |  | — |  |  | (36) |  |  | (36) |  |
| Balance as of November 1, 2020(c) |  | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |

[0001730168-20-000226:notes:404]
(a)Included $19 million and $2 million of restructuring expense related to discontinued operations recognized during fiscal years 2020 and 2018, respectively, which was included in loss from discontinued operations.

[0001730168-20-000226:notes:405]
(b)Upon adoption of Topic 842, certain restructuring lease liabilities were required to be recognized as a reduction to the corresponding ROU assets.

[0001730168-20-000226:notes:406]
(c)The majority of the employee termination costs balance is expected to be paid within the first half of fiscal year 2021.

[0001730168-20-000226:notes:407]
Impairment and Disposal Charges
During fiscal years 2020 and 2018, impairment and disposal charges of $19 million and $13 million, respectively, primarily related to leasehold improvements. During fiscal year 2019, impairment and disposal charges of $67 million primarily related to property, plant and equipment.


## us-gaap:SubsequentEventsTextBlock

[0001730168-20-000226:notes:408]
Subsequent Events 
Preferred Stock Cash Dividends Declared

[0001730168-20-000226:notes:409]
On December 8, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on December 31, 2020 to stockholders of record on December 15, 2020.

[0001730168-20-000226:notes:410]
Common Stock Cash Dividends Declared

[0001730168-20-000226:notes:411]
On December 8, 2020, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on December 31, 2020 to stockholders of record on December 21, 2020.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001730168-20-000226:notes:412]
Supplementary Financial Data — Quarterly Data (Unaudited)

[0001730168-20-000226:notes:413]
|  |  | Fiscal Quarter Ended |
|  |  | November 1, 2020 (1) |  | August 2, 2020 (2) |  | May 3, 2020 (3) |  | February 2, 2020 (4) |  | November 3, 2019 (5) |  | August 4, 2019 (6) |  | May 5, 2019 (7) |  | February 3, 2019 (8) |
|  |  | (In millions, except per share data) |
| Total net revenue |  | $ | 6,467 |  |  | $ | 5,821 |  |  | $ | 5,742 |  |  | $ | 5,858 |  |  | $ | 5,776 |  |  | $ | 5,515 |  |  | $ | 5,517 |  |  | $ | 5,789 |  |
| Gross margin |  | 3,747 |  |  | 3,316 |  |  | 3,189 |  |  | 3,264 |  |  | 3,152 |  |  | 3,034 |  |  | 3,089 |  |  | 3,208 |  |
| Operating income |  | 1,526 |  |  | 1,008 |  |  | 766 |  |  | 714 |  |  | 1,054 |  |  | 865 |  |  | 970 |  |  | 555 |  |
| Income from continuing operations |  | 1,324 |  |  | 689 |  |  | 568 |  |  | 380 |  |  | 847 |  |  | 715 |  |  | 693 |  |  | 481 |  |
| Income (loss) from discontinued operations, net of income taxes |  | — |  |  | (1) |  |  | (5) |  |  | 5 |  |  | — |  |  | — |  |  | (2) |  |  | (10) |  |
| Net income |  | 1,324 |  |  | 688 |  |  | 563 |  |  | 385 |  |  | 847 |  |  | 715 |  |  | 691 |  |  | 471 |  |
| Dividends on preferred stock(9) |  | (74) |  |  | (74) |  |  | (75) |  |  | (74) |  |  | (29) |  |  | — |  |  | — |  |  | — |  |
| Net income attributable to common stock |  | $ | 1,250 |  |  | $ | 614 |  |  | $ | 488 |  |  | $ | 311 |  |  | $ | 818 |  |  | $ | 715 |  |  | $ | 691 |  |  | $ | 471 |  |
| Diluted income per share attributable to common stock(10): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.93 |  |  | $ | 1.46 |  |  | $ | 1.18 |  |  | $ | 0.73 |  |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 1.15 |  |
| Income (loss) per share from discontinued operations |  | — |  |  | (0.01) |  |  | (0.01) |  |  | 0.01 |  |  | — |  |  | — |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 2.93 |  |  | $ | 1.45 |  |  | $ | 1.17 |  |  | $ | 0.74 |  |  | $ | 1.97 |  |  | $ | 1.71 |  |  | $ | 1.64 |  |  | $ | 1.12 |  |
| Dividends declared and paid per share to common stockholders |  | $ | 3.25 |  |  | $ | 3.25 |  |  | $ | 3.25 |  |  | $ | 3.25 |  |  | $ | 2.65 |  |  | $ | 2.65 |  |  | $ | 2.65 |  |  | $ | 2.65 |  |
| Dividends declared and paid per share to common stockholders -full year |  | $ | 13.00 |  |  |  |  |  |  |  |  | $ | 10.60 |  |  |  |  |  |  |  |

[0001730168-20-000226:notes:414]
(1)Included amortization of acquisition-related intangible assets of $1,561 million.

[0001730168-20-000226:notes:415]
(2)Included amortization of acquisition-related intangible assets of $1,553 million.

[0001730168-20-000226:notes:416]
(3)Included amortization of acquisition-related intangible assets of $1,553 million.

[0001730168-20-000226:notes:417]
(4)Included the results of Symantec Business beginning with the fiscal quarter ended February 2, 2020 in connection with the Symantec Asset Purchase on November 4, 2019. Also included amortization of acquisition-related intangible assets of $1,553 million.

[0001730168-20-000226:notes:418]
(5)Included amortization of acquisition-related intangible assets of $1,301 million.

[0001730168-20-000226:notes:419]
(6)Included amortization of acquisition-related intangible assets of $1,303 million.

[0001730168-20-000226:notes:420]
(7)Included amortization of acquisition-related intangible assets of $1,299 million.

[0001730168-20-000226:notes:421]
(8)Included amortization of acquisition-related intangible assets of $1,309 million and restructuring, impairment and disposal charges of $629 million.

[0001730168-20-000226:notes:422]
(9)Beginning with the fiscal quarter ended November 3, 2019, net income attributable to common stock excluded dividends on Mandatory Convertible Preferred Stock issued during the fiscal quarter ended November 3, 2019.
(10)The sum of quarterly per share information may not equal annual earnings per share as quarterly earnings per share were computed independently for each period presented.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-20-000226:notes:423]
Schedule II — Valuation and Qualifying Accounts

[0001730168-20-000226:notes:424]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (1) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 1, 2020 |  | $ | 153 |  |  | $ | 696 |  |  | $ | (700) |  |  | $ | 149 |  |
| Fiscal year ended November 3, 2019 |  | $ | 151 |  |  | $ | 705 |  |  | $ | (703) |  |  | $ | 153 |  |
| Fiscal year ended November 4, 2018 |  | $ | 177 |  |  | $ | 882 |  |  | $ | (908) |  |  | $ | 151 |  |
| Other accounts receivable allowances (2) |  |  |  |  |  |  |  |  |
| Fiscal year ended November 1, 2020 |  | $ | 38 |  |  | $ | 84 |  |  | $ | (94) |  |  | $ | 28 |  |
| Fiscal year ended November 3, 2019 |  | $ | 12 |  |  | $ | 99 |  |  | $ | (73) |  |  | $ | 38 |  |
| Fiscal year ended November 4, 2018 |  | $ | 31 |  |  | $ | 116 |  |  | $ | (135) |  |  | $ | 12 |  |
| Income tax valuation allowances: |  |  |  |  |  |  |  |  |
| Fiscal year ended November 1, 2020 |  | $ | 1,563 |  |  | $ | 149 |  |  | $ | (5) |  |  | $ | 1,707 |  |
| Fiscal year ended November 3, 2019 |  | $ | 1,347 |  |  | $ | 284 |  |  | $ | (68) |  |  | $ | 1,563 |  |
| Fiscal year ended November 4, 2018 |  | $ | 1,447 |  |  | $ | 314 |  |  | $ | (414) |  |  | $ | 1,347 |  |

[0001730168-20-000226:notes:425]
_______________________________________

[0001730168-20-000226:notes:426]
(1)Distributor credit allowances relate to price adjustments and other allowances.

[0001730168-20-000226:notes:427]
(2)Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts.
