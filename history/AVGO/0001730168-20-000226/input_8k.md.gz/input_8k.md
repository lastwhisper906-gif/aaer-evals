# AVGO 8-K — 0001730168-20-000201 filed 2020-12-10

## item codes, every 8-K on or before 2020-12-18

- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2020-12-18

- none on or before 2020-12-18

## item 2.02 — earnings release, exhibit 99.1

[0001730168-20-000201:8k_2_02:1]
EX-99.1
2
avgo-11012020x8kxex99.htm
EX-99.1

[0001730168-20-000201:8k_2_02:2]
Document

[0001730168-20-000201:8k_2_02:3]
Exhibit 99.1

[0001730168-20-000201:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2020 Financial Results and Quarterly Dividends

[0001730168-20-000201:8k_2_02:5]
•Revenue of $6,467 million for the fourth quarter, up 12 percent from the prior year period

[0001730168-20-000201:8k_2_02:6]
•GAAP net income of $1,324 million for the fourth quarter; Adjusted EBITDA of $3,827 million for the fourth quarter

[0001730168-20-000201:8k_2_02:7]
•GAAP diluted EPS of $2.93 for the fourth quarter; Non-GAAP diluted EPS of $6.35 for the fourth quarter

[0001730168-20-000201:8k_2_02:8]
•$3,246 million of free cash flow from operations for the fourth quarter, defined as cash from operations of $3,348 million less capital expenditures of $102 million

[0001730168-20-000201:8k_2_02:9]
•Quarterly common stock dividend increased by 11 percent to $3.60 per share from the prior quarter

[0001730168-20-000201:8k_2_02:10]
•First quarter revenue guidance of approximately $6.6 billion, an expected increase of 13 percent from the prior year period

[0001730168-20-000201:8k_2_02:11]
•First quarter Adjusted EBITDA guidance of approximately $3.9 billion, or 59 percent of projected revenue 1

[0001730168-20-000201:8k_2_02:12]
SAN JOSE, Calif. – December 10, 2020 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year ended November 1, 2020, provided guidance for the first quarter of its fiscal year 2021 and announced its quarterly dividends.

[0001730168-20-000201:8k_2_02:13]
“We concluded the year with strong fourth quarter results driven by continued demand for networking  from cloud and for broadband from service providers as well as the significant ramp in wireless, even as enterprise demand remained soft. Our infrastructure software segment continued to be stable and delivered solid results,” said Hock Tan, President and CEO of Broadcom Inc. “Our first quarter revenue outlook, which projects continued overall strength, is expected to show 13 percent year over year growth, all organic.”

[0001730168-20-000201:8k_2_02:14]
“Despite the challenges presented by the ongoing pandemic and macroeconomic uncertainties, we achieved record profitability, generating $11.6 billion of free cash flow in fiscal 2020,” said Tom Krause, CFO of Broadcom Inc. “As a result, we are raising our target common stock dividend by 11 percent to $3.60 per share per quarter for fiscal year 2021.”

[0001730168-20-000201:8k_2_02:15]
________________________________

[0001730168-20-000201:8k_2_02:16]
1 The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-20-000201:8k_2_02:17]
1

[0001730168-20-000201:8k_2_02:18]
Fourth Quarter Fiscal Year 2020 Financial Highlights

[0001730168-20-000201:8k_2_02:19]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 20 |  | Q4 19 |  | Change |  | Q4 20 |  | Q4 19 |  | Change |
| Net revenue |  | $ | 6,467 |  |  | $ | 5,776 |  |  | +12 | % |  | $ | 6,467 |  |  | $ | 5,776 |  |  | +12 | % |
| Net income |  | $ | 1,324 |  |  | $ | 847 |  |  | +$477 |  |  | $ | 2,865 |  |  | $ | 2,391 |  |  | +$474 |  |
| Earnings per common share - diluted |  | $ | 2.93 |  |  | $ | 1.97 |  |  | +$0.96 |  |  | $ | 6.35 |  |  | $ | 5.39 |  |  | +$0.96 |  |

[0001730168-20-000201:8k_2_02:20]
| (Dollars in millions) |  | Q4 20 |  | Q4 19 |  | Change |  |
| Cash flow from operations |  | $ | 3,348 |  |  | $ | 2,479 |  |  | +$869 |  |
| Adjusted EBITDA |  | $ | 3,827 |  |  | $ | 3,165 |  |  | +$662 |  |
| Free cash flow |  | $ | 3,246 |  |  | $ | 2,383 |  |  | +$863 |  |

[0001730168-20-000201:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 20 |  |  |  | Q4 19 |  | Change |  |
| Semiconductor solutions |  | $ | 4,830 |  |  | 75 | % |  |  |  |  |  |  | $ | 4,576 |  |  | 79 | % |  | +6 | % |  |
| Infrastructure software |  | 1,637 |  |  | 25 |  |  |  |  |  |  |  | 1,200 |  |  | 21 |  |  | +36 | % |  |
| Total net revenue |  | $ | 6,467 |  |  | 100 | % |  |  |  |  |  |  | $ | 5,776 |  |  | 100 | % |  |  |  |  |

[0001730168-20-000201:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fourth fiscal quarter were $7,618 million, compared to $8,857 million at the end of the prior quarter.

[0001730168-20-000201:8k_2_02:23]
During the fourth fiscal quarter, the Company generated $3,348 million in cash from operations and spent $102 million on capital expenditures.

[0001730168-20-000201:8k_2_02:24]
On September 30, 2020, the Company paid a cash dividend of $3.25 per share of common stock, totaling $1,320 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-20-000201:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-20-000201:8k_2_02:26]
Fiscal Year 2020 Financial Highlights

[0001730168-20-000201:8k_2_02:27]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net revenue |  | $ | 23,888 |  |  | $ | 22,597 |  |  | +6 | % |  | $ | 23,888 |  |  | $ | 22,597 |  |  | +6 | % |
| Net income |  | $ | 2,960 |  |  | $ | 2,724 |  |  | +$236 |  |  | $ | 9,993 |  |  | $ | 9,452 |  |  | +$541 |  |
| Earnings per common share - diluted |  | $ | 6.33 |  |  | $ | 6.43 |  |  | -$0.10 |  |  | $ | 22.16 |  |  | $ | 21.29 |  |  | +$0.87 |  |

[0001730168-20-000201:8k_2_02:28]
| (Dollars in millions) |  | 2020 |  | 2019 |  | Change |  |
| Cash flow from operations |  | $ | 12,061 |  |  | $ | 9,697 |  |  | +$2,364 |  |
| Adjusted EBITDA |  | $ | 13,643 |  |  | $ | 12,579 |  |  | +$1,064 |  |
| Free cash flow |  | $ | 11,598 |  |  | $ | 9,265 |  |  | +$2,333 |  |

[0001730168-20-000201:8k_2_02:29]
2

[0001730168-20-000201:8k_2_02:30]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | 2020 |  | 2019 |  | Change |  |
| Semiconductor solutions |  | $ | 17,267 |  |  | 72 | % |  | $ | 17,441 |  |  | 77 | % |  | -1 | % |  |
| Infrastructure software |  | 6,621 |  |  | 28 |  |  | 5,156 |  |  | 23 |  |  | +28 | % |  |
| Total net revenue |  | $ | 23,888 |  |  | 100 | % |  | $ | 22,597 |  |  | 100 | % |  |  |  |  |

[0001730168-20-000201:8k_2_02:31]
First Quarter Fiscal Year 2021 Business Outlook

[0001730168-20-000201:8k_2_02:32]
Based on current business trends and conditions, the outlook for the first quarter of fiscal year 2021, ending January 31, 2021, is expected to be as follows:

[0001730168-20-000201:8k_2_02:33]
•First quarter revenue guidance of approximately $6.6 billion; and

[0001730168-20-000201:8k_2_02:34]
•First quarter Adjusted EBITDA of approximately $3.9 billion, or 59 percent of projected revenue.

[0001730168-20-000201:8k_2_02:35]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000201:8k_2_02:36]
Broadcom Inc. will be presenting to investors at the J.P. Morgan Tech Forum on January 12, 2021.

[0001730168-20-000201:8k_2_02:37]
Quarterly Dividends

[0001730168-20-000201:8k_2_02:38]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.60 per share. The common stock dividend is payable on December 31, 2020 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 21, 2020.

[0001730168-20-000201:8k_2_02:39]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on December 31, 2020 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 15, 2020.

[0001730168-20-000201:8k_2_02:40]
Financial Results Conference Call

[0001730168-20-000201:8k_2_02:41]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter and fiscal year ended November 1, 2020, and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 5074985. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 5074985. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001730168-20-000201:8k_2_02:42]
Basis of Presentation

[0001730168-20-000201:8k_2_02:43]
The Company’s financial results include contributions from the Symantec enterprise security business’s continuing operations starting in the first quarter of fiscal year 2020. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented above, unless otherwise stated.

[0001730168-20-000201:8k_2_02:44]
Non-GAAP Financial Measures

[0001730168-20-000201:8k_2_02:45]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gain from lapse of indemnification, gains (losses) on investments, gain from sale of business, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-20-000201:8k_2_02:46]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-20-000201:8k_2_02:47]
Broadcom believes this non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release.

[0001730168-20-000201:8k_2_02:48]
About Broadcom Inc.

[0001730168-20-000201:8k_2_02:49]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions

[0001730168-20-000201:8k_2_02:50]
4

[0001730168-20-000201:8k_2_02:51]
include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to www.broadcom.com.

[0001730168-20-000201:8k_2_02:52]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-20-000201:8k_2_02:53]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has, and will likely continue to, negatively impact the global economy and disrupt normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; global political and economic conditions; government regulations, trade restrictions and trade tensions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our

[0001730168-20-000201:8k_2_02:54]
5

[0001730168-20-000201:8k_2_02:55]
ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-20-000201:8k_2_02:56]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000201:8k_2_02:57]
Contact:

[0001730168-20-000201:8k_2_02:58]
Broadcom Inc.

[0001730168-20-000201:8k_2_02:59]
Beatrice F. Russotto

[0001730168-20-000201:8k_2_02:60]
Investor Relations

[0001730168-20-000201:8k_2_02:61]
408-433-8000

[0001730168-20-000201:8k_2_02:62]
investor.relations@broadcom.com

[0001730168-20-000201:8k_2_02:63]
6

[0001730168-20-000201:8k_2_02:64]
BROADCOM INC.

[0001730168-20-000201:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-20-000201:8k_2_02:66]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-20-000201:8k_2_02:67]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 1,2020 |  | August 2,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
| Net revenue |  | $ | 6,467 |  |  | $ | 5,821 |  |  | $ | 5,776 |  |  | $ | 23,888 |  |  | $ | 22,597 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,753 |  |  | 1,537 |  |  | 1,788 |  |  | 6,518 |  |  | 6,723 |  |
| Amortization of acquisition-related intangible assets |  | 962 |  |  | 953 |  |  | 827 |  |  | 3,819 |  |  | 3,314 |  |
| Restructuring charges |  | 5 |  |  | 15 |  |  | 9 |  |  | 35 |  |  | 77 |  |
| Total cost of revenue |  | 2,720 |  |  | 2,505 |  |  | 2,624 |  |  | 10,372 |  |  | 10,114 |  |
| Gross margin |  | 3,747 |  |  | 3,316 |  |  | 3,152 |  |  | 13,516 |  |  | 12,483 |  |
| Research and development |  | 1,182 |  |  | 1,228 |  |  | 1,177 |  |  | 4,968 |  |  | 4,696 |  |
| Selling, general and administrative |  | 405 |  |  | 428 |  |  | 409 |  |  | 1,935 |  |  | 1,709 |  |
| Amortization of acquisition-related intangible assets |  | 599 |  |  | 600 |  |  | 474 |  |  | 2,401 |  |  | 1,898 |  |
| Restructuring, impairment and disposal charges |  | 35 |  |  | 52 |  |  | 38 |  |  | 198 |  |  | 736 |  |
| Total operating expenses |  | 2,221 |  |  | 2,308 |  |  | 2,098 |  |  | 9,502 |  |  | 9,039 |  |
| Operating income |  | 1,526 |  |  | 1,008 |  |  | 1,054 |  |  | 4,014 |  |  | 3,444 |  |
| Interest expense |  | (420) |  |  | (464) |  |  | (361) |  |  | (1,777) |  |  | (1,444) |  |
| Other income, net |  | 31 |  |  | 49 |  |  | 54 |  |  | 206 |  |  | 226 |  |
| Income from continuing operations before income taxes |  | 1,137 |  |  | 593 |  |  | 747 |  |  | 2,443 |  |  | 2,226 |  |
| Benefit from income taxes |  | (187) |  |  | (96) |  |  | (100) |  |  | (518) |  |  | (510) |  |
| Income from continuing operations |  | 1,324 |  |  | 689 |  |  | 847 |  |  | 2,961 |  |  | 2,736 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | (1) |  |  | — |  |  | (1) |  |  | (12) |  |
| Net income |  | 1,324 |  |  | 688 |  |  | 847 |  |  | 2,960 |  |  | 2,724 |  |
| Dividends on preferred stock |  | (74) |  |  | (74) |  |  | (29) |  |  | (297) |  |  | (29) |  |
| Net income attributable to common stock |  | $ | 1,250 |  |  | $ | 614 |  |  | $ | 818 |  |  | $ | 2,663 |  |  | $ | 2,695 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 3.09 |  |  | $ | 1.53 |  |  | $ | 2.06 |  |  | $ | 6.62 |  |  | $ | 6.80 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 3.09 |  |  | $ | 1.52 |  |  | $ | 2.06 |  |  | $ | 6.62 |  |  | $ | 6.77 |  |
| Diluted income per share attributable to common stock (1): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.93 |  |  | $ | 1.46 |  |  | $ | 1.97 |  |  | $ | 6.33 |  |  | $ | 6.46 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 2.93 |  |  | $ | 1.45 |  |  | $ | 1.97 |  |  | $ | 6.33 |  |  | $ | 6.43 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 405 |  |  | 403 |  |  | 397 |  |  | 402 |  |  | 398 |  |
| Diluted |  | 426 |  |  | 422 |  |  | 416 |  |  | 421 |  |  | 419 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 38 |  |  | $ | 37 |  |  | $ | 41 |  |  | $ | 159 |  |  | $ | 163 |  |
| Research and development |  | 318 |  |  | 337 |  |  | 394 |  |  | 1,419 |  |  | 1,532 |  |
| Selling, general and administrative |  | 93 |  |  | 91 |  |  | 109 |  |  | 398 |  |  | 490 |  |
| Total stock-based compensation expense |  | $ | 449 |  |  | $ | 465 |  |  | $ | 544 |  |  | $ | 1,976 |  |  | $ | 2,185 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-20-000201:8k_2_02:68]
BROADCOM INC.

[0001730168-20-000201:8k_2_02:69]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-20-000201:8k_2_02:70]
(IN MILLIONS)

[0001730168-20-000201:8k_2_02:71]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 1,2020 |  | August 2,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
| Gross margin on GAAP basis |  | $ | 3,747 |  |  | $ | 3,316 |  |  | $ | 3,152 |  |  | $ | 13,516 |  |  | $ | 12,483 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 962 |  |  | 953 |  |  | 827 |  |  | 3,819 |  |  | 3,314 |  |
| Stock-based compensation expense |  | 38 |  |  | 37 |  |  | 41 |  |  | 159 |  |  | 163 |  |
| Restructuring charges |  | 5 |  |  | 15 |  |  | 9 |  |  | 35 |  |  | 77 |  |
| Acquisition-related costs |  | 6 |  |  | — |  |  | 6 |  |  | 12 |  |  | 18 |  |
| Gross margin on non-GAAP basis |  | $ | 4,758 |  |  | $ | 4,321 |  |  | $ | 4,035 |  |  | $ | 17,552 |  |  | $ | 16,055 |  |
| Research and development on GAAP basis |  | $ | 1,182 |  |  | $ | 1,228 |  |  | $ | 1,177 |  |  | $ | 4,968 |  |  | $ | 4,696 |  |
| Stock-based compensation expense |  | 318 |  |  | 337 |  |  | 394 |  |  | 1,419 |  |  | 1,532 |  |
| Acquisition-related costs |  | 1 |  |  | 1 |  |  | 1 |  |  | 14 |  |  | 5 |  |
| Research and development on non-GAAP basis |  | $ | 863 |  |  | $ | 890 |  |  | $ | 782 |  |  | $ | 3,535 |  |  | $ | 3,159 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 405 |  |  | $ | 428 |  |  | $ | 409 |  |  | $ | 1,935 |  |  | $ | 1,709 |  |
| Stock-based compensation expense |  | 93 |  |  | 91 |  |  | 109 |  |  | 398 |  |  | 490 |  |
| Acquisition-related costs |  | 60 |  |  | 66 |  |  | 65 |  |  | 396 |  |  | 252 |  |
| Litigation settlements |  | — |  |  | 21 |  |  | — |  |  | 63 |  |  | — |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 252 |  |  | $ | 250 |  |  | $ | 235 |  |  | $ | 1,078 |  |  | $ | 967 |  |
| Total operating expenses on GAAP basis |  | $ | 2,221 |  |  | $ | 2,308 |  |  | $ | 2,098 |  |  | $ | 9,502 |  |  | $ | 9,039 |  |
| Amortization of acquisition-related intangible assets |  | 599 |  |  | 600 |  |  | 474 |  |  | 2,401 |  |  | 1,898 |  |
| Stock-based compensation expense |  | 411 |  |  | 428 |  |  | 503 |  |  | 1,817 |  |  | 2,022 |  |
| Restructuring, impairment and disposal charges |  | 35 |  |  | 52 |  |  | 38 |  |  | 198 |  |  | 736 |  |
| Litigation settlements |  | — |  |  | 21 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 61 |  |  | 67 |  |  | 66 |  |  | 410 |  |  | 257 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,115 |  |  | $ | 1,140 |  |  | $ | 1,017 |  |  | $ | 4,613 |  |  | $ | 4,126 |  |
| Operating income on GAAP basis |  | $ | 1,526 |  |  | $ | 1,008 |  |  | $ | 1,054 |  |  | $ | 4,014 |  |  | $ | 3,444 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,561 |  |  | 1,553 |  |  | 1,301 |  |  | 6,220 |  |  | 5,212 |  |
| Stock-based compensation expense |  | 449 |  |  | 465 |  |  | 544 |  |  | 1,976 |  |  | 2,185 |  |
| Restructuring, impairment and disposal charges |  | 40 |  |  | 67 |  |  | 47 |  |  | 233 |  |  | 813 |  |
| Litigation settlements |  | — |  |  | 21 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 67 |  |  | 67 |  |  | 72 |  |  | 422 |  |  | 275 |  |
| Operating income on non-GAAP basis |  | $ | 3,643 |  |  | $ | 3,181 |  |  | $ | 3,018 |  |  | $ | 12,939 |  |  | $ | 11,929 |  |
| Interest expense on GAAP basis |  | $ | (420) |  |  | $ | (464) |  |  | $ | (361) |  |  | $ | (1,777) |  |  | $ | (1,444) |  |
| Loss on debt extinguishment |  | 16 |  |  | 55 |  |  | 26 |  |  | 169 |  |  | 54 |  |
| Interest expense on non-GAAP basis |  | $ | (404) |  |  | $ | (409) |  |  | $ | (335) |  |  | $ | (1,608) |  |  | $ | (1,390) |  |
| Other income, net on GAAP basis |  | $ | 31 |  |  | $ | 49 |  |  | $ | 54 |  |  | $ | 206 |  |  | $ | 226 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | (116) |  |  | — |  |
| Gains on investments |  | (10) |  |  | (31) |  |  | (50) |  |  | (31) |  |  | (145) |  |
| Gain from sale of business |  | — |  |  | (23) |  |  | — |  |  | (23) |  |  | — |  |
| Acquisition-related gain |  | (4) |  |  | — |  |  | — |  |  | (11) |  |  | — |  |
| Other income (loss), net on non-GAAP basis |  | $ | 17 |  |  | $ | (5) |  |  | $ | 4 |  |  | $ | 25 |  |  | $ | 81 |  |

[0001730168-20-000201:8k_2_02:72]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 1,2020 |  | August 2,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
| Benefit from income taxes on GAAP basis |  | $ | (187) |  |  | $ | (96) |  |  | $ | (100) |  |  | $ | (518) |  |  | $ | (510) |  |
| Non-GAAP tax reconciling adjustments |  | 578 |  |  | 428 |  |  | 396 |  |  | 1,881 |  |  | 1,678 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 391 |  |  | $ | 332 |  |  | $ | 296 |  |  | $ | 1,363 |  |  | $ | 1,168 |  |
| Net income on GAAP basis |  | $ | 1,324 |  |  | $ | 688 |  |  | $ | 847 |  |  | $ | 2,960 |  |  | $ | 2,724 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,561 |  |  | 1,553 |  |  | 1,301 |  |  | 6,220 |  |  | 5,212 |  |
| Stock-based compensation expense |  | 449 |  |  | 465 |  |  | 544 |  |  | 1,976 |  |  | 2,185 |  |
| Restructuring, impairment and disposal charges |  | 40 |  |  | 67 |  |  | 47 |  |  | 233 |  |  | 813 |  |
| Litigation settlements |  | — |  |  | 21 |  |  | — |  |  | 63 |  |  | — |  |
| Acquisition-related costs |  | 63 |  |  | 67 |  |  | 72 |  |  | 411 |  |  | 275 |  |
| Loss on debt extinguishment |  | 16 |  |  | 55 |  |  | 26 |  |  | 169 |  |  | 54 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | (116) |  |  | — |  |
| Gains on investments |  | (10) |  |  | (31) |  |  | (50) |  |  | (31) |  |  | (145) |  |
| Gain from sale of business |  | — |  |  | (23) |  |  | — |  |  | (23) |  |  | — |  |
| Non-GAAP tax reconciling adjustments |  | (578) |  |  | (428) |  |  | (396) |  |  | (1,881) |  |  | (1,678) |  |
| Discontinued operations, net of income taxes |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 12 |  |
| Net income on non-GAAP basis |  | $ | 2,865 |  |  | $ | 2,435 |  |  | $ | 2,391 |  |  | $ | 9,993 |  |  | $ | 9,452 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 426 |  |  | 422 |  |  | 416 |  |  | 421 |  |  | 419 |  |
| Non-GAAP adjustment (1) |  | 25 |  |  | 29 |  |  | 28 |  |  | 30 |  |  | 25 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 451 |  |  | 451 |  |  | 444 |  |  | 451 |  |  | 444 |  |
| Net income on non-GAAP basis |  | $ | 2,865 |  |  | $ | 2,435 |  |  | $ | 2,391 |  |  | $ | 9,993 |  |  | $ | 9,452 |  |
| Interest expense on non-GAAP basis |  | 404 |  |  | 409 |  |  | 335 |  |  | 1,608 |  |  | 1,390 |  |
| Provision for income taxes on non-GAAP basis |  | 391 |  |  | 332 |  |  | 296 |  |  | 1,363 |  |  | 1,168 |  |
| Depreciation |  | 139 |  |  | 138 |  |  | 143 |  |  | 570 |  |  | 569 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 28 |  |  | 28 |  |  | — |  |  | 109 |  |  | — |  |
| Adjusted EBITDA |  | $ | 3,827 |  |  | $ | 3,342 |  |  | $ | 3,165 |  |  | $ | 13,643 |  |  | $ | 12,579 |  |
| Net cash provided by operating activities |  | $ | 3,348 |  |  | $ | 3,178 |  |  | $ | 2,479 |  |  | $ | 12,061 |  |  | $ | 9,697 |  |
| Purchases of property, plant and equipment |  | (102) |  |  | (105) |  |  | (96) |  |  | (463) |  |  | (432) |  |
| Free cash flow |  | $ | 3,246 |  |  | $ | 3,073 |  |  | $ | 2,383 |  |  | $ | 11,598 |  |  | $ | 9,265 |  |

[0001730168-20-000201:8k_2_02:73]
|  |  | Fiscal Quarter Ending |
|  |  | January 31, |
| Expected average diluted share count: |  | 2021 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 427 |  |
| Non-GAAP adjustment (1) |  | 23 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 450 |  |

[0001730168-20-000201:8k_2_02:74]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the periods presented, the non-GAAP adjustment included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. For the fiscal quarter ending January 31, 2021, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |

[0001730168-20-000201:8k_2_02:75]
BROADCOM INC.

[0001730168-20-000201:8k_2_02:76]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-20-000201:8k_2_02:77]
(IN MILLIONS)

[0001730168-20-000201:8k_2_02:78]
|  |  | November 1,2020 |  | November 3,2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 7,618 |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  | 2,297 |  |  | 3,259 |  |
| Inventory |  | 1,003 |  |  | 874 |  |
| Other current assets |  | 977 |  |  | 729 |  |
| Total current assets |  | 11,895 |  |  | 9,917 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,509 |  |  | 2,565 |  |
| Goodwill |  | 43,447 |  |  | 36,714 |  |
| Intangible assets, net |  | 16,782 |  |  | 17,554 |  |
| Other long-term assets |  | 1,300 |  |  | 743 |  |
| Total assets |  | $ | 75,933 |  |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 836 |  |  | $ | 855 |  |
| Employee compensation and benefits |  | 877 |  |  | 641 |  |
| Current portion of long-term debt |  | 827 |  |  | 2,787 |  |
| Other current liabilities |  | 3,831 |  |  | 2,616 |  |
| Total current liabilities |  | 6,371 |  |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 40,235 |  |  | 30,011 |  |
| Other long-term liabilities |  | 5,426 |  |  | 5,613 |  |
| Total liabilities |  | 52,032 |  |  | 42,523 |  |
| Preferred stock dividend obligation |  | 27 |  |  | 29 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 23,982 |  |  | 25,081 |  |
| Retained earnings |  | — |  |  | — |  |
| Accumulated other comprehensive loss |  | (108) |  |  | (140) |  |
| Total stockholders' equity |  | 23,874 |  |  | 24,941 |  |
| Total liabilities and equity |  | $ | 75,933 |  |  | $ | 67,493 |  |

[0001730168-20-000201:8k_2_02:79]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | November 1,2020 |  | August 2,2020 |  | November 3,2019 |  | November 1,2020 |  | November 3,2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,324 |  |  | $ | 688 |  |  | $ | 847 |  |  | $ | 2,960 |  |  | $ | 2,724 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,589 |  |  | 1,581 |  |  | 1,309 |  |  | 6,335 |  |  | 5,239 |  |
| Depreciation |  | 139 |  |  | 138 |  |  | 143 |  |  | 570 |  |  | 569 |  |
| Stock-based compensation |  | 449 |  |  | 465 |  |  | 544 |  |  | 1,976 |  |  | 2,185 |  |
| Deferred taxes and other non-cash taxes |  | (459) |  |  | (436) |  |  | (226) |  |  | (1,142) |  |  | (934) |  |
| Loss on debt extinguishment included in interest expense |  | 16 |  |  | 55 |  |  | 26 |  |  | 169 |  |  | 28 |  |
| Non-cash restructuring, impairment and disposal charges |  | 12 |  |  | 15 |  |  | 20 |  |  | 44 |  |  | 133 |  |
| Non-cash interest expense |  | 25 |  |  | 22 |  |  | 19 |  |  | 108 |  |  | 69 |  |
| Other |  | (9) |  |  | (54) |  |  | (49) |  |  | (52) |  |  | (132) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 391 |  |  | 542 |  |  | 285 |  |  | 981 |  |  | 486 |  |
| Inventory |  | 67 |  |  | (128) |  |  | 217 |  |  | (31) |  |  | 250 |  |
| Accounts payable |  | (230) |  |  | (123) |  |  | (147) |  |  | (3) |  |  | (42) |  |
| Employee compensation and benefits |  | 142 |  |  | 231 |  |  | 66 |  |  | 217 |  |  | (294) |  |
| Other current assets and current liabilities |  | (131) |  |  | (2) |  |  | (398) |  |  | 331 |  |  | (283) |  |
| Other long-term assets and long-term liabilities |  | 23 |  |  | 184 |  |  | (177) |  |  | (402) |  |  | (301) |  |
| Net cash provided by operating activities |  | 3,348 |  |  | 3,178 |  |  | 2,479 |  |  | 12,061 |  |  | 9,697 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (2) |  |  | — |  |  | (10,872) |  |  | (16,033) |  |
| Proceeds from sales of businesses |  | — |  |  | 50 |  |  | — |  |  | 218 |  |  | 957 |  |
| Purchases of property, plant and equipment |  | (102) |  |  | (105) |  |  | (96) |  |  | (463) |  |  | (432) |  |
| Proceeds from disposals of property, plant and equipment |  | 2 |  |  | 10 |  |  | 6 |  |  | 12 |  |  | 88 |  |
| Other |  | — |  |  | 1 |  |  | 2 |  |  | (4) |  |  | (2) |  |
| Net cash used in investing activities |  | (100) |  |  | (46) |  |  | (88) |  |  | (11,109) |  |  | (15,422) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | 7,953 |  |  | — |  |  | 27,802 |  |  | 28,793 |  |
| Repayment of debt |  | (3,000) |  |  | (6,825) |  |  | (4,800) |  |  | (18,814) |  |  | (16,800) |  |
| Other borrowings, net |  | — |  |  | (3,028) |  |  | (104) |  |  | (1,285) |  |  | 1,241 |  |
| Payment of dividends |  | (1,395) |  |  | (1,386) |  |  | (1,054) |  |  | (5,534) |  |  | (4,235) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | — |  |  | (433) |  |  | — |  |  | (5,435) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (185) |  |  | (192) |  |  | (154) |  |  | (765) |  |  | (972) |  |
| Issuance of preferred stock, net |  | — |  |  | — |  |  | 3,679 |  |  | — |  |  | 3,679 |  |
| Issuance of common stock |  | 102 |  |  | 46 |  |  | 59 |  |  | 276 |  |  | 253 |  |
| Other |  | (9) |  |  | (50) |  |  | 9 |  |  | (69) |  |  | (36) |  |
| Net cash provided by (used in) financing activities |  | (4,487) |  |  | (3,482) |  |  | (2,798) |  |  | 1,611 |  |  | 6,488 |  |
| Net change in cash and cash equivalents |  | (1,239) |  |  | (350) |  |  | (407) |  |  | 2,563 |  |  | 763 |  |
| Cash and cash equivalents at beginning of period |  | 8,857 |  |  | 9,207 |  |  | 5,462 |  |  | 5,055 |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 7,618 |  |  | $ | 8,857 |  |  | $ | 5,055 |  |  | $ | 7,618 |  |  | $ | 5,055 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 383 |  |  | $ | 269 |  |  | $ | 307 |  |  | $ | 1,408 |  |  | $ | 1,287 |  |
| Cash paid for income taxes |  | $ | 202 |  |  | $ | 44 |  |  | $ | 123 |  |  | $ | 501 |  |  | $ | 741 |  |
