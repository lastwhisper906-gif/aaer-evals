# AVGO note change history — 0001730168-20-000109 → 0001730168-20-000164


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:1]
The following table summarizes contractual obligations and commitments as of August 2, 2020 that materially changed from the end of fiscal year 2019:
  (was, 2020-06-12, similarity 0.9751):
[0001730168-20-000109:note_history:1]
The following table summarizes contractual obligations and commitments as of May 3, 2020 that materially changed from the end of fiscal year 2019:

- changed (2020-09-11):
[0001730168-20-000164:note_history:2]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended August 2, 2020.
  (was, 2020-06-12, similarity 0.9833):
[0001730168-20-000109:note_history:2]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 3, 2020.

- changed (2020-09-11):
[0001730168-20-000164:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,307 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 2, 2020 have been excluded from the contractual obligations table above.
  (was, 2020-06-12, similarity 0.9816):
[0001730168-20-000109:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 3, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,300 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 3, 2020 have been excluded from the contractual obligations table above.

- added (2020-09-11):
[0001730168-20-000164:note_history:4]
As of August 2, 2020 and November 3, 2019, we had standby letters of credit of $63 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- added (2020-09-11):
[0001730168-20-000164:note_history:5]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- changed (2020-09-11):
[0001730168-20-000164:note_history:6]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgement interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgement, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgement interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.
  (was, 2020-06-12, similarity 0.6947):
[0001730168-20-000109:note_history:6]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties have filed post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

- added (2020-09-11):
[0001730168-20-000164:note_history:7]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgement and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

- changed (2020-09-11):
[0001730168-20-000164:note_history:8]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and
  (was, 2020-06-12, similarity 0.8589):
[0001730168-20-000109:note_history:8]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice

- changed (2020-09-11):
[0001730168-20-000164:note_history:9]
approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.
  (was, 2020-06-12, similarity 0.9081):
[0001730168-20-000109:note_history:9]
on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

- changed (2020-09-11):
[0001730168-20-000164:note_history:10]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgement for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.
  (was, 2020-06-12, similarity 0.9996):
[0001730168-20-000109:note_history:10]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.

- removed (2020-09-11):
[0001730168-20-000109:note_history:11]
As of May 3, 2020 and November 3, 2019, we had standby letters of credit of $57 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- removed (2020-09-11):
[0001730168-20-000109:note_history:12]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- removed (2020-09-11):
[0001730168-20-000109:note_history:13]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:14]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing on the acquisition date.
  (was, 2020-06-12, similarity 0.9912):
[0001730168-20-000109:note_history:14]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash (the “Symantec Asset Purchase”). The results of operations of the Symantec Business are included in the unaudited condensed consolidated financial statements commencing as of the acquisition date.

- changed (2020-09-11):
[0001730168-20-000164:note_history:15]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ended on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.
  (was, 2020-06-12, similarity 0.9964):
[0001730168-20-000109:note_history:15]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

- changed (2020-09-11):
[0001730168-20-000164:note_history:16]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.
  (was, 2020-06-12, similarity 0.9928):
[0001730168-20-000109:note_history:16]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 3, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

- changed (2020-09-11):
[0001730168-20-000164:note_history:17]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgement and carry a higher degree of variability and volatility, and may change materially in future periods.
  (was, 2020-06-12, similarity 0.9917):
[0001730168-20-000109:note_history:17]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

- changed (2020-09-11):
[0001730168-20-000164:note_history:18]
Recent Accounting Guidance
  (was, 2020-06-12, similarity 0.8387):
[0001730168-20-000109:note_history:18]
Recently Adopted Accounting Guidance

- added (2020-09-11):
[0001730168-20-000164:note_history:19]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for 
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. This guidance had no impact on our contracts as of August 2, 2020.

- removed (2020-09-11):
[0001730168-20-000109:note_history:20]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for

- removed (2020-09-11):
[0001730168-20-000109:note_history:21]
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.

- removed (2020-09-11):
[0001730168-20-000109:note_history:22]
Recent Accounting Guidance Not Yet Adopted

- removed (2020-09-11):
[0001730168-20-000109:note_history:23]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. We are currently evaluating the impact of this guidance on our contracts, including but not limited to our credit agreements.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:24]
The future scheduled principal payments of debt as of August 2, 2020 were as follows:
  (was, 2020-06-12, similarity 0.956):
[0001730168-20-000109:note_history:24]
The future scheduled principal payments of debt as of May 3, 2020 were as follows:

- changed (2020-09-11):
[0001730168-20-000164:note_history:25]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 6,069 |  |
| 2024 |  | 3,403 |  |
| Thereafter |  | 32,392 |  |
| Total |  | $ | 44,498 |  |
  (was, 2020-06-12, similarity 0.9952):
[0001730168-20-000109:note_history:25]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 3,803 |  |
| 2021 |  | 2,674 |  |
| 2022 |  | 4,698 |  |
| 2023 |  | 7,644 |  |
| 2024 |  | 5,582 |  |
| Thereafter |  | 21,775 |  |
| Total |  | $ | 46,176 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-09-11):
[0001730168-20-000164:note_history:26]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.56 | % |  | 4,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.58 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

- added (2020-09-11):
[0001730168-20-000164:note_history:27]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%-4.55% |  | 22 |  |  | 2.59%-4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 44,498 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  | (542) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 43,956 |  |  |  |  | $ | 32,798 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:28]
________________________________________________________________
  (was, 2020-06-12, similarity 0.6667):
[0001730168-20-000109:note_history:28]
________________________________

- changed (2020-09-11):
[0001730168-20-000164:note_history:29]
As of August 2, 2020, $15 million of short-term and $52 million of long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.
  (was, 2020-06-12, similarity 0.9167):
[0001730168-20-000109:note_history:29]
As of May 3, 2020, $12 million and $43 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- added (2020-09-11):
[0001730168-20-000164:note_history:30]
June 2020 Senior Notes

- added (2020-09-11):
[0001730168-20-000164:note_history:31]
On June 4, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024, for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “June 2020 Senior Notes”). As a result of this exchange, we incurred premiums of $177 million. The June 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). We may, at our option, redeem or purchase, in whole or in part, any of the June 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the June 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the June 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- added (2020-09-11):
[0001730168-20-000164:note_history:32]
On May 8, 2020, we issued $8 billion of senior unsecured notes, which consisted of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest. As of August 2, 2020, the May 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- added (2020-09-11):
[0001730168-20-000164:note_history:33]
The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, as defined below, were used to repay an aggregate of $5,424 million of term loans outstanding under the November 2019 Credit Agreement, as defined below, consisting of repayments of $2,712 million of each of our unsecured term A-3 and A-5 facilities, and $3 billion of borrowings outstanding under the Revolving Facility, as defined below.

- added (2020-09-11):
[0001730168-20-000164:note_history:34]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. Additionally, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus

- added (2020-09-11):
[0001730168-20-000164:note_history:35]
accrued and unpaid interest. As of August 2, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- changed (2020-09-11):
[0001730168-20-000164:note_history:36]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “November 2019 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the November 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. During the fiscal quarter ended May 3, 2020, we repaid $194 million of each of our unsecured term A-3 and A-5 facilities.
  (was, 2020-06-12, similarity 0.7076):
[0001730168-20-000109:note_history:36]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. Beginning the second quarter of fiscal year 2020, we are required to repay 2.5% of the original principal borrowed under our November 2019 Term Loans every quarter until their respective maturity dates, unless and to the extent any amounts prepaid under the November 2019 Term Loans are applied to these required amortization payments.

- added (2020-09-11):
[0001730168-20-000164:note_history:37]
During the fiscal quarter ended August 2, 2020, as discussed above, we used the net proceeds from the May 2020 Senior Notes and the remaining net proceeds from the April 2020 Senior Notes to repay a portion of our November 2019 Term Loans. Additionally, we made repayments with cash on hand. In total, we repaid an aggregate of $6,224 million of our November 2019 Term Loans, consisting of repayments of $2,737 million and $3,487 million of our unsecured term A-3 and A-5 facilities, respectively, and wrote off $44 million of unamortized discount and issuance costs. As a result of these repayments, all remaining principal payments are due more than one year after August 2, 2020 and were included in long-term debt.

- added (2020-09-11):
[0001730168-20-000164:note_history:38]
In January 2020, we repaid an aggregate of $1 billion of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities (collectively, the “May 2019 Term Loans”) under the credit agreement entered into in May 2019 (the “May 2019 Credit Agreement”). In July 2020, we repaid an aggregate of $600 million of the May 2019 Term Loans, representing the outstanding balance of the May 2019 Term Loans.

- changed (2020-09-11):
[0001730168-20-000164:note_history:39]
The May 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the May 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the May 2019 Credit Agreement in accordance with the terms thereof. On May 8, 2020, using net proceeds from the May 2020 Senior Notes and April 2020 Senior Notes, we repaid $3 billion of borrowings outstanding under the Revolving Facility. As of August 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.
  (was, 2020-06-12, similarity 0.7297):
[0001730168-20-000109:note_history:39]
In addition to these unsecured term facilities, the 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of May 3, 2020, we had $3 billion of borrowings outstanding under the Revolving Facility with a term of less than one month. We had no borrowings outstanding as of November 3, 2019 under the Revolving Facility. Per the terms of the 2019 Credit Agreement, we have the ability and intent to continuously refinance our borrowings under the Revolving Facility and have therefore recorded such borrowings as long-term debt.

- added (2020-09-11):
[0001730168-20-000164:note_history:40]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of August 2, 2020, we had no Commercial Paper outstanding. We had $1 billion of Commercial Paper outstanding as of November 3, 2019 with maturities generally less than three months. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we record Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- changed (2020-09-11):
[0001730168-20-000164:note_history:41]
Exchange Offer
  (was, 2020-06-12, similarity 0.6471):
[0001730168-20-000109:note_history:41]
May 2020 Exchange Notes

- added (2020-09-11):
[0001730168-20-000164:note_history:42]
In connection with the issuance of the June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes (collectively, the “2020 Senior Notes”) and $11 billion of senior unsecured notes in April 2019 (the “April 2019 Senior Notes”), we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the SEC, and cause to be declared effective, a registration statement with respect to an offer to exchange (the “Exchange Offer”) each series of the 2020 Senior Notes and April 2019 Senior Notes for notes that are registered with the SEC (the “Registered Notes”), with substantially identical terms. On July 6, 2020, we launched the Exchange Offer, which expired on August 7, 2020. Substantially all of our 2020 Senior Notes and April 2019 Senior Notes were tendered and exchanged for the corresponding Registered Notes in the Exchange Offer.

- changed (2020-09-11):
[0001730168-20-000164:note_history:43]
As of August 2, 2020, the estimated aggregate fair value of debt was $48,483 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2020-06-12, similarity 0.7724):
[0001730168-20-000109:note_history:43]
As of May 3, 2020, the estimated aggregate fair value of debt was $47,732 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans and May 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our revolver borrowings and Commercial Paper approximated their carrying value due to the short-term maturity of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2020-09-11):
[0001730168-20-000164:note_history:44]
The future scheduled principal payments of debt as of August 2, 2020 were as follows:
  (was, 2020-06-12, similarity 0.956):
[0001730168-20-000109:note_history:44]
The future scheduled principal payments of debt as of May 3, 2020 were as follows:

- changed (2020-09-11):
[0001730168-20-000164:note_history:45]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 807 |  |
| 2022 |  | 1,827 |  |
| 2023 |  | 6,069 |  |
| 2024 |  | 3,403 |  |
| Thereafter |  | 32,392 |  |
| Total |  | $ | 44,498 |  |
  (was, 2020-06-12, similarity 0.9952):
[0001730168-20-000109:note_history:45]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 3,803 |  |
| 2021 |  | 2,674 |  |
| 2022 |  | 4,698 |  |
| 2023 |  | 7,644 |  |
| 2024 |  | 5,582 |  |
| Thereafter |  | 21,775 |  |
| Total |  | $ | 46,176 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:46]
As of August 2, 2020 and November 3, 2019, we accrued interest payable of $306 million and $214 million, respectively, and were in compliance with all debt covenants.
  (was, 2020-06-12, similarity 0.9769):
[0001730168-20-000109:note_history:46]
As of May 3, 2020 and November 3, 2019, we accrued interest payable of $190 million and $214 million, respectively, and were in compliance with all debt covenants.

- removed (2020-09-11):
[0001730168-20-000109:note_history:47]
|  |  | May 3,2020 |  |  |  | November 3,2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | $ | 2,250 |  |  |  |  | $ | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 2.38 | % |  | 7,556 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 2.40 | % |  | 7,556 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  | 2.35 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  | 2.44 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 726 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 399 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 1,139 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |  |  |  |
| Revolving facility under the 2019 Credit Agreement |  | 1.97 | % |  |  | 3,000 |  |  |  |  | — |  |
| Commercial paper |  | 2.90 | % | (a) | 28 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  |  | 22 |  |  | 2.59%- 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  |  | 46,176 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  |  | (368) |  |  |  |  | (261) |  |
| Total debt |  |  |  |  | $ | 45,808 |  |  |  |  | $ | 32,798 |  |

- removed (2020-09-11):
[0001730168-20-000109:note_history:48]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our April 2020 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable April 2020 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. As of May 3, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- removed (2020-09-11):
[0001730168-20-000109:note_history:49]
In January 2020, we repaid an aggregate of $1,000 million of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities under the credit agreement entered into in May 2019 (the “2019 Credit Agreement”), using net proceeds from issuances of Commercial Paper, as defined below. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- removed (2020-09-11):
[0001730168-20-000109:note_history:50]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of May 3, 2020 and November 3, 2019, we had $28 million and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than three months. As our commercial paper program is

- removed (2020-09-11):
[0001730168-20-000109:note_history:51]
supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- removed (2020-09-11):
[0001730168-20-000109:note_history:52]
Subsequent to the fiscal quarter ended May 3, 2020, we issued $8,000 million of senior unsecured notes on May 8, 2020. These notes are comprised of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. Each series of our May 2020 Senior Notes pays interest semi-annually in arrears on May 15 and November 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities at a price equal to 100% of the principal amount, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, were used to repay an aggregate of $5,424 million of term loans outstanding under the 2020 Credit Agreement, consisting of repayments of $2,712 million of each of our unsecured term A-3 facility and unsecured term A-5 facility, and $3,000 million of borrowings outstanding under the Revolving Facility. The remaining term loans outstanding under the 2020 Credit Agreement are due more than one year after May 3, 2020 and were included in long-term debt.

- removed (2020-09-11):
[0001730168-20-000109:note_history:53]
On June 4, 2020, subsequent to the fiscal quarter ended May 3, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024 (the “Exchange Offers”), for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “May 2020 Exchange Notes”). As a result of the settlement, we recorded $201 million and $117 million of our 3.125% notes due April 2021 and 2.200% notes due January 2021, respectively, as long-term debt as of May 3, 2020. The May 2020 Exchange Notes pay interest semi-annually in arrears on March 15 and September 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Exchange Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable May 2020 Exchange Notes, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Exchange Notes, plus accrued and unpaid interest.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-09-11):
[0001730168-20-000164:note_history:54]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | $ | 1,695 |  |  |  |  | $ | — |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  |  |  | — |  |
| May 2020 Senior Notes- fixed rate |  |  |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 1,000 |  |  |  |  | — |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 2,250 |  |  |  |  | — |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  |  |  | — |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  |  |  | — |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 2,250 |  |  |  |  | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.56 | % |  | 4,819 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.58 | % |  | 4,069 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  |  |  | — |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  |  |  | — |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 525 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 693 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 1,044 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 282 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 842 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 1,352 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 283 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |

- added (2020-09-11):
[0001730168-20-000164:note_history:55]
|  |  | August 2, 2020 |  |  |  | November 3, 2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| Other borrowings |  |  |  |  |  |  |  |  |
| Commercial paper |  |  |  | — |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%-4.55% |  | 22 |  |  | 2.59%-4.55% |  | 22 |  |
| Total principal amount outstanding |  |  |  | 44,498 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  | (542) |  |  |  |  | (261) |  |
| Total debt |  |  |  | $ | 43,956 |  |  |  |  | $ | 32,798 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:56]
________________________________________________________________
  (was, 2020-06-12, similarity 0.6667):
[0001730168-20-000109:note_history:56]
________________________________

- removed (2020-09-11):
[0001730168-20-000109:note_history:57]
|  |  | May 3,2020 |  |  |  | November 3,2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | $ | 2,250 |  |  |  |  | $ | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 2.38 | % |  | 7,556 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 2.40 | % |  | 7,556 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  | 2.35 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  | 2.44 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 726 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 399 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 1,139 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |  |  |  |
| Revolving facility under the 2019 Credit Agreement |  | 1.97 | % |  |  | 3,000 |  |  |  |  | — |  |
| Commercial paper |  | 2.90 | % | (a) | 28 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  |  | 22 |  |  | 2.59%- 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  |  | 46,176 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  |  | (368) |  |  |  |  | (261) |  |
| Total debt |  |  |  |  | $ | 45,808 |  |  |  |  | $ | 32,798 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:58]
|  |  | Fiscal Quarter Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |
  (was, 2020-06-12, similarity 0.9872):
[0001730168-20-000109:note_history:58]
|  |  | Fiscal Quarter Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:59]
|  |  | Fiscal Quarter Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |
  (was, 2020-06-12, similarity 0.9872):
[0001730168-20-000109:note_history:59]
|  |  | Fiscal Quarter Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services (a) |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:60]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |
  (was, 2020-06-12, similarity 0.9791):
[0001730168-20-000109:note_history:60]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:61]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |
  (was, 2020-06-12, similarity 0.9791):
[0001730168-20-000109:note_history:61]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services (a) |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:62]
|  |  | Fiscal Quarter Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |
  (was, 2020-06-12, similarity 0.9872):
[0001730168-20-000109:note_history:62]
|  |  | Fiscal Quarter Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:63]
|  |  | Fiscal Quarter Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 506 |  |  | $ | 3,582 |  |  | $ | 325 |  |  | $ | 4,413 |  |
| Subscriptions and services (a) |  | 711 |  |  | 124 |  |  | 267 |  |  | 1,102 |  |
| Total |  | $ | 1,217 |  |  | $ | 3,706 |  |  | $ | 592 |  |  | $ | 5,515 |  |
  (was, 2020-06-12, similarity 0.9872):
[0001730168-20-000109:note_history:63]
|  |  | Fiscal Quarter Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services (a) |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:64]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |
  (was, 2020-06-12, similarity 0.9791):
[0001730168-20-000109:note_history:64]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:65]
|  |  | Three Fiscal Quarters Ended August 4, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,731 |  |  | $ | 10,674 |  |  | $ | 1,065 |  |  | $ | 13,470 |  |
| Subscriptions and services (a) |  | 2,276 |  |  | 339 |  |  | 736 |  |  | 3,351 |  |
| Total |  | $ | 4,007 |  |  | $ | 11,013 |  |  | $ | 1,801 |  |  | $ | 16,821 |  |
  (was, 2020-06-12, similarity 0.9791):
[0001730168-20-000109:note_history:65]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services (a) |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:66]
Although we recognize revenue for the majority of our semiconductor products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.
  (was, 2020-06-12, similarity 0.9792):
[0001730168-20-000109:note_history:66]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by distributors, original equipment manufacturers, contract manufacturers, channel partners, or software customers.

- changed (2020-09-11):
[0001730168-20-000164:note_history:67]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of August 2, 2020 (a) |  | $ | 158 |  |  | $ | 3,463 |  |
  (was, 2020-06-12, similarity 0.981):
[0001730168-20-000109:note_history:67]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of May 3, 2020 (a) |  | $ | 197 |  |  | $ | 3,776 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:68]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of August 2, 2020.
  (was, 2020-06-12, similarity 0.9671):
[0001730168-20-000109:note_history:68]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of May 3, 2020.

- changed (2020-09-11):
[0001730168-20-000164:note_history:69]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of August 4, 2019 |  | $ | 229 |  |  | $ | 2,269 |  |
  (was, 2020-06-12, similarity 0.981):
[0001730168-20-000109:note_history:69]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |

- changed (2020-09-11):
[0001730168-20-000164:note_history:70]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balances do not include contract assets or contract liabilities associated with CA.
  (was, 2020-06-12, similarity 0.9815):
[0001730168-20-000109:note_history:70]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

- changed (2020-09-11):
[0001730168-20-000164:note_history:71]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $173 million.
  (was, 2020-06-12, similarity 0.9519):
[0001730168-20-000109:note_history:71]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019

- changed (2020-09-11):
[0001730168-20-000164:note_history:72]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are accordingly deemed to
  (was, 2020-06-12, similarity 0.7455):
[0001730168-20-000109:note_history:72]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- added (2020-09-11):
[0001730168-20-000164:note_history:73]
not be committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- added (2020-09-11):
[0001730168-20-000164:note_history:74]
Because the substantial majority of our customer software contracts allow our customers to terminate for convenience without a substantive penalty or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of August 2, 2020 was not material. Since the majority of our software contracts are not deemed to be committed, although our customers generally do not exercise their termination for convenience rights, and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- removed (2020-09-11):
[0001730168-20-000109:note_history:75]
that was included in the contract liabilities balance as of November 5, 2018 was $144 million.

- removed (2020-09-11):
[0001730168-20-000109:note_history:76]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 3, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-09-11):
[0001730168-20-000164:note_history:77]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2020 to stockholders of record on September 15, 2020.
  (was, 2020-06-12, similarity 0.916):
[0001730168-20-000109:note_history:77]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2020 to stockholders of record on June 15, 2020.

- changed (2020-09-11):
[0001730168-20-000164:note_history:78]
On September 2, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on September 30, 2020 to stockholders of record on September 22, 2020.
  (was, 2020-06-12, similarity 0.9038):
[0001730168-20-000109:note_history:78]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on June 30, 2020 to stockholders of record on June 22, 2020.
