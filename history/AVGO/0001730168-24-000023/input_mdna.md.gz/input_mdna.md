# AVGO MD&A — 0001730168-24-000023


## mdna

[0001730168-24-000023:mdna:1]
[same as prior period, unchanged from 0001730168-23-000077:mdna:1]

[0001730168-24-000023:mdna:2]
[same as prior period, unchanged from 0001730168-23-000077:mdna:2]

[0001730168-24-000023:mdna:3]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile and hybrid cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-24-000023:mdna:4]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and IP licensing. Our infrastructure software segment includes our application development and delivery, application networking and security, mainframe, distributed, software-defined edge, hybrid cloud and cyber security solutions, and our FC SAN business.

[0001730168-24-000023:mdna:5]
Our fiscal quarter ended February 4, 2024 contained 14 weeks compared to 13 weeks in the fiscal quarter ended January 29, 2023. The additional week resulted in higher net revenue, gross margin dollars, research and development expense, and selling general and administrative expense for the fiscal quarter ended February 4, 2024, compared to the corresponding prior year fiscal period.

[0001730168-24-000023:mdna:6]
[same as prior period, unchanged from 0001730168-23-000077:mdna:5]

[0001730168-24-000023:mdna:7]
Highlights during the fiscal quarter ended February 4, 2024 include the following:

[0001730168-24-000023:mdna:8]
•On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”), for approximately $30.8 billion in cash and 54.4 million shares of Broadcom common stock with a fair value of $53.4 billion.

[0001730168-24-000023:mdna:9]
•We entered an $11,195 million unsecured term A-2 facility, an $11,195 million unsecured term A-3 facility and an $8,000 million unsecured term A-5 facility, collectively referred to as the “2023 Term Loans”. See Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q for more details.

[0001730168-24-000023:mdna:10]
•We generated $4,815 million of cash from operations.

[0001730168-24-000023:mdna:11]
•We paid $2,435 million in cash dividends.

[0001730168-24-000023:mdna:12]
•We repurchased $7,176 million of common stock.

[0001730168-24-000023:mdna:13]
Acquisition of VMware

[0001730168-24-000023:mdna:14]
On November 22, 2023, we acquired VMware in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. In addition, we assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding RSU awards held by non-employee directors and in-the-money VMware stock options were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000023:mdna:15]
[same as prior period, unchanged from 0001730168-23-000077:mdna:18]

[0001730168-24-000023:mdna:16]
[same as prior period, unchanged from 0001730168-23-000077:mdna:19]

[0001730168-24-000023:mdna:17]
There were no significant changes in our critical accounting estimates during the fiscal quarter ended February 4, 2024 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2023 Annual Report on Form 10-K.

[0001730168-24-000023:mdna:18]
[same as prior period, unchanged from 0001730168-23-000077:mdna:21]

[0001730168-24-000023:mdna:19]
Fiscal Quarter Ended February 4, 2024 Compared to Fiscal Quarter Ended January 29, 2023

[0001730168-24-000023:mdna:20]
The following table sets forth our results of operations for the periods presented:

[0001730168-24-000023:mdna:21]
|  |  | Fiscal Quarter Ended |
|  |  | February 4,2024 |  | January 29,2023 |  | February 4,2024 |  | January 29,2023 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 7,412 |  |  | $ | 7,082 |  |  | 62 | % |  | 79 | % |
| Subscriptions and services |  | 4,549 |  |  | 1,833 |  |  | 38 |  |  | 21 |  |
| Total net revenue |  | 11,961 |  |  | 8,915 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,160 |  |  | 2,225 |  |  | 18 |  |  | 25 |  |
| Cost of subscriptions and services |  | 954 |  |  | 149 |  |  | 8 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,380 |  |  | 535 |  |  | 11 |  |  | 6 |  |
| Restructuring charges |  | 92 |  |  | 2 |  |  | 1 |  |  | — |  |
| Total cost of revenue |  | 4,586 |  |  | 2,911 |  |  | 38 |  |  | 33 |  |
| Gross margin |  | 7,375 |  |  | 6,004 |  |  | 62 |  |  | 67 |  |
| Research and development |  | 2,308 |  |  | 1,195 |  |  | 19 |  |  | 13 |  |
| Selling, general and administrative |  | 1,572 |  |  | 348 |  |  | 13 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 792 |  |  | 348 |  |  | 7 |  |  | 4 |  |
| Restructuring and other charges |  | 620 |  |  | 10 |  |  | 5 |  |  | — |  |
| Total operating expenses |  | 5,292 |  |  | 1,901 |  |  | 44 |  |  | 21 |  |
| Operating income |  | $ | 2,083 |  |  | $ | 4,103 |  |  | 18 | % |  | 46 | % |

[0001730168-24-000023:mdna:22]
[same as prior period, unchanged from 0001730168-23-000077:mdna:28]

[0001730168-24-000023:mdna:23]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 27% and 22% of our net revenue for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively.

[0001730168-24-000023:mdna:24]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 40% and 35% of our net revenue for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 17% and 20% of our net revenue for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-24-000023:mdna:25]
[same as prior period, unchanged from 0001730168-23-000077:mdna:31]

[0001730168-24-000023:mdna:26]
[same as prior period, unchanged from 0001730168-23-000077:mdna:32]

[0001730168-24-000023:mdna:27]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Net Revenue by Segment |  | February 4, 2024 |  | January 29, 2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 7,390 |  |  | $ | 7,107 |  |  | $ | 283 |  |  | 4 | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 4,571 |  |  | 1,808 |  |  | 2,763 |  |  | 153 | % |  |  |  |  |  |  |  |  |
| Total net revenue |  | $ | 11,961 |  |  | $ | 8,915 |  |  | $ | 3,046 |  |  | 34 | % |  |  |  |  |  |  |  |  |

[0001730168-24-000023:mdna:28]
|  |  | Fiscal Quarter Ended |  |  |
| Net Revenue by Segment |  | February 4,2024 |  | January 29,2023 |  |  |  |  |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 62 | % |  | 80 | % |  |  |  |  |
| Infrastructure software |  | 38 |  |  | 20 |  |  |  |  |  |
| Total net revenue |  | 100 | % |  | 100 | % |  |  |  |  |

[0001730168-24-000023:mdna:29]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period due to strong product demand for networking products, partially offset by lower demand for our server storage and broadband products. Net revenue from our infrastructure software segment increased in the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period primarily due to contributions from VMware.

[0001730168-24-000023:mdna:30]
[same as prior period, unchanged from 0001730168-23-000077:mdna:36]

[0001730168-24-000023:mdna:31]
Gross margin was $7,375 million for the fiscal quarter ended February 4, 2024 compared to $6,004 million for the fiscal quarter ended January 29, 2023. The $1,371 million increase was primarily due to contributions from VMware, partially offset by higher amortization of acquisition-related intangible assets from the VMware Merger.

[0001730168-24-000023:mdna:32]
As a percentage of net revenue, gross margin was 62% and 67% of net revenue for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. The 5% decrease was primarily due to higher amortization of acquisition-related intangible assets from the VMware Merger.

[0001730168-24-000023:mdna:33]
[same as prior period, unchanged from 0001730168-23-000077:mdna:39]

[0001730168-24-000023:mdna:34]
Research and development expense increased $1,113 million, or 93%, for the fiscal quarter ended February 4, 2024, compared to the prior year fiscal period. The increase was primarily due to higher stock-based compensation expense as a result of RSUs assumed in connection with the VMware Merger and annual employee equity awards granted in March 2023 at higher grant-date fair values, as well as higher compensation due to an increase in headcount from the VMware Merger.

[0001730168-24-000023:mdna:35]
[same as prior period, unchanged from 0001730168-23-000077:mdna:43]

[0001730168-24-000023:mdna:36]
Selling, general and administrative expense increased $1,224 million, or 352% for the fiscal quarter ended February 4, 2024, compared to the prior year fiscal period. The increase was primarily due to higher stock-based compensation expense as a result of RSUs assumed in connection with the VMware Merger, higher acquisition-related costs, as well as higher compensation due to an increase in headcount from the VMware Merger.

[0001730168-24-000023:mdna:37]
[same as prior period, unchanged from 0001730168-23-000077:mdna:45]

[0001730168-24-000023:mdna:38]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $444 million, or 128%, for the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period primarily due to higher amortization of customer-related intangible assets from the VMware Merger.

[0001730168-24-000023:mdna:39]
[same as prior period, unchanged from 0001730168-23-000077:mdna:47]

[0001730168-24-000023:mdna:40]
Restructuring and other charges recognized in operating expenses was $620 million for the fiscal quarter ended February 4, 2024 primarily due to employee termination costs associated with the VMware Merger. We expect to incur additional restructuring and other charges in future periods as a result of the VMware Merger.

[0001730168-24-000023:mdna:41]
[same as prior period, unchanged from 0001730168-23-000077:mdna:49]

[0001730168-24-000023:mdna:42]
Total stock-based compensation expense was $1,572 million and $391 million for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. The increase was primarily due to equity awards assumed in connection with the VMware Merger and annual employee equity awards granted in March 2023 at higher grant-date fair values. Stock-based compensation expense for the fiscal quarter ended February 4, 2024 also included a one-time impact from aligning the vesting dates of certain assumed awards with our RSU vesting dates, as well as accelerated vesting of certain assumed equity awards held by employees terminated in connection with the VMware Merger.

[0001730168-24-000023:mdna:43]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of February 4, 2024. The remaining weighted-average service period was 3.3 years.

[0001730168-24-000023:mdna:44]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 3,467 |  |
| 2025 |  | 3,682 |  |
| 2026 |  | 2,857 |  |
| 2027 |  | 1,900 |  |
| 2028 |  | 226 |  |
| Total |  | $ | 12,132 |  |

[0001730168-24-000023:mdna:45]
[same as prior period, unchanged from 0001730168-23-000077:mdna:55]

[0001730168-24-000023:mdna:46]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  |  |  |  |
| Operating Income by Segment |  | February 4,2024 |  | January 29,2023 |  | $ Change |  | % Change |  |  |  |  |  |  |  |  |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 4,116 |  |  | $ | 4,123 |  |  | $ | (7) |  |  | — | % |  |  |  |  |  |  |  |  |
| Infrastructure software |  | 2,715 |  |  | 1,307 |  |  | 1,408 |  |  | 108 | % |  |  |  |  |  |  |  |  |
| Unallocated expenses |  | (4,748) |  |  | (1,327) |  |  | (3,421) |  |  | 258 | % |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 2,083 |  |  | $ | 4,103 |  |  | $ | (2,020) |  |  | (49) | % |  |  |  |  |  |  |  |  |

[0001730168-24-000023:mdna:47]
Operating income from our semiconductor solutions segment was relatively flat for the quarter ended February 4, 2024 compared to the prior year fiscal period. Higher compensation expense as a result of an additional week in the current year fiscal quarter and lower gross margins driven by product mix were offset by higher revenue from networking products. Higher operating income from our infrastructure software segment in the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period was primarily due to contributions from VMware.

[0001730168-24-000023:mdna:48]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring and other charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 258% for the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period primarily due to higher amortization of acquisition-related intangible assets, stock-based compensation expense, and restructuring and other charges. These increases were primarily due to the VMware Merger. The increase in stock based compensation expense was also due to annual employee equity awards granted in March 2023 at higher grant-date fair values.

[0001730168-24-000023:mdna:49]
[same as prior period, unchanged from 0001730168-23-000077:mdna:59]

[0001730168-24-000023:mdna:50]
Interest expense. Interest expense was $926 million and $406 million for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. The increase was primarily due to interest on debt incurred for the VMware Merger.

[0001730168-24-000023:mdna:51]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $185 million and $143 million for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. The increase was primarily due to higher interest income as a result of higher interest rates on a higher invested balance.

[0001730168-24-000023:mdna:52]
Provision for income taxes. The provision for income taxes was $68 million and $66 million for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. In the fiscal quarter ended February 4, 2024, lower uncertain tax benefits recognized were offset by lower income from continuing operations before income taxes and higher excess tax benefits from stock-based awards compared to the fiscal quarter ended January 29, 2023, and a valuation allowance release.

[0001730168-24-000023:mdna:53]
[same as prior period, unchanged from 0001730168-23-000077:mdna:63]

[0001730168-24-000023:mdna:54]
[same as prior period, unchanged from 0001730168-23-000077:mdna:64]

[0001730168-24-000023:mdna:55]
Our primary sources of liquidity as of February 4, 2024 consisted of: (i) $11,864 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets and debt or equity financings from time to time. In February 2024, we signed a definitive agreement to sell VMware’s end-user computing business for approximately $3.8 billion, before working capital adjustments and estimated selling costs. The sale is expected to close in calendar year 2024, subject to customary closing conditions, including regulatory approvals.

[0001730168-24-000023:mdna:56]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $78,521 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2024 as compared to fiscal year 2023. Our debt and liquidity needs increased as a result of completing the VMware Merger. We funded the cash portion of the consideration with net proceeds from the $30,390 million 2023 Term Loans, as well as cash on hand. We also assumed $8,250 million of VMware’s outstanding senior unsecured notes. On March 5, 2024, we made a partial repayment of $2.0 billion on our 2023 Term Loans.

[0001730168-24-000023:mdna:57]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-24-000023:mdna:58]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes, the 2023 Term Loans and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-24-000023:mdna:59]
[same as prior period, unchanged from 0001730168-23-000077:mdna:69]

[0001730168-24-000023:mdna:60]
[same as prior period, unchanged from 0001730168-23-000077:mdna:70]

[0001730168-24-000023:mdna:61]
On November 22, 2023, we completed the VMware Merger. The following table presents the changes in selected balance sheet captions other than assets acquired and liabilities assumed from the VMware Merger during the fiscal quarter ended February 4, 2024.

[0001730168-24-000023:mdna:62]
|  |  | Balances at October 29, 2023 |  | Balances acquired and assumed from VMware on November 22, 2023 |  | Balances at February 4, 2024 |  | Non-VMware acquisition increase (decrease) |
|  |  | (In millions) |
| Cash and cash equivalents |  | $ | 14,189 |  |  | $ | 6,642 |  |  | $ | 11,864 |  |  | $ | (8,967) |  |
| Trade accounts receivable, net |  | $ | 3,154 |  |  | $ | 3,571 |  |  | $ | 4,969 |  |  | $ | (1,756) |  |
| Assets held-for-sale |  | $ | — |  |  | $ | 5,959 |  |  | $ | 5,934 |  |  | $ | (25) |  |
| Other current assets |  | $ | 1,606 |  |  | $ | 540 |  |  | $ | 2,505 |  |  | $ | 359 |  |
| Employee compensation and benefits |  | $ | 935 |  |  | $ | 848 |  |  | $ | 1,128 |  |  | $ | (655) |  |
| Current portion of long-term debt |  | $ | 1,608 |  |  | $ | 1,264 |  |  | $ | 2,433 |  |  | $ | (439) |  |
| Liabilities held-for-sale |  | $ | — |  |  | $ | 2,581 |  |  | $ | 2,436 |  |  | $ | (145) |  |
| Other current liabilities |  | $ | 3,652 |  |  | $ | 10,732 |  |  | $ | 12,876 |  |  | $ | (1,508) |  |

[0001730168-24-000023:mdna:63]
•Cash and cash equivalents decreased primarily due to $32,058 million paid for the VMware Merger, $7,176 million of common stock repurchases, $2,435 million of dividend payments and $1,114 million of employee withholding tax payments related to net settled equity awards, offset in part by $29,076 million in net proceeds from borrowings and $4,815 million in net cash provided by operating activities.

[0001730168-24-000023:mdna:64]
•Trade accounts receivable, net decreased primarily due to strong collections.

[0001730168-24-000023:mdna:65]
•Other current assets increased primarily due to higher prepaid income taxes.

[0001730168-24-000023:mdna:66]
•Employee compensation and benefits decreased primarily due to the timing of annual employee bonus plan payments.

[0001730168-24-000023:mdna:67]
•Current portion of long-term debt decreased due to $934 million of repayments, offset in part by $495 million becoming due within the next twelve months.

[0001730168-24-000023:mdna:68]
•Liabilities held-for-sale decreased due to software revenue recognized in discontinued operations.

[0001730168-24-000023:mdna:69]
•Other current liabilities decreased as software revenue recognized resulted in lower contract liabilities, offset in part by an increase in liabilities related to restructuring activities associated with the VMware Merger.

[0001730168-24-000023:mdna:70]
[same as prior period, unchanged from 0001730168-23-000077:mdna:77]

[0001730168-24-000023:mdna:71]
|  |  | Fiscal Quarter Ended |
| Cash Dividends Declared and Paid |  | February 4,2024 |  | January 29,2023 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 5.25 |  |  | $ | 4.60 |  |
| Dividends to common stockholders |  | $ | 2,435 |  |  | $ | 1,926 |  |

[0001730168-24-000023:mdna:72]
During the fiscal quarters ended February 4, 2024 and January 29, 2023, we repurchased and retired approximately 7 million and 2 million shares of our common stock for $7,176 million and $1,188 million, respectively. All $20 billion of the authorized amount under our stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000023:mdna:73]
During the fiscal quarters ended February 4, 2024 and January 29, 2023, we paid approximately $1,114 million and $333 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 1 million shares of common stock from employees in connection with such net share settlements during each of the fiscal quarters ended February 4, 2024 and January 29, 2023.

[0001730168-24-000023:mdna:74]
[same as prior period, unchanged from 0001730168-23-000077:mdna:84]

[0001730168-24-000023:mdna:75]
|  |  | Fiscal Quarter Ended |
|  |  | February 4,2024 |  | January 29,2023 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 4,815 |  |  | $ | 4,036 |  |
| Net cash used in investing activities |  | (25,477) |  |  | (103) |  |
| Net cash provided by (used in) financing activities |  | 18,337 |  |  | (3,702) |  |
| Net change in cash and cash equivalents |  | $ | (2,325) |  |  | $ | 231 |  |

[0001730168-24-000023:mdna:76]
[same as prior period, unchanged from 0001730168-23-000077:mdna:86]

[0001730168-24-000023:mdna:77]
Cash flows from operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $779 million increase in cash provided by operations during the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period was primarily due to contributions from VMware. The $2,449 million decrease in net income was largely driven by $2,930 million of higher non-cash adjustments including amortization of intangible assets and stock-based compensation.

[0001730168-24-000023:mdna:78]
[same as prior period, unchanged from 0001730168-23-000077:mdna:88]

[0001730168-24-000023:mdna:79]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures and proceeds and payments related to investments. The $25,374 million increase in cash used in investing activities during the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period was primarily due to $25,416 million cash paid in connection with the VMware Merger, net of cash acquired.

[0001730168-24-000023:mdna:80]
[same as prior period, unchanged from 0001730168-23-000077:mdna:90]

[0001730168-24-000023:mdna:81]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, stock repurchases, dividend payments and employee withholding tax payments related to net settled equity awards. The $22,039 million increase in cash flows from financing activities during the fiscal quarter ended February 4, 2024 compared to the prior year fiscal period was primarily due to $30,010 million of net proceeds from the 2023 Term Loans, offset in part by a $5,988 million increase in stock repurchases, a $781 million increase in employee withholding tax payments related to net settled equity awards, a $674 million increase in payments of debt obligations and a $509 million increase in dividend payments.
