# AVGO notes — 0001730168-24-000023


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-24-000023:notes:1]
[same as prior period, unchanged from 0001730168-23-000077:notes:1]

[0001730168-24-000023:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

[0001730168-24-000023:notes:3]
On November 22, 2023, we completed the acquisition of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”). The VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million. VMware was a leading provider of multi-cloud services for all applications, enabling digital innovation with enterprise control. We acquired VMware to enhance our infrastructure software capabilities. The results of operations of VMware are included in the unaudited condensed consolidated financial statements commencing on November 22, 2023. See Note 3. “Acquisition of VMware, Inc.” for additional information.

[0001730168-24-000023:notes:4]
[same as prior period, unchanged from 0001730168-23-000077:notes:3]

[0001730168-24-000023:notes:5]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending November 3, 2024 (“fiscal year 2024”) is a 53-week fiscal year, with our first fiscal quarter containing 14 weeks. Our fiscal year ended October 29, 2023 (“fiscal year 2023”) was a 52-week fiscal year.

[0001730168-24-000023:notes:6]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 29, 2023 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2023 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 4, 2024 are not necessarily indicative of the results that may be expected for fiscal year 2024, or for any other future period.

[0001730168-24-000023:notes:7]
[same as prior period, unchanged from 0001730168-23-000077:notes:6]

[0001730168-24-000023:notes:8]
[same as prior period, unchanged from 0001730168-23-000077:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-24-000023:notes:9]
[same as prior period, unchanged from 0001730168-23-000077:notes:8]

[0001730168-24-000023:notes:10]
[same as prior period, unchanged from 0001730168-23-000077:notes:9]

[0001730168-24-000023:notes:11]
[same as prior period, unchanged from 0001730168-23-000077:notes:10]

[0001730168-24-000023:notes:12]
[same as prior period, unchanged from 0001730168-23-000077:notes:11]

[0001730168-24-000023:notes:13]
|  |  | Fiscal Quarter Ended February 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 708 |  |  | $ | 6,191 |  |  | $ | 513 |  |  | $ | 7,412 |  |
| Subscriptions and services |  | 2,377 |  |  | 506 |  |  | 1,666 |  |  | 4,549 |  |
| Total |  | $ | 3,085 |  |  | $ | 6,697 |  |  | $ | 2,179 |  |  | $ | 11,961 |  |

[0001730168-24-000023:notes:14]
|  |  | Fiscal Quarter Ended January 29, 2023 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 609 |  |  | $ | 5,937 |  |  | $ | 536 |  |  | $ | 7,082 |  |
| Subscriptions and services |  | 1,230 |  |  | 200 |  |  | 403 |  |  | 1,833 |  |
| Total |  | $ | 1,839 |  |  | $ | 6,137 |  |  | $ | 939 |  |  | $ | 8,915 |  |

[0001730168-24-000023:notes:15]
[same as prior period, unchanged from 0001730168-23-000077:notes:18]

[0001730168-24-000023:notes:16]
[same as prior period, unchanged from 0001730168-23-000077:notes:19]

[0001730168-24-000023:notes:17]
Contract assets and contract liabilities balances were as follows:

[0001730168-24-000023:notes:18]
|  |  | February 4,2024 |  | October 29,2023 |
|  | (In millions) |
| Contract Assets |  | $ | 1,647 |  |  | $ | 955 |  |
| Contract Liabilities |  | $ | 15,451 |  |  | $ | 2,786 |  |

[0001730168-24-000023:notes:19]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. Contract assets and contract liabilities as of February 4, 2024 included the impact of VMware balances acquired on November 22, 2023. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. As of February 4, 2024, approximately 39% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $1,313 million. The amount of revenue recognized during the fiscal quarter ended January 29, 2023 that was included in the contract liabilities balance as of October 30, 2022 was $1,435 million.

[0001730168-24-000023:notes:20]
[same as prior period, unchanged from 0001730168-23-000077:notes:22]

[0001730168-24-000023:notes:21]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or

[0001730168-24-000023:notes:22]
services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-24-000023:notes:23]
Certain multi-year customer contracts contain firmly committed amounts and the remaining performance obligations under these contracts as of February 4, 2024 were approximately $27.7 billion. We expect approximately 44% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. In addition, the majority of our contracts have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-24-000023:notes:24]
Acquisition of VMware, Inc.
On November 22, 2023, we completed the VMware Merger. Pursuant to the Agreement and Plan of Merger, each share of VMware common stock issued and outstanding immediately prior to the VMware Merger was indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash or 0.2520 shares of Broadcom common stock. The stockholder election was prorated, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, in each case, was equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the VMware Merger. Based on the VMware stockholders’ elections, the VMware stockholders received approximately $30,788 million in cash and 54.4 million shares of Broadcom common stock with a fair value of $53,398 million.

[0001730168-24-000023:notes:25]
We funded the cash portion of the VMware Merger with the net proceeds from the issuance of the 2023 Term Loans, as defined and discussed in Note 7. “Borrowings”, as well as cash on hand. We assumed $8,250 million of VMware’s outstanding senior unsecured notes.

[0001730168-24-000023:notes:26]
Purchase Consideration

[0001730168-24-000023:notes:27]
|  |  | (In millions) |
| Fair value of Broadcom common stock issued for outstanding VMware common stock |  | $ | 53,398 |  |
| Cash paid for outstanding VMware common stock |  | 30,788 |  |
| Cash paid by Broadcom to retire VMware’s term loan |  | 1,257 |  |
| Fair value of partially vested assumed VMware equity awards |  | 805 |  |
| Fair value of Broadcom common stock issued for accelerated VMware equity awards |  | 23 |  |
| Cash paid for accelerated VMware equity awards |  | 13 |  |
| Effective settlement of pre-existing relationships |  | 6 |  |
| Total purchase consideration |  | 86,290 |  |
| Less: cash acquired |  | 6,642 |  |
| Total purchase consideration, net of cash acquired |  | $ | 79,648 |  |

[0001730168-24-000023:notes:28]
We assumed all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit (“PSU”) awards held by continuing employees. The assumed awards were converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors were accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-24-000023:notes:29]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on their estimated fair values. These fair values were based on estimates and assumptions made by management at the time of acquisition. As additional information becomes available, we may further revise our preliminary purchase price allocation during the remainder of the measurement period, which will not exceed 12 months from the date of the VMware Merger. Any such revisions or changes may be material.

[0001730168-24-000023:notes:30]
The following table presents our preliminary allocation of the total purchase price, net of cash acquired:

[0001730168-24-000023:notes:31]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Trade accounts receivable |  | $ | 3,571 |  |
| Inventory |  | 15 |
| Assets held-for-sale |  | 5,959 |  |
| Other current assets |  | 540 |  |
| Property, plant and equipment |  | 531 |  |
| Goodwill |  | 53,933 |  |
| Intangible assets |  | 45,528 |  |
| Other long-term assets |  | 906 |  |
| Total assets acquired |  | 110,983 |  |
| Accounts payable |  | (359) |  |
| Employee compensation and benefits |  | (848) |  |
| Current portion of long-term debt |  | (1,264) |  |
| Liabilities held-for-sale |  | (2,581) |  |
| Other current liabilities |  | (10,732) |  |
| Long-term debt |  | (6,254) |  |
| Other long-term liabilities |  | (9,297) |  |
| Total liabilities assumed |  | (31,335) |  |
| Fair value of net assets acquired |  | $ | 79,648 |  |

[0001730168-24-000023:notes:32]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the VMware business. The synergies include certain cost savings, operating efficiencies and other strategic benefits projected to be achieved as a result of the VMware Merger. Goodwill is not deductible for tax purposes.

[0001730168-24-000023:notes:33]
Assets and liabilities held-for-sale primarily included VMware’s end-user computing (“EUC”) business and certain other assets and liabilities, which were not aligned with our strategic objectives. We do not expect to have significant continuing involvement after disposal and have presented the results in discontinued operations. In February 2024, we signed a definitive agreement to sell EUC for approximately $3.8 billion, before working capital adjustments and estimated selling costs. The sale is expected to close in calendar year 2024, subject to customary closing conditions, including regulatory approvals.

[0001730168-24-000023:notes:34]
Our results of continuing operations for the fiscal quarter ended February 4, 2024 included $2,102 million of net revenue attributable to VMware. It is impracticable to determine the effect on net income attributable to VMware as we have integrated a substantial portion of VMware into our ongoing operations. Transaction costs of $220 million related to the VMware Merger for the fiscal quarter ended February 4, 2024 were primarily included in selling, general and administrative expense.

[0001730168-24-000023:notes:35]
Intangible Assets

[0001730168-24-000023:notes:36]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 24,420 |  |  | 8 |
| Customer contracts and related relationships |  | 14,837 |  |  | 8 |
| Trade name |  | 1,150 |  |  | 14 |
| Off-market component of customer contracts |  | 221 |  |  | 2 |
| Total identified finite-lived intangible assets |  | 40,628 |  |  |  |
| In-process research and development |  | 4,900 |  |  | N/A |
| Total identified intangible assets |  | $ | 45,528 |  |  |  |

[0001730168-24-000023:notes:37]
Developed technology relates to products used for VMware cloud foundation, application management, security, application networking and security, and software defined edge. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-24-000023:notes:38]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of VMware. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-24-000023:notes:39]
Trade name relates to the “VMware” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-24-000023:notes:40]
Off-market component of customer contracts relate to rebates and marketing development funds provided to customers prior to the VMware Merger. We valued these contracts based on their remaining unamortized balances, which approximate their fair value. The economic useful life was determined based on the remaining terms of customer contracts.

[0001730168-24-000023:notes:41]
The fair value of in-process research and development (“IPR&D”) was determined using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the IPR&D, less charges representing the contribution of other assets to those cash flows.

[0001730168-24-000023:notes:42]
The following table presents the details of IPR&D by category as of the date of the VMware Merger:

[0001730168-24-000023:notes:43]
| Description |  | IPR&D |  | Percentage of Completion |  | Estimated Cost to Complete |  | Expected Release Date(By Fiscal Year) |
|  |  | (Dollars in millions) |
| VMware cloud foundation July 2024 releases |  | $ | 810 |  |  | 67 | % |  | $ | 38 |  |  | 2024 |
| VMware cloud foundation March 2025 releases |  | $ | 3,000 |  |  | 58 | % |  | $ | 185 |  |  | 2025 |
| VMware cloud foundation July 2025 releases |  | $ | 780 |  |  | 43 | % |  | $ | 65 |  |  | 2025 |
| VMware cloud foundation networking and security virtualization |  | $ | 280 |  |  | 21 | % |  | $ | 59 |  |  | 2024 |
| Application networking and security |  | $ | 30 |  |  | 21 | % |  | $ | 47 |  |  | 2024 |

[0001730168-24-000023:notes:44]
VMware cloud foundation is a flexible and simplified private cloud platform with public cloud extensibility that integrates leading products including compute, storage, networking, and management into a single solution. It enables customers to modernize infrastructure and accelerate developer productivity, with greater resilience and security.

[0001730168-24-000023:notes:45]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the date of the VMware Merger.

[0001730168-24-000023:notes:46]
Unaudited Pro Forma Information

[0001730168-24-000023:notes:47]
The following unaudited pro forma financial information presents combined results of operations for each of the periods presented, as if VMware had been acquired as of the beginning of fiscal year 2023. The unaudited pro forma information includes adjustments to amortization for intangible assets acquired, stock-based compensation expense, interest expense for acquisition financing, amortization of deferred assets and liabilities, and depreciation for property and equipment acquired. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2023 or of the results of our future operations of the combined business.

[0001730168-24-000023:notes:48]
|  |  | Fiscal Quarter Ended |
|  |  | February 4,2024 |  | January 29,2023 |
|  |  | (In millions) |
| Pro forma net revenue |  | $ | 12,523 |  |  | $ | 12,224 |  |
| Pro forma net income |  | $ | 1,615 |  |  | $ | 2,053 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-24-000023:notes:49]
[same as prior period, unchanged from 0001730168-23-000077:notes:34]

[0001730168-24-000023:notes:50]
Cash equivalents included $1,300 million and $1,470 million of time deposits and $2,910 million and $1,650 million of money-market funds as of February 4, 2024 and October 29, 2023, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-24-000023:notes:51]
[same as prior period, unchanged from 0001730168-23-000077:notes:36]

[0001730168-24-000023:notes:52]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,250 million and $1,025 million during the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively.

[0001730168-24-000023:notes:53]
[same as prior period, unchanged from 0001730168-23-000077:notes:38]

[0001730168-24-000023:notes:54]
|  |  | February 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Finished goods |  | $ | 683 |  |  | $ | 676 |  |
| Work-in-process |  | 793 |  |  | 901 |  |
| Raw materials |  | 444 |  |  | 321 |  |
| Total inventory |  | $ | 1,920 |  |  | $ | 1,898 |  |

[0001730168-24-000023:notes:55]
Assets and Liabilities Held-for-Sale

[0001730168-24-000023:notes:56]
In connection with the VMware Merger, we classified VMware’s EUC business and certain other assets and liabilities, which were not aligned with our strategic objectives, as assets and liabilities held-for-sale on November 22, 2023. The carrying value of these assets and liabilities as of February 4, 2024 represented the fair value determined in the preliminary purchase price allocation of the VMware Merger, adjusted for operating activities since the date of the VMware Merger. As of February 4, 2024, the carrying values of these assets, net of liabilities, approximated the expected selling prices.

[0001730168-24-000023:notes:57]
|  |  | February 4, 2024 |
|  |  | EUC |  | Other |  | Total |
|  |  | (In millions) |
| Assets held-for-sale: |  |  |  |  |  |  |
| Goodwill |  | $ | 2,398 |  |  | $ | 8 |  |  | $ | 2,406 |  |
| Intangible assets, net |  | 2,545 |  |  | 244 |  |  | 2,789 |  |
| Other assets |  | 38 |  |  | 701 |  |  | 739 |
| Total assets held-for-sale |  | $ | 4,981 |  |  | $ | 953 |  |  | $ | 5,934 |  |
| Liabilities held-for-sale: |  | $ | 1,686 |  |  | $ | 750 |  |  | $ | 2,436 |  |

[0001730168-24-000023:notes:58]
Discontinued Operations

[0001730168-24-000023:notes:59]
We have presented the operating results of these assets and liabilities held-for-sale in discontinued operations as follows:

[0001730168-24-000023:notes:60]
|  |  | Fiscal Quarter Ended February 4, 2024 |  |  |
|  |  | EUC |  | Other |  | Total |  |  |  |  |
|  |  | (In millions) |
| Net revenue |  | $ | 292 |  |  | $ | 58 |  |  | $ | 350 |  |  |  |  |  |
| Income (loss) from discontinued operations before income taxes |  | $ | 78 |  |  | $ | (20) |  |  | $ | 58 |  |  |  |  |  |
| (Provision for) benefit from income taxes |  | (9) |  |  | 2 |  |  | (7) |  |  |  |  |  |
| Income (loss) from discontinued operations, net of income taxes |  | $ | 69 |  |  | $ | (18) |  |  | $ | 51 |  |  |  |  |  |

[0001730168-24-000023:notes:61]
[same as prior period, unchanged from 0001730168-23-000077:notes:40]

[0001730168-24-000023:notes:62]
|  |  | February 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Assets held-for-sale |  | $ | 5,934 |  |  | $ | — |  |
| Prepaid expenses |  | 1,420 |  |  | 743 |  |
| Other |  | 1,085 |  |  | 863 |  |
| Total other current assets |  | $ | 8,439 |  |  | $ | 1,606 |  |

[0001730168-24-000023:notes:63]
[same as prior period, unchanged from 0001730168-23-000077:notes:42]

[0001730168-24-000023:notes:64]
|  |  | February 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,593 |  |  | $ | 2,487 |  |
| Liabilities held-for-sale |  | 2,436 |  |  | — |  |
| Tax liabilities |  | 1,414 |  |  | 473 |  |
| Interest payable |  | 490 |  |  | 380 |  |
| Other |  | 1,379 |  |  | 312 |  |
| Total other current liabilities |  | $ | 15,312 |  |  | $ | 3,652 |  |

[0001730168-24-000023:notes:65]
[same as prior period, unchanged from 0001730168-23-000077:notes:44]

[0001730168-24-000023:notes:66]
|  |  | February 4,2024 |  | October 29,2023 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,220 |  |  | $ | 2,792 |  |
| Contract liabilities |  | 5,858 |  |  | 299 |  |
| Deferred tax liabilities |  | 2,760 |  |  | 99 |  |
| Other |  | 1,911 |  |  | 657 |  |
| Total other long-term liabilities |  | $ | 13,749 |  |  | $ | 3,847 |  |

[0001730168-24-000023:notes:67]
[same as prior period, unchanged from 0001730168-23-000077:notes:46]

[0001730168-24-000023:notes:68]
|  |  | Fiscal Quarter Ended |
|  |  | February 4,2024 |  | January 29,2023 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 750 |  |  | $ | 361 |  |
| Cash paid for income taxes |  | $ | 904 |  |  | $ | 273 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-24-000023:notes:69]
Goodwill and Intangible Assets
Goodwill

[0001730168-24-000023:notes:70]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |  |
|  |  |  |  |  |  |  |  |  |  | (In millions) |  |
| Balance as of October 29, 2023 |  |  |  |  |  |  |  |  |  | $ | 26,001 |  |  | $ | 17,652 |  |  | $ | 43,653 |  |  |
| VMware acquisition |  |  |  |  |  |  |  |  |  | — |  |  | 53,933 |  |  | 53,933 |  |  |
| Balance as of February 4, 2024 |  |  |  |  |  |  |  |  |  | $ | 26,001 |  |  | $ | 71,585 |  |  | $ | 97,586 |  |  |

[0001730168-24-000023:notes:71]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of February 4, 2024: |  |  |  |  |  |  |
| Purchased technology |  | $ | 37,368 |  |  | $ | (12,102) |  |  | $ | 25,266 |  |
| Customer contracts and related relationships |  | 22,117 |  |  | (6,553) |  |  | 15,564 |  |
| Trade names |  | 1,799 |  |  | (415) |  |  | 1,384 |  |
| Other |  | 177 |  |  | (106) |  |  | 71 |  |
| Intangible assets subject to amortization |  | 61,461 |  |  | (19,176) |  |  | 42,285 |  |
| In-process research and development |  | 4,900 |  |  | — |  |  | 4,900 |  |
| Total |  | $ | 66,361 |  |  | $ | (19,176) |  |  | $ | 47,185 |  |
| As of October 29, 2023: |  |  |  |  |  |  |
| Purchased technology |  | $ | 12,938 |  |  | $ | (10,723) |  |  | $ | 2,215 |  |
| Customer contracts and related relationships |  | 7,059 |  |  | (5,753) |  |  | 1,306 |  |
| Trade names |  | 649 |  |  | (388) |  |  | 261 |  |
| Other |  | 177 |  |  | (102) |  |  | 75 |  |
| Intangible assets subject to amortization |  | 20,823 |  |  | (16,966) |  |  | 3,857 |  |
| In-process research and development |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 20,833 |  |  | $ | (16,966) |  |  | $ | 3,867 |  |

[0001730168-24-000023:notes:72]
Based on the amount of intangible assets subject to amortization as of February 4, 2024, the expected amortization expense was as follows:

[0001730168-24-000023:notes:73]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 6,598 |  |
| 2025 |  | 7,630 |  |
| 2026 |  | 7,237 |  |
| 2027 |  | 6,180 |  |
| 2028 |  | 5,077 |  |
| Thereafter |  | 9,563 |  |
| Total |  | $ | 42,285 |  |

[0001730168-24-000023:notes:74]
[same as prior period, unchanged from 0001730168-23-000077:notes:54]

[0001730168-24-000023:notes:75]
| Amortizable intangible assets: |  | February 4,2024 |
|  |  | (In years) |
| Purchased technology |  | 7 |
| Customer contracts and related relationships |  | 8 |
| Trade names |  | 13 |
| Other |  | 8 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-24-000023:notes:76]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-24-000023:notes:77]
Potentially dilutive shares outstanding include the dilutive effect of unvested RSUs and employee stock purchase plan (“ESPP”) rights (collectively referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-24-000023:notes:78]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for purchasing shares under the ESPP and the amount of stock-based compensation expense for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0001730168-24-000023:notes:79]
[same as prior period, unchanged from 0001730168-23-000077:notes:60]

[0001730168-24-000023:notes:80]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | January 29,2023 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1,274 |  |  | $ | 3,774 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | 51 |  |  | — |  |  |  |  |  |
| Net income |  | $ | 1,325 |  |  | $ | 3,774 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 452 |  | 418 |  |  |  |  |
| Dilutive effect of equity awards |  | 15 |  | 11 |  |  |  |  |
| Weighted-average shares outstanding - diluted |  | 467 |  |  | 429 |  |  |  |  |

[0001730168-24-000023:notes:81]
| Basic income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.82 |  |  | $ | 9.03 |  |  |  |  |  |
| Income per share from discontinued operations |  | 0.11 |  |  | — |  |  |  |  |  |
| Net income per share |  | $ | 2.93 |  |  | $ | 9.03 |  |  |  |  |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.73 |  |  | $ | 8.80 |  |  |  |  |  |
| Income per share from discontinued operations |  | 0.11 |  |  | — |  |  |  |  |  |
| Net income per share |  | $ | 2.84 |  |  | $ | 8.80 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-24-000023:notes:82]
Borrowings

[0001730168-24-000023:notes:83]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2025 |  | 7.11 | % |  | $ | 11,195 |  |  | $ | — |  |
| SOFR plus 1.250% term loan due November 2026 |  | 7.02 | % |  | 11,195 |  |  | — |  |
| SOFR plus 1.625% term loan due November 2028 |  | 7.22 | % |  | 8,000 |  |  | — |  |
|  |  |  |  | 30,390 |  |  | — |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | — |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,861 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
|  |  |  |  | 2,277 |  |  | 2,277 |  |

[0001730168-24-000023:notes:84]
|  |  | Effective Interest Rate |  | February 4,2024 |  | October 29,2023 |
|  |  | (Dollars in millions) |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | — |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 4,194 |  |  | 5,023 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.000% notes due August 2024 |  | 5.80 | % |  | 1,250 |  |  | — |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | 750 |  |  | — |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | — |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | — |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | — |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | — |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | — |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | — |  |
|  |  |  |  | 8,250 |  |  | — |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 13 |  |
| Total principal amount outstanding |  |  |  | $ | 78,521 |  |  | $ | 40,815 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 2,374 |  |  | $ | 1,563 |  |
| Short-term finance lease liabilities |  |  |  | 59 |  |  | 45 |  |
| Total current portion of long-term debt |  |  |  | $ | 2,433 |  |  | $ | 1,608 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 76,147 |  |  | $ | 39,252 |  |
| Long-term finance lease liabilities |  |  |  | 39 |  |  | 4 |  |
| Unamortized discount and issuance costs |  |  |  | (2,718) |  |  | (1,635) |  |
| Total long-term debt |  |  |  | $ | 73,468 |  |  | $ | 37,621 |  |

[0001730168-24-000023:notes:85]
2023 Term Loans

[0001730168-24-000023:notes:86]
On August 15, 2023, we entered into a credit agreement (the “2023 Credit Agreement”), which provided us with the ability to borrow term loans in connection with the VMware Merger. Upon completion of the VMware Merger, we entered an $11,195 million unsecured term A-2 facility (the "Term A-2 Loan”), an $11,195 million unsecured term A-3 facility (the “Term A-3 Loan”), and an $8,000 million unsecured term A-5 facility (the “Term A-5 Loan”, collectively, the “2023 Term Loans”).

[0001730168-24-000023:notes:87]
The term loans under the Term A-2 Loan, Term A-3 Loan and Term A-5 Loan bear interest, payable monthly or every three months at our election, at floating interest rates tied to the Secured Overnight Financing Rate (“SOFR”). The term loans will mature and be payable on the second, third or fifth anniversary, respectively, of the date of the VMware Merger. Subject to the terms of the 2023 Credit Agreement, we are permitted to voluntarily make prepayments of the term loans without penalty. Our obligations under the 2023 Credit Agreement are unsecured and are not guaranteed by any of our subsidiaries.

[0001730168-24-000023:notes:88]
On March 5, 2024, we made a repayment of $2.0 billion on our Term A-2 Loan.

[0001730168-24-000023:notes:89]
Assumed VMware Senior Notes

[0001730168-24-000023:notes:90]
In connection with the VMware Merger, we assumed $8,250 million of VMware’s outstanding senior unsecured notes (the “Assumed VMware Senior Notes”). We may redeem all or a portion of the Assumed VMware Senior Notes at any time, subject to a specified make-whole premium as set forth in the indenture. Upon the occurrence of a change of control and certain downgrades of the ratings, each note holder will have the right to require us to repurchase all or any part of the holders’ notes in cash at a price equal to 101% of the principal amount plus accrued and unpaid interest. Each series of the Assumed VMware Senior Notes pays interest semi-annually.

[0001730168-24-000023:notes:91]
2021 Credit Agreement

[0001730168-24-000023:notes:92]
In January 2021, we entered into a credit agreement (the “2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under our revolving credit facility for revolving loans. Subject to the terms of the 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the 2021 Credit Agreement. We had no borrowings outstanding under our revolving credit facility at either February 4, 2024 or October 29, 2023.

[0001730168-24-000023:notes:93]
Commercial Paper

[0001730168-24-000023:notes:94]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either February 4, 2024 or October 29, 2023.

[0001730168-24-000023:notes:95]
Fair Value of Debt

[0001730168-24-000023:notes:96]
As of February 4, 2024, the estimated aggregate fair value of debt was $73,590 million. The fair value of our senior notes was determined using quoted prices from less active markets. The carrying value of the 2023 Term Loans approximates its fair value as the 2023 Term Loans are carried at a market observable interest rate that resets periodically. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-24-000023:notes:97]
Future Principal Payments of Debt

[0001730168-24-000023:notes:98]
The future scheduled principal payments of debt as of February 4, 2024 were as follows:

[0001730168-24-000023:notes:99]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 1,879 |  |
| 2025 |  | 1,245 |  |
| 2026 |  | 14,347 |  |
| 2027 |  | 16,082 |  |
| 2028 |  | 3,395 |  |
| Thereafter |  | 41,573 |  |
| Total |  | $ | 78,521 |  |

[0001730168-24-000023:notes:100]
As of February 4, 2024 and October 29, 2023, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-24-000023:notes:101]
[same as prior period, unchanged from 0001730168-23-000077:notes:76]

[0001730168-24-000023:notes:102]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | January 29,2023 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 5.25 |  |  | $ | 4.60 |  |  |  |  |  |
| Dividends to common stockholders |  | $ | 2,435 |  |  | $ | 1,926 |  |  |  |  |  |

[0001730168-24-000023:notes:103]
[same as prior period, unchanged from 0001730168-23-000077:notes:79]

[0001730168-24-000023:notes:104]
We repurchased and retired approximately 7 million and 2 million shares of our common stock for $7,176 million and $1,188 million during the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. All $20 billion under our previously authorized stock repurchase programs was utilized prior to expiration on December 31, 2023.

[0001730168-24-000023:notes:105]
VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan

[0001730168-24-000023:notes:106]
In connection with the VMware Merger, we assumed the VMware, Inc. Amended and Restated 2007 Equity and Incentive Plan (the “2007 Plan”) and outstanding unvested RSU awards and PSU awards originally granted by VMware under the 2007 Plan that were held by continuing employees. These assumed awards were converted into approximately 5 million Broadcom RSU awards and will vest in accordance with their original terms, generally over 4 years. Under the 2007 Plan, we may grant stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock, RSUs, and other stock-based or cash-based awards to employees. Equity awards granted under the 2007 Plan following the VMware Merger are expected to be on similar terms and consistent with similar grants made pursuant to our Amended and Restated Broadcom Inc. 2012 Stock Incentive Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of February 4, 2024, 6 million shares remained available for issuance under the 2007 Plan.

[0001730168-24-000023:notes:107]
[same as prior period, unchanged from 0001730168-23-000077:notes:83]

[0001730168-24-000023:notes:108]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | January 29,2023 |  |  |  |  |
|  |  | (In millions) |
| Cost of products sold |  | $ | 28 |  |  | $ | 16 |  |  |  |  |  |
| Cost of subscriptions and services |  | 133 |  |  | 21 |  |  |  |  |  |
| Research and development |  | 863 |  |  | 267 |  |  |  |  |  |
| Selling, general and administrative |  | 548 |  |  | 87 |  |  |  |  |  |
| Total stock-based compensation expense (a) |  | $ | 1,572 |  |  | $ | 391 |  |  |  |  |  |

[0001730168-24-000023:notes:109]
_______________

[0001730168-24-000023:notes:110]
(a) Does not include $70 million of stock-based compensation during the fiscal quarter ended February 4, 2024, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statement of operations.

[0001730168-24-000023:notes:111]
For the fiscal quarter ended February 4, 2024, stock-based compensation expense included $710 million related to equity awards assumed in connection with the VMware Merger. Stock-based compensation expense related to equity awards assumed included a one-time impact from aligning the vesting dates of equity awards assumed with our RSU vesting dates, as well as expenses related to accelerated vesting of certain equity awards held by employees terminated in connection with the VMware Merger.

[0001730168-24-000023:notes:112]
As of February 4, 2024, the total unrecognized compensation cost related to unvested stock-based awards was $12,132 million, which is expected to be recognized over the remaining weighted-average service period of 3.3 years.

[0001730168-24-000023:notes:113]
[same as prior period, unchanged from 0001730168-23-000077:notes:86]

[0001730168-24-000023:notes:114]
[same as prior period, unchanged from 0001730168-23-000077:notes:87]

[0001730168-24-000023:notes:115]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 29, 2023 |  | 22 |  |  | $ | 389.21 |  |  |  |  |  |
| Assumed in VMware Merger |  | 5 |  |  | $ | 968.52 |  |  |  |  |  |
| Granted |  | 5 |  |  | $ | 1,085.69 |  |  |  |  |  |
| Vested |  | (3) |  |  | $ | 478.69 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 838.11 |  |  |  |  |  |
| Balance as of February 4, 2024 |  | 28 |  |  | $ | 583.54 |  |  |  |  |  |

[0001730168-24-000023:notes:116]
The aggregate fair value of time- and market-based RSUs that vested during the fiscal quarter ended February 4, 2024 was $3,064 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-24-000023:notes:117]
Income Taxes
The provision for income taxes was $68 million and $66 million for the fiscal quarters ended February 4, 2024 and January 29, 2023, respectively. In the fiscal quarter ended February 4, 2024, lower uncertain tax benefits recognized were offset by lower income from continuing operations before income taxes and higher excess tax benefits from stock-based awards compared to the fiscal quarter ended January 29, 2023, and a valuation allowance release.

[0001730168-24-000023:notes:118]
As of February 4, 2024, we had $6,162 million of gross unrecognized tax benefits and accrued interest and penalties. Gross unrecognized tax benefits increased by $892 million compared to the balance as of October 29, 2023 primarily due to uncertain tax positions assumed in the VMware Merger. We continue to reevaluate uncertain tax positions and any adjustments to our preliminary estimates are recognized in goodwill, provided we are within the measurement period.

[0001730168-24-000023:notes:119]
It is possible that our existing unrecognized tax benefits may change up to $697 million within the next 12 months as a result of lapses of statutes of limitations for certain audit periods, anticipated closures of audit examinations, and changes in balances related to tax positions to be taken during the current fiscal year.

[0001730168-24-000023:notes:120]
In connection with the VMware Merger, we established $3,653 million of net deferred tax liabilities on the excess of book basis over the tax basis of acquired assets, which included $2,129 million of net deferred tax assets in Ireland that we do not believe, as of the acquisition date, is more-likely-than-not to be realizable. As a result, we recorded a $2,129 million valuation allowance in the preliminary purchase price allocation. The net deferred tax liabilities, assets and valuation allowance are based upon certain assumptions underlying our preliminary purchase price allocation. Upon finalization of the purchase price allocation, additional adjustments to the amount of our net deferred taxes may be required, provided we are within the measurement period.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-24-000023:notes:121]
[same as prior period, unchanged from 0001730168-23-000077:notes:92]

[0001730168-24-000023:notes:122]
[same as prior period, unchanged from 0001730168-23-000077:notes:93]

[0001730168-24-000023:notes:123]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, service provider, and enterprise networking applications. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions, custom touch controllers, and inductive charging solutions for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-24-000023:notes:124]
Infrastructure software. We provide a portfolio of software solutions that enables customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical FC SAN products and related software.

[0001730168-24-000023:notes:125]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as marketing, general and administrative activities, facilities and information technology expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-24-000023:notes:126]
[same as prior period, unchanged from 0001730168-23-000077:notes:97]

[0001730168-24-000023:notes:127]
[same as prior period, unchanged from 0001730168-23-000077:notes:98]

[0001730168-24-000023:notes:128]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the “Summary of Significant Accounting Policies” included in the Annual Report on Form 10-K for fiscal year 2023.

[0001730168-24-000023:notes:129]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | January 29,2023 |  |  |  |  |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 7,390 |  |  | $ | 7,107 |  |  |  |  |  |
| Infrastructure software |  | 4,571 |  |  | 1,808 |  |  |  |  |  |
| Total net revenue |  | $ | 11,961 |  |  | $ | 8,915 |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,116 |  |  | $ | 4,123 |  |  |  |  |  |
| Infrastructure software |  | 2,715 |  |  | 1,307 |  |  |  |  |  |
| Unallocated expenses |  | (4,748) |  |  | (1,327) |  |  |  |  |  |
| Total operating income |  | $ | 2,083 |  |  | $ | 4,103 |  |  |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-24-000023:notes:130]
Commitments and Contingencies
Commitments

[0001730168-24-000023:notes:131]
The following table summarizes contractual obligations and commitments as of February 4, 2024:

[0001730168-24-000023:notes:132]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2024 (remainder) |  | $ | 223 |  |  | $ | 234 |  |
| 2025 |  | 155 |  |  | 300 |  |
| 2026 |  | 23 |  |  | 295 |  |
| 2027 |  | 7 |  |  | 229 |  |
| 2028 |  | 7 |  |  | 183 |  |
| Thereafter |  | — |  |  | 349 |  |
| Total |  | $ | 415 |  |  | $ | 1,590 |  |

[0001730168-24-000023:notes:133]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-24-000023:notes:134]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to information technology and other service agreements.

[0001730168-24-000023:notes:135]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 4, 2024, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,220 million of unrecognized tax benefits and accrued interest and penalties as of February 4, 2024 have been excluded from the table above.

[0001730168-24-000023:notes:136]
Contingencies

[0001730168-24-000023:notes:137]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-24-000023:notes:138]
Lawsuits Relating to VMware Backlog

[0001730168-24-000023:notes:139]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. We cannot reasonably estimate the ultimate outcome and believe a potential loss is not probable and the range of loss is not reasonably estimable. We intend to vigorously defend against this matter.

[0001730168-24-000023:notes:140]
Other Matters

[0001730168-24-000023:notes:141]
We are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-24-000023:notes:142]
Contingency Assessment

[0001730168-24-000023:notes:143]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-24-000023:notes:144]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-24-000023:notes:145]
Other Indemnifications

[0001730168-24-000023:notes:146]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-24-000023:notes:147]
Restructuring and Other Charges
In connection with the VMware Merger, we initiated restructuring activities to integrate the acquired business, align our workforce and improve efficiencies in our operations. We recognized $712 million of restructuring charges primarily related to employee termination costs during the fiscal quarter ended February 4, 2024. We expect these restructuring activities to be substantially completed by the end of fiscal year 2025. These charges were recognized primarily in operating expenses in continuing operations.

[0001730168-24-000023:notes:148]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the fiscal quarter ended February 4, 2024:

[0001730168-24-000023:notes:149]
|  |  | Employee Termination Costs |  | Lease and Impairment Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 29, 2023 |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Restructuring charges (a)(b) |  | 673 |  |  | 39 |  |  | 712 |  |
| Utilization |  | (280) |  |  | (39) |  |  | (319) |  |
| Balance as of February 4, 2024 |  | $ | 395 |  |  | $ | — |  |  | $ | 395 |  |

[0001730168-24-000023:notes:150]
(a) Lease and impairment costs included the write-down of $19 million lease-related assets and $20 million of asset impairments and other costs.

[0001730168-24-000023:notes:151]
(b) Does not include $17 million of restructuring charges related to discontinued operations, which was included in income from discontinued operations, net of income taxes in our condensed consolidated statements of operations.


## us-gaap:SubsequentEventsTextBlock

[0001730168-24-000023:notes:152]
Subsequent Events
Cash Dividends Declared

[0001730168-24-000023:notes:153]
On March 6, 2024, our Board of Directors declared a quarterly cash dividend of $5.25 per share on our common stock, payable on March 29, 2024 to stockholders of record on March 21, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001730168-24-000023:notes:154]
Henry Samueli, Ph.D., our Chairman of the Board, has voting and dispositive power over the shares held by D95GT, LLC. Dr. Samueli disclaims beneficial ownership of the shares held by D95GT, LLC, except to the extent of his pecuniary interest. Dr. Samueli does not have a pecuniary interest in the shares held by the Samueli Foundation, but the Samueli Foundation may be deemed an affiliate of Dr. Samueli. On January 10, 2024, D95GT, LLC and the Samueli Foundation, adopted a trading plan intended to satisfy Rule 10b5-1(c) under the Exchange Act (the “Trading Plan”). Pursuant to the Trading Plan, (i) D95GT, LLC will gift up to $105,976,000 in shares of Broadcom common stock (the “Donated Shares”) to the Samueli Foundation between April 15, 2024 and December 30, 2024 and (ii) the Samueli Foundation will subsequently sell the Donated Shares between April 16, 2024 and December 31, 2024, subject to the volume and price limitations set forth in the Trading Plan. The Trading Plan will expire on December 31, 2024, subject to early termination for certain specified events set forth in the Trading Plan.
