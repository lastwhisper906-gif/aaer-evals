# AVGO 8-K — 0001730168-24-000012 filed 2024-03-07

## item codes, every 8-K on or before 2024-03-14

- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2024-03-14

- none on or before 2024-03-14

## item 2.02 — earnings release, exhibit 99.1

[0001730168-24-000012:8k_2_02:1]
EX-99.1
2
avgo-02042024x8kxex99.htm
EX-99.1

[0001730168-24-000012:8k_2_02:2]
Document

[0001730168-24-000012:8k_2_02:3]
Exhibit 99.1

[0001730168-24-000012:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2024 Financial Results and Quarterly Dividend

[0001730168-24-000012:8k_2_02:5]
•Revenue of $11,961 million for the first quarter, up 34 percent from the prior year period

[0001730168-24-000012:8k_2_02:6]
•Cash from operations of $4,815 million for the first quarter, less capital expenditures of $122 million, resulted in $4,693 million of free cash flow, or 39 percent of revenue

[0001730168-24-000012:8k_2_02:7]
•GAAP net income of $1,325 million for the first quarter; Non-GAAP net income of $5,254 million for the first quarter

[0001730168-24-000012:8k_2_02:8]
•Adjusted EBITDA of $7,156 million for the first quarter, or 60 percent of revenue

[0001730168-24-000012:8k_2_02:9]
•GAAP diluted EPS of $2.84 for the first quarter; Non-GAAP diluted EPS of $10.99 for the first quarter

[0001730168-24-000012:8k_2_02:10]
•Quarterly common stock dividend of $5.25 per share

[0001730168-24-000012:8k_2_02:11]
•Repurchased and eliminated 7.7 million shares for $8,290 million

[0001730168-24-000012:8k_2_02:12]
•Fiscal 2024 annual revenue guidance of approximately $50.0 billion including contribution from VMware, an increase of 40 percent from the prior year period

[0001730168-24-000012:8k_2_02:13]
•Fiscal 2024 annual Adjusted EBITDA guidance of approximately 60 percent of projected revenue (1)

[0001730168-24-000012:8k_2_02:14]
PALO ALTO, Calif. – March 7, 2024 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2024, ended February 4, 2024, provided guidance for its fiscal year 2024 and announced its quarterly dividend.

[0001730168-24-000012:8k_2_02:15]
“We are pleased to have two strong drivers of revenue growth for Broadcom in the first quarter and fiscal year 2024. First, our acquisition of VMware is accelerating revenue growth in our infrastructure software segment, as customers deploy VMware Cloud Foundation. Second, strong demand for our networking products in AI data centers, as well as custom AI accelerators from hyperscalers, are driving growth in our semiconductor segment,” said Hock Tan, President and CEO of Broadcom Inc. “We reiterate our fiscal year 2024 guidance for consolidated revenue of $50 billion and adjusted EBITDA of $30 billion.”

[0001730168-24-000012:8k_2_02:16]
“Consolidated revenue grew 34% year-over-year to $12.0 billion, including the contribution from VMware, and was up 11% year-over-year, excluding VMware. Adjusted EBITDA increased 26% year-over-year to $7.2 billion,” said Kirsten Spears, CFO of Broadcom Inc. “Free cash flow, excluding restructuring in the quarter, continued to be strong at $5.4 billion. We have started to pay down debt, beginning with $3 billion to date in 2024, and expect to continue to pay down debt in fiscal year 2024.”

[0001730168-24-000012:8k_2_02:17]
First Quarter Fiscal Year 2024 Financial Highlights

[0001730168-24-000012:8k_2_02:18]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 24 |  | Q1 23 |  | Change |  | Q1 24 |  | Q1 23 |  | Change |
| Net revenue |  | $ | 11,961 |  |  | $ | 8,915 |  |  | +34 | % |  | $ | 11,961 |  |  | $ | 8,915 |  |  | +34 | % |
| Net income |  | $ | 1,325 |  |  | $ | 3,774 |  |  | -$2,449 |  |  | $ | 5,254 |  |  | $ | 4,483 |  |  | +$771 |  |
| Earnings per common share - diluted |  | $ | 2.84 |  |  | $ | 8.80 |  |  | -$5.96 |  |  | $ | 10.99 |  |  | $ | 10.33 |  |  | +$0.66 |  |

[0001730168-24-000012:8k_2_02:19]
________________________________

[0001730168-24-000012:8k_2_02:20]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-24-000012:8k_2_02:21]
1

[0001730168-24-000012:8k_2_02:22]
| (Dollars in millions) |  | Q1 24 |  | Q1 23 |  | Change |  |
| Cash flow from operations |  | $ | 4,815 |  |  | $ | 4,036 |  |  | +$779 |  |
| Adjusted EBITDA |  | $ | 7,156 |  |  | $ | 5,678 |  |  | +$1,478 |  |
| Free cash flow |  | $ | 4,693 |  |  | $ | 3,933 |  |  | +$760 |  |

[0001730168-24-000012:8k_2_02:23]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 24 |  |  |  | Q1 23 |  | Change |  |
| Semiconductor solutions |  | $ | 7,390 |  |  | 62 | % |  |  |  |  |  |  | $ | 7,107 |  |  | 80 | % |  | +4 | % |  |
| Infrastructure software |  | 4,571 |  |  | 38 |  |  |  |  |  |  |  | 1,808 |  |  | 20 |  |  | +153 | % |  |
| Total net revenue |  | $ | 11,961 |  |  | 100 | % |  |  |  |  |  |  | $ | 8,915 |  |  | 100 | % |  |  |  |  |

[0001730168-24-000012:8k_2_02:24]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $11,864 million, compared to $14,189 million at the end of the prior quarter.

[0001730168-24-000012:8k_2_02:25]
During the first fiscal quarter, the Company generated $4,815 million in cash from operations and spent $122 million on capital expenditures. The Company spent $8,290 million on share repurchases and eliminations, consisting of $7,176 million in repurchases of 6.7 million shares and $1,114 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 1.0 million shares withheld).

[0001730168-24-000012:8k_2_02:26]
On December 29, 2023, the Company paid a cash dividend of $5.25 per share, totaling $2,435 million.

[0001730168-24-000012:8k_2_02:27]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-24-000012:8k_2_02:28]
Fiscal Year 2024 Business Outlook

[0001730168-24-000012:8k_2_02:29]
Based on current business trends and conditions, the outlook for continuing operations for fiscal year 2024, ending November 3, 2024, including the contribution from VMware, is expected to be as follows:

[0001730168-24-000012:8k_2_02:30]
•Fiscal year 2024 revenue guidance of approximately $50.0 billion; and

[0001730168-24-000012:8k_2_02:31]
•Fiscal year 2024 Adjusted EBITDA guidance of approximately 60 percent of projected revenue.

[0001730168-24-000012:8k_2_02:32]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000012:8k_2_02:33]
2

[0001730168-24-000012:8k_2_02:34]
Quarterly Dividends

[0001730168-24-000012:8k_2_02:35]
The Company’s Board of Directors has approved a quarterly cash dividend of $5.25 per share. The dividend is payable on March 29, 2024 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 21, 2024.

[0001730168-24-000012:8k_2_02:36]
Financial Results Conference Call

[0001730168-24-000012:8k_2_02:37]
Broadcom Inc. will host a conference call to review its financial results for the first quarter of fiscal year 2024 and to discuss the business outlook today at 2:15 p.m. Pacific Time.

[0001730168-24-000012:8k_2_02:38]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-24-000012:8k_2_02:39]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BI6ca5b6701f3e42dfa51a334fd6672810. Upon registering, a link to the dial-in number and unique PIN will be emailed to the registrant.

[0001730168-24-000012:8k_2_02:40]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-24-000012:8k_2_02:41]
Non-GAAP Financial Measures

[0001730168-24-000012:8k_2_02:42]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-24-000012:8k_2_02:43]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-24-000012:8k_2_02:44]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right

[0001730168-24-000012:8k_2_02:45]
to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-24-000012:8k_2_02:46]
About Broadcom

[0001730168-24-000012:8k_2_02:47]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops, and supplies a broad range of semiconductor, enterprise software and security solutions. Broadcom’s category-leading product portfolio serves critical markets including cloud, data center, networking, broadband, wireless, storage, industrial, and enterprise software. Our solutions include service provider and enterprise networking and storage, mobile device and broadband connectivity, mainframe, cybersecurity, and private and hybrid cloud infrastructure. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, go to www.broadcom.com.

[0001730168-24-000012:8k_2_02:48]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-24-000012:8k_2_02:49]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our acquisition of VMware, Inc., including employee retention, unexpected costs, charges or expenses, and our ability to successfully integrate VMware’s business and realize the expected benefits; any acquisitions or dispositions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; dependence on and risks associated with distributors and resellers of our products; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cyber security threats and a breach of security systems; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; involvement in legal proceedings; demand for our data center virtualization products; customer and market acceptance of our products and services;

[0001730168-24-000012:8k_2_02:50]
4

[0001730168-24-000012:8k_2_02:51]
compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third-party software used in our products; use of open source software in our products; ability of our software products to manage and secure IT infrastructures and environments; sales to government customers; our ability to manage products and services lifecycles; quarterly and annual fluctuations in operating results; our competitive performance; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs, our ability to maintain tax concessions in certain jurisdictions and potential tax liabilities as a result of acquiring VMware; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-24-000012:8k_2_02:52]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-24-000012:8k_2_02:53]
Contact:

[0001730168-24-000012:8k_2_02:54]
Ji Yoo

[0001730168-24-000012:8k_2_02:55]
Broadcom Inc.

[0001730168-24-000012:8k_2_02:56]
Investor Relations

[0001730168-24-000012:8k_2_02:57]
650-427-6000

[0001730168-24-000012:8k_2_02:58]
investor.relations@broadcom.com

[0001730168-24-000012:8k_2_02:59]
(AVGO-Q)

[0001730168-24-000012:8k_2_02:60]
5

[0001730168-24-000012:8k_2_02:61]
BROADCOM INC.

[0001730168-24-000012:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-24-000012:8k_2_02:63]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-24-000012:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | October 29,2023 |  | January 29,2023 |  |  |  |  |
| Net revenue |  | $ | 11,961 |  |  | $ | 9,295 |  |  | $ | 8,915 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 3,114 |  |  | 2,449 |  |  | 2,374 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,380 |  |  | 438 |  |  | 535 |  |  |  |  |  |
| Restructuring charges |  | 92 |  |  | 1 |  |  | 2 |  |  |  |  |  |
| Total cost of revenue |  | 4,586 |  |  | 2,888 |  |  | 2,911 |  |  |  |  |  |
| Gross margin |  | 7,375 |  |  | 6,407 |  |  | 6,004 |  |  |  |  |  |
| Research and development |  | 2,308 |  |  | 1,388 |  |  | 1,195 |  |  |  |  |  |
| Selling, general and administrative |  | 1,572 |  |  | 418 |  |  | 348 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 792 |  |  | 348 |  |  | 348 |  |  |  |  |  |
| Restructuring and other charges |  | 620 |  |  | 13 |  |  | 10 |  |  |  |  |  |
| Total operating expenses |  | 5,292 |  |  | 2,167 |  |  | 1,901 |  |  |  |  |  |
| Operating income |  | 2,083 |  |  | 4,240 |  |  | 4,103 |  |  |  |  |  |
| Interest expense |  | (926) |  |  | (405) |  |  | (406) |  |  |  |  |  |
| Other income, net |  | 185 |  |  | 132 |  |  | 143 |  |  |  |  |  |
| Income before income taxes |  | 1,342 |  |  | 3,967 |  |  | 3,840 |  |  |  |  |  |
| Provision for income taxes |  | 68 |  |  | 443 |  |  | 66 |  |  |  |  |  |
| Income from continuing operations |  | 1,274 |  |  | 3,524 |  |  | 3,774 |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | 51 |  |  | — |  |  | — |  |  |  |  |  |
| Net income |  | $ | 1,325 |  |  | $ | 3,524 |  |  | $ | 3,774 |  |  |  |  |  |
| Basic income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.82 |  |  | $ | 8.53 |  |  | $ | 9.03 |  |  |  |  |  |
| Income per share from discontinued operations |  | 0.11 |  |  | — |  |  | — |  |  |  |  |  |
| Net income per share |  | $ | 2.93 |  |  | $ | 8.53 |  |  | $ | 9.03 |  |  |  |  |  |
| Diluted income per share: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 2.73 |  |  | $ | 8.25 |  |  | $ | 8.80 |  |  |  |  |  |
| Income per share from discontinued operations |  | 0.11 |  |  | — |  |  | — |  |  |  |  |  |
| Net income per share |  | $ | 2.84 |  |  | $ | 8.25 |  |  | $ | 8.80 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 452 |  |  | 413 |  |  | 418 |  |  |  |  |  |
| Diluted |  | 467 |  |  | 427 |  |  | 429 |  |  |  |  |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 161 |  |  | $ | 62 |  |  | $ | 37 |  |  |  |  |  |
| Research and development |  | 863 |  |  | 448 |  |  | 267 |  |  |  |  |  |
| Selling, general and administrative |  | 548 |  |  | 128 |  |  | 87 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 1,572 |  |  | $ | 638 |  |  | $ | 391 |  |  |  |  |  |

[0001730168-24-000012:8k_2_02:65]
BROADCOM INC.

[0001730168-24-000012:8k_2_02:66]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-24-000012:8k_2_02:67]
(IN MILLIONS)

[0001730168-24-000012:8k_2_02:68]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | October 29,2023 |  | January 29,2023 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 7,375 |  |  | $ | 6,407 |  |  | $ | 6,004 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,380 |  |  | 438 |  |  | 535 |  |  |  |  |  |
| Stock-based compensation expense |  | 161 |  |  | 62 |  |  | 37 |  |  |  |  |  |
| Restructuring charges |  | 92 |  |  | 1 |  |  | 2 |  |  |  |  |  |
| Acquisition-related costs |  | 6 |  |  | — |  |  | — |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 9,014 |  |  | $ | 6,908 |  |  | $ | 6,578 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 2,308 |  |  | $ | 1,388 |  |  | $ | 1,195 |  |  |  |  |  |
| Stock-based compensation expense |  | 863 |  |  | 448 |  |  | 267 |  |  |  |  |  |
| Acquisition-related costs |  | 1 |  |  | — |  |  | (1) |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 1,444 |  |  | $ | 940 |  |  | $ | 929 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,572 |  |  | $ | 418 |  |  | $ | 348 |  |  |  |  |  |
| Stock-based compensation expense |  | 548 |  |  | 128 |  |  | 87 |  |  |  |  |  |
| Acquisition-related costs |  | 285 |  |  | 69 |  |  | 42 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 739 |  |  | $ | 221 |  |  | $ | 219 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 5,292 |  |  | $ | 2,167 |  |  | $ | 1,901 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 792 |  |  | 348 |  |  | 348 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,411 |  |  | 576 |  |  | 354 |  |  |  |  |  |
| Restructuring and other charges |  | 620 |  |  | 13 |  |  | 10 |  |  |  |  |  |
| Acquisition-related costs |  | 286 |  |  | 69 |  |  | 41 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,183 |  |  | $ | 1,161 |  |  | $ | 1,148 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 2,083 |  |  | $ | 4,240 |  |  | $ | 4,103 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,172 |  |  | 786 |  |  | 883 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,572 |  |  | 638 |  |  | 391 |  |  |  |  |  |
| Restructuring and other charges |  | 712 |  |  | 14 |  |  | 12 |  |  |  |  |  |
| Acquisition-related costs |  | 292 |  |  | 69 |  |  | 41 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 6,831 |  |  | $ | 5,747 |  |  | $ | 5,430 |  |  |  |  |  |
| Other income, net on GAAP basis |  | $ | 185 |  |  | $ | 132 |  |  | $ | 143 |  |  |  |  |  |
| (Gains) losses on investments |  | (33) |  |  | 24 |  |  | (44) |  |  |  |  |  |
| Other |  | — |  |  | (1) |  |  | — |  |  |  |  |  |
| Other income, net on non-GAAP basis |  | $ | 152 |  |  | $ | 155 |  |  | $ | 99 |  |  |  |  |  |
| Provision for income taxes on GAAP basis |  | $ | 68 |  |  | $ | 443 |  |  | $ | 66 |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | 735 |  |  | 244 |  |  | 574 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 803 |  |  | $ | 687 |  |  | $ | 640 |  |  |  |  |  |

[0001730168-24-000012:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | October 29,2023 |  | January 29,2023 |  |  |  |  |
| Net income on GAAP basis |  | $ | 1,325 |  |  | $ | 3,524 |  |  | $ | 3,774 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,172 |  |  | 786 |  |  | 883 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,572 |  |  | 638 |  |  | 391 |  |  |  |  |  |
| Restructuring and other charges |  | 712 |  |  | 14 |  |  | 12 |  |  |  |  |  |
| Acquisition-related costs |  | 292 |  |  | 69 |  |  | 41 |  |  |  |  |  |
| (Gains) losses on investments |  | (33) |  |  | 24 |  |  | (44) |  |  |  |  |  |
| Other |  | — |  |  | (1) |  |  | — |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (735) |  |  | (244) |  |  | (574) |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | (51) |  |  | — |  |  | — |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 5,254 |  |  | $ | 4,810 |  |  | $ | 4,483 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 1,325 |  |  | $ | 3,524 |  |  | $ | 3,774 |  |  |  |  |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 2,172 |  |  | 786 |  |  | 883 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,572 |  |  | 638 |  |  | 391 |  |  |  |  |  |
| Restructuring and other charges |  | 712 |  |  | 14 |  |  | 12 |  |  |  |  |  |
| Acquisition-related costs |  | 292 |  |  | 69 |  |  | 41 |  |  |  |  |  |
| (Gains) losses on investments |  | (33) |  |  | 24 |  |  | (44) |  |  |  |  |  |
| Other |  | — |  |  | (1) |  |  | — |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments |  | (735) |  |  | (244) |  |  | (574) |  |  |  |  |  |
| Income from discontinued operations, net of income taxes |  | (51) |  |  | — |  |  | — |  |  |  |  |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 926 |  |  | 405 |  |  | 406 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 803 |  |  | 687 |  |  | 640 |  |  |  |  |  |
| Depreciation |  | 139 |  |  | 124 |  |  | 127 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 34 |  |  | 22 |  |  | 22 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 7,156 |  |  | $ | 6,048 |  |  | $ | 5,678 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 467 |  |  | 427 |  |  | 429 |  |  |  |  |  |
| Non-GAAP adjustment (1) |  | 11 |  |  | 8 |  |  | 5 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 478 |  |  | 435 |  |  | 434 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 4,815 |  |  | $ | 4,828 |  |  | $ | 4,036 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (105) |  |  | (103) |  |  |  |  |  |
| Free cash flow |  | $ | 4,693 |  |  | $ | 4,723 |  |  | $ | 3,933 |  |  |  |  |  |

[0001730168-24-000012:8k_2_02:70]
|  |  | Fiscal Quarter Ending |
|  |  | May 5, |
| Expected average diluted share count: |  | 2024 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 480 |  |
| Non-GAAP adjustment (1) |  | 12 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 492 |  |

[0001730168-24-000012:8k_2_02:71]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |

[0001730168-24-000012:8k_2_02:72]
BROADCOM INC.

[0001730168-24-000012:8k_2_02:73]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-24-000012:8k_2_02:74]
(IN MILLIONS)

[0001730168-24-000012:8k_2_02:75]
|  |  | February 4,2024 |  | October 29,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,864 |  |  | $ | 14,189 |  |
| Trade accounts receivable, net |  | 4,969 |  |  | 3,154 |  |
| Inventory |  | 1,920 |  |  | 1,898 |  |
| Other current assets |  | 8,439 |  |  | 1,606 |  |
| Total current assets |  | 27,192 |  |  | 20,847 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,662 |  |  | 2,154 |  |
| Goodwill |  | 97,586 |  |  | 43,653 |  |
| Intangible assets, net |  | 47,185 |  |  | 3,867 |  |
| Other long-term assets |  | 3,245 |  |  | 2,340 |  |
| Total assets |  | $ | 177,870 |  |  | $ | 72,861 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,496 |  |  | $ | 1,210 |  |
| Employee compensation and benefits |  | 1,128 |  |  | 935 |  |
| Current portion of long-term debt |  | 2,433 |  |  | 1,608 |  |
| Other current liabilities |  | 15,312 |  |  | 3,652 |  |
| Total current liabilities |  | 20,369 |  |  | 7,405 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 73,468 |  |  | 37,621 |  |
| Other long-term liabilities |  | 13,749 |  |  | 3,847 |  |
| Total liabilities |  | 107,586 |  |  | 48,873 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 70,077 |  |  | 21,099 |  |
| Retained earnings |  | — |  |  | 2,682 |  |
| Accumulated other comprehensive income |  | 207 |  |  | 207 |  |
| Total stockholders' equity |  | 70,284 |  |  | 23,988 |  |
| Total liabilities and equity |  | $ | 177,870 |  |  | $ | 72,861 |  |

[0001730168-24-000012:8k_2_02:76]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 4,2024 |  | October 29,2023 |  | January 29,2023 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,325 |  |  | $ | 3,524 |  |  | $ | 3,774 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,206 |  |  | 808 |  |  | 905 |  |  |  |  |  |
| Depreciation |  | 139 |  |  | 124 |  |  | 127 |  |  |  |  |  |
| Stock-based compensation |  | 1,582 |  |  | 638 |  |  | 391 |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | (294) |  |  | 639 |  |  | (573) |  |  |  |  |  |
| Non-cash interest expense |  | 102 |  |  | 34 |  |  | 32 |  |  |  |  |  |
| Other |  | 38 |  |  | 27 |  |  | (39) |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 1,756 |  |  | (231) |  |  | (276) |  |  |  |  |  |
| Inventory |  | (14) |  |  | (56) |  |  | 26 |  |  |  |  |  |
| Accounts payable |  | (74) |  |  | 215 |  |  | (80) |  |  |  |  |  |
| Employee compensation and benefits |  | (660) |  |  | 103 |  |  | (657) |  |  |  |  |  |
| Other current assets and current liabilities |  | (2,182) |  |  | (694) |  |  | 570 |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | 891 |  |  | (303) |  |  | (164) |  |  |  |  |  |
| Net cash provided by operating activities |  | 4,815 |  |  | 4,828 |  |  | 4,036 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (25,416) |  |  | (36) |  |  | — |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (105) |  |  | (103) |  |  |  |  |  |
| Purchases of investments |  | (13) |  |  | (58) |  |  | — |  |  |  |  |  |
| Sales of investments |  | 89 |  |  | 154 |  |  | — |  |  |  |  |  |
| Other |  | (15) |  |  | (79) |  |  | — |  |  |  |  |  |
| Net cash used in investing activities |  | (25,477) |  |  | (124) |  |  | (103) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 30,010 |  |  | — |  |  | — |  |  |  |  |  |
| Payments on debt obligations |  | (934) |  |  | (143) |  |  | (260) |  |  |  |  |  |
| Payments of dividends |  | (2,435) |  |  | (1,904) |  |  | (1,926) |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  | (7,176) |  |  | (123) |  |  | (1,188) |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (1,114) |  |  | (454) |  |  | (333) |  |  |  |  |  |
| Issuance of common stock |  | — |  |  | 59 |  |  | — |  |  |  |  |  |
| Other |  | (14) |  |  | (5) |  |  | 5 |  |  |  |  |  |
| Net cash provided by (used in) financing activities |  | 18,337 |  |  | (2,570) |  |  | (3,702) |  |  |  |  |  |
| Net change in cash and cash equivalents |  | (2,325) |  |  | 2,134 |  |  | 231 |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 14,189 |  |  | 12,055 |  |  | 12,416 |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 11,864 |  |  | $ | 14,189 |  |  | $ | 12,647 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 750 |  |  | $ | 397 |  |  | $ | 361 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 904 |  |  | $ | 191 |  |  | $ | 273 |  |  |  |  |  |
