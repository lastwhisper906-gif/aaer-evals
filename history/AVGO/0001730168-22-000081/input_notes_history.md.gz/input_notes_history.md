# AVGO note change history — 0001730168-22-000029 → 0001730168-22-000081


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-06-09):
[0001730168-22-000081:note_history:1]
The following table summarizes contractual obligations and commitments as of May 1, 2022 that materially changed from the end of fiscal year 2021:
  (was, 2022-03-10, similarity 0.9787):
[0001730168-22-000029:note_history:1]
The following table summarizes contractual obligations and commitments as of January 30, 2022 that materially changed from the end of fiscal year 2021:

- changed (2022-06-09):
[0001730168-22-000081:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 66 |  |  | $ | 609 |  |
| 2023 |  | 174 |  |  | 189 |  |
| 2024 |  | 130 |  |  | 131 |  |
| 2025 |  | 71 |  |  | 26 |  |
| 2026 |  | 2 |  |  | 48 |  |
| Thereafter |  | — |  |  | 1 |  |
| Total |  | $ | 443 |  |  | $ | 1,004 |  |
  (was, 2022-03-10, similarity 0.9966):
[0001730168-22-000029:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 126 |  |  | $ | 698 |  |
| 2023 |  | 146 |  |  | 181 |  |
| 2024 |  | 80 |  |  | 122 |  |
| 2025 |  | 60 |  |  | 25 |  |
| 2026 |  | — |  |  | 49 |  |
| Thereafter |  | — |  |  | 2 |  |
| Total |  | $ | 412 |  |  | $ | 1,077 |  |

- changed (2022-06-09):
[0001730168-22-000081:note_history:3]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT, human resources, and other service agreements.
  (was, 2022-03-10, similarity 0.9965):
[0001730168-22-000029:note_history:3]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

- changed (2022-06-09):
[0001730168-22-000081:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 1, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,339 million of unrecognized tax benefits and accrued interest and penalties as of May 1, 2022 have been excluded from the table above.
  (was, 2022-03-10, similarity 0.8641):
[0001730168-22-000029:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at January 30, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,366 million of unrecognized tax benefits and accrued interest and penalties classified within other long-term liabilities on our condensed consolidated balance sheet as of January 30, 2022 have been excluded from the table above.

- changed (2022-06-09):
[0001730168-22-000081:note_history:5]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. The Federal Circuit Court issued its decision on February 4, 2022. While the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. The Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court.
  (was, 2022-03-10, similarity 0.7363):
[0001730168-22-000029:note_history:5]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District

- changed (2022-06-09):
[0001730168-22-000081:note_history:6]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a retrial at the lower court and further appeals) could significantly change the assessment of damages. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards.
  (was, 2022-03-10, similarity 0.6139):
[0001730168-22-000029:note_history:6]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We do not believe a material loss is probable or estimable at this time. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a possible rehearing by the Federal Circuit Court, retrial at the lower court and further appeals) could significantly change the assessment of damages.

- removed (2022-06-09):
[0001730168-22-000029:note_history:7]
Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. The Federal Circuit Court issued its decision on February 4, 2022. While the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. Broadcom and Apple anticipate filing a petition for rehearing with the Federal Circuit Court by April 6, 2022.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-06-09):
[0001730168-22-000081:note_history:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ended on May 1, 2022 and the third quarter ends on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.
  (was, 2022-03-10, similarity 0.9966):
[0001730168-22-000029:note_history:8]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ends on May 1, 2022 and the third quarter ends on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.

- changed (2022-06-09):
[0001730168-22-000081:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for each of the fiscal quarter and two fiscal quarters ended May 1, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.
  (was, 2022-03-10, similarity 0.9745):
[0001730168-22-000029:note_history:9]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended January 30, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.

- changed (2022-06-09):
[0001730168-22-000081:note_history:10]
Recently Adopted Accounting Guidance
In October 2021, the Financial Accounting Standards Board issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not materially impact our condensed consolidated financial statements.
  (was, 2022-03-10, similarity 0.9914):
[0001730168-22-000029:note_history:10]
Recently Adopted Accounting Guidance
In October 2021, the Financial Accounting Standards Boards issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not impact our condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-09):
[0001730168-22-000081:note_history:11]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
  (was, 2022-03-10, similarity 0.712):
[0001730168-22-000029:note_history:11]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | $ | 3,250 |  |  | $ | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,965 |  |  | 1,965 |  |
|  |  |  |  | 2,717 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,679 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,684 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,020 |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 1,086 |  |  | 1,086 |  |
|  |  |  |  | 2,106 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 944 |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,958 |  |  | 1,958 |  |
|  |  |  |  | 3,524 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:12]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 33 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 302 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 29 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,823) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,164 |  |  | $ | 39,440 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:13]
April 2022 Senior Notes

- added (2022-06-09):
[0001730168-22-000081:note_history:14]
In April 2022, we issued $750 million of 4.000% senior unsecured notes due 2029 and $1,200 million of 4.150% senior unsecured notes due 2032. Using the net proceeds, we redeemed the outstanding balance of $1,020 million of our 4.700% notes due 2025 and $944 million of our 4.250% notes due 2026. As a result of these redemptions, we incurred premiums of $85 million and wrote off $15 million of unamortized discount and issuance costs. Both amounts were included in interest expense.

- added (2022-06-09):
[0001730168-22-000081:note_history:15]
In April 2022, we issued $2,500 million of 4.926% new senior unsecured notes due 2037 in exchange for $2,502 million of certain of our outstanding notes maturing between 2027 and 2030. We paid premiums of $47 million, which were included in unamortized discount and issuance costs. The 4.926% notes due 2037, the 4.000% notes due 2029 and the 4.150% notes due 2032 are collectively referred as the “April 2022 Senior Notes”.

- added (2022-06-09):
[0001730168-22-000081:note_history:16]
We may redeem or purchase, in whole or in part, any of the April 2022 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the April 2022 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

- changed (2022-06-09):
[0001730168-22-000081:note_history:17]
Credit Agreement
  (was, 2022-03-10, similarity 0.7619):
[0001730168-22-000029:note_history:17]
January 2021 Credit Agreement

- changed (2022-06-09):
[0001730168-22-000081:note_history:18]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either May 1, 2022 or October 31, 2021.
  (was, 2022-03-10, similarity 0.9767):
[0001730168-22-000029:note_history:18]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either January 30, 2022 or October 31, 2021.

- changed (2022-06-09):
[0001730168-22-000081:note_history:19]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either May 1, 2022 or October 31, 2021.
  (was, 2022-03-10, similarity 0.9074):
[0001730168-22-000029:note_history:19]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. We had no Commercial Paper outstanding at either January 30, 2022 or October 31, 2021.

- changed (2022-06-09):
[0001730168-22-000081:note_history:20]
As of May 1, 2022, the estimated aggregate fair value of debt was $36,521 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2022-03-10, similarity 0.9832):
[0001730168-22-000029:note_history:20]
As of January 30, 2022, the estimated aggregate fair value of debt was $41,558 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2022-06-09):
[0001730168-22-000081:note_history:21]
The future scheduled principal payments of debt as of May 1, 2022 were as follows:
  (was, 2022-03-10, similarity 0.9625):
[0001730168-22-000029:note_history:21]
The future scheduled principal payments of debt as of January 30, 2022 were as follows:

- changed (2022-06-09):
[0001730168-22-000081:note_history:22]
As of May 1, 2022 and October 31, 2021, we accrued interest payable of $332 million and $282 million, respectively, and were in compliance with all debt covenants.
  (was, 2022-03-10, similarity 0.9801):
[0001730168-22-000029:note_history:22]
As of January 30, 2022 and October 31, 2021, we accrued interest payable of $417 million and $282 million, respectively, and were in compliance with all debt covenants.

- removed (2022-06-09):
[0001730168-22-000029:note_history:23]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 265 |  |  | 265 |  |
|  |  |  |  | 408 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,244 |  |  | 41,499 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,803) |  |  | (1,834) |  |
| Total debt |  |  |  | $ | 39,441 |  |  | $ | 39,665 |  |

- removed (2022-06-09):
[0001730168-22-000029:note_history:24]
As of January 30, 2022 and October 31, 2021, short-term finance lease liabilities of $31 million and $26 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $33 million and $39 million, respectively, were included in long-term debt.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-09):
[0001730168-22-000081:note_history:25]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
  (was, 2022-03-10, similarity 0.712):
[0001730168-22-000029:note_history:25]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | $ | 3,250 |  |  | $ | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,965 |  |  | 1,965 |  |
|  |  |  |  | 2,717 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,679 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,684 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,020 |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 1,086 |  |  | 1,086 |  |
|  |  |  |  | 2,106 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 944 |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,958 |  |  | 1,958 |  |
|  |  |  |  | 3,524 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:26]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 33 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 302 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 29 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,823) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,164 |  |  | $ | 39,440 |  |

- removed (2022-06-09):
[0001730168-22-000029:note_history:27]
|  |  | Effective Interest Rate |  | January 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 265 |  |  | 265 |  |
|  |  |  |  | 408 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,244 |  |  | 41,499 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,803) |  |  | (1,834) |  |
| Total debt |  |  |  | $ | 39,441 |  |  | $ | 39,665 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: title_similarity, score: 0.9467

- changed (2022-06-09):
[0001730168-22-000081:note_history:28]
The future scheduled principal payments of debt as of May 1, 2022 were as follows:
  (was, 2022-03-10, similarity 0.9625):
[0001730168-22-000029:note_history:28]
The future scheduled principal payments of debt as of January 30, 2022 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-06-09):
[0001730168-22-000081:note_history:29]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:30]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:31]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:32]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- removed (2022-06-09):
[0001730168-22-000029:note_history:33]
|  |  | Fiscal Quarter Ended January 30, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 548 |  |  | $ | 4,984 |  |  | $ | 521 |  |  | $ | 6,053 |  |
| Subscriptions and services (a) |  | 1,109 |  |  | 128 |  |  | 416 |  |  | 1,653 |  |
| Total |  | $ | 1,657 |  |  | $ | 5,112 |  |  | $ | 937 |  |  | $ | 7,706 |  |

- removed (2022-06-09):
[0001730168-22-000029:note_history:34]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-06-09):
[0001730168-22-000081:note_history:35]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:36]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:37]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- added (2022-06-09):
[0001730168-22-000081:note_history:38]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- changed (2022-06-09):
[0001730168-22-000081:note_history:39]
|  |  | May 1,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 79 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 4,099 |  |  | $ | 3,185 |  |
  (was, 2022-03-10, similarity 0.9789):
[0001730168-22-000029:note_history:39]
|  |  | January 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 105 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,545 |  |  | $ | 3,185 |  |

- changed (2022-06-09):
[0001730168-22-000081:note_history:40]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 1, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,974 million. The amount of revenue recognized during the two fiscal quarters ended May 2, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,853 million.
  (was, 2022-03-10, similarity 0.9788):
[0001730168-22-000029:note_history:40]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended January 30, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,216 million. The amount of revenue recognized during the fiscal quarter ended January 31, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,132 million.

- changed (2022-06-09):
[0001730168-22-000081:note_history:41]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of May 1, 2022 were approximately $16.5 billion. We expect approximately 31% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2022-03-10, similarity 0.9944):
[0001730168-22-000029:note_history:41]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of January 30, 2022 were approximately $15.3 billion. We expect approximately 28% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2022-06-09):
[0001730168-22-000029:note_history:42]
|  |  | Fiscal Quarter Ended January 30, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 548 |  |  | $ | 4,984 |  |  | $ | 521 |  |  | $ | 6,053 |  |
| Subscriptions and services (a) |  | 1,109 |  |  | 128 |  |  | 416 |  |  | 1,653 |  |
| Total |  | $ | 1,657 |  |  | $ | 5,112 |  |  | $ | 937 |  |  | $ | 7,706 |  |

- removed (2022-06-09):
[0001730168-22-000029:note_history:43]
|  |  | Fiscal Quarter Ended January 31, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 390 |  |  | $ | 4,320 |  |  | $ | 371 |  |  | $ | 5,081 |  |
| Subscriptions and services (a) |  | 1,004 |  |  | 191 |  |  | 379 |  |  | 1,574 |  |
| Total |  | $ | 1,394 |  |  | $ | 4,511 |  |  | $ | 750 |  |  | $ | 6,655 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-06-09):
[0001730168-22-000081:note_history:44]
On May 25, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2022 to stockholders of record on June 15, 2022.
  (was, 2022-03-10, similarity 0.9421):
[0001730168-22-000029:note_history:44]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2022 to stockholders of record on March 15, 2022.

- changed (2022-06-09):
[0001730168-22-000081:note_history:45]
On May 25, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on June 30, 2022 to stockholders of record on June 22, 2022.
  (was, 2022-03-10, similarity 0.9333):
[0001730168-22-000029:note_history:45]
On March 2, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on March 31, 2022 to stockholders of record on March 22, 2022.

- added (2022-06-09):
[0001730168-22-000081:note_history:46]
Pending Acquisition of VMware, Inc.

- added (2022-06-09):
[0001730168-22-000081:note_history:47]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. In addition, we will assume $8 billion of VMware net debt.

- added (2022-06-09):
[0001730168-22-000081:note_history:48]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

- added (2022-06-09):
[0001730168-22-000081:note_history:49]
We will assume all outstanding VMware restricted stock unit awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into restricted stock unit awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and restricted stock unit awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

- added (2022-06-09):
[0001730168-22-000081:note_history:50]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

- added (2022-06-09):
[0001730168-22-000081:note_history:51]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

- added (2022-06-09):
[0001730168-22-000081:note_history:52]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023, is subject to satisfaction or waiver of customary closing conditions, including adoption of the VMware Merger Agreement by VMware stockholders, the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976, and clearance under the antitrust laws of the European Union and certain other jurisdictions, and the effectiveness of a registration statement on Form S-4 to be filed by us. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion (or, in certain circumstances, VMware’s termination fee would be $750 million).
