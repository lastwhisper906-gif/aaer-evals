# AVGO 8-K — 0001193125-22-160304 filed 2022-05-26

## item codes, every 8-K on or before 2022-06-09

- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2022-06-09

- none on or before 2022-06-09

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-160304:8k_2_02:1]
EX-99.1
2
d262320dex991.htm
EX-99.1

[0001193125-22-160304:8k_2_02:2]
EX-99.1

[0001193125-22-160304:8k_2_02:3]
Exhibit 99.1

[0001193125-22-160304:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2022 Financial Results and

[0001193125-22-160304:8k_2_02:5]
Quarterly Dividends

[0001193125-22-160304:8k_2_02:6]
|  | • |  | Revenue of $8,103 million for the second quarter, up 23 percent from the prior year period |

[0001193125-22-160304:8k_2_02:7]
|  | • |  | GAAP net income of $2,590 million for the second quarter; Adjusted EBITDA of $5,111 million for the second quarter |

[0001193125-22-160304:8k_2_02:8]
|  | • |  | GAAP diluted EPS of $5.93 for the second quarter; Non-GAAP diluted EPS of $9.07 for the second quarter |

[0001193125-22-160304:8k_2_02:9]
|  | • |  | $4,158 million of free cash flow from operations for the second quarter, defined as cash from operations of $4,243 million less capital expenditures of $85 million |

[0001193125-22-160304:8k_2_02:10]
|  | • |  | Quarterly common stock dividend of $4.10 per share |

[0001193125-22-160304:8k_2_02:11]
|  | • |  | Repurchased and eliminated 5.6 million shares for $3,290 million |

[0001193125-22-160304:8k_2_02:12]
|  | • |  | Third quarter revenue guidance of approximately $8.4 billion, an expected increase of 24 percent from the prior year period |

[0001193125-22-160304:8k_2_02:13]
|  | • |  | Third quarter Adjusted EBITDA guidance of approximately 63.5 percent of projected revenue (1) |

[0001193125-22-160304:8k_2_02:14]
|  | • |  | New share repurchase program authorized up to $10 billion of common stock, incremental to $3 billion remaining under the current authorization to date |

[0001193125-22-160304:8k_2_02:15]
SAN JOSE, Calif. – May 26, 2022
– Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2022, ended
May 1, 2022, provided guidance for the third quarter of its fiscal year 2022 and announced its quarterly dividends.

[0001193125-22-160304:8k_2_02:16]
“Broadcom’s second
quarter revenue accelerated sequentially, and was driven by strength in networking and server storage,” said Hock Tan, President and CEO of Broadcom Inc. “We expect this momentum to continue into the third quarter.”

[0001193125-22-160304:8k_2_02:17]
“Consolidated revenue grew 23% year-over-year to a record $8.1 billion and operating profit increased 30%,” said Kirsten Spears, CFO of
Broadcom Inc. “We generated $4.2 billion in free cash flow and are expecting free cash flow to remain strong in the third quarter. Consistent with our commitment to return excess cash to shareholders, we returned $4.5 billion to
shareholders in the quarter including $1.7 billion of cash dividends and $2.8 billion of share repurchases.”

[0001193125-22-160304:8k_2_02:18]
| (1) | The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort. |

[0001193125-22-160304:8k_2_02:19]
Second Quarter Fiscal Year 2022 Financial Highlights

[0001193125-22-160304:8k_2_02:20]
|  |  | GAAP |  |  | Non-GAAP |  |
| (Dollars in millions, except per share data) |  | Q2 22 |  |  | Q2 21 |  |  | Change |  |  | Q2 22 |  |  | Q2 21 |  |  | Change |  |
| Net revenue |  | $ | 8,103 |  |  | $ | 6,610 |  |  |  | +23 | % |  | $ | 8,103 |  |  | $ | 6,610 |  |  |  | +23 | % |
| Net income |  | $ | 2,590 |  |  | $ | 1,493 |  |  | +$ | 1,097 |  |  | $ | 4,000 |  |  | $ | 2,980 |  |  | +$ | 1,020 |  |
| Earnings per common share - diluted |  | $ | 5.93 |  |  | $ | 3.30 |  |  | +$ | 2.63 |  |  | $ | 9.07 |  |  | $ | 6.62 |  |  | +$ | 2.45 |  |

[0001193125-22-160304:8k_2_02:21]
| (Dollars in millions) |  | Q2 22 |  |  | Q2 21 |  |  | Change |  |
| Cash flow from operations |  | $ | 4,243 |  |  | $ | 3,569 |  |  | +$ | 674 |  |
| Adjusted EBITDA |  | $ | 5,111 |  |  | $ | 3,960 |  |  | +$ | 1,151 |  |
| Free cash flow |  | $ | 4,158 |  |  | $ | 3,443 |  |  | +$ | 715 |  |

[0001193125-22-160304:8k_2_02:22]
| Net revenue by segment (Dollars in millions) |  | Q2 22 |  |  | Q2 21 |  |  | Change |  |
| Semiconductor solutions |  | $ | 6,229 |  |  |  | 77 | % |  | $ | 4,820 |  |  |  | 73 | % |  |  | +29 | % |
| Infrastructure software |  |  | 1,874 |  |  |  | 23 |  |  |  | 1,790 |  |  |  | 27 |  |  |  | +5 | % |
| Total net revenue |  | $ | 8,103 |  |  |  | 100 | % |  | $ | 6,610 |  |  |  | 100 | % |  |  |  |  |

[0001193125-22-160304:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,005 million, compared to
$10,219 million at the end of the prior quarter.

[0001193125-22-160304:8k_2_02:24]
During the second fiscal quarter, the Company generated $4,243 million in cash from operations
and spent $85 million on capital expenditures. The Company spent $3,290 million on share repurchases and eliminations, consisting of $2,776 million in repurchases of 4.7 million shares and $514 million of withholding tax
payments related to net settled equity awards that vested in the quarter (representing approximately 0.9 million shares withheld).

[0001193125-22-160304:8k_2_02:25]
On March 31,
2022, the Company paid a cash dividend of $4.10 per share of common stock, totaling $1,676 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $74 million.

[0001193125-22-160304:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001193125-22-160304:8k_2_02:27]
Third Quarter Fiscal Year 2022 Business Outlook

[0001193125-22-160304:8k_2_02:28]
Based on
current business trends and conditions, the outlook for the third quarter of fiscal year 2022, ending July 31, 2022, is expected to be as follows:

[0001193125-22-160304:8k_2_02:29]
|  | • |  | Third quarter revenue guidance of approximately $8.4 billion; and |

[0001193125-22-160304:8k_2_02:30]
|  | • |  | Third quarter Adjusted EBITDA guidance of approximately 63.5 percent of projected revenue. |

[0001193125-22-160304:8k_2_02:31]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company
is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or
obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-22-160304:8k_2_02:32]
2

[0001193125-22-160304:8k_2_02:33]
Quarterly Dividends

[0001193125-22-160304:8k_2_02:34]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $4.10 per share. The common stock dividend is payable on
June 30, 2022 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 22, 2022.

[0001193125-22-160304:8k_2_02:35]
The Company’s Board of
Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on June 30, 2022 to preferred stockholders of record at the close of business
(5:00 p.m. Eastern Time) on June 15, 2022.

[0001193125-22-160304:8k_2_02:36]
New Share Repurchase Authorization

[0001193125-22-160304:8k_2_02:37]
The Company’s Board of Directors has authorized a new share repurchase program to repurchase up to $10 billion of our common stock through
December 31, 2023. This new share repurchase authorization is in addition to the share repurchase program authorized in December 2021, under which we may repurchase the current remaining $3 billion of common stock through December 31,
2022. Repurchases under the new share repurchase authorization may be made through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business
and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. Broadcom is not obligated to repurchase any specific amount of shares of common stock, and the share
repurchase program may be suspended or terminated at any time.

[0001193125-22-160304:8k_2_02:38]
Conference Call

[0001193125-22-160304:8k_2_02:39]
In a separate press release issued today, Broadcom announced the proposed acquisition of VMware, Inc.

[0001193125-22-160304:8k_2_02:40]
Broadcom will host a conference call today at 8:00 a.m. Eastern Time (5:00 a.m. Pacific Time). A live webcast and the accompanying materials will be available
in the “Investors” section of Broadcom’s website at https://investors.broadcom.com in advance of the conference call.

[0001193125-22-160304:8k_2_02:41]
To Listen
via Telephone: Preregistration is required by the conference call operator. Please preregister by clicking here. Upon registering, you will be emailed a dial-in number, direct passcode and unique
PIN.

[0001193125-22-160304:8k_2_02:42]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at
https://investors.broadcom.com/.

[0001193125-22-160304:8k_2_02:43]
Replay: A telephone playback of the conference call can be accessed for one week following the call by
dialing: (855) 859-2056; International + 1 (404) 537-3406; Passcode: 5733459; or through the Investors section of the Broadcom website at
https://investors.broadcom.com/.

[0001193125-22-160304:8k_2_02:44]
3

[0001193125-22-160304:8k_2_02:45]
Non-GAAP Financial Measures

[0001193125-22-160304:8k_2_02:46]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance
prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to
help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001193125-22-160304:8k_2_02:47]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other
data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring,
impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued
operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development
programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s
operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be
interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001193125-22-160304:8k_2_02:48]
Free cash flow measures have
limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as
implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001193125-22-160304:8k_2_02:49]
About Broadcom Inc.

[0001193125-22-160304:8k_2_02:50]
Broadcom Inc. (NASDAQ: AVGO) is a
global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom’s category-leading product portfolio serves critical markets including data center, networking,
enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components,
telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001193125-22-160304:8k_2_02:51]
4

[0001193125-22-160304:8k_2_02:52]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-22-160304:8k_2_02:53]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19
pandemic continues to disrupt, normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our
dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global economic conditions and concerns;
cyclicality in the semiconductor industry or in our target markets; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our
share repurchase programs; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays,
challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth
prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain
accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities,
warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our
ability to protect against cyber security threats and a breach of security systems; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses;
compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source
code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to

[0001193125-22-160304:8k_2_02:54]
new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and
overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a
political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business
and economic environment as a result.

[0001193125-22-160304:8k_2_02:55]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss
some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the
estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001193125-22-160304:8k_2_02:56]
Contact:

[0001193125-22-160304:8k_2_02:57]
Ji Yoo

[0001193125-22-160304:8k_2_02:58]
Broadcom Inc.

[0001193125-22-160304:8k_2_02:59]
Investor Relations

[0001193125-22-160304:8k_2_02:60]
408-433-8000

[0001193125-22-160304:8k_2_02:61]
investor.relations@broadcom.com

[0001193125-22-160304:8k_2_02:62]
(AVGO-Q)

[0001193125-22-160304:8k_2_02:63]
6

[0001193125-22-160304:8k_2_02:64]
BROADCOM INC.

[0001193125-22-160304:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS - UNAUDITED

[0001193125-22-160304:8k_2_02:66]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001193125-22-160304:8k_2_02:67]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 1, |  |  | January 30, |  |  | May 2, |  |  | May 1, |  |  | May 2, |  |
|  |  | 2022 |  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net revenue |  | $ | 8,103 |  |  | $ | 7,706 |  |  | $ | 6,610 |  |  | $ | 15,809 |  |  | $ | 13,265 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  | 1,956 |  |  |  | 1,925 |  |  |  | 1,699 |  |  |  | 3,881 |  |  |  | 3,513 |  |
| Amortization of acquisition-related intangible assets |  |  | 707 |  |  |  | 730 |  |  |  | 853 |  |  |  | 1,437 |  |  |  | 1,727 |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 16 |  |
| Total cost of revenue |  |  | 2,664 |  |  |  | 2,657 |  |  |  | 2,553 |  |  |  | 5,321 |  |  |  | 5,256 |  |
| Gross margin |  |  | 5,439 |  |  |  | 5,049 |  |  |  | 4,057 |  |  |  | 10,488 |  |  |  | 8,009 |  |
| Research and development |  |  | 1,261 |  |  |  | 1,206 |  |  |  | 1,238 |  |  |  | 2,467 |  |  |  | 2,449 |  |
| Selling, general and administrative |  |  | 368 |  |  |  | 321 |  |  |  | 325 |  |  |  | 689 |  |  |  | 664 |  |
| Amortization of acquisition-related intangible assets |  |  | 398 |  |  |  | 397 |  |  |  | 494 |  |  |  | 795 |  |  |  | 988 |  |
| Restructuring, impairment and disposal charges |  |  | 18 |  |  |  | 17 |  |  |  | 25 |  |  |  | 35 |  |  |  | 96 |  |
| Total operating expenses |  |  | 2,045 |  |  |  | 1,941 |  |  |  | 2,082 |  |  |  | 3,986 |  |  |  | 4,197 |  |
| Operating income |  |  | 3,394 |  |  |  | 3,108 |  |  |  | 1,975 |  |  |  | 6,502 |  |  |  | 3,812 |  |
| Interest expense |  |  | (518 | ) |  |  | (407 | ) |  |  | (466 | ) |  |  | (925 | ) |  |  | (1,036 | ) |
| Other income (expense), net |  |  | (86 | ) |  |  | (14 | ) |  |  | (23 | ) |  |  | (100 | ) |  |  | 94 |  |
| Income before income taxes |  |  | 2,790 |  |  |  | 2,687 |  |  |  | 1,486 |  |  |  | 5,477 |  |  |  | 2,870 |  |
| Provision for (benefit from) income taxes |  |  | 200 |  |  |  | 215 |  |  |  | (7 | ) |  |  | 415 |  |  |  | (1 | ) |
| Net income |  |  | 2,590 |  |  |  | 2,472 |  |  |  | 1,493 |  |  |  | 5,062 |  |  |  | 2,871 |  |
| Dividends on preferred stock |  |  | (75 | ) |  |  | (74 | ) |  |  | (76 | ) |  |  | (149 | ) |  |  | (150 | ) |
| Net income attributable to common stock |  | $ | 2,515 |  |  | $ | 2,398 |  |  | $ | 1,417 |  |  | $ | 4,913 |  |  | $ | 2,721 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 6.16 |  |  | $ | 5.82 |  |  | $ | 3.46 |  |  | $ | 11.98 |  |  | $ | 6.67 |  |
| Diluted (1) |  | $ | 5.93 |  |  | $ | 5.59 |  |  | $ | 3.30 |  |  | $ | 11.53 |  |  | $ | 6.34 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 408 |  |  |  | 412 |  |  |  | 409 |  |  |  | 410 |  |  |  | 408 |  |
| Diluted (1) |  |  | 424 |  |  |  | 429 |  |  |  | 429 |  |  |  | 426 |  |  |  | 429 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 36 |  |  | $ | 36 |  |  | $ | 38 |  |  | $ | 72 |  |  | $ | 70 |  |
| Research and development |  |  | 261 |  |  |  | 268 |  |  |  | 307 |  |  |  | 529 |  |  |  | 635 |  |
| Selling, general and administrative |  |  | 89 |  |  |  | 83 |  |  |  | 80 |  |  |  | 172 |  |  |  | 164 |  |
| Total stock-based compensation expense |  | $ | 386 |  |  | $ | 387 |  |  | $ | 425 |  |  | $ | 773 |  |  | $ | 869 |  |

[0001193125-22-160304:8k_2_02:68]
| (1) | Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001193125-22-160304:8k_2_02:69]
7

[0001193125-22-160304:8k_2_02:70]
BROADCOM INC.

[0001193125-22-160304:8k_2_02:71]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP - UNAUDITED

[0001193125-22-160304:8k_2_02:72]
(IN MILLIONS)

[0001193125-22-160304:8k_2_02:73]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 1, |  |  | January 30, |  |  | May 2, |  |  | May 1, |  |  | May 2, |  |
|  |  | 2022 |  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross margin on GAAP basis |  | $ | 5,439 |  |  | $ | 5,049 |  |  | $ | 4,057 |  |  | $ | 10,488 |  |  | $ | 8,009 |  |
| Amortization of acquisition-related intangible assets |  |  | 707 |  |  |  | 730 |  |  |  | 853 |  |  |  | 1,437 |  |  |  | 1,727 |  |
| Stock-based compensation expense |  |  | 36 |  |  |  | 36 |  |  |  | 38 |  |  |  | 72 |  |  |  | 70 |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 16 |  |
| Acquisition-related costs |  |  | 3 |  |  |  | 4 |  |  |  | 3 |  |  |  | 7 |  |  |  | 6 |  |
| Gross margin on non-GAAP basis |  | $ | 6,186 |  |  | $ | 5,821 |  |  | $ | 4,952 |  |  | $ | 12,007 |  |  | $ | 9,828 |  |
| Research and development on GAAP basis |  | $ | 1,261 |  |  | $ | 1,206 |  |  | $ | 1,238 |  |  | $ | 2,467 |  |  | $ | 2,449 |  |
| Stock-based compensation expense |  |  | 261 |  |  |  | 268 |  |  |  | 307 |  |  |  | 529 |  |  |  | 635 |  |
| Acquisition-related costs |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 2 |  |
| Research and development on non-GAAP basis |  | $ | 1,000 |  |  | $ | 938 |  |  | $ | 930 |  |  | $ | 1,938 |  |  | $ | 1,812 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 368 |  |  | $ | 321 |  |  | $ | 325 |  |  | $ | 689 |  |  | $ | 664 |  |
| Stock-based compensation expense |  |  | 89 |  |  |  | 83 |  |  |  | 80 |  |  |  | 172 |  |  |  | 164 |  |
| Acquisition-related costs |  |  | 32 |  |  |  | 11 |  |  |  | 25 |  |  |  | 43 |  |  |  | 66 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 247 |  |  | $ | 227 |  |  | $ | 220 |  |  | $ | 474 |  |  | $ | 434 |  |
| Total operating expenses on GAAP basis |  | $ | 2,045 |  |  | $ | 1,941 |  |  | $ | 2,082 |  |  | $ | 3,986 |  |  | $ | 4,197 |  |
| Amortization of acquisition-related intangible assets |  |  | 398 |  |  |  | 397 |  |  |  | 494 |  |  |  | 795 |  |  |  | 988 |  |
| Stock-based compensation expense |  |  | 350 |  |  |  | 351 |  |  |  | 387 |  |  |  | 701 |  |  |  | 799 |  |
| Restructuring, impairment and disposal charges |  |  | 18 |  |  |  | 17 |  |  |  | 25 |  |  |  | 35 |  |  |  | 96 |  |
| Acquisition-related costs |  |  | 32 |  |  |  | 11 |  |  |  | 26 |  |  |  | 43 |  |  |  | 68 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,247 |  |  | $ | 1,165 |  |  | $ | 1,150 |  |  | $ | 2,412 |  |  | $ | 2,246 |  |
| Operating income on GAAP basis |  | $ | 3,394 |  |  | $ | 3,108 |  |  | $ | 1,975 |  |  | $ | 6,502 |  |  | $ | 3,812 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,105 |  |  |  | 1,127 |  |  |  | 1,347 |  |  |  | 2,232 |  |  |  | 2,715 |  |
| Stock-based compensation expense |  |  | 386 |  |  |  | 387 |  |  |  | 425 |  |  |  | 773 |  |  |  | 869 |  |
| Restructuring, impairment and disposal charges |  |  | 19 |  |  |  | 19 |  |  |  | 26 |  |  |  | 38 |  |  |  | 112 |  |
| Acquisition-related costs |  |  | 35 |  |  |  | 15 |  |  |  | 29 |  |  |  | 50 |  |  |  | 74 |  |
| Operating income on non-GAAP basis |  | $ | 4,939 |  |  | $ | 4,656 |  |  | $ | 3,802 |  |  | $ | 9,595 |  |  | $ | 7,582 |  |
| Interest expense on GAAP basis |  | $ | (518 | ) |  | $ | (407 | ) |  | $ | (466 | ) |  | $ | (925 | ) |  | $ | (1,036 | ) |
| Loss on debt extinguishment |  |  | 112 |  |  |  | — |  |  |  | 50 |  |  |  | 112 |  |  |  | 222 |  |
| Interest expense on non-GAAP basis |  | $ | (406 | ) |  | $ | (407 | ) |  | $ | (416 | ) |  | $ | (813 | ) |  | $ | (814 | ) |
| Other income (expense), net on GAAP basis |  | $ | (86 | ) |  | $ | (14 | ) |  | $ | (23 | ) |  | $ | (100 | ) |  | $ | 94 |  |
| (Gains) losses on investments |  |  | 99 |  |  |  | 16 |  |  |  | 25 |  |  |  | 115 |  |  |  | (94 | ) |
| Other |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (3 | ) |
| Other income (expense), net on non-GAAP basis |  | $ | 13 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 15 |  |  | $ | (3 | ) |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 200 |  |  | $ | 215 |  |  | $ | (7 | ) |  | $ | 415 |  |  | $ | (1 | ) |
| Non-GAAP tax reconciling adjustments |  |  | 346 |  |  |  | 295 |  |  |  | 414 |  |  |  | 641 |  |  |  | 813 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 546 |  |  | $ | 510 |  |  | $ | 407 |  |  | $ | 1,056 |  |  | $ | 812 |  |
| Net income on GAAP basis |  | $ | 2,590 |  |  | $ | 2,472 |  |  | $ | 1,493 |  |  | $ | 5,062 |  |  | $ | 2,871 |  |
| Amortization of acquisition-related intangible assets |  |  | 1,105 |  |  |  | 1,127 |  |  |  | 1,347 |  |  |  | 2,232 |  |  |  | 2,715 |  |
| Stock-based compensation expense |  |  | 386 |  |  |  | 387 |  |  |  | 425 |  |  |  | 773 |  |  |  | 869 |  |
| Restructuring, impairment and disposal charges |  |  | 19 |  |  |  | 19 |  |  |  | 26 |  |  |  | 38 |  |  |  | 112 |  |
| Acquisition-related costs |  |  | 35 |  |  |  | 15 |  |  |  | 28 |  |  |  | 50 |  |  |  | 71 |  |
| Loss on debt extinguishment |  |  | 112 |  |  |  | — |  |  |  | 50 |  |  |  | 112 |  |  |  | 222 |  |
| (Gains) losses on investments |  |  | 99 |  |  |  | 16 |  |  |  | 25 |  |  |  | 115 |  |  |  | (94 | ) |
| Non-GAAP tax reconciling adjustments |  |  | (346 | ) |  |  | (295 | ) |  |  | (414 | ) |  |  | (641 | ) |  |  | (813 | ) |
| Net income on non-GAAP basis |  | $ | 4,000 |  |  | $ | 3,741 |  |  | $ | 2,980 |  |  | $ | 7,741 |  |  | $ | 5,953 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  |  | 424 |  |  |  | 429 |  |  |  | 429 |  |  |  | 426 |  |  |  | 429 |  |
| Non-GAAP adjustment (1) |  |  | 17 |  |  |  | 17 |  |  |  | 21 |  |  |  | 17 |  |  |  | 21 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  |  | 441 |  |  |  | 446 |  |  |  | 450 |  |  |  | 443 |  |  |  | 450 |  |
| Net income on non-GAAP basis |  | $ | 4,000 |  |  | $ | 3,741 |  |  | $ | 2,980 |  |  | $ | 7,741 |  |  | $ | 5,953 |  |
| Interest expense on non-GAAP basis |  |  | 406 |  |  |  | 407 |  |  |  | 416 |  |  |  | 813 |  |  |  | 814 |  |
| Provision for income taxes on non-GAAP basis |  |  | 546 |  |  |  | 510 |  |  |  | 407 |  |  |  | 1,056 |  |  |  | 812 |  |
| Depreciation |  |  | 135 |  |  |  | 136 |  |  |  | 133 |  |  |  | 271 |  |  |  | 271 |  |
| Amortization of purchased intangibles and right-of-use assets |  |  | 24 |  |  |  | 24 |  |  |  | 24 |  |  |  | 48 |  |  |  | 51 |  |
| Adjusted EBITDA |  | $ | 5,111 |  |  | $ | 4,818 |  |  | $ | 3,960 |  |  | $ | 9,929 |  |  | $ | 7,901 |  |
| Net cash provided by operating activities |  | $ | 4,243 |  |  | $ | 3,486 |  |  | $ | 3,569 |  |  | $ | 7,729 |  |  | $ | 6,682 |  |
| Purchases of property, plant and equipment |  |  | (85 | ) |  |  | (101 | ) |  |  | (126 | ) |  |  | (186 | ) |  |  | (240 | ) |
| Free cash flow |  | $ | 4,158 |  |  | $ | 3,385 |  |  | $ | 3,443 |  |  | $ | 7,543 |  |  | $ | 6,442 |  |

[0001193125-22-160304:8k_2_02:74]
|  |  | Fiscal QuarterEnding |  |
|  |  | July 31,2022 |  |
| Expected average diluted share count (2): |  |  |  |  |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  |  | 421 |  |
| Non-GAAP adjustment (1) |  |  | 18 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  |  | 439 |  |

[0001193125-22-160304:8k_2_02:75]
| (1) | Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis. For the fiscal quarter ending July 31, 2022, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |

[0001193125-22-160304:8k_2_02:76]
| (2) | Excludes the effects of potential share repurchases. |

[0001193125-22-160304:8k_2_02:77]
BROADCOM INC.

[0001193125-22-160304:8k_2_02:78]
CONDENSED CONSOLIDATED BALANCE SHEETS - UNAUDITED

[0001193125-22-160304:8k_2_02:79]
(IN MILLIONS)

[0001193125-22-160304:8k_2_02:80]
|  |  | May 1,2022 |  |  | October 31,2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,005 |  |  | $ | 12,163 |  |
| Trade accounts receivable, net |  |  | 3,083 |  |  |  | 2,071 |  |
| Inventory |  |  | 1,668 |  |  |  | 1,297 |  |
| Other current assets |  |  | 1,054 |  |  |  | 1,055 |  |
| Total current assets |  |  | 14,810 |  |  |  | 16,586 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 2,262 |  |  |  | 2,348 |  |
| Goodwill |  |  | 43,603 |  |  |  | 43,450 |  |
| Intangible assets, net |  |  | 9,241 |  |  |  | 11,374 |  |
| Other long-term assets |  |  | 1,803 |  |  |  | 1,812 |  |
| Total assets |  | $ | 71,719 |  |  | $ | 75,570 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 1,069 |  |  | $ | 1,086 |  |
| Employee compensation and benefits |  |  | 751 |  |  |  | 1,066 |  |
| Current portion of long-term debt |  |  | 302 |  |  |  | 290 |  |
| Other current liabilities |  |  | 4,788 |  |  |  | 3,839 |  |
| Total current liabilities |  |  | 6,910 |  |  |  | 6,281 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |
| Long-term debt |  |  | 39,164 |  |  |  | 39,440 |  |
| Other long-term liabilities |  |  | 4,655 |  |  |  | 4,860 |  |
| Total liabilities |  |  | 50,729 |  |  |  | 50,581 |  |
| Preferred stock dividend obligation |  |  | 27 |  |  |  | 27 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  |  | — |  |
| Common stock |  |  | — |  |  |  | — |  |
| Additional paid-in capital |  |  | 21,078 |  |  |  | 24,330 |  |
| Retained earnings |  |  | — |  |  |  | 748 |  |
| Accumulated other comprehensive loss |  |  | (115 | ) |  |  | (116 | ) |
| Total stockholders’ equity |  |  | 20,963 |  |  |  | 24,962 |  |
| Total liabilities and equity |  | $ | 71,719 |  |  | $ | 75,570 |  |

[0001193125-22-160304:8k_2_02:81]
9

[0001193125-22-160304:8k_2_02:82]
BROADCOM INC.

[0001193125-22-160304:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS - UNAUDITED

[0001193125-22-160304:8k_2_02:84]
(IN MILLIONS)

[0001193125-22-160304:8k_2_02:85]
|  |  | Fiscal Quarter Ended |  |  | Two Fiscal Quarters Ended |  |
|  |  | May 1, |  |  | January 30, |  |  | May 2, |  |  | May 1, |  |  | May 2, |  |
|  |  | 2022 |  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,590 |  |  | $ | 2,472 |  |  | $ | 1,493 |  |  | $ | 5,062 |  |  | $ | 2,871 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  |  | 1,129 |  |  |  | 1,151 |  |  |  | 1,371 |  |  |  | 2,280 |  |  |  | 2,766 |  |
| Depreciation |  |  | 135 |  |  |  | 136 |  |  |  | 133 |  |  |  | 271 |  |  |  | 271 |  |
| Stock-based compensation |  |  | 386 |  |  |  | 387 |  |  |  | 425 |  |  |  | 773 |  |  |  | 869 |  |
| Deferred taxes and other non-cash taxes |  |  | — |  |  |  | 70 |  |  |  | (177 | ) |  |  | 70 |  |  |  | (326 | ) |
| Loss on debt extinguishment |  |  | 100 |  |  |  | — |  |  |  | 26 |  |  |  | 100 |  |  |  | 198 |  |
| (Gains) losses on investments |  |  | 99 |  |  |  | 16 |  |  |  | 25 |  |  |  | 115 |  |  |  | (94 | ) |
| Non-cash interest expense |  |  | 33 |  |  |  | 32 |  |  |  | 21 |  |  |  | 65 |  |  |  | 43 |  |
| Other |  |  | 11 |  |  |  | (1 | ) |  |  | 9 |  |  |  | 10 |  |  |  | 19 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  |  | (536 | ) |  |  | (468 | ) |  |  | 106 |  |  |  | (1,004 | ) |  |  | (141 | ) |
| Inventory |  |  | (147 | ) |  |  | (223 | ) |  |  | (52 | ) |  |  | (370 | ) |  |  | (1 | ) |
| Accounts payable |  |  | (31 | ) |  |  | — |  |  |  | (58 | ) |  |  | (31 | ) |  |  | (14 | ) |
| Employee compensation and benefits |  |  | 215 |  |  |  | (528 | ) |  |  | 135 |  |  |  | (313 | ) |  |  | (240 | ) |
| Other current assets and current liabilities |  |  | 287 |  |  |  | 521 |  |  |  | 182 |  |  |  | 808 |  |  |  | 590 |  |
| Other long-term assets and long-term liabilities |  |  | (28 | ) |  |  | (79 | ) |  |  | (70 | ) |  |  | (107 | ) |  |  | (129 | ) |
| Net cash provided by operating activities |  |  | 4,243 |  |  |  | 3,486 |  |  |  | 3,569 |  |  |  | 7,729 |  |  |  | 6,682 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (225 | ) |  |  | (9 | ) |  |  | — |  |  |  | (234 | ) |  |  | (8 | ) |
| Purchases of property, plant and equipment |  |  | (85 | ) |  |  | (101 | ) |  |  | (126 | ) |  |  | (186 | ) |  |  | (240 | ) |
| Purchases of investments |  |  | — |  |  |  | (200 | ) |  |  | — |  |  |  | (200 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (310 | ) |  |  | (309 | ) |  |  | (126 | ) |  |  | (619 | ) |  |  | (248 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  |  | 1,935 |  |  |  | — |  |  |  | — |  |  |  | 1,935 |  |  |  | 9,904 |  |
| Payments on debt obligations |  |  | (2,097 | ) |  |  | (255 | ) |  |  | (1,533 | ) |  |  | (2,352 | ) |  |  | (10,733 | ) |
| Payments of dividends |  |  | (1,750 | ) |  |  | (1,764 | ) |  |  | (1,552 | ) |  |  | (3,514 | ) |  |  | (3,095 | ) |
| Repurchases of common stock - repurchase program |  |  | (2,776 | ) |  |  | (2,724 | ) |  |  | — |  |  |  | (5,500 | ) |  |  | — |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  |  | (514 | ) |  |  | (375 | ) |  |  | (461 | ) |  |  | (889 | ) |  |  | (686 | ) |
| Issuance of common stock |  |  | 59 |  |  |  | 1 |  |  |  | 71 |  |  |  | 60 |  |  |  | 106 |  |
| Other |  |  | (4 | ) |  |  | (4 | ) |  |  | (2 | ) |  |  | (8 | ) |  |  | (30 | ) |
| Net cash used in financing activities |  |  | (5,147 | ) |  |  | (5,121 | ) |  |  | (3,477 | ) |  |  | (10,268 | ) |  |  | (4,534 | ) |
| Net change in cash and cash equivalents |  |  | (1,214 | ) |  |  | (1,944 | ) |  |  | (34 | ) |  |  | (3,158 | ) |  |  | 1,900 |  |
| Cash and cash equivalents at beginning of period |  |  | 10,219 |  |  |  | 12,163 |  |  |  | 9,552 |  |  |  | 12,163 |  |  |  | 7,618 |  |
| Cash and cash equivalents at end of period |  | $ | 9,005 |  |  | $ | 10,219 |  |  | $ | 9,518 |  |  | $ | 9,005 |  |  | $ | 9,518 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 459 |  |  | $ | 240 |  |  | $ | 369 |  |  | $ | 699 |  |  | $ | 741 |  |
| Cash paid for income taxes |  | $ | 240 |  |  | $ | 186 |  |  | $ | 293 |  |  | $ | 426 |  |  | $ | 440 |  |

[0001193125-22-160304:8k_2_02:86]
10
