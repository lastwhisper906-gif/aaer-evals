# AVGO MD&A — 0001730168-22-000081


## mdna

[0001730168-22-000081:mdna:1]
[same as prior period, unchanged from 0001730168-22-000029:mdna:1]

[0001730168-22-000081:mdna:2]
[same as prior period, unchanged from 0001730168-22-000029:mdna:3]

[0001730168-22-000081:mdna:3]
[same as prior period, unchanged from 0001730168-22-000029:mdna:4]

[0001730168-22-000081:mdna:4]
[same as prior period, unchanged from 0001730168-22-000029:mdna:5]

[0001730168-22-000081:mdna:5]
[same as prior period, unchanged from 0001730168-22-000029:mdna:6]

[0001730168-22-000081:mdna:6]
Highlights during the fiscal quarter ended May 1, 2022 include the following:

[0001730168-22-000081:mdna:7]
•We generated $4,243 million of cash from operations.

[0001730168-22-000081:mdna:8]
•We paid $1,750 million in cash dividends.

[0001730168-22-000081:mdna:9]
•We repurchased $2,776 million of common stock.

[0001730168-22-000081:mdna:10]
[same as prior period, unchanged from 0001730168-22-000029:mdna:25]

[0001730168-22-000081:mdna:11]
Pending Acquisition of VMware, Inc.

[0001730168-22-000081:mdna:12]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. In addition, we will assume $8 billion of VMware net debt.

[0001730168-22-000081:mdna:13]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

[0001730168-22-000081:mdna:14]
We will assume all outstanding VMware restricted stock unit awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into restricted stock unit awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and restricted stock unit awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-22-000081:mdna:15]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

[0001730168-22-000081:mdna:16]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

[0001730168-22-000081:mdna:17]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023, is subject to satisfaction or waiver of customary closing conditions, including adoption of the VMware Merger Agreement by VMware stockholders, the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 (the “HSR Act”) and clearance under the antitrust laws of the European Union and certain other jurisdictions, and the effectiveness of a registration statement on Form S-4 to be filed by us. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion (or, in certain circumstances, VMware’s termination fee would be $750 million).

[0001730168-22-000081:mdna:18]
[same as prior period, unchanged from 0001730168-22-000029:mdna:11]

[0001730168-22-000081:mdna:19]
[same as prior period, unchanged from 0001730168-22-000029:mdna:12]

[0001730168-22-000081:mdna:20]
The demand environment for our semiconductor products was consistent with our expectations for the second quarter of our fiscal year ending October 30, 2022 (“fiscal year 2022”), with continued investments by enterprises, hyperclouds and service providers in technologies and solutions to support remote or hybrid tele-work and learning arising from COVID-19, as well as the transition to office re-openings. While we continue to see robust demand in this area and record profitability driven by the supply imbalance, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. We continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. While supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet increased demand. To date, the impact of COVID-19 on the demand environment for our software products has been limited.

[0001730168-22-000081:mdna:21]
[same as prior period, unchanged from 0001730168-22-000029:mdna:14]

[0001730168-22-000081:mdna:22]
[same as prior period, unchanged from 0001730168-22-000029:mdna:15]

[0001730168-22-000081:mdna:23]
[same as prior period, unchanged from 0001730168-22-000029:mdna:40]

[0001730168-22-000081:mdna:24]
[same as prior period, unchanged from 0001730168-22-000029:mdna:16]

[0001730168-22-000081:mdna:25]
[same as prior period, unchanged from 0001730168-22-000029:mdna:17]

[0001730168-22-000081:mdna:26]
There were no significant changes in our critical accounting estimates during the two fiscal quarters ended May 1, 2022 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2021 Annual Report on Form 10-K.

[0001730168-22-000081:mdna:27]
[same as prior period, unchanged from 0001730168-22-000029:mdna:19]

[0001730168-22-000081:mdna:28]
Fiscal Quarter and Two Fiscal Quarters Ended May 1, 2022 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 2, 2021

[0001730168-22-000081:mdna:29]
The following tables set forth our results of operations for the periods presented:

[0001730168-22-000081:mdna:30]
|  |  | Fiscal Quarter Ended |
|  |  | May 1,2022 |  | May 2,2021 |  | May 1,2022 |  | May 2,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 6,417 |  |  | $ | 4,983 |  |  | 79 | % |  | 75 | % |
| Subscriptions and services |  | 1,686 |  |  | 1,627 |  |  | 21 |  |  | 25 |  |
| Total net revenue |  | 8,103 |  |  | 6,610 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,798 |  |  | 1,548 |  |  | 22 |  |  | 24 |  |
| Cost of subscriptions and services |  | 158 |  |  | 151 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 707 |  |  | 853 |  |  | 9 |  |  | 13 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,664 |  |  | 2,553 |  |  | 33 |  |  | 39 |  |
| Gross margin |  | 5,439 |  |  | 4,057 |  |  | 67 |  |  | 61 |  |
| Research and development |  | 1,261 |  |  | 1,238 |  |  | 16 |  |  | 19 |  |
| Selling, general and administrative |  | 368 |  |  | 325 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 398 |  |  | 494 |  |  | 5 |  |  | 7 |  |
| Restructuring, impairment and disposal charges |  | 18 |  |  | 25 |  |  | — |  |  | — |  |
| Total operating expenses |  | 2,045 |  |  | 2,082 |  |  | 25 |  |  | 31 |  |
| Operating income |  | $ | 3,394 |  |  | $ | 1,975 |  |  | 42 | % |  | 30 | % |

[0001730168-22-000081:mdna:31]
[same as prior period, unchanged from 0001730168-22-000029:mdna:54]

[0001730168-22-000081:mdna:32]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 1,2022 |  | May 2,2021 |  | May 1,2022 |  | May 2,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 12,470 |  |  | $ | 10,064 |  |  | 79 | % |  | 76 | % |
| Subscriptions and services |  | 3,339 |  |  | 3,201 |  |  | 21 |  |  | 24 |  |
| Total net revenue |  | 15,809 |  |  | 13,265 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 3,567 |  |  | 3,220 |  |  | 23 |  |  | 25 |  |
| Cost of subscriptions and services |  | 314 |  |  | 293 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,437 |  |  | 1,727 |  |  | 9 |  |  | 13 |  |
| Restructuring charges |  | 3 |  |  | 16 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,321 |  |  | 5,256 |  |  | 34 |  |  | 40 |  |
| Gross margin |  | 10,488 |  |  | 8,009 |  |  | 66 |  |  | 60 |  |
| Research and development |  | 2,467 |  |  | 2,449 |  |  | 16 |  |  | 18 |  |
| Selling, general and administrative |  | 689 |  |  | 664 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 795 |  |  | 988 |  |  | 5 |  |  | 7 |  |
| Restructuring, impairment and disposal charges |  | 35 |  |  | 96 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 3,986 |  |  | 4,197 |  |  | 25 |  |  | 31 |  |
| Operating income |  | $ | 6,502 |  |  | $ | 3,812 |  |  | 41 | % |  | 29 | % |

[0001730168-22-000081:mdna:33]
[same as prior period, unchanged from 0001730168-22-000029:mdna:23]

[0001730168-22-000081:mdna:34]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 17% and 20% of our net revenue for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, and 17% and 18% of our net revenue for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively.

[0001730168-22-000081:mdna:35]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 1, 2022 and May 2, 2021. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 1, 2022 and May 2, 2021. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-22-000081:mdna:36]
[same as prior period, unchanged from 0001730168-22-000029:mdna:27]

[0001730168-22-000081:mdna:37]
[same as prior period, unchanged from 0001730168-22-000029:mdna:68]

[0001730168-22-000081:mdna:38]
[same as prior period, unchanged from 0001730168-22-000029:mdna:28]

[0001730168-22-000081:mdna:39]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | May 1, 2022 |  | May 2, 2021 |  | $ Change |  | % Change |  | May 1, 2022 |  | May 2, 2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 6,229 |  |  | $ | 4,820 |  |  | $ | 1,409 |  |  | 29 | % |  | $ | 12,102 |  |  | $ | 9,728 |  |  | $ | 2,374 |  |  | 24 | % |
| Infrastructure software |  | 1,874 |  |  | 1,790 |  |  | 84 |  |  | 5 | % |  | 3,707 |  |  | 3,537 |  |  | 170 |  |  | 5 | % |
| Total net revenue |  | $ | 8,103 |  |  | $ | 6,610 |  |  | $ | 1,493 |  |  | 23 | % |  | $ | 15,809 |  |  | $ | 13,265 |  |  | $ | 2,544 |  |  | 19 | % |

[0001730168-22-000081:mdna:40]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 1,2022 |  | May 2,2021 |  | May 1,2022 |  | May 2,2021 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 77 | % |  | 73 | % |  | 77 | % |  | 73 | % |
| Infrastructure software |  | 23 |  |  | 27 |  |  | 23 |  |  | 27 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-22-000081:mdna:41]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended May 1, 2022 compared to the prior year fiscal periods due to on-going strong product demand, primarily for networking, server storage and broadband products. Net revenue from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended May 1, 2022 compared to the prior year fiscal periods primarily due to higher demand for our mainframe solutions.

[0001730168-22-000081:mdna:42]
[same as prior period, unchanged from 0001730168-22-000029:mdna:32]

[0001730168-22-000081:mdna:43]
Gross margin was $5,439 million, or 67% of net revenue, for the fiscal quarter ended May 1, 2022 compared to $4,057 million, or 61% of net revenue, for the fiscal quarter ended May 2, 2021, and $10,488 million, or 66% of net revenue, for the two fiscal quarters ended May 1, 2022 compared to $8,009 million, or 60% of net revenue, for the two fiscal quarters ended May 2, 2021.

[0001730168-22-000081:mdna:44]
The increases were primarily due to lower amortization of acquisition-related intangible assets and improved profitability within our semiconductor solutions segment.

[0001730168-22-000081:mdna:45]
[same as prior period, unchanged from 0001730168-22-000029:mdna:34]

[0001730168-22-000081:mdna:46]
Research and development expense increased $23 million, or 2%, and $18 million, or 1%, for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher variable employee compensation expense and engineering project costs, partially offset by lower stock-based compensation expense reflecting the full vesting of certain equity awards.

[0001730168-22-000081:mdna:47]
[same as prior period, unchanged from 0001730168-22-000029:mdna:36]

[0001730168-22-000081:mdna:48]
Selling, general and administrative expense increased $43 million, or 13%, and $25 million, or 4%, for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher variable employee compensation expense and sales initiatives.

[0001730168-22-000081:mdna:49]
[same as prior period, unchanged from 0001730168-22-000029:mdna:38]

[0001730168-22-000081:mdna:50]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $96 million, or 19%, and $193 million, or 20%, for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-22-000081:mdna:51]
[same as prior period, unchanged from 0001730168-22-000029:mdna:41]

[0001730168-22-000081:mdna:52]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $7 million, or 28%, and $61 million, or 64%, for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower employee termination costs and lease and other exit costs in the current year fiscal periods following the completion of key restructuring activities from acquisitions.

[0001730168-22-000081:mdna:53]
27

[0001730168-22-000081:mdna:54]
[same as prior period, unchanged from 0001730168-22-000029:mdna:43]

[0001730168-22-000081:mdna:55]
Total stock-based compensation expense was $386 million and $773 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to $425 million and $869 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively. The decreases primarily reflect the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-22-000081:mdna:56]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of May 1, 2022, which we expect to recognize over the remaining weighted-average service period of 3.0 years.

[0001730168-22-000081:mdna:57]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 750 |  |
| 2023 |  | 1,186 |  |
| 2024 |  | 804 |  |
| 2025 |  | 467 |  |
| 2026 |  | 102 |  |
| Total |  | $ | 3,309 |  |

[0001730168-22-000081:mdna:58]
[same as prior period, unchanged from 0001730168-22-000029:mdna:47]

[0001730168-22-000081:mdna:59]
[same as prior period, unchanged from 0001730168-22-000029:mdna:48]

[0001730168-22-000081:mdna:60]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | May 1,2022 |  | May 2,2021 |  | $ Change |  | % Change |  | May 1, 2022 |  | May 2, 2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 3,626 |  |  | $ | 2,547 |  |  | $ | 1,079 |  |  | 42 | % |  | $ | 6,975 |  |  | $ | 5,108 |  |  | $ | 1,867 |  |  | 37 | % |
| Infrastructure software |  | 1,313 |  |  | 1,255 |  |  | 58 |  |  | 5 | % |  | 2,620 |  |  | 2,474 |  |  | 146 |  |  | 6 | % |
| Unallocated expenses |  | (1,545) |  |  | (1,827) |  |  | 282 |  |  | (15) | % |  | (3,093) |  |  | (3,770) |  |  | 677 |  |  | (18) | % |
| Total operating income |  | $ | 3,394 |  |  | $ | 1,975 |  |  | $ | 1,419 |  |  | 72 | % |  | $ | 6,502 |  |  | $ | 3,812 |  |  | $ | 2,690 |  |  | 71 | % |

[0001730168-22-000081:mdna:61]
Operating income from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended May 1, 2022 compared to the prior year fiscal periods, primarily due to higher net revenue due to on-going strong product demand, primarily for networking, server storage and broadband products, and improved profitability. Operating income from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended May 1, 2022 compared to the prior year fiscal periods, primarily due to higher demand for our mainframe solutions.

[0001730168-22-000081:mdna:62]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 15% and 18% for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the prior year fiscal periods primarily due to lower amortization of acquisition-related intangible assets.

[0001730168-22-000081:mdna:63]
[same as prior period, unchanged from 0001730168-22-000029:mdna:52]

[0001730168-22-000081:mdna:64]
Interest expense. Interest expense was $518 million and $925 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to $466 million and $1,036 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively. The increase in the fiscal quarter ended May 1, 2022 was primarily due to higher losses on extinguishment of debt related to debt transactions. The decrease in two fiscal quarters ended May 1, 2022 was primarily due to lower losses on extinguishment of debt. We expect to incur additional interest expense in future periods as a result of term loan indebtedness associated with future acquisitions, including the pending VMware Merger.

[0001730168-22-000081:mdna:65]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other expense, net, was $86 million and $100 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to other expense, net of $23 million and other income, net of $94 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively. The changes were primarily due to changes in investment gains or losses.

[0001730168-22-000081:mdna:66]
Provision for (benefit from) income taxes. The provision for income taxes was $200 million and $415 million for the fiscal quarter and two fiscal quarters ended May 1, 2022, respectively, compared to the benefit from income taxes of $7 million and $1 million for the fiscal quarter and two fiscal quarters ended May 2, 2021, respectively. The provision for income taxes in the current year fiscal periods was primarily driven by income before income taxes, offset by a shift in jurisdictional mix of income and expenses, and excess tax benefits from stock-based awards. The benefit from income taxes in the prior year fiscal periods was due to excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, substantially offset by income tax expense arising from operations.

[0001730168-22-000081:mdna:67]
[same as prior period, unchanged from 0001730168-22-000029:mdna:57]

[0001730168-22-000081:mdna:68]
[same as prior period, unchanged from 0001730168-22-000029:mdna:58]

[0001730168-22-000081:mdna:69]
Our primary sources of liquidity as of May 1, 2022 consisted of: (i) $9,005 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-22-000081:mdna:70]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including the pending VMware Merger, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $41,227 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect a slight increase in capital expenditures in fiscal year 2022 as compared to fiscal year 2021. Our debt and liquidity needs will also increase as a result of the pending VMware Merger. We intend to fund the cash portion of the consideration with $32 billion in new, fully committed debt financing.

[0001730168-22-000081:mdna:71]
We believe that our cash and cash equivalents on hand, cash flows from operations, the Revolving Facility, as well as the committed debt funding related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 10. “Commitments and Contingencies” and Note 6. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-22-000081:mdna:72]
[same as prior period, unchanged from 0001730168-22-000029:mdna:62]

[0001730168-22-000081:mdna:73]
[same as prior period, unchanged from 0001730168-22-000029:mdna:63]

[0001730168-22-000081:mdna:74]
[same as prior period, unchanged from 0001730168-22-000029:mdna:64]

[0001730168-22-000081:mdna:75]
Working capital decreased to $7,900 million at May 1, 2022 from $10,305 million at October 31, 2021. The decrease was primarily attributable to the following:

[0001730168-22-000081:mdna:76]
•Cash and cash equivalents decreased to $9,005 million at May 1, 2022 from $12,163 million at October 31, 2021,

[0001730168-22-000081:mdna:77]
29

[0001730168-22-000081:mdna:78]
primarily due to $5,500 million of common stock repurchases, $3,514 million of dividend payments, $2,352 million of debt payments, and $889 million of employee withholding tax payments related to net settled equity awards. These decreases were partially offset by $7,729 million in net cash provided by operating activities and $1,935 million in proceeds from long-term borrowings.

[0001730168-22-000081:mdna:79]
•Other current liabilities increased to $4,788 million at May 1, 2022 from $3,839 million at October 31, 2021, primarily due to increases in contract liabilities and interest payable.

[0001730168-22-000081:mdna:80]
[same as prior period, unchanged from 0001730168-22-000029:mdna:69]

[0001730168-22-000081:mdna:81]
•Accounts receivable increased to $3,083 million at May 1, 2022 from $2,071 million at October 31, 2021, primarily due to revenue linearity and less receivables sold through factoring arrangements.

[0001730168-22-000081:mdna:82]
•Inventory increased to $1,668 million at May 1, 2022 from $1,297 million at October 31, 2021, primarily to support customer demand and due to higher material costs.

[0001730168-22-000081:mdna:83]
•Employee compensation and benefits decreased to $751 million at May 1, 2022 from $1,066 million at October 31, 2021, primarily due to the timing of employee bonus plan payments.

[0001730168-22-000081:mdna:84]
[same as prior period, unchanged from 0001730168-22-000029:mdna:73]

[0001730168-22-000081:mdna:85]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 1,2022 |  | May 2,2021 |
|  |  | (In millions, except per share data) |
| Cash dividends declared and paid per share to common stockholders |  | $ | 8.20 |  |  | $ | 7.20 |  |
| Cash dividends declared and paid to common stockholders |  | $ | 3,365 |  |  | $ | 2,945 |  |
| Cash dividends declared and paid per share to preferred stockholders |  | $ | 40.00 |  |  | $ | 40.00 |  |
| Cash dividends declared and paid to preferred stockholders |  | $ | 149 |  |  | $ | 150 |  |
| Stock repurchases |  | $ | 5,500 |  |  | $ | — |  |

[0001730168-22-000081:mdna:86]
Pursuant to a $10 billion stock repurchase program authorized by our Board of Directors in December 2021, we repurchased and retired approximately 9 million shares of our common stock at a weighted average price of $602.53 during the two fiscal quarters ended May 1, 2022.

[0001730168-22-000081:mdna:87]
In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023. Repurchases under our stock repurchase programs may be made through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-22-000081:mdna:88]
During the two fiscal quarters ended May 1, 2022 and May 2, 2021, we paid approximately $889 million and $686 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the two fiscal quarters ended May 1, 2022 and May 2, 2021.

[0001730168-22-000081:mdna:89]
[same as prior period, unchanged from 0001730168-22-000029:mdna:77]

[0001730168-22-000081:mdna:90]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 1,2022 |  | May 2,2021 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 7,729 |  |  | $ | 6,682 |  |
| Net cash used in investing activities |  | (619) |  |  | (248) |  |
| Net cash used in financing activities |  | (10,268) |  |  | (4,534) |  |
| Net change in cash and cash equivalents |  | $ | (3,158) |  |  | $ | 1,900 |  |

[0001730168-22-000081:mdna:91]
[same as prior period, unchanged from 0001730168-22-000029:mdna:79]

[0001730168-22-000081:mdna:92]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes

[0001730168-22-000081:mdna:93]
30

[0001730168-22-000081:mdna:94]
in assets and liabilities. The $1,047 million increase in cash provided by operations during the two fiscal quarters ended May 1, 2022 compared to the prior year fiscal period was due to $2,191 million higher net income, offset by a $62 million decrease in amortization of intangible assets and stock-based compensation and other adjustments, as well as a $1,082 million decrease resulting from changes in operating assets and liabilities.

[0001730168-22-000081:mdna:95]
[same as prior period, unchanged from 0001730168-22-000029:mdna:81]

[0001730168-22-000081:mdna:96]
Cash flows from investing activities primarily consisted of cash used for acquisitions, investments and capital expenditures. The $371 million increase in cash used in investing activities during the two fiscal quarters ended May 1, 2022 compared to the prior year fiscal period was primarily due to a $226 million increase in cash paid for acquisitions as well as $200 million investment purchases.

[0001730168-22-000081:mdna:97]
[same as prior period, unchanged from 0001730168-22-000029:mdna:83]

[0001730168-22-000081:mdna:98]
Cash flows from financing activities primarily consisted of proceeds and payments related to our stock repurchases, dividend payments, long-term borrowings and employee withholding tax payments related to net settled equity awards. The $5,734 million increase in cash used in financing activities during the two fiscal quarters ended May 1, 2022 compared to the prior year fiscal period was primarily due to $5,500 million in common stock repurchases, a $419 million increase in dividend payments and a $203 million increase in employee withholding tax payments related to net settled equity awards, offset in part by a $412 million change in net borrowing activities.

[0001730168-22-000081:mdna:99]
[same as prior period, unchanged from 0001730168-22-000029:mdna:85]

[0001730168-22-000081:mdna:100]
[same as prior period, unchanged from 0001730168-22-000029:mdna:86]
