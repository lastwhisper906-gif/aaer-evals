# AVGO MD&A — 0001730168-20-000109


## mdna

[0001730168-20-000109:mdna:1]
[same as prior period, unchanged from 0001730168-20-000045:mdna:1]

[0001730168-20-000109:mdna:2]
[same as prior period, unchanged from 0001730168-20-000045:mdna:2]

[0001730168-20-000109:mdna:3]
[same as prior period, unchanged from 0001730168-20-000045:mdna:3]

[0001730168-20-000109:mdna:4]
During the first quarter of our fiscal year ending November 1, 2020 (“fiscal year 2020”), we changed our organizational structure, resulting in two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines, except for those related to our fibre channel storage area networking (“FC SAN”) products, as well as our IP licensing. Our infrastructure software segment includes our FC SAN products; mainframe and enterprise software solutions; and enterprise security solutions. Prior period segment results have been recast to conform to the current presentation.

[0001730168-20-000109:mdna:5]
[same as prior period, unchanged from 0001730168-20-000045:mdna:5]

[0001730168-20-000109:mdna:6]
Highlights during the second fiscal quarter ended May 3, 2020 include the following:

[0001730168-20-000109:mdna:7]
•We generated $3,213 million of cash from operations.

[0001730168-20-000109:mdna:8]
•We paid $1,381 million in cash dividends.

[0001730168-20-000109:mdna:9]
•We issued $4,500 million of senior unsecured notes (the “April 2020 Senior Notes”), the proceeds of which were used to repurchase $3,986 million of certain senior notes. See Note 8. “Borrowings” in Part I, Item 1 of this Form 10-Q for more details.

[0001730168-20-000109:mdna:10]
29

[0001730168-20-000109:mdna:11]
•We increased our borrowings under our unsecured revolving facility (the “Revolving Facility”), provided for under the credit agreement entered into in May 2019 to $3,000 million and correspondingly reduced our unsecured commercial paper note borrowings by $1,972 million. We repaid amounts drawn under our Revolving Facility in full subsequent to the end of the fiscal quarter ended May 3, 2020.

[0001730168-20-000109:mdna:12]
COVID-19 Update

[0001730168-20-000109:mdna:13]
In response to the COVID-19 pandemic and the various resulting government directives, we took proactive measures to protect the health and safety of our employees, contractors, customers and visitors to our facilities. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-20-000109:mdna:14]
The demand environment for our semiconductor products was consistent with our expectations for our second quarter of fiscal year 2020, with substantial demand driven by a need for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this segment, the environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, lead times have extended making it difficult to obtain necessary inputs and supply in a timely manner. In addition, our primary warehouse facility and many of our key suppliers are in Malaysia and other parts of the Asia-Pacific region, where COVID-19 lockdowns have resulted in significant logistical challenges and further delays.

[0001730168-20-000109:mdna:15]
We are also taking various actions to de-risk our business in light of the ongoing uncertainty. For example, we are principally building semiconductor products to order, instead of based on customer forecasts, and reducing semiconductor inventory in our distribution channels. In addition, during the second fiscal quarter and into the third fiscal quarter, we took various actions to strengthen our balance sheet, including closely managing working capital, increasing our liquidity, and refinancing and extending the maturities of many of our debt instruments.

[0001730168-20-000109:mdna:16]
Overall, in light of the changing nature and continuing uncertainty around the COVID-19 pandemic, our ability to predict the impact of COVID-19 on our business in future periods remains limited. The effects of the pandemic on our semiconductor business are unlikely to be fully realized, or reflected in our financial results, until future periods.

[0001730168-20-000109:mdna:17]
[same as prior period, unchanged from 0001730168-20-000045:mdna:13]

[0001730168-20-000109:mdna:18]
[same as prior period, unchanged from 0001730168-20-000045:mdna:14]

[0001730168-20-000109:mdna:19]
During the fiscal quarter ended February 2, 2020, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation (now known as NortonLifeLock Inc.) Enterprise Security business (the “Symantec Business”) for $10.7 billion (the “Symantec Asset Purchase”). We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications.

[0001730168-20-000109:mdna:20]
[same as prior period, unchanged from 0001730168-20-000045:mdna:16]

[0001730168-20-000109:mdna:21]
[same as prior period, unchanged from 0001730168-20-000045:mdna:17]

[0001730168-20-000109:mdna:22]
Recent Developments

[0001730168-20-000109:mdna:23]
In May 2020, we issued $8 billion of senior unsecured notes. The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, were used to repay an aggregate of $5,424 million of term loans outstanding under our credit agreement dated November 4, 2019, consisting of repayments of $2,712 million of each of our unsecured term A-3 facility and unsecured term A-5 facility (collectively, the “November 2019 Term Loans”), and $3,000 million of borrowings outstanding under the Revolving Facility. We also issued $3,917 million in aggregate principal amount of new senior notes due in 2026 and 2028, in exchange for $3,742 million in aggregate principal amount of existing senior notes due 2021, 2022 and 2024, pursuant to an exchange offer that we completed on June 4, 2020. See Note 8. “Borrowings” in Part I, Item 1 of this Form 10-Q for additional information.

[0001730168-20-000109:mdna:24]
30

[0001730168-20-000109:mdna:25]
[same as prior period, unchanged from 0001730168-20-000045:mdna:18]

[0001730168-20-000109:mdna:26]
[same as prior period, unchanged from 0001730168-20-000045:mdna:19]

[0001730168-20-000109:mdna:27]
There were no significant changes in our critical accounting policies during the two fiscal quarters ended May 3, 2020 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2019 Annual Report on Form 10-K.

[0001730168-20-000109:mdna:28]
[same as prior period, unchanged from 0001730168-20-000045:mdna:21]

[0001730168-20-000109:mdna:29]
Fiscal Quarter and Two Fiscal Quarters Ended  May 3, 2020 Compared to Fiscal Quarter and Two Fiscal Quarters Ended  May 5, 2019

[0001730168-20-000109:mdna:30]
The following tables set forth our results of operations for the periods presented:

[0001730168-20-000109:mdna:31]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |  | (As a percentage of total net revenue) |  |  |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 4,253 |  |  | $ | 4,418 |  |  | 74 | % |  | 80 | % |
| Subscriptions and services |  | 1,489 |  |  | 1,099 |  |  | 26 |  |  | 20 |  |
| Total net revenue |  | 5,742 |  |  | 5,517 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,448 |  |  | 1,457 |  |  | 25 |  |  | 27 |  |
| Cost of subscriptions and services |  | 144 |  |  | 135 |  |  | 3 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 954 |  |  | 826 |  |  | 17 |  |  | 15 |  |
| Restructuring charges |  | 7 |  |  | 10 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,553 |  |  | 2,428 |  |  | 45 |  |  | 44 |  |
| Gross margin |  | 3,189 |  |  | 3,089 |  |  | 55 |  |  | 56 |  |
| Research and development |  | 1,269 |  |  | 1,151 |  |  | 22 |  |  | 21 |  |
| Selling, general and administrative |  | 501 |  |  | 419 |  |  | 9 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 599 |  |  | 473 |  |  | 10 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 54 |  |  | 76 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 2,423 |  |  | 2,119 |  |  | 42 |  |  | 38 |  |
| Operating income |  | $ | 766 |  |  | $ | 970 |  |  | 13 | % |  | 18 | % |

[0001730168-20-000109:mdna:32]
|  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |  | (As a percentage of total net revenue) |  |  |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 8,457 |  |  | $ | 9,057 |  |  | 73 | % |  | 80 | % |
| Subscriptions and services |  | 3,143 |  |  | 2,249 |  |  | 27 |  |  | 20 |  |
| Total net revenue |  | 11,600 |  |  | 11,306 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 2,907 |  |  | 3,011 |  |  | 25 |  |  | 27 |  |
| Cost of subscriptions and services |  | 321 |  |  | 273 |  |  | 3 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 1,904 |  |  | 1,659 |  |  | 16 |  |  | 15 |  |
| Restructuring charges |  | 15 |  |  | 66 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 5,147 |  |  | 5,009 |  |  | 44 |  |  | 44 |  |
| Gross margin |  | 6,453 |  |  | 6,297 |  |  | 56 |  |  | 56 |  |
| Research and development |  | 2,558 |  |  | 2,284 |  |  | 22 |  |  | 20 |  |
| Selling, general and administrative |  | 1,102 |  |  | 890 |  |  | 10 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 1,202 |  |  | 949 |  |  | 10 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 111 |  |  | 649 |  |  | 1 |  |  | 6 |  |
| Total operating expenses |  | 4,973 |  |  | 4,772 |  |  | 43 |  |  | 42 |  |
| Operating income |  | $ | 1,480 |  |  | $ | 1,525 |  |  | 13 | % |  | 14 | % |

[0001730168-20-000109:mdna:33]
[same as prior period, unchanged from 0001730168-20-000045:mdna:25]

[0001730168-20-000109:mdna:34]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 14% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020 and May 5, 2019. Direct sales to Tech Data Corporation, also a distributor, accounted for 11% and 10% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively.

[0001730168-20-000109:mdna:35]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 30% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020 and approximately 30% and less than 40% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for less than 20% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2020, and for more than 10% and less than 20% of our net revenue for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-20-000109:mdna:36]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile handsets. In addition, the ongoing COVID-19 pandemic and related challenges and uncertainties may also cause our net revenue to fluctuate significantly and adversely affect our results of operations, as discussed above.

[0001730168-20-000109:mdna:37]
32

[0001730168-20-000109:mdna:38]
[same as prior period, unchanged from 0001730168-20-000045:mdna:29]

[0001730168-20-000109:mdna:39]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |
| Net Revenue by Segment |  | May 3,2020 |  | May 5,2019 |  | $ Change |  | % Change |  | May 3, 2020 |  | May 5, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,027 |  |  | $ | 4,104 |  |  | $ | (77) |  |  | (2) | % |  | $ | 8,218 |  |  | $ | 8,490 |  |  | $ | (272) |  |  | (3) | % |
| Infrastructure software |  | 1,715 |  |  | 1,413 |  |  | 302 |  |  | 21 | % |  | 3,382 |  |  | 2,816 |  |  | 566 |  |  | 20 | % |
| Total net revenue |  | $ | 5,742 |  |  | $ | 5,517 |  |  | $ | 225 |  |  | 4 | % |  | $ | 11,600 |  |  | $ | 11,306 |  |  | $ | 294 |  |  | 3 | % |

[0001730168-20-000109:mdna:40]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
| % of Net Revenue by Segment |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
| Semiconductor solutions |  | 70 | % |  | 74 | % |  | 71 | % |  | 75 | % |
| Infrastructure software |  | 30 |  |  | 26 |  |  | 29 |  |  | 25 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-20-000109:mdna:41]
Fiscal quarter ended May 3, 2020 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to lower demand for our broadband products, partially offset by increases in wireless volume and content in mobile handsets, as well as an increase in demand for our storage products. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000109:mdna:42]
Two fiscal quarters ended May 3, 2020 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment decreased primarily due to a decrease in demand for our mixed signal custom products, as well as decreases in demand for our broadband and certain networking products. These decreases were partially offset by an increase in demand for our storage products and an increase in wireless content in mobile handsets. Net revenue from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, as well as an increase in demand for our mainframe and enterprise software solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000109:mdna:43]
[same as prior period, unchanged from 0001730168-20-000045:mdna:33]

[0001730168-20-000109:mdna:44]
Gross margin was $3,189 million for the fiscal quarter ended May 3, 2020 compared to $3,089 million for the fiscal quarter ended May 5, 2019 and was $6,453 million for the two fiscal quarters ended May 3, 2020 compared to $6,297 million for the two fiscal quarters ended May 5, 2019. As a percentage of net revenue, gross margin was 55% and 56% of net revenue for the fiscal quarters ended May 3, 2020 and May 5, 2019, respectively, and 56% of net revenue for each of the two fiscal quarters ended May 3, 2020 and May 5, 2019.

[0001730168-20-000109:mdna:45]
Gross margin was relatively flat for the fiscal quarter and two fiscal quarters ended May 3, 2020 and May 5, 2019. Gross margin contributions from our Symantec enterprise security solutions were substantially offset by the effects of unfavorable product mix in our semiconductor solutions products.

[0001730168-20-000109:mdna:46]
[same as prior period, unchanged from 0001730168-20-000045:mdna:36]

[0001730168-20-000109:mdna:47]
Research and development expense increased $118 million, or 10%, and $274 million, or 12%, for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to the Symantec Asset Purchase. The increase for the two fiscal quarters was also due to higher stock-based compensation expense. The increase in stock-based compensation expense primarily resulted from the recognition of two full quarters of expense in the two fiscal quarters ended May 3, 2020 for the multi-year equity grants of restricted stock units issued during the first quarter of fiscal year 2019 (“Multi-Year Equity Awards”).

[0001730168-20-000109:mdna:48]
[same as prior period, unchanged from 0001730168-20-000045:mdna:38]

[0001730168-20-000109:mdna:49]
Selling, general and administrative expense increased $82 million, or 20%, and $212 million, or 24%, for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to the Symantec Asset Purchase and associated acquisition-related costs, partially offset by decreases in stock-based compensation expense. The decreases in stock-based compensation expense were due to the full vesting of certain equity awards, including equity awards assumed from the acquisition of CA, Inc. (“CA Merger”). The decrease in the two fiscal quarters was partially offset by the recognition of two full quarters of expense associated with Multi-Year Equity Awards.

[0001730168-20-000109:mdna:50]
[same as prior period, unchanged from 0001730168-20-000045:mdna:40]

[0001730168-20-000109:mdna:51]
Amortization of acquisition-related intangible assets recognized in operating expenses increased $126 million and $253 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to intangible assets acquired in the Symantec Asset Purchase.

[0001730168-20-000109:mdna:52]
[same as prior period, unchanged from 0001730168-20-000045:mdna:42]

[0001730168-20-000109:mdna:53]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $22 million and $538 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to the prior year fiscal periods. These charges were higher in the fiscal quarter and two fiscal quarters ended May 5, 2019 due to employee termination costs, as well as lease and other exit costs resulting from the CA Merger.

[0001730168-20-000109:mdna:54]
[same as prior period, unchanged from 0001730168-20-000045:mdna:44]

[0001730168-20-000109:mdna:55]
|  |  | Fiscal Quarter Ended |  |  |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |
| Operating Income by Segment |  | May 3,2020 |  | May 5,2019 |  | $ Change |  | % Change |  | May 3, 2020 |  | May 5, 2019 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 1,840 |  |  | $ | 1,899 |  |  | $ | (59) |  |  | (3) | % |  | $ | 3,819 |  |  | $ | 3,931 |  |  | $ | (112) |  |  | (3) | % |
| Infrastructure software |  | 1,191 |  |  | 1,050 |  |  | 141 |  |  | 13 | % |  | 2,296 |  |  | 2,070 |  |  | 226 |  |  | 11 | % |
| Unallocated expenses |  | (2,265) |  |  | (1,979) |  |  | (286) |  |  | 14 | % |  | (4,635) |  |  | (4,476) |  |  | (159) |  |  | 4 | % |
| Total operating income |  | $ | 766 |  |  | $ | 970 |  |  | $ | (204) |  |  | (21) | % |  | $ | 1,480 |  |  | $ | 1,525 |  |  | $ | (45) |  |  | (3) | % |

[0001730168-20-000109:mdna:56]
Fiscal quarter ended May 3, 2020 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to lower demand for our broadband products, as well as less favorable product mix for certain networking products. These decreases were partially offset by increases in wireless volume and content in mobile handsets, as well as an increase in demand for our storage products. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000109:mdna:57]
Two fiscal quarters ended May 3, 2020 compared to corresponding prior year period. Operating income from our semiconductor solutions segment decreased primarily due to decreases in demand for certain networking, broadband and mixed signal custom products. These decreases were partially offset by an increase in demand for our storage products. Operating income from our infrastructure software segment increased primarily due to contributions from our Symantec enterprise security solutions, partially offset by lower demand for our FC SAN products.

[0001730168-20-000109:mdna:58]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; acquisition-related costs; restructuring, impairment and disposal charges; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 14% and 4% for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher amortization of acquisition-related intangible assets and acquisition-related costs, partially offset by lower restructuring, impairment and disposal charges.

[0001730168-20-000109:mdna:59]
[same as prior period, unchanged from 0001730168-20-000045:mdna:48]

[0001730168-20-000109:mdna:60]
Interest expense. Interest expense was $487 million and $893 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, and $376 million and $721 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. The increases were primarily due to interest on the debt we incurred to finance the Symantec Asset Purchase, as well as a loss on extinguishment of debt related to the repurchase of certain senior notes in the fiscal quarter ended May 3, 2020.

[0001730168-20-000109:mdna:61]
Other income, net. Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net was $130 million and $126 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, as compared to $63 million and $131 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Other income, net for the fiscal quarter and two fiscal quarters ended May 3, 2020 included a $116 million one-time gain from the lapse of a tax indemnification arrangement, partially offset by  decreases in gains on investments and foreign currency remeasurement.

[0001730168-20-000109:mdna:62]
Benefit from income taxes. The benefit from income taxes was $159 million and $235 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, and $36 million and $239 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 3, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards that vested or were exercised during the period.

[0001730168-20-000109:mdna:63]
The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 5, 2019 was primarily due to excess tax benefits from stock-based awards that vested or were exercised during the period and also included the impact of several provisions of the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”) that took effect for us for the first time in fiscal year 2019. These provisions included a new minimum tax on certain foreign earnings, known as Global Intangible Low-taxed Income (“GILTI”), a new incentive for foreign-derived intangible income, changes to the limitation on the deductibility of certain executive compensation, and new limitations on the deductibility of interest expense. We accounted for GILTI as a period cost rather than on a deferred basis.

[0001730168-20-000109:mdna:64]
Additionally, for the two fiscal quarters ended May 5, 2019, our benefit from income taxes was due to the recognition of gross uncertain tax benefits as a result of audit settlements, lapses of statutes of limitations and a partial release of our valuation allowance resulting from the CA Merger.

[0001730168-20-000109:mdna:65]
[same as prior period, unchanged from 0001730168-20-000045:mdna:52]

[0001730168-20-000109:mdna:66]
[same as prior period, unchanged from 0001730168-20-000045:mdna:53]

[0001730168-20-000109:mdna:67]
Our primary sources of liquidity as of May 3, 2020 consisted of: (i) $9,207 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $5 billion Revolving Facility. In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-20-000109:mdna:68]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $46,176 million of outstanding indebtedness and (vi) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-20-000109:mdna:69]
[same as prior period, unchanged from 0001730168-20-000045:mdna:56]

[0001730168-20-000109:mdna:70]
In this unprecedented environment, as a result of the COVID-19 pandemic, we took actions to enhance our balance sheet strength and liquidity position. During the fiscal quarter ended May 3, 2020, we drew down $3 billion under the Revolving Facility, issued $4,500 million aggregate principal amount of senior notes due in 2025 and 2030, repurchased $3,986 million aggregate principal amount of senior notes due in 2021 and 2022 pursuant to a cash tender offer and repaid our unsecured commercial paper borrowings of $1,972 million using funds drawn under the Revolving Facility. Following the end of the fiscal quarter ended May 3, 2020, we issued $8 billion aggregate principal amount of senior notes due in 2023, 2025, 2030 and 2032, the net proceeds of which, together with the remaining proceeds from the issuance of the April 2020 Senior Notes, were used to repay an aggregate of $5,424 million of our November 2019 Term Loans and $3 billion of borrowings outstanding under the Revolving Facility. We also issued $3,917 million aggregate principal amount of senior notes due in 2026 and 2028 in exchange for $3,742 million aggregate principal amount of senior notes due in 2021, 2022 and 2024 pursuant to an exchange offer. We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months.

[0001730168-20-000109:mdna:71]
[same as prior period, unchanged from 0001730168-20-000045:mdna:58]

[0001730168-20-000109:mdna:72]
[same as prior period, unchanged from 0001730168-20-000045:mdna:59]

[0001730168-20-000109:mdna:73]
Working capital increased to $7,621 million at May 3, 2020 from $3,018 million at November 3, 2019. The increase was primarily attributable to the following:

[0001730168-20-000109:mdna:74]
•Cash and cash equivalents increased to $9,207 million at May 3, 2020 from $5,055 million at November 3, 2019, primarily due to $21,592 million in proceeds from borrowings and $5,535 million in net cash provided by operating activities. These increases were partially offset by $10,700 million paid for the Symantec Asset Purchase, $8,989 million of debt repayments, and $2,753 million of dividend payments.

[0001730168-20-000109:mdna:75]
•Other current assets increased to $851 million at May 3, 2020 from $729 million at November 3, 2019, primarily due to increases in prepaid taxes and other receivables.

[0001730168-20-000109:mdna:76]
•Employee compensation and benefits liabilities decreased to $494 million at May 3, 2020 from $641 million at November 3, 2019, primarily due to the timing of employee bonus plan payments.

[0001730168-20-000109:mdna:77]
•Current portion of long-term debt decreased to $819 million at May 3, 2020 from $2,787 million at November 3, 2019 due to repayment of certain debt, partially offset by additional amounts coming due within twelve months.

[0001730168-20-000109:mdna:78]
[same as prior period, unchanged from 0001730168-20-000045:mdna:66]

[0001730168-20-000109:mdna:79]
•Accounts payable increased to $1,230 million at May 3, 2020 from $855 million at November 3, 2019, primarily due to timing of vendor payments.

[0001730168-20-000109:mdna:80]
•Other current liabilities increased to $4,058 million at May 3, 2020 from $2,616 million at November 3, 2019, primarily due to the Symantec Asset Purchase and increases in contract liabilities, lease liabilities resulting from the adoption of Accounting Standard Codification Topic 842, and taxes payable, partially offset by repayments of notional pooling liabilities.

[0001730168-20-000109:mdna:81]
Working capital decreased to $2,174 million at May 5, 2019 from $6,769 million at November 4, 2018. The decrease was attributable to the following:

[0001730168-20-000109:mdna:82]
•Current portion of long-term debt increased by $3,537 million due to certain debt instruments becoming due within twelve months.

[0001730168-20-000109:mdna:83]
•Other current liabilities increased to $3,729 million at May 5, 2019 from $812 million at November 4, 2018, primarily due to liabilities assumed in the CA Merger and increases in contract liabilities from adoption of Accounting Standard Codification Topic 606 (“Topic 606”), notional pooling liabilities, restructuring reserves, and interest payable.

[0001730168-20-000109:mdna:84]
•Inventory decreased to $1,034 million at May 5, 2019 from $1,124 million at November 4, 2018, primarily due to consumption to support customer shipments.

[0001730168-20-000109:mdna:85]
[same as prior period, unchanged from 0001730168-20-000045:mdna:72]

[0001730168-20-000109:mdna:86]
•Cash and cash equivalents increased to $5,328 million at May 5, 2019 from $4,292 million at November 4, 2018, primarily due to $30,368 million in proceeds from borrowings, $4,799 million in net cash provided by operating activities and $957 million in proceeds from the sale of Veracode, Inc., a wholly-owned subsidiary acquired in the CA Merger, partially offset by $16,027 million paid for the CA Merger, $12 billion of debt repayments, $4,266 million of common stock repurchases and $2,124 million of dividend payments.

[0001730168-20-000109:mdna:87]
•Other current assets increased to $831 million at May 5, 2019 from $366 million at November 4, 2018, primarily due to assets acquired in the CA Merger and increases in taxes receivable, other receivables and contract assets from Topic 606 adoption.

[0001730168-20-000109:mdna:88]
•Accounts receivable increased to $3,484 million at May 5, 2019 from $3,325 million at November 4, 2018, primarily due to revenue linearity and an increase due to the CA Merger.

[0001730168-20-000109:mdna:89]
•Employee compensation and benefits decreased to $478 million at May 5, 2019 from $715 million at November 4, 2018, primarily due to timing of employee bonus plan payments, partially offset by increases attributable to the CA Merger.

[0001730168-20-000109:mdna:90]
[same as prior period, unchanged from 0001730168-20-000045:mdna:79]

[0001730168-20-000109:mdna:91]
|  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions, except per share data) |  |  |
| Dividends per share to common stockholders |  | $ | 6.50 |  |  | $ | 5.30 |  |
| Dividends to common stockholders |  | $ | 2,603 |  |  | $ | 2,124 |  |
| Dividends per share to preferred stockholders |  | $ | 40.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 150 |  |  | $ | — |  |
| Stock repurchases |  | $ | — |  |  | $ | 4,266 |  |

[0001730168-20-000109:mdna:92]
In addition, during the two fiscal quarters ended May 3, 2020 and May 5, 2019, we paid approximately $388 million and $577 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the two fiscal quarters ended May 3, 2020 and May 5, 2019.

[0001730168-20-000109:mdna:93]
[same as prior period, unchanged from 0001730168-20-000045:mdna:82]

[0001730168-20-000109:mdna:94]
|  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |
| Net cash provided by operating activities |  | $ | 5,535 |  |  | $ | 4,799 |  |
| Net cash used in investing activities |  | (10,963) |  |  | (15,299) |  |
| Net cash provided by financing activities |  | 9,580 |  |  | 11,536 |  |
| Net change in cash and cash equivalents |  | $ | 4,152 |  |  | $ | 1,036 |  |

[0001730168-20-000109:mdna:95]
[same as prior period, unchanged from 0001730168-20-000045:mdna:84]

[0001730168-20-000109:mdna:96]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $736 million increase in cash provided by operations during the two fiscal quarters ended May 3, 2020 compared to the two fiscal quarters ended May 5, 2019 was primarily due to cash flows from net income adjusted for non-cash items, including amortization of intangible and right-of-use assets, stock-based compensation, depreciation and deferred taxes and other non-cash taxes.

[0001730168-20-000109:mdna:97]
[same as prior period, unchanged from 0001730168-20-000045:mdna:86]

[0001730168-20-000109:mdna:98]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures and proceeds from sales of businesses. The $4,336 million decrease in cash used in investing activities during the two fiscal quarters ended May 3, 2020 compared to the two fiscal quarters ended May 5, 2019 was primarily related to $10,700 million paid for the Symantec Asset Purchase in the fiscal year 2020 period, compared to $16,027 million paid for the CA Merger in the prior fiscal year period, offset in part by $789 million less in proceeds received from sales of businesses in the fiscal year 2020 period.

[0001730168-20-000109:mdna:99]
[same as prior period, unchanged from 0001730168-20-000045:mdna:88]

[0001730168-20-000109:mdna:100]
Cash flows from financing activities primarily consisted of net proceeds and payments related to our long-term debt, dividend payments and stock repurchases. The $1,956 million decrease in cash provided by financing activities during the two fiscal quarters ended May 3, 2020 compared to the two fiscal quarters ended May 5, 2019 was primarily due to a decrease of $5,765 million in net proceeds from borrowings and an increase of $629 million of dividend payments, partially offset by an absence of repurchases of common stock under our repurchase program, which ended in fiscal year 2019, as compared to $4,266 million of repurchases in the fiscal year 2019 period.

[0001730168-20-000109:mdna:101]
[same as prior period, unchanged from 0001730168-20-000045:mdna:90]

[0001730168-20-000109:mdna:102]
[same as prior period, unchanged from 0001730168-20-000045:mdna:91]

[0001730168-20-000109:mdna:103]
Summarized Obligor Group Financial Information

[0001730168-20-000109:mdna:104]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), Broadcom Corporation (“BRCM”) and Broadcom Cayman Finance Limited (“Cayman Finance,” together with BRCM, the “Co-Issuers”), 100%-owned subsidiaries of Broadcom, issued $13,550 million and $4,000 million aggregate principal amount of notes,

[0001730168-20-000109:mdna:105]
respectively (collectively, the “2017 Senior Notes”). Each series of the 2017 Senior Notes pays interest semi-annually in cash in arrears on January 15 and July 15 of each year. We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom and the Co-Issuers to merge, consolidate or sell all or substantially all of their assets. Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-20-000109:mdna:106]
Broadcom and Broadcom Technologies Inc. (“BTI”), a 100%-owned subsidiary of Broadcom, fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2017 Senior Notes. Because the guarantees are not secured, they are effectively subordinated to any existing and future secured indebtedness of the guarantors to the extent of the value of the collateral securing that indebtedness. The guarantee by Broadcom and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer (including through merger, consolidation, liquidation or dissolution) of all or substantially all of the assets of such guarantor if such sale, exchange, disposition or other transfer (including through merger, consolidation, liquidation or dissolution) is made in compliance with the 2017 Indentures. The guarantee by Broadcom (1) will also be automatically and unconditionally released at such time as: (A) the Co-Issuers, in their sole discretion, determine that such guarantee is no longer required by Rule 3-10(b), (c), (d) or (e), as applicable, of Regulation S-X promulgated by the SEC (or any successor statute, rule or other provision) to except the Co-Issuers’ financial statements from being required to be filed with the SEC pursuant to Rule 3-10(a)(1) of Regulation S-X promulgated by the SEC (or any successor statue, rule or other provision) or otherwise facilitate a reduction in its financial reporting obligations or (B) either of the Co-Issuers becomes subject to Section 13 or 15(d) of the Exchange Act and (2) may, at the election of the Co-Issuers, be unconditionally released at such time as Broadcom is eligible to suspend its reporting obligation under the Exchange Act.

[0001730168-20-000109:mdna:107]
During fiscal year 2019, Cayman Finance was merged into BTI, with BTI remaining as the surviving entity. In connection with this merger, BTI remains a guarantor and became a co-issuer of the 2017 Senior Notes. Broadcom, as the parent guarantor of the 2017 Senior Notes, with co-issuers BTI and BRCM, are referred to herein collectively as the Obligor Group.

[0001730168-20-000109:mdna:108]
The following tables set forth the summarized financial information of the Obligor Group on a combined basis for the periods presented. This summarized financial information excludes any subsidiaries that are not issuers or guarantors (the “Non-Obligor Group”). Intercompany balances and transactions between members of the Obligor Group have been eliminated.

[0001730168-20-000109:mdna:109]
38

[0001730168-20-000109:mdna:110]
| Summarized Balance Sheets |  | May 3,2020 |  |  |  |  |  |  |  |  |  | November 3,2019 |
|  |  | (In millions) |  |  |  |  |  |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 1,852 |  |  |  |  |  |  |  |  |  |  | $ | 1,617 |  |
| Other current assets |  | 4,228 |  |  |  |  |  |  |  |  |  |  | 1,082 |  |
| Total current assets |  | $ | 6,080 |  |  |  |  |  |  |  |  |  |  | $ | 2,699 |  |
| Long-term assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 8,220 |  |  |  |  |  |  |  |  |  |  | $ | — |  |
| Goodwill |  | 1,360 |  |  |  |  |  |  |  |  |  |  | 1,360 |  |
| Other long-term assets |  | 1,265 |  |  |  |  |  |  |  |  |  |  | 955 |  |
| Total long-term assets |  | $ | 10,845 |  |  |  |  |  |  |  |  |  |  | $ | 2,315 |  |
| LIABILITIES |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 7,322 |  |  |  |  |  |  |  |  |  |  | $ | 9,223 |  |
| Current portion of long-term debt |  | 807 |  |  |  |  |  |  |  |  |  |  | 2,750 |  |
| Other current liabilities |  | 223 |  |  |  |  |  |  |  |  |  |  | 452 |  |
| Total current liabilities |  | $ | 8,352 |  |  |  |  |  |  |  |  |  |  | $ | 12,425 |  |
| Long-term liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amount due to Non-Obligor Group, long-term |  | $ | 932 |  |  |  |  |  |  |  |  |  |  | $ | 932 |  |
| Long-term debt |  | 43,912 |  |  |  |  |  |  |  |  |  |  | 28,171 |  |
| Other long-term liabilities |  | 2,453 |  |  |  |  |  |  |  |  |  |  | 2,108 |  |
| Total long-term liabilities |  | $ | 47,297 |  |  |  |  |  |  |  |  |  |  | $ | 31,211 |  |

[0001730168-20-000109:mdna:111]
|  |  | Two Fiscal Quarters Ended |  |  |  |  |  |  |  |  |
| Summarized Statement of Operations |  | May 3,2020 |  |  |  |  |  |  |  |  |
|  |  | (In millions) |  |  |  |  |  |  |  |  |
| Intercompany revenue with Non-Obligor Group |  | $ | 811 |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 737 |  |  |  |  |  |  |  |  |  |
| Loss from continuing operations (a) |  | $ | (1,012) |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (1,012) |  |  |  |  |  |  |  |  |  |

[0001730168-20-000109:mdna:112]
_________________________________

[0001730168-20-000109:mdna:113]
(a) Included $307 million of net income from the Non-Obligor Group related to intercompany transactions.

[0001730168-20-000109:mdna:114]
[same as prior period, unchanged from 0001730168-20-000045:mdna:92]

[0001730168-20-000109:mdna:115]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000109:mdna:116]
[same as prior period, unchanged from 0001730168-20-000045:mdna:94]

[0001730168-20-000109:mdna:117]
We had no material off-balance sheet arrangements at May 3, 2020 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-20-000109:mdna:118]
[same as prior period, unchanged from 0001730168-20-000045:mdna:96]

[0001730168-20-000109:mdna:119]
See Note 12. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-20-000109:mdna:120]
[same as prior period, unchanged from 0001730168-20-000045:mdna:98]

[0001730168-20-000109:mdna:121]
[same as prior period, unchanged from 0001730168-20-000045:mdna:99]
