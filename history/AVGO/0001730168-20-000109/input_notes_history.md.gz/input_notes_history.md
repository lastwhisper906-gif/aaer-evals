# AVGO note change history — 0001730168-20-000045 → 0001730168-20-000109


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-06-12):
[0001730168-20-000109:note_history:1]
The following table summarizes contractual obligations and commitments as of May 3, 2020 that materially changed from the end of fiscal year 2019:
  (was, 2020-03-13, similarity 0.9753):
[0001730168-20-000045:note_history:1]
The following table summarizes contractual obligations and commitments as of February 2, 2020 that materially changed from the end of fiscal year 2019:

- changed (2020-06-12):
[0001730168-20-000109:note_history:2]
|  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt principal, interest and fees |  | $ | 53,832 |  |  | $ | 4,520 |  |  | $ | 4,058 |  |  | $ | 6,015 |  |  | $ | 8,729 |  |  | $ | 6,563 |  |  | $ | 23,947 |  |
| Purchase commitments |  | 852 |  |  | 754 |  |  | 65 |  |  | 33 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 943 |  |  | 97 |  |  | 161 |  |  | 148 |  |  | 141 |  |  | 97 |  |  | 299 |  |
| Total |  | $ | 55,627 |  |  | $ | 5,371 |  |  | $ | 4,284 |  |  | $ | 6,196 |  |  | $ | 8,870 |  |  | $ | 6,660 |  |  | $ | 24,246 |  |
  (was, 2020-03-13, similarity 0.962):
[0001730168-20-000045:note_history:2]
|  |  |  |  | Fiscal Year |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |
| Debt principal, interest and fees |  | $ | 51,917 |  |  | $ | 4,236 |  |  | $ | 5,668 |  |  | $ | 8,289 |  |  | $ | 8,560 |  |  | $ | 6,382 |  |  | $ | 18,782 |  |
| Purchase commitments |  | 823 |  |  | 743 |  |  | 64 |  |  | 16 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 550 |  |  | 137 |  |  | 105 |  |  | 90 |  |  | 81 |  |  | 72 |  |  | 65 |  |
| Total |  | $ | 53,290 |  |  | $ | 5,116 |  |  | $ | 5,837 |  |  | $ | 8,395 |  |  | $ | 8,641 |  |  | $ | 6,454 |  |  | $ | 18,847 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:3]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 3, 2020.
  (was, 2020-03-13, similarity 0.9834):
[0001730168-20-000045:note_history:3]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended February 2, 2020.

- changed (2020-06-12):
[0001730168-20-000109:note_history:4]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.
  (was, 2020-03-13, similarity 0.9342):
[0001730168-20-000045:note_history:4]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to information technology, human resources, and other service agreements.

- changed (2020-06-12):
[0001730168-20-000109:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 3, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,300 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 3, 2020 have been excluded from the contractual obligations table above.
  (was, 2020-03-13, similarity 0.9816):
[0001730168-20-000045:note_history:5]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at February 2, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,297 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of February 2, 2020 have been excluded from the contractual obligations table above.

- changed (2020-06-12):
[0001730168-20-000109:note_history:6]
As of May 3, 2020 and November 3, 2019, we had standby letters of credit of $57 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.
  (was, 2020-03-13, similarity 0.9862):
[0001730168-20-000045:note_history:6]
As of February 2, 2020 and November 3, 2019, we had standby letters of credit of $59 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- changed (2020-06-12):
[0001730168-20-000109:note_history:7]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.
  (was, 2020-03-13, similarity 0.9996):
[0001730168-20-000045:note_history:7]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our line of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- changed (2020-06-12):
[0001730168-20-000109:note_history:8]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties have filed post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.
  (was, 2020-03-13, similarity 0.9932):
[0001730168-20-000045:note_history:8]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties will file post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

- added (2020-06-12):
[0001730168-20-000109:note_history:9]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

- changed (2020-06-12):
[0001730168-20-000109:note_history:10]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice
  (was, 2020-03-13, similarity 0.7925):
[0001730168-20-000045:note_history:10]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, AT Wireless and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Exchange Act. The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint

- changed (2020-06-12):
[0001730168-20-000109:note_history:11]
on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.
  (was, 2020-03-13, similarity 0.9338):
[0001730168-20-000045:note_history:11]
seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

- removed (2020-06-12):
[0001730168-20-000045:note_history:12]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-06-12):
[0001730168-20-000109:note_history:13]
Overview, Basis of Presentation and Significant Accounting Policies
Overview

- changed (2020-06-12):
[0001730168-20-000109:note_history:14]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.
  (was, 2020-03-13, similarity 0.9964):
[0001730168-20-000045:note_history:14]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ends on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

- changed (2020-06-12):
[0001730168-20-000109:note_history:15]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 3, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.
  (was, 2020-03-13, similarity 0.9781):
[0001730168-20-000045:note_history:15]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter ended February 2, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

- added (2020-06-12):
[0001730168-20-000109:note_history:16]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

- added (2020-06-12):
[0001730168-20-000109:note_history:17]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for

- added (2020-06-12):
[0001730168-20-000109:note_history:18]
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.

- added (2020-06-12):
[0001730168-20-000109:note_history:19]
Recent Accounting Guidance Not Yet Adopted

- added (2020-06-12):
[0001730168-20-000109:note_history:20]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. We are currently evaluating the impact of this guidance on our contracts, including but not limited to our credit agreements.

- removed (2020-06-12):
[0001730168-20-000045:note_history:21]
Overview

- removed (2020-06-12):
[0001730168-20-000045:note_history:22]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates, and such differences could affect the results of operations reported in future periods.

- removed (2020-06-12):
[0001730168-20-000045:note_history:23]
In February 2016, the Financial Accounting Standards Board issued ASU 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of the comparative period is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets

- removed (2020-06-12):
[0001730168-20-000045:note_history:24]
included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statement of operations and comprehensive income and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-06-12):
[0001730168-20-000109:note_history:25]
The future scheduled principal payments of debt as of May 3, 2020 were as follows:
  (was, 2020-03-13, similarity 0.9565):
[0001730168-20-000045:note_history:25]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-12):
[0001730168-20-000109:note_history:26]
|  |  | May 3,2020 |  |  |  | November 3,2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | $ | 2,250 |  |  |  |  | $ | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 2.38 | % |  | 7,556 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 2.40 | % |  | 7,556 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  | 2.35 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  | 2.44 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 726 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 399 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 1,139 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |  |  |  |
| Revolving facility under the 2019 Credit Agreement |  | 1.97 | % |  |  | 3,000 |  |  |  |  | — |  |
| Commercial paper |  | 2.90 | % | (a) | 28 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  |  | 22 |  |  | 2.59%- 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  |  | 46,176 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  |  | (368) |  |  |  |  | (261) |  |
| Total debt |  |  |  |  | $ | 45,808 |  |  |  |  | $ | 32,798 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:27]
(a) Represents the weighted average interest rate on outstanding commercial paper.
  (was, 2020-03-13, similarity 0.8283):
[0001730168-20-000045:note_history:27]
(a) Represents the weighted average interest rate on outstanding commercial paper for each of the periods presented.

- changed (2020-06-12):
[0001730168-20-000109:note_history:28]
As of May 3, 2020, $12 million and $43 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.
  (was, 2020-03-13, similarity 0.9804):
[0001730168-20-000045:note_history:28]
As of February 2, 2020, $11 million and $44 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- added (2020-06-12):
[0001730168-20-000109:note_history:29]
April 2020 Senior Notes

- added (2020-06-12):
[0001730168-20-000109:note_history:30]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our April 2020 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable April 2020 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. As of May 3, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- added (2020-06-12):
[0001730168-20-000109:note_history:31]
Pursuant to a cash tender offer that we completed on April 23, 2020, we repurchased $2,361 million of our 3.000% notes due January 2022, $1,274 million of our 3.125% notes due April 2021 and $351 million of our 2.200% notes due January 2021 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense in the condensed consolidated statements of operations.

- changed (2020-06-12):
[0001730168-20-000109:note_history:32]
November 2019 Term Loans
  (was, 2020-03-13, similarity 0.7273):
[0001730168-20-000045:note_history:32]
2020 Term Loans

- added (2020-06-12):
[0001730168-20-000109:note_history:33]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. Beginning the second quarter of fiscal year 2020, we are required to repay 2.5% of the original principal borrowed under our November 2019 Term Loans every quarter until their respective maturity dates, unless and to the extent any amounts prepaid under the November 2019 Term Loans are applied to these required amortization payments.

- changed (2020-06-12):
[0001730168-20-000109:note_history:34]
May 2019 Term Loans
  (was, 2020-03-13, similarity 0.8571):
[0001730168-20-000045:note_history:34]
2019 Term Loans

- added (2020-06-12):
[0001730168-20-000109:note_history:35]
In January 2020, we repaid an aggregate of $1,000 million of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities under the credit agreement entered into in May 2019 (the “2019 Credit Agreement”), using net proceeds from issuances of Commercial Paper, as defined below. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

- changed (2020-06-12):
[0001730168-20-000109:note_history:36]
In addition to these unsecured term facilities, the 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of May 3, 2020, we had $3 billion of borrowings outstanding under the Revolving Facility with a term of less than one month. We had no borrowings outstanding as of November 3, 2019 under the Revolving Facility. Per the terms of the 2019 Credit Agreement, we have the ability and intent to continuously refinance our borrowings under the Revolving Facility and have therefore recorded such borrowings as long-term debt.
  (was, 2020-03-13, similarity 0.7105):
[0001730168-20-000045:note_history:36]
The 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of February 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

- changed (2020-06-12):
[0001730168-20-000109:note_history:37]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of May 3, 2020 and November 3, 2019, we had $28 million and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than three months. As our commercial paper program is
  (was, 2020-03-13, similarity 0.7186):
[0001730168-20-000045:note_history:37]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of February 2, 2020 and November 3, 2019, we had $2 billion and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than seventy-five days. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance our Commercial Paper with newly issued Commercial Paper upon maturity. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- added (2020-06-12):
[0001730168-20-000109:note_history:38]
supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- added (2020-06-12):
[0001730168-20-000109:note_history:39]
May 2020 Senior Notes

- added (2020-06-12):
[0001730168-20-000109:note_history:40]
Subsequent to the fiscal quarter ended May 3, 2020, we issued $8,000 million of senior unsecured notes on May 8, 2020. These notes are comprised of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. Each series of our May 2020 Senior Notes pays interest semi-annually in arrears on May 15 and November 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities at a price equal to 100% of the principal amount, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, were used to repay an aggregate of $5,424 million of term loans outstanding under the 2020 Credit Agreement, consisting of repayments of $2,712 million of each of our unsecured term A-3 facility and unsecured term A-5 facility, and $3,000 million of borrowings outstanding under the Revolving Facility. The remaining term loans outstanding under the 2020 Credit Agreement are due more than one year after May 3, 2020 and were included in long-term debt.

- added (2020-06-12):
[0001730168-20-000109:note_history:41]
May 2020 Exchange Notes

- added (2020-06-12):
[0001730168-20-000109:note_history:42]
On June 4, 2020, subsequent to the fiscal quarter ended May 3, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024 (the “Exchange Offers”), for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “May 2020 Exchange Notes”). As a result of the settlement, we recorded $201 million and $117 million of our 3.125% notes due April 2021 and 2.200% notes due January 2021, respectively, as long-term debt as of May 3, 2020. The May 2020 Exchange Notes pay interest semi-annually in arrears on March 15 and September 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Exchange Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable May 2020 Exchange Notes, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Exchange Notes, plus accrued and unpaid interest.

- added (2020-06-12):
[0001730168-20-000109:note_history:43]
As of May 3, 2020, the estimated aggregate fair value of debt was $47,732 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans and May 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our revolver borrowings and Commercial Paper approximated their carrying value due to the short-term maturity of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- changed (2020-06-12):
[0001730168-20-000109:note_history:44]
The future scheduled principal payments of debt as of May 3, 2020 were as follows:
  (was, 2020-03-13, similarity 0.9565):
[0001730168-20-000045:note_history:44]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:

- changed (2020-06-12):
[0001730168-20-000109:note_history:45]
As of May 3, 2020 and November 3, 2019, we accrued interest payable of $190 million and $214 million, respectively, and were in compliance with all debt covenants.
  (was, 2020-03-13, similarity 0.977):
[0001730168-20-000045:note_history:45]
As of February 2, 2020 and November 3, 2019, we accrued interest payable of $203 million and $214 million, respectively, and were in compliance with all debt covenants.

- removed (2020-06-12):
[0001730168-20-000045:note_history:46]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| 2020 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 3.13 | % |  | $ | 7,750 |  |  |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 3.14 | % |  | 7,750 |  |  |  |  | — |  |
|  |  |  |  | 15,500 |  |  |  |  | — |  |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 2,000 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
|  |  |  |  | 11,000 |  |  |  |  | 11,000 |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.10 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.19 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
|  |  |  |  | 600 |  |  |  |  | 1,600 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 750 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 3,500 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
|  |  |  |  | 14,800 |  |  |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
|  |  |  |  | 1,100 |  |  |  |  | 1,850 |  |
| Commercial paper |  | 2.27 | % | (a) | 2,000 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  |  | 22 |  |  | 2.59% - 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 45,022 |  |  |  |  | 33,059 |  |
| Less: Unaccreted net discount and unamortized debt issuance costs |  |  |  | (359 | ) |  |  |  | (261 | ) |
| Total debt |  |  |  | $ | 44,663 |  |  |  |  | $ | 32,798 |  |

- removed (2020-06-12):
[0001730168-20-000045:note_history:47]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to pay off $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”).

- removed (2020-06-12):
[0001730168-20-000045:note_history:48]
In January 2020, we repaid $500 million of each of our unsecured term A-5 and A-7 facilities, collectively referred to as the “2019 Term Loans”, under the credit agreement entered into in May 2019 (the “2019 Credit Agreement), using net proceeds from Commercial Paper, as defined below.

- removed (2020-06-12):
[0001730168-20-000045:note_history:49]
As of February 2, 2020, the estimated aggregate fair value of debt was $46,381 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 and 2020 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-12):
[0001730168-20-000109:note_history:50]
Borrowings

- added (2020-06-12):
[0001730168-20-000109:note_history:51]
|  |  | May 3,2020 |  |  |  | November 3,2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | $ | 2,250 |  |  |  |  | $ | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 2.38 | % |  | 7,556 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 2.40 | % |  | 7,556 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  | 2.35 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  | 2.44 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 726 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 399 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 1,139 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |  |  |  |
| Revolving facility under the 2019 Credit Agreement |  | 1.97 | % |  |  | 3,000 |  |  |  |  | — |  |
| Commercial paper |  | 2.90 | % | (a) | 28 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  |  | 22 |  |  | 2.59%- 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  |  | 46,176 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  |  | (368) |  |  |  |  | (261) |  |
| Total debt |  |  |  |  | $ | 45,808 |  |  |  |  | $ | 32,798 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:52]
(a) Represents the weighted average interest rate on outstanding commercial paper.
  (was, 2020-03-13, similarity 0.8283):
[0001730168-20-000045:note_history:52]
(a) Represents the weighted average interest rate on outstanding commercial paper for each of the periods presented.

- removed (2020-06-12):
[0001730168-20-000045:note_history:53]
|  |  | February 2, 2020 |  | November 3, 2019 |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |
| 2020 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 3.13 | % |  | $ | 7,750 |  |  |  |  | $ | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 3.14 | % |  | 7,750 |  |  |  |  | — |  |
|  |  |  |  | 15,500 |  |  |  |  | — |  |
| 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 2,000 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
|  |  |  |  | 11,000 |  |  |  |  | 11,000 |  |
| 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due through May 2024 |  | 3.10 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due through May 2026 |  | 3.19 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
|  |  |  |  | 600 |  |  |  |  | 1,600 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 750 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 3,500 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
|  |  |  |  | 14,800 |  |  |  |  | 17,550 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
|  |  |  |  | 1,100 |  |  |  |  | 1,850 |  |
| Commercial paper |  | 2.27 | % | (a) | 2,000 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  |  | 22 |  |  | 2.59% - 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 45,022 |  |  |  |  | 33,059 |  |
| Less: Unaccreted net discount and unamortized debt issuance costs |  |  |  | (359 | ) |  |  |  | (261 | ) |
| Total debt |  |  |  | $ | 44,663 |  |  |  |  | $ | 32,798 |  |

- removed (2020-06-12):
[0001730168-20-000045:note_history:54]
As of February 2, 2020, $11 million and $44 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

- removed (2020-06-12):
[0001730168-20-000045:note_history:55]
2020 Term Loans

- removed (2020-06-12):
[0001730168-20-000045:note_history:56]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility, collectively referred to as the “2020 Term Loans”. Interest on our 2020 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the 2020 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to pay off $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”).

- removed (2020-06-12):
[0001730168-20-000045:note_history:57]
2019 Term Loans

- removed (2020-06-12):
[0001730168-20-000045:note_history:58]
In January 2020, we repaid $500 million of each of our unsecured term A-5 and A-7 facilities, collectively referred to as the “2019 Term Loans”, under the credit agreement entered into in May 2019 (the “2019 Credit Agreement), using net proceeds from Commercial Paper, as defined below.

- removed (2020-06-12):
[0001730168-20-000045:note_history:59]
The 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million was available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of February 2, 2020 and November 3, 2019, we had no borrowings outstanding under the Revolving Facility.

- removed (2020-06-12):
[0001730168-20-000045:note_history:60]
Commercial Paper

- removed (2020-06-12):
[0001730168-20-000045:note_history:61]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of February 2, 2020 and November 3, 2019, we had $2 billion and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than seventy-five days. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance our Commercial Paper with newly issued Commercial Paper upon maturity. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

- removed (2020-06-12):
[0001730168-20-000045:note_history:62]
Fair Value of Debt

- removed (2020-06-12):
[0001730168-20-000045:note_history:63]
As of February 2, 2020, the estimated aggregate fair value of debt was $46,381 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our 2019 and 2020 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our Commercial Paper approximated its carrying value due to the short-term nature of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

- removed (2020-06-12):
[0001730168-20-000045:note_history:64]
Future Principal Payments of Debt

- removed (2020-06-12):
[0001730168-20-000045:note_history:65]
The future scheduled principal payments of debt as of February 2, 2020 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-06-12):
[0001730168-20-000109:note_history:66]
|  |  | Fiscal Quarter Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:67]
|  |  | Fiscal Quarter Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services (a) |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:68]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:69]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services (a) |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- removed (2020-06-12):
[0001730168-20-000045:note_history:70]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- removed (2020-06-12):
[0001730168-20-000045:note_history:71]
|  |  | Fiscal Quarter Ended February 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services (a) |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-06-12):
[0001730168-20-000109:note_history:72]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 11. “Segment Information”.
  (was, 2020-03-13, similarity 0.9824):
[0001730168-20-000045:note_history:72]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations and comprehensive income. In addition, revenues by reportable segment are presented in Note 11. “Segment Information”.

- added (2020-06-12):
[0001730168-20-000109:note_history:73]
|  |  | Fiscal Quarter Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:74]
|  |  | Fiscal Quarter Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services (a) |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:75]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- added (2020-06-12):
[0001730168-20-000109:note_history:76]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services (a) |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:77]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of May 3, 2020 (a) |  | $ | 197 |  |  | $ | 3,776 |  |
  (was, 2020-03-13, similarity 0.9644):
[0001730168-20-000045:note_history:77]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of February 2, 2020 (a) |  | $ | 208 |  |  | $ | 3,668 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:78]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of May 3, 2020.
  (was, 2020-03-13, similarity 0.9674):
[0001730168-20-000045:note_history:78]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of February 2, 2020.

- changed (2020-06-12):
[0001730168-20-000109:note_history:79]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |
  (was, 2020-03-13, similarity 0.9644):
[0001730168-20-000045:note_history:79]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of February 3, 2019 |  | $ | 173 |  |  | $ | 2,209 |  |

- changed (2020-06-12):
[0001730168-20-000109:note_history:80]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019
  (was, 2020-03-13, similarity 0.9412):
[0001730168-20-000045:note_history:80]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $669 million. The amount of revenue recognized during the fiscal quarter ended February 3, 2019 that was included in the contract liabilities balance as of November 5, 2018 was $93 million.

- added (2020-06-12):
[0001730168-20-000109:note_history:81]
that was included in the contract liabilities balance as of November 5, 2018 was $144 million.

- changed (2020-06-12):
[0001730168-20-000109:note_history:82]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).
  (was, 2020-03-13, similarity 0.7845):
[0001730168-20-000045:note_history:82]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for CA where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists. This has been extended to all CA customers, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- changed (2020-06-12):
[0001730168-20-000109:note_history:83]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 3, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.
  (was, 2020-03-13, similarity 0.9915):
[0001730168-20-000045:note_history:83]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of February 2, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscription and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.

- removed (2020-06-12):
[0001730168-20-000045:note_history:84]
|  |  | Fiscal Quarter Ended February 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 440 |  |  | $ | 3,451 |  |  | $ | 313 |  |  | $ | 4,204 |  |
| Subscriptions and services (a) |  | 1,099 |  |  | 169 |  |  | 386 |  |  | 1,654 |  |
| Total |  | $ | 1,539 |  |  | $ | 3,620 |  |  | $ | 699 |  |  | $ | 5,858 |  |

- removed (2020-06-12):
[0001730168-20-000045:note_history:85]
|  |  | Fiscal Quarter Ended February 3, 2019 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 617 |  |  | $ | 3,720 |  |  | $ | 302 |  |  | $ | 4,639 |  |
| Subscriptions and services (a) |  | 816 |  |  | 114 |  |  | 220 |  |  | 1,150 |  |
| Total |  | $ | 1,433 |  |  | $ | 3,834 |  |  | $ | 522 |  |  | $ | 5,789 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-06-12):
[0001730168-20-000109:note_history:86]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2020 to stockholders of record on June 15, 2020.
  (was, 2020-03-13, similarity 0.9291):
[0001730168-20-000045:note_history:86]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on March 31, 2020 to stockholders of record on March 15, 2020.

- changed (2020-06-12):
[0001730168-20-000109:note_history:87]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on June 30, 2020 to stockholders of record on June 22, 2020.
  (was, 2020-03-13, similarity 0.9184):
[0001730168-20-000045:note_history:87]
On March 11, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on March 31, 2020 to stockholders of record on March 23, 2020.
