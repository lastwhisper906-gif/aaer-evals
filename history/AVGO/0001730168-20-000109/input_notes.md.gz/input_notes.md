# AVGO notes — 0001730168-20-000109


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-20-000109:notes:1]
Overview, Basis of Presentation and Significant Accounting Policies
Overview

[0001730168-20-000109:notes:2]
[same as prior period, unchanged from 0001730168-20-000045:notes:2]

[0001730168-20-000109:notes:3]
[same as prior period, unchanged from 0001730168-20-000045:notes:3]

[0001730168-20-000109:notes:4]
[same as prior period, unchanged from 0001730168-20-000045:notes:4]

[0001730168-20-000109:notes:5]
[same as prior period, unchanged from 0001730168-20-000045:notes:5]

[0001730168-20-000109:notes:6]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year 2020 is a 52-week fiscal year. The first quarter of our fiscal year 2020 ended on February 2, 2020, the second quarter ended on May 3, 2020 and the third quarter ends on August 2, 2020. Our fiscal year ended November 3, 2019 (“fiscal year 2019”) was also a 52-week fiscal year.

[0001730168-20-000109:notes:7]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2019 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2019 as filed with the Securities and Exchange Commission (the “SEC”). All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 3, 2020 are not necessarily indicative of the results that may be expected for fiscal year 2020, or for any other future period.

[0001730168-20-000109:notes:8]
[same as prior period, unchanged from 0001730168-20-000045:notes:8]

[0001730168-20-000109:notes:9]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

[0001730168-20-000109:notes:10]
[same as prior period, unchanged from 0001730168-20-000045:notes:10]

[0001730168-20-000109:notes:11]
Recently Adopted Accounting Guidance

[0001730168-20-000109:notes:12]
In February 2016, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (“Topic 842”), which requires a lessee to recognize lease assets and lease liabilities on the balance sheet for

[0001730168-20-000109:notes:13]
operating leases. At the beginning of fiscal year 2020, we adopted Topic 842 using the optional adoption method, whereby no adjustment to the financial statements of comparative periods is required. Upon adoption, we recorded net right-of-use (“ROU”) assets of $545 million and lease liabilities of $591 million and there were no cumulative effect adjustments as of November 4, 2019. The net ROU assets included the effect of reclassifying deferred rent and a portion of facilities-related restructuring reserves as an offset in accordance with the transition guidance. The standard did not materially affect the condensed consolidated statements of operations and the condensed consolidated statement of cash flows. See Note 5. “Leases” for further information.

[0001730168-20-000109:notes:14]
Recent Accounting Guidance Not Yet Adopted

[0001730168-20-000109:notes:15]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform. This guidance provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships and other transactions, subject to meeting certain criteria, that reference the London Interbank Offered Rate (“LIBOR”) or another reference rate expected to be discontinued because of reference rate reform. The amendments in this ASU were effective upon issuance and may be applied through December 31, 2022. We are currently evaluating the impact of this guidance on our contracts, including but not limited to our credit agreements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-20-000109:notes:16]
[same as prior period, unchanged from 0001730168-20-000045:notes:14]

[0001730168-20-000109:notes:17]
[same as prior period, unchanged from 0001730168-20-000045:notes:15]

[0001730168-20-000109:notes:18]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the Chief Operating Decision Maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 11. “Segment Information”.

[0001730168-20-000109:notes:19]
[same as prior period, unchanged from 0001730168-20-000045:notes:17]

[0001730168-20-000109:notes:20]
|  |  | Fiscal Quarter Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

[0001730168-20-000109:notes:21]
|  |  | Fiscal Quarter Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 608 |  |  | $ | 3,372 |  |  | $ | 438 |  |  | $ | 4,418 |  |
| Subscriptions and services (a) |  | 749 |  |  | 101 |  |  | 249 |  |  | 1,099 |  |
| Total |  | $ | 1,357 |  |  | $ | 3,473 |  |  | $ | 687 |  |  | $ | 5,517 |  |

[0001730168-20-000109:notes:22]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

[0001730168-20-000109:notes:23]
|  |  | Two Fiscal Quarters Ended May 5, 2019 |  |  |  |  |  |  |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |  |  |  |  |  |  |
| Products |  | $ | 1,225 |  |  | $ | 7,092 |  |  | $ | 740 |  |  | $ | 9,057 |  |
| Subscriptions and services (a) |  | 1,565 |  |  | 215 |  |  | 469 |  |  | 2,249 |  |
| Total |  | $ | 2,790 |  |  | $ | 7,307 |  |  | $ | 1,209 |  |  | $ | 11,306 |  |

[0001730168-20-000109:notes:24]
[same as prior period, unchanged from 0001730168-20-000045:notes:20]

[0001730168-20-000109:notes:25]
[same as prior period, unchanged from 0001730168-20-000045:notes:21]

[0001730168-20-000109:notes:26]
[same as prior period, unchanged from 0001730168-20-000045:notes:22]

[0001730168-20-000109:notes:27]
[same as prior period, unchanged from 0001730168-20-000045:notes:23]

[0001730168-20-000109:notes:28]
[same as prior period, unchanged from 0001730168-20-000045:notes:24]

[0001730168-20-000109:notes:29]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 3, 2019 |  | $ | 259 |  |  | $ | 1,808 |  |
| Balance as of May 3, 2020 (a) |  | $ | 197 |  |  | $ | 3,776 |  |

[0001730168-20-000109:notes:30]
(a) Contract liabilities associated with the Symantec Business were included in the balance as of May 3, 2020.

[0001730168-20-000109:notes:31]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |  |  |  |
| Balance as of November 5, 2018 (a) |  | $ | 18 |  |  | $ | 272 |  |
| Balance as of May 5, 2019 |  | $ | 210 |  |  | $ | 2,470 |  |

[0001730168-20-000109:notes:32]
(a) We adopted ASU 2014-09, Revenue from Contracts with Customers, on November 5, 2018, immediately prior to the acquisition of CA, Inc. (“CA”). Accordingly, the opening balance does not include contract assets or contract liabilities associated with CA.

[0001730168-20-000109:notes:33]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million. The amount of revenue recognized during the two fiscal quarters ended May 5, 2019

[0001730168-20-000109:notes:34]
that was included in the contract liabilities balance as of November 5, 2018 was $144 million.

[0001730168-20-000109:notes:35]
[same as prior period, unchanged from 0001730168-20-000045:notes:30]

[0001730168-20-000109:notes:36]
Revenue allocated to remaining performance obligations represents the transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied. It includes unearned revenue and amounts that will be invoiced and recognized as revenue in future periods and does not include contracts for subscriptions and services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less nor have we included contracts with sales-based and usage-based royalties promised in exchange for a license of intellectual property (“IP”).

[0001730168-20-000109:notes:37]
Because the substantial majority of our customer contracts allow our customers to terminate for convenience or have an original duration of one year or less, the total amount of the transaction price allocated to remaining performance obligations as of May 3, 2020 was not material. Since our customers generally do not exercise their termination for convenience rights and the majority of the contracts we execute for products, as well as subscriptions and services, have a duration of one year or less, our remaining performance obligations are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-20-000109:notes:38]
[same as prior period, unchanged from 0001730168-20-000045:notes:33]

[0001730168-20-000109:notes:39]
On November 4, 2019, we completed the purchase of the Symantec Business, which was an established leader in cybersecurity, for $10.7 billion in cash. We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications. We financed this acquisition with the net proceeds from borrowings under the November 2019 Term Loans, as defined in Note 8. “Borrowings”.

[0001730168-20-000109:notes:40]
We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on their estimated fair values, which were based on estimates and assumptions made by management at the time of acquisition. As additional information becomes available, we may further revise our preliminary purchase price allocation during the remainder of the measurement period (which will not exceed 12 months from November 4, 2019). Any such revisions or changes may be material.

[0001730168-20-000109:notes:41]
[same as prior period, unchanged from 0001730168-20-000045:notes:36]

[0001730168-20-000109:notes:42]
|  |  | Estimated Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 276 |  |
| Goodwill |  | 6,634 |  |
| Intangible assets |  | 5,411 |  |
| Other long-term assets |  | 93 |  |
| Total assets acquired |  | 12,414 |  |
| Current liabilities |  | (1,127) |  |
| Other long-term liabilities |  | (587) |  |
| Total liabilities assumed |  | (1,714) |  |
| Fair value of net assets acquired |  | $ | 10,700 |  |

[0001730168-20-000109:notes:43]
[same as prior period, unchanged from 0001730168-20-000045:notes:38]

[0001730168-20-000109:notes:44]
Current assets and current liabilities included amounts held-for-sale related to the acquired Symantec Cyber Security Services (“CSS”) business. The CSS business was not aligned with our acquisition-date strategic objectives and was sold on April 30, 2020. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-20-000109:notes:45]
Revenue attributable to the Symantec Business has been included in our infrastructure software segment. Transaction costs related to the Symantec Asset Purchase of $110 million were included in selling, general and administrative expense for the two fiscal quarters ended May 3, 2020.

[0001730168-20-000109:notes:46]
[same as prior period, unchanged from 0001730168-20-000045:notes:41]

[0001730168-20-000109:notes:47]
|  |  | Estimated Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,900 |  |  | 5 |
| Customer contracts and related relationships |  | 2,410 |  |  | 5 |
| Trade name |  | 90 |  |  | 6 |
| Order backlog |  | 11 |  |  | 3 |
| Total identified intangible assets |  | $ | 5,411 |  |  |  |

[0001730168-20-000109:notes:48]
Developed technology relates to products used for cybersecurity solutions, including data loss prevention, endpoint protection, and web, email and cloud security solutions. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-20-000109:notes:49]
[same as prior period, unchanged from 0001730168-20-000045:notes:44]

[0001730168-20-000109:notes:50]
[same as prior period, unchanged from 0001730168-20-000045:notes:46]

[0001730168-20-000109:notes:51]
[same as prior period, unchanged from 0001730168-20-000045:notes:45]

[0001730168-20-000109:notes:52]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of November 4, 2019.

[0001730168-20-000109:notes:53]
[same as prior period, unchanged from 0001730168-20-000045:notes:48]

[0001730168-20-000109:notes:54]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if we had completed the Symantec Asset Purchase as of the beginning of fiscal year 2019. The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. For the two fiscal quarters ended May 5, 2019, non-recurring pro forma adjustments directly attributable to the Symantec Asset Purchase included transaction costs of $136 million. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-20-000109:notes:55]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Pro forma net revenue |  | $ | 5,568 |  |  | $ | 5,927 |  |  | $ | 11,207 |  |  | $ | 12,260 |  |
| Pro forma net income attributable to common stock |  | $ | 403 |  |  | $ | 363 |  |  | $ | 632 |  |  | $ | 489 |  |

[0001730168-20-000109:notes:56]
[same as prior period, unchanged from 0001730168-20-000045:notes:51]

[0001730168-20-000109:notes:57]
During the fiscal quarter ended February 2, 2020, we also completed three other acquisitions qualifying as business combinations for total consideration of $201 million, of which $109 million was allocated to goodwill and $46 million was allocated to intangible assets. We do not consider these acquisitions to be material, individually or in the aggregate, to our condensed consolidated statements of operations.

[0001730168-20-000109:notes:58]
[same as prior period, unchanged from 0001730168-20-000045:notes:53]

[0001730168-20-000109:notes:59]
[same as prior period, unchanged from 0001730168-20-000045:notes:54]

[0001730168-20-000109:notes:60]
The following unaudited pro forma financial information presents combined results of operations for the periods presented, as if CA had been acquired as of the beginning of our fiscal year ended November 4, 2018 (“fiscal year 2018”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to stock-based compensation expense, interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2018 or of the results of our future operations of the combined business.

[0001730168-20-000109:notes:61]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 5,2019 |  | May 5,2019 |
|  |  | (In millions) |  |  |
| Pro forma net revenue |  | $ | 5,289 |  |  | $ | 10,850 |  |
| Pro forma net income attributable to common stock |  | $ | 558 |  |  | $ | 1,353 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-20-000109:notes:62]
[same as prior period, unchanged from 0001730168-20-000045:notes:57]

[0001730168-20-000109:notes:63]
Cash equivalents included $2,658 million and $850 million of time deposits and $1,686 million and $649 million of money-market funds as of May 3, 2020 and November 3, 2019, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-20-000109:notes:64]
[same as prior period, unchanged from 0001730168-20-000045:notes:59]

[0001730168-20-000109:notes:65]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $926 million and $1,827 million during the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, and $90 million during both the fiscal quarter and two fiscal quarters ended May 5, 2019. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any of the periods presented.

[0001730168-20-000109:notes:66]
[same as prior period, unchanged from 0001730168-20-000045:notes:61]

[0001730168-20-000109:notes:67]
|  |  | May 3,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Finished goods |  | $ | 306 |  |  | $ | 339 |  |
| Work-in-process |  | 471 |  |  | 414 |  |
| Raw materials |  | 176 |  |  | 121 |  |
| Total inventory |  | $ | 953 |  |  | $ | 874 |  |

[0001730168-20-000109:notes:68]
[same as prior period, unchanged from 0001730168-20-000045:notes:63]

[0001730168-20-000109:notes:69]
|  |  | May 3,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Prepaid expenses |  | $ | 389 |  |  | $ | 302 |  |
| Other (miscellaneous) |  | 462 |  |  | 427 |  |
| Total other current assets |  | $ | 851 |  |  | $ | 729 |  |

[0001730168-20-000109:notes:70]
[same as prior period, unchanged from 0001730168-20-000045:notes:65]

[0001730168-20-000109:notes:71]
|  |  | May 3,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Contract liabilities |  | $ | 3,065 |  |  | $ | 1,501 |  |
| Other (miscellaneous) |  | 993 |  |  | 1,115 |  |
| Total other current liabilities |  | $ | 4,058 |  |  | $ | 2,616 |  |

[0001730168-20-000109:notes:72]
[same as prior period, unchanged from 0001730168-20-000045:notes:67]

[0001730168-20-000109:notes:73]
|  |  | May 3,2020 |  | November 3,2019 |
|  |  | (In millions) |  |  |
| Unrecognized tax benefits |  | $ | 3,300 |  |  | $ | 3,269 |  |
| Contract liabilities |  | 711 |  |  | 307 |  |
| Other (miscellaneous) |  | 1,922 |  |  | 2,037 |  |
| Total other long-term liabilities |  | $ | 5,933 |  |  | $ | 5,613 |  |

[0001730168-20-000109:notes:74]
Other Income, net

[0001730168-20-000109:notes:75]
Other income, net for the fiscal quarter and two fiscal quarters ended May 3, 2020 included a $116 million one-time gain from the lapse of a tax indemnification arrangement.

[0001730168-20-000109:notes:76]
[same as prior period, unchanged from 0001730168-20-000045:notes:69]

[0001730168-20-000109:notes:77]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |  |  |
|  |  | (In millions) |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 375 |  |  | $ | 189 |  |  | $ | 756 |  |  | $ | 612 |  |  |  |
| Cash paid for income taxes |  | $ | 124 |  |  | $ | 425 |  |  | $ | 255 |  |  | $ | 520 |  |  |  |

[0001730168-20-000109:notes:78]
As of May 3, 2020 and May 5, 2019, we had $53 million and $35 million, respectively, of unpaid purchases of property, plant and equipment included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001730168-20-000109:notes:79]
Leases 
Effective November 4, 2019, we adopted Topic 842 using the optional adoption method and elected practical expedients which allowed us to account for the lease and non-lease components as a single component. In addition, we elected not to reassess whether any expired or existing contracts contain leases and the corresponding lease classification and initial direct costs. The practical expedients were applied across our lease portfolios.

[0001730168-20-000109:notes:80]
We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize ROU assets and lease liabilities for operating and finance leases with terms greater than 12 months. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on

[0001730168-20-000109:notes:81]
our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective-interest method over the lease term.

[0001730168-20-000109:notes:82]
We entered into operating and finance leases for our facilities, data centers and certain equipment. For the fiscal quarter and two fiscal quarters ended May 3, 2020, we recorded $26 million and $51 million of operating lease expense, respectively, and $3 million and $5 million of finance lease expense, respectively. For the fiscal quarter and two fiscal quarters ended May 5, 2019, rent expense was $59 million and $126 million, respectively.

[0001730168-20-000109:notes:83]
Other information related to leases was as follows:

[0001730168-20-000109:notes:84]
|  |  | Two Fiscal Quarters Ended |  |
|  |  | May 3,2020 |  |
|  |  | (In millions) |  |
| Cash paid for operating leases included in operating cash flows |  | $ | 63 |  |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 659 |  |  |
| ROU assets obtained in exchange for finance lease liabilities |  | $ | 58 |  |  |
|  |  | May 3,2020 |  |
| Weighted-average remaining lease term – operating leases (In years) |  | 11 |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 5 |  |
| Weighted-average discount rate – operating leases |  | 3.71 |  | % |  |
| Weighted-average discount rate – finance leases |  | 3.33 |  | % |  |

[0001730168-20-000109:notes:85]
Supplemental balance sheet information related to leases was as follows:

[0001730168-20-000109:notes:86]
|  |  | Classification on the Condensed Consolidated Balance Sheet |  | May 3,2020 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  |  | $ | 613 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  |  | $ | 53 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  |  | $ | 95 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 553 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  |  | $ | 12 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 43 |  |

[0001730168-20-000109:notes:87]
The maturities of lease liabilities were as follows:

[0001730168-20-000109:notes:88]
|  |  | May 3,2020 |  |  |
|  |  | Operating Leases |  | Finance Leases |
|  |  | (In millions) |  |  |
| 2020 (remainder) |  | $ | 59 |  |  | $ | 8 |  |
| 2021 |  | 114 |  |  | 13 |  |
| 2022 |  | 91 |  |  | 13 |  |
| 2023 |  | 80 |  |  | 13 |  |
| 2024 |  | 61 |  |  | 13 |  |
| Thereafter |  | 403 |  |  | — |  |
| Total undiscounted liabilities |  | 808 |  |  | 60 |  |
| Less: interest |  | 160 |  |  | 5 |  |
| Present value of lease liabilities |  | $ | 648 |  |  | $ | 55 |  |

[0001730168-20-000109:notes:89]
As of November 3, 2019, future minimum lease payments under non-cancelable lease liabilities prior to our adoption of Topic 842 were as follows:

[0001730168-20-000109:notes:90]
|  |  | November 3,2019 |
|  |  | (In millions) |
| 2020 |  | $ | 115 |  |
| 2021 |  | 99 |  |
| 2022 |  | 80 |  |
| 2023 |  | 69 |  |
| 2024 |  | 47 |  |
| Thereafter |  | 390 |  |
| Total minimum lease payments |  | $ | 800 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-20-000109:notes:91]
[same as prior period, unchanged from 0001730168-20-000045:notes:83]

[0001730168-20-000109:notes:92]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | IP Licensing |  | Total |
|  |  |  |  |  |  |  |  |  |  | (In millions) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  |  |  |  |  |  |  |  |  |  | $ | 25,929 |  |  | $ | 10,776 |  |  | $ | 9 |  |  | $ | 36,714 |  |
| Reallocation due to change in segments |  |  |  |  |  |  |  |  |  |  | 9 |  |  | — |  |  | (9) |  |  | — |  |
| Acquisitions |  |  |  |  |  |  |  |  |  |  | 35 |  |  | 6,708 |  |  | — |  |  | 6,743 |  |
| Balance as of May 3, 2020 |  |  |  |  |  |  |  |  |  |  | $ | 25,973 |  |  | $ | 17,484 |  |  | $ | — |  |  | $ | 43,457 |  |

[0001730168-20-000109:notes:93]
[same as prior period, unchanged from 0001730168-20-000045:notes:85]

[0001730168-20-000109:notes:94]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |  |  |  |  |
| As of May 3, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,073 |  |  | $ | (12,013) |  |  | $ | 12,060 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (2,484) |  |  | 5,905 |  |
| Order backlog |  | 2,579 |  |  | (1,372) |  |  | 1,207 |  |
| Trade names |  | 797 |  |  | (282) |  |  | 515 |  |
| Other |  | 252 |  |  | (100) |  |  | 152 |  |
| Intangible assets subject to amortization |  | 36,090 |  |  | (16,251) |  |  | 19,839 |  |
| In-process research and development |  | 70 |  |  | — |  |  | 70 |  |
| Total |  | $ | 36,160 |  |  | $ | (16,251) |  |  | $ | 19,909 |  |

[0001730168-20-000109:notes:95]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |  |  |  |  |
| As of November 3, 2019: |  |  |  |  |  |  |
| Purchased technology |  | $ | 20,935 |  |  | $ | (10,113) |  |  | $ | 10,822 |  |
| Customer contracts and related relationships |  | 5,978 |  |  | (1,787) |  |  | 4,191 |  |
| Order backlog |  | 2,569 |  |  | (908) |  |  | 1,661 |  |
| Trade names |  | 712 |  |  | (247) |  |  | 465 |  |
| Other |  | 241 |  |  | (89) |  |  | 152 |  |
| Intangible assets subject to amortization |  | 30,435 |  |  | (13,144) |  |  | 17,291 |  |
| In-process research and development |  | 263 |  |  | — |  |  | 263 |  |
| Total |  | $ | 30,698 |  |  | $ | (13,144) |  |  | $ | 17,554 |  |

[0001730168-20-000109:notes:96]
Based on the amount of intangible assets subject to amortization at May 3, 2020, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-20-000109:notes:97]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 3,117 |  |
| 2021 |  | 5,402 |  |
| 2022 |  | 4,360 |  |
| 2023 |  | 3,231 |  |
| 2024 |  | 2,362 |  |
| Thereafter |  | 1,367 |  |
| Total |  | $ | 19,839 |  |

[0001730168-20-000109:notes:98]
[same as prior period, unchanged from 0001730168-20-000045:notes:89]

[0001730168-20-000109:notes:99]
| Amortizable intangible assets: |  | May 3,2020 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 5 |
| Order backlog |  | 2 |
| Trade names |  | 9 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-20-000109:notes:100]
[same as prior period, unchanged from 0001730168-20-000045:notes:91]

[0001730168-20-000109:notes:101]
Diluted shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”), in-the-money stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), (collectively referred to as “equity awards”), as well as Mandatory Convertible Preferred Stock, as defined in Note 9. “Stockholders’ Equity.” Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-20-000109:notes:102]
[same as prior period, unchanged from 0001730168-20-000045:notes:93]

[0001730168-20-000109:notes:103]
For both the fiscal quarter and two fiscal quarters ended May 3, 2020, diluted net income per share excluded the potentially dilutive effect of 13 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-20-000109:notes:104]
[same as prior period, unchanged from 0001730168-20-000045:notes:95]

[0001730168-20-000109:notes:105]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 568 |  |  | $ | 693 |  |  | $ | 948 |  |  | $ | 1,174 |  |
| Less: Dividends on preferred stock |  | 75 |  |  | — |  |  | 149 |  |  | — |  |
| Income from continuing operations attributable to common stock |  | 493 |  |  | 693 |  |  | 799 |  |  | 1,174 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | (5) |  |  | (2) |  |  | — |  |  | (12) |  |
| Net income attributable to common stock |  | $ | 488 |  |  | $ | 691 |  |  | $ | 799 |  |  | $ | 1,162 |  |

[0001730168-20-000109:notes:106]
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 401 |  |  | 397 |  |  | 400 |  |  | 399 |  |
| Dilutive effect of equity awards |  | 16 |  |  | 25 |  |  | 19 |  |  | 21 |  |
| Weighted-average shares outstanding - diluted |  | 417 |  |  | 422 |  |  | 419 |  |  | 420 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.23 |  |  | $ | 1.75 |  |  | $ | 2.00 |  |  | $ | 2.94 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | (0.01) |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 1.22 |  |  | $ | 1.74 |  |  | $ | 2.00 |  |  | $ | 2.91 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.18 |  |  | $ | 1.64 |  |  | $ | 1.91 |  |  | $ | 2.80 |  |
| Loss per share from discontinued operations |  | (0.01) |  |  | — |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 1.17 |  |  | $ | 1.64 |  |  | $ | 1.91 |  |  | $ | 2.77 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-20-000109:notes:107]
Borrowings

[0001730168-20-000109:notes:108]
|  |  | May 3,2020 |  |  |  | November 3,2019 |  |  |
|  |  | Effective Interest Rate |  | Aggregate Principal Amount |  | Effective Interest Rate |  | Aggregate Principal Amount |
|  |  | (In millions) |  |  |  |  |  |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | $ | 2,250 |  |  |  |  | $ | — |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  |  |  | — |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due through November 2022 |  | 2.38 | % |  | 7,556 |  |  |  |  | — |  |
| LIBOR plus 1.250% term loan due through November 2024 |  | 2.40 | % |  | 7,556 |  |  |  |  | — |  |
| May 2019 Term Loans - floating rate |  |  |  |  |  |  |  |  |
| LIBOR plus 1.250% term loan due May 2024 |  | 2.35 | % |  | 300 |  |  | 3.36 | % |  | 800 |  |
| LIBOR plus 1.375% term loan due May 2026 |  | 2.44 | % |  | 300 |  |  | 3.45 | % |  | 800 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | 726 |  |  | 3.61 | % |  | 2,000 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | 1,500 |  |  | 3.53 | % |  | 1,500 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 2,000 |  |  | 3.98 | % |  | 2,000 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 2,500 |  |  | 4.54 | % |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 4.95 | % |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |  |  |
| 2.375% notes due January 2020 |  |  |  | — |  |  | 2.62 | % |  | 2,750 |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | 399 |  |  | 2.41 | % |  | 750 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 1,139 |  |  | 3.21 | % |  | 3,500 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 1,000 |  |  | 2.78 | % |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 2,500 |  |  | 3.74 | % |  | 2,500 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 1,000 |  |  | 3.23 | % |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 4,800 |  |  | 4.02 | % |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 3.60 | % |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |  |  |  |
| 5.375% notes due December 2019 |  |  |  | — |  |  | 3.43 | % |  | 750 |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | 500 |  |  | 4.07 | % |  | 500 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 250 |  |  | 4.10 | % |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 5.15 | % |  | 350 |  |
| Other borrowings |  |  |  |  |  |  |  |  |  |
| Revolving facility under the 2019 Credit Agreement |  | 1.97 | % |  |  | 3,000 |  |  |  |  | — |  |
| Commercial paper |  | 2.90 | % | (a) | 28 |  |  | 2.55 | % | (a) | 1,000 |  |
| 1.375% convertible notes due January 2020 |  |  |  | — |  |  | 0.63 | % |  | 37 |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59%- 4.55% |  |  | 22 |  |  | 2.59%- 4.55% |  |  | 22 |  |
| Total principal amount outstanding |  |  |  |  | 46,176 |  |  |  |  | 33,059 |  |
| Less: Unamortized premium/discount and issuance costs |  |  |  |  | (368) |  |  |  |  | (261) |  |
| Total debt |  |  |  |  | $ | 45,808 |  |  |  |  | $ | 32,798 |  |

[0001730168-20-000109:notes:109]
(a) Represents the weighted average interest rate on outstanding commercial paper.

[0001730168-20-000109:notes:110]
As of May 3, 2020, $12 million and $43 million of short-term and long-term finance lease liabilities were included in the current portion of long-term debt and long-term debt, respectively, on the condensed consolidated balance sheet.

[0001730168-20-000109:notes:111]
April 2020 Senior Notes

[0001730168-20-000109:notes:112]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). The April 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”). Each series of our April 2020 Senior Notes pays interest semi-annually in arrears on April 15 and October 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable April 2020 Senior Notes, plus a corresponding make-whole premium as set forth in the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. As of May 3, 2020, the April 2020 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-20-000109:notes:113]
Pursuant to a cash tender offer that we completed on April 23, 2020, we repurchased $2,361 million of our 3.000% notes due January 2022, $1,274 million of our 3.125% notes due April 2021 and $351 million of our 2.200% notes due January 2021 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense in the condensed consolidated statements of operations.

[0001730168-20-000109:notes:114]
November 2019 Term Loans

[0001730168-20-000109:notes:115]
On November 4, 2019, in connection with the Symantec Asset Purchase, we entered into a credit agreement (the “2020 Credit Agreement”), which provides for a $7,750 million unsecured term A-3 facility and a $7,750 million unsecured term A-5 facility (collectively, the “November 2019 Term Loans”). Interest on our November 2019 Term Loans is based on a floating rate and is payable monthly. We used $10.7 billion of the net proceeds from the November 2019 Term Loans to fund the Symantec Asset Purchase. During the fiscal quarter ended February 2, 2020, we also used the net proceeds to repay $750 million principal amount of 5.375% notes due December 1, 2019 and $2,750 million principal amount of 2.375% notes due January 15, 2020, on their respective maturity dates. Our obligations under the 2020 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI. Beginning the second quarter of fiscal year 2020, we are required to repay 2.5% of the original principal borrowed under our November 2019 Term Loans every quarter until their respective maturity dates, unless and to the extent any amounts prepaid under the November 2019 Term Loans are applied to these required amortization payments.

[0001730168-20-000109:notes:116]
May 2019 Term Loans

[0001730168-20-000109:notes:117]
In January 2020, we repaid an aggregate of $1,000 million of term loans consisting of $500 million of each of our unsecured term A-5 and A-7 facilities under the credit agreement entered into in May 2019 (the “2019 Credit Agreement”), using net proceeds from issuances of Commercial Paper, as defined below. Our obligations under the 2019 Credit Agreement are guaranteed on an unsecured basis by BRCM and BTI.

[0001730168-20-000109:notes:118]
In addition to these unsecured term facilities, the 2019 Credit Agreement provides for a five-year $5 billion unsecured revolving facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the 2019 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time, prior to the earlier of (a) May 2024 or (b) the date of termination, in whole of the revolving lenders’ commitments under the 2019 Credit Agreement in accordance with the terms thereof. As of May 3, 2020, we had $3 billion of borrowings outstanding under the Revolving Facility with a term of less than one month. We had no borrowings outstanding as of November 3, 2019 under the Revolving Facility. Per the terms of the 2019 Credit Agreement, we have the ability and intent to continuously refinance our borrowings under the Revolving Facility and have therefore recorded such borrowings as long-term debt.

[0001730168-20-000109:notes:119]
Commercial Paper

[0001730168-20-000109:notes:120]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. As of May 3, 2020 and November 3, 2019, we had $28 million and $1 billion, respectively, of Commercial Paper outstanding with maturities generally less than three months. As our commercial paper program is

[0001730168-20-000109:notes:121]
supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As a result, we have recorded Commercial Paper, net of discount, as long-term debt. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility.

[0001730168-20-000109:notes:122]
May 2020 Senior Notes

[0001730168-20-000109:notes:123]
Subsequent to the fiscal quarter ended May 3, 2020, we issued $8,000 million of senior unsecured notes on May 8, 2020. These notes are comprised of $1,000 million of senior notes due 2023, $2,250 million of senior notes due 2025, $2,750 million of senior notes due 2030 and $2,000 million of senior notes due 2032 (collectively, the “May 2020 Senior Notes”). The May 2020 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by BRCM and BTI. Each series of our May 2020 Senior Notes pays interest semi-annually in arrears on May 15 and November 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities at a price equal to 100% of the principal amount, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Senior Notes, plus accrued and unpaid interest. The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, were used to repay an aggregate of $5,424 million of term loans outstanding under the 2020 Credit Agreement, consisting of repayments of $2,712 million of each of our unsecured term A-3 facility and unsecured term A-5 facility, and $3,000 million of borrowings outstanding under the Revolving Facility. The remaining term loans outstanding under the 2020 Credit Agreement are due more than one year after May 3, 2020 and were included in long-term debt.

[0001730168-20-000109:notes:124]
May 2020 Exchange Notes

[0001730168-20-000109:notes:125]
On June 4, 2020, subsequent to the fiscal quarter ended May 3, 2020, we completed the settlement of our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024 (the “Exchange Offers”), for $1,695 million of new senior notes due 2026 and $2,222 million of new senior notes due 2028 (collectively, the “May 2020 Exchange Notes”). As a result of the settlement, we recorded $201 million and $117 million of our 3.125% notes due April 2021 and 2.200% notes due January 2021, respectively, as long-term debt as of May 3, 2020. The May 2020 Exchange Notes pay interest semi-annually in arrears on March 15 and September 15 of each year. We may, at our option, redeem or purchase, in whole or in part, any of the May 2020 Exchange Notes prior to their respective maturities, at a price equal to 100% of the principal amount of the applicable May 2020 Exchange Notes, plus a corresponding make-whole premium as set forth in the indenture governing the May 2020 Exchange Notes, plus accrued and unpaid interest.

[0001730168-20-000109:notes:126]
Fair Value of Debt

[0001730168-20-000109:notes:127]
As of May 3, 2020, the estimated aggregate fair value of debt was $47,732 million. The fair value of our senior notes was determined using quoted prices from less active markets. The estimated fair value of our November 2019 Term Loans and May 2019 Term Loans approximated carrying value due to their floating interest rates and consistency in our credit ratings. The estimated fair value of our revolver borrowings and Commercial Paper approximated their carrying value due to the short-term maturity of these borrowings. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-20-000109:notes:128]
Future Principal Payments of Debt

[0001730168-20-000109:notes:129]
The future scheduled principal payments of debt as of May 3, 2020 were as follows:

[0001730168-20-000109:notes:130]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2020 (remainder) |  | $ | 3,803 |  |
| 2021 |  | 2,674 |  |
| 2022 |  | 4,698 |  |
| 2023 |  | 7,644 |  |
| 2024 |  | 5,582 |  |
| Thereafter |  | 21,775 |  |
| Total |  | $ | 46,176 |  |

[0001730168-20-000109:notes:131]
As of May 3, 2020 and November 3, 2019, we accrued interest payable of $190 million and $214 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-20-000109:notes:132]
[same as prior period, unchanged from 0001730168-20-000045:notes:115]

[0001730168-20-000109:notes:133]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”), which generated net proceeds of approximately $3,679 million.

[0001730168-20-000109:notes:134]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of May 3, 2020, the minimum conversion rate was 3.0456 and the maximum conversion rate was 3.5600.

[0001730168-20-000109:notes:135]
We recognized $28 million and $29 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets as of May 3, 2020 and November 3, 2019, respectively.

[0001730168-20-000109:notes:136]
[same as prior period, unchanged from 0001730168-20-000045:notes:119]

[0001730168-20-000109:notes:137]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Dividends per share to common stockholders |  | $ | 3.25 |  |  | $ | 2.65 |  |  | $ | 6.50 |  |  | $ | 5.30 |  |
| Dividends to common stockholders |  | $ | 1,306 |  |  | $ | 1,057 |  |  | $ | 2,603 |  |  | $ | 2,124 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | — |  |  | $ | 40.00 |  |  | $ | — |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | — |  |  | $ | 150 |  |  | $ | — |  |

[0001730168-20-000109:notes:138]
[same as prior period, unchanged from 0001730168-20-000045:notes:121]

[0001730168-20-000109:notes:139]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Cost of products sold |  | $ | 27 |  |  | $ | 29 |  |  | $ | 58 |  |  | $ | 55 |  |
| Cost of subscriptions and services |  | 14 |  |  | 12 |  |  | 26 |  |  | 20 |  |
| Research and development |  | 373 |  |  | 371 |  |  | 764 |  |  | 682 |  |
| Selling, general and administrative |  | 103 |  |  | 132 |  |  | 214 |  |  | 252 |  |
| Total stock-based compensation expense |  | $ | 517 |  |  | $ | 544 |  |  | $ | 1,062 |  |  | $ | 1,009 |  |

[0001730168-20-000109:notes:140]
As of May 3, 2020, the total unrecognized compensation cost related to unvested stock-based awards was $5,049 million, which is expected to be recognized over the remaining weighted-average service period of 3.8 years.

[0001730168-20-000109:notes:141]
[same as prior period, unchanged from 0001730168-20-000045:notes:124]

[0001730168-20-000109:notes:142]
[same as prior period, unchanged from 0001730168-20-000045:notes:125]

[0001730168-20-000109:notes:143]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |  |  |  |  |
| Granted |  | 2 |  |  | $ | 249.79 |  |  |  |  |  |
| Vested |  | (4) |  |  | $ | 200.57 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 191.85 |  |  |  |  |  |
| Balance as of May 3, 2020 |  | 37 |  |  | $ | 191.38 |  |  |  |  |  |

[0001730168-20-000109:notes:144]
The aggregate fair value of time- and market-based RSUs that vested during the two fiscal quarters ended May 3, 2020 was $1,093 million, which represents the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-20-000109:notes:145]
[same as prior period, unchanged from 0001730168-20-000045:notes:128]

[0001730168-20-000109:notes:146]
|  |  | Number of OptionsOutstanding |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualLife (In years) |  | AggregateIntrinsicValue |
|  |  | (In millions, except years and per share data) |  |  |  |  |  |  |
| Balance as of November 3, 2019 |  | 4 |  |  | $ | 51.83 |  |  |  |  |  |
| Exercised |  | (1) |  |  |  | $ | 46.39 |  |  |  |  | $ | 400 |  |
| Balance as of May 3, 2020 |  | 3 |  |  | $ | 55.07 |  |  | 0.7 |  | $ | 567 |  |
| Fully vested as of May 3, 2020 |  | 3 |  |  | $ | 55.07 |  |  | 0.7 |  | $ | 566 |  |
| Fully vested and expected to vest as of May 3, 2020 |  | 3 |  |  | $ | 55.07 |  |  | 0.7 |  | $ | 567 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-20-000109:notes:147]
10. Income Taxes

[0001730168-20-000109:notes:148]
The benefit from income taxes was $159 million and $235 million for the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, compared to $36 million and $239 million for the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively.

[0001730168-20-000109:notes:149]
The benefit from income taxes for the fiscal quarter and two fiscal quarters ended May 3, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards that vested or were exercised during the periods.

[0001730168-20-000109:notes:150]
[same as prior period, unchanged from 0001730168-20-000045:notes:134]

[0001730168-20-000109:notes:151]
The benefit from income taxes for the fiscal quarter ended May 5, 2019 was primarily due to excess tax benefits from stock-based awards that vested or were exercised during the period, partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the U.S. Tax Cuts and Jobs Act (the “2017 Tax Reform Act”).

[0001730168-20-000109:notes:152]
The benefit from income taxes for the two fiscal quarters ended May 5, 2019 was primarily due to excess tax benefits from stock-based awards that vested or were exercised during the period, the recognition of gross uncertain tax benefits as a result of audit settlements and lapses of statutes of limitations, and the partial release of our valuation allowance as a result of the CA Merger, partially offset by a change in estimate of our fiscal year 2018 provision resulting from regulations issued related to the 2017 Tax Reform Act.

[0001730168-20-000109:notes:153]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was enacted and signed into law. The CARES Act includes a number of income tax changes, including, but not limited to, (i) permitting net operating loss carrybacks to offset 100% of taxable income for taxable years beginning before 2021, (ii) accelerating alternative minimum tax refunds and (iii) temporarily increasing the allowable business interest deduction from 30% to 50% of adjusted taxable income. These changes did not have a material impact on the condensed consolidated financial statements presented herein.

[0001730168-20-000109:notes:154]
[same as prior period, unchanged from 0001730168-20-000045:notes:135]

[0001730168-20-000109:notes:155]
The balance of gross unrecognized tax benefits was $4,578 million and $4,422 million as of May 3, 2020 and November 3, 2019, respectively. This increase was primarily due to changes in uncertain tax positions from adjustments arising from audits conducted by tax authorities.

[0001730168-20-000109:notes:156]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of May 3, 2020 and November 3, 2019, the combined amount of cumulative accrued interest and penalties was approximately $313 million and $303 million, respectively.

[0001730168-20-000109:notes:157]
As of May 3, 2020 and November 3, 2019, approximately $4,891 million and $4,725 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-20-000109:notes:158]
We are subject to U.S. income tax examination for fiscal years 2013 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $154 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-20-000109:notes:159]
[same as prior period, unchanged from 0001730168-20-000045:notes:140]

[0001730168-20-000109:notes:160]
[same as prior period, unchanged from 0001730168-20-000045:notes:141]

[0001730168-20-000109:notes:161]
[same as prior period, unchanged from 0001730168-20-000045:notes:142]

[0001730168-20-000109:notes:162]
[same as prior period, unchanged from 0001730168-20-000045:notes:143]

[0001730168-20-000109:notes:163]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as global operations, including manufacturing support, logistics and quality control, in addition to expenses associated with selling, general and administrative activities for the business, which are allocated primarily based on revenue, while facilities and information technology (“IT”) expenses are allocated primarily based on site-specific headcount.

[0001730168-20-000109:notes:164]
[same as prior period, unchanged from 0001730168-20-000045:notes:145]

[0001730168-20-000109:notes:165]
[same as prior period, unchanged from 0001730168-20-000045:notes:146]

[0001730168-20-000109:notes:166]
Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for the fiscal quarter and two fiscal quarters ended May 3, 2020 and May 5, 2019. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-20-000109:notes:167]
|  |  | Fiscal Quarter Ended |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
|  |  | (In millions) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 4,027 |  |  | $ | 4,104 |  |  | $ | 8,218 |  |  | $ | 8,490 |  |
| Infrastructure software |  | 1,715 |  |  | 1,413 |  |  | 3,382 |  |  | 2,816 |  |
| Total net revenue |  | $ | 5,742 |  |  | $ | 5,517 |  |  | $ | 11,600 |  |  | $ | 11,306 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 1,840 |  |  | $ | 1,899 |  |  | $ | 3,819 |  |  | $ | 3,931 |  |
| Infrastructure software |  | 1,191 |  |  | 1,050 |  |  | 2,296 |  |  | 2,070 |  |
| Unallocated expenses |  | (2,265) |  |  | (1,979) |  |  | (4,635) |  |  | (4,476) |  |
| Total operating income |  | $ | 766 |  |  | $ | 970 |  |  | $ | 1,480 |  |  | $ | 1,525 |  |

[0001730168-20-000109:notes:168]
[same as prior period, unchanged from 0001730168-20-000045:notes:149]

[0001730168-20-000109:notes:169]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. One customer accounted for 14% and 24% of our net accounts receivable balance as of May 3, 2020 and November 3, 2019, respectively.
One customer accounted for 14% of our net revenue during each of the fiscal quarter and two fiscal quarters ended May 3, 2020. This customer also accounted for 14% of our net revenue during each of the fiscal quarter and two fiscal quarters ended May 5, 2019. Net revenue from this customer was included in our semiconductor solutions segment. A second customer accounted for 11% and 10% of net revenue during the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively. Net revenue from this customer was primarily included in our infrastructure software segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-20-000109:notes:170]
Commitments and Contingencies
Commitments

[0001730168-20-000109:notes:171]
The following table summarizes contractual obligations and commitments as of May 3, 2020 that materially changed from the end of fiscal year 2019:

[0001730168-20-000109:notes:172]
|  |  |  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |  |
|  |  | Total |  | 2020(remainder) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
|  |  | (In millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt principal, interest and fees |  | $ | 53,832 |  |  | $ | 4,520 |  |  | $ | 4,058 |  |  | $ | 6,015 |  |  | $ | 8,729 |  |  | $ | 6,563 |  |  | $ | 23,947 |  |
| Purchase commitments |  | 852 |  |  | 754 |  |  | 65 |  |  | 33 |  |  | — |  |  | — |  |  | — |  |
| Other contractual commitments |  | 943 |  |  | 97 |  |  | 161 |  |  | 148 |  |  | 141 |  |  | 97 |  |  | 299 |  |
| Total |  | $ | 55,627 |  |  | $ | 5,371 |  |  | $ | 4,284 |  |  | $ | 6,196 |  |  | $ | 8,870 |  |  | $ | 6,660 |  |  | $ | 24,246 |  |

[0001730168-20-000109:notes:173]
Debt Principal, Interest and Fees. Represents principal, estimated interest and fees on our borrowings. For borrowings subject to a floating interest rate, the estimated interest was based on the rate in effect during the last month of the fiscal quarter ended May 3, 2020.

[0001730168-20-000109:notes:174]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

[0001730168-20-000109:notes:175]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-20-000109:notes:176]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 3, 2020, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,300 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 3, 2020 have been excluded from the contractual obligations table above.

[0001730168-20-000109:notes:177]
Standby Letters of Credit

[0001730168-20-000109:notes:178]
As of May 3, 2020 and November 3, 2019, we had standby letters of credit of $57 million and $62 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-20-000109:notes:179]
Contingencies

[0001730168-20-000109:notes:180]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights. Legal proceedings are often complex, may require the expenditure of significant funds and other resources, and the outcome of litigation is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-20-000109:notes:181]
Lawsuits Relating to California Institute of Technology

[0001730168-20-000109:notes:182]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. The jury did not, however, find willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. The parties have filed post-trial motions with the Central District Court, and Broadcom and Apple will appeal to the United States Court of Appeals for the Federal Circuit.

[0001730168-20-000109:notes:183]
We believe that the evidence and the law do not support the jury’s findings of infringement and the award of damages and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including post-trial motions at the U.S. Central District Court and appeals by both Broadcom and Caltech) could significantly change the assessment of damages.

[0001730168-20-000109:notes:184]
Lawsuits Relating to the Acquisition of Emulex Corporation

[0001730168-20-000109:notes:185]
On April 8, 2015, a putative class action complaint was filed in the U.S. Central District Court, entitled Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 8:15-cv-554-CJC-JCG. The complaint names as defendants Emulex Corporation (“Emulex”), its directors, Avago Technologies Wireless (U.S.A.) Manufacturing (“AT Wireless”) and Emerald Merger Sub, and purported to assert claims under Sections 14(d), 14(e) and 20(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”). The complaint alleged, among other things, that the board of directors of Emulex failed to provide material information and/or omitted material information from the Solicitation/Recommendation Statement on Schedule 14D-9 filed with the SEC on April 7, 2015 by Emulex, together with the exhibits and annexes thereto. The complaint sought to enjoin the tender offer to purchase all of the outstanding shares of Emulex common stock, as well as certain other equitable relief and attorneys’ fees and costs. On July 28, 2015, the U.S. Central District Court issued an order appointing the lead plaintiff and approving lead counsel for the putative class. On September 9, 2015, plaintiff filed a first amended complaint seeking rescission of the merger, unspecified money damages, other equitable relief and attorneys’ fees and costs. On October 13, 2015, defendants moved to dismiss the first amended complaint, which the U.S. Central District Court granted with prejudice

[0001730168-20-000109:notes:186]
on January 13, 2016. Plaintiff filed a notice of appeal to the United States Court of Appeals for the Ninth Circuit (the “Ninth Circuit Court”) on January 15, 2016. The appeal is captioned Gary Varjabedian, et al. v. Emulex Corporation, et al., No. 16-55088. On June 27, 2016, the Plaintiff-Appellant filed his opening brief, on August 17 and August 22, 2016, the Defendants-Appellees filed their answering briefs, and on October 5, 2016 Plaintiff-Appellant filed his reply brief. The Ninth Circuit Court heard oral arguments on October 5, 2017. On April 20, 2018, the Ninth Circuit Court issued an opinion affirming in part and reversing in part the decision of the U.S. Central District Court and remanding Plaintiff-Appellant’s claims under Sections 14(e) and 20(a) of the Exchange Act to the U.S. Central District Court for reconsideration. On May 4, 2018, the Defendants-Appellees filed a Petition for Rehearing En Banc with the Ninth Circuit Court. On July 13, 2018, Plaintiff-Appellant filed an Opposition to the Petition for Rehearing En Banc. On September 6, 2018, the Ninth Circuit Court issued an order denying the Petition for Rehearing En Banc. On October 11, 2018, Defendants-Appellees filed a Petition for a Writ of Certiorari to the United States Supreme Court (the “U.S. Supreme Court”), which was granted on January 4, 2019. On April 23, 2019, the U.S. Supreme Court dismissed the writ of certiorari as having been improvidently granted. On May 28, 2019, the Ninth Circuit Court remanded the case back to the U.S. Central District Court. On October 6, 2019, Plaintiff voluntarily dismissed AT Wireless from this action and the remaining defendants, Emulex and its directors, filed motions to dismiss the complaint on October 7, 2019. On February 26, 2020, the U.S. Central District Court dismissed Plaintiff’s complaint with prejudice.

[0001730168-20-000109:notes:187]
Other Matters

[0001730168-20-000109:notes:188]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-20-000109:notes:189]
Contingency Assessment

[0001730168-20-000109:notes:190]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-20-000109:notes:191]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-20-000109:notes:192]
Other Indemnifications

[0001730168-20-000109:notes:193]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-20-000109:notes:194]
Restructuring Charges
The following is a summary of significant restructuring expense recognized primarily in operating expenses:

[0001730168-20-000109:notes:195]
•During the first quarter of fiscal year 2020, we initiated cost reduction activities associated with the Symantec Asset Purchase. As a result, we recognized $57 million and $90 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020.

[0001730168-20-000109:notes:196]
•During the first quarter of fiscal year 2019, we initiated cost reduction activities associated with the CA Merger. As a result, we recognized $19 million of restructuring expense during two fiscal quarters ended May 3, 2020, and $81 million and $675 million during the fiscal quarter and two fiscal quarters ended May 5, 2019, respectively, primarily related to employee termination and lease and other exit costs. We expect these restructuring activities to be substantially completed by the end of fiscal year 2020.

[0001730168-20-000109:notes:197]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the two fiscal quarters ended May 3, 2020.

[0001730168-20-000109:notes:198]
|  |  | Employee Termination Costs |  | Leases and Other Exit Costs |  | Total |
|  |  | (In millions) |  |  |  |  |
| Balance as of November 3, 2019 |  |  | $ | 69 |  |  | $ | 39 |  |  | $ | 108 |  |
| Restructuring charges (a) |  | 110 |  |  | 21 |  |  | 131 |  |
| Utilization |  |  | (91) |  |  | (24) |  |  | (115) |  |
| Effect of adoption of Topic 842 (b) |  | — |  |  | (36) |  |  | (36) |  |
| Balance as of May 3, 2020 (c) |  | $ | 88 |  |  | $ | — |  |  | $ | 88 |  |

[0001730168-20-000109:notes:199]
_________________________________

[0001730168-20-000109:notes:200]
(a) Included $12 million and $17 million of restructuring expense related to discontinued operations recognized during the fiscal quarter and two fiscal quarters ended May 3, 2020, respectively, which was included in income from discontinued operations.

[0001730168-20-000109:notes:201]
(b) Upon adoption of Topic 842, certain restructuring lease liabilities were required to be recognized as a reduction to the corresponding ROU assets.

[0001730168-20-000109:notes:202]
(c) The majority of the employee termination costs balance is expected to be paid by the end of fiscal year 2020.


## us-gaap:SubsequentEventsTextBlock

[0001730168-20-000109:notes:203]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-20-000109:notes:204]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2020 to stockholders of record on June 15, 2020.

[0001730168-20-000109:notes:205]
Common Stock Cash Dividends Declared

[0001730168-20-000109:notes:206]
On June 3, 2020, our Board of Directors declared a quarterly cash dividend of $3.25 per share on our common stock, payable on June 30, 2020 to stockholders of record on June 22, 2020.
