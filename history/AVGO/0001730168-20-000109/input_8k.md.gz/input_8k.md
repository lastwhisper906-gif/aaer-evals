# AVGO 8-K — 0001730168-20-000099 filed 2020-06-04

## item codes, every 8-K on or before 2020-06-12

- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2020-06-12

- none on or before 2020-06-12

## item 2.02 — earnings release, exhibit 99.1

[0001730168-20-000099:8k_2_02:1]
EX-99.1
2
avgo-05032020x8kxex99.htm
EX-99.1

[0001730168-20-000099:8k_2_02:2]
Document

[0001730168-20-000099:8k_2_02:3]
Exhibit 99.1

[0001730168-20-000099:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2020 Financial Results and Quarterly Dividends

[0001730168-20-000099:8k_2_02:5]
•Revenue of $5,742 million; GAAP net income of $563 million; Adjusted EBITDA of $3,209 million

[0001730168-20-000099:8k_2_02:6]
•GAAP diluted EPS of $1.17; Non-GAAP diluted EPS of $5.14

[0001730168-20-000099:8k_2_02:7]
•$3,065 million of free cash flow from operations, defined as cash from operations of $3,213 million less capital expenditures of $148 million

[0001730168-20-000099:8k_2_02:8]
•Quarterly common stock dividend of $3.25 per share

[0001730168-20-000099:8k_2_02:9]
•Third quarter revenue guidance of $5.75 billion plus or minus $150 million

[0001730168-20-000099:8k_2_02:10]
•Third quarter Adjusted EBITDA guidance of $3,220 million plus or minus $75 million, or 56% of revenue at the midpoint of guidance 1

[0001730168-20-000099:8k_2_02:11]
SAN JOSE, Calif. - June 4, 2020 - Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2020, ended May 3, 2020, provided guidance for the third quarter of its fiscal year 2020 and announced its quarterly dividends.

[0001730168-20-000099:8k_2_02:12]
“Second quarter results were in-line with our expectations, and saw limited impact from the effects of COVID-19,” said Hock Tan, President and CEO of Broadcom Inc. “Looking ahead, our third quarter guidance for semiconductors reflects a surge in demand from cloud, telecom and enterprise customers, offset by supply chain constraints and an expected substantial reset in wireless. We remain focused on investing in our diverse set of mission critical semiconductor and software franchises, while carefully managing our expenses in this uncertain environment.”

[0001730168-20-000099:8k_2_02:13]
“We generated record quarterly free cash flow of over $3 billion and reinforced our balance sheet, ending the quarter with over $9 billion of cash,” said Tom Krause, CFO of Broadcom Inc. “Given our strong free cash flow generation, healthy balance sheet and enhanced liquidity position, we remain committed to maintaining our dividend while we navigate these unprecedented times.”

[0001730168-20-000099:8k_2_02:14]
________________________________

[0001730168-20-000099:8k_2_02:15]
1 The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-20-000099:8k_2_02:16]
1

[0001730168-20-000099:8k_2_02:17]
Second Quarter Fiscal Year 2020 Financial Highlights

[0001730168-20-000099:8k_2_02:18]
|  |  | GAAP |  |  |  |  |  |  | Non-GAAP |  |  |  |  |  |
| (Dollars in millions, except per share data) |  | Q2 20 |  | Q2 19 |  | Change |  |  | Q2 20 |  | Q2 19 |  | Change |  |
| Net revenue |  | $ | 5,742 |  |  | $ | 5,517 |  |  | +4 | % |  |  | $ | 5,742 |  |  | $ | 5,517 |  |  | +4 | % |  |
| Net income |  | $ | 563 |  |  | $ | 691 |  |  | -$128 |  |  | $ | 2,323 |  |  | $ | 2,334 |  |  | -$11 |  |
| Earnings per common share - diluted |  | $ | 1.17 |  |  | $ | 1.64 |  |  | -$0.47 |  |  | $ | 5.14 |  |  | $ | 5.21 |  |  | -$0.07 |  |
| (Dollars in millions) |  |  |  |  |  |  |  |  | Q2 20 |  | Q2 19 |  | Change |  |
| Cash flow from operations |  |  |  |  |  |  |  |  | $ | 3,213 |  |  | $ | 2,667 |  |  | +$546 |  |
| Adjusted EBITDA |  |  |  |  |  |  |  |  | $ | 3,209 |  |  | $ | 3,114 |  |  | +$95 |  |
| Free cash flow |  |  |  |  |  |  |  |  | $ | 3,065 |  |  | $ | 2,542 |  |  | +$523 |  |

[0001730168-20-000099:8k_2_02:19]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q2 20 |  |  |  |  | Q2 19 |  |  |  |  | Change |  |
| Semiconductor solutions |  | $ | 4,027 |  |  | 70 | % |  |  | $ | 4,104 |  |  | 74 | % |  |  | -2 | % |  |
| Infrastructure software |  | 1,715 |  |  | 30 |  |  | 1,413 |  |  | 26 |  |  | +21 | % |  |
| Total net revenue |  | $ | 5,742 |  |  | 100 | % |  |  | $ | 5,517 |  |  | 100 | % |  |  |  |  |

[0001730168-20-000099:8k_2_02:20]
The Company’s cash and cash equivalents at the end of the second fiscal quarter were $9,207 million, compared to $6,444 million at the end of the prior quarter.

[0001730168-20-000099:8k_2_02:21]
During the second fiscal quarter, the Company generated $3,213 million in cash from operations and spent $148 million on capital expenditures.

[0001730168-20-000099:8k_2_02:22]
On March 31, 2020, the Company paid a cash dividend of $3.25 per share of common stock, totaling $1,306 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-20-000099:8k_2_02:23]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-20-000099:8k_2_02:24]
Third Quarter Fiscal Year 2020 Business Outlook

[0001730168-20-000099:8k_2_02:25]
Based on current business trends and conditions, the outlook for the third quarter of fiscal year 2020, ending August 2, 2020, is expected to be as follows:

[0001730168-20-000099:8k_2_02:26]
•Third quarter revenue guidance of $5.75 billion plus or minus $150 million; and

[0001730168-20-000099:8k_2_02:27]
•Third quarter Adjusted EBITDA of $3,220 million plus or minus $75 million, or 56% of revenue at the midpoint of guidance.

[0001730168-20-000099:8k_2_02:28]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance

[0001730168-20-000099:8k_2_02:29]
2

[0001730168-20-000099:8k_2_02:30]
and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000099:8k_2_02:31]
Quarterly Dividends

[0001730168-20-000099:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.25 per share. The common stock dividend is payable on June 30, 2020 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 22, 2020.

[0001730168-20-000099:8k_2_02:33]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on June 30, 2020 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 15, 2020.

[0001730168-20-000099:8k_2_02:34]
Financial Results Conference Call

[0001730168-20-000099:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the second quarter of fiscal year 2020, ended May 3, 2020, and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 7865139. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 7865139. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at www.broadcom.com.

[0001730168-20-000099:8k_2_02:36]
Basis of Presentation

[0001730168-20-000099:8k_2_02:37]
The Company’s financial results include contributions from the Symantec enterprise security business’ continuing operations starting in the first quarter of fiscal year 2020. The financial results from businesses that have been classified as discontinued operations in the Company’s financial statements are not included in the results presented above, unless otherwise stated.

[0001730168-20-000099:8k_2_02:38]
Non-GAAP Financial Measures

[0001730168-20-000099:8k_2_02:39]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gain from lapse of indemnification, gains (losses) on investments, income (loss) from discontinued operations and non-GAAP tax reconciling adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s

[0001730168-20-000099:8k_2_02:40]
3

[0001730168-20-000099:8k_2_02:41]
non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual. Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-20-000099:8k_2_02:42]
Broadcom believes this non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. These non-GAAP measures are provided in addition to, and not as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release.

[0001730168-20-000099:8k_2_02:43]
About Broadcom Inc.

[0001730168-20-000099:8k_2_02:44]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to www.broadcom.com.

[0001730168-20-000099:8k_2_02:45]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-20-000099:8k_2_02:46]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has, and will likely continue to, negatively impact the global economy and disrupt normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; global economic conditions and concerns; international political and economic conditions; any acquisitions we may make, such as delays, challenges and expenses associated

[0001730168-20-000099:8k_2_02:47]
4

[0001730168-20-000099:8k_2_02:48]
with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions, including our recent acquisition of Symantec Corporation’s Enterprise Security business; government regulations and trade restrictions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; involvement in legal or administrative proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; sales to our government clients; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; changes in accounting standards; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-20-000099:8k_2_02:49]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-20-000099:8k_2_02:50]
Contact:

[0001730168-20-000099:8k_2_02:51]
Broadcom Inc.

[0001730168-20-000099:8k_2_02:52]
Beatrice F. Russotto

[0001730168-20-000099:8k_2_02:53]
Investor Relations

[0001730168-20-000099:8k_2_02:54]
408-433-8000

[0001730168-20-000099:8k_2_02:55]
investor.relations@broadcom.com

[0001730168-20-000099:8k_2_02:56]
5

[0001730168-20-000099:8k_2_02:57]
BROADCOM INC.

[0001730168-20-000099:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-20-000099:8k_2_02:59]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-20-000099:8k_2_02:60]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | February 2,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
| Net revenue |  | $ | 5,742 |  |  |  | $ | 5,858 |  |  |  | $ | 5,517 |  |  | $ | 11,600 |  |  | $ | 11,306 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,592 |  |  | 1,636 |  |  | 1,592 |  |  | 3,228 |  |  | 3,284 |  |
| Amortization of acquisition-related intangible assets |  | 954 |  |  | 950 |  |  | 826 |  |  | 1,904 |  |  | 1,659 |  |
| Restructuring charges |  | 7 |  |  | 8 |  |  | 10 |  |  | 15 |  |  | 66 |  |
| Total cost of revenue |  | 2,553 |  |  | 2,594 |  |  | 2,428 |  |  | 5,147 |  |  | 5,009 |  |
| Gross margin |  | 3,189 |  |  | 3,264 |  |  | 3,089 |  |  | 6,453 |  |  | 6,297 |  |
| Research and development |  | 1,269 |  |  | 1,289 |  |  | 1,151 |  |  | 2,558 |  |  | 2,284 |  |
| Selling, general and administrative |  | 501 |  |  | 601 |  |  | 419 |  |  | 1,102 |  |  | 890 |  |
| Amortization of acquisition-related intangible assets |  | 599 |  |  | 603 |  |  | 473 |  |  | 1,202 |  |  | 949 |  |
| Restructuring, impairment and disposal charges |  | 54 |  |  | 57 |  |  | 76 |  |  | 111 |  |  | 649 |  |
| Total operating expenses |  | 2,423 |  |  | 2,550 |  |  | 2,119 |  |  | 4,973 |  |  | 4,772 |  |
| Operating income |  | 766 |  |  | 714 |  |  | 970 |  |  | 1,480 |  |  | 1,525 |  |
| Interest expense |  | (487) |  |  | (406) |  |  | (376) |  |  | (893) |  |  | (721) |  |
| Other income (expense), net |  | 130 |  |  | (4) |  |  | 63 |  |  | 126 |  |  | 131 |  |
| Income from continuing operations before income taxes |  | 409 |  |  | 304 |  |  | 657 |  |  | 713 |  |  | 935 |  |
| Benefit from income taxes |  | (159) |  |  | (76) |  |  | (36) |  |  | (235) |  |  | (239) |  |
| Income from continuing operations |  | 568 |  |  |  | 380 |  |  |  | 693 |  |  |  | 948 |  |  |  | 1,174 |  |
| Income (loss) from discontinued operations, net of income taxes |  | (5) |  |  |  | 5 |  |  |  | (2) |  |  |  | — |  |  |  | (12) |  |
| Net income |  | 563 |  |  |  | 385 |  |  |  | 691 |  |  |  | 948 |  |  |  | 1,162 |  |
| Dividends on preferred stock (1) |  | (75) |  |  |  | (74) |  |  |  | — |  |  |  | (149) |  |  |  | — |  |
| Net income attributable to common stock |  | $ | 488 |  |  |  | $ | 311 |  |  |  | $ | 691 |  |  |  | $ | 799 |  |  |  | $ | 1,162 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.23 |  |  | $ | 0.77 |  |  | $ | 1.75 |  |  | $ | 2.00 |  |  | $ | 2.94 |  |
| Income (loss) per share from discontinued operations |  | (0.01) |  |  | 0.01 |  |  | (0.01) |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 1.22 |  |  | $ | 0.78 |  |  | $ | 1.74 |  |  | $ | 2.00 |  |  | $ | 2.91 |  |
| Diluted income per share attributable to common stock (2): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 1.18 |  |  | $ | 0.73 |  |  | $ | 1.64 |  |  | $ | 1.91 |  |  | $ | 2.80 |  |
| Income (loss) per share from discontinued operations |  | (0.01) |  |  | 0.01 |  |  | — |  |  | — |  |  | (0.03) |  |
| Net income per share |  | $ | 1.17 |  |  | $ | 0.74 |  |  | $ | 1.64 |  |  | $ | 1.91 |  |  | $ | 2.77 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 401 |  |  |  | 398 |  |  |  | 397 |  |  |  | 400 |  |  |  | 399 |  |
| Diluted |  | 417 |  |  |  | 420 |  |  |  | 422 |  |  |  | 419 |  |  |  | 420 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 41 |  |  |  | $ | 43 |  |  |  | $ | 41 |  |  |  | $ | 84 |  |  |  | $ | 75 |  |
| Research and development |  | 373 |  |  |  | 391 |  |  |  | 371 |  |  |  | 764 |  |  |  | 682 |  |
| Selling, general and administrative |  | 103 |  |  |  | 111 |  |  |  | 132 |  |  |  | 214 |  |  |  | 252 |  |
| Total stock-based compensation expense |  | $ | 517 |  |  |  | $ | 545 |  |  |  | $ | 544 |  |  |  | $ | 1,062 |  |  |  | $ | 1,009 |  |
| (1) For the fiscal quarter and two fiscal quarters ended May 3, 2020 and the fiscal quarter ended February 2, 2020, net income attributable to common stock excludes dividends on Mandatory Convertible Preferred Stock issued during the fiscal quarter ended November 3, 2019. |  |  |  |  |  |  |  |  |  |  |
| (2) For the fiscal quarter and two fiscal quarters ended May 3, 2020 and the fiscal quarter ended February 2, 2020, diluted income per share excluded the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |  |  |  |  |  |  |  |  |  |  |

[0001730168-20-000099:8k_2_02:61]
BROADCOM INC.

[0001730168-20-000099:8k_2_02:62]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-20-000099:8k_2_02:63]
(IN MILLIONS)

[0001730168-20-000099:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | February 2,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
| Gross margin on GAAP basis |  | $ | 3,189 |  |  |  | $ | 3,264 |  |  |  | $ | 3,089 |  |  | $ | 6,453 |  |  | $ | 6,297 |  |
| Purchase accounting effect on inventory |  | — |  |  | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 954 |  |  | 950 |  |  | 826 |  |  | 1,904 |  |  | 1,659 |  |
| Stock-based compensation expense |  | 41 |  |  | 43 |  |  | 41 |  |  | 84 |  |  | 75 |  |
| Restructuring charges |  | 7 |  |  | 8 |  |  | 10 |  |  | 15 |  |  | 66 |  |
| Acquisition-related costs |  | 5 |  |  | 1 |  |  | 5 |  |  | 6 |  |  | 7 |  |
| Gross margin on non-GAAP basis |  | $ | 4,196 |  |  | $ | 4,277 |  |  | $ | 3,971 |  |  | $ | 8,473 |  |  | $ | 8,104 |  |
| Research and development on GAAP basis |  | $ | 1,269 |  |  |  | $ | 1,289 |  |  |  | $ | 1,151 |  |  | $ | 2,558 |  |  | $ | 2,284 |  |
| Stock-based compensation expense |  | 373 |  |  | 391 |  |  | 371 |  |  | 764 |  |  | 682 |  |
| Acquisition-related costs |  | 5 |  |  | 7 |  |  | 1 |  |  | 12 |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 891 |  |  | $ | 891 |  |  | $ | 779 |  |  | $ | 1,782 |  |  | $ | 1,599 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 501 |  |  |  | $ | 601 |  |  |  | $ | 419 |  |  | $ | 1,102 |  |  | $ | 890 |  |
| Stock-based compensation expense |  | 103 |  |  | 111 |  |  | 132 |  |  | 214 |  |  | 252 |  |
| Acquisition-related costs |  | 95 |  |  | 175 |  |  | 44 |  |  | 270 |  |  | 134 |  |
| Litigation settlements |  | 29 |  |  | 13 |  |  | — |  |  | 42 |  |  | — |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 274 |  |  | $ | 302 |  |  | $ | 243 |  |  | $ | 576 |  |  | $ | 504 |  |
| Total operating expenses on GAAP basis |  | $ | 2,423 |  |  |  | $ | 2,550 |  |  |  | $ | 2,119 |  |  | $ | 4,973 |  |  | $ | 4,772 |  |
| Amortization of acquisition-related intangible assets |  | 599 |  |  | 603 |  |  | 473 |  |  | 1,202 |  |  | 949 |  |
| Stock-based compensation expense |  | 476 |  |  | 502 |  |  | 503 |  |  | 978 |  |  | 934 |  |
| Restructuring, impairment and disposal charges |  | 54 |  |  | 57 |  |  | 76 |  |  | 111 |  |  | 649 |  |
| Litigation settlements |  | 29 |  |  | 13 |  |  | — |  |  | 42 |  |  | — |  |
| Acquisition-related costs |  | 100 |  |  | 182 |  |  | 45 |  |  | 282 |  |  | 137 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,165 |  |  | $ | 1,193 |  |  | $ | 1,022 |  |  | $ | 2,358 |  |  | $ | 2,103 |  |
| Operating income on GAAP basis |  | $ | 766 |  |  |  | $ | 714 |  |  |  | $ | 970 |  |  | $ | 1,480 |  |  | $ | 1,525 |  |
| Purchase accounting effect on inventory |  | — |  |  | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,299 |  |  | 3,106 |  |  | 2,608 |  |
| Stock-based compensation expense |  | 517 |  |  | 545 |  |  | 544 |  |  | 1,062 |  |  | 1,009 |  |
| Restructuring, impairment and disposal charges |  | 61 |  |  | 65 |  |  | 86 |  |  | 126 |  |  | 715 |  |
| Litigation settlements |  | 29 |  |  | 13 |  |  | — |  |  | 42 |  |  | — |  |
| Acquisition-related costs |  | 105 |  |  | 183 |  |  | 50 |  |  | 288 |  |  | 144 |  |
| Operating income on non-GAAP basis |  | $ | 3,031 |  |  | $ | 3,084 |  |  | $ | 2,949 |  |  | $ | 6,115 |  |  | $ | 6,001 |  |
| Interest expense on GAAP basis |  | $ | (487) |  |  |  | $ | (406) |  |  |  | $ | (376) |  |  | $ | (893) |  |  | $ | (721) |  |
| Loss on debt extinguishment |  | 93 |  |  | 5 |  |  | 26 |  |  | 98 |  |  | 26 |  |
| Interest expense on non-GAAP basis |  | $ | (394) |  |  | $ | (401) |  |  | $ | (350) |  |  | $ | (795) |  |  | $ | (695) |  |
| Other income (expense), net on GAAP basis |  | $ | 130 |  |  |  | $ | (4) |  |  |  | $ | 63 |  |  | $ | 126 |  |  | $ | 131 |  |
| Gain from lapse of indemnification |  | (116) |  |  | — |  |  | — |  |  | (116) |  |  | — |  |
| (Gains) losses on investments |  | (8) |  |  | 18 |  |  | (40) |  |  | 10 |  |  | (67) |  |
| Acquisition-related gain |  | (3) |  |  | (4) |  |  | — |  |  | (7) |  |  | — |  |
| Other income, net on non-GAAP basis |  | $ | 3 |  |  | $ | 10 |  |  | $ | 23 |  |  | $ | 13 |  |  | $ | 64 |  |

[0001730168-20-000099:8k_2_02:65]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | February 2,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
| Income from continuing operations before income taxes on GAAP basis |  | $ | 409 |  |  |  | $ | 304 |  |  |  | $ | 657 |  |  | $ | 713 |  |  | $ | 935 |  |
| Purchase accounting effect on inventory |  | — |  |  | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,299 |  |  | 3,106 |  |  | 2,608 |  |
| Stock-based compensation expense |  | 517 |  |  | 545 |  |  | 544 |  |  | 1,062 |  |  | 1,009 |  |
| Restructuring, impairment and disposal charges |  | 61 |  |  | 65 |  |  | 86 |  |  | 126 |  |  | 715 |  |
| Litigation settlements |  | 29 |  |  | 13 |  |  | — |  |  | 42 |  |  | — |  |
| Acquisition-related costs |  | 102 |  |  | 179 |  |  | 50 |  |  | 281 |  |  | 144 |  |
| Loss on debt extinguishment |  | 93 |  |  | 5 |  |  | 26 |  |  | 98 |  |  | 26 |  |
| Gain from lapse of indemnification |  | (116) |  |  | — |  |  | — |  |  | (116) |  |  | — |  |
| (Gains) losses on investments |  | (8) |  |  | 18 |  |  | (40) |  |  | 10 |  |  | (67) |  |
| Income before income taxes on non-GAAP basis |  | $ | 2,640 |  |  | $ | 2,693 |  |  | $ | 2,622 |  |  | $ | 5,333 |  |  | $ | 5,370 |  |
| Benefit from income taxes on GAAP basis |  | $ | (159) |  |  |  | $ | (76) |  |  |  | $ | (36) |  |  | $ | (235) |  |  | $ | (239) |  |
| Non-GAAP tax reconciling adjustments |  | 476 |  |  | 399 |  |  | 324 |  |  | 875 |  |  | 829 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 317 |  |  | $ | 323 |  |  | $ | 288 |  |  | $ | 640 |  |  | $ | 590 |  |
| Net income on GAAP basis |  | $ | 563 |  |  |  | $ | 385 |  |  |  | $ | 691 |  |  | $ | 948 |  |  | $ | 1,162 |  |
| Purchase accounting effect on inventory |  | — |  |  | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Amortization of acquisition-related intangible assets |  | 1,553 |  |  | 1,553 |  |  | 1,299 |  |  | 3,106 |  |  | 2,608 |  |
| Stock-based compensation expense |  | 517 |  |  | 545 |  |  | 544 |  |  | 1,062 |  |  | 1,009 |  |
| Restructuring, impairment and disposal charges |  | 61 |  |  | 65 |  |  | 86 |  |  | 126 |  |  | 715 |  |
| Litigation settlements |  | 29 |  |  | 13 |  |  | — |  |  | 42 |  |  | — |  |
| Acquisition-related costs |  | 102 |  |  | 179 |  |  | 50 |  |  | 281 |  |  | 144 |  |
| Loss on debt extinguishment |  | 93 |  |  | 5 |  |  | 26 |  |  | 98 |  |  | 26 |  |
| Gain from lapse of indemnification |  | (116) |  |  | — |  |  | — |  |  | (116) |  |  | — |  |
| (Gains) losses on investments |  | (8) |  |  | 18 |  |  | (40) |  |  | 10 |  |  | (67) |  |
| Non-GAAP tax reconciling adjustments |  | (476) |  |  | (399) |  |  | (324) |  |  | (875) |  |  | (829) |  |
| Discontinued operations, net of income taxes |  | 5 |  |  | (5) |  |  | 2 |  |  | — |  |  | 12 |  |
| Net income on non-GAAP basis |  | $ | 2,323 |  |  | $ | 2,370 |  |  | $ | 2,334 |  |  | $ | 4,693 |  |  | $ | 4,780 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 417 |  |  | 420 |  |  | 422 |  |  | 419 |  |  | 420 |  |
| Non-GAAP adjustment (1) |  | 35 |  |  | 31 |  |  | 26 |  |  | 33 |  |  | 25 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 452 |  |  | 451 |  |  | 448 |  |  | 452 |  |  | 445 |  |
| Net income on non-GAAP basis |  | $ | 2,323 |  |  |  | $ | 2,370 |  |  |  | $ | 2,334 |  |  | $ | 4,693 |  |  | $ | 4,780 |  |
| Interest expense on non-GAAP basis |  | 394 |  |  | 401 |  |  | 350 |  |  | 795 |  |  | 695 |  |
| Provision for income taxes on non-GAAP basis |  | 317 |  |  | 323 |  |  | 288 |  |  | 640 |  |  | 590 |  |
| Depreciation |  | 147 |  |  | 146 |  |  | 142 |  |  | 293 |  |  | 285 |  |
| Amortization on non-GAAP basis |  | 28 |  |  | 25 |  |  | — |  |  | 53 |  |  | — |  |
| Adjusted EBITDA |  | $ | 3,209 |  |  | $ | 3,265 |  |  | $ | 3,114 |  |  | $ | 6,474 |  |  | $ | 6,350 |  |
| Net cash provided by operating activities |  | $ | 3,213 |  |  |  | $ | 2,322 |  |  |  | $ | 2,667 |  |  | $ | 5,535 |  |  | $ | 4,799 |  |
| Purchases of property, plant and equipment |  | (148) |  |  | (108) |  |  | (125) |  |  | (256) |  |  | (224) |  |
| Free cash flow |  | $ | 3,065 |  |  | $ | 2,214 |  |  | $ | 2,542 |  |  | $ | 5,279 |  |  | $ | 4,575 |  |

[0001730168-20-000099:8k_2_02:66]
|  |  | Fiscal Quarter Ending |
|  |  | August 2, |
| Expected average diluted share count: |  | 2020 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 419 |  |
| Non-GAAP adjustment (1) |  | 33 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 452 |  |

[0001730168-20-000099:8k_2_02:67]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. For the fiscal quarter and two fiscal quarters ended May 3, 2020 and the fiscal quarter ended February 2, 2020, the non-GAAP adjustment included the impact of Mandatory Convertible Preferred Stock that was antidilutive on a GAAP basis. For the fiscal quarter ending August 2, 2020, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |  |  |  |  |  |  |  |  |  |  |

[0001730168-20-000099:8k_2_02:68]
BROADCOM INC.

[0001730168-20-000099:8k_2_02:69]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-20-000099:8k_2_02:70]
(IN MILLIONS)

[0001730168-20-000099:8k_2_02:71]
|  |  | May 3,2020 |  | November 3,2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,207 |  |  | $ | 5,055 |  |
| Trade accounts receivable, net |  | 3,211 |  |  | 3,259 |  |
| Inventory |  | 953 |  |  | 874 |  |
| Other current assets |  | 851 |  |  | 729 |  |
| Total current assets |  | 14,222 |  |  | 9,917 |  |
| Long-term assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 2,618 |  |  | 2,565 |  |
| Goodwill |  | 43,457 |  |  | 36,714 |  |
| Intangible assets, net |  | 19,909 |  |  | 17,554 |  |
| Other long-term assets |  | 1,342 |  |  | 743 |  |
| Total assets |  | $ | 81,548 |  |  | $ | 67,493 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,230 |  |  | $ | 855 |  |
| Employee compensation and benefits |  | 494 |  |  | 641 |  |
| Current portion of long-term debt |  | 819 |  |  | 2,787 |  |
| Other current liabilities |  | 4,058 |  |  | 2,616 |  |
| Total current liabilities |  | 6,601 |  |  | 6,899 |  |
| Long-term liabilities: |  |  |  |  |  |  |
| Long-term debt |  | 45,044 |  |  | 30,011 |  |
| Other long-term liabilities |  | 5,933 |  |  | 5,613 |  |
| Total liabilities |  | 57,578 |  |  | 42,523 |  |
| Preferred stock dividend obligation |  | 28 |  |  | 29 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 24,073 |  |  | 25,081 |  |
| Retained earnings |  | — |  |  | — |  |
| Accumulated other comprehensive loss |  | (131) |  |  | (140) |  |
| Total stockholders' equity |  | 23,942 |  |  | 24,941 |  |
| Total liabilities and equity |  | $ | 81,548 |  |  | $ | 67,493 |  |

[0001730168-20-000099:8k_2_02:72]
| BROADCOM INC. |  |  |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |  |  |  |  |  |  |  |  |  |
| (IN MILLIONS) |  |  |  |  |  |  |  |  |  |  |
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |
|  |  | May 3,2020 |  | February 2,2020 |  | May 5,2019 |  | May 3,2020 |  | May 5,2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 563 |  |  |  | $ | 385 |  |  |  | $ | 691 |  |  | $ | 948 |  |  | $ | 1,162 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,583 |  |  |  | 1,582 |  |  |  | 1,305 |  |  | 3,165 |  |  | 2,621 |  |
| Depreciation |  | 147 |  |  |  | 146 |  |  |  | 142 |  |  | 293 |  |  | 285 |  |
| Stock-based compensation |  | 517 |  |  |  | 545 |  |  |  | 544 |  |  | 1,062 |  |  | 1,009 |  |
| Deferred taxes and other non-cash taxes |  | (175) |  |  |  | (72) |  |  |  | (94) |  |  | (247) |  |  | (473) |  |
| Loss on debt extinguishment |  | 93 |  |  |  | 5 |  |  |  | — |  |  | 98 |  |  | — |  |
| Non-cash restructuring, impairment and disposal charges |  | 6 |  |  |  | 11 |  |  |  | 6 |  |  | 17 |  |  | 98 |  |
| Non-cash interest expense |  | 31 |  |  |  | 30 |  |  |  | 14 |  |  | 61 |  |  | 27 |  |
| Other |  | (8) |  |  |  | 19 |  |  |  | (39) |  |  | 11 |  |  | (60) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 440 |  |  |  | (392) |  |  |  | 193 |  |  | 48 |  |  | 261 |  |
| Inventory |  | (10) |  |  |  | 40 |  |  |  | 40 |  |  | 30 |  |  | 90 |  |
| Accounts payable |  | 233 |  |  |  | 117 |  |  |  | 30 |  |  | 350 |  |  | (139) |  |
| Employee compensation and benefits |  | 61 |  |  |  | (217) |  |  |  | (6) |  |  | (156) |  |  | (464) |  |
| Other current assets and current liabilities |  | 118 |  |  |  | 346 |  |  |  | (37) |  |  | 464 |  |  | 469 |  |
| Other long-term assets and long-term liabilities |  | (386) |  |  |  | (223) |  |  |  | (122) |  |  | (609) |  |  | (87) |  |
| Net cash provided by operating activities |  | 3,213 |  |  |  | 2,322 |  |  |  | 2,667 |  |  | 5,535 |  |  | 4,799 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  |  | (10,870) |  |  |  | — |  |  | (10,870) |  |  | (16,027) |  |
| Proceeds from sales of businesses |  | 168 |  |  |  | — |  |  |  | — |  |  | 168 |  |  | 957 |  |
| Purchases of property, plant and equipment |  | (148) |  |  |  | (108) |  |  |  | (125) |  |  | (256) |  |  | (224) |  |
| Other |  | 4 |  |  |  | (9) |  |  |  | 19 |  |  | (5) |  |  | (5) |  |
| Net cash provided by (used in) investing activities |  | 24 |  |  |  | (10,987) |  |  |  | (106) |  |  | (10,963) |  |  | (15,299) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 4,468 |  |  |  | 15,381 |  |  |  | 10,897 |  |  | 19,849 |  |  | 28,793 |  |
| Repayment of debt |  | (4,452) |  |  |  | (4,537) |  |  |  | (12,000) |  |  | (8,989) |  |  | (12,000) |  |
| Other borrowings, net |  | 1,025 |  |  |  | 718 |  |  |  | 1,044 |  |  | 1,743 |  |  | 1,575 |  |
| Payments of dividends |  | (1,381) |  |  |  | (1,372) |  |  |  | (1,057) |  |  | (2,753) |  |  | (2,124) |  |
| Repurchases of common stock - repurchase program |  | — |  |  |  | — |  |  |  | (830) |  |  | — |  |  | (4,266) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (219) |  |  |  | (169) |  |  |  | (500) |  |  | (388) |  |  | (577) |  |
| Issuance of common stock |  | 91 |  |  |  | 37 |  |  |  | 121 |  |  | 128 |  |  | 183 |  |
| Other |  | (6) |  |  |  | (4) |  |  |  | (1) |  |  | (10) |  |  | (48) |  |
| Net cash provided by (used in) financing activities |  | (474) |  |  |  | 10,054 |  |  |  | (2,326) |  |  | 9,580 |  |  | 11,536 |  |
| Net change in cash and cash equivalents |  | 2,763 |  |  |  | 1,389 |  |  |  | 235 |  |  | 4,152 |  |  | 1,036 |  |
| Cash and cash equivalents at the beginning of period |  | 6,444 |  |  |  | 5,055 |  |  |  | 5,093 |  |  | 5,055 |  |  | 4,292 |  |
| Cash and cash equivalents at end of period |  | $ | 9,207 |  |  | $ | 6,444 |  |  | $ | 5,328 |  |  | $ | 9,207 |  |  | $ | 5,328 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 375 |  |  |  | $ | 381 |  |  |  | $ | 189 |  |  |  | $ | 756 |  |  |  | $ | 612 |  |
| Cash paid for income taxes |  | $ | 124 |  |  |  | $ | 131 |  |  |  | $ | 425 |  |  |  | $ | 255 |  |  |  | $ | 520 |  |
