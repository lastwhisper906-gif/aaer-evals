# AVGO notes — 0001730168-22-000094


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-22-000094:notes:1]
[same as prior period, unchanged from 0001730168-22-000081:notes:1]

[0001730168-22-000094:notes:2]
[same as prior period, unchanged from 0001730168-22-000081:notes:2]

[0001730168-22-000094:notes:3]
[same as prior period, unchanged from 0001730168-22-000081:notes:3]

[0001730168-22-000094:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ended on May 1, 2022 and the third quarter ended on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.

[0001730168-22-000094:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for each of the fiscal quarter and three fiscal quarters ended July 31, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.

[0001730168-22-000094:notes:6]
[same as prior period, unchanged from 0001730168-22-000081:notes:6]

[0001730168-22-000094:notes:7]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. Due to the ongoing COVID-19 pandemic, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.
Recently Adopted Accounting Guidance. In October 2021, the Financial Accounting Standards Board issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not materially impact our condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-22-000094:notes:8]
[same as prior period, unchanged from 0001730168-22-000081:notes:9]

[0001730168-22-000094:notes:9]
[same as prior period, unchanged from 0001730168-22-000081:notes:10]

[0001730168-22-000094:notes:10]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 10. “Segment Information”.

[0001730168-22-000094:notes:11]
[same as prior period, unchanged from 0001730168-22-000081:notes:12]

[0001730168-22-000094:notes:12]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |

[0001730168-22-000094:notes:13]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |

[0001730168-22-000094:notes:14]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |

[0001730168-22-000094:notes:15]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |

[0001730168-22-000094:notes:16]
[same as prior period, unchanged from 0001730168-22-000081:notes:17]

[0001730168-22-000094:notes:17]
[same as prior period, unchanged from 0001730168-22-000081:notes:18]

[0001730168-22-000094:notes:18]
[same as prior period, unchanged from 0001730168-22-000081:notes:19]

[0001730168-22-000094:notes:19]
[same as prior period, unchanged from 0001730168-22-000081:notes:20]

[0001730168-22-000094:notes:20]
[same as prior period, unchanged from 0001730168-22-000081:notes:21]

[0001730168-22-000094:notes:21]
|  |  | July 31,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 77 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,740 |  |  | $ | 3,185 |  |

[0001730168-22-000094:notes:22]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended July 31, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $2,482 million. The amount of revenue recognized during the three fiscal quarters ended August 1, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,330 million.

[0001730168-22-000094:notes:23]
[same as prior period, unchanged from 0001730168-22-000081:notes:24]

[0001730168-22-000094:notes:24]
[same as prior period, unchanged from 0001730168-22-000081:notes:25]

[0001730168-22-000094:notes:25]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of July 31, 2022 were approximately $25.2 billion. We expect approximately 24% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## avgo:PendingBusinessCombinationDisclosureTextBlock

[0001730168-22-000094:notes:26]
Pending Acquisition of VMware, Inc.
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion based on the closing price of Broadcom common stock on May 25, 2022. In addition, we will assume approximately $8 billion of VMware long-term debt, net of $4 billion of expected cash at close.

[0001730168-22-000094:notes:27]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

[0001730168-22-000094:notes:28]
We will assume all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-22-000094:notes:29]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

[0001730168-22-000094:notes:30]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

[0001730168-22-000094:notes:31]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023, is subject to satisfaction or waiver of customary closing conditions, including (i) adoption of the VMware Merger Agreement by VMware stockholders, (ii) the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 and clearance under the antitrust laws of the European Union and certain other jurisdictions, and (iii) the effectiveness of the registration statement on Form S-4 that we filed on July 15, 2022, as may be amended from time to time, registering approximately 59 million shares of our common stock. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-22-000094:notes:32]
[same as prior period, unchanged from 0001730168-22-000081:notes:27]

[0001730168-22-000094:notes:33]
Cash equivalents included $2,576 million and $4,668 million of time deposits and $1,747 million and $1,607 million of money-market funds as of July 31, 2022 and October 31, 2021, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-22-000094:notes:34]
[same as prior period, unchanged from 0001730168-22-000081:notes:29]

[0001730168-22-000094:notes:35]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $900 million and $3,000 million during the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, and $1,000 million and $2,827 million during the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-22-000094:notes:36]
[same as prior period, unchanged from 0001730168-22-000081:notes:31]

[0001730168-22-000094:notes:37]
|  |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Finished goods |  | $ | 641 |  |  | $ | 423 |  |
| Work-in-process |  | 994 |  |  | 680 |  |
| Raw materials |  | 203 |  |  | 194 |  |
| Total inventory |  | $ | 1,838 |  |  | $ | 1,297 |  |

[0001730168-22-000094:notes:38]
[same as prior period, unchanged from 0001730168-22-000081:notes:33]

[0001730168-22-000094:notes:39]
|  |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 728 |  |  | $ | 539 |  |
| Other |  | 310 |  |  | 516 |  |
| Total other current assets |  | $ | 1,038 |  |  | $ | 1,055 |  |

[0001730168-22-000094:notes:40]
[same as prior period, unchanged from 0001730168-22-000081:notes:35]

[0001730168-22-000094:notes:41]
|  |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,297 |  |  | $ | 2,619 |  |
| Tax liabilities |  | 471 |  |  | 541 |  |
| Other |  | 839 |  |  | 679 |  |
| Total other current liabilities |  | $ | 4,607 |  |  | $ | 3,839 |  |

[0001730168-22-000094:notes:42]
[same as prior period, unchanged from 0001730168-22-000081:notes:37]

[0001730168-22-000094:notes:43]
|  |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,307 |  |  | $ | 3,407 |  |
| Other |  | 1,223 |  |  | 1,453 |  |
| Total other long-term liabilities |  | $ | 4,530 |  |  | $ | 4,860 |  |

[0001730168-22-000094:notes:44]
[same as prior period, unchanged from 0001730168-22-000081:notes:39]

[0001730168-22-000094:notes:45]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 290 |  |  | $ | 253 |  |  | $ | 989 |  |  | $ | 994 |  |
| Cash paid for income taxes |  | $ | 231 |  |  | $ | 167 |  |  | $ | 657 |  |  | $ | 607 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-22-000094:notes:46]
Goodwill and Intangible Assets
Intangible assets consisted of the following:

[0001730168-22-000094:notes:47]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of July 31, 2022: |  |  |  |  |  |  |
| Purchased technology |  | $ | 21,792 |  |  | $ | (17,065) |  |  | $ | 4,727 |  |
| Customer contracts and related relationships |  | 8,347 |  |  | (5,510) |  |  | 2,837 |  |
| Order backlog |  | 1,288 |  |  | (1,152) |  |  | 136 |  |
| Trade names |  | 700 |  |  | (353) |  |  | 347 |  |
| Other |  | 183 |  |  | (85) |  |  | 98 |  |
| Intangible assets subject to amortization |  | 32,310 |  |  | (24,165) |  |  | 8,145 |  |
| In-process research and development |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 32,339 |  |  | $ | (24,165) |  |  | $ | 8,174 |  |
| As of October 31, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 23,932 |  |  | $ | (17,148) |  |  | $ | 6,784 |  |
| Customer contracts and related relationships |  | 8,356 |  |  | (4,533) |  |  | 3,823 |  |
| Order backlog |  | 2,579 |  |  | (2,352) |  |  | 227 |  |
| Trade names |  | 787 |  |  | (386) |  |  | 401 |  |
| Other |  | 239 |  |  | (127) |  |  | 112 |  |
| Intangible assets subject to amortization |  | 35,893 |  |  | (24,546) |  |  | 11,347 |  |
| In-process research and development |  | 27 |  |  | — |  |  | 27 |  |
| Total |  | $ | 35,920 |  |  | $ | (24,546) |  |  | $ | 11,374 |  |

[0001730168-22-000094:notes:48]
During the three fiscal quarters ended July 31, 2022, we completed three acquisitions qualifying as business combinations. In connection with the acquisitions, we recorded $158 million of goodwill and $106 million of intangible assets primarily within our infrastructure software segment.

[0001730168-22-000094:notes:49]
Based on the amount of intangible assets subject to amortization as of July 31, 2022, the expected amortization expense was as follows:

[0001730168-22-000094:notes:50]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 1,067 |  |
| 2023 |  | 3,254 |  |
| 2024 |  | 2,387 |  |
| 2025 |  | 680 |  |
| 2026 |  | 343 |  |
| Thereafter |  | 414 |  |
| Total |  | $ | 8,145 |  |

[0001730168-22-000094:notes:51]
[same as prior period, unchanged from 0001730168-22-000081:notes:46]

[0001730168-22-000094:notes:52]
| Amortizable intangible assets: |  | July 31,2022 |
|  |  | (In years) |
| Purchased technology |  | 4 |
| Customer contracts and related relationships |  | 2 |
| Order backlog |  | 1 |
| Trade names |  | 8 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-22-000094:notes:53]
[same as prior period, unchanged from 0001730168-22-000081:notes:48]

[0001730168-22-000094:notes:54]
Diluted shares outstanding include the dilutive effect of unvested RSUs, in-the-money stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”), (collectively referred to as “equity awards”), as well as Mandatory Convertible Preferred Stock, as defined in Note 8. “Stockholders’ Equity.” Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-22-000094:notes:55]
[same as prior period, unchanged from 0001730168-22-000081:notes:50]

[0001730168-22-000094:notes:56]
For each of the fiscal quarter and three fiscal quarters ended August 1, 2021, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-22-000094:notes:57]
[same as prior period, unchanged from 0001730168-22-000081:notes:52]

[0001730168-22-000094:notes:58]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions, except per share data) |
| Numerator - Basic: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,074 |  |  | $ | 1,876 |  |  | $ | 8,136 |  |  | $ | 4,747 |  |
| Dividends on preferred stock |  | (75) |  |  | (74) |  |  | (224) |  |  | (224) |  |
| Net income attributable to common stock - basic |  | $ | 2,999 |  |  | $ | 1,802 |  |  | $ | 7,912 |  |  | $ | 4,523 |  |
| Numerator - Diluted: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,074 |  |  | $ | 1,876 |  |  | $ | 8,136 |  |  | $ | 4,747 |  |
| Dividends on preferred stock |  | — |  |  | (74) |  |  | — |  |  | (224) |  |
| Net income attributable to common stock - diluted |  | $ | 3,074 |  |  | $ | 1,802 |  |  | $ | 8,136 |  |  | $ | 4,523 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 405 |  | 411 |  | 408 |  | 409 |
| Dilutive effect of equity awards |  | 13 |  | 18 |  | 15 |  | 20 |
| Dilutive effect of Mandatory Convertible Preferred Stock |  | 12 |  | — |  |  | 12 |  | — |  |
| Weighted-average shares outstanding - diluted |  | 430 |  | 429 |  | 435 |  | 429 |

[0001730168-22-000094:notes:59]
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 7.40 |  |  | $ | 4.38 |  |  | $ | 19.39 |  |  | $ | 11.06 |  |
| Diluted |  | $ | 7.15 |  |  | $ | 4.20 |  |  | $ | 18.70 |  |  | $ | 10.54 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-22-000094:notes:60]
Borrowings

[0001730168-22-000094:notes:61]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |

[0001730168-22-000094:notes:62]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 35 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 304 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 26 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,793) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,191 |  |  | $ | 39,440 |  |

[0001730168-22-000094:notes:63]
April 2022 Senior Notes

[0001730168-22-000094:notes:64]
In April 2022, we issued $750 million of 4.000% senior unsecured notes due 2029 and $1,200 million of 4.150% senior unsecured notes due 2032. Using the net proceeds, we redeemed the outstanding balance of $1,020 million of our 4.700% notes due 2025 and $944 million of our 4.250% notes due 2026. As a result of these redemptions, we incurred premiums of $85 million and wrote off $15 million of unamortized discount and issuance costs. Both amounts were included in interest expense.

[0001730168-22-000094:notes:65]
In April 2022, we issued $2,500 million of 4.926% new senior unsecured notes due 2037 in exchange for $2,502 million of certain of our outstanding notes maturing between 2027 and 2030. We paid premiums of $47 million, which were included in unamortized discount and issuance costs. The 4.926% notes due 2037, the 4.000% notes due 2029 and the 4.150% notes due 2032 are collectively referred as the “April 2022 Senior Notes”.

[0001730168-22-000094:notes:66]
We may redeem or purchase, in whole or in part, any of the April 2022 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the April 2022 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-22-000094:notes:67]
Credit Agreement

[0001730168-22-000094:notes:68]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either July 31, 2022 or October 31, 2021.

[0001730168-22-000094:notes:69]
Commercial Paper

[0001730168-22-000094:notes:70]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either July 31, 2022 or October 31, 2021.

[0001730168-22-000094:notes:71]
Fair Value of Debt

[0001730168-22-000094:notes:72]
As of July 31, 2022, the estimated aggregate fair value of debt was $37,003 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-22-000094:notes:73]
Future Principal Payments of Debt

[0001730168-22-000094:notes:74]
The future scheduled principal payments of debt as of July 31, 2022 were as follows:

[0001730168-22-000094:notes:75]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 9 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 495 |  |
| 2026 |  | 1,652 |  |
| Thereafter |  | 37,105 |  |
| Total |  | $ | 41,227 |  |

[0001730168-22-000094:notes:76]
As of July 31, 2022 and October 31, 2021, we accrued interest payable of $415 million and $282 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-22-000094:notes:77]
[same as prior period, unchanged from 0001730168-22-000081:notes:72]

[0001730168-22-000094:notes:78]
[same as prior period, unchanged from 0001730168-22-000081:notes:73]

[0001730168-22-000094:notes:79]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of July 31, 2022, the minimum conversion rate was 3.1058 and the maximum conversion rate was 3.6301.

[0001730168-22-000094:notes:80]
As of each July 31, 2022 and October 31, 2021, we recognized $27 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets.

[0001730168-22-000094:notes:81]
[same as prior period, unchanged from 0001730168-22-000081:notes:76]

[0001730168-22-000094:notes:82]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 4.10 |  |  | $ | 3.60 |  |  | $ | 12.30 |  |  | $ | 10.80 |  |
| Dividends to common stockholders |  | $ | 1,661 |  |  | $ | 1,482 |  |  | $ | 5,026 |  |  | $ | 4,427 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |  | $ | 60.00 |  |  | $ | 60.00 |  |
| Dividends to preferred stockholders |  | $ | 75 |  |  | $ | 74 |  |  | $ | 224 |  |  | $ | 224 |  |

[0001730168-22-000094:notes:83]
[same as prior period, unchanged from 0001730168-22-000081:notes:78]

[0001730168-22-000094:notes:84]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. During the fiscal quarter and three fiscal quarters ended July 31, 2022, we repurchased and retired approximately 3 million and 12 million shares of our common stock for $1.5 billion and $7 billion, respectively, under this stock repurchase program.

[0001730168-22-000094:notes:85]
[same as prior period, unchanged from 0001730168-22-000081:notes:80]

[0001730168-22-000094:notes:86]
[same as prior period, unchanged from 0001730168-22-000081:notes:81]

[0001730168-22-000094:notes:87]
[same as prior period, unchanged from 0001730168-22-000081:notes:82]

[0001730168-22-000094:notes:88]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 15 |  |  | $ | 18 |  |  | $ | 49 |  |  | $ | 59 |  |
| Cost of subscriptions and services |  | 22 |  |  | 18 |  |  | 60 |  |  | 47 |  |
| Research and development |  | 259 |  |  | 285 |  |  | 788 |  |  | 920 |  |
| Selling, general and administrative |  | 77 |  |  | 100 |  |  | 249 |  |  | 264 |  |
| Total stock-based compensation expense |  | $ | 373 |  |  | $ | 421 |  |  | $ | 1,146 |  |  | $ | 1,290 |  |

[0001730168-22-000094:notes:89]
As of July 31, 2022, the total unrecognized compensation cost related to unvested stock-based awards was $2,993 million, which is expected to be recognized over the remaining weighted-average service period of 2.9 years.

[0001730168-22-000094:notes:90]
[same as prior period, unchanged from 0001730168-22-000081:notes:85]

[0001730168-22-000094:notes:91]
[same as prior period, unchanged from 0001730168-22-000081:notes:86]

[0001730168-22-000094:notes:92]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of October 31, 2021 |  | 23 |  |  | $ | 200.38 |  |  |  |  |  |
| Granted |  | 3 |  |  | $ | 532.68 |  |  |  |  |  |
| Vested |  | (6) |  |  | $ | 223.21 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | $ | 240.56 |  |  |  |  |  |
| Balance as of July 31, 2022 |  | 19 |  |  | $ | 236.05 |  |  |  |  |  |

[0001730168-22-000094:notes:93]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended July 31, 2022 was $3,357 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-22-000094:notes:94]
Income Taxes
The provision for income taxes was $263 million and $678 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the benefit from income taxes of $150 million and $151 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. The provision for income taxes for the fiscal quarter and three fiscal quarters ended July 31, 2022 was primarily driven by income before income taxes, offset by a shift in jurisdictional mix of income and expenses, and excess tax benefits from stock-based awards.

[0001730168-22-000094:notes:95]
The benefit from income taxes for the fiscal quarter ended August 1, 2021 was primarily due to excess tax benefits from stock-based awards, the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, and a shift in jurisdictional mix of income and expenses, offset in part by income tax expense on operations. The benefit from income taxes for the three fiscal quarters ended August 1, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, offset in part by income tax expense on operations.

[0001730168-22-000094:notes:96]
As of July 31, 2022, we had $5,105 million of gross unrecognized tax benefits, of which all, if recognized, would favorably impact the effective tax rate. It is possible that our existing unrecognized tax benefits may change up to $390 million as a result of lapses of the statute of limitations for certain audit periods and/or anticipated closure of audit examinations within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-22-000094:notes:97]
[same as prior period, unchanged from 0001730168-22-000081:notes:91]

[0001730168-22-000094:notes:98]
[same as prior period, unchanged from 0001730168-22-000081:notes:92]

[0001730168-22-000094:notes:99]
[same as prior period, unchanged from 0001730168-22-000081:notes:93]

[0001730168-22-000094:notes:100]
[same as prior period, unchanged from 0001730168-22-000081:notes:94]

[0001730168-22-000094:notes:101]
[same as prior period, unchanged from 0001730168-22-000081:notes:95]

[0001730168-22-000094:notes:102]
[same as prior period, unchanged from 0001730168-22-000081:notes:96]

[0001730168-22-000094:notes:103]
[same as prior period, unchanged from 0001730168-22-000081:notes:97]

[0001730168-22-000094:notes:104]
[same as prior period, unchanged from 0001730168-22-000081:notes:98]

[0001730168-22-000094:notes:105]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 6,624 |  |  | $ | 5,021 |  |  | $ | 18,726 |  |  | $ | 14,749 |  |
| Infrastructure software |  | 1,840 |  |  | 1,757 |  |  | 5,547 |  |  | 5,294 |  |
| Total net revenue |  | $ | 8,464 |  |  | $ | 6,778 |  |  | $ | 24,273 |  |  | $ | 20,043 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 3,916 |  |  | $ | 2,720 |  |  | $ | 10,891 |  |  | $ | 7,828 |  |
| Infrastructure software |  | 1,283 |  |  | 1,226 |  |  | 3,903 |  |  | 3,700 |  |
| Unallocated expenses |  | (1,462) |  |  | (1,820) |  |  | (4,555) |  |  | (5,590) |  |
| Total operating income |  | $ | 3,737 |  |  | $ | 2,126 |  |  | $ | 10,239 |  |  | $ | 5,938 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-22-000094:notes:106]
Commitments and Contingencies
Commitments

[0001730168-22-000094:notes:107]
The following table summarizes contractual obligations and commitments as of July 31, 2022 that materially changed from the end of fiscal year 2021:

[0001730168-22-000094:notes:108]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 42 |  |  | $ | 554 |  |
| 2023 |  | 178 |  |  | 185 |  |
| 2024 |  | 159 |  |  | 148 |  |
| 2025 |  | 79 |  |  | 36 |  |
| 2026 |  | 9 |  |  | 50 |  |
| Thereafter |  | 7 |  |  | 1 |  |
| Total |  | $ | 474 |  |  | $ | 974 |  |

[0001730168-22-000094:notes:109]
Purchase Commitments. Represent unconditional purchase obligations that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. These commitments include agreements to purchase inventory and other goods or services. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-22-000094:notes:110]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-22-000094:notes:111]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at July 31, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,307 million of unrecognized tax benefits and accrued interest and penalties as of July 31, 2022 have been excluded from the table above.

[0001730168-22-000094:notes:112]
Contingencies

[0001730168-22-000094:notes:113]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-22-000094:notes:114]
Lawsuits Relating to California Institute of Technology

[0001730168-22-000094:notes:115]
California Institute of Technology (“Caltech“) filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. The Federal Circuit Court issued its decision on February 4, 2022. While the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. The Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court.

[0001730168-22-000094:notes:116]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a retrial at the lower court and further appeals) could significantly change the assessment of damages. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards.

[0001730168-22-000094:notes:117]
Other Matters

[0001730168-22-000094:notes:118]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-22-000094:notes:119]
Contingency Assessment

[0001730168-22-000094:notes:120]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-22-000094:notes:121]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-22-000094:notes:122]
Other Indemnifications

[0001730168-22-000094:notes:123]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-22-000094:notes:124]
Restructuring, Impairment and Disposal Charges
From time to time, we initiate cost reduction activities to integrate acquired businesses, to align our workforce with strategic business activities, or to improve efficiencies in our operations. We recognized charges of $8 million and $39 million in the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, and $25 million and $123 million in the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. These charges were primarily recognized in operating expenses.

[0001730168-22-000094:notes:125]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended July 31, 2022:

[0001730168-22-000094:notes:126]
|  |  | Employee Termination Costs |  | Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of October 31, 2021 |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Restructuring charges |  | 19 |  |  | 2 |  |  | 21 |  |
| Utilization |  | (21) |  |  | (2) |  |  | (23) |  |
| Balance as of July 31, 2022 |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0001730168-22-000094:notes:127]
Restructuring, impairment and disposal charges for the three fiscal quarters ended July 31, 2022 included $16 million for the write-down of certain lease-related right-of-use assets and other lease-related charges. As of July 31, 2022, short-term and long-term lease liabilities included $56 million of liabilities related to restructuring activities.


## us-gaap:SubsequentEventsTextBlock

[0001730168-22-000094:notes:128]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-22-000094:notes:129]
On August 31, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2022 to stockholders of record on September 15, 2022.

[0001730168-22-000094:notes:130]
Common Stock Cash Dividends Declared

[0001730168-22-000094:notes:131]
On August 31, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on September 30, 2022 to stockholders of record on September 22, 2022.
