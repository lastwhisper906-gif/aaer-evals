# AVGO MD&A — 0001730168-22-000094


## mdna

[0001730168-22-000094:mdna:1]
[same as prior period, unchanged from 0001730168-22-000081:mdna:1]

[0001730168-22-000094:mdna:2]
[same as prior period, unchanged from 0001730168-22-000081:mdna:2]

[0001730168-22-000094:mdna:3]
[same as prior period, unchanged from 0001730168-22-000081:mdna:3]

[0001730168-22-000094:mdna:4]
[same as prior period, unchanged from 0001730168-22-000081:mdna:4]

[0001730168-22-000094:mdna:5]
[same as prior period, unchanged from 0001730168-22-000081:mdna:5]

[0001730168-22-000094:mdna:6]
Highlights during the fiscal quarter ended July 31, 2022 include the following:

[0001730168-22-000094:mdna:7]
•We generated $4,424 million of cash from operations.

[0001730168-22-000094:mdna:8]
•We paid $1,736 million in cash dividends.

[0001730168-22-000094:mdna:9]
•We repurchased $1,500 million of common stock.

[0001730168-22-000094:mdna:10]
[same as prior period, unchanged from 0001730168-22-000081:mdna:23]

[0001730168-22-000094:mdna:11]
[same as prior period, unchanged from 0001730168-22-000081:mdna:11]

[0001730168-22-000094:mdna:12]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. In addition, we will assume approximately $8 billion of VMware long-term debt, net of $4 billion expected cash at close.

[0001730168-22-000094:mdna:13]
[same as prior period, unchanged from 0001730168-22-000081:mdna:13]

[0001730168-22-000094:mdna:14]
[same as prior period, unchanged from 0001730168-22-000081:mdna:14]

[0001730168-22-000094:mdna:15]
[same as prior period, unchanged from 0001730168-22-000081:mdna:15]

[0001730168-22-000094:mdna:16]
[same as prior period, unchanged from 0001730168-22-000081:mdna:16]

[0001730168-22-000094:mdna:17]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023, is subject to satisfaction or waiver of customary closing conditions, including (i) adoption of the VMware Merger Agreement by VMware stockholders, (ii) the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 (the “HSR Act”) and clearance under the antitrust laws of the European Union and certain other jurisdictions, and (iii) the effectiveness of the registration statement on Form S-4 that we filed on July 15, 2022, as may be amended from time to time, registering approximately 59 million shares of our common stock. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-22-000094:mdna:18]
[same as prior period, unchanged from 0001730168-22-000081:mdna:18]

[0001730168-22-000094:mdna:19]
[same as prior period, unchanged from 0001730168-22-000081:mdna:19]

[0001730168-22-000094:mdna:20]
The demand environment for our semiconductor products was consistent with our expectations for the third quarter of our fiscal year ending October 30, 2022 (“fiscal year 2022”), with continued investments in technologies and solutions by enterprises, hyperscale customers and service providers. While we recently experienced robust demand in this area and record profitability driven by the supply imbalance, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. We continue to experience various constraints in our supply chain, including with respect to wafers and substrates. Although supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet demand.

[0001730168-22-000094:mdna:21]
[same as prior period, unchanged from 0001730168-22-000081:mdna:21]

[0001730168-22-000094:mdna:22]
[same as prior period, unchanged from 0001730168-22-000081:mdna:22]

[0001730168-22-000094:mdna:23]
[same as prior period, unchanged from 0001730168-22-000081:mdna:31]

[0001730168-22-000094:mdna:24]
[same as prior period, unchanged from 0001730168-22-000081:mdna:24]

[0001730168-22-000094:mdna:25]
[same as prior period, unchanged from 0001730168-22-000081:mdna:25]

[0001730168-22-000094:mdna:26]
There were no significant changes in our critical accounting estimates during the three fiscal quarters ended July 31, 2022 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2021 Annual Report on Form 10-K.

[0001730168-22-000094:mdna:27]
[same as prior period, unchanged from 0001730168-22-000081:mdna:27]

[0001730168-22-000094:mdna:28]
Fiscal Quarter and Three Fiscal Quarters Ended July 31, 2022 Compared to Fiscal Quarter and Three Fiscal Quarters Ended August 1, 2021

[0001730168-22-000094:mdna:29]
[same as prior period, unchanged from 0001730168-22-000081:mdna:29]

[0001730168-22-000094:mdna:30]
|  |  | Fiscal Quarter Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 6,627 |  |  | $ | 5,064 |  |  | 78 | % |  | 75 | % |
| Subscriptions and services |  | 1,837 |  |  | 1,714 |  |  | 22 |  |  | 25 |  |
| Total net revenue |  | 8,464 |  |  | 6,778 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,921 |  |  | 1,572 |  |  | 23 |  |  | 23 |  |
| Cost of subscriptions and services |  | 156 |  |  | 157 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 705 |  |  | 851 |  |  | 8 |  |  | 13 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,783 |  |  | 2,581 |  |  | 33 |  |  | 38 |  |
| Gross margin |  | 5,681 |  |  | 4,197 |  |  | 67 |  |  | 62 |  |
| Research and development |  | 1,255 |  |  | 1,205 |  |  | 15 |  |  | 18 |  |
| Selling, general and administrative |  | 323 |  |  | 346 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 359 |  |  | 494 |  |  | 4 |  |  | 8 |  |
| Restructuring, impairment and disposal charges |  | 7 |  |  | 26 |  |  | — |  |  | — |  |
| Total operating expenses |  | 1,944 |  |  | 2,071 |  |  | 23 |  |  | 31 |  |
| Operating income |  | $ | 3,737 |  |  | $ | 2,126 |  |  | 44 | % |  | 31 | % |

[0001730168-22-000094:mdna:31]
[same as prior period, unchanged from 0001730168-22-000081:mdna:37]

[0001730168-22-000094:mdna:32]
|  |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 19,097 |  |  | $ | 15,128 |  |  | 79 | % |  | 75 | % |
| Subscriptions and services |  | 5,176 |  |  | 4,915 |  |  | 21 |  |  | 25 |  |
| Total net revenue |  | 24,273 |  |  | 20,043 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 5,488 |  |  | 4,792 |  |  | 22 |  |  | 24 |  |
| Cost of subscriptions and services |  | 470 |  |  | 450 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 2,142 |  |  | 2,578 |  |  | 9 |  |  | 13 |  |
| Restructuring charges |  | 4 |  |  | 17 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 8,104 |  |  | 7,837 |  |  | 33 |  |  | 39 |  |
| Gross margin |  | 16,169 |  |  | 12,206 |  |  | 67 |  |  | 61 |  |
| Research and development |  | 3,722 |  |  | 3,654 |  |  | 16 |  |  | 18 |  |
| Selling, general and administrative |  | 1,012 |  |  | 1,010 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,154 |  |  | 1,482 |  |  | 5 |  |  | 7 |  |
| Restructuring, impairment and disposal charges |  | 42 |  |  | 122 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 5,930 |  |  | 6,268 |  |  | 25 |  |  | 31 |  |
| Operating income |  | $ | 10,239 |  |  | $ | 5,938 |  |  | 42 | % |  | 30 | % |

[0001730168-22-000094:mdna:33]
[same as prior period, unchanged from 0001730168-22-000081:mdna:33]

[0001730168-22-000094:mdna:34]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 18% and 19% of our net revenue for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, and 16% and 17% of our net revenue for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively.

[0001730168-22-000094:mdna:35]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and three fiscal quarters ended July 31, 2022 and August 1, 2021. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of the fiscal quarter and three fiscal quarters ended July 31, 2022 and August 1, 2021. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-22-000094:mdna:36]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile devices. The ongoing COVID-19 pandemic and macroeconomic uncertainties may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-22-000094:mdna:37]
[same as prior period, unchanged from 0001730168-22-000081:mdna:53]

[0001730168-22-000094:mdna:38]
[same as prior period, unchanged from 0001730168-22-000081:mdna:38]

[0001730168-22-000094:mdna:39]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | July 31, 2022 |  | August 1, 2021 |  | $ Change |  | % Change |  | July 31, 2022 |  | August 1, 2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 6,624 |  |  | $ | 5,021 |  |  | $ | 1,603 |  |  | 32 | % |  | $ | 18,726 |  |  | $ | 14,749 |  |  | $ | 3,977 |  |  | 27 | % |
| Infrastructure software |  | 1,840 |  |  | 1,757 |  |  | 83 |  |  | 5 | % |  | 5,547 |  |  | 5,294 |  |  | 253 |  |  | 5 | % |
| Total net revenue |  | $ | 8,464 |  |  | $ | 6,778 |  |  | $ | 1,686 |  |  | 25 | % |  | $ | 24,273 |  |  | $ | 20,043 |  |  | $ | 4,230 |  |  | 21 | % |

[0001730168-22-000094:mdna:40]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | July 31,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 78 | % |  | 74 | % |  | 77 | % |  | 74 | % |
| Infrastructure software |  | 22 |  |  | 26 |  |  | 23 |  |  | 26 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-22-000094:mdna:41]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and three fiscal quarters ended July 31, 2022 compared to the prior year fiscal periods due to ongoing strong product demand, primarily for networking, server storage and broadband products, as well as higher demand for our wireless content in mobile devices. Net revenue from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended July 31, 2022 compared to the prior year fiscal periods primarily due to higher demand for our mainframe solutions and FC SAN products.

[0001730168-22-000094:mdna:42]
[same as prior period, unchanged from 0001730168-22-000081:mdna:42]

[0001730168-22-000094:mdna:43]
Gross margin was $5,681 million, or 67% of net revenue, for the fiscal quarter ended July 31, 2022 compared to $4,197 million, or 62% of net revenue, for the fiscal quarter ended August 1, 2021, and $16,169 million, or 67% of net revenue, for the three fiscal quarters ended July 31, 2022 compared to $12,206 million, or 61% of net revenue, for the three fiscal quarters ended August 1, 2021.

[0001730168-22-000094:mdna:44]
The increases were primarily due to lower amortization of acquisition-related intangible assets mainly from our 2016 acquisition of Broadcom Corporation and, to a lesser extent, favorable margin within our semiconductor solutions segment.

[0001730168-22-000094:mdna:45]
[same as prior period, unchanged from 0001730168-22-000081:mdna:45]

[0001730168-22-000094:mdna:46]
Research and development expense increased $50 million, or 4%, and $68 million, or 2%, for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher variable employee compensation expense and engineering project costs, partially offset by lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-22-000094:mdna:47]
[same as prior period, unchanged from 0001730168-22-000081:mdna:47]

[0001730168-22-000094:mdna:48]
Selling, general and administrative expense decreased $23 million, or 7%, for the fiscal quarter ended July 31, 2022, compared to the prior year fiscal period, primarily due to lower stock-based compensation expense. Selling, general and administrative expense for the three fiscal quarters ended July 31, 2022 was relatively flat compared to the prior year fiscal period as higher variable employee compensation expense and sales initiatives were offset by lower acquisition-related costs and stock-based compensation expense.

[0001730168-22-000094:mdna:49]
[same as prior period, unchanged from 0001730168-22-000081:mdna:49]

[0001730168-22-000094:mdna:50]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $135 million, or 27%, and $328 million, or 22%, for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-22-000094:mdna:51]
[same as prior period, unchanged from 0001730168-22-000081:mdna:51]

[0001730168-22-000094:mdna:52]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $19 million, or 73%, and $80 million, or 66%, for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the prior

[0001730168-22-000094:mdna:53]
year fiscal periods. The decreases were primarily due to lower employee termination costs in the current year fiscal periods following the completion of key restructuring activities from acquisitions.

[0001730168-22-000094:mdna:54]
[same as prior period, unchanged from 0001730168-22-000081:mdna:54]

[0001730168-22-000094:mdna:55]
Total stock-based compensation expense was $373 million and $1,146 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to $421 million and $1,290 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. The decreases primarily reflect the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-22-000094:mdna:56]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of July 31, 2022, which we expect to recognize over the remaining weighted-average service period of 2.9 years.

[0001730168-22-000094:mdna:57]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 375 |  |
| 2023 |  | 1,197 |  |
| 2024 |  | 822 |  |
| 2025 |  | 485 |  |
| 2026 |  | 114 |  |
| Total |  | $ | 2,993 |  |

[0001730168-22-000094:mdna:58]
[same as prior period, unchanged from 0001730168-22-000081:mdna:58]

[0001730168-22-000094:mdna:59]
[same as prior period, unchanged from 0001730168-22-000081:mdna:59]

[0001730168-22-000094:mdna:60]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Three Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | July 31,2022 |  | August 1,2021 |  | $ Change |  | % Change |  | July 31, 2022 |  | August 1, 2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 3,916 |  |  | $ | 2,720 |  |  | $ | 1,196 |  |  | 44 | % |  | $ | 10,891 |  |  | $ | 7,828 |  |  | $ | 3,063 |  |  | 39 | % |
| Infrastructure software |  | 1,283 |  |  | 1,226 |  |  | 57 |  |  | 5 | % |  | 3,903 |  |  | 3,700 |  |  | 203 |  |  | 5 | % |
| Unallocated expenses |  | (1,462) |  |  | (1,820) |  |  | 358 |  |  | (20) | % |  | (4,555) |  |  | (5,590) |  |  | 1,035 |  |  | (19) | % |
| Total operating income |  | $ | 3,737 |  |  | $ | 2,126 |  |  | $ | 1,611 |  |  | 76 | % |  | $ | 10,239 |  |  | $ | 5,938 |  |  | $ | 4,301 |  |  | 72 | % |

[0001730168-22-000094:mdna:61]
Operating income from our semiconductor solutions segment increased in the fiscal quarter and three fiscal quarters ended July 31, 2022 compared to the prior year fiscal periods, primarily due to higher net revenue from networking, server storage, broadband, and wireless products, as well as higher gross margin. Operating income from our infrastructure software segment increased in the fiscal quarter and three fiscal quarters ended July 31, 2022 compared to the prior year fiscal periods, primarily due to higher demand for our mainframe solutions and FC SAN products.

[0001730168-22-000094:mdna:62]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 20% and 19% for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the prior year fiscal periods primarily due to lower amortization of acquisition-related intangible assets.

[0001730168-22-000094:mdna:63]
[same as prior period, unchanged from 0001730168-22-000081:mdna:63]

[0001730168-22-000094:mdna:64]
Interest expense. Interest expense was $406 million and $1,331 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to $415 million and $1,451 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. The decrease in the fiscal quarter ended July 31, 2022 was primarily due to the September 2021 debt transactions, resulting in overall lower interest rates in the current year fiscal period. The decrease in three fiscal quarters ended July 31, 2022 was primarily due to lower losses on extinguishment of debt. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the pending VMware Merger.

[0001730168-22-000094:mdna:65]
Other income (expense), net. Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $6 million and other expense, net was $94 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to other income, net of $15 million and $109 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. The changes were primarily due to changes in investment gains or losses.

[0001730168-22-000094:mdna:66]
Provision for (benefit from) income taxes. The provision for income taxes was $263 million and $678 million for the fiscal quarter and three fiscal quarters ended July 31, 2022, respectively, compared to the benefit from income taxes of $150 million and $151 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively. The provision for income taxes in the current year fiscal periods was primarily driven by income before income taxes, offset by a shift in jurisdictional mix of income and expenses, and excess tax benefits from stock-based awards. The benefit from income taxes for the fiscal quarter ended August 1, 2021 was primarily due to excess tax benefits from stock-based awards, the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, and a shift in jurisdictional mix of income and expenses, offset in part by income tax expense on operations. The benefit from income taxes for the three fiscal quarters ended August 1, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, offset in part by income tax expense on operations.

[0001730168-22-000094:mdna:67]
[same as prior period, unchanged from 0001730168-22-000081:mdna:67]

[0001730168-22-000094:mdna:68]
[same as prior period, unchanged from 0001730168-22-000081:mdna:68]

[0001730168-22-000094:mdna:69]
Our primary sources of liquidity as of July 31, 2022 consisted of: (i) $9,977 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-22-000094:mdna:70]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including the pending VMware Merger, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $41,227 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be consistent in fiscal year 2022 as compared to fiscal year 2021. Our debt and liquidity needs will increase as a result of the pending VMware Merger, and we intend to fund the cash portion of the consideration with $32 billion in new, fully committed debt financing.

[0001730168-22-000094:mdna:71]
We believe that our cash and cash equivalents on hand, cash flows from operations, the Revolving Facility, as well as the committed debt funding related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations and indebtedness, see Note 11. “Commitments and Contingencies” and Note 7. “Borrowings” in Part I, Item 1 of this Form 10-Q.

[0001730168-22-000094:mdna:72]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may also seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our

[0001730168-22-000094:mdna:73]
[same as prior period, unchanged from 0001730168-22-000081:mdna:93]

[0001730168-22-000094:mdna:74]
ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-22-000094:mdna:75]
[same as prior period, unchanged from 0001730168-22-000081:mdna:73]

[0001730168-22-000094:mdna:76]
[same as prior period, unchanged from 0001730168-22-000081:mdna:74]

[0001730168-22-000094:mdna:77]
Working capital decreased to $8,859 million at July 31, 2022 from $10,305 million at October 31, 2021. The decrease was primarily attributable to the following:

[0001730168-22-000094:mdna:78]
•Cash and cash equivalents decreased to $9,977 million at July 31, 2022 from $12,163 million at October 31, 2021, primarily due to $7,000 million of common stock repurchases, $5,250 million of dividend payments, $2,352 million of debt payments, and $1,181 million of employee withholding tax payments related to net settled equity awards. These decreases were partially offset by $12,153 million in net cash provided by operating activities and $1,935 million in proceeds from long-term borrowings.

[0001730168-22-000094:mdna:79]
•Other current liabilities increased to $4,607 million at July 31, 2022 from $3,839 million at October 31, 2021, primarily due to increases in contract liabilities and interest payable.

[0001730168-22-000094:mdna:80]
[same as prior period, unchanged from 0001730168-22-000081:mdna:80]

[0001730168-22-000094:mdna:81]
•Accounts receivable increased to $2,708 million at July 31, 2022 from $2,071 million at October 31, 2021, primarily due to revenue linearity and less receivables sold through factoring arrangements.

[0001730168-22-000094:mdna:82]
•Inventory increased to $1,838 million at July 31, 2022 from $1,297 million at October 31, 2021, primarily to support customer demand and due to higher material costs.

[0001730168-22-000094:mdna:83]
•Accounts payable decreased to $712 million at July 31, 2022 from $1,086 million at October 31, 2021, primarily due to the timing of vendor payments.

[0001730168-22-000094:mdna:84]
[same as prior period, unchanged from 0001730168-22-000081:mdna:84]

[0001730168-22-000094:mdna:85]
|  |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions, except per share data) |
| Cash dividends declared and paid per share to common stockholders |  | $ | 12.30 |  |  | $ | 10.80 |  |
| Cash dividends declared and paid to common stockholders |  | $ | 5,026 |  |  | $ | 4,427 |  |
| Cash dividends declared and paid per share to preferred stockholders |  | $ | 60.00 |  |  | $ | 60.00 |  |
| Cash dividends declared and paid to preferred stockholders |  | $ | 224 |  |  | $ | 224 |  |
| Stock repurchases |  | $ | 7,000 |  |  | $ | — |  |

[0001730168-22-000094:mdna:86]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. During the three fiscal quarters ended July 31, 2022, we repurchased and retired approximately 12 million shares of our common stock at a weighted average price of $595.96 under this stock repurchase program. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023.

[0001730168-22-000094:mdna:87]
Repurchases under our stock repurchase programs may be made through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-22-000094:mdna:88]
During the three fiscal quarters ended July 31, 2022 and August 1, 2021, we paid approximately $1,181 million and $1,033 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld over 2 million shares of common stock from employees in connection with such net share settlements during each of the three fiscal quarters ended July 31, 2022 and August 1, 2021.

[0001730168-22-000094:mdna:89]
31

[0001730168-22-000094:mdna:90]
[same as prior period, unchanged from 0001730168-22-000081:mdna:89]

[0001730168-22-000094:mdna:91]
|  |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | August 1,2021 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 12,153 |  |  | $ | 10,223 |  |
| Net cash used in investing activities |  | (539) |  |  | (295) |  |
| Net cash used in financing activities |  | (13,800) |  |  | (6,441) |  |
| Net change in cash and cash equivalents |  | $ | (2,186) |  |  | $ | 3,487 |  |

[0001730168-22-000094:mdna:92]
[same as prior period, unchanged from 0001730168-22-000081:mdna:91]

[0001730168-22-000094:mdna:93]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,930 million increase in cash provided by operations during the three fiscal quarters ended July 31, 2022 compared to the prior year fiscal period was primarily due to $3,389 million higher net income and certain non-cash adjustments including deferred taxes and other non-cash taxes and (gain) loss on investments, offset by a decrease in amortization of intangible assets and stock-based compensation, as well as a $1,507 million decrease resulting from changes in operating assets and liabilities.

[0001730168-22-000094:mdna:94]
[same as prior period, unchanged from 0001730168-22-000081:mdna:95]

[0001730168-22-000094:mdna:95]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures, and proceeds and payments related to investments. The $244 million increase in cash used in investing activities during the three fiscal quarters ended July 31, 2022 compared to the prior year fiscal period was primarily due to a $231 million increase in cash paid for acquisitions.

[0001730168-22-000094:mdna:96]
[same as prior period, unchanged from 0001730168-22-000081:mdna:97]

[0001730168-22-000094:mdna:97]
Cash flows from financing activities primarily consisted of our stock repurchases, dividend payments, proceeds and payments related to long-term borrowings, and employee withholding tax payments related to net settled equity awards. The $7,359 million increase in cash used in financing activities during the three fiscal quarters ended July 31, 2022 compared to the prior year fiscal period was primarily due to $7,000 million in common stock repurchases, a $599 million increase in dividend payments and a $148 million increase in employee withholding tax payments related to net settled equity awards, offset in part by a $412 million change in net borrowing activities.

[0001730168-22-000094:mdna:98]
[same as prior period, unchanged from 0001730168-22-000081:mdna:99]

[0001730168-22-000094:mdna:99]
[same as prior period, unchanged from 0001730168-22-000081:mdna:100]
