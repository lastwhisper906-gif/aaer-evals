# AVGO 8-K — 0001730168-22-000091 filed 2022-09-01

## item codes, every 8-K on or before 2022-09-08

- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2022-09-08

- none on or before 2022-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001730168-22-000091:8k_2_02:1]
EX-99.1
2
avgo-07312022x8kxex99.htm
EX-99.1

[0001730168-22-000091:8k_2_02:2]
Document

[0001730168-22-000091:8k_2_02:3]
Exhibit 99.1

[0001730168-22-000091:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2022 Financial Results and Quarterly Dividends

[0001730168-22-000091:8k_2_02:5]
•Cash from operations of $4,424 million for the third quarter, less capital expenditures of $116 million resulted in $4,308 million of free cash flow, or 51 percent of revenue

[0001730168-22-000091:8k_2_02:6]
•Quarterly common stock dividend of $4.10 per share, FY22 annual common stock dividend of $16.40 per share

[0001730168-22-000091:8k_2_02:7]
•Revenue of $8,464 million for the third quarter, up 25 percent from the prior year period

[0001730168-22-000091:8k_2_02:8]
•GAAP net income of $3,074 million for the third quarter; Adjusted EBITDA of $5,378 million for the third quarter

[0001730168-22-000091:8k_2_02:9]
•GAAP diluted EPS of $7.15 for the third quarter; Non-GAAP diluted EPS of $9.73 for the third quarter

[0001730168-22-000091:8k_2_02:10]
•Repurchased and eliminated 3.2 million shares for $1,792 million

[0001730168-22-000091:8k_2_02:11]
•Fourth quarter revenue guidance of approximately $8.9 billion, an increase of 20 percent from the prior year period

[0001730168-22-000091:8k_2_02:12]
•Fourth quarter Adjusted EBITDA guidance of approximately 63 percent of projected revenue (1)

[0001730168-22-000091:8k_2_02:13]
SAN JOSE, Calif. – September 1, 2022 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2022, ended July 31, 2022, provided guidance for the fourth quarter of its fiscal year 2022 and announced its quarterly dividends.

[0001730168-22-000091:8k_2_02:14]
“Broadcom’s record third quarter results were driven by robust demand across cloud, service providers, and enterprise,” said Hock Tan, President and CEO of Broadcom Inc. “We expect solid demand across our end markets to continue in the fourth quarter, reflecting continued investment by our customers of next generation technologies in data centers, broadband, and wireless.”

[0001730168-22-000091:8k_2_02:15]
“Consolidated revenue grew 25% year-over-year to $8.5 billion and operating profit increased 32%,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $4.3 billion in free cash flow and are expecting free cash flow to be strong in the fourth quarter. We remain committed to return excess cash to shareholders and in the third quarter, we returned $3.2 billion to shareholders including $1.7 billion of cash dividends and $1.5 billion of share repurchases.”

[0001730168-22-000091:8k_2_02:16]
Third Quarter Fiscal Year 2022 Financial Highlights

[0001730168-22-000091:8k_2_02:17]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q3 22 |  | Q3 21 |  | Change |  | Q3 22 |  | Q3 21 |  | Change |
| Net revenue |  | $ | 8,464 |  |  | $ | 6,778 |  |  | +25 | % |  | $ | 8,464 |  |  | $ | 6,778 |  |  | +25 | % |
| Net income |  | $ | 3,074 |  |  | $ | 1,876 |  |  | +$1,198 |  |  | $ | 4,241 |  |  | $ | 3,124 |  |  | +$1,117 |  |
| Earnings per common share - diluted |  | $ | 7.15 |  |  | $ | 4.20 |  |  | +$2.95 |  |  | $ | 9.73 |  |  | $ | 6.96 |  |  | +$2.77 |  |

[0001730168-22-000091:8k_2_02:18]
________________________________

[0001730168-22-000091:8k_2_02:19]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-22-000091:8k_2_02:20]
1

[0001730168-22-000091:8k_2_02:21]
| (Dollars in millions) |  | Q3 22 |  | Q3 21 |  | Change |  |
| Cash flow from operations |  | $ | 4,424 |  |  | $ | 3,541 |  |  | +$883 |  |
| Adjusted EBITDA |  | $ | 5,378 |  |  | $ | 4,123 |  |  | +$1,255 |  |
| Free cash flow |  | $ | 4,308 |  |  | $ | 3,426 |  |  | +$882 |  |

[0001730168-22-000091:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 22 |  |  |  | Q3 21 |  | Change |  |
| Semiconductor solutions |  | $ | 6,624 |  |  | 78 | % |  |  |  |  |  |  | $ | 5,021 |  |  | 74 | % |  | +32 | % |  |
| Infrastructure software |  | 1,840 |  |  | 22 |  |  |  |  |  |  |  | 1,757 |  |  | 26 |  |  | +5 | % |  |
| Total net revenue |  | $ | 8,464 |  |  | 100 | % |  |  |  |  |  |  | $ | 6,778 |  |  | 100 | % |  |  |  |  |

[0001730168-22-000091:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $9,977 million, compared to $9,005 million at the end of the prior quarter.

[0001730168-22-000091:8k_2_02:24]
During the third fiscal quarter, the Company generated $4,424 million in cash from operations and spent $116 million on capital expenditures. The Company spent $1,792 million on share repurchases and eliminations, consisting of $1,500 million in repurchases of 2.6 million shares and $292 million of withholding tax payments related to net settled equity awards that vested in the quarter (representing approximately 0.6 million shares withheld).

[0001730168-22-000091:8k_2_02:25]
On June 30, 2022, the Company paid a cash dividend of $4.10 per share of common stock, totaling $1,661 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-22-000091:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-22-000091:8k_2_02:27]
Fourth Quarter Fiscal Year 2022 Business Outlook

[0001730168-22-000091:8k_2_02:28]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2022, ending October 30, 2022, is expected to be as follows:

[0001730168-22-000091:8k_2_02:29]
•Fourth quarter revenue guidance of approximately $8.9 billion; and

[0001730168-22-000091:8k_2_02:30]
•Fourth quarter Adjusted EBITDA guidance of approximately 63 percent of projected revenue.

[0001730168-22-000091:8k_2_02:31]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000091:8k_2_02:32]
2

[0001730168-22-000091:8k_2_02:33]
Quarterly Dividends

[0001730168-22-000091:8k_2_02:34]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $4.10 per share. The common stock dividend is payable on September 30, 2022 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 22, 2022.

[0001730168-22-000091:8k_2_02:35]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on September 30, 2022 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 15, 2022.

[0001730168-22-000091:8k_2_02:36]
Financial Results Conference Call

[0001730168-22-000091:8k_2_02:37]
Broadcom Inc. will host a conference call to review its financial results for the third quarter fiscal year 2022 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-22-000091:8k_2_02:38]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-22-000091:8k_2_02:39]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BI4b942b6b1ed0474fab3f1f6f2d0f2b98. Upon registering, you will be emailed a link to the dial-in number and unique PIN.

[0001730168-22-000091:8k_2_02:40]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom's website at https://investors.broadcom.com/.

[0001730168-22-000091:8k_2_02:41]
Non-GAAP Financial Measures

[0001730168-22-000091:8k_2_02:42]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-22-000091:8k_2_02:43]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth

[0001730168-22-000091:8k_2_02:44]
3

[0001730168-22-000091:8k_2_02:45]
initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-22-000091:8k_2_02:46]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-22-000091:8k_2_02:47]
About Broadcom Inc.

[0001730168-22-000091:8k_2_02:48]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-22-000091:8k_2_02:49]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-22-000091:8k_2_02:50]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase programs; the COVID-19 pandemic continues to disrupt, normal business activity; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; failing to complete or realize the

[0001730168-22-000091:8k_2_02:51]
4

[0001730168-22-000091:8k_2_02:52]
expected benefits of our acquisition of VMware, Inc.; any acquisitions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to protect against cyber security threats and a breach of security systems; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-22-000091:8k_2_02:53]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000091:8k_2_02:54]
Contact:

[0001730168-22-000091:8k_2_02:55]
Ji Yoo

[0001730168-22-000091:8k_2_02:56]
Broadcom Inc.

[0001730168-22-000091:8k_2_02:57]
Investor Relations

[0001730168-22-000091:8k_2_02:58]
408-433-8000

[0001730168-22-000091:8k_2_02:59]
investor.relations@broadcom.com

[0001730168-22-000091:8k_2_02:60]
(AVGO-Q)

[0001730168-22-000091:8k_2_02:61]
BROADCOM INC.

[0001730168-22-000091:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-22-000091:8k_2_02:63]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-22-000091:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | May 1,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
| Net revenue |  | $ | 8,464 |  |  | $ | 8,103 |  |  | $ | 6,778 |  |  | $ | 24,273 |  |  | $ | 20,043 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 2,077 |  |  | 1,956 |  |  | 1,729 |  |  | 5,958 |  |  | 5,242 |  |
| Amortization of acquisition-related intangible assets |  | 705 |  |  | 707 |  |  | 851 |  |  | 2,142 |  |  | 2,578 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 17 |  |
| Total cost of revenue |  | 2,783 |  |  | 2,664 |  |  | 2,581 |  |  | 8,104 |  |  | 7,837 |  |
| Gross margin |  | 5,681 |  |  | 5,439 |  |  | 4,197 |  |  | 16,169 |  |  | 12,206 |  |
| Research and development |  | 1,255 |  |  | 1,261 |  |  | 1,205 |  |  | 3,722 |  |  | 3,654 |  |
| Selling, general and administrative |  | 323 |  |  | 368 |  |  | 346 |  |  | 1,012 |  |  | 1,010 |  |
| Amortization of acquisition-related intangible assets |  | 359 |  |  | 398 |  |  | 494 |  |  | 1,154 |  |  | 1,482 |  |
| Restructuring, impairment and disposal charges |  | 7 |  |  | 18 |  |  | 26 |  |  | 42 |  |  | 122 |  |
| Total operating expenses |  | 1,944 |  |  | 2,045 |  |  | 2,071 |  |  | 5,930 |  |  | 6,268 |  |
| Operating income |  | 3,737 |  |  | 3,394 |  |  | 2,126 |  |  | 10,239 |  |  | 5,938 |  |
| Interest expense |  | (406) |  |  | (518) |  |  | (415) |  |  | (1,331) |  |  | (1,451) |  |
| Other income (expense), net |  | 6 |  |  | (86) |  |  | 15 |  |  | (94) |  |  | 109 |  |
| Income before income taxes |  | 3,337 |  |  | 2,790 |  |  | 1,726 |  |  | 8,814 |  |  | 4,596 |  |
| Provision for (benefit from) income taxes |  | 263 |  |  | 200 |  |  | (150) |  |  | 678 |  |  | (151) |  |
| Net income |  | 3,074 |  |  | 2,590 |  |  | 1,876 |  |  | 8,136 |  |  | 4,747 |  |
| Dividends on preferred stock |  | (75) |  |  | (75) |  |  | (74) |  |  | (224) |  |  | (224) |  |
| Net income attributable to common stock |  | $ | 2,999 |  |  | $ | 2,515 |  |  | $ | 1,802 |  |  | $ | 7,912 |  |  | $ | 4,523 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 7.40 |  |  | $ | 6.16 |  |  | $ | 4.38 |  |  | $ | 19.39 |  |  | $ | 11.06 |  |
| Diluted (1) |  | $ | 7.15 |  |  | $ | 5.93 |  |  | $ | 4.20 |  |  | $ | 18.70 |  |  | $ | 10.54 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 405 |  |  | 408 |  |  | 411 |  |  | 408 |  |  | 409 |  |
| Diluted (1) |  | 430 |  |  | 424 |  |  | 429 |  |  | 435 |  |  | 429 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 37 |  |  | $ | 36 |  |  | $ | 36 |  |  | $ | 109 |  |  | $ | 106 |  |
| Research and development |  | 259 |  |  | 261 |  |  | 285 |  |  | 788 |  |  | 920 |  |
| Selling, general and administrative |  | 77 |  |  | 89 |  |  | 100 |  |  | 249 |  |  | 264 |  |
| Total stock-based compensation expense |  | $ | 373 |  |  | $ | 386 |  |  | $ | 421 |  |  | $ | 1,146 |  |  | $ | 1,290 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive for the fiscal quarters ended May 1, 2022 and August 1, 2021, and for the three fiscal quarters ended August 1, 2021. |

[0001730168-22-000091:8k_2_02:65]
BROADCOM INC.

[0001730168-22-000091:8k_2_02:66]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-22-000091:8k_2_02:67]
(IN MILLIONS)

[0001730168-22-000091:8k_2_02:68]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | May 1,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
| Gross margin on GAAP basis |  | $ | 5,681 |  |  | $ | 5,439 |  |  | $ | 4,197 |  |  | $ | 16,169 |  |  | $ | 12,206 |  |
| Amortization of acquisition-related intangible assets |  | 705 |  |  | 707 |  |  | 851 |  |  | 2,142 |  |  | 2,578 |  |
| Stock-based compensation expense |  | 37 |  |  | 36 |  |  | 36 |  |  | 109 |  |  | 106 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 17 |  |
| Acquisition-related costs |  | 3 |  |  | 3 |  |  | 3 |  |  | 10 |  |  | 9 |  |
| Gross margin on non-GAAP basis |  | $ | 6,427 |  |  | $ | 6,186 |  |  | $ | 5,088 |  |  | $ | 18,434 |  |  | $ | 14,916 |  |
| Research and development on GAAP basis |  | $ | 1,255 |  |  | $ | 1,261 |  |  | $ | 1,205 |  |  | $ | 3,722 |  |  | $ | 3,654 |  |
| Stock-based compensation expense |  | 259 |  |  | 261 |  |  | 285 |  |  | 788 |  |  | 920 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 996 |  |  | $ | 1,000 |  |  | $ | 919 |  |  | $ | 2,934 |  |  | $ | 2,731 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 323 |  |  | $ | 368 |  |  | $ | 346 |  |  | $ | 1,012 |  |  | $ | 1,010 |  |
| Stock-based compensation expense |  | 77 |  |  | 89 |  |  | 100 |  |  | 249 |  |  | 264 |  |
| Acquisition-related costs |  | 14 |  |  | 32 |  |  | 22 |  |  | 57 |  |  | 88 |  |
| Litigation settlements |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 232 |  |  | $ | 247 |  |  | $ | 223 |  |  | $ | 706 |  |  | $ | 657 |  |
| Total operating expenses on GAAP basis |  | $ | 1,944 |  |  | $ | 2,045 |  |  | $ | 2,071 |  |  | $ | 5,930 |  |  | $ | 6,268 |  |
| Amortization of acquisition-related intangible assets |  | 359 |  |  | 398 |  |  | 494 |  |  | 1,154 |  |  | 1,482 |  |
| Stock-based compensation expense |  | 336 |  |  | 350 |  |  | 385 |  |  | 1,037 |  |  | 1,184 |  |
| Restructuring, impairment and disposal charges |  | 7 |  |  | 18 |  |  | 26 |  |  | 42 |  |  | 122 |  |
| Litigation settlements |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 14 |  |  | 32 |  |  | 23 |  |  | 57 |  |  | 91 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,228 |  |  | $ | 1,247 |  |  | $ | 1,142 |  |  | $ | 3,640 |  |  | $ | 3,388 |  |
| Operating income on GAAP basis |  | $ | 3,737 |  |  | $ | 3,394 |  |  | $ | 2,126 |  |  | $ | 10,239 |  |  | $ | 5,938 |  |
| Amortization of acquisition-related intangible assets |  | 1,064 |  |  | 1,105 |  |  | 1,345 |  |  | 3,296 |  |  | 4,060 |  |
| Stock-based compensation expense |  | 373 |  |  | 386 |  |  | 421 |  |  | 1,146 |  |  | 1,290 |  |
| Restructuring, impairment and disposal charges |  | 8 |  |  | 19 |  |  | 27 |  |  | 46 |  |  | 139 |  |
| Litigation settlements |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 17 |  |  | 35 |  |  | 26 |  |  | 67 |  |  | 100 |  |
| Operating income on non-GAAP basis |  | $ | 5,199 |  |  | $ | 4,939 |  |  | $ | 3,946 |  |  | $ | 14,794 |  |  | $ | 11,528 |  |
| Interest expense on GAAP basis |  | $ | (406) |  |  | $ | (518) |  |  | $ | (415) |  |  | $ | (1,331) |  |  | $ | (1,451) |  |
| Loss on debt extinguishment |  | — |  |  | 112 |  |  | — |  |  | 112 |  |  | 222 |  |
| Interest expense on non-GAAP basis |  | $ | (406) |  |  | $ | (406) |  |  | $ | (415) |  |  | $ | (1,219) |  |  | $ | (1,229) |  |
| Other income (expense), net on GAAP basis |  | $ | 6 |  |  | $ | (86) |  |  | $ | 15 |  |  | $ | (94) |  |  | $ | 109 |  |
| (Gains) losses on investments |  | 25 |  |  | 99 |  |  | 4 |  |  | 140 |  |  | (90) |  |
| Other |  | (5) |  |  | — |  |  | — |  |  | (5) |  |  | (3) |  |
| Other income, net on non-GAAP basis |  | $ | 26 |  |  | $ | 13 |  |  | $ | 19 |  |  | $ | 41 |  |  | $ | 16 |  |

[0001730168-22-000091:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | May 1,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 263 |  |  | $ | 200 |  |  | $ | (150) |  |  | $ | 678 |  |  | $ | (151) |  |
| Non-GAAP tax reconciling adjustments |  | 315 |  |  | 346 |  |  | 576 |  |  | 956 |  |  | 1,389 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 578 |  |  | $ | 546 |  |  | $ | 426 |  |  | $ | 1,634 |  |  | $ | 1,238 |  |
| Net income on GAAP basis |  | $ | 3,074 |  |  | $ | 2,590 |  |  | $ | 1,876 |  |  | $ | 8,136 |  |  | $ | 4,747 |  |
| Amortization of acquisition-related intangible assets |  | 1,064 |  |  | 1,105 |  |  | 1,345 |  |  | 3,296 |  |  | 4,060 |  |
| Stock-based compensation expense |  | 373 |  |  | 386 |  |  | 421 |  |  | 1,146 |  |  | 1,290 |  |
| Restructuring, impairment and disposal charges |  | 8 |  |  | 19 |  |  | 27 |  |  | 46 |  |  | 139 |  |
| Litigation settlements |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 17 |  |  | 35 |  |  | 26 |  |  | 67 |  |  | 100 |  |
| Loss on debt extinguishment |  | — |  |  | 112 |  |  | — |  |  | 112 |  |  | 222 |  |
| (Gains) losses on investments |  | 25 |  |  | 99 |  |  | 4 |  |  | 140 |  |  | (90) |  |
| Other |  | (5) |  |  | — |  |  | — |  |  | (5) |  |  | (3) |  |
| Non-GAAP tax reconciling adjustments |  | (315) |  |  | (346) |  |  | (576) |  |  | (956) |  |  | (1,389) |  |
| Net income on non-GAAP basis |  | $ | 4,241 |  |  | $ | 4,000 |  |  | $ | 3,124 |  |  | $ | 11,982 |  |  | $ | 9,077 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 430 |  |  | 424 |  |  | 429 |  |  | 435 |  |  | 429 |  |
| Non-GAAP adjustment (1) |  | 6 |  |  | 17 |  |  | 20 |  |  | 6 |  |  | 20 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 436 |  |  | 441 |  |  | 449 |  |  | 441 |  |  | 449 |  |
| Net income on non-GAAP basis |  | $ | 4,241 |  |  | $ | 4,000 |  |  | $ | 3,124 |  |  | $ | 11,982 |  |  | $ | 9,077 |  |
| Interest expense on non-GAAP basis |  | 406 |  |  | 406 |  |  | 415 |  |  | 1,219 |  |  | 1,229 |  |
| Provision for income taxes on non-GAAP basis |  | 578 |  |  | 546 |  |  | 426 |  |  | 1,634 |  |  | 1,238 |  |
| Depreciation |  | 129 |  |  | 135 |  |  | 134 |  |  | 400 |  |  | 405 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 24 |  |  | 24 |  |  | 72 |  |  | 75 |  |
| Adjusted EBITDA |  | $ | 5,378 |  |  | $ | 5,111 |  |  | $ | 4,123 |  |  | $ | 15,307 |  |  | $ | 12,024 |  |
| Net cash provided by operating activities |  | $ | 4,424 |  |  | $ | 4,243 |  |  | $ | 3,541 |  |  | $ | 12,153 |  |  | $ | 10,223 |  |
| Purchases of property, plant and equipment |  | (116) |  |  | (85) |  |  | (115) |  |  | (302) |  |  | (355) |  |
| Free cash flow |  | $ | 4,308 |  |  | $ | 4,158 |  |  | $ | 3,426 |  |  | $ | 11,851 |  |  | $ | 9,868 |  |

[0001730168-22-000091:8k_2_02:70]
|  |  | Fiscal Quarter Ending |
|  |  | October 30, |
| Expected average diluted share count (2): |  | 2022 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 429 |  |
| Non-GAAP adjustment (1) |  | 6 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 435 |  |

[0001730168-22-000091:8k_2_02:71]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis for the fiscal quarters ended May 1, 2022 and August 1, 2021, and for the three fiscal quarters ended August 1, 2021. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-22-000091:8k_2_02:72]
BROADCOM INC.

[0001730168-22-000091:8k_2_02:73]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-22-000091:8k_2_02:74]
(IN MILLIONS)

[0001730168-22-000091:8k_2_02:75]
|  |  | July 31,2022 |  | October 31,2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,977 |  |  | $ | 12,163 |  |
| Trade accounts receivable, net |  | 2,708 |  |  | 2,071 |  |
| Inventory |  | 1,838 |  |  | 1,297 |  |
| Other current assets |  | 1,038 |  |  | 1,055 |  |
| Total current assets |  | 15,561 |  |  | 16,586 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,250 |  |  | 2,348 |  |
| Goodwill |  | 43,608 |  |  | 43,450 |  |
| Intangible assets, net |  | 8,174 |  |  | 11,374 |  |
| Other long-term assets |  | 1,733 |  |  | 1,812 |  |
| Total assets |  | $ | 71,326 |  |  | $ | 75,570 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 712 |  |  | $ | 1,086 |  |
| Employee compensation and benefits |  | 1,079 |  |  | 1,066 |  |
| Current portion of long-term debt |  | 304 |  |  | 290 |  |
| Other current liabilities |  | 4,607 |  |  | 3,839 |  |
| Total current liabilities |  | 6,702 |  |  | 6,281 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 39,191 |  |  | 39,440 |  |
| Other long-term liabilities |  | 4,530 |  |  | 4,860 |  |
| Total liabilities |  | 50,423 |  |  | 50,581 |  |
| Preferred stock dividend obligation |  | 27 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 20,990 |  |  | 24,330 |  |
| Retained earnings |  | — |  |  | 748 |  |
| Accumulated other comprehensive loss |  | (114) |  |  | (116) |  |
| Total stockholders' equity |  | 20,876 |  |  | 24,962 |  |
| Total liabilities and equity |  | $ | 71,326 |  |  | $ | 75,570 |  |

[0001730168-22-000091:8k_2_02:76]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | July 31,2022 |  | May 1,2022 |  | August 1,2021 |  | July 31,2022 |  | August 1,2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,074 |  |  | $ | 2,590 |  |  | $ | 1,876 |  |  | $ | 8,136 |  |  | $ | 4,747 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,088 |  |  | 1,129 |  |  | 1,369 |  |  | 3,368 |  |  | 4,135 |  |
| Depreciation |  | 129 |  |  | 135 |  |  | 134 |  |  | 400 |  |  | 405 |  |
| Stock-based compensation |  | 373 |  |  | 386 |  |  | 421 |  |  | 1,146 |  |  | 1,290 |  |
| Deferred taxes and other non-cash taxes |  | (15) |  |  | — |  |  | (436) |  |  | 55 |  |  | (762) |  |
| Loss on debt extinguishment |  | — |  |  | 100 |  |  | — |  |  | 100 |  |  | 198 |  |
| (Gains) losses on investments |  | 25 |  |  | 99 |  |  | 4 |  |  | 140 |  |  | (90) |  |
| Non-cash interest expense |  | 32 |  |  | 33 |  |  | 24 |  |  | 97 |  |  | 67 |  |
| Other |  | 2 |  |  | 11 |  |  | 8 |  |  | 12 |  |  | 27 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 375 |  |  | (536) |  |  | 191 |  |  | (629) |  |  | 50 |  |
| Inventory |  | (170) |  |  | (147) |  |  | (156) |  |  | (540) |  |  | (157) |  |
| Accounts payable |  | (352) |  |  | (31) |  |  | 156 |  |  | (383) |  |  | 142 |  |
| Employee compensation and benefits |  | 321 |  |  | 215 |  |  | 254 |  |  | 8 |  |  | 14 |  |
| Other current assets and current liabilities |  | (198) |  |  | 287 |  |  | (227) |  |  | 610 |  |  | 363 |  |
| Other long-term assets and long-term liabilities |  | (260) |  |  | (28) |  |  | (77) |  |  | (367) |  |  | (206) |  |
| Net cash provided by operating activities |  | 4,424 |  |  | 4,243 |  |  | 3,541 |  |  | 12,153 |  |  | 10,223 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (5) |  |  | (225) |  |  | — |  |  | (239) |  |  | (8) |  |
| Purchases of property, plant and equipment |  | (116) |  |  | (85) |  |  | (115) |  |  | (302) |  |  | (355) |  |
| Purchases of investments |  | — |  |  | — |  |  | — |  |  | (200) |  |  | — |  |
| Sales of investments |  | 200 |  |  | — |  |  | 67 |  |  | 200 |  |  | 67 |  |
| Other |  | 1 |  |  | — |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Net cash provided by (used in) investing activities |  | 80 |  |  | (310) |  |  | (47) |  |  | (539) |  |  | (295) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | 1,935 |  |  | — |  |  | 1,935 |  |  | 9,904 |  |
| Payments on debt obligations |  | — |  |  | (2,097) |  |  | — |  |  | (2,352) |  |  | (10,733) |  |
| Payments of dividends |  | (1,736) |  |  | (1,750) |  |  | (1,556) |  |  | (5,250) |  |  | (4,651) |  |
| Repurchases of common stock - repurchase program |  | (1,500) |  |  | (2,776) |  |  | — |  |  | (7,000) |  |  | — |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (292) |  |  | (514) |  |  | (347) |  |  | (1,181) |  |  | (1,033) |  |
| Issuance of common stock |  | — |  |  | 59 |  |  | 7 |  |  | 60 |  |  | 113 |  |
| Other |  | (4) |  |  | (4) |  |  | (11) |  |  | (12) |  |  | (41) |  |
| Net cash used in financing activities |  | (3,532) |  |  | (5,147) |  |  | (1,907) |  |  | (13,800) |  |  | (6,441) |  |
| Net change in cash and cash equivalents |  | 972 |  |  | (1,214) |  |  | 1,587 |  |  | (2,186) |  |  | 3,487 |  |
| Cash and cash equivalents at beginning of period |  | 9,005 |  |  | 10,219 |  |  | 9,518 |  |  | 12,163 |  |  | 7,618 |  |
| Cash and cash equivalents at end of period |  | $ | 9,977 |  |  | $ | 9,005 |  |  | $ | 11,105 |  |  | $ | 9,977 |  |  | $ | 11,105 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 290 |  |  | $ | 459 |  |  | $ | 253 |  |  | $ | 989 |  |  | $ | 994 |  |
| Cash paid for income taxes |  | $ | 231 |  |  | $ | 240 |  |  | $ | 167 |  |  | $ | 657 |  |  | $ | 607 |  |
