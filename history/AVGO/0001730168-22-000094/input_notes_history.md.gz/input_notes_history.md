# AVGO note change history — 0001730168-22-000081 → 0001730168-22-000094


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:1]
The following table summarizes contractual obligations and commitments as of July 31, 2022 that materially changed from the end of fiscal year 2021:
  (was, 2022-06-09, similarity 0.9821):
[0001730168-22-000081:note_history:1]
The following table summarizes contractual obligations and commitments as of May 1, 2022 that materially changed from the end of fiscal year 2021:

- changed (2022-09-08):
[0001730168-22-000094:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 42 |  |  | $ | 554 |  |
| 2023 |  | 178 |  |  | 185 |  |
| 2024 |  | 159 |  |  | 148 |  |
| 2025 |  | 79 |  |  | 36 |  |
| 2026 |  | 9 |  |  | 50 |  |
| Thereafter |  | 7 |  |  | 1 |  |
| Total |  | $ | 474 |  |  | $ | 974 |  |
  (was, 2022-06-09, similarity 0.839):
[0001730168-22-000081:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2022 (remainder) |  | $ | 66 |  |  | $ | 609 |  |
| 2023 |  | 174 |  |  | 189 |  |
| 2024 |  | 130 |  |  | 131 |  |
| 2025 |  | 71 |  |  | 26 |  |
| 2026 |  | 2 |  |  | 48 |  |
| Thereafter |  | — |  |  | 1 |  |
| Total |  | $ | 443 |  |  | $ | 1,004 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at July 31, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,307 million of unrecognized tax benefits and accrued interest and penalties as of July 31, 2022 have been excluded from the table above.
  (was, 2022-06-09, similarity 0.987):
[0001730168-22-000081:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 1, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,339 million of unrecognized tax benefits and accrued interest and penalties as of May 1, 2022 have been excluded from the table above.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ended on May 1, 2022 and the third quarter ended on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.
  (was, 2022-06-09, similarity 0.9966):
[0001730168-22-000081:note_history:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 30, 2022 (“fiscal year 2022”) is a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ended on May 1, 2022 and the third quarter ends on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) was also a 52-week fiscal year.

- changed (2022-09-08):
[0001730168-22-000094:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for each of the fiscal quarter and three fiscal quarters ended July 31, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.
  (was, 2022-06-09, similarity 0.9947):
[0001730168-22-000081:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The October 31, 2021 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2021 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for each of the fiscal quarter and two fiscal quarters ended May 1, 2022 are not necessarily indicative of the results that may be expected for fiscal year 2022, or for any other future period.

- changed (2022-09-08):
[0001730168-22-000094:note_history:6]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. Due to the ongoing COVID-19 pandemic, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.
Recently Adopted Accounting Guidance. In October 2021, the Financial Accounting Standards Board issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not materially impact our condensed consolidated financial statements.
  (was, 2022-06-09, similarity 0.6951):
[0001730168-22-000081:note_history:6]
Use of estimates. The preparation of condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods. As the impact of the COVID-19 pandemic continues to develop, many of these estimates could require increased judgment and carry a higher degree of variability and volatility, and may change materially in future periods.

- removed (2022-09-08):
[0001730168-22-000081:note_history:7]
Recently Adopted Accounting Guidance
In October 2021, the Financial Accounting Standards Board issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted ASU 2021-08 at the beginning of fiscal year 2022 and it did not materially impact our condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:8]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
  (was, 2022-06-09, similarity 0.9988):
[0001730168-22-000081:note_history:8]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:9]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 35 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 304 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 26 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,793) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,191 |  |  | $ | 39,440 |  |
  (was, 2022-06-09, similarity 0.9979):
[0001730168-22-000081:note_history:9]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 33 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 302 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 29 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,823) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,164 |  |  | $ | 39,440 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:10]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either July 31, 2022 or October 31, 2021.
  (was, 2022-06-09, similarity 0.9718):
[0001730168-22-000081:note_history:10]
In January 2021, we entered into a credit agreement (the “Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either May 1, 2022 or October 31, 2021.

- changed (2022-09-08):
[0001730168-22-000094:note_history:11]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either July 31, 2022 or October 31, 2021.
  (was, 2022-06-09, similarity 0.997):
[0001730168-22-000081:note_history:11]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either May 1, 2022 or October 31, 2021.

- changed (2022-09-08):
[0001730168-22-000094:note_history:12]
As of July 31, 2022, the estimated aggregate fair value of debt was $37,003 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2022-06-09, similarity 0.9894):
[0001730168-22-000081:note_history:12]
As of May 1, 2022, the estimated aggregate fair value of debt was $36,521 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2022-09-08):
[0001730168-22-000094:note_history:13]
The future scheduled principal payments of debt as of July 31, 2022 were as follows:
  (was, 2022-06-09, similarity 0.9682):
[0001730168-22-000081:note_history:13]
The future scheduled principal payments of debt as of May 1, 2022 were as follows:

- changed (2022-09-08):
[0001730168-22-000094:note_history:14]
As of July 31, 2022 and October 31, 2021, we accrued interest payable of $415 million and $282 million, respectively, and were in compliance with all debt covenants.
  (was, 2022-06-09, similarity 0.9833):
[0001730168-22-000081:note_history:14]
As of May 1, 2022 and October 31, 2021, we accrued interest payable of $332 million and $282 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:15]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
  (was, 2022-06-09, similarity 0.9988):
[0001730168-22-000081:note_history:15]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:16]
|  |  | Effective Interest Rate |  | July 31,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 35 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 304 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 26 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,793) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,191 |  |  | $ | 39,440 |  |
  (was, 2022-06-09, similarity 0.9979):
[0001730168-22-000081:note_history:16]
|  |  | Effective Interest Rate |  | May 1,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,227 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 269 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 33 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 302 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,958 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 29 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,823) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,164 |  |  | $ | 39,440 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:17]
The future scheduled principal payments of debt as of July 31, 2022 were as follows:
  (was, 2022-06-09, similarity 0.9682):
[0001730168-22-000081:note_history:17]
The future scheduled principal payments of debt as of May 1, 2022 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:18]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |
  (was, 2022-06-09, similarity 0.9924):
[0001730168-22-000081:note_history:18]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:19]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |
  (was, 2022-06-09, similarity 0.9863):
[0001730168-22-000081:note_history:19]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:20]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |
  (was, 2022-06-09, similarity 0.9835):
[0001730168-22-000081:note_history:20]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:21]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |
  (was, 2022-06-09, similarity 0.9776):
[0001730168-22-000081:note_history:21]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:22]
|  |  | Fiscal Quarter Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 645 |  |  | $ | 5,500 |  |  | $ | 482 |  |  | $ | 6,627 |  |
| Subscriptions and services (a) |  | 1,117 |  |  | 345 |  |  | 375 |  |  | 1,837 |  |
| Total |  | $ | 1,762 |  |  | $ | 5,845 |  |  | $ | 857 |  |  | $ | 8,464 |  |
  (was, 2022-06-09, similarity 0.9924):
[0001730168-22-000081:note_history:22]
|  |  | Fiscal Quarter Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 658 |  |  | $ | 5,260 |  |  | $ | 499 |  |  | $ | 6,417 |  |
| Subscriptions and services (a) |  | 1,154 |  |  | 125 |  |  | 407 |  |  | 1,686 |  |
| Total |  | $ | 1,812 |  |  | $ | 5,385 |  |  | $ | 906 |  |  | $ | 8,103 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:23]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |
  (was, 2022-06-09, similarity 0.9863):
[0001730168-22-000081:note_history:23]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:24]
|  |  | Three Fiscal Quarters Ended July 31, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,851 |  |  | $ | 15,744 |  |  | $ | 1,502 |  |  | $ | 19,097 |  |
| Subscriptions and services (a) |  | 3,380 |  |  | 598 |  |  | 1,198 |  |  | 5,176 |  |
| Total |  | $ | 5,231 |  |  | $ | 16,342 |  |  | $ | 2,700 |  |  | $ | 24,273 |  |
  (was, 2022-06-09, similarity 0.9835):
[0001730168-22-000081:note_history:24]
|  |  | Two Fiscal Quarters Ended May 1, 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,206 |  |  | $ | 10,244 |  |  | $ | 1,020 |  |  | $ | 12,470 |  |
| Subscriptions and services (a) |  | 2,263 |  |  | 253 |  |  | 823 |  |  | 3,339 |  |
| Total |  | $ | 3,469 |  |  | $ | 10,497 |  |  | $ | 1,843 |  |  | $ | 15,809 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:25]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |
  (was, 2022-06-09, similarity 0.9776):
[0001730168-22-000081:note_history:25]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:26]
|  |  | July 31,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 77 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,740 |  |  | $ | 3,185 |  |
  (was, 2022-06-09, similarity 0.9822):
[0001730168-22-000081:note_history:26]
|  |  | May 1,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 79 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 4,099 |  |  | $ | 3,185 |  |

- changed (2022-09-08):
[0001730168-22-000094:note_history:27]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended July 31, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $2,482 million. The amount of revenue recognized during the three fiscal quarters ended August 1, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,330 million.
  (was, 2022-06-09, similarity 0.9899):
[0001730168-22-000081:note_history:27]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 1, 2022 that was included in the contract liabilities balance as of October 31, 2021 was $1,974 million. The amount of revenue recognized during the two fiscal quarters ended May 2, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,853 million.

- changed (2022-09-08):
[0001730168-22-000094:note_history:28]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of July 31, 2022 were approximately $25.2 billion. We expect approximately 24% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2022-06-09, similarity 0.9965):
[0001730168-22-000081:note_history:28]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of May 1, 2022 were approximately $16.5 billion. We expect approximately 31% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-09-08):
[0001730168-22-000094:note_history:29]
On August 31, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2022 to stockholders of record on September 15, 2022.
  (was, 2022-06-09, similarity 0.9254):
[0001730168-22-000081:note_history:29]
On May 25, 2022, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2022 to stockholders of record on June 15, 2022.

- changed (2022-09-08):
[0001730168-22-000094:note_history:30]
On August 31, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on September 30, 2022 to stockholders of record on September 22, 2022.
  (was, 2022-06-09, similarity 0.9145):
[0001730168-22-000081:note_history:30]
On May 25, 2022, our Board of Directors declared a quarterly cash dividend of $4.10 per share on our common stock, payable on June 30, 2022 to stockholders of record on June 22, 2022.

- removed (2022-09-08):
[0001730168-22-000081:note_history:31]
Pending Acquisition of VMware, Inc.

- removed (2022-09-08):
[0001730168-22-000081:note_history:32]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. In addition, we will assume $8 billion of VMware net debt.

- removed (2022-09-08):
[0001730168-22-000081:note_history:33]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

- removed (2022-09-08):
[0001730168-22-000081:note_history:34]
We will assume all outstanding VMware restricted stock unit awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into restricted stock unit awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and restricted stock unit awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

- removed (2022-09-08):
[0001730168-22-000081:note_history:35]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

- removed (2022-09-08):
[0001730168-22-000081:note_history:36]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

- removed (2022-09-08):
[0001730168-22-000081:note_history:37]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023, is subject to satisfaction or waiver of customary closing conditions, including adoption of the VMware Merger Agreement by VMware stockholders, the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976, and clearance under the antitrust laws of the European Union and certain other jurisdictions, and the effectiveness of a registration statement on Form S-4 to be filed by us. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion (or, in certain circumstances, VMware’s termination fee would be $750 million).
