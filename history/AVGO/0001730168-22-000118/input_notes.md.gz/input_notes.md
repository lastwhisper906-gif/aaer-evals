# AVGO notes — 0001730168-22-000118


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001730168-22-000118:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2023 Annual Meeting of Stockholders are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001730168-22-000118:notes:2]
Overview and Basis of Presentation 
Overview

[0001730168-22-000118:notes:3]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.

[0001730168-22-000118:notes:4]
Basis of Presentation

[0001730168-22-000118:notes:5]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ended October 30, 2022 (“fiscal year 2022”) was a 52-week fiscal year. The first quarter of our fiscal year 2022 ended on January 30, 2022, the second quarter ended on May 1, 2022 and the third quarter ended on July 31, 2022. Our fiscal year ended October 31, 2021 (“fiscal year 2021”) and fiscal year ended November 1, 2020 (“fiscal year 2020”) were both 52-week fiscal years.

[0001730168-22-000118:notes:6]
On November 4, 2019, we completed the purchase of certain assets and assumption of certain liabilities of the Symantec Corporation Enterprise Security business (the “Symantec Business”). We have two reportable segments: semiconductor solutions and infrastructure software. See Note 13. “Segment Information” for additional information.

[0001730168-22-000118:notes:7]
The accompanying consolidated financial statements include the accounts of Broadcom and its subsidiaries and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”). All intercompany balances and transactions have been eliminated in consolidation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001730168-22-000118:notes:8]
Summary of Significant Accounting Policies 
Foreign currency remeasurement.  We operate in a U.S. dollar functional currency environment. Foreign currency assets and liabilities for monetary accounts are remeasured into U.S. dollars at current exchange rates. Non-monetary items such as inventory and property, plant and equipment, are measured and recorded at historical exchange rates. The effects of foreign currency remeasurement were not material for any period presented.

[0001730168-22-000118:notes:9]
Use of estimates.  The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The inputs into certain of these estimates and assumptions include the consideration of the economic impact of the COVID-19 pandemic, and many of these estimates could require increased judgment and carry a higher degree of variability and volatility. Actual results could differ materially from these estimates, and such differences could affect the results of operations reported in future periods.

[0001730168-22-000118:notes:10]
Cash and cash equivalents.  We consider all highly liquid investment securities with original maturities of three months or less at the date of purchase to be cash equivalents. We determine the appropriate classification of our cash and cash equivalents at the time of purchase.

[0001730168-22-000118:notes:11]
Trade accounts receivable, net.  Trade accounts receivable are recognized at the invoiced amount and do not bear interest. Accounts receivable are reduced by an allowance for doubtful accounts, which is our best estimate of the expected credit losses in our existing accounts receivable. We determine the allowance based on historical experience, current economic conditions and certain forward-looking information, among other factors. Allowances for doubtful accounts were not material as of October 30, 2022 or October 31, 2021. Accounts receivable are also recognized net of sales returns and distributor credit allowances. These amounts are recognized when it is both probable and estimable that discounts will be granted or products will be returned. Allowances for sales returns and distributor credit allowances as of October 30, 2022 and October 31, 2021 were $126 million and $129 million, respectively.

[0001730168-22-000118:notes:12]
Concentrations of credit risk and significant customers.  Our cash, cash equivalents and accounts receivable are potentially subject to concentration of credit risk. Cash and cash equivalents may be redeemable upon demand and are maintained with financial institutions that management believes are of high credit quality and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profile of these counterparties. Our accounts receivable are derived from revenue earned from customers located both within and outside the U.S. We mitigate collection risks from our customers by performing regular credit evaluations of our customers’ financial conditions, and require collateral, such as letters of credit and bank guarantees, in certain circumstances.

[0001730168-22-000118:notes:13]
Concentration of other risks.  We operate in markets that are highly competitive and rapidly changing. Significant technological changes, shifting customer needs, the emergence of competitive products with new capabilities, general economic conditions worldwide, the ability to safeguard patents and other intellectual property (“IP”) in a rapidly evolving market and reliance on assembly and test subcontractors, third-party wafer fabricators and independent distributors and other factors could affect our financial results.

[0001730168-22-000118:notes:14]
Inventory.  We value our inventory at the lower of actual cost or net realizable value of the inventory, with cost being determined under the first-in, first-out method. We record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. The excess and obsolete balance determined by this analysis becomes the basis for our excess and obsolete inventory charge and the written-down value of the inventory becomes its new cost basis.

[0001730168-22-000118:notes:15]
Retirement benefit plans. For defined benefit pension plans, we consider various factors in determining our respective benefit obligations and net periodic benefit (income) cost, including the number of employees that we expect to receive benefits, their salary levels and years of service, the expected return on plan assets, the discount rate, the timing of the payment of benefits, and other actuarial assumptions. If the actual results and events of the benefit plans differ from our current assumptions, the benefit obligations may be over- or under-valued.

[0001730168-22-000118:notes:16]
The key assumptions are the discount rate and the expected rate of return on plan assets. The U.S. discount rates are based on a hypothetical yield curve constructed using high-quality corporate bonds selected to yield cash flows that match the expected timing and amount of the benefit payments. The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy. We evaluate these assumptions at least annually. For the non-U.S. plans, we set assumptions specific to each country. We have elected to measure defined benefit pension plan assets and liabilities as of October 31, which is the month end that is closest to our fiscal year end.

[0001730168-22-000118:notes:17]
Derivative instruments.  We use derivative financial instruments to manage exposure to foreign exchange risk and interest rate risk. We do not use derivative financial instruments for speculative or trading purposes.

[0001730168-22-000118:notes:18]
Outstanding derivatives are recognized as assets or liabilities at their fair values based on Level 2 inputs, as defined in the fair value hierarchy. For derivative instruments designated as cash flow hedges, the changes in fair value are initially recognized in other comprehensive income (loss), net of tax in the period of change, and are subsequently reclassified and recognized in the same line item as the hedged item when either the hedged transactions affect earnings or it becomes probable that the hedged transactions will not occur.

[0001730168-22-000118:notes:19]
We use foreign exchange forward contracts to manage exposure to foreign exchange risk. These forward contracts are not designated as hedging instruments, and the changes in fair value are recognized in other income (expense), net in the period of change. We did not have any outstanding foreign exchange forward contracts as of October 30, 2022 or October 31, 2021. The gains and losses recorded in other income (expense), net for derivative instruments not designated as hedges were not material.

[0001730168-22-000118:notes:20]
During fiscal year 2022, we entered into treasury rate lock contracts that mature in approximately one year to hedge variability of cash flows due to changes in the benchmark interest rate of anticipated future debt issuances. These treasury rate locks are designated and accounted for as cash flow hedging instruments. As of October 30, 2022, the total notional amount of these contracts was $1.3 billion, and the fair value of these contracts was $47 million, which was recorded as a derivative asset with the gains recorded net of tax as a component of accumulated other comprehensive loss on our consolidated balance sheet.

[0001730168-22-000118:notes:21]
Property, plant and equipment.  Property, plant and equipment are stated at cost less accumulated depreciation and amortization. Additions, improvements and major renewals are capitalized, and maintenance, repairs and minor renewals are expensed as incurred. Assets are held in construction in progress until placed in service, upon which date, we begin to depreciate these assets. When assets are retired or disposed of, the assets and related accumulated depreciation and amortization are removed from our property, plant and equipment balances and the resulting gain or loss is reflected in the consolidated statements of operations. Buildings and leasehold improvements are generally depreciated over 15 to 40 years,

[0001730168-22-000118:notes:22]
or over the lease period, whichever is shorter, and machinery and equipment are generally depreciated over 3 to 10 years. We use the straight-line method of depreciation for all property, plant and equipment.

[0001730168-22-000118:notes:23]
Leases.  We determine if an arrangement is a lease, or contains a lease, at the inception of the arrangement and evaluate whether the lease is an operating lease or a finance lease at the commencement date. We recognize right-of-use (“ROU”) assets and lease liabilities for operating and finance leases with terms greater than 12 months, and account for the lease and non-lease components as a single component. ROU assets represent our right to use an asset for the lease term, while lease liabilities represent our obligation to make lease payments. Operating and finance lease ROU assets and liabilities are recognized based on the present value of lease payments over the lease term at the lease commencement date. We use the implicit interest rate or, if not readily determinable, our incremental borrowing rate as of the lease commencement date to determine the present value of lease payments. The incremental borrowing rate is based on our unsecured borrowing rate, adjusted for the effects of collateral. Operating and finance lease ROU assets are recognized net of any lease prepayments and incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective-interest method over the lease term.

[0001730168-22-000118:notes:24]
Fair value measurement.  Fair value is defined as the price that would be received upon sale of an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. A three-level hierarchy is applied to prioritize the inputs to valuation techniques used to measure fair value. The hierarchy gives the highest priority to unadjusted quoted prices in active markets for identical assets or liabilities (Level 1 measurements) and the lowest priority to unobservable inputs (Level 3 measurements).

[0001730168-22-000118:notes:25]
The three levels of the fair value hierarchy under the guidance for fair value measurements are described below:

[0001730168-22-000118:notes:26]
Level 1 — Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities that the reporting entity has the ability to access at the measurement date. Our Level 1 assets include cash equivalents, banker's acceptances, trading securities investments and investment funds. We measure trading securities investments and investment funds at quoted market prices as they are traded in active markets with sufficient volume and frequency of transactions.

[0001730168-22-000118:notes:27]
Level 2 — Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly. If the asset or liability has a specified contractual term, a Level 2 input must be observable for substantially the full term of the asset or liability.

[0001730168-22-000118:notes:28]
Level 3 — Level 3 inputs are unobservable inputs for the asset or liability in which there is little, if any, market activity for the asset or liability at the measurement date. Level 3 assets and liabilities include investment in equity securities without readily determinable fair values, goodwill, intangible assets, and property, plant and equipment, which are measured at fair value using a discounted cash flow approach when they are impaired. Quantitative information for Level 3 assets and liabilities reviewed at each reporting period includes indicators of significant deterioration in the earnings performance, credit rating, asset quality, business prospects of the investee, and financial indicators of the investee's ability to continue as a going concern.

[0001730168-22-000118:notes:29]
Business combinations.  We account for business combinations under the acquisition method of accounting, which requires us to recognize separately from goodwill the assets acquired and the liabilities assumed at their acquisition date fair values. While we use our best estimates and assumptions to accurately value assets acquired and liabilities assumed at the acquisition date as well as contingent consideration, where applicable, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recognized in our consolidated statements of operations. Accounting for business combinations requires our management to make significant estimates and assumptions, especially at the acquisition date including our estimates for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain acquired intangible assets under the income approach include growth in future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp-up period, technology obsolescence rates, expected costs to develop in-process research and development (“IPR&D”) into commercially viable products, estimated cash flows from the projects when completed and discount rates. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-22-000118:notes:30]
Goodwill.  Goodwill represents the excess of purchase price and related costs over the value assigned to the net tangible and identifiable intangible assets of businesses acquired. Goodwill is not amortized but is reviewed annually (or more frequently if impairment indicators arise) for impairment. To review for impairment we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. Those factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value. If the fair value of the reporting unit is greater than its net book value, there is no impairment. Otherwise, we calculate the implied fair value of goodwill by deducting the fair value of all tangible and intangible assets, excluding goodwill, of the reporting unit from the fair value of the reporting unit. The implied fair value of goodwill is compared to the carrying value of goodwill. If the implied fair value of goodwill is less than the carrying value of goodwill, an impairment loss is recognized equal to the difference. Determining the fair value of a reporting unit involves the use of significant estimates and assumptions.

[0001730168-22-000118:notes:31]
Long-lived assets.  Purchased finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is recognized over the periods during which the intangible assets are expected to contribute to our cash flows. Purchased IPR&D projects are capitalized at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives. If an IPR&D project is abandoned, we recognize the carrying value of the related intangible asset in our consolidated statements of operations in the period it is abandoned. On a quarterly basis, we monitor factors and changes in circumstances that could indicate carrying amounts of long-lived assets, including purchased intangible assets and property, plant and equipment, may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, and (iii) significant negative industry or economic trends. An impairment loss must be measured if the sum of the expected future cash flows (undiscounted and before interest) from the use and eventual disposition of the asset (or asset group) is less than the net book value of the asset (or asset group). The amount of the impairment loss will generally be measured as the difference between the net book value of the asset (or asset group) and the estimated fair value.

[0001730168-22-000118:notes:32]
Warranty.  We accrue for the estimated costs of product warranties at the time revenue is recognized. Product warranty costs are estimated based upon our historical experience and specific identification of the product requirements, which may fluctuate based on product mix. Additionally, we accrue for warranty costs associated with occasional or unanticipated product quality issues if a loss is probable and can be reasonably estimated.

[0001730168-22-000118:notes:33]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.

[0001730168-22-000118:notes:34]
Nature of Products and Services

[0001730168-22-000118:notes:35]
Our products and services can be broadly categorized as sales of products and subscriptions and services. The following is a description of the principal activities from which we generate revenue.

[0001730168-22-000118:notes:36]
Products.  We recognize revenue from sales to direct customers and distributors when control transfers to the customer. Rebates and incentives offered to distributors, which are earned when sales to end customers are completed, are estimated at the point of revenue recognition. We have elected to exclude from the transaction price any taxes collected from a customer and to account for shipping and handling activities performed after a customer obtains control of the product as activities to fulfill the promise to transfer the product. From time to time, certain customers agree to pay us secure supply fees in exchange for prioritized fulfillment of product orders. Such fees are included in the transaction price of the product orders and are recognized as revenue in the period that control over the products is transferred to the customer.

[0001730168-22-000118:notes:37]
Subscriptions and services.  Our subscriptions and services revenue consists of sales and royalties from software arrangements, support services, professional services, transfer of IP, and non-recurring engineering (“NRE”) arrangements.

[0001730168-22-000118:notes:38]
Revenue from software arrangements primarily consists of fees, which may be paid either at contract inception or in

[0001730168-22-000118:notes:39]
installments over the contract term, that provide customers with a right to use the software, access general support and maintenance, and utilize our professional services.

[0001730168-22-000118:notes:40]
Our software licenses have standalone functionality from which customers derive benefit, and the customer obtains control of the software when it is delivered or made available for download. We believe that for the majority of software arrangements, customers derive significant benefit from the ongoing support we provide. The majority of our subscriptions and services arrangements permit our customers to unilaterally terminate or cancel these arrangements at any time at the customer’s convenience, referred to as termination for convenience provisions, without substantive termination penalty and receive a pro-rata refund of any prepaid fees. Accordingly, we account for arrangements with these termination for convenience provisions as a series of daily contracts, resulting in ratable revenue recognition of software revenue over the contractual period.

[0001730168-22-000118:notes:41]
Support services consist primarily of telephone support and the provision of unspecified updates and upgrades on a when-and-if-available basis. Support services represent stand-ready obligations for which revenue is recognized ratably over the term of the arrangement.

[0001730168-22-000118:notes:42]
Professional services consist of implementation, consulting, customer education and customer training services. The obligation to provide professional services is generally satisfied over time, with the customer simultaneously receiving and consuming the benefits as we satisfy our performance obligations.

[0001730168-22-000118:notes:43]
Rights to our IP are either sold or licensed to a customer. IP revenue recognition is dependent on the nature and terms of each agreement. We recognize IP revenue upon delivery of the IP if there are no substantive future obligations to perform under the arrangement. Sales-based or usage-based royalties from the license of IP are recognized at the later of the period the sales or usages occur or the satisfaction of the performance obligation to which some or all of the sales-based or usage-based royalties have been allocated.

[0001730168-22-000118:notes:44]
There are two main categories of NRE contracts that we enter into with our customers: (a) NRE contracts in which we develop a custom chip and (b) NRE contracts in which we accelerate our development of a new chip upon the customer’s request. The majority of our NRE contract revenues meet the over time criteria. As such, revenue is recognized over the development period with the measure of progress using the input method based on costs incurred to total cost as the services are provided. For NRE contracts that do not meet the over time criteria, revenue is recognized at a point in time when the NRE services are complete.

[0001730168-22-000118:notes:45]
Material rights.  Contracts with customers may also include material rights that are also performance obligations. These include the right to renew or receive products or services at a discounted price in the future. Revenue allocated to material rights is recognized when the customer exercises the right or the right expires.

[0001730168-22-000118:notes:46]
Arrangements with Multiple Performance Obligations

[0001730168-22-000118:notes:47]
Our contracts may contain more than one of the products and services listed above, each of which is separately accounted for as a distinct performance obligation.

[0001730168-22-000118:notes:48]
Allocation of consideration.  We allocate total contract consideration to each distinct performance obligation in a bundled arrangement on a relative standalone selling price basis. The standalone selling price reflects the price we would charge for a specific product or service if it were sold separately in similar circumstances and to similar customers.

[0001730168-22-000118:notes:49]
Standalone selling price.  When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. When directly observable transactions are not available, our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-22-000118:notes:50]
We separately determine the standalone selling prices by product or service type. Additionally, we segment the standalone selling prices for products where the pricing strategies differ, and where there are differences in customers and circumstances that warrant segmentation.

[0001730168-22-000118:notes:51]
We also estimate the standalone selling price of our material rights. We estimate the value of the customer’s option to purchase or receive additional products or services at a discounted price by estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-22-000118:notes:52]
Other Policies and Judgments

[0001730168-22-000118:notes:53]
Contract modifications.  We may modify contracts to offer customers additional products or services. Each of the additional products and services is generally considered distinct from those products or services transferred to the customer before the modification. We evaluate whether the contract price for the additional products and services reflects the

[0001730168-22-000118:notes:54]
standalone selling price as adjusted for facts and circumstances applicable to that contract. In these cases, we account for the additional products or services as a separate contract. In other cases where the pricing in the modification does not reflect the standalone selling price as adjusted for facts and circumstances applicable to that contract, we account for the additional products or services as part of the existing contract on a prospective basis, on a cumulative catch-up basis, or a combination of both based on the nature of the modification. In instances where the pricing in the modification offers the customer a credit for a prior arrangement, we adjust our variable consideration reserves for returns and other concessions.

[0001730168-22-000118:notes:55]
Right of return.  Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-22-000118:notes:56]
Practical expedient elected.  We do not disclose the value of unsatisfied performance obligations for (i) contracts with an original expected length of one year or less and (ii) contracts for which we recognize revenue at the amount to which we have the right to invoice for services performed. For contracts that were modified before the beginning of the earliest reporting period presented, we have not retrospectively restated the contract for those modifications. We have disclosed the aggregate effect of all modifications when identifying the satisfied and unsatisfied performance obligations for purposes of determining the transaction price and allocating the transaction price at transition.

[0001730168-22-000118:notes:57]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers and third parties engaged in the design and development of our products, software and technologies, including salary, bonus and stock-based compensation expense, project material costs, services and depreciation. Such costs are charged to research and development expense as they are incurred.

[0001730168-22-000118:notes:58]
Stock-based compensation expense.  We recognize compensation expense for time-based restricted stock units (“RSUs”) using the straight-line amortization method based on the fair value of RSUs on the date of grant. The fair value of RSUs is the closing market price of Broadcom common stock on the date of grant, reduced by the present value of dividends expected to be paid on Broadcom common stock prior to vesting. We recognize compensation expense for time-based stock options and employee stock purchase plan rights under the Broadcom Inc. Employee Stock Purchase Plan, as amended (“ESPP”) based on the estimated grant-date fair value determined using the Black-Scholes valuation model with a straight-line amortization method.

[0001730168-22-000118:notes:59]
Certain equity awards include both service and market conditions. The fair value of market-based awards is estimated on the date of grant using the Monte Carlo simulation technique. Compensation expense for market-based awards is amortized based upon a graded vesting method over the service period.

[0001730168-22-000118:notes:60]
We estimate forfeitures expected to occur and recognize stock-based compensation expense for such awards expected to vest. Changes in the estimated forfeiture rates can have a significant effect on stock-based compensation expense since the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001730168-22-000118:notes:61]
Shipping and handling costs.  Our shipping and handling costs charged to customers are included in net revenue and the associated expense is included in cost of revenue for all periods presented.

[0001730168-22-000118:notes:62]
Litigation and settlement cost.  We are involved in legal actions and other matters arising in our recent business acquisitions and in the normal course of business. We recognize an estimated loss contingency when the outcome is probable prior to issuance of the consolidated financial statements and we are able to reasonably estimate the amount or range of any possible loss.

[0001730168-22-000118:notes:63]
Income taxes.  We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the consolidated financial statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date.

[0001730168-22-000118:notes:64]
We recognize net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such determination, we consider all available positive and negative evidence, including scheduled reversals of deferred tax liabilities, projected future taxable income, tax planning strategies and recent financial operations. If we determine that we are able to realize our deferred income tax assets in the future in excess of their net carrying values, we adjust the valuation allowance and reduce the provision for income taxes or increase the benefit from income taxes. Likewise, if we determine that we are not able to realize all or part of our net deferred tax assets, we increase the provision for income taxes or decrease the benefit from income taxes in the period such determination is made.

[0001730168-22-000118:notes:65]
We account for uncertainty in income taxes in accordance with the applicable accounting guidance on income taxes. This guidance provides that a tax benefit from an uncertain tax position may be recognized when it is more likely than not that the position will be sustained upon examination, including resolutions of any related appeals or litigation processes, based on the technical merits.

[0001730168-22-000118:notes:66]
Net income per share.  Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Diluted shares outstanding include the dilutive effect of unvested RSUs, in-the-money stock options, and ESPP rights (together referred to as “equity awards”), as well as convertible preferred stock. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-22-000118:notes:67]
The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and purchasing shares under the ESPP and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares. The dilutive effect of convertible preferred stock is calculated using the if-converted method. The if-converted method assumes that these securities were converted at the beginning of the reporting period to the extent that the effect is dilutive.

[0001730168-22-000118:notes:68]
Recently Adopted Accounting Guidance.  In October 2021, the Financial Accounting Standards Board issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with Accounting Standards Codification 606, Revenue from Contracts with Customers, as if it had originated the contracts. We early adopted this guidance at the beginning of fiscal year 2022 and it did not materially impact our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-22-000118:notes:69]
Revenue from Contracts with Customers 
Disaggregation

[0001730168-22-000118:notes:70]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 13. “Segment Information.”

[0001730168-22-000118:notes:71]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

[0001730168-22-000118:notes:72]
|  |  | Fiscal Year 2022 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,371 |  |  | $ | 21,761 |  |  | $ | 2,145 |  |  | $ | 26,277 |  |
| Subscriptions and services(a) |  | 4,573 |  |  | 744 |  |  | 1,609 |  |  | 6,926 |  |
| Total |  | $ | 6,944 |  |  | $ | 22,505 |  |  | $ | 3,754 |  |  | $ | 33,203 |  |

[0001730168-22-000118:notes:73]
|  |  | Fiscal Year 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,809 |  |  | $ | 17,258 |  |  | $ | 1,819 |  |  | $ | 20,886 |  |
| Subscriptions and services(a) |  | 4,290 |  |  | 720 |  |  | 1,554 |  |  | 6,564 |  |
| Total |  | $ | 6,099 |  |  | $ | 17,978 |  |  | $ | 3,373 |  |  | $ | 27,450 |  |

[0001730168-22-000118:notes:74]
|  |  | Fiscal Year 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,775 |  |  | $ | 14,442 |  |  | $ | 1,218 |  |  | $ | 17,435 |  |
| Subscriptions and services(a) |  | 4,059 |  |  | 881 |  |  | 1,513 |  |  | 6,453 |  |
| Total |  | $ | 5,834 |  |  | $ | 15,323 |  |  | $ | 2,731 |  |  | $ | 23,888 |  |

[0001730168-22-000118:notes:75]
_____________________________

[0001730168-22-000118:notes:76]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

[0001730168-22-000118:notes:77]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer (“OEM”) customers, contract manufacturers, channel partners, or software customers.

[0001730168-22-000118:notes:78]
Contract Balances

[0001730168-22-000118:notes:79]
Contract assets and contract liabilities balances were as follows:

[0001730168-22-000118:notes:80]
|  |  | October 30,2022 |  | October 31,2021 |
|  | (In millions) |
| Contract Assets |  | $ | 128 |  |  | $ | 126 |  |
| Contract Liabilities |  | $ | 3,341 |  |  | $ | 3,185 |  |

[0001730168-22-000118:notes:81]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements which may include termination for convenience provisions. The amount of revenue recognized during fiscal year 2022 that was included in the contract liabilities balance as of October 31, 2021 was $2,615 million. The amount of revenue recognized during fiscal year 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,617 million.

[0001730168-22-000118:notes:82]
Remaining Performance Obligations

[0001730168-22-000118:notes:83]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when termination for convenience without payment of a substantive penalty exists, either contractually or through customary business practice. The majority of our customer software contracts include termination for convenience clauses without a substantive penalty and are not considered committed. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of IP.

[0001730168-22-000118:notes:84]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of October 30, 2022 were approximately $23.6 billion. We expect approximately 28% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-22-000118:notes:85]
Acquisitions 
Pending Acquisition of VMware, Inc.

[0001730168-22-000118:notes:86]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion based on the closing price of Broadcom common stock on May 25, 2022. We will also assume VMware’s closing date outstanding debt, net of expected cash.

[0001730168-22-000118:notes:87]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

[0001730168-22-000118:notes:88]
We will assume all outstanding VMware RSU awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-22-000118:notes:89]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

[0001730168-22-000118:notes:90]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

[0001730168-22-000118:notes:91]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023 (“fiscal year 2023”), is subject to satisfaction or waiver of customary closing conditions, including the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 and clearance under the antitrust laws of the European Union and certain other jurisdictions. On October 3, 2022, we registered approximately 59 million shares of our common stock. On November 4, 2022, VMware stockholders adopted the VMware Merger Agreement. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-22-000118:notes:92]
Acquisition of the Symantec Corporation Enterprise Security Business

[0001730168-22-000118:notes:93]
On November 4, 2019 (the “Symantec Acquisition Date”), we completed the purchase of the Symantec Business, which was an established leader in cyber security, for $10.7 billion in cash. We acquired the Symantec Business to expand our footprint of mission critical infrastructure software with our existing customer base. The Symantec Business includes a deep and broad mix of products, services and solutions, unifying cloud and on-premises security to provide advanced threat protection and information protection across endpoints, network, email and cloud applications. We financed this acquisition with borrowings.

[0001730168-22-000118:notes:94]
The following table presents our allocation of the total purchase price:

[0001730168-22-000118:notes:95]
|  |  | Fair Value |
|  |  | (In millions) |
| Current assets |  | $ | 273 |  |
| Goodwill |  | 6,638 |  |
| Intangible assets |  | 5,411 |  |
| Other long-term assets |  | 92 |  |
| Total assets acquired |  | 12,414 |  |
| Current liabilities |  | (1,127) |  |
| Other long-term liabilities |  | (587) |  |
| Total liabilities assumed |  | (1,714) |  |
| Fair value of net assets acquired |  | $ | 10,700 |  |

[0001730168-22-000118:notes:96]
Goodwill is primarily attributable to the assembled workforce and anticipated synergies and economies of scale expected from the integration of the Symantec Business. The synergies include certain cost savings, operating efficiencies, and other strategic benefits projected to be achieved resulting from the acquisition of the Symantec Business. Substantially all goodwill is deductible for tax purposes.

[0001730168-22-000118:notes:97]
Current assets and current liabilities included amounts held-for-sale related to the acquired Symantec Cyber Security Services business, which was not aligned with our acquisition-date strategic objectives and was sold on April 30, 2020. We do not have any material continuing involvement with this business and have presented its results in discontinued operations.

[0001730168-22-000118:notes:98]
Our results of continuing operations for fiscal year 2020 included $1,610 million of net revenue attributable to the Symantec Business. It was impracticable to determine the effect on net income attributable to the Symantec Business as we had integrated the Symantec Business into our ongoing operations during the year. The results of operations of the Symantec Business were included in our infrastructure software segment. Transaction costs related to the acquisition of the Symantec Business of $110 million were included in selling, general and administrative expense for fiscal year 2020.

[0001730168-22-000118:notes:99]
Intangible Assets

[0001730168-22-000118:notes:100]
|  |  | Fair Value |  | Weighted-Average Amortization Periods |
|  |  | (In millions) |  | (In years) |
| Developed technology |  | $ | 2,900 |  |  | 5 |
| Customer contracts and related relationships |  | 2,410 |  |  | 5 |
| Trade name |  | 90 |  |  | 6 |
| Order backlog |  | 11 |  |  | 3 |
| Total identified finite-lived intangible assets |  | $ | 5,411 |  |  |  |

[0001730168-22-000118:notes:101]
Developed technology relates to products used for cyber security solutions, including data loss prevention, endpoint protection, and web, email and cloud security solutions. We valued the developed technology using the multi-period excess earnings method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated by the developed technology less charges representing the contribution of other assets to those cash flows. The economic useful life was determined based on the technology cycle related to each developed technology, as well as the cash flows over the forecast period.

[0001730168-22-000118:notes:102]
Customer contracts and related relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of the Symantec Business. Customer contracts and related relationships were valued using the with-and-without-method under the income approach. In the with-and-without method, the fair value was measured by the difference between the present values of the cash flows with and without the existing customers in place over the period of time necessary to reacquire the customers. The economic useful life was determined by evaluating many factors, including the useful life of other intangible assets, the length of time remaining on the acquired contracts and the historical customer turnover rates.

[0001730168-22-000118:notes:103]
Trade name relates to the “Symantec” trade name. The fair value was determined by applying the relief-from-royalty method under the income approach. This method is based on the application of a royalty rate to forecasted revenue under the trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecast period.

[0001730168-22-000118:notes:104]
Order backlog represents business under existing contractual obligations. The fair value of backlog was determined using the multi-period excess earnings method under the income approach based on expected operating cash flows from future contractual revenue. The economic useful life was determined based on the expected life of the backlog and the cash flows over the forecast period.

[0001730168-22-000118:notes:105]
We believe the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Symantec Acquisition Date.

[0001730168-22-000118:notes:106]
Unaudited Pro Forma Information

[0001730168-22-000118:notes:107]
The following unaudited pro forma financial information presents combined results of operations for the period presented, as if we had completed the acquisition of the Symantec Business as of the beginning of our fiscal year ended November 3, 2019 (“fiscal year 2019”). The unaudited pro forma information includes adjustments to amortization and depreciation for intangible assets and property, plant and equipment acquired, adjustments to interest expense for the additional indebtedness incurred to complete the acquisition, restructuring charges related to the acquisition and transaction costs. The unaudited pro forma information presented below is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2019 or of the results of our future operations of the combined business.

[0001730168-22-000118:notes:108]
|  |  |  | Fiscal Year |
|  |  |  | 2020 |
|  |  | (In millions) |
| Pro forma net revenue |  |  | $ | 23,264 |  |
| Pro forma net income attributable to common stock |  |  | $ | 2,368 |  |

[0001730168-22-000118:notes:109]
Other Acquisitions

[0001730168-22-000118:notes:110]
During fiscal year 2022, we completed four acquisitions qualifying as business combinations for total consideration of $245 million. For these acquisitions, $164 million was allocated to goodwill and $110 million was allocated to intangible assets, with additional amounts allocated to tangible assets and liabilities, primarily within our infrastructure software segment.
During fiscal year 2020, we completed three other acquisitions qualifying as business combinations for total consideration of $201 million. For these acquisitions, $109 million was allocated to goodwill and $46 million was allocated to intangible assets, with additional amounts allocated to tangible assets and liabilities, primarily within our infrastructure software segment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001730168-22-000118:notes:111]
Supplemental Financial Information 
Cash Equivalents

[0001730168-22-000118:notes:112]
Cash equivalents included $3,915 million and $4,668 million of time deposits and $2,365 million and $1,607 million of money-market funds as of October 30, 2022 and October 31, 2021, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-22-000118:notes:113]
Accounts Receivable Factoring

[0001730168-22-000118:notes:114]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided

[0001730168-22-000118:notes:115]
by operating activities in the consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $3,700 million, $4,027 million and $3,723 million during fiscal years 2022, 2021 and 2020, respectively. Factoring fees for the sales of receivables were recorded in other income (expense), net and were not material for any of the periods presented.

[0001730168-22-000118:notes:116]
Inventory

[0001730168-22-000118:notes:117]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Finished goods |  | $ | 780 |  |  | $ | 423 |  |
| Work-in-process |  | 966 |  |  | 680 |  |
| Raw materials |  | 179 |  |  | 194 |  |
| Total inventory |  | $ | 1,925 |  |  | $ | 1,297 |  |

[0001730168-22-000118:notes:118]
Property, Plant and Equipment, Net

[0001730168-22-000118:notes:119]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Land |  | $ | 195 |  |  | $ | 195 |  |
| Construction in progress |  | 63 |  |  | 38 |  |
| Buildings and leasehold improvements |  | 1,156 |  |  | 1,150 |  |
| Machinery and equipment |  | 4,413 |  |  | 4,161 |  |
| Total property, plant and equipment |  | 5,827 |  |  | 5,544 |  |
| Accumulated depreciation and amortization |  | (3,604) |  |  | (3,196) |  |
| Total property, plant and equipment, net |  | $ | 2,223 |  |  | $ | 2,348 |  |

[0001730168-22-000118:notes:120]
Depreciation expense was $529 million, $539 million and $570 million for fiscal years 2022, 2021, and 2020, respectively.

[0001730168-22-000118:notes:121]
Other Current Assets

[0001730168-22-000118:notes:122]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 864 |  |  | $ | 539 |  |
| Other |  | 341 |  |  | 516 |  |
| Total other current assets |  | $ | 1,205 |  |  | $ | 1,055 |  |

[0001730168-22-000118:notes:123]
Other Current Liabilities

[0001730168-22-000118:notes:124]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 2,931 |  |  | $ | 2,619 |  |
| Tax liabilities |  | 680 |  |  | 541 |  |
| Interest payable |  | 393 |  |  | 282 |  |
| Other |  | 408 |  |  | 397 |  |
| Total other current liabilities |  | $ | 4,412 |  |  | $ | 3,839 |  |

[0001730168-22-000118:notes:125]
Other Long-Term Liabilities

[0001730168-22-000118:notes:126]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Unrecognized tax benefits, interest and penalties |  | $ | 3,229 |  |  | $ | 3,407 |  |
| Contract liabilities |  | 410 |  |  | 566 |  |
| Other |  | 774 |  |  | 887 |  |
| Total other long-term liabilities |  | $ | 4,413 |  |  | $ | 4,860 |  |

[0001730168-22-000118:notes:127]
Other Income (Expense), Net

[0001730168-22-000118:notes:128]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Gain (loss) on investments |  | $ | (169) |  |  | $ | 99 |  |  | $ | 31 |  |
| Other income |  | 30 |  |  | 26 |  |  | 56 |  |
| Interest income |  | 100 |  |  | 16 |  |  | 53 |  |
| Other expense |  | (15) |  |  | (10) |  |  | (50) |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | 116 |  |
| Other income (expense), net |  | $ | (54) |  |  | $ | 131 |  |  | $ | 206 |  |

[0001730168-22-000118:notes:129]
Other income includes foreign exchange gains, dividends, and other miscellaneous items.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001730168-22-000118:notes:130]
Leases
At the beginning of fiscal year 2020, we adopted ASU 2016-02, Leases (“Topic 842”) using the optional adoption method, whereby no adjustment to the financial statements of comparative periods was required.  We have operating and finance leases for our facilities, data centers and certain equipment. Operating lease expense was $98 million, $102 million and $106 million for fiscal years 2022, 2021 and 2020, respectively. Finance lease expense was $18 million, $16 million and $14 million for fiscal years 2022, 2021 and 2020 respectively.

[0001730168-22-000118:notes:131]
Other information related to leases was as follows:

[0001730168-22-000118:notes:132]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Cash paid for operating leases included in operating cash flows |  | $ | 103 |  |  | $ | 140 |  |  | $ | 125 |  |
| ROU assets obtained in exchange for operating lease liabilities |  | $ | 16 |  |  | $ | 92 |  |  | $ | 682 |  |
| ROU assets obtained in exchange for finance lease liabilities |  | $ | 1 |  |  | $ | 15 |  |  | $ | 74 |  |
|  |  | October 30,2022 |  | October 31,2021 |  |  |
| Weighted-average remaining lease term – operating leases (In years) |  | 10 |  | 10 |  |  |
| Weighted-average remaining lease term – finance leases (In years) |  | 2 |  | 3 |  |  |
| Weighted-average discount rate – operating leases |  | 3.60 |  | % | 3.78 |  | % |  |
| Weighted-average discount rate – finance leases |  | 3.05 |  | % | 3.11 |  | % |  |

[0001730168-22-000118:notes:133]
Supplemental balance sheet information related to leases was as follows:

[0001730168-22-000118:notes:134]
|  |  | Classification on the Consolidated Balance Sheets |  | October 30,2022 |  | October 31,2021 |
|  |  |  |  | (In millions) |
| ROU assets - operating leases |  | Other long-term assets |  | $ | 517 |  |  | $ | 588 |  |
| ROU assets - finance leases |  | Property, plant and equipment, net |  | $ | 40 |  |  | $ | 55 |  |
| Short-term lease liabilities - operating leases |  | Other current liabilities |  | $ | 74 |  |  | $ | 83 |  |
| Long-term lease liabilities - operating leases |  | Other long-term liabilities |  | $ | 389 |  |  | $ | 460 |  |
| Short-term lease liabilities - finance leases |  | Current portion of long-term debt |  | $ | 37 |  |  | $ | 26 |  |
| Long-term lease liabilities - finance leases |  | Long-term debt |  | $ | 22 |  |  | $ | 39 |  |

[0001730168-22-000118:notes:135]
Future minimum lease payments under non-cancelable leases as of October 30, 2022 were as follows:

[0001730168-22-000118:notes:136]
|  |  | October 30,2022 |
|  |  | Operating Leases |  | Finance Leases |
|  |  | (In millions) |
| 2023 |  | $ | 89 |  |  | $ | 38 |  |
| 2024 |  | 69 |  |  | 18 |  |
| 2025 |  | 58 |  |  | 2 |  |
| 2026 |  | 45 |  |  | 2 |  |
| 2027 |  | 40 |  |  | — |  |
| Thereafter |  | 267 |  |  | — |  |
| Total undiscounted liabilities |  | 568 |  |  | 60 |  |
| Less: interest |  | (105) |  |  | (1) |  |
| Present value of lease liabilities |  | $ | 463 |  |  | $ | 59 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-22-000118:notes:137]
Goodwill and Intangible Assets 
Goodwill

[0001730168-22-000118:notes:138]
|  |  |  |  |  |  |  |  |  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  |  |  |  |  |  |  |  |  | (In millions) |
| Balance as of November 1, 2020 |  |  |  |  |  |  |  |  |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | 43,447 |  |
| Acquisition |  |  |  |  |  |  |  |  |  | — |  |  | 10 |  |  | 10 |  |
| Sale of business |  |  |  |  |  |  |  |  |  | — |  |  | (7) |  |  | (7) |  |
| Balance as of October 31, 2021 |  |  |  |  |  |  |  |  |  | 25,959 |  |  | 17,491 |  |  | 43,450 |  |
| Acquisitions |  |  |  |  |  |  |  |  |  | 8 |  |  | 156 |  |  | 164 |  |
| Balance as of October 30, 2022 |  |  |  |  |  |  |  |  |  | $ | 25,967 |  |  | $ | 17,647 |  |  | $ | 43,614 |  |

[0001730168-22-000118:notes:139]
During the fourth quarter of fiscal years 2022, 2021 and 2020, we completed our annual impairment assessments and concluded that goodwill was not impaired in any of these years.

[0001730168-22-000118:notes:140]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of October 30, 2022: |  |  |  |  |  |  |
| Purchased technology |  | $ | 19,450 |  |  | $ | (15,422) |  |  | $ | 4,028 |  |
| Customer contracts and related relationships |  | 7,066 |  |  | (4,535) |  |  | 2,531 |  |
| Order backlog |  | 484 |  |  | (382) |  |  | 102 |  |
| Trade names |  | 700 |  |  | (372) |  |  | 328 |  |
| Other |  | 174 |  |  | (81) |  |  | 93 |  |
| Intangible assets subject to amortization |  | 27,874 |  |  | (20,792) |  |  | 7,082 |  |
| IPR&D |  | 29 |  |  | — |  |  | 29 |  |
| Total |  | $ | 27,903 |  |  | $ | (20,792) |  |  | $ | 7,111 |  |
| As of October 31, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 23,932 |  |  | $ | (17,148) |  |  | $ | 6,784 |  |
| Customer contracts and related relationships |  | 8,356 |  |  | (4,533) |  |  | 3,823 |  |
| Order backlog |  | 2,579 |  |  | (2,352) |  |  | 227 |  |
| Trade names |  | 787 |  |  | (386) |  |  | 401 |  |
| Other |  | 239 |  |  | (127) |  |  | 112 |  |
| Intangible assets subject to amortization |  | 35,893 |  |  | (24,546) |  |  | 11,347 |  |
| IPR&D |  | 27 |  |  | — |  |  | 27 |  |
| Total |  | $ | 35,920 |  |  | $ | (24,546) |  |  | $ | 11,374 |  |

[0001730168-22-000118:notes:141]
Based on the amount of intangible assets subject to amortization at October 30, 2022, the expected amortization expense for each of the next five fiscal years and thereafter was as follows:

[0001730168-22-000118:notes:142]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2023 |  | $ | 3,255 |  |
| 2024 |  | 2,388 |  |
| 2025 |  | 681 |  |
| 2026 |  | 344 |  |
| 2027 |  | 216 |  |
| Thereafter |  | 198 |  |
| Total |  | $ | 7,082 |  |

[0001730168-22-000118:notes:143]
The weighted-average amortization periods remaining by intangible asset category were as follows:

[0001730168-22-000118:notes:144]
| Amortizable intangible assets: |  | October 30,2022 |  | October 31,2021 |
|  |  | (In years) |
| Purchased technology |  | 3 |  | 4 |
| Customer contracts and related relationships |  | 2 |  | 3 |
| Order backlog |  | 1 |  | 2 |
| Trade names |  | 8 |  | 8 |
| Other |  | 8 |  | 9 |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001730168-22-000118:notes:145]
Net Income Per Share

[0001730168-22-000118:notes:146]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 11,495 |  |  | $ | 6,736 |  |  | $ | 2,961 |  |
| Dividends on preferred stock |  | (272) |  |  | (299) |  |  | (297) |  |
| Income from continuing operations attributable to common stock |  | 11,223 |  |  | 6,437 |  |  | 2,664 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | — |  |  | — |  |  | (1) |  |
| Net income attributable to common stock |  | $ | 11,223 |  |  | $ | 6,437 |  |  | $ | 2,663 |  |
| Denominator: |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 409 |  |  | 410 |  |  | 402 |  |
| Dilutive effect of equity awards |  | 14 |  |  | 19 |  |  | 19 |  |
| Weighted-average shares outstanding - diluted |  | 423 |  |  | 429 |  |  | 421 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |
| Basic |  | $ | 27.44 |  |  | $ | 15.70 |  |  | $ | 6.62 |  |
| Diluted |  | $ | 26.53 |  |  | $ | 15.00 |  |  | $ | 6.33 |  |


## us-gaap:EarningsPerShareTextBlock

[0001730168-22-000118:notes:147]
For fiscal years 2022, 2021 and 2020, diluted net income per share excluded the potentially dilutive effect of 10 million, 12 million and 12 million shares of common stock, respectively, issuable upon the conversion of Mandatory Convertible Preferred Stock, as defined in Note 11. “Stockholders’ Equity,” as their effect was antidilutive.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001730168-22-000118:notes:148]
Retirement Plans 
Defined Benefit Pension Plans

[0001730168-22-000118:notes:149]
The U.S. defined benefit pension plans primarily consist of a qualified pension plan. Benefits of the qualified pension plan are provided under an adjusted career-average-pay program, a cash-balance program or a dollar-per-month program. Benefit accruals under this plan were frozen in 2009. Participants in the adjusted career-average-pay program no longer earn service accruals. Participants in the cash-balance program no longer earn service accruals, but continue to earn 4% interest per year on their cash-balance accounts. There are no active participants under the dollar-per-month program. We also have a non-qualified supplemental pension plan in the United States that principally provides benefits based on compensation in excess of amounts that can be considered under the qualified pension plan.

[0001730168-22-000118:notes:150]
We also have defined benefit pension plans for certain employees in Austria, France, Germany, India, Israel, Italy, Japan and Taiwan. Eligibility is generally determined based on the terms of our plans and local statutory requirements.

[0001730168-22-000118:notes:151]
Net Periodic Benefit Cost

[0001730168-22-000118:notes:152]
|  |  | Fiscal Year |  |  |
|  |  | 2022 |  | 2021 |  | 2020 |  |  |  |  |  |  |
|  |  | (In millions) |
| Service cost |  | $ | 8 |  |  | $ | 11 |  |  | $ | 12 |  |  |  |  |  |  |  |
| Interest cost |  | 39 |  |  | 39 |  |  | 45 |  |  |  |  |  |  |  |
| Expected return on plan assets |  | (39) |  |  | (40) |  |  | (46) |  |  |  |  |  |  |  |
| Other |  | 1 |  |  | 1 |  |  | (3) |  |  |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 9 |  |  | $ | 11 |  |  | $ | 8 |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  | $ | (17) |  |  | $ | 8 |  |  | $ | (28) |  |  |  |  |  |  |  |

[0001730168-22-000118:notes:153]
The components of net periodic benefit cost other than the service cost are included in other income (expense), net. Service cost is recognized in operating expenses.

[0001730168-22-000118:notes:154]
Benefit Obligations and Plan Assets

[0001730168-22-000118:notes:155]
|  |  | October 30,2022 |  | October 31,2021 |  |  |  |  |
|  |  | (In millions) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets — beginning of period |  | $ | 1,521 |  |  | $ | 1,593 |  |  |  |  |  |
| Actual return on plan assets |  | (279) |  |  | 20 |  |  |  |  |  |
| Employer contributions |  | 10 |  |  | 9 |  |  |  |  |  |
| Plan participants’ contributions |  | 1 |  |  | — |  |  |  |  |  |
| Payments from plan assets |  | (95) |  |  | (102) |  |  |  |  |  |
| Foreign currency impact |  | 2 |  |  | 1 |  |  |  |  |  |
| Fair value of plan assets — end of period |  | 1,160 |  |  | 1,521 |  |  |  |  |  |
| Change in benefit obligations: |  |  |  |  |  |  |  |  |
| Benefit obligations — beginning of period |  | 1,526 |  |  | 1,588 |  |  |  |  |  |
| Service cost |  | 8 |  |  | 11 |  |  |  |  |  |
| Interest cost |  | 39 |  |  | 39 |  |  |  |  |  |
| Actuarial gain (a) |  | (336) |  |  | (11) |  |  |  |  |  |
| Plan participants' contributions |  | 1 |  |  | — |  |  |  |  |  |
| Benefit payments |  | (95) |  |  | (102) |  |  |  |  |  |
| Curtailments |  | — |  |  | (1) |  |  |  |  |  |
| Foreign currency impact |  | — |  |  | 2 |  |  |  |  |  |
| Benefit obligations — end of period |  | 1,143 |  |  | 1,526 |  |  |  |  |  |
| Overfunded (underfunded) status of benefit obligations (b) |  | $ | 17 |  |  | $ | (5) |  |  |  |  |  |
| Actuarial losses and prior service costs recognized in accumulated other comprehensive loss, net of taxes |  | $ | (82) |  |  | $ | (100) |  |  |  |  |  |

[0001730168-22-000118:notes:156]
_______________________________

[0001730168-22-000118:notes:157]
(a)The actuarial gain in fiscal year 2022 was primarily due to an increase in discount rates experienced by the majority of our plans.

[0001730168-22-000118:notes:158]
(b)Substantially all amounts recognized on the consolidated balance sheets were recorded in other long-term assets and other long-term liabilities for all periods presented.

[0001730168-22-000118:notes:159]
Plans with benefit obligations in excess of plan assets:

[0001730168-22-000118:notes:160]
|  |  | October 30,2022 |  | October 31,2021 |  |  |  |  |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 71 |  |  | $ | 83 |  |  |  |  |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 55 |  |  | $ | 65 |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets |  | $ | 12 |  |  | $ | 13 |  |  |  |  |  |  |  |  |  |

[0001730168-22-000118:notes:161]
Plans with benefit obligations less than plan assets:

[0001730168-22-000118:notes:162]
|  |  | October 30,2022 |  | October 31,2021 |  |  |  |  |
|  |  | (In millions) |
| Projected benefit obligations |  | $ | 1,072 |  |  | $ | 1,443 |  |  |  |  |  |
| Accumulated benefit obligations |  | $ | 1,070 |  |  | $ | 1,442 |  |  |  |  |  |
| Fair value of plan assets |  | $ | 1,148 |  |  | $ | 1,508 |  |  |  |  |  |

[0001730168-22-000118:notes:163]
The fair value of pension plan assets as of October 30, 2022 and October 31, 2021 included $184 million and $174 million, respectively, of assets for our non-U.S. pension plans.

[0001730168-22-000118:notes:164]
The projected benefit obligations as of October 30, 2022 and October 31, 2021 included $185 million and $217 million, respectively, of obligations related to our non-U.S. pension plans. The accumulated benefit obligations as of October 30, 2022 and October 31, 2021 included $168 million and $199 million, respectively, of obligations related to our non-U.S. pension plans.

[0001730168-22-000118:notes:165]
Expected Future Benefit Payments

[0001730168-22-000118:notes:166]
| Fiscal Years: |  | Expected Benefit Payments |  |  |
|  |  | (In millions) |
| 2023 |  | $ | 95 |  |  |  |
| 2024 |  | $ | 95 |  |  |  |
| 2025 |  | $ | 94 |  |  |  |
| 2026 |  | $ | 94 |  |  |  |
| 2027 |  | $ | 93 |  |  |  |
| 2028-2032 |  | $ | 444 |  |  |  |

[0001730168-22-000118:notes:167]
Investment Policy

[0001730168-22-000118:notes:168]
Plan assets of the U.S. qualified pension plan, which represent substantially all of the plan assets, are generally invested in funds held by third-party fund managers. Our benefit plan investment committee has set the investment strategy to fully match the liability. We direct the overall portfolio allocation and use a third-party investment consultant that has the discretion to structure portfolios and select the investment managers within those allocation parameters. Multiple investment managers are utilized, including both active and passive management approaches. The plan assets are invested using the liability-driven investment strategy intended to minimize market and interest rate risks, and those assets are periodically rebalanced toward asset allocation targets.

[0001730168-22-000118:notes:169]
The target asset allocation for the U.S. qualified pension plan reflects a risk/return profile that we believe is appropriate relative to the liability structure and return goals for the plan. We periodically review the allocation of plan assets relative to alternative allocation models to evaluate the need for adjustments based on forecasted liabilities and plan liquidity needs. For both fiscal years 2022 and 2021, 100% of the U.S. qualified pension plan assets were allocated to fixed income, in line with the target allocation. The fixed income allocation is primarily directed toward long-term core bond investments, with smaller allocations to Treasury Inflation-Protected Securities and high-yield bonds.

[0001730168-22-000118:notes:170]
Fair Value Measurement of Plan Assets

[0001730168-22-000118:notes:171]
|  |  | October 30, 2022 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |  |
|  |  | (In millions) |  |
| Cash equivalents |  | $ | 19 |  | (a) |  | $ | — |  |  |  |  |  | $ | 19 |  |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 46 |  | (b) |  | — |  |  |  |  |  | 46 |  |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 147 |  | (c) |  |  |  | 147 |  |  |
| Corporate bonds |  | — |  |  |  | 901 |  | (c) |  |  |  | 901 |  |  |
| Municipal bonds |  | — |  |  |  | 20 |  | (c) |  |  |  | 20 |  |  |
| Government bonds |  | — |  |  |  | 25 |  | (c) |  |  |  | 25 |  |  |
| Asset-backed securities |  | — |  |  |  | 2 |  | (c) |  |  |  | 2 |  |  |
| Total plan assets |  | $ | 65 |  |  |  | $ | 1,095 |  |  |  |  |  | $ | 1,160 |  |  |

[0001730168-22-000118:notes:172]
|  |  | October 31, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Level 1 |  |  | Level 2 |  |  |  |  | Total |
|  |  | (In millions) |
| Cash equivalents |  | $ | 24 |  | (a) |  | $ | — |  |  |  |  |  | $ | 24 |  |
| Equity securities: |  |  |  |  |  |  |  |  |  |  |
| Non-U.S. equity securities |  | 28 |  | (b) |  | — |  |  |  |  |  | 28 |  |
| Fixed-income securities: |  |  |  |  |  |  |  |  |  |  |
| U.S. treasuries |  | — |  |  |  | 186 |  | (c) |  |  |  | 186 |  |
| Corporate bonds |  | — |  |  |  | 1,222 |  | (c) |  |  |  | 1,222 |  |
| Municipal bonds |  | — |  |  |  | 24 |  | (c) |  |  |  | 24 |  |
| Government bonds |  | — |  |  |  | 34 |  | (c) |  |  |  | 34 |  |
| Asset-backed securities |  | — |  |  |  | 3 |  | (c) |  |  |  | 3 |  |
| Total plan assets |  | $ | 52 |  |  |  | $ | 1,469 |  |  |  |  |  | $ | 1,521 |  |

[0001730168-22-000118:notes:173]
______________________________

[0001730168-22-000118:notes:174]
(a)Cash equivalents primarily included short-term investment funds which consisted of short-term money market instruments that were valued based on quoted prices in active markets.

[0001730168-22-000118:notes:175]
(b)These equity securities were valued based on quoted prices in active markets.

[0001730168-22-000118:notes:176]
(c)These amounts consisted of investments that were traded less frequently than Level 1 securities and were valued using inputs that included quoted prices for similar assets in active markets and inputs other than quoted prices that were observable for the assets, such as interest rates, yield curves, prepayment speeds, collateral performance, broker/dealer quotes and indices that were observable at commonly quoted intervals.

[0001730168-22-000118:notes:177]
Assumptions

[0001730168-22-000118:notes:178]
The assumptions used to determine the benefit obligations and net periodic benefit cost for our defined benefit pension plans are presented in the table below. The expected long-term return on assets shown in the table below represents an estimate of long-term returns on investment portfolios primarily consisting of combinations of debt, equity and other investments, depending on the plan. The long-term rates of return are then weighted based on the asset classes in which the pension funds are invested. Discount rates reflect the current rate at which defined benefit pension obligations could be settled based on the measurement dates of the plans, which is October 31, the month end closest to our fiscal year end. The range of assumptions reflects the different economic environments within various countries.

[0001730168-22-000118:notes:179]
|  |  | Assumptions for Benefit Obligationsas of |  | Assumptions for Net Periodic Benefit CostFiscal Year |
|  |  | October 30,2022 |  | October 31,2021 |  | 2022 |  | 2021 |  | 2020 |
| Discount rate |  | 1.25%-7.25% |  | 0.75%-6.50% |  | 0.75%-6.50% |  | 0.61%-6.54% |  | 0.47%-7.00% |
| Average increase in compensation levels |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 2.00%-10.00% |  | 2.00%-10.00% |
| Expected long-term return on assets |  | N/A |  | N/A |  | 1.50%-7.25% |  | 1.00%-8.00% |  | 1.50%-7.80% |

[0001730168-22-000118:notes:180]
Defined Contribution Plans

[0001730168-22-000118:notes:181]
Our eligible U.S. employees participate in a company-sponsored 401(k) plan. Under the plan, we match employee contributions dollar for dollar up to 6% of their eligible earnings. All matching contributions vest immediately. During fiscal years 2022, 2021 and 2020, we made contributions of $96 million, $94 million and $99 million, respectively, to the 401(k) plan.

[0001730168-22-000118:notes:182]
In addition, other eligible employees outside of the U.S. receive retirement benefits under various defined contribution retirement plans.


## us-gaap:DebtDisclosureTextBlock

[0001730168-22-000118:notes:183]
Borrowings

[0001730168-22-000118:notes:184]
|  |  | Effective Interest Rate |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | $ | 750 |  |  | $ | — |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | — |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | — |  |
|  |  |  |  | 4,450 |  |  | — |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,965 |  |
|  |  |  |  | 1,870 |  |  | 2,717 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 105 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 2,679 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,861 |  |  | 5,684 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | — |  |  | 1,020 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 1,086 |  |
|  |  |  |  | 606 |  |  | 2,106 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 622 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | — |  |  | 944 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,958 |  |
|  |  |  |  | 2,277 |  |  | 3,524 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | — |  |  | 255 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 260 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 829 |  |

[0001730168-22-000118:notes:185]
|  |  | Effective Interest Rate |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 495 |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 5,283 |  |  | 5,538 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 143 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 265 |  |
|  |  |  |  | 358 |  |  | 408 |  |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 2.500% notes due August 2022 |  | 2.59 | % |  | — |  |  | 9 |  |
| 3.500% notes due August 2024 |  | 3.55 | % |  | 7 |  |  | 7 |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
|  |  |  |  | 13 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | $ | 41,218 |  |  | $ | 41,499 |  |
| Current portion of principal amount outstanding |  |  |  | $ | 403 |  |  | $ | 264 |  |
| Short-term finance lease liabilities |  |  |  | 37 |  |  | 26 |  |
| Total current portion of long-term debt |  |  |  | $ | 440 |  |  | $ | 290 |  |
| Non-current portion of principal amount outstanding |  |  |  | $ | 40,815 |  |  | $ | 41,235 |  |
| Long-term finance lease liabilities |  |  |  | 22 |  |  | 39 |  |
| Unamortized discount and issuance costs |  |  |  | (1,762) |  |  | (1,834) |  |
| Total long-term debt |  |  |  | $ | 39,075 |  |  | $ | 39,440 |  |

[0001730168-22-000118:notes:186]
The senior notes are recorded net of discount and issuance costs, which are amortized to interest expense over the respective terms of such senior notes.

[0001730168-22-000118:notes:187]
April 2022 Senior Notes

[0001730168-22-000118:notes:188]
In April 2022, we issued $750 million of 4.000% senior unsecured notes due April 2029 and $1,200 million of 4.150% senior unsecured notes due April 2032. Using the net proceeds, we redeemed the outstanding balance of $1,020 million of our 4.700% notes due 2025 and $944 million of our 4.250% notes due 2026. As a result of these redemptions, we incurred premiums of $85 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense.

[0001730168-22-000118:notes:189]
In April 2022, we issued $2,500 million of 4.926% senior unsecured notes due May 2037 in exchange for $2,502 million of certain of our outstanding notes maturing between 2027 and 2030. As a result of this exchange, we paid premiums of $47 million, which were included in unamortized discount and issuance costs. The 4.926% notes due 2037, the 4.000% notes due 2029 and the 4.150% notes due 2032 are collectively referred as the “April 2022 Senior Notes.”

[0001730168-22-000118:notes:190]
We may redeem or purchase, in whole or in part, any of the April 2022 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the April 2022 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-22-000118:notes:191]
September 2021 Senior Notes

[0001730168-22-000118:notes:192]
In September 2021, we completed our private offers to exchange $6.0 billion of certain of our outstanding notes maturing between 2025 and 2030 for $3,250 million of 3.137% senior unsecured notes due November 2035 and $2,750 million of 3.187% senior unsecured notes due November 2036 (collectively, the “September 2021 Senior Notes”). As a result of this exchange, we paid premiums of $762 million, which were included in unamortized discount and issuance costs. We

[0001730168-22-000118:notes:193]
may redeem or purchase, in whole or in part, any of the September 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the September 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-22-000118:notes:194]
March 2021 Senior Notes

[0001730168-22-000118:notes:195]
In March 2021, we completed our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “March 2021 Exchange Offer”) for $2,250 million of 3.419% senior unsecured notes due April 2033 and $3,250 million of 3.469% senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of this exchange, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. We may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-22-000118:notes:196]
In connection with the March 2021 Exchange Offer, Broadcom Corporation (“BRCM”) and Broadcom Technologies Inc. (“BTI”) were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes, as defined below respectively.

[0001730168-22-000118:notes:197]
January 2021 Senior Notes

[0001730168-22-000118:notes:198]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). We may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest.

[0001730168-22-000118:notes:199]
Using the net proceeds from the January 2021 Senior Notes, we repaid the outstanding balance of $5,888 million of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”), repurchased $3,830 million of certain of our outstanding notes maturing between 2021 and 2023 through a cash tender offer and redemption, and repaid $282 million of our 2.200% notes upon maturity in January 2021. As a result of these repayments and repurchases, we incurred premiums of $151 million and wrote off $47 million of unamortized discount and issuance costs, both of which were included in interest expense.

[0001730168-22-000118:notes:200]
January 2021 Credit Agreement

[0001730168-22-000118:notes:201]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019 (the “May 2019 Credit Agreement”), which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. We had no borrowings outstanding under the Revolving Facility at either October 30, 2022 or October 31, 2021.

[0001730168-22-000118:notes:202]
June 2020 Senior Notes

[0001730168-22-000118:notes:203]
In June 2020, we completed our private offers to exchange $3,742 million of certain series of our outstanding notes maturing between 2021 and 2024 for $1,695 million of senior notes due 2026 and $2,222 million of senior notes due 2028 (collectively, the “June 2020 Senior Notes”). As a result of this exchange, we paid premiums of $177 million, which were included in unamortized discount and issuance costs. We may redeem or purchase, in whole or in part, any of the June 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the June 2020 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-22-000118:notes:204]
May 2020 Senior Notes

[0001730168-22-000118:notes:205]
In May 2020, we issued $8 billion of senior unsecured notes (the “May 2020 Senior Notes”). We may redeem or purchase, in whole or in part, any of the May 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the May 2020 Senior Notes, plus accrued and

[0001730168-22-000118:notes:206]
unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-22-000118:notes:207]
The net proceeds from this issuance, together with the remaining net proceeds from the issuance of the April 2020 Senior Notes, as defined below, were used to repay an aggregate of $5,424 million of term loans outstanding under the November 2019 Credit Agreement, consisting of repayments of $2,712 million of each of our unsecured term A-3 and A-5 facilities and $3 billion of borrowings outstanding under the unsecured revolving credit facility provided by the May 2019 Credit Agreement. During fiscal year 2020, we wrote off $60 million of unamortized discount and issuance costs as a result of repayments of term loans outstanding under the November 2019 Credit Agreement, which were included in interest expense.

[0001730168-22-000118:notes:208]
April 2020 Senior Notes

[0001730168-22-000118:notes:209]
In April 2020, we issued $4.5 billion of senior unsecured notes (the “April 2020 Senior Notes”). We may redeem or purchase, in whole or in part, any of the April 2020 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the April 2020 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-22-000118:notes:210]
Pursuant to a cash tender offer that we completed in April 2020, we repurchased certain of outstanding notes maturing between 2021 and 2022 with the net proceeds from the April 2020 Senior Notes. As a result of these repurchases, we incurred premiums of $78 million and wrote off $15 million of unamortized discount and issuance costs, both of which were included in interest expense.

[0001730168-22-000118:notes:211]
April 2019 Senior Notes

[0001730168-22-000118:notes:212]
In April 2019, we issued $11 billion of senior unsecured notes (the “April 2019 Senior Notes”). We may redeem or purchase, in whole or in part, any of the April 2019 Senior Notes prior to their respective maturities, subject to a make-whole premium determined in accordance with the indenture governing the April 2019 Senior Notes, plus accrued and unpaid interest.

[0001730168-22-000118:notes:213]
Registered Exchange Offer

[0001730168-22-000118:notes:214]
In connection with the issuance of the June 2020 Senior Notes, the May 2020 Senior Notes, the April 2020 Senior Notes (collectively, the “2020 Senior Notes”) and the April 2019 Senior Notes, we entered into registration rights agreements, pursuant to which we were obligated to use commercially reasonable efforts to file with the Securities and Exchange Commission (the “SEC”), and cause to be declared effective, a registration statement with respect to an offer to exchange (the “Registered Exchange Offer”) each series of the 2020 Senior Notes and the April 2019 Senior Notes for notes that are registered with the SEC (the “Registered Notes”), with substantially identical terms. We completed the Registered Exchange Offer on August 10, 2020. Substantially all of our 2020 Senior Notes and April 2019 Senior Notes were tendered and exchanged for the corresponding Registered Notes in the Registered Exchange Offer.

[0001730168-22-000118:notes:215]
Commercial Paper

[0001730168-22-000118:notes:216]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under our revolving credit facility. We had no Commercial Paper outstanding at either October 30, 2022 or October 31, 2021.

[0001730168-22-000118:notes:217]
2017 Senior Notes

[0001730168-22-000118:notes:218]
During the fiscal year ended October 29, 2017, Broadcom Cayman Finance Limited, which subsequently merged into BTI during fiscal year 2019 with BTI remaining as the surviving entity, and BRCM issued $17,550 million of senior unsecured notes (the “2017 Senior Notes”). Our 2017 Senior Notes are fully and unconditionally guaranteed, jointly and severally, on an unsecured, unsubordinated basis by Broadcom and BTI. We may redeem or purchase, in whole or in part, any of the 2017 Senior Notes prior to their respective maturities, subject to a make-whole premium determined in accordance with the indenture governing the 2017 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-22-000118:notes:219]
During the fiscal year ended November 4, 2018, substantially all of the 2017 Senior Notes were tendered and exchanged for notes registered with the SEC, with substantially identical terms.

[0001730168-22-000118:notes:220]
Assumed CA Senior Notes

[0001730168-22-000118:notes:221]
In connection with our acquisition of CA, Inc. (“CA”) during fiscal year 2019, we assumed $2.25 billion of CA’s outstanding senior unsecured notes (the “Assumed CA Senior Notes”). CA remains the sole obligor under the Assumed CA Senior Notes. We may redeem all or a portion of the Assumed CA Senior Notes at any time, subject to a specified make-whole premium as set forth with the indenture governing the Assumed CA Senior Notes. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes plus accrued and unpaid interest.

[0001730168-22-000118:notes:222]
Fair Value of Debt

[0001730168-22-000118:notes:223]
As of October 30, 2022, the estimated aggregate fair value of our debt was $33,014 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-22-000118:notes:224]
Future Principal Payments of Debt

[0001730168-22-000118:notes:225]
The future scheduled principal payments of debt as of October 30, 2022 were as follows:

[0001730168-22-000118:notes:226]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2023 |  | $ | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 495 |  |
| 2026 |  | 1,652 |  |
| 2027 |  | 3,137 |  |
| Thereafter |  | 33,968 |  |
| Total |  | $ | 41,218 |  |

[0001730168-22-000118:notes:227]
As of October 30, 2022 and October 31, 2021, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-22-000118:notes:228]
Stockholders’ Equity 
Mandatory Convertible Preferred Stock

[0001730168-22-000118:notes:229]
On September 30, 2019, we completed an offering of approximately 4 million shares of 8.00% Mandatory Convertible Preferred Stock, Series A, $0.001 par value per share (“Mandatory Convertible Preferred Stock”), which generated net proceeds of approximately $3,679 million and would automatically convert into shares of our common stock on September 30, 2022. At any time prior to September 30, 2022, holders could elect to convert each share of Mandatory Convertible Preferred Stock at the then minimum conversion rate. The conversion rates were subject to anti-dilution adjustments.

[0001730168-22-000118:notes:230]
The holders of Mandatory Convertible Preferred Stock were entitled to receive, when, as and if declared by our Board of Directors, or an authorized committee thereof, out of funds legally available for payment, cumulative dividends at the annual rate of 8.00% of the liquidation preference of $1,000 per share (equivalent to $80 annually per share), payable in cash or, subject to certain limitations, by delivery of shares of our common stock or any combination of cash and shares of our common stock, at our election; provided, however, that any undeclared and unpaid dividends will continue to accumulate.

[0001730168-22-000118:notes:231]
Subject to limited exceptions, no dividends may be declared or paid on shares of our common stock, unless all accumulated dividends have been paid or set aside for payment on all outstanding shares of our Mandatory Convertible Preferred Stock for all past completed dividend periods. In the event of our voluntary or involuntary liquidation, dissolution or winding-up, no distribution of our assets may be made to holders of our common stock until we have paid to holders of our Mandatory Convertible Preferred Stock a liquidation preference equal to $1,000 per share plus accumulated and unpaid dividends.

[0001730168-22-000118:notes:232]
During fiscal year 2022, outstanding shares of our Mandatory Convertible Preferred Stock converted into an aggregate of approximately 12 million shares of our common stock at conversion rates ranging between 3.0894 and 3.1149 common shares per share of Mandatory Convertible Preferred Stock. We paid cash in lieu of fractional shares of common stock upon conversion.

[0001730168-22-000118:notes:233]
As of October 31, 2021, we recognized $27 million of accrued preferred stock dividends, which was presented as temporary equity on our consolidated balance sheet.

[0001730168-22-000118:notes:234]
Cash Dividends Declared and Paid

[0001730168-22-000118:notes:235]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 16.40 |  |  | $ | 14.40 |  |  | $ | 13.00 |  |
| Dividends to common stockholders |  | $ | 6,733 |  |  | $ | 5,913 |  |  | $ | 5,235 |  |
| Dividends per share to preferred stockholders |  | $ | 80.00 |  |  | $ | 80.00 |  |  | $ | 80.00 |  |
| Dividends to preferred stockholders |  | $ | 299 |  |  | $ | 299 |  |  | $ | 299 |  |

[0001730168-22-000118:notes:236]
Stock Repurchase Program

[0001730168-22-000118:notes:237]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. During fiscal year 2022, we repurchased and retired approximately 12 million shares of our common stock for $7 billion under this stock repurchase program.

[0001730168-22-000118:notes:238]
In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023.

[0001730168-22-000118:notes:239]
Repurchases under our stock repurchase programs may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-22-000118:notes:240]
Equity Incentive Award Plan

[0001730168-22-000118:notes:241]
2012 Plan

[0001730168-22-000118:notes:242]
In connection with the acquisition of BRCM, we assumed the BRCM 2012 Stock Incentive Plan (the “Original 2012 Plan”) and outstanding unvested RSUs originally granted by BRCM under the Original 2012 Plan that were held by continuing employees. During the second quarter of fiscal year 2021, our stockholders approved the amendment and restatement of the Original 2012 Plan, now called Broadcom Inc. 2012 Stock Incentive Plan (the “Amended 2012 Plan”). Under the Amended 2012 Plan, we may grant to employees stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, restricted stock awards and RSUs. No participant may be granted such awards for more than an aggregate of 4 million shares in any fiscal year. Equity awards granted under the Amended 2012 Plan generally vest over four years. The Amended 2012 Plan reduced the number of shares available for new equity award grants to 20 million shares and removed the annual share replenishment provision provided under the Original 2012 Plan. Awards cancelled or forfeited and shares withheld to satisfy tax withholding obligations become available for future issuance. As of October 30, 2022, 21 million shares remained available for issuance under the Amended 2012 Plan.

[0001730168-22-000118:notes:243]
We may grant market-based RSUs with both a service condition and a market condition as part of our equity compensation programs. The market-based RSUs generally vest over four years, subject to satisfaction of market conditions. During fiscal years 2022, 2021 and 2020, we granted market-based RSUs under which grantees may receive the number of shares ranging from 0% to 300% of the original grant at vesting based upon the total stockholder return (“TSR”) on our common stock on an absolute basis and as compared to the TSR of an index group of companies.

[0001730168-22-000118:notes:244]
Employee Stock Purchase Plan

[0001730168-22-000118:notes:245]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in us through periodic payroll deductions, based on a 6-month look-back period, at a price equal to the lesser of 85% of the fair market value of our common stock at either the beginning or the end of the relevant offering period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the ESPP is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974.

[0001730168-22-000118:notes:246]
Stock-Based Compensation Expense

[0001730168-22-000118:notes:247]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 65 |  |  | $ | 78 |  |  | $ | 109 |  |
| Cost of subscriptions and services |  | 82 |  |  | 65 |  |  | 50 |  |
| Research and development |  | 1,048 |  |  | 1,199 |  |  | 1,419 |  |
| Selling, general and administrative |  | 338 |  |  | 362 |  |  | 398 |  |
| Total stock-based compensation expense |  | $ | 1,533 |  |  | $ | 1,704 |  |  | $ | 1,976 |  |
| Estimated income tax benefits for stock-based compensation |  | $ | 255 |  |  | $ | 283 |  |  | $ | 345 |  |
| Excess income tax benefits for stock-based awards exercised or released |  | $ | 375 |  |  | $ | 310 |  |  | $ | 147 |  |

[0001730168-22-000118:notes:248]
We have assumed an annualized forfeiture rate for RSUs of 5%. We will recognize additional expense if actual forfeitures are lower than we estimated, and will recognize a benefit if actual forfeitures are higher than we estimated.

[0001730168-22-000118:notes:249]
During the first quarter of fiscal year 2019, the Compensation Committee of our Board of Directors approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. Stock-based compensation expense related to the Multi-Year Equity Awards was $794 million, $816 million and $902 million for fiscal years 2022, 2021 and 2020, respectively.

[0001730168-22-000118:notes:250]
As of October 30, 2022, the total unrecognized compensation cost related to unvested stock-based awards was $2,704 million, which is expected to be recognized over the remaining weighted-average service period of 2.7 years.

[0001730168-22-000118:notes:251]
The following table summarizes the weighted-average assumptions utilized to calculate the fair value of market-based awards granted in the periods presented:

[0001730168-22-000118:notes:252]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
| Risk-free interest rate |  | 1.4 | % |  | 0.3 | % |  | 1.2 | % |
| Dividend yield |  | 2.7 | % |  | 3.0 | % |  | 4.7 | % |
| Volatility |  | 37.1 | % |  | 39.0 | % |  | 31.2 | % |
| Expected term (in years) |  | 3.4 |  | 3.4 |  | 4.0 |

[0001730168-22-000118:notes:253]
The risk-free interest rate was derived from the average U.S. Treasury Strips rate, which approximated the rate in effect appropriate for the term at the time of grant.

[0001730168-22-000118:notes:254]
The dividend yield was based on the historical and expected dividend payouts as of the respective award grant dates.

[0001730168-22-000118:notes:255]
The volatility was based on our own historical stock price volatility over the period commensurate with the expected life of the awards and the implied volatility of a 180-day call option on our own common stock measured at a specific date.

[0001730168-22-000118:notes:256]
The expected term was commensurate with the awards’ contractual terms.

[0001730168-22-000118:notes:257]
Restricted Stock Unit Awards

[0001730168-22-000118:notes:258]
A summary of time- and market-based RSU activity is as follows:

[0001730168-22-000118:notes:259]
|  |  | Number of RSUsOutstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |
|  |  | (In millions, except per share data) |
| Balance as of November 3, 2019 |  | 40 |  |  | $ | 188.52 |  |  |  |
| Granted |  | 3 |  |  | $ | 252.36 |  |  |  |
| Vested |  | (8) |  |  | $ | 210.84 |  |  |  |
| Forfeited |  | (3) |  |  | $ | 198.17 |  |  |  |
| Balance as of November 1, 2020 |  | 32 |  |  | $ | 188.35 |  |  |  |
| Granted |  | 2 |  |  | $ | 408.69 |  |  |  |
| Vested |  | (8) |  |  | $ | 214.15 |  |  |  |
| Forfeited |  | (3) |  |  | $ | 189.84 |  |  |  |
| Balance as of October 31, 2021 |  | 23 |  |  | $ | 200.38 |  |  |  |
| Granted |  | 3 |  |  | $ | 527.69 |  |  |  |
| Vested |  | (7) |  |  | $ | 225.52 |  |  |  |
| Forfeited |  | (1) |  |  | $ | 242.82 |  |  |  |
| Balance as of October 30, 2022 |  | 18 |  |  | $ | 238.49 |  |  |  |

[0001730168-22-000118:notes:260]
The aggregate fair value of time- and market-based RSUs that vested in fiscal years 2022, 2021 and 2020 was $4,207 million, $3,715 million, and $2,254 million, respectively, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.

[0001730168-22-000118:notes:261]
Stock Option Awards

[0001730168-22-000118:notes:262]
As of October 30, 2022, our stock options outstanding were not material. The aggregate intrinsic value of stock options exercised in fiscal years 2022, 2021 and 2020 was $3 million, $339 million, and $917 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-22-000118:notes:263]
Income Taxes 
The components of income from continuing operations before income taxes by U.S. and foreign jurisdictions were as follows:

[0001730168-22-000118:notes:264]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Domestic loss |  | $ | (2,020) |  |  | $ | (3,103) |  |  | $ | (4,221) |  |
| Foreign income |  | 14,454 |  |  | 9,868 |  |  | 6,664 |  |
| Income from continuing operations before income taxes |  | $ | 12,434 |  |  | $ | 6,765 |  |  | $ | 2,443 |  |

[0001730168-22-000118:notes:265]
The components of the provision for and benefit from income taxes were as follows:

[0001730168-22-000118:notes:266]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Current tax expense: |  |  |  |  |  |  |
| Federal |  | $ | 174 |  |  | $ | 446 |  |  | $ | 7 |  |
| State |  | 48 |  |  | 46 |  |  | 51 |  |
| Foreign |  | 762 |  |  | 534 |  |  | 506 |  |
| Total |  | 984 |  |  | 1,026 |  |  | 564 |  |
| Deferred tax expense (benefit from): |  |  |  |  |  |  |
| Federal |  | 68 |  |  | (876) |  |  | (627) |  |
| State |  | (15) |  |  | (114) |  |  | (161) |  |
| Foreign |  | (98) |  |  | (7) |  |  | (294) |  |
| Total |  | (45) |  |  | (997) |  |  | (1,082) |  |
| Total provision for (benefit from) income taxes |  | $ | 939 |  |  | $ | 29 |  |  | $ | (518) |  |

[0001730168-22-000118:notes:267]
The following is a reconciliation of our effective tax rate to the statutory federal tax rate:

[0001730168-22-000118:notes:268]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
| Statutory tax rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State, net of federal benefit |  | 0.2 |  |  | (0.8) |  |  | (3.6) |  |
| Foreign income taxed at different rates |  | (19.1) |  |  | (22.8) |  |  | (48.6) |  |
| Deemed inclusion of foreign earnings |  | 9.4 |  |  | 12.7 |  |  | 23.3 |  |
| Foreign-derived intangible income deduction |  | — |  |  | (3.1) |  |  | (1.5) |  |
| Deferred taxes on unremitted foreign earnings |  | 0.1 |  |  | (0.7) |  |  | (1.1) |  |
| Excess tax benefits from stock-based compensation |  | (3.0) |  |  | (4.6) |  |  | (6.0) |  |
| Research and development credit |  | (1.4) |  |  | (2.3) |  |  | (4.3) |  |
| Other, net |  | 0.3 |  |  | 1.0 |  |  | (0.4) |  |
| Effective tax rate on income before income taxes |  | 7.5 | % |  | 0.4 | % |  | (21.2) | % |

[0001730168-22-000118:notes:269]
The increase in provision for income taxes in fiscal year 2022 compared to fiscal year 2021 was primarily due to higher income from continuing operations.

[0001730168-22-000118:notes:270]
The provision for income taxes in fiscal year 2021 compared to the benefit from income taxes in fiscal year 2020 was primarily due to higher income from continuing operations, offset in part by higher excess tax benefits from stock-based awards. The benefit from income taxes in fiscal year 2020 was primarily due to jurisdictional mix of income and expenses, discrete benefits from the remeasurement of certain deferred tax assets and liabilities in a foreign jurisdiction, and excess tax benefits from stock-based awards.

[0001730168-22-000118:notes:271]
Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are expected to expire in November 2025.

[0001730168-22-000118:notes:272]
We have also obtained a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028. The tax holiday that we negotiated in Malaysia is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such conditions specified, we will lose the related tax benefits and we could be required to refund previously realized material tax benefits.

[0001730168-22-000118:notes:273]
Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to decrease the provision for income taxes by approximately $1,821 million and $1,156 million for fiscal years 2022 and 2021, respectively, and increase the benefit from income taxes by approximately $833 million for fiscal year 2020.

[0001730168-22-000118:notes:274]
Significant components of our deferred tax assets and liabilities consisted of the following:

[0001730168-22-000118:notes:275]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Deferred income tax assets: |  |  |  |  |
| Net operating loss, credit and other carryforwards |  | $ | 1,808 |  |  | $ | 1,774 |  |
| Deferred revenue |  | 645 |  |  | 1,332 |  |
| Employee stock awards |  | 183 |  |  | 192 |  |
| Other deferred income tax assets |  | 499 |  |  | 446 |  |
| Gross deferred income tax assets |  | 3,135 |  |  | 3,744 |  |
| Less: valuation allowance |  | (1,777) |  |  | (1,782) |  |
| Deferred income tax assets |  | 1,358 |  |  | 1,962 |  |
| Deferred income tax liabilities: |  |  |  |  |
| Depreciation and amortization |  | 341 |  |  | 847 |  |
| Unamortized discount and issuance costs |  | 322 |  |  | 374 |  |
| Foreign earnings not indefinitely reinvested |  | 86 |  |  | 73 |  |
| Other deferred income tax liabilities |  | 36 |  |  | — |  |
| Deferred income tax liabilities |  | 785 |  |  | 1,294 |  |
| Net deferred income tax assets |  | $ | 573 |  |  | $ | 668 |  |

[0001730168-22-000118:notes:276]
We continue to indefinitely reinvest $2,112 million of certain accumulated foreign earnings. The unrecognized deferred income tax liability related to these earnings is estimated to be $222 million. All other current and future earnings of all our foreign subsidiaries are not considered permanently reinvested.

[0001730168-22-000118:notes:277]
As of October 30, 2022, we had tax effected U.S. state net operating loss carryforwards of $200 million and foreign net operating loss carryforwards of $190 million, all of which expire in various years beginning fiscal year 2023. We had $1,334 million of state research and development tax credits which begin to expire in fiscal year 2023. We have provided a valuation allowance on substantially all state tax credits and state and foreign net operating loss carryforwards as we do not expect them to be realized.

[0001730168-22-000118:notes:278]
Uncertain Tax Positions

[0001730168-22-000118:notes:279]
The following table reconciles the beginning and ending balance of gross unrecognized tax benefits:

[0001730168-22-000118:notes:280]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Beginning balance |  | $ | 5,030 |  |  | $ | 4,748 |  |  | $ | 4,422 |  |
| Lapses of statutes of limitations |  | (50) |  |  | (58) |  |  | (95) |  |
| Increases in balances related to tax positions taken during prior periods (including those related to acquisitions made during the year) |  | — |  |  | 41 |  |  | 98 |  |
| Decreases in balances related to tax positions taken during prior periods |  | (113) |  |  | — |  |  | (14) |  |
| Increases in balances related to tax positions taken during current period |  | 288 |  |  | 337 |  |  | 379 |  |
| Decreases in balances related to settlements with taxing authorities |  | (38) |  |  | (38) |  |  | (42) |  |
| Ending balance |  | $ | 5,117 |  |  | $ | 5,030 |  |  | $ | 4,748 |  |

[0001730168-22-000118:notes:281]
We recognize interest and penalties related to unrecognized tax benefits within the provision for (benefit from) income taxes. Accrued interest and penalties were included within other long-term liabilities. During fiscal years 2022 and 2021, we recognized interest and penalties of $25 million and $46 million, respectively, within the provision for income taxes. During fiscal year 2020, we recognized interest and penalties of $37 million within the benefit from income taxes. As of October 30, 2022 and October 31, 2021, the combined amount of cumulative accrued interest and penalties was approximately $411 million and $386 million, respectively.
As of October 30, 2022 and October 31, 2021, approximately $5,528 million and $5,416 million, respectively, of the unrecognized tax benefits and accrued interest and penalties would, if recognized, benefit our effective income tax rate. We are subject to U.S. income tax examination for fiscal years 2015 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $163 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-22-000118:notes:282]
Reportable Segments

[0001730168-22-000118:notes:283]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment has separate financial information that is utilized on a regular basis by the CODM in determining how to allocate resources and evaluate performance. The reportable segments are determined based on several factors including, but not limited to, customer base, homogeneity of products, technology, delivery channels and similar economic characteristics.

[0001730168-22-000118:notes:284]
Semiconductor solutions. We provide semiconductor solutions for managing the movement of data in data center, service provider, enterprise and embedded networking applications. We provide a broad variety of radio frequency semiconductor devices, wireless connectivity solutions, custom touch controllers, and inductive charging solutions for mobile applications. We also provide semiconductor solutions for enabling the set-top box and broadband access markets and for enabling secure movement of digital data to and from host machines, such as servers, personal computers and storage systems, to the underlying storage devices, such as hard disk drives and solid state drives. We also provide a broad variety of products for the general industrial and automotive markets. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-22-000118:notes:285]
Infrastructure software. We provide a portfolio of software solutions that enables customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical FC SAN products and related software.

[0001730168-22-000118:notes:286]
Our CODM assesses the performance of each segment and allocates resources to each segment based on net revenue and operating results and does not evaluate each segment using discrete asset information. Operating results by segment include items that are directly attributable to each segment and also include shared expenses such as marketing, general and administrative activities, facilities and information technology (“IT”) expenses. Shared expenses are primarily allocated based on revenue, headcount or evenly between the segments.

[0001730168-22-000118:notes:287]
Unallocated Expenses

[0001730168-22-000118:notes:288]
Unallocated expenses include amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Acquisition-related costs include transaction costs and any costs directly related to the acquisition and integration of acquired businesses.

[0001730168-22-000118:notes:289]
Depreciation expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation expense by operating segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the summary of significant accounting policies.

[0001730168-22-000118:notes:290]
|  |  | Fiscal Year |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 25,818 |  |  | $ | 20,383 |  |  | $ | 17,267 |  |
| Infrastructure software |  | 7,385 |  |  | 7,067 |  |  | 6,621 |  |
| Total net revenue |  | $ | 33,203 |  |  | $ | 27,450 |  |  | $ | 23,888 |  |
| Operating income: |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 15,075 |  |  | $ | 10,976 |  |  | $ | 8,576 |  |
| Infrastructure software |  | 5,219 |  |  | 4,936 |  |  | 4,363 |  |
| Unallocated expenses |  | (6,069) |  |  | (7,393) |  |  | (8,925) |  |
| Total operating income |  | $ | 14,225 |  |  | $ | 8,519 |  |  | $ | 4,014 |  |

[0001730168-22-000118:notes:291]
Geographic Information

[0001730168-22-000118:notes:292]
Net revenue by country is based primarily on the geographic shipment or delivery location as specified by the distributors, OEMs, contract manufacturers, channel partners, or software customers who purchased our products or services. For the majority of our products, title and control transfer to our customers in Penang, Malaysia. The products are then transported to the customer specific locations. Net revenue from the United States for fiscal years 2022, 2021 and 2020 was $5,915 million, $5,285 million and $4,778 million, respectively. Net revenue from China (including Hong Kong) for fiscal years 2022, 2021 and 2020 was $11,637 million, $9,752 million and $7,808 million, respectively. Net revenue from Singapore for fiscal years 2022 and 2021 was $4,003 million and $2,754 million, respectively (the amount was less than 10% for fiscal year 2020). Net revenue from other foreign countries for fiscal years 2022, 2021 and 2020 was $11,648 million, $9,659 million and $11,302 million, respectively. These geographic delivery locations are not necessarily indicative of the geographic location of our end customers or the country in which our end customers sell devices containing our products. For example, we believe a substantial portion of our products shipped or delivered to China (including Hong Kong) is included in devices sold by our end customers in the United States and Europe.

[0001730168-22-000118:notes:293]
Long-lived assets include property, plant and equipment and are based on the physical location of the assets.

[0001730168-22-000118:notes:294]
|  |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |
| Long-lived assets: |  |  |  |  |
| United States |  | $ | 1,441 |  |  | $ | 1,540 |  |
| Taiwan |  | 318 |  |  | 313 |  |
| Other |  | 464 |  |  | 495 |  |
| Total long-lived assets |  | $ | 2,223 |  |  | $ | 2,348 |  |

[0001730168-22-000118:notes:295]
Significant Customer Information
We sell our products through our direct sales force and a select network of distributors and channel partners globally.  Two customers accounted for 15% and 11% of our net accounts receivable balance as of October 30, 2022. No customer accounted for more than 10% of our net accounts receivable balance as of October 31, 2021. During fiscal years 2022, 2021 and 2020, one customer accounted for 20%, 18% and 13% of our net revenue, respectively. Revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-22-000118:notes:296]
Commitments

[0001730168-22-000118:notes:297]
The following table summarizes contractual obligations and commitments as of October 30, 2022:

[0001730168-22-000118:notes:298]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  | (In millions) |
| 2023 |  | $ | 199 |  |  | $ | 304 |  |
| 2024 |  | 211 |  |  | 261 |  |
| 2025 |  | 90 |  |  | 147 |  |
| 2026 |  | 11 |  |  | 162 |  |
| 2027 |  | 7 |  |  | 112 |  |
| Thereafter |  | 7 |  |  | 447 |  |
| Total |  | $ | 525 |  |  | $ | 1,433 |  |

[0001730168-22-000118:notes:299]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

[0001730168-22-000118:notes:300]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-22-000118:notes:301]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at October 30, 2022, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,229 million of unrecognized tax benefits and accrued interest and penalties classified within other long-term liabilities on our consolidated balance sheet as of October 30, 2022 have been excluded from the table above.

[0001730168-22-000118:notes:302]
Contingencies

[0001730168-22-000118:notes:303]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-22-000118:notes:304]
Lawsuits Relating to California Institute of Technology

[0001730168-22-000118:notes:305]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple appealed to the United States Court of

[0001730168-22-000118:notes:306]
Appeals for the Federal Circuit (the “Federal Circuit Court”). In February 2022, the Federal Circuit Court affirmed infringement of two patents, both of which expired in August 2020, but it did not address all issues and ordered a new trial on damages and on the infringement of the 7,916,781 patent, which also expired in August 2020. In May 2022, the Federal Circuit Court denied the petition for rehearing filed by Broadcom and Apple, and remanded the case to the U.S. Central District Court. Subsequently, Caltech withdrew its infringement allegations as to the 7,916,781 patent.

[0001730168-22-000118:notes:307]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement. We cannot reasonably estimate the ultimate outcome as the Federal Circuit Court vacated the above damages, and a number of factors (including a retrial at the lower court and further appeals) could significantly change the assessment of damages. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards.

[0001730168-22-000118:notes:308]
Other Matters

[0001730168-22-000118:notes:309]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-22-000118:notes:310]
Contingency Assessment

[0001730168-22-000118:notes:311]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-22-000118:notes:312]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our consolidated financial statements.

[0001730168-22-000118:notes:313]
Other Indemnifications

[0001730168-22-000118:notes:314]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-22-000118:notes:315]
Restructuring, Impairment and Disposal Charges 
Restructuring Charges

[0001730168-22-000118:notes:316]
From time to time, we initiate cost reduction activities to integrate acquired businesses, to align our workforce with strategic business activities, or to improve efficiencies in our operations. We recognized charges of $55 million, $149 million and $233 million during fiscal years 2022, 2021 and 2020, respectively. These charges were primarily recognized in operating expenses.

[0001730168-22-000118:notes:317]
The following table summarizes the significant activities within, and components of, the restructuring liabilities:

[0001730168-22-000118:notes:318]
|  |  | Employee Termination Costs |  | Other Exit Costs(a) |  | Total |
|  |  | (In millions) |
| Balance as of November 3, 2019 |  | $ | 69 |  |  | $ | 39 |  |  | $ | 108 |  |
| Restructuring charges(b) |  | 186 |  |  | 47 |  |  | 233 |  |
| Utilization |  | (221) |  |  | (50) |  |  | (271) |  |
| Effect of adoption of Topic 842(c) |  | — |  |  | (36) |  |  | (36) |  |
| Balance as of November 1, 2020 |  | 34 |  |  | — |  |  | 34 |  |
| Restructuring charges |  | 100 |  | 13 |  | 113 |
| Utilization |  | (130) |  |  | (13) |  |  | (143) |  |
| Balance as of October 31, 2021 |  | 4 |  |  | — |  |  | 4 |  |
| Restructuring charges |  | 24 |  |  | 6 |  |  | 30 |  |
| Utilization |  | (24) |  |  | (4) |  |  | (28) |  |
| Balance as of October 30, 2022 |  | $ | 4 |  |  | $ | 2 |  |  | $ | 6 |  |

[0001730168-22-000118:notes:319]
(a)Included $30 million of restructuring expense related to the write-down of certain lease-related ROU assets and other lease-related charges during fiscal year 2020.

[0001730168-22-000118:notes:320]
(b)Included $19 million of restructuring expense related to discontinued operations recognized during fiscal year 2020, which was included in loss from discontinued operations.

[0001730168-22-000118:notes:321]
(c)Upon adoption of Topic 842, certain restructuring lease liabilities were required to be recognized as a reduction to the corresponding ROU assets.

[0001730168-22-000118:notes:322]
Restructuring, impairment and disposal charges in our consolidated statement of operations for the fiscal years 2022 and 2021 included $25 million and $36 million, respectively, for the write-down of certain lease-related ROU assets and other lease-related charges. As of each October 30, 2022 and October 31, 2021, short-term and long-term lease liabilities included $52 million of liabilities related to restructuring activities.

[0001730168-22-000118:notes:323]
Impairment and Disposal Charges

[0001730168-22-000118:notes:324]
During fiscal years 2022, 2021 and 2020, impairment and disposal charges of $7 million, $16 million and $19 million, respectively, primarily related to leasehold improvements.


## us-gaap:SubsequentEventsTextBlock

[0001730168-22-000118:notes:325]
Subsequent Events 
Cash Dividends Declared

[0001730168-22-000118:notes:326]
On December 6, 2022, our Board of Directors declared a quarterly cash dividend of $4.60 per share on our common stock, payable on December 30, 2022 to stockholders of record on December 20, 2022.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001730168-22-000118:notes:327]
Schedule II — Valuation and Qualifying Accounts

[0001730168-22-000118:notes:328]
|  |  | Balance atBeginningof Period |  | Additions to Allowances |  | ChargesUtilized/Write-offs |  | Balance atEnd ofPeriod |
|  |  | (In millions) |
| Accounts receivable allowances: |  |  |  |  |  |  |  |  |
| Distributor credit allowances (1) |  |  |  |  |  |  |  |  |
| Fiscal year ended October 30, 2022 |  | $ | 128 |  |  | $ | 484 |  |  | $ | (487) |  |  | $ | 125 |  |
| Fiscal year ended October 31, 2021 |  | $ | 149 |  |  | $ | 756 |  |  | $ | (777) |  |  | $ | 128 |  |
| Fiscal year ended November 1, 2020 |  | $ | 153 |  |  | $ | 696 |  |  | $ | (700) |  |  | $ | 149 |  |
| Other accounts receivable allowances (2) |  |  |  |  |  |  |  |  |
| Fiscal year ended October 30, 2022 |  | $ | 2 |  |  | $ | 10 |  |  | $ | (11) |  |  | $ | 1 |  |
| Fiscal year ended October 31, 2021 |  | $ | 28 |  |  | $ | 14 |  |  | $ | (40) |  |  | $ | 2 |  |
| Fiscal year ended November 1, 2020 |  | $ | 38 |  |  | $ | 84 |  |  | $ | (94) |  |  | $ | 28 |  |
| Income tax valuation allowances: |  |  |  |  |  |  |  |  |
| Fiscal year ended October 30, 2022 |  | $ | 1,782 |  |  | $ | 118 |  |  | $ | (123) |  |  | $ | 1,777 |  |
| Fiscal year ended October 31, 2021 |  | $ | 1,707 |  |  | $ | 121 |  |  | $ | (46) |  |  | $ | 1,782 |  |
| Fiscal year ended November 1, 2020 |  | $ | 1,563 |  |  | $ | 149 |  |  | $ | (5) |  |  | $ | 1,707 |  |

[0001730168-22-000118:notes:329]
________________________________

[0001730168-22-000118:notes:330]
(1)Distributor credit allowances relate to price adjustments and other allowances.

[0001730168-22-000118:notes:331]
(2)Other accounts receivable allowances primarily include sales returns and allowance for doubtful accounts.
