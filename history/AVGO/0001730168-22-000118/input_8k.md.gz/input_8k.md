# AVGO 8-K — 0001730168-22-000110 filed 2022-12-08

## item codes, every 8-K on or before 2022-12-16

- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2022-12-16

- none on or before 2022-12-16

## item 2.02 — earnings release, exhibit 99.1

[0001730168-22-000110:8k_2_02:1]
EX-99.1
2
avgo-10302022x8kxex99.htm
EX-99.1

[0001730168-22-000110:8k_2_02:2]
Document

[0001730168-22-000110:8k_2_02:3]
Exhibit 99.1

[0001730168-22-000110:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2022 Financial Results and Quarterly Dividend

[0001730168-22-000110:8k_2_02:5]
•Cash from operations of $4,583 million for the fourth quarter, less capital expenditures of $122 million, resulted in $4,461 million of free cash flow, or 50 percent of revenue

[0001730168-22-000110:8k_2_02:6]
•Quarterly common stock dividend increased by 12 percent to $4.60 from the prior quarter

[0001730168-22-000110:8k_2_02:7]
•Revenue of $8,930 million for the fourth quarter, up 21 percent from the prior year period

[0001730168-22-000110:8k_2_02:8]
•GAAP net income of $3,359 million for the fourth quarter; Adjusted EBITDA of $5,722 million for the fourth quarter

[0001730168-22-000110:8k_2_02:9]
•GAAP diluted EPS of $7.83 for the fourth quarter; Non-GAAP diluted EPS of $10.45 for the fourth quarter

[0001730168-22-000110:8k_2_02:10]
•First quarter revenue guidance of approximately $8.9 billion, an increase of 16 percent from the prior year period

[0001730168-22-000110:8k_2_02:11]
•First quarter Adjusted EBITDA guidance of approximately 63 percent of projected revenue (1)

[0001730168-22-000110:8k_2_02:12]
SAN JOSE, Calif. – December 8, 2022 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year ended October 30, 2022, provided guidance for the first quarter of its fiscal year 2023 and announced its quarterly dividend.

[0001730168-22-000110:8k_2_02:13]
“Broadcom’s fiscal year 2022 revenue grew 21% year-over-year to a record $33.2 billion, as a result of strong demand from hyperscale, service providers, and enterprise,” said Hock Tan, President and CEO of Broadcom Inc. “This growth was driven by our strong partnerships with customers and accelerated adoption of our next generation technologies. As we look into fiscal 2023, our increased R&D investments during the preceding years position us to extend our leadership in next generation products within the end markets we address.”

[0001730168-22-000110:8k_2_02:14]
“In fiscal 2022 we achieved record adjusted EBITDA margin of 63%, generating $16.3 billion in free cash flow or 49% of revenue, demonstrating our stable and focused business model,” said Kirsten Spears, CFO of Broadcom Inc. “Consistent with our commitment to return cash to shareholders, we will resume our authorized share repurchase programs for the remaining $13 billion, and we are increasing our quarterly common stock dividend by 12 percent to $4.60 per share for fiscal year 2023. The target fiscal 2023 annual common stock dividend of $18.40 per share is a record, and the twelfth consecutive increase in annual dividends since we initiated dividends in fiscal 2011.”

[0001730168-22-000110:8k_2_02:15]
Fourth Quarter Fiscal Year 2022 Financial Highlights

[0001730168-22-000110:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 22 |  | Q4 21 |  | Change |  | Q4 22 |  | Q4 21 |  | Change |
| Net revenue |  | $ | 8,930 |  |  | $ | 7,407 |  |  | +21 | % |  | $ | 8,930 |  |  | $ | 7,407 |  |  | +21 | % |
| Net income |  | $ | 3,359 |  |  | $ | 1,989 |  |  | +$1,370 |  |  | $ | 4,544 |  |  | $ | 3,501 |  |  | +$1,043 |  |
| Earnings per common share - diluted |  | $ | 7.83 |  |  | $ | 4.45 |  |  | +$3.38 |  |  | $ | 10.45 |  |  | $ | 7.81 |  |  | +$2.64 |  |

[0001730168-22-000110:8k_2_02:17]
________________________________

[0001730168-22-000110:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-22-000110:8k_2_02:19]
1

[0001730168-22-000110:8k_2_02:20]
| (Dollars in millions) |  | Q4 22 |  | Q4 21 |  | Change |  |
| Cash flow from operations |  | $ | 4,583 |  |  | $ | 3,541 |  |  | +$1,042 |  |
| Adjusted EBITDA |  | $ | 5,722 |  |  | $ | 4,547 |  |  | +$1,175 |  |
| Free cash flow |  | $ | 4,461 |  |  | $ | 3,453 |  |  | +$1,008 |  |

[0001730168-22-000110:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 22 |  |  |  | Q4 21 |  | Change |  |
| Semiconductor solutions |  | $ | 7,092 |  |  | 79 | % |  |  |  |  |  |  | $ | 5,634 |  |  | 76 | % |  | +26 | % |  |
| Infrastructure software |  | 1,838 |  |  | 21 |  |  |  |  |  |  |  | 1,773 |  |  | 24 |  |  | +4 | % |  |
| Total net revenue |  | $ | 8,930 |  |  | 100 | % |  |  |  |  |  |  | $ | 7,407 |  |  | 100 | % |  |  |  |  |

[0001730168-22-000110:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $12,416 million, compared to $9,977 million at the end of the prior quarter.

[0001730168-22-000110:8k_2_02:23]
During the fourth fiscal quarter, the Company generated $4,583 million in cash from operations and spent $122 million on capital expenditures.

[0001730168-22-000110:8k_2_02:24]
On September 30, 2022, the Company paid a cash dividend of $4.10 per share of common stock, totaling $1,707 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-22-000110:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-22-000110:8k_2_02:26]
Fiscal Year 2022 Financial Highlights

[0001730168-22-000110:8k_2_02:27]
|  |  | GAAP |  | Non-GAAP |  |  |  |  |
| (Dollars in millions, except per share data) |  | FY 22 |  | FY 21 |  | Change |  | FY 22 |  | FY 21 |  | Change |  |  |  |  |
| Net revenue |  | $ | 33,203 |  |  | $ | 27,450 |  |  | +21 | % |  | $ | 33,203 |  |  | $ | 27,450 |  |  | +21 | % |  |  |  |  |
| Net income |  | $ | 11,495 |  |  | $ | 6,736 |  |  | +$4,759 |  |  | $ | 16,526 |  |  | $ | 12,578 |  |  | +$3,948 |  |  |  |  |  |
| Earnings per common share - diluted |  | $ | 26.53 |  |  | $ | 15.00 |  |  | +$11.53 |  |  | $ | 37.64 |  |  | $ | 28.01 |  |  | +$9.63 |  |  |  |  |  |

[0001730168-22-000110:8k_2_02:28]
| (Dollars in millions) |  | FY 22 |  | FY 21 |  | Change |  |
| Cash flow from operations |  | $ | 16,736 |  |  | $ | 13,764 |  |  | +$2,972 |  |
| Adjusted EBITDA |  | $ | 21,029 |  |  | $ | 16,571 |  |  | +$4,458 |  |
| Free cash flow |  | $ | 16,312 |  |  | $ | 13,321 |  |  | +$2,991 |  |

[0001730168-22-000110:8k_2_02:29]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | FY 22 |  |  |  | FY 21 |  | Change |  |
| Semiconductor solutions |  | $ | 25,818 |  |  | 78 | % |  |  |  |  |  |  | $ | 20,383 |  |  | 74 | % |  | +27 | % |  |
| Infrastructure software |  | 7,385 |  |  | 22 |  |  |  |  |  |  |  | 7,067 |  |  | 26 |  |  | +4 | % |  |
| Total net revenue |  | $ | 33,203 |  |  | 100 | % |  |  |  |  |  |  | $ | 27,450 |  |  | 100 | % |  |  |  |  |

[0001730168-22-000110:8k_2_02:30]
2

[0001730168-22-000110:8k_2_02:31]
First Quarter Fiscal Year 2023 Business Outlook

[0001730168-22-000110:8k_2_02:32]
Based on current business trends and conditions, the outlook for the first quarter of fiscal year 2023, ending January 29, 2023, is expected to be as follows:

[0001730168-22-000110:8k_2_02:33]
•First quarter revenue guidance of approximately $8.9 billion; and

[0001730168-22-000110:8k_2_02:34]
•First quarter Adjusted EBITDA guidance of approximately 63 percent of projected revenue.

[0001730168-22-000110:8k_2_02:35]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000110:8k_2_02:36]
Quarterly Dividends

[0001730168-22-000110:8k_2_02:37]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $4.60 per share. The common stock dividend is payable on December 30, 2022 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 20, 2022.

[0001730168-22-000110:8k_2_02:38]
Financial Results Conference Call

[0001730168-22-000110:8k_2_02:39]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter and fiscal year 2022 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-22-000110:8k_2_02:40]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-22-000110:8k_2_02:41]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at https://register.vevent.com/register/BI3bd5e222a5a94efa94293a14af6ff35a. Upon registering, you will be emailed a link to the dial-in number and unique PIN.

[0001730168-22-000110:8k_2_02:42]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom's website at https://investors.broadcom.com/.

[0001730168-22-000110:8k_2_02:43]
Non-GAAP Financial Measures

[0001730168-22-000110:8k_2_02:44]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-22-000110:8k_2_02:45]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation

[0001730168-22-000110:8k_2_02:46]
3

[0001730168-22-000110:8k_2_02:47]
expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-22-000110:8k_2_02:48]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-22-000110:8k_2_02:49]
About Broadcom Inc.

[0001730168-22-000110:8k_2_02:50]
Broadcom Inc. (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-22-000110:8k_2_02:51]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-22-000110:8k_2_02:52]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a

[0001730168-22-000110:8k_2_02:53]
limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase programs; the COVID-19 pandemic; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; failing to complete or realize the expected benefits of our acquisition of VMware, Inc.; any acquisitions we may make, including our acquisition of VMware, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to protect against cyber security threats and a breach of security systems; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and may continue to be, exacerbated by the COVID-19 pandemic. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-22-000110:8k_2_02:54]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-22-000110:8k_2_02:55]
Contact:

[0001730168-22-000110:8k_2_02:56]
Ji Yoo

[0001730168-22-000110:8k_2_02:57]
Broadcom Inc.

[0001730168-22-000110:8k_2_02:58]
Investor Relations

[0001730168-22-000110:8k_2_02:59]
408-433-8000

[0001730168-22-000110:8k_2_02:60]
investor.relations@broadcom.com

[0001730168-22-000110:8k_2_02:61]
(AVGO-Q)

[0001730168-22-000110:8k_2_02:62]
5

[0001730168-22-000110:8k_2_02:63]
BROADCOM INC.

[0001730168-22-000110:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-22-000110:8k_2_02:65]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-22-000110:8k_2_02:66]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 30,2022 |  | July 31,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
| Net revenue |  | $ | 8,930 |  |  | $ | 8,464 |  |  | $ | 7,407 |  |  | $ | 33,203 |  |  | $ | 27,450 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 2,298 |  |  | 2,077 |  |  | 1,920 |  |  | 8,256 |  |  | 7,162 |  |
| Amortization of acquisition-related intangible assets |  | 705 |  |  | 705 |  |  | 849 |  |  | 2,847 |  |  | 3,427 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | — |  |  | 5 |  |  | 17 |  |
| Total cost of revenue |  | 3,004 |  |  | 2,783 |  |  | 2,769 |  |  | 11,108 |  |  | 10,606 |  |
| Gross margin |  | 5,926 |  |  | 5,681 |  |  | 4,638 |  |  | 22,095 |  |  | 16,844 |  |
| Research and development |  | 1,197 |  |  | 1,255 |  |  | 1,200 |  |  | 4,919 |  |  | 4,854 |  |
| Selling, general and administrative |  | 370 |  |  | 323 |  |  | 337 |  |  | 1,382 |  |  | 1,347 |  |
| Amortization of acquisition-related intangible assets |  | 358 |  |  | 359 |  |  | 494 |  |  | 1,512 |  |  | 1,976 |  |
| Restructuring, impairment and disposal charges |  | 15 |  |  | 7 |  |  | 26 |  |  | 57 |  |  | 148 |  |
| Total operating expenses |  | 1,940 |  |  | 1,944 |  |  | 2,057 |  |  | 7,870 |  |  | 8,325 |  |
| Operating income |  | 3,986 |  |  | 3,737 |  |  | 2,581 |  |  | 14,225 |  |  | 8,519 |  |
| Interest expense |  | (406) |  |  | (406) |  |  | (434) |  |  | (1,737) |  |  | (1,885) |  |
| Other income (expense), net |  | 40 |  |  | 6 |  |  | 22 |  |  | (54) |  |  | 131 |  |
| Income before income taxes |  | 3,620 |  |  | 3,337 |  |  | 2,169 |  |  | 12,434 |  |  | 6,765 |  |
| Provision for income taxes |  | 261 |  |  | 263 |  |  | 180 |  |  | 939 |  |  | 29 |  |
| Net income |  | 3,359 |  |  | 3,074 |  |  | 1,989 |  |  | 11,495 |  |  | 6,736 |  |
| Dividends on preferred stock |  | (48) |  |  | (75) |  |  | (75) |  |  | (272) |  |  | (299) |  |
| Net income attributable to common stock |  | $ | 3,311 |  |  | $ | 2,999 |  |  | $ | 1,914 |  |  | $ | 11,223 |  |  | $ | 6,437 |  |
| Net income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 8.06 |  |  | $ | 7.40 |  |  | $ | 4.65 |  |  | $ | 27.44 |  |  | $ | 15.70 |  |
| Diluted (1) |  | $ | 7.83 |  |  | $ | 7.15 |  |  | $ | 4.45 |  |  | $ | 26.53 |  |  | $ | 15.00 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 411 |  |  | 405 |  |  | 412 |  |  | 409 |  |  | 410 |  |
| Diluted (1) |  | 429 |  |  | 430 |  |  | 430 |  |  | 423 |  |  | 429 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 38 |  |  | $ | 37 |  |  | $ | 37 |  |  | $ | 147 |  |  | $ | 143 |  |
| Research and development |  | 260 |  |  | 259 |  |  | 279 |  |  | 1,048 |  |  | 1,199 |  |
| Selling, general and administrative |  | 89 |  |  | 77 |  |  | 98 |  |  | 338 |  |  | 362 |  |
| Total stock-based compensation expense |  | $ | 387 |  |  | $ | 373 |  |  | $ | 414 |  |  | $ | 1,533 |  |  | $ | 1,704 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive for the fiscal quarter ended October 31, 2021, and for the fiscal years ended October 30, 2022 and October 31, 2021. |

[0001730168-22-000110:8k_2_02:67]
BROADCOM INC.

[0001730168-22-000110:8k_2_02:68]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-22-000110:8k_2_02:69]
(IN MILLIONS)

[0001730168-22-000110:8k_2_02:70]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 30,2022 |  | July 31,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
| Gross margin on GAAP basis |  | $ | 5,926 |  |  | $ | 5,681 |  |  | $ | 4,638 |  |  | $ | 22,095 |  |  | $ | 16,844 |  |
| Amortization of acquisition-related intangible assets |  | 705 |  |  | 705 |  |  | 849 |  |  | 2,847 |  |  | 3,427 |  |
| Stock-based compensation expense |  | 38 |  |  | 37 |  |  | 37 |  |  | 147 |  |  | 143 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | — |  |  | 5 |  |  | 17 |  |
| Acquisition-related costs |  | 3 |  |  | 3 |  |  | 3 |  |  | 13 |  |  | 12 |  |
| Gross margin on non-GAAP basis |  | $ | 6,673 |  |  | $ | 6,427 |  |  | $ | 5,527 |  |  | $ | 25,107 |  |  | $ | 20,443 |  |
| Research and development on GAAP basis |  | $ | 1,197 |  |  | $ | 1,255 |  |  | $ | 1,200 |  |  | $ | 4,919 |  |  | $ | 4,854 |  |
| Stock-based compensation expense |  | 260 |  |  | 259 |  |  | 279 |  |  | 1,048 |  |  | 1,199 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Research and development on non-GAAP basis |  | $ | 937 |  |  | $ | 996 |  |  | $ | 921 |  |  | $ | 3,871 |  |  | $ | 3,652 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 370 |  |  | $ | 323 |  |  | $ | 337 |  |  | $ | 1,382 |  |  | $ | 1,347 |  |
| Stock-based compensation expense |  | 89 |  |  | 77 |  |  | 98 |  |  | 338 |  |  | 362 |  |
| Acquisition-related costs |  | 45 |  |  | 14 |  |  | 17 |  |  | 102 |  |  | 105 |  |
| Litigation settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 236 |  |  | $ | 232 |  |  | $ | 222 |  |  | $ | 942 |  |  | $ | 879 |  |
| Total operating expenses on GAAP basis |  | $ | 1,940 |  |  | $ | 1,944 |  |  | $ | 2,057 |  |  | $ | 7,870 |  |  | $ | 8,325 |  |
| Amortization of acquisition-related intangible assets |  | 358 |  |  | 359 |  |  | 494 |  |  | 1,512 |  |  | 1,976 |  |
| Stock-based compensation expense |  | 349 |  |  | 336 |  |  | 377 |  |  | 1,386 |  |  | 1,561 |  |
| Restructuring, impairment and disposal charges |  | 15 |  |  | 7 |  |  | 26 |  |  | 57 |  |  | 148 |  |
| Litigation settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 45 |  |  | 14 |  |  | 17 |  |  | 102 |  |  | 108 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,173 |  |  | $ | 1,228 |  |  | $ | 1,143 |  |  | $ | 4,813 |  |  | $ | 4,531 |  |
| Operating income on GAAP basis |  | $ | 3,986 |  |  | $ | 3,737 |  |  | $ | 2,581 |  |  | $ | 14,225 |  |  | $ | 8,519 |  |
| Amortization of acquisition-related intangible assets |  | 1,063 |  |  | 1,064 |  |  | 1,343 |  |  | 4,359 |  |  | 5,403 |  |
| Stock-based compensation expense |  | 387 |  |  | 373 |  |  | 414 |  |  | 1,533 |  |  | 1,704 |  |
| Restructuring, impairment and disposal charges |  | 16 |  |  | 8 |  |  | 26 |  |  | 62 |  |  | 165 |  |
| Litigation settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 48 |  |  | 17 |  |  | 20 |  |  | 115 |  |  | 120 |  |
| Operating income on non-GAAP basis |  | $ | 5,500 |  |  | $ | 5,199 |  |  | $ | 4,384 |  |  | $ | 20,294 |  |  | $ | 15,912 |  |
| Interest expense on GAAP basis |  | $ | (406) |  |  | $ | (406) |  |  | $ | (434) |  |  | $ | (1,737) |  |  | $ | (1,885) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | 23 |  |  | 112 |  |  | 245 |  |
| Interest expense on non-GAAP basis |  | $ | (406) |  |  | $ | (406) |  |  | $ | (411) |  |  | $ | (1,625) |  |  | $ | (1,640) |  |
| Other income (expense), net on GAAP basis |  | $ | 40 |  |  | $ | 6 |  |  | $ | 22 |  |  | $ | (54) |  |  | $ | 131 |  |
| (Gains) losses on investments |  | 29 |  |  | 25 |  |  | (9) |  |  | 169 |  |  | (99) |  |
| Other |  | — |  |  | (5) |  |  | (8) |  |  | (5) |  |  | (11) |  |
| Other income, net on non-GAAP basis |  | $ | 69 |  |  | $ | 26 |  |  | $ | 5 |  |  | $ | 110 |  |  | $ | 21 |  |

[0001730168-22-000110:8k_2_02:71]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 30,2022 |  | July 31,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
| Provision for income taxes on GAAP basis |  | $ | 261 |  |  | $ | 263 |  |  | $ | 180 |  |  | $ | 939 |  |  | $ | 29 |  |
| Non-GAAP tax reconciling adjustments |  | 358 |  |  | 315 |  |  | 297 |  |  | 1,314 |  |  | 1,686 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 619 |  |  | $ | 578 |  |  | $ | 477 |  |  | $ | 2,253 |  |  | $ | 1,715 |  |
| Net income on GAAP basis |  | $ | 3,359 |  |  | $ | 3,074 |  |  | $ | 1,989 |  |  | $ | 11,495 |  |  | $ | 6,736 |  |
| Amortization of acquisition-related intangible assets |  | 1,063 |  |  | 1,064 |  |  | 1,343 |  |  | 4,359 |  |  | 5,403 |  |
| Stock-based compensation expense |  | 387 |  |  | 373 |  |  | 414 |  |  | 1,533 |  |  | 1,704 |  |
| Restructuring, impairment and disposal charges |  | 16 |  |  | 8 |  |  | 26 |  |  | 62 |  |  | 165 |  |
| Litigation settlements |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Acquisition-related costs |  | 48 |  |  | 17 |  |  | 20 |  |  | 115 |  |  | 120 |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | 23 |  |  | 112 |  |  | 245 |  |
| (Gains) losses on investments |  | 29 |  |  | 25 |  |  | (9) |  |  | 169 |  |  | (99) |  |
| Other |  | — |  |  | (5) |  |  | (8) |  |  | (5) |  |  | (11) |  |
| Non-GAAP tax reconciling adjustments |  | (358) |  |  | (315) |  |  | (297) |  |  | (1,314) |  |  | (1,686) |  |
| Net income on non-GAAP basis |  | $ | 4,544 |  |  | $ | 4,241 |  |  | $ | 3,501 |  |  | $ | 16,526 |  |  | $ | 12,578 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 429 |  |  | 430 |  |  | 430 |  |  | 423 |  |  | 429 |  |
| Non-GAAP adjustment (1) |  | 6 |  |  | 6 |  |  | 18 |  |  | 16 |  |  | 20 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 435 |  |  | 436 |  |  | 448 |  |  | 439 |  |  | 449 |  |
| Net income on non-GAAP basis |  | $ | 4,544 |  |  | $ | 4,241 |  |  | $ | 3,501 |  |  | $ | 16,526 |  |  | $ | 12,578 |  |
| Interest expense on non-GAAP basis |  | 406 |  |  | 406 |  |  | 411 |  |  | 1,625 |  |  | 1,640 |  |
| Provision for income taxes on non-GAAP basis |  | 619 |  |  | 578 |  |  | 477 |  |  | 2,253 |  |  | 1,715 |  |
| Depreciation |  | 129 |  |  | 129 |  |  | 134 |  |  | 529 |  |  | 539 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 24 |  |  | 24 |  |  | 96 |  |  | 99 |  |
| Adjusted EBITDA |  | $ | 5,722 |  |  | $ | 5,378 |  |  | $ | 4,547 |  |  | $ | 21,029 |  |  | $ | 16,571 |  |
| Net cash provided by operating activities |  | $ | 4,583 |  |  | $ | 4,424 |  |  | $ | 3,541 |  |  | $ | 16,736 |  |  | $ | 13,764 |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (116) |  |  | (88) |  |  | (424) |  |  | (443) |  |
| Free cash flow |  | $ | 4,461 |  |  | $ | 4,308 |  |  | $ | 3,453 |  |  | $ | 16,312 |  |  | $ | 13,321 |  |

[0001730168-22-000110:8k_2_02:72]
|  |  | Fiscal Quarter Ending |
|  |  | January 29, |
| Expected average diluted share count (2): |  | 2023 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 429 |  |
| Non-GAAP adjustment (1) |  | 6 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 435 |  |

[0001730168-22-000110:8k_2_02:73]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis for the fiscal quarter ended October 31, 2021 and the fiscal years ended October 30, 2022 and October 31, 2021. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-22-000110:8k_2_02:74]
BROADCOM INC.

[0001730168-22-000110:8k_2_02:75]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-22-000110:8k_2_02:76]
(IN MILLIONS)

[0001730168-22-000110:8k_2_02:77]
|  |  | October 30,2022 |  | October 31,2021 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 12,416 |  |  | $ | 12,163 |  |
| Trade accounts receivable, net |  | 2,958 |  |  | 2,071 |  |
| Inventory |  | 1,925 |  |  | 1,297 |  |
| Other current assets |  | 1,205 |  |  | 1,055 |  |
| Total current assets |  | 18,504 |  |  | 16,586 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,223 |  |  | 2,348 |  |
| Goodwill |  | 43,614 |  |  | 43,450 |  |
| Intangible assets, net |  | 7,111 |  |  | 11,374 |  |
| Other long-term assets |  | 1,797 |  |  | 1,812 |  |
| Total assets |  | $ | 73,249 |  |  | $ | 75,570 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 998 |  |  | $ | 1,086 |  |
| Employee compensation and benefits |  | 1,202 |  |  | 1,066 |  |
| Current portion of long-term debt |  | 440 |  |  | 290 |  |
| Other current liabilities |  | 4,412 |  |  | 3,839 |  |
| Total current liabilities |  | 7,052 |  |  | 6,281 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 39,075 |  |  | 39,440 |  |
| Other long-term liabilities |  | 4,413 |  |  | 4,860 |  |
| Total liabilities |  | 50,540 |  |  | 50,581 |  |
| Preferred stock dividend obligation |  | — |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 21,159 |  |  | 24,330 |  |
| Retained earnings |  | 1,604 |  |  | 748 |  |
| Accumulated other comprehensive loss |  | (54) |  |  | (116) |  |
| Total stockholders' equity |  | 22,709 |  |  | 24,962 |  |
| Total liabilities and equity |  | $ | 73,249 |  |  | $ | 75,570 |  |

[0001730168-22-000110:8k_2_02:78]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 30,2022 |  | July 31,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,359 |  |  | $ | 3,074 |  |  | $ | 1,989 |  |  | $ | 11,495 |  |  | $ | 6,736 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,087 |  |  | 1,088 |  |  | 1,367 |  |  | 4,455 |  |  | 5,502 |  |
| Depreciation |  | 129 |  |  | 129 |  |  | 134 |  |  | 529 |  |  | 539 |  |
| Stock-based compensation |  | 387 |  |  | 373 |  |  | 414 |  |  | 1,533 |  |  | 1,704 |  |
| Deferred taxes and other non-cash taxes |  | (89) |  |  | (15) |  |  | (47) |  |  | (34) |  |  | (809) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | — |  |  | 100 |  |  | 198 |  |
| Non-cash restructuring, impairment and disposal charges |  | 2 |  |  | 2 |  |  | 3 |  |  | 13 |  |  | 38 |  |
| Non-cash interest expense |  | 32 |  |  | 32 |  |  | 29 |  |  | 129 |  |  | 96 |  |
| Other |  | 29 |  |  | 25 |  |  | (15) |  |  | 170 |  |  | (113) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (241) |  |  | 375 |  |  | 160 |  |  | (870) |  |  | 210 |  |
| Inventory |  | (87) |  |  | (170) |  |  | (137) |  |  | (627) |  |  | (294) |  |
| Accounts payable |  | 304 |  |  | (352) |  |  | 101 |  |  | (79) |  |  | 243 |  |
| Employee compensation and benefits |  | 128 |  |  | 321 |  |  | 172 |  |  | 136 |  |  | 186 |  |
| Other current assets and current liabilities |  | (388) |  |  | (198) |  |  | (540) |  |  | 222 |  |  | (177) |  |
| Other long-term assets and long-term liabilities |  | (69) |  |  | (260) |  |  | (89) |  |  | (436) |  |  | (295) |  |
| Net cash provided by operating activities |  | 4,583 |  |  | 4,424 |  |  | 3,541 |  |  | 16,736 |  |  | 13,764 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (7) |  |  | (5) |  |  | — |  |  | (246) |  |  | (8) |  |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Purchases of property, plant and equipment |  | (122) |  |  | (116) |  |  | (88) |  |  | (424) |  |  | (443) |  |
| Purchases of investments |  | — |  |  | — |  |  | — |  |  | (200) |  |  | — |  |
| Sales of investments |  | — |  |  | 200 |  |  | 102 |  |  | 200 |  |  | 169 |  |
| Other |  | 1 |  |  | 1 |  |  | (9) |  |  | 3 |  |  | (8) |  |
| Net cash provided by (used in) investing activities |  | (128) |  |  | 80 |  |  | 50 |  |  | (667) |  |  | (245) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | — |  |  | 1,935 |  |  | 9,904 |  |
| Payments on debt obligations |  | (9) |  |  | — |  |  | (762) |  |  | (2,361) |  |  | (11,495) |  |
| Payments of dividends |  | (1,782) |  |  | (1,736) |  |  | (1,561) |  |  | (7,032) |  |  | (6,212) |  |
| Repurchases of common stock - repurchase program |  | — |  |  | (1,500) |  |  | — |  |  | (7,000) |  |  | — |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (274) |  |  | (292) |  |  | (266) |  |  | (1,455) |  |  | (1,299) |  |
| Issuance of common stock |  | 54 |  |  | — |  |  | 57 |  |  | 114 |  |  | 170 |  |
| Other |  | (5) |  |  | (4) |  |  | (1) |  |  | (17) |  |  | (42) |  |
| Net cash used in financing activities |  | (2,016) |  |  | (3,532) |  |  | (2,533) |  |  | (15,816) |  |  | (8,974) |  |
| Net change in cash and cash equivalents |  | 2,439 |  |  | 972 |  |  | 1,058 |  |  | 253 |  |  | 4,545 |  |
| Cash and cash equivalents at beginning of period |  | 9,977 |  |  | 9,005 |  |  | 11,105 |  |  | 12,163 |  |  | 7,618 |  |
| Cash and cash equivalents at end of period |  | $ | 12,416 |  |  | $ | 9,977 |  |  | $ | 12,163 |  |  | $ | 12,416 |  |  | $ | 12,163 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 397 |  |  | $ | 290 |  |  | $ | 571 |  |  | $ | 1,386 |  |  | $ | 1,565 |  |
| Cash paid for income taxes |  | $ | 251 |  |  | $ | 231 |  |  | $ | 168 |  |  | $ | 908 |  |  | $ | 775 |  |
