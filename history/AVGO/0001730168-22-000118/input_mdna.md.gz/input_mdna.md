# AVGO MD&A — 0001730168-22-000118


## mdna

[0001730168-22-000118:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-22-000118:mdna:2]
The following section generally discusses our financial condition and results of operations for our fiscal year ended October 30, 2022 (“fiscal year 2022”) compared to our fiscal year ended October 31, 2021 (“fiscal year 2021”). A discussion regarding our financial condition and results of operations for fiscal year 2021 compared to our fiscal year ended November 1, 2020 (“fiscal year 2020”) can be found in Part II, Item 7 of our Annual Report on Form 10-K for fiscal year 2021, filed with the Securities and Exchange Commission (the “SEC”) on December 17, 2021.

[0001730168-22-000118:mdna:3]
Overview

[0001730168-22-000118:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-22-000118:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software. Our semiconductor solutions segment includes all of our product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our mainframe, distributed and cyber security solutions, and our FC SAN business.

[0001730168-22-000118:mdna:6]
Our strategy is to combine best-of-breed technology leadership in semiconductor and infrastructure software solutions, with unmatched scale, on a common sales and administrative platform to deliver a comprehensive suite of infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through responsibly financed acquisitions of category-leading businesses and technologies, as well as investing extensively in research and development, to ensure our products retain their technology leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-22-000118:mdna:7]
The demand for our products has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-22-000118:mdna:8]
•gain or loss of significant customers;

[0001730168-22-000118:mdna:9]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-22-000118:mdna:10]
•our distributors’ product inventory and end customer demand;

[0001730168-22-000118:mdna:11]
•the rate at which our present and future customers and end-users adopt our products and technologies in our target markets, and the rate at which our customers' products that include our technology are accepted in their markets;

[0001730168-22-000118:mdna:12]
•the shift to cloud-based information technology solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our products for use in traditional enterprise data centers; and

[0001730168-22-000118:mdna:13]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-22-000118:mdna:14]
COVID-19 Update

[0001730168-22-000118:mdna:15]
The COVID-19 pandemic and the efforts to control it disrupted, and reduced the efficiency of, normal business activities in much of the world. The pandemic resulted in authorities around the world implementing numerous unprecedented measures that created supply chain and market disruption, impacting our workforce and operations, and those of our customers, contract manufacturers, suppliers and logistics providers.

[0001730168-22-000118:mdna:16]
While the demand environment for our semiconductor products was consistent with our expectations for fiscal year 2022, with robust and increased profitability driven by the supply imbalance, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. We continue to experience various constraints in our supply chain, including with respect to wafers and substrates. Although supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet demand.

[0001730168-22-000118:mdna:17]
In response to the pandemic, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We continue to monitor the implications of the pandemic on our operations and may modify our business practices and policies from time to time.

[0001730168-22-000118:mdna:18]
Our ability to predict the impact of the pandemic on our business remains limited and its effects on our business are unlikely to be fully realized, or reflected in our financial results, until future periods.

[0001730168-22-000118:mdna:19]
Fiscal Year Highlights

[0001730168-22-000118:mdna:20]
Highlights during fiscal year 2022 include the following:

[0001730168-22-000118:mdna:21]
•We generated $16,736 million of cash from operations.

[0001730168-22-000118:mdna:22]
•We paid $7,032 million in cash dividends.

[0001730168-22-000118:mdna:23]
•We repurchased $7,000 million of common stock.

[0001730168-22-000118:mdna:24]
Pending Acquisition of VMware, Inc.

[0001730168-22-000118:mdna:25]
On May 26, 2022, we entered into an Agreement and Plan of Merger (the “VMware Merger Agreement”) to acquire all of the outstanding shares of VMware, Inc. (“VMware”) in a cash-and-stock transaction (the “VMware Merger”) that values VMware at approximately $61 billion, based on the closing price of Broadcom common stock on May 25, 2022. We will also assume VMware’s closing date outstanding debt, net of expected cash.

[0001730168-22-000118:mdna:26]
Under the terms of the VMware Merger Agreement, each share of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger will be indirectly converted into the right to receive, at the election of the holder of such share of VMware common stock, either $142.50 in cash, without interest, or 0.2520 shares of Broadcom common stock. The stockholder election will be subject to proration, such that the total number of shares of VMware common stock entitled to receive cash and the total number of shares of VMware common stock entitled to receive Broadcom common stock, will, in each case, be equal to 50% of the aggregate number of shares of VMware common stock issued and outstanding immediately prior to the effective time of the VMware Merger.

[0001730168-22-000118:mdna:27]
We will assume all outstanding VMware restricted stock unit (“RSU”) awards and performance stock unit awards held by continuing employees. The assumed awards will be converted into RSU awards for shares of Broadcom common stock. All outstanding in-the-money VMware stock options and RSU awards held by non-employee directors will be accelerated and converted into the right to receive cash and shares of Broadcom common stock, in equal parts.

[0001730168-22-000118:mdna:28]
Effective upon the effective time of the VMware Merger, one member of the VMware Board of Directors, to be mutually agreed by us and VMware, will be added to our Board of Directors.

[0001730168-22-000118:mdna:29]
In connection with the execution of the VMware Merger Agreement, we entered into a commitment letter on May 26, 2022, with certain financial institutions that committed to provide, subject to the terms and conditions of the commitment letter, a senior unsecured bridge facility in an aggregate principal amount of $32 billion.

[0001730168-22-000118:mdna:30]
The VMware Merger, which is expected to be completed in our fiscal year ending October 29, 2023 (“fiscal year 2023”), is subject to satisfaction or waiver of customary closing conditions, including the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976 and clearance under the antitrust laws of the European Union and certain other jurisdictions. On October 3, 2022, we registered approximately 59 million shares of our common stock. On November 4, 2022, VMware stockholders adopted the VMware Merger Agreement. We and VMware each have termination rights under the VMware Merger Agreement and, under specified circumstances, upon termination of the agreement, we and VMware would be required to pay the other a termination fee of $1.5 billion.

[0001730168-22-000118:mdna:31]
Net Revenue

[0001730168-22-000118:mdna:32]
A majority of our net revenue is derived from sales of a broad range of semiconductor devices that are incorporated into electronic products, as well as from modules, switches and subsystems. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, automate, manage, and secure applications across mainframe, distributed, mobile, and cloud platforms.

[0001730168-22-000118:mdna:33]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, have varied from quarter to quarter, due largely to fluctuations in end-

[0001730168-22-000118:mdna:34]
market demand, including the effects of seasonality, which are discussed in detail in Part I, Item 1. Business under “Seasonality” of this Annual Report on Form 10-K.

[0001730168-22-000118:mdna:35]
Distributors and original equipment manufacturers (“OEMs”), or their contract manufacturers, typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive IP portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon the delivery of our products to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-22-000118:mdna:36]
Our software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-22-000118:mdna:37]
Costs and Expenses

[0001730168-22-000118:mdna:38]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense, related occupancy, computer services, equipment costs, manufacturing quality, order fulfillment, warranty adjustments, inventory adjustments  including write-downs for inventory obsolescence, and acquisition costs, which include direct transaction costs and acquisition-related costs.

[0001730168-22-000118:mdna:39]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-22-000118:mdna:40]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-22-000118:mdna:41]
Total cost of revenue also includes amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-22-000118:mdna:42]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-22-000118:mdna:43]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs and other corporate expenses.

[0001730168-22-000118:mdna:44]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are being amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with the acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-22-000118:mdna:45]
Restructuring, impairment and disposal charges.  Restructuring, impairment and disposal charges consist primarily of compensation costs associated with employee exit programs, alignment of our global manufacturing operations, rationalizing product development program costs, facility and lease abandonments, fixed asset impairment, IPR&D impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-22-000118:mdna:46]
37

[0001730168-22-000118:mdna:47]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-22-000118:mdna:48]
Other income (expense), net.  Other income (expense), net includes interest income, gains or losses on investments, foreign currency remeasurement, and other miscellaneous items.

[0001730168-22-000118:mdna:49]
Provision for income taxes.  We have structured our operations to maximize the benefit from tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax, subject to our compliance with the conditions specified in these incentives and legislative developments. These Singapore tax incentives are presently expected to expire in November 2025. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in 2028.

[0001730168-22-000118:mdna:50]
Each tax incentive and tax holiday is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to decrease the provision for income taxes by approximately $1,821 million and $1,156 million for fiscal years 2022 and 2021, respectively.

[0001730168-22-000118:mdna:51]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect or if these tax incentives are substantially modified or rescinded, we could suffer material adverse tax and other financial consequences, which would increase our expenses, reduce our profitability and adversely affect our cash flows. In addition, taxable income in any jurisdiction is dependent upon acceptance of our operational practices and intercompany transfer pricing by local tax authorities as being on an arm’s length basis. Due to inconsistencies in application of the arm’s length standard among taxing authorities, as well as lack of adequate treaty-based protection, transfer pricing challenges by tax authorities could, if successful, substantially increase our income tax expense.

[0001730168-22-000118:mdna:52]
Critical Accounting Estimates

[0001730168-22-000118:mdna:53]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, valuation of goodwill and long-lived assets, and income taxes. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-22-000118:mdna:54]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-22-000118:mdna:55]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-22-000118:mdna:56]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-22-000118:mdna:57]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance, including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting the financial multiples of comparable companies and applying a control premium. A reporting unit's carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-22-000118:mdna:58]
We assess the impairment of long-lived assets, including purchased IPR&D, property, plant and equipment, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include: (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment, and intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business to which the long-lived assets relate. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived assets stated on our consolidated balance sheets to reflect their estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-22-000118:mdna:59]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition.

[0001730168-22-000118:mdna:60]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax laws and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-22-000118:mdna:61]
39

[0001730168-22-000118:mdna:62]
Fiscal Year Presentation

[0001730168-22-000118:mdna:63]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal years 2022, 2021 and 2020 consisted of 52 weeks.

[0001730168-22-000118:mdna:64]
The financial statements included in Part II, Item 8. of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-22-000118:mdna:65]
Results of Operations

[0001730168-22-000118:mdna:66]
Fiscal Year 2022 Compared to Fiscal Year 2021

[0001730168-22-000118:mdna:67]
The following table sets forth our results of operations for the periods presented:

[0001730168-22-000118:mdna:68]
|  |  | Fiscal Year Ended |
|  |  | October 30,2022 |  | October 31,2021 |  | October 30,2022 |  | October 31,2021 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 26,277 |  |  | $ | 20,886 |  |  | 79 | % |  | 76 | % |
| Subscriptions and services |  | 6,926 |  |  | 6,564 |  |  | 21 |  |  | 24 |  |
| Total net revenue |  | 33,203 |  |  | 27,450 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 7,629 |  |  | 6,555 |  |  | 23 |  |  | 24 |  |
| Cost of subscriptions and services |  | 627 |  |  | 607 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 2,847 |  |  | 3,427 |  |  | 8 |  |  | 13 |  |
| Restructuring charges |  | 5 |  |  | 17 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 11,108 |  |  | 10,606 |  |  | 33 |  |  | 39 |  |
| Gross margin |  | 22,095 |  |  | 16,844 |  |  | 67 |  |  | 61 |  |
| Research and development |  | 4,919 |  |  | 4,854 |  |  | 15 |  |  | 18 |  |
| Selling, general and administrative |  | 1,382 |  |  | 1,347 |  |  | 4 |  |  | 5 |  |
| Amortization of acquisition-related intangible assets |  | 1,512 |  |  | 1,976 |  |  | 5 |  |  | 7 |  |
| Restructuring, impairment and disposal charges |  | 57 |  |  | 148 |  |  | — |  |  | — |  |
| Total operating expenses |  | 7,870 |  |  | 8,325 |  |  | 24 |  |  | 30 |  |
| Operating income |  | $ | 14,225 |  |  | $ | 8,519 |  |  | 43 | % |  | 31 | % |

[0001730168-22-000118:mdna:69]
Net Revenue

[0001730168-22-000118:mdna:70]
A relatively small number of customers account for a significant portion of our net revenue. Sales of products to distributors accounted for 56% and 53% of our net revenue for fiscal years 2022 and 2021, respectively. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 20% and 18% of our net revenue for fiscal years 2022 and 2021, respectively. We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of fiscal years 2022 and 2021. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of fiscal years 2022 and 2021. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-22-000118:mdna:71]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile devices. The COVID-19 pandemic and macroeconomic  uncertainties may cause our net revenue to fluctuate significantly and impact our results of operations.

[0001730168-22-000118:mdna:72]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based primarily on the geographic shipment or delivery location specified by our distributors, OEMs, contract manufacturers, channel partners, or software customers. In each of fiscal years 2022 and 2021, approximately 35% of our net revenue came from shipments or deliveries to China (including Hong Kong). However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-22-000118:mdna:73]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-22-000118:mdna:74]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | October 30,2022 |  | October 31,2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 25,818 |  |  | $ | 20,383 |  |  | $ | 5,435 |  |  | 27 | % |
| Infrastructure software |  | 7,385 |  |  | 7,067 |  |  | 318 |  |  | 4 | % |
| Total net revenue |  | $ | 33,203 |  |  | $ | 27,450 |  |  | $ | 5,753 |  |  | 21 | % |

[0001730168-22-000118:mdna:75]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | October 30, 2022 |  | October 31, 2021 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 78 | % |  | 74 | % |
| Infrastructure software |  | 22 |  |  | 26 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-22-000118:mdna:76]
Net revenue from our semiconductor solutions segment increased due to strong product demand, primarily for networking, server storage and broadband products, as well as higher demand for our wireless content in mobile devices. Net revenue from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions and FC SAN products.

[0001730168-22-000118:mdna:77]
Gross Margin

[0001730168-22-000118:mdna:78]
Gross margin was $22,095 million, or 67% of net revenue, for fiscal year 2022, compared to $16,844 million, or 61% of net revenue, for fiscal year 2021. The increase was primarily due to lower amortization of acquisition-related intangible assets, mainly from our 2016 acquisition of Broadcom Corporation and, to a lesser extent, favorable margin within our semiconductor solutions segment.

[0001730168-22-000118:mdna:79]
Research and Development Expense

[0001730168-22-000118:mdna:80]
Research and development expense increased $65 million, or 1%, in fiscal year 2022, compared to the prior fiscal year. The increase was primarily due to higher variable employee compensation expense and engineering project costs, partially offset by lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures.

[0001730168-22-000118:mdna:81]
Selling, General and Administrative Expense

[0001730168-22-000118:mdna:82]
Selling, general and administrative expense increased $35 million, or 3%, in fiscal year 2022, compared to the prior fiscal year. The increase was primarily due to higher variable employee compensation expense, offset in part by lower stock-based compensation expense.

[0001730168-22-000118:mdna:83]
Amortization of Acquisition-Related Intangible Assets

[0001730168-22-000118:mdna:84]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $464 million, or 23%, in fiscal year 2022, compared to the prior fiscal year. The decrease was primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-22-000118:mdna:85]
Restructuring, Impairment and Disposal Charges

[0001730168-22-000118:mdna:86]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $91 million, or 61%, in fiscal year 2022, compared to the prior fiscal year. The decrease was primarily due to lower employee termination costs following the completion of key restructuring activities from acquisitions.

[0001730168-22-000118:mdna:87]
Stock-Based Compensation Expense

[0001730168-22-000118:mdna:88]
Total stock-based compensation expense was $1,533 million and $1,704 million for fiscal years 2022 and 2021, respectively. The decrease primarily reflects the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-22-000118:mdna:89]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of October 30, 2022, which we expect to recognize over the remaining weighted-average service period of 2.7 years.

[0001730168-22-000118:mdna:90]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2023 |  | $ | 1,221 |  |
| 2024 |  | 846 |  |
| 2025 |  | 507 |  |
| 2026 |  | 130 |  |
| Total |  | $ | 2,704 |  |

[0001730168-22-000118:mdna:91]
During the first quarter of fiscal year ended November 3, 2019 (“fiscal year 2019”), our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-22-000118:mdna:92]
Segment Operating Results

[0001730168-22-000118:mdna:93]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | October 30, 2022 |  | October 31, 2021 |  | $ Change |  | % Change |
|  |  | (In millions, except percentages) |
| Semiconductor solutions |  | $ | 15,075 |  |  | $ | 10,976 |  |  | $ | 4,099 |  |  | 37 | % |
| Infrastructure software |  | 5,219 |  |  | 4,936 |  |  | 283 |  |  | 6 | % |
| Unallocated expenses |  | (6,069) |  |  | (7,393) |  |  | 1,324 |  |  | (18) | % |
| Total operating income |  | $ | 14,225 |  |  | $ | 8,519 |  |  | $ | 5,706 |  |  | 67 | % |

[0001730168-22-000118:mdna:94]
Operating income from our semiconductor solutions segment increased primarily due to higher net revenue from networking, server storage, broadband, and wireless products, as well as higher gross margin. Operating income from our infrastructure software segment increased primarily due to higher demand for our mainframe solutions and FC SAN products.

[0001730168-22-000118:mdna:95]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 18% in fiscal year 2022, compared to the prior fiscal year, primarily due to lower amortization of acquisition-related intangible assets.

[0001730168-22-000118:mdna:96]
Non-Operating Income and Expenses

[0001730168-22-000118:mdna:97]
Interest expense.  Interest expense was $1,737 million and $1,885 million for fiscal years 2022 and 2021, respectively. The decrease was primarily due to lower losses on extinguishment of debt. We expect to incur additional interest expense in future periods as a result of indebtedness associated with the pending VMware Merger.

[0001730168-22-000118:mdna:98]
Other income (expense), net.  Other income (expense), net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other expense, net, was $54 million for fiscal year 2022,  compared to other income, net, of $131 million for fiscal year 2021. The change was primarily due to changes in investment gains or losses.

[0001730168-22-000118:mdna:99]
Provision for income taxes.  The provision for income taxes was $939 million and $29 million for fiscal years 2022 and 2021, respectively. The increase was primarily due to higher income from continuing operations before income taxes.

[0001730168-22-000118:mdna:100]
Liquidity and Capital Resources

[0001730168-22-000118:mdna:101]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-22-000118:mdna:102]
Our primary sources of liquidity as of October 30, 2022 consisted of: (i) $12,416 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit

[0001730168-22-000118:mdna:103]
43

[0001730168-22-000118:mdna:104]
facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-22-000118:mdna:105]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, including the pending VMware Merger, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our $41,218 million of outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. We expect capital expenditures to be higher in fiscal year 2023 as compared to fiscal year 2022. Our debt and liquidity needs will increase as a result of the pending VMware Merger, and we intend to fund the cash portion of the consideration with $32 billion in new, fully committed debt financing.

[0001730168-22-000118:mdna:106]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility, as well as the committed debt funding related to the pending VMware Merger, will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. For additional information regarding our cash requirement from contractual obligations, indebtedness and lease obligations, see Note 14. “Commitments and Contingencies”, Note 10. “Borrowings” and Note 6. “Leases” in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-22-000118:mdna:107]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-22-000118:mdna:108]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0001730168-22-000118:mdna:109]
Working Capital

[0001730168-22-000118:mdna:110]
Working capital increased to $11,452 million at October 30, 2022 from $10,305 million at October 31, 2021. The increase was attributable to the following:

[0001730168-22-000118:mdna:111]
•Accounts receivable increased to $2,958 million at October 30, 2022 from $2,071 million at October 31, 2021, primarily due to revenue linearity and less receivables sold through factoring arrangements.

[0001730168-22-000118:mdna:112]
•Inventory increased to $1,925 million at October 30, 2022 from $1,297 million at October 31, 2021, primarily to support customer demand and due to higher material costs.

[0001730168-22-000118:mdna:113]
•Cash and cash equivalents increased to $12,416 million at October 30, 2022 from $12,163 million at October 31, 2021, primarily due to $16,736 million in net cash provided by operating activities and $1,935 million in proceeds from long-term borrowings, partially offset by $7,032 million of dividend payments, $7,000 million of common stock repurchases, $2,361 million of debt payments, and $1,455 million of employee withholding tax payments related to net settled equity awards.

[0001730168-22-000118:mdna:114]
•Other current assets increased to $1,205 million at October 30, 2022 from $1,055 million at October 31, 2021, primarily due to an increase in prepaid taxes, offset in part by a decrease in short-term investments.

[0001730168-22-000118:mdna:115]
These increases in working capital were offset in part by the following:

[0001730168-22-000118:mdna:116]
•Other current liabilities increased to $4,412 million at October 30, 2022 from $3,839 million at October 31, 2021, primarily due to increases in contract liabilities, taxes payable and interest payable.

[0001730168-22-000118:mdna:117]
•Current portion of long-term debt increased to $440 million at October 30, 2022 from $290 million at October 31, 2021, primarily due to certain debt instruments becoming due within the next twelve months, offset in part by repayments.

[0001730168-22-000118:mdna:118]
•Employee compensation and benefits increased to $1,202 million at October 30, 2022 from $1,066 million at October 31, 2021, primarily due to higher variable compensation based on current fiscal year performance.

[0001730168-22-000118:mdna:119]
Capital Returns

[0001730168-22-000118:mdna:120]
|  |  | Fiscal Year Ended |
| Cash Dividends Declared and Paid |  | October 30, 2022 |  | October 31, 2021 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 16.40 |  |  | $ | 14.40 |  |
| Dividends to common stockholders |  | $ | 6,733 |  |  | $ | 5,913 |  |
| Dividends per share to preferred stockholders |  | $ | 80.00 |  |  | $ | 80.00 |  |
| Dividends to preferred stockholders |  | $ | 299 |  |  | $ | 299 |  |

[0001730168-22-000118:mdna:121]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. During fiscal year 2022, we repurchased and retired approximately 12 million shares of our common stock for $7 billion under this stock repurchase program. In May 2022, our Board of Directors authorized another stock repurchase program to repurchase up to an additional $10 billion of our common stock from time to time through December 31, 2023.

[0001730168-22-000118:mdna:122]
Repurchases under our stock repurchase programs may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase programs may be suspended or terminated at any time.

[0001730168-22-000118:mdna:123]
During fiscal years 2022 and 2021, we paid approximately $1,455 million and $1,299 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 3 million shares of common stock from employees in connection with such net share settlements during each of fiscal years 2022 and 2021.

[0001730168-22-000118:mdna:124]
Cash Flows

[0001730168-22-000118:mdna:125]
|  |  | Fiscal Year Ended |
|  |  | October 30, 2022 |  | October 31, 2021 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 16,736 |  |  | $ | 13,764 |  |
| Net cash used in investing activities |  | (667) |  |  | (245) |  |
| Net cash used in financing activities |  | (15,816) |  |  | (8,974) |  |
| Net change in cash and cash equivalents |  | $ | 253 |  |  | $ | 4,545 |  |

[0001730168-22-000118:mdna:126]
Operating Activities

[0001730168-22-000118:mdna:127]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $2,972 million increase in cash provided by operations during fiscal year 2022 compared to fiscal year 2021 was due to $4,759 million higher net income and certain non-cash adjustments including deferred taxes and other non-cash taxes, offset by a decrease in amortization of intangible assets and stock-based compensation, as well as a $1,527 million decrease resulting from changes in operating assets and liabilities.

[0001730168-22-000118:mdna:128]
Investing Activities

[0001730168-22-000118:mdna:129]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures, and sales and purchases of investments. The $422 million increase in cash used in investing activities for fiscal year 2022 compared to fiscal year 2021 was primarily due to a $238 million increase in cash paid for acquisitions and $169 million lower net proceeds from sales of investments.

[0001730168-22-000118:mdna:130]
Financing Activities

[0001730168-22-000118:mdna:131]
Cash flows from financing activities primarily consisted of dividend payments, stock repurchases, proceeds and payments related to our long-term borrowings, and employee withholding tax payments related to net settled equity awards. The $6,842 million increase in cash used in financing activities for fiscal year 2022 compared to fiscal year 2021 was primarily

[0001730168-22-000118:mdna:132]
due to $7,000 million in common stock repurchases, a $820 million increase in dividend payments, and a $156 million increase in employee withholding tax payments related to net settled equity awards, offset in part by a $1,165 million change in net borrowing activities.

[0001730168-22-000118:mdna:133]
Accounting Changes and Recent Accounting Standards

[0001730168-22-000118:mdna:134]
For a description of accounting changes and recent accounting standards, including the expected dates of adoption and estimated effects, if any, in our consolidated financial statements, see Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K.
