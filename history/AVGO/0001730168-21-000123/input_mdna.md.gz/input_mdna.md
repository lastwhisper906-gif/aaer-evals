# AVGO MD&A — 0001730168-21-000123


## mdna

[0001730168-21-000123:mdna:1]
[same as prior period, unchanged from 0001730168-21-000116:mdna:1]

[0001730168-21-000123:mdna:2]
[same as prior period, unchanged from 0001730168-21-000116:mdna:3]

[0001730168-21-000123:mdna:3]
[same as prior period, unchanged from 0001730168-21-000116:mdna:4]

[0001730168-21-000123:mdna:4]
[same as prior period, unchanged from 0001730168-21-000116:mdna:5]

[0001730168-21-000123:mdna:5]
[same as prior period, unchanged from 0001730168-21-000116:mdna:6]

[0001730168-21-000123:mdna:6]
[same as prior period, unchanged from 0001730168-21-000116:mdna:7]

[0001730168-21-000123:mdna:7]
Highlights during the fiscal quarter ended August 1, 2021 include the following:

[0001730168-21-000123:mdna:8]
•We generated $3,541 million of cash from operations.

[0001730168-21-000123:mdna:9]
•We paid $1,556 million in cash dividends.

[0001730168-21-000123:mdna:10]
[same as prior period, unchanged from 0001730168-21-000116:mdna:17]

[0001730168-21-000123:mdna:11]
[same as prior period, unchanged from 0001730168-21-000116:mdna:12]

[0001730168-21-000123:mdna:12]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in some of our employees working remotely for an extended period of time. While we have implemented a phased-in return of employees to many of our facilities, we may need to modify our business practices and policies. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-21-000123:mdna:13]
The demand environment for our semiconductor products was consistent with our expectations for the third quarter of our fiscal year ending October 31, 2021 (“fiscal year 2021”), with continued demand for products and infrastructure to support a dramatic increase around the world in remote or tele-work and learning due to COVID-19. While we continue to see robust demand in this area, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. To date, the impact of COVID-19 on the demand environment for our software products has been limited. On the product supply side, we continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. While supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet increased demand.

[0001730168-21-000123:mdna:14]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty. In addition, we have continued to strengthen our balance sheet, including closely managing working capital and our debt instruments.

[0001730168-21-000123:mdna:15]
[same as prior period, unchanged from 0001730168-21-000116:mdna:16]

[0001730168-21-000123:mdna:16]
[same as prior period, unchanged from 0001730168-21-000116:mdna:18]

[0001730168-21-000123:mdna:17]
[same as prior period, unchanged from 0001730168-21-000116:mdna:19]

[0001730168-21-000123:mdna:18]
There were no significant changes in our critical accounting policies during the three fiscal quarters ended August 1, 2021 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2020 Annual Report on Form 10-K.

[0001730168-21-000123:mdna:19]
[same as prior period, unchanged from 0001730168-21-000116:mdna:21]

[0001730168-21-000123:mdna:20]
Fiscal Quarter and Three Fiscal Quarters Ended August 1, 2021 Compared to Fiscal Quarter and Three Fiscal Quarters Ended August 2, 2020

[0001730168-21-000123:mdna:21]
[same as prior period, unchanged from 0001730168-21-000116:mdna:25]

[0001730168-21-000123:mdna:22]
[same as prior period, unchanged from 0001730168-21-000116:mdna:23]

[0001730168-21-000123:mdna:23]
|  |  | Fiscal Quarter Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 5,064 |  |  | $ | 4,125 |  |  | 75 | % |  | 71 | % |
| Subscriptions and services |  | 1,714 |  |  | 1,696 |  |  | 25 |  |  | 29 |  |
| Total net revenue |  | 6,778 |  |  | 5,821 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 1,572 |  |  | 1,383 |  |  | 23 |  |  | 24 |  |
| Cost of subscriptions and services |  | 157 |  |  | 154 |  |  | 2 |  |  | 3 |  |
| Amortization of acquisition-related intangible assets |  | 851 |  |  | 953 |  |  | 13 |  |  | 16 |  |
| Restructuring charges |  | 1 |  |  | 15 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 2,581 |  |  | 2,505 |  |  | 38 |  |  | 43 |  |
| Gross margin |  | 4,197 |  |  | 3,316 |  |  | 62 |  |  | 57 |  |
| Research and development |  | 1,205 |  |  | 1,228 |  |  | 18 |  |  | 21 |  |
| Selling, general and administrative |  | 346 |  |  | 428 |  |  | 5 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 600 |  |  | 8 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 52 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 2,071 |  |  | 2,308 |  |  | 31 |  |  | 40 |  |
| Operating income |  | $ | 2,126 |  |  | $ | 1,008 |  |  | 31 | % |  | 17 | % |

[0001730168-21-000123:mdna:24]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 15,128 |  |  | $ | 12,582 |  |  | 75 | % |  | 72 | % |
| Subscriptions and services |  | 4,915 |  |  | 4,839 |  |  | 25 |  |  | 28 |  |
| Total net revenue |  | 20,043 |  |  | 17,421 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,792 |  |  | 4,290 |  |  | 24 |  |  | 25 |  |
| Cost of subscriptions and services |  | 450 |  |  | 475 |  |  | 2 |  |  | 3 |  |
| Amortization of acquisition-related intangible assets |  | 2,578 |  |  | 2,857 |  |  | 13 |  |  | 16 |  |
| Restructuring charges |  | 17 |  |  | 30 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 7,837 |  |  | 7,652 |  |  | 39 |  |  | 44 |  |
| Gross margin |  | 12,206 |  |  | 9,769 |  |  | 61 |  |  | 56 |  |
| Research and development |  | 3,654 |  |  | 3,786 |  |  | 18 |  |  | 22 |  |
| Selling, general and administrative |  | 1,010 |  |  | 1,530 |  |  | 5 |  |  | 9 |  |
| Amortization of acquisition-related intangible assets |  | 1,482 |  |  | 1,802 |  |  | 7 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 122 |  |  | 163 |  |  | 1 |  |  | 1 |  |
| Total operating expenses |  | 6,268 |  |  | 7,281 |  |  | 31 |  |  | 42 |  |
| Operating income |  | $ | 5,938 |  |  | $ | 2,488 |  |  | 30 | % |  | 14 | % |

[0001730168-21-000123:mdna:25]
[same as prior period, unchanged from 0001730168-21-000116:mdna:31]

[0001730168-21-000123:mdna:26]
[same as prior period, unchanged from 0001730168-21-000116:mdna:27]

[0001730168-21-000123:mdna:27]
Historically, a relatively small number of customers have accounted for a significant portion of our net revenue. Direct sales to WT Microelectronics, a distributor, accounted for 16% and 17% of our net revenue for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and 12% of our net revenue for the three fiscal quarters ended August 2, 2020. No customer accounted for more than 10% of our net revenue for the fiscal quarter ended August 2, 2020.

[0001730168-21-000123:mdna:28]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 35% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 1, 2021 and approximately 25% and 30% of our net revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% of our net revenue for each of the fiscal quarter and three fiscal quarters ended August 1, 2021, and approximately 10% and 15% of our net revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-21-000123:mdna:29]
[same as prior period, unchanged from 0001730168-21-000116:mdna:30]

[0001730168-21-000123:mdna:30]
[same as prior period, unchanged from 0001730168-21-000116:mdna:32]

[0001730168-21-000123:mdna:31]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | August 1, 2021 |  | August 2, 2020 |  | $ Change |  | % Change |  | August 1, 2021 |  | August 2, 2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 5,021 |  |  | $ | 4,219 |  |  | $ | 802 |  |  | 19 | % |  | $ | 14,749 |  |  | $ | 12,437 |  |  | $ | 2,312 |  |  | 19 | % |
| Infrastructure software |  | 1,757 |  |  | 1,602 |  |  | 155 |  |  | 10 | % |  | 5,294 |  |  | 4,984 |  |  | 310 |  |  | 6 | % |
| Total net revenue |  | $ | 6,778 |  |  | $ | 5,821 |  |  | $ | 957 |  |  | 16 | % |  | $ | 20,043 |  |  | $ | 17,421 |  |  | $ | 2,622 |  |  | 15 | % |

[0001730168-21-000123:mdna:32]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Net Revenue by Segment |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 74 | % |  | 72 | % |  | 74 | % |  | 71 | % |
| Infrastructure software |  | 26 |  |  | 28 |  |  | 26 |  |  | 29 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-21-000123:mdna:33]
Fiscal quarter ended August 1, 2021 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as the delayed production ramp of a new mobile handset by a major customer, which resulted in lower shipments in the prior year fiscal period. Net revenue from our semiconductor solutions segment also increased due to higher demand for our networking products driven by service providers’ continued investments, as well as higher demand for our wireless connectivity products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our FC SAN products and mainframe solutions.

[0001730168-21-000123:mdna:34]
Three fiscal quarters ended August 1, 2021 compared to corresponding prior year period. Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as the delayed production ramp of a new mobile handset by a major customer, which resulted in lower shipments in the prior year fiscal period. Net revenue from our semiconductor solutions segment also increased due to higher demand for our networking products driven by service providers’ continued investments, as well as higher demand for our wireless connectivity products, partially offset by lower demand for our server storage products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our FC SAN products, mainframe and cyber security solutions.

[0001730168-21-000123:mdna:35]
28

[0001730168-21-000123:mdna:36]
[same as prior period, unchanged from 0001730168-21-000116:mdna:37]

[0001730168-21-000123:mdna:37]
Gross margin was $4,197 million for the fiscal quarter ended August 1, 2021 compared to $3,316 million for the fiscal quarter ended August 2, 2020 and $12,206 million for the three fiscal quarters ended August 1, 2021 compared to $9,769 million for the three fiscal quarters ended August 2, 2020. As a percentage of net revenue, gross margin was 62% and 61% of net revenue for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and 57% and 56% of net revenue for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively.

[0001730168-21-000123:mdna:38]
The increases in gross margin were primarily due to lower amortization of acquisition-related intangible assets and favorable margin within our semiconductor solutions segment due to increased demand compared to the prior year fiscal periods.

[0001730168-21-000123:mdna:39]
[same as prior period, unchanged from 0001730168-21-000116:mdna:40]

[0001730168-21-000123:mdna:40]
Research and development expense decreased $23 million, or 2%, and $132 million, or 3%, for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures, partially offset by higher variable employee compensation expense.

[0001730168-21-000123:mdna:41]
[same as prior period, unchanged from 0001730168-21-000116:mdna:42]

[0001730168-21-000123:mdna:42]
Selling, general and administrative expense decreased $82 million, or 19%, and $520 million, or 34%, for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to higher acquisition-related costs incurred in the prior year fiscal periods as a result of our acquisition of the Symantec Corporation Enterprise Security business (the “Symantec Business”). The decreases were also due to lower compensation expense reflecting the full benefit of the completed Symantec Business integration. In addition, fiscal year 2020 included non-recurring litigation settlements.

[0001730168-21-000123:mdna:43]
[same as prior period, unchanged from 0001730168-21-000116:mdna:44]

[0001730168-21-000123:mdna:44]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $106 million and $320 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to lower amortization of certain intangible assets from our acquisition of CA, Inc.

[0001730168-21-000123:mdna:45]
[same as prior period, unchanged from 0001730168-21-000116:mdna:46]

[0001730168-21-000123:mdna:46]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $26 million and $41 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to the prior year fiscal periods. The decreases were primarily due to higher employee termination costs in the prior year fiscal periods from cost reduction activities related to our acquisition of the Symantec Business.

[0001730168-21-000123:mdna:47]
[same as prior period, unchanged from 0001730168-21-000116:mdna:48]

[0001730168-21-000123:mdna:48]
Total stock-based compensation expense was $421 million and $1,290 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to $465 million and $1,527 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. The decreases primarily reflect the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-21-000123:mdna:49]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of August 1, 2021.

[0001730168-21-000123:mdna:50]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 413 |  |
| 2022 |  | 1,279 |  |
| 2023 |  | 896 |  |
| 2024 |  | 522 |  |
| 2025 |  | 199 |  |
| Thereafter |  | 25 |  |
| Total |  | $ | 3,334 |  |

[0001730168-21-000123:mdna:51]
[same as prior period, unchanged from 0001730168-21-000116:mdna:55]

[0001730168-21-000123:mdna:52]
[same as prior period, unchanged from 0001730168-21-000116:mdna:52]

[0001730168-21-000123:mdna:53]
[same as prior period, unchanged from 0001730168-21-000116:mdna:53]

[0001730168-21-000123:mdna:54]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
| Operating Income by Segment |  | August 1,2021 |  | August 2,2020 |  | $ Change |  | % Change |  | August 1, 2021 |  | August 2, 2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 2,720 |  |  | $ | 2,112 |  |  | $ | 608 |  |  | 29 | % |  | $ | 7,828 |  |  | $ | 6,046 |  |  | $ | 1,782 |  |  | 29 | % |
| Infrastructure software |  | 1,226 |  |  | 1,069 |  |  | 157 |  |  | 15 | % |  | 3,700 |  |  | 3,250 |  |  | 450 |  |  | 14 | % |
| Unallocated expenses |  | (1,820) |  |  | (2,173) |  |  | 353 |  |  | (16) | % |  | (5,590) |  |  | (6,808) |  |  | 1,218 |  |  | (18) | % |
| Total operating income |  | $ | 2,126 |  |  | $ | 1,008 |  |  | $ | 1,118 |  |  | 111 | % |  | $ | 5,938 |  |  | $ | 2,488 |  |  | $ | 3,450 |  |  | 139 | % |

[0001730168-21-000123:mdna:55]
Fiscal quarter ended August 1, 2021 compared to corresponding prior year period. Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as the delayed production ramp of a new mobile handset by a major customer, which resulted in lower shipments in the prior year fiscal period. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and wireless connectivity products, as well as higher gross margin. Operating income from our infrastructure software segment increased primarily due to higher demand for our FC SAN products and mainframe solutions.

[0001730168-21-000123:mdna:56]
Three fiscal quarters ended August 1, 2021 compared to corresponding prior year period. Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless content in mobile handsets, as well as the delayed production ramp of a new mobile handset by a major customer, which resulted in lower shipments in the prior year fiscal period. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and wireless connectivity products, as well as higher gross margin, partially offset by lower demand for our server storage products. Operating income from our infrastructure software segment increased primarily due to higher demand for our FC SAN products, mainframe and cyber security solutions.

[0001730168-21-000123:mdna:57]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 16% and 18% for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to prior year fiscal periods. The decreases were primarily due to lower amortization of acquisition-related intangible assets, acquisition-related costs and stock-based compensation expense.

[0001730168-21-000123:mdna:58]
[same as prior period, unchanged from 0001730168-21-000116:mdna:59]

[0001730168-21-000123:mdna:59]
Interest expense. Interest expense was $415 million and $1,451 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and $464 million and $1,357 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. The decrease for the fiscal quarter ended August 1, 2021 was primarily due to losses on extinguishment of debt related to refinancing activities incurred in the prior year fiscal period. The increase for the three fiscal quarters ended August 1, 2021 was primarily due to higher losses on extinguishment of debt related to refinancing activities and higher interest expense.

[0001730168-21-000123:mdna:60]
Other income, net. Other income, net, includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $109 million and $175 million for the three fiscal quarters ended August 1, 2021 and  August 2, 2020, respectively. The decrease was primarily due to a $116 million non-recurring gain from the lapse of a tax indemnification arrangement included in the prior year fiscal period, offset in part by an increase in gains on investments in the current year fiscal period.

[0001730168-21-000123:mdna:61]
Benefit from income taxes. The benefit from income taxes was $150 million and $151 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and $96 million and $331 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively.

[0001730168-21-000123:mdna:62]
[same as prior period, unchanged from 0001730168-21-000116:mdna:67]

[0001730168-21-000123:mdna:63]
The benefit from income taxes for the fiscal quarter ended August 1, 2021 was primarily due to excess tax benefits from stock-based awards, the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, and the jurisdictional mix of income and expense. The benefit from income taxes for the three fiscal quarters ended August 1, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, offset in part by higher taxes on income from continuing operations.

[0001730168-21-000123:mdna:64]
The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 2, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities and excess tax benefits from stock-based awards.

[0001730168-21-000123:mdna:65]
[same as prior period, unchanged from 0001730168-21-000116:mdna:64]

[0001730168-21-000123:mdna:66]
[same as prior period, unchanged from 0001730168-21-000116:mdna:65]

[0001730168-21-000123:mdna:67]
Our primary sources of liquidity as of August 1, 2021 consisted of: (i) $11,105 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-21-000123:mdna:68]
[same as prior period, unchanged from 0001730168-21-000116:mdna:68]

[0001730168-21-000123:mdna:69]
[same as prior period, unchanged from 0001730168-21-000116:mdna:69]

[0001730168-21-000123:mdna:70]
[same as prior period, unchanged from 0001730168-21-000116:mdna:70]

[0001730168-21-000123:mdna:71]
[same as prior period, unchanged from 0001730168-21-000116:mdna:71]

[0001730168-21-000123:mdna:72]
[same as prior period, unchanged from 0001730168-21-000116:mdna:72]

[0001730168-21-000123:mdna:73]
Working capital increased to $9,135 million at August 1, 2021 from $5,524 million at November 1, 2020. The increase was primarily attributable to the following:

[0001730168-21-000123:mdna:74]
•Cash and cash equivalents increased to $11,105 million at August 1, 2021 from $7,618 million at November 1, 2020, primarily due to $10,223 million in net cash provided by operating activities and $9,904 million in proceeds from long-term borrowings. These increases were partially offset by $10,733 million of debt payments, $4,651 million of dividend payments, and $1,033 million of employee withholding tax payments related to net settled equity awards.

[0001730168-21-000123:mdna:75]
•Current portion of long-term debt decreased to $279 million at August 1, 2021 from $827 million at November 1, 2020 due to repayments of certain debt instruments.

[0001730168-21-000123:mdna:76]
•Other current assets increased to $1,137 million at August 1, 2021 from $977 million at November 1, 2020, primarily due to increases in prepaid taxes.

[0001730168-21-000123:mdna:77]
[same as prior period, unchanged from 0001730168-21-000116:mdna:84]

[0001730168-21-000123:mdna:78]
•Inventory increased to $1,160 million at August 1, 2021 from $1,003 million at November 1, 2020, primarily to support customer demand.

[0001730168-21-000123:mdna:79]
[same as prior period, unchanged from 0001730168-21-000116:mdna:79]

[0001730168-21-000123:mdna:80]
•Other current liabilities increased to $4,361 million at August 1, 2021 from $3,831 million at November 1, 2020, primarily due to increases in contract liabilities and interest payable.

[0001730168-21-000123:mdna:81]
•Accounts payable increased to $968 million at August 1, 2021 from $836 million at November 1, 2020, primarily due to the timing of payments.

[0001730168-21-000123:mdna:82]
Working capital increased to $6,979 million at August 2, 2020 from $3,018 million at November 3, 2019. The increase was attributable to the following:

[0001730168-21-000123:mdna:83]
•Cash and cash equivalents increased to $8,857 million at August 2, 2020 from $5,055 million at November 3, 2019, primarily due to $27,802 million in proceeds from long-term borrowings and $8,713 million in net cash provided by operating activities. These increases were partially offset by $17,099 million of debt repayments, $10.7 billion of our acquisition of the Symantec Business (the “Symantec Asset Purchase”), and $4,139 million of dividend payments.

[0001730168-21-000123:mdna:84]
•Inventory increased to $1,081 million at August 2, 2020 from $874 million at November 3, 2019, primarily due to the timing of customer product ramps.

[0001730168-21-000123:mdna:85]
•Other current assets increased to $1,059 million at August 2, 2020 from $729 million at November 3, 2019, primarily due to increases in prepaid taxes and short-term investments.

[0001730168-21-000123:mdna:86]
•Current portion of long-term debt decreased to $822 million at August 2, 2020 from $2,787 million at November 3, 2019, primarily due to repayment of certain debt instruments, partially offset by certain debt instruments becoming due within the next twelve months.

[0001730168-21-000123:mdna:87]
[same as prior period, unchanged from 0001730168-21-000116:mdna:87]

[0001730168-21-000123:mdna:88]
•Accounts receivable decreased to $2,684 million at August 2, 2020 from $3,259 million at November 3, 2019, primarily due to revenue linearity and $552 million of additional receivables sold through factoring arrangements.

[0001730168-21-000123:mdna:89]
•Accounts payable increased to $1,092 million at August 2, 2020 from $855 million at November 3, 2019, primarily due to the timing of vendor payments.

[0001730168-21-000123:mdna:90]
•Other current liabilities increased to $4,056 million at August 2, 2020 from $2,616 million at November 3, 2019, primarily due to increases in contract liabilities, interest payable, lease liabilities resulting from the adoption of the new lease standard, and higher taxes payable, partially offset by repayments of notional pooling liabilities.

[0001730168-21-000123:mdna:91]
[same as prior period, unchanged from 0001730168-21-000116:mdna:90]

[0001730168-21-000123:mdna:92]
|  |  | Three Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 10.80 |  |  | $ | 9.75 |  |
| Dividends to common stockholders |  | $ | 4,427 |  |  | $ | 3,915 |  |
| Dividends per share to preferred stockholders |  | $ | 60.00 |  |  | $ | 60.00 |  |
| Dividends to preferred stockholders |  | $ | 224 |  |  | $ | 224 |  |

[0001730168-21-000123:mdna:93]
During the three fiscal quarters ended August 1, 2021 and August 2, 2020, we paid approximately $1,033 million and $580 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 2 million shares of common stock from employees in connection with such net share settlements during each of the three fiscal quarters ended August 1, 2021 and August 2, 2020.

[0001730168-21-000123:mdna:94]
[same as prior period, unchanged from 0001730168-21-000116:mdna:93]

[0001730168-21-000123:mdna:95]
|  |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 10,223 |  |  | $ | 8,713 |  |
| Net cash used in investing activities |  | (295) |  |  | (11,009) |  |
| Net cash provided by (used in) financing activities |  | (6,441) |  |  | 6,098 |  |
| Net change in cash and cash equivalents |  | $ | 3,487 |  |  | $ | 3,802 |  |

[0001730168-21-000123:mdna:96]
[same as prior period, unchanged from 0001730168-21-000116:mdna:95]

[0001730168-21-000123:mdna:97]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,510 million increase in cash provided by operations during the three fiscal quarters ended August 1, 2021 compared to the prior year fiscal period was due to $3,111 million higher net income, offset by a $976 million decrease in amortization of intangible assets and stock-based compensation and other adjustments, as well as a $625 million decrease resulting from changes in operating assets and liabilities.

[0001730168-21-000123:mdna:98]
[same as prior period, unchanged from 0001730168-21-000116:mdna:97]

[0001730168-21-000123:mdna:99]
Cash flows from investing activities primarily consisted of cash used for acquisitions and capital expenditures. The $10,714 million decrease in cash used in investing activities during the three fiscal quarters ended August 1, 2021 compared to the prior year fiscal period was primarily related to a $10,864 million decrease in cash paid for acquisitions.

[0001730168-21-000123:mdna:100]
[same as prior period, unchanged from 0001730168-21-000116:mdna:99]

[0001730168-21-000123:mdna:101]
Cash flows from financing activities primarily consisted of proceeds and payments related to our long-term borrowings, dividend payments and employee withholding tax payments related to net settled equity awards. The $12,539 million change in cash related to financing activities during the three fiscal quarters ended August 1, 2021 compared to the prior year fiscal period was primarily due to an $11,532 million change in net borrowing activities, a $512 million increase in dividend payments and a $453 million increase in employee withholding tax payments related to net settled equity awards.

[0001730168-21-000123:mdna:102]
[same as prior period, unchanged from 0001730168-21-000116:mdna:101]

[0001730168-21-000123:mdna:103]
[same as prior period, unchanged from 0001730168-21-000116:mdna:102]

[0001730168-21-000123:mdna:104]
[same as prior period, unchanged from 0001730168-21-000116:mdna:103]

[0001730168-21-000123:mdna:105]
[same as prior period, unchanged from 0001730168-21-000116:mdna:104]

[0001730168-21-000123:mdna:106]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom, BRCM and BTI (collectively, the “Obligor Group”) to merge, consolidate or sell all or substantially all of their assets.

[0001730168-21-000123:mdna:107]
Broadcom and BTI fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2017 Senior Notes. Because the guarantees are not secured, they are effectively subordinated to any existing and future secured indebtedness of the guarantors to the extent of the value of the collateral securing that indebtedness. The guarantee by Broadcom and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs in compliance with the 2017 Indentures. The guarantee by Broadcom (1) will also be automatically and unconditionally released at such time as: (A) the 2017 Senior Notes Co-Issuers, in their sole discretion, determine that such guarantee is no longer required by Rule 3-10(a), as applicable, of Regulation S-X to except the 2017 Senior Notes Co-Issuers’ financial statements from being required to be filed pursuant to Rule 3-10(a) of Regulation S-X or otherwise facilitate a reduction in its financial reporting obligations or (B) either of the 2017 Senior Notes Co-Issuers becomes subject to Section 13 or 15(d) of the Exchange Act and (2) may, at the election of the 2017

[0001730168-21-000123:mdna:108]
Senior Notes Co-Issuers, be unconditionally released at such time as Broadcom is eligible to suspend its reporting obligation under the Exchange Act.

[0001730168-21-000123:mdna:109]
[same as prior period, unchanged from 0001730168-21-000116:mdna:107]

[0001730168-21-000123:mdna:110]
[same as prior period, unchanged from 0001730168-21-000116:mdna:108]

[0001730168-21-000123:mdna:111]
| Summarized Balance Sheet Information |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions) |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 1,228 |  |  | $ | 1,889 |  |
| Other current assets |  | 9,153 |  |  | 4,091 |  |
| Total current assets |  | $ | 10,381 |  |  | $ | 5,980 |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 5,825 |  |  | $ | 8,220 |  |
| Goodwill |  | 1,380 |  |  | 1,360 |  |
| Other long-term assets |  | 1,530 |  |  | 1,318 |  |
| Total long-term assets |  | $ | 8,735 |  |  | $ | 10,898 |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 7,726 |  |  | $ | 7,147 |  |
| Current portion of long-term debt |  | 255 |  |  | 807 |  |
| Other current liabilities |  | 587 |  |  | 601 |  |
| Total current liabilities |  | $ | 8,568 |  |  | $ | 8,555 |  |
| Long-term liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group, long-term |  | $ | 484 |  |  | $ | — |  |
| Long-term debt |  | 39,658 |  |  | 39,311 |  |
| Other long-term liabilities |  | 2,658 |  |  | 2,477 |  |
| Total long-term liabilities |  | $ | 42,800 |  |  | $ | 41,788 |  |

[0001730168-21-000123:mdna:112]
|  |  | Three Fiscal Quarters Ended |
| Summarized Statement of Operations Information |  | August 1,2021 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 1,311 |  |
| Intercompany gross margin |  | $ | 1,186 |  |
| Net loss (a) |  | $ | (983) |  |

[0001730168-21-000123:mdna:113]
[same as prior period, unchanged from 0001730168-21-000116:mdna:111]

[0001730168-21-000123:mdna:114]
(a) In addition to intercompany gross margin, there were $691 million of intercompany transactions included in net loss.

[0001730168-21-000123:mdna:115]
[same as prior period, unchanged from 0001730168-21-000116:mdna:113]

[0001730168-21-000123:mdna:116]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000123:mdna:117]
[same as prior period, unchanged from 0001730168-21-000116:mdna:115]

[0001730168-21-000123:mdna:118]
We had no material off-balance sheet arrangements at August 1, 2021 as defined in Item 303(a)(4)(ii) of Regulation S-K under the Exchange Act.

[0001730168-21-000123:mdna:119]
[same as prior period, unchanged from 0001730168-21-000116:mdna:117]

[0001730168-21-000123:mdna:120]
See Note 11. “Commitments and Contingencies” in Part I, Item 1 of this Form 10-Q.

[0001730168-21-000123:mdna:121]
[same as prior period, unchanged from 0001730168-21-000116:mdna:119]

[0001730168-21-000123:mdna:122]
[same as prior period, unchanged from 0001730168-21-000116:mdna:120]
