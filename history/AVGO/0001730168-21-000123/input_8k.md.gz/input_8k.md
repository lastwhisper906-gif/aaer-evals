# AVGO 8-K — 0001730168-21-000121 filed 2021-09-02

## item codes, every 8-K on or before 2021-09-09

- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2021-09-09

- none on or before 2021-09-09

## item 2.02 — earnings release, exhibit 99.1

[0001730168-21-000121:8k_2_02:1]
EX-99.1
2
avgo-08012021x8kxex99.htm
EX-99.1

[0001730168-21-000121:8k_2_02:2]
Document

[0001730168-21-000121:8k_2_02:3]
Exhibit 99.1

[0001730168-21-000121:8k_2_02:4]
Broadcom Inc. Announces Third Quarter Fiscal Year 2021 Financial Results and Quarterly Dividends

[0001730168-21-000121:8k_2_02:5]
•Revenue of $6,778 million for the third quarter, up 16 percent from the prior year period

[0001730168-21-000121:8k_2_02:6]
•GAAP net income of $1,876 million for the third quarter; Adjusted EBITDA of $4,123 million for the third quarter

[0001730168-21-000121:8k_2_02:7]
•GAAP diluted EPS of $4.20 for the third quarter; Non-GAAP diluted EPS of $6.96 for the third quarter

[0001730168-21-000121:8k_2_02:8]
•$3,426 million of free cash flow from operations for the third quarter, defined as cash from operations of $3,541 million less capital expenditures of $115 million

[0001730168-21-000121:8k_2_02:9]
•Quarterly common stock dividend of $3.60 per share

[0001730168-21-000121:8k_2_02:10]
•Fourth quarter revenue guidance of approximately $7.35 billion, an expected increase of 14 percent from the prior year period

[0001730168-21-000121:8k_2_02:11]
•Fourth quarter Adjusted EBITDA guidance of approximately 61 percent of projected revenue  (1)

[0001730168-21-000121:8k_2_02:12]
SAN JOSE, Calif. – September 2, 2021 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its third quarter of fiscal year 2021, ended August 1, 2021, provided guidance for the fourth quarter of its fiscal year 2021 and announced its quarterly dividends.

[0001730168-21-000121:8k_2_02:13]
“Broadcom delivered record revenues in the third quarter reflecting our product and technology leadership across multiple secular growth markets in cloud, 5G infrastructure, broadband, and wireless,” said Hock Tan, President and CEO of Broadcom Inc. “We are projecting the momentum to continue in the fourth quarter.”

[0001730168-21-000121:8k_2_02:14]
“Our business model continues to perform. Consolidated revenue grew 16% year-over-year to $6.8 billion and operating profit increased 24% with adjusted EBITDA margin a record 61%,” said Kirsten Spears, CFO of Broadcom Inc. “We generated $3.4 billion in free cash flow or 51% of revenue in the quarter, and we expect free cash flow to remain strong in the fourth quarter.”

[0001730168-21-000121:8k_2_02:15]
Third Quarter Fiscal Year 2021 Financial Highlights

[0001730168-21-000121:8k_2_02:16]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q3 21 |  | Q3 20 |  | Change |  | Q3 21 |  | Q3 20 |  | Change |
| Net revenue |  | $ | 6,778 |  |  | $ | 5,821 |  |  | +16 | % |  | $ | 6,778 |  |  | $ | 5,821 |  |  | +16 | % |
| Net income |  | $ | 1,876 |  |  | $ | 688 |  |  | +$1,188 |  |  | $ | 3,124 |  |  | $ | 2,435 |  |  | +$689 |  |
| Earnings per common share - diluted |  | $ | 4.20 |  |  | $ | 1.45 |  |  | +$2.75 |  |  | $ | 6.96 |  |  | $ | 5.40 |  |  | +$1.56 |  |

[0001730168-21-000121:8k_2_02:17]
________________________________

[0001730168-21-000121:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-21-000121:8k_2_02:19]
1

[0001730168-21-000121:8k_2_02:20]
| (Dollars in millions) |  | Q3 21 |  | Q3 20 |  | Change |  |
| Cash flow from operations |  | $ | 3,541 |  |  | $ | 3,178 |  |  | +$363 |  |
| Adjusted EBITDA |  | $ | 4,123 |  |  | $ | 3,342 |  |  | +$781 |  |
| Free cash flow |  | $ | 3,426 |  |  | $ | 3,073 |  |  | +$353 |  |

[0001730168-21-000121:8k_2_02:21]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q3 21 |  |  |  | Q3 20 |  | Change |  |
| Semiconductor solutions |  | $ | 5,021 |  |  | 74 | % |  |  |  |  |  |  | $ | 4,219 |  |  | 72 | % |  | +19 | % |  |
| Infrastructure software |  | 1,757 |  |  | 26 |  |  |  |  |  |  |  | 1,602 |  |  | 28 |  |  | +10 | % |  |
| Total net revenue |  | $ | 6,778 |  |  | 100 | % |  |  |  |  |  |  | $ | 5,821 |  |  | 100 | % |  |  |  |  |

[0001730168-21-000121:8k_2_02:22]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $11,105 million, compared to $9,518 million at the end of the prior quarter.

[0001730168-21-000121:8k_2_02:23]
During the third fiscal quarter, the Company generated $3,541 million in cash from operations and spent $115 million on capital expenditures.

[0001730168-21-000121:8k_2_02:24]
On June 30, 2021, the Company paid a cash dividend of $3.60 per share of common stock, totaling $1,482 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $74 million.

[0001730168-21-000121:8k_2_02:25]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-21-000121:8k_2_02:26]
Fourth Quarter Fiscal Year 2021 Business Outlook

[0001730168-21-000121:8k_2_02:27]
Based on current business trends and conditions, the outlook for the fourth quarter of fiscal year 2021, ending October 31, 2021, is expected to be as follows:

[0001730168-21-000121:8k_2_02:28]
•Fourth quarter revenue guidance of approximately $7.35 billion; and

[0001730168-21-000121:8k_2_02:29]
•Fourth quarter Adjusted EBITDA guidance of approximately 61 percent of projected revenue

[0001730168-21-000121:8k_2_02:30]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000121:8k_2_02:31]
Quarterly Dividends

[0001730168-21-000121:8k_2_02:32]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $3.60 per share. The common stock dividend is payable on September 30, 2021 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 22, 2021.

[0001730168-21-000121:8k_2_02:33]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on September 30, 2021 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on September 15, 2021.

[0001730168-21-000121:8k_2_02:34]
Financial Results Conference Call

[0001730168-21-000121:8k_2_02:35]
Broadcom Inc. will host a conference call to review its financial results for the third quarter fiscal year 2021 and to discuss the business outlook, today at 2:00 p.m. Pacific Time. Those wishing to access the call should dial (866) 310-8712; International +1 (720) 634-2946. The passcode is 1962853. A replay of the call will be accessible for one week after the call. To access the replay dial (855) 859-2056; International +1 (404) 537-3406; and reference the passcode: 1962853. A webcast of the conference call will also be available in the “Investors” section of Broadcom’s website at https://www.broadcom.com.

[0001730168-21-000121:8k_2_02:36]
Non-GAAP Financial Measures

[0001730168-21-000121:8k_2_02:37]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-21-000121:8k_2_02:38]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-21-000121:8k_2_02:39]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-21-000121:8k_2_02:40]
About Broadcom Inc.

[0001730168-21-000121:8k_2_02:41]
3

[0001730168-21-000121:8k_2_02:42]
Broadcom Inc., (NASDAQ: AVGO), a Delaware corporation headquartered in San Jose, CA, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage, enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-21-000121:8k_2_02:43]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-21-000121:8k_2_02:44]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has disrupted, and will likely continue to disrupt, normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global economic conditions and concerns; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; cyclicality in the semiconductor industry or in our target markets; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products;

[0001730168-21-000121:8k_2_02:45]
4

[0001730168-21-000121:8k_2_02:46]
our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-21-000121:8k_2_02:47]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000121:8k_2_02:48]
Contact:

[0001730168-21-000121:8k_2_02:49]
Ji Yoo

[0001730168-21-000121:8k_2_02:50]
Broadcom Inc.

[0001730168-21-000121:8k_2_02:51]
Investor Relations

[0001730168-21-000121:8k_2_02:52]
408-433-8000

[0001730168-21-000121:8k_2_02:53]
investor.relations@broadcom.com

[0001730168-21-000121:8k_2_02:54]
BROADCOM INC.

[0001730168-21-000121:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-21-000121:8k_2_02:56]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-21-000121:8k_2_02:57]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | May 2,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
| Net revenue |  | $ | 6,778 |  |  | $ | 6,610 |  |  | $ | 5,821 |  |  | $ | 20,043 |  |  | $ | 17,421 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,729 |  |  | 1,699 |  |  | 1,537 |  |  | 5,242 |  |  | 4,765 |  |
| Amortization of acquisition-related intangible assets |  | 851 |  |  | 853 |  |  | 953 |  |  | 2,578 |  |  | 2,857 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 15 |  |  | 17 |  |  | 30 |  |
| Total cost of revenue |  | 2,581 |  |  | 2,553 |  |  | 2,505 |  |  | 7,837 |  |  | 7,652 |  |
| Gross margin |  | 4,197 |  |  | 4,057 |  |  | 3,316 |  |  | 12,206 |  |  | 9,769 |  |
| Research and development |  | 1,205 |  |  | 1,238 |  |  | 1,228 |  |  | 3,654 |  |  | 3,786 |  |
| Selling, general and administrative |  | 346 |  |  | 325 |  |  | 428 |  |  | 1,010 |  |  | 1,530 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 600 |  |  | 1,482 |  |  | 1,802 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 25 |  |  | 52 |  |  | 122 |  |  | 163 |  |
| Total operating expenses |  | 2,071 |  |  | 2,082 |  |  | 2,308 |  |  | 6,268 |  |  | 7,281 |  |
| Operating income |  | 2,126 |  |  | 1,975 |  |  | 1,008 |  |  | 5,938 |  |  | 2,488 |  |
| Interest expense |  | (415) |  |  | (466) |  |  | (464) |  |  | (1,451) |  |  | (1,357) |  |
| Other income (expense), net |  | 15 |  |  | (23) |  |  | 49 |  |  | 109 |  |  | 175 |  |
| Income from continuing operations before income taxes |  | 1,726 |  |  | 1,486 |  |  | 593 |  |  | 4,596 |  |  | 1,306 |  |
| Benefit from income taxes |  | (150) |  |  | (7) |  |  | (96) |  |  | (151) |  |  | (331) |  |
| Income from continuing operations |  | 1,876 |  |  | 1,493 |  |  | 689 |  |  | 4,747 |  |  | 1,637 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Net income |  | 1,876 |  |  | 1,493 |  |  | 688 |  |  | 4,747 |  |  | 1,636 |  |
| Dividends on preferred stock |  | (74) |  |  | (76) |  |  | (74) |  |  | (224) |  |  | (223) |  |
| Net income attributable to common stock |  | $ | 1,802 |  |  | $ | 1,417 |  |  | $ | 614 |  |  | $ | 4,523 |  |  | $ | 1,413 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.38 |  |  | $ | 3.46 |  |  | $ | 1.53 |  |  | $ | 11.06 |  |  | $ | 3.53 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income per share |  | $ | 4.38 |  |  | $ | 3.46 |  |  | $ | 1.52 |  |  | $ | 11.06 |  |  | $ | 3.52 |  |
| Diluted income per share attributable to common stock (1): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.20 |  |  | $ | 3.30 |  |  | $ | 1.46 |  |  | $ | 10.54 |  |  | $ | 3.37 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income per share |  | $ | 4.20 |  |  | $ | 3.30 |  |  | $ | 1.45 |  |  | $ | 10.54 |  |  | $ | 3.36 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 411 |  |  | 409 |  |  | 403 |  |  | 409 |  |  | 401 |  |
| Diluted |  | 429 |  |  | 429 |  |  | 422 |  |  | 429 |  |  | 420 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 36 |  |  | $ | 38 |  |  | $ | 37 |  |  | $ | 106 |  |  | $ | 121 |  |
| Research and development |  | 285 |  |  | 307 |  |  | 337 |  |  | 920 |  |  | 1,101 |  |
| Selling, general and administrative |  | 100 |  |  | 80 |  |  | 91 |  |  | 264 |  |  | 305 |  |
| Total stock-based compensation expense |  | $ | 421 |  |  | $ | 425 |  |  | $ | 465 |  |  | $ | 1,290 |  |  | $ | 1,527 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-21-000121:8k_2_02:58]
BROADCOM INC.

[0001730168-21-000121:8k_2_02:59]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-21-000121:8k_2_02:60]
(IN MILLIONS)

[0001730168-21-000121:8k_2_02:61]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | May 2,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
| Gross margin on GAAP basis |  | $ | 4,197 |  |  | $ | 4,057 |  |  | $ | 3,316 |  |  | $ | 12,206 |  |  | $ | 9,769 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 851 |  |  | 853 |  |  | 953 |  |  | 2,578 |  |  | 2,857 |  |
| Stock-based compensation expense |  | 36 |  |  | 38 |  |  | 37 |  |  | 106 |  |  | 121 |  |
| Restructuring charges |  | 1 |  |  | 1 |  |  | 15 |  |  | 17 |  |  | 30 |  |
| Acquisition-related costs |  | 3 |  |  | 3 |  |  | — |  |  | 9 |  |  | 6 |  |
| Gross margin on non-GAAP basis |  | $ | 5,088 |  |  | $ | 4,952 |  |  | $ | 4,321 |  |  | $ | 14,916 |  |  | $ | 12,794 |  |
| Research and development on GAAP basis |  | $ | 1,205 |  |  | $ | 1,238 |  |  | $ | 1,228 |  |  | $ | 3,654 |  |  | $ | 3,786 |  |
| Stock-based compensation expense |  | 285 |  |  | 307 |  |  | 337 |  |  | 920 |  |  | 1,101 |  |
| Acquisition-related costs |  | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 13 |  |
| Research and development on non-GAAP basis |  | $ | 919 |  |  | $ | 930 |  |  | $ | 890 |  |  | $ | 2,731 |  |  | $ | 2,672 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 346 |  |  | $ | 325 |  |  | $ | 428 |  |  | $ | 1,010 |  |  | $ | 1,530 |  |
| Stock-based compensation expense |  | 100 |  |  | 80 |  |  | 91 |  |  | 264 |  |  | 305 |  |
| Acquisition-related costs |  | 22 |  |  | 25 |  |  | 66 |  |  | 88 |  |  | 336 |  |
| Litigation settlements |  | 1 |  |  | — |  |  | 21 |  |  | 1 |  |  | 63 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 223 |  |  | $ | 220 |  |  | $ | 250 |  |  | $ | 657 |  |  | $ | 826 |  |
| Total operating expenses on GAAP basis |  | $ | 2,071 |  |  | $ | 2,082 |  |  | $ | 2,308 |  |  | $ | 6,268 |  |  | $ | 7,281 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 600 |  |  | 1,482 |  |  | 1,802 |  |
| Stock-based compensation expense |  | 385 |  |  | 387 |  |  | 428 |  |  | 1,184 |  |  | 1,406 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 25 |  |  | 52 |  |  | 122 |  |  | 163 |  |
| Litigation settlements |  | 1 |  |  | — |  |  | 21 |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 23 |  |  | 26 |  |  | 67 |  |  | 91 |  |  | 349 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,142 |  |  | $ | 1,150 |  |  | $ | 1,140 |  |  | $ | 3,388 |  |  | $ | 3,498 |  |
| Operating income on GAAP basis |  | $ | 2,126 |  |  | $ | 1,975 |  |  | $ | 1,008 |  |  | $ | 5,938 |  |  | $ | 2,488 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,345 |  |  | 1,347 |  |  | 1,553 |  |  | 4,060 |  |  | 4,659 |  |
| Stock-based compensation expense |  | 421 |  |  | 425 |  |  | 465 |  |  | 1,290 |  |  | 1,527 |  |
| Restructuring, impairment and disposal charges |  | 27 |  |  | 26 |  |  | 67 |  |  | 139 |  |  | 193 |  |
| Litigation settlements |  | 1 |  |  | — |  |  | 21 |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 26 |  |  | 29 |  |  | 67 |  |  | 100 |  |  | 355 |  |
| Operating income on non-GAAP basis |  | $ | 3,946 |  |  | $ | 3,802 |  |  | $ | 3,181 |  |  | $ | 11,528 |  |  | $ | 9,296 |  |
| Interest expense on GAAP basis |  | $ | (415) |  |  | $ | (466) |  |  | $ | (464) |  |  | $ | (1,451) |  |  | $ | (1,357) |  |
| Loss on debt extinguishment |  | — |  |  | 50 |  |  | 55 |  |  | 222 |  |  | 153 |  |
| Interest expense on non-GAAP basis |  | $ | (415) |  |  | $ | (416) |  |  | $ | (409) |  |  | $ | (1,229) |  |  | $ | (1,204) |  |
| Other income (expense), net on GAAP basis |  | $ | 15 |  |  | $ | (23) |  |  | $ | 49 |  |  | $ | 109 |  |  | $ | 175 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | 4 |  |  | 25 |  |  | (31) |  |  | (90) |  |  | (21) |  |
| Gain from sale of business |  | — |  |  | — |  |  | (23) |  |  | — |  |  | (23) |  |
| Acquisition-related gain |  | — |  |  | (1) |  |  | — |  |  | (3) |  |  | (7) |  |
| Other income (expense), net on non-GAAP basis |  | $ | 19 |  |  | $ | 1 |  |  | $ | (5) |  |  | $ | 16 |  |  | $ | 8 |  |

[0001730168-21-000121:8k_2_02:62]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | May 2,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
| Benefit from income taxes on GAAP basis |  | $ | (150) |  |  | $ | (7) |  |  | $ | (96) |  |  | $ | (151) |  |  | $ | (331) |  |
| Non-GAAP tax reconciling adjustments |  | 576 |  |  | 414 |  |  | 428 |  |  | 1,389 |  |  | 1,303 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 426 |  |  | $ | 407 |  |  | $ | 332 |  |  | $ | 1,238 |  |  | $ | 972 |  |
| Net income on GAAP basis |  | $ | 1,876 |  |  | $ | 1,493 |  |  | $ | 688 |  |  | $ | 4,747 |  |  | $ | 1,636 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,345 |  |  | 1,347 |  |  | 1,553 |  |  | 4,060 |  |  | 4,659 |  |
| Stock-based compensation expense |  | 421 |  |  | 425 |  |  | 465 |  |  | 1,290 |  |  | 1,527 |  |
| Restructuring, impairment and disposal charges |  | 27 |  |  | 26 |  |  | 67 |  |  | 139 |  |  | 193 |  |
| Litigation settlements |  | 1 |  |  | — |  |  | 21 |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 26 |  |  | 28 |  |  | 67 |  |  | 97 |  |  | 348 |  |
| Loss on debt extinguishment |  | — |  |  | 50 |  |  | 55 |  |  | 222 |  |  | 153 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | 4 |  |  | 25 |  |  | (31) |  |  | (90) |  |  | (21) |  |
| Gain from sale of business |  | — |  |  | — |  |  | (23) |  |  | — |  |  | (23) |  |
| Non-GAAP tax reconciling adjustments |  | (576) |  |  | (414) |  |  | (428) |  |  | (1,389) |  |  | (1,303) |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income on non-GAAP basis |  | $ | 3,124 |  |  | $ | 2,980 |  |  | $ | 2,435 |  |  | $ | 9,077 |  |  | $ | 7,128 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 429 |  |  | 429 |  |  | 422 |  |  | 429 |  |  | 420 |  |
| Non-GAAP adjustment (1) |  | 20 |  |  | 21 |  |  | 29 |  |  | 20 |  |  | 32 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 449 |  |  | 450 |  |  | 451 |  |  | 449 |  |  | 452 |  |
| Net income on non-GAAP basis |  | $ | 3,124 |  |  | $ | 2,980 |  |  | $ | 2,435 |  |  | $ | 9,077 |  |  | $ | 7,128 |  |
| Interest expense on non-GAAP basis |  | 415 |  |  | 416 |  |  | 409 |  |  | 1,229 |  |  | 1,204 |  |
| Provision for income taxes on non-GAAP basis |  | 426 |  |  | 407 |  |  | 332 |  |  | 1,238 |  |  | 972 |  |
| Depreciation |  | 134 |  |  | 133 |  |  | 138 |  |  | 405 |  |  | 431 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 24 |  |  | 28 |  |  | 75 |  |  | 81 |  |
| Adjusted EBITDA |  | $ | 4,123 |  |  | $ | 3,960 |  |  | $ | 3,342 |  |  | $ | 12,024 |  |  | $ | 9,816 |  |
| Net cash provided by operating activities |  | $ | 3,541 |  |  | $ | 3,569 |  |  | $ | 3,178 |  |  | $ | 10,223 |  |  | $ | 8,713 |  |
| Purchases of property, plant and equipment |  | (115) |  |  | (126) |  |  | (105) |  |  | (355) |  |  | (361) |  |
| Free cash flow |  | $ | 3,426 |  |  | $ | 3,443 |  |  | $ | 3,073 |  |  | $ | 9,868 |  |  | $ | 8,352 |  |

[0001730168-21-000121:8k_2_02:63]
|  |  | Fiscal Quarter Ending |
|  |  | October 31, |
| Expected average diluted share count: |  | 2021 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 429 |  |
| Non-GAAP adjustment (1) |  | 19 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 448 |  |

[0001730168-21-000121:8k_2_02:64]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis. For the fiscal quarter ending October 31, 2021, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |

[0001730168-21-000121:8k_2_02:65]
BROADCOM INC.

[0001730168-21-000121:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-21-000121:8k_2_02:67]
(IN MILLIONS)

[0001730168-21-000121:8k_2_02:68]
|  |  | August 1,2021 |  | November 1,2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,105 |  |  | $ | 7,618 |  |
| Trade accounts receivable, net |  | 2,234 |  |  | 2,297 |  |
| Inventory |  | 1,160 |  |  | 1,003 |  |
| Other current assets |  | 1,137 |  |  | 977 |  |
| Total current assets |  | 15,636 |  |  | 11,895 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,370 |  |  | 2,509 |  |
| Goodwill |  | 43,457 |  |  | 43,447 |  |
| Intangible assets, net |  | 12,719 |  |  | 16,782 |  |
| Other long-term assets |  | 1,698 |  |  | 1,300 |  |
| Total assets |  | $ | 75,880 |  |  | $ | 75,933 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 968 |  |  | $ | 836 |  |
| Employee compensation and benefits |  | 893 |  |  | 877 |  |
| Current portion of long-term debt |  | 279 |  |  | 827 |  |
| Other current liabilities |  | 4,361 |  |  | 3,831 |  |
| Total current liabilities |  | 6,501 |  |  | 6,371 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 40,178 |  |  | 40,235 |  |
| Other long-term liabilities |  | 4,834 |  |  | 5,426 |  |
| Total liabilities |  | 51,513 |  |  | 52,032 |  |
| Preferred stock dividend obligation |  | 27 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 24,126 |  |  | 23,982 |  |
| Retained earnings |  | 320 |  |  | — |  |
| Accumulated other comprehensive loss |  | (106) |  |  | (108) |  |
| Total stockholders' equity |  | 24,340 |  |  | 23,874 |  |
| Total liabilities and equity |  | $ | 75,880 |  |  | $ | 75,933 |  |

[0001730168-21-000121:8k_2_02:69]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | May 2,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,876 |  |  | $ | 1,493 |  |  | $ | 688 |  |  | $ | 4,747 |  |  | $ | 1,636 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,369 |  |  | 1,371 |  |  | 1,581 |  |  | 4,135 |  |  | 4,746 |  |
| Depreciation |  | 134 |  |  | 133 |  |  | 138 |  |  | 405 |  |  | 431 |  |
| Stock-based compensation |  | 421 |  |  | 425 |  |  | 465 |  |  | 1,290 |  |  | 1,527 |  |
| Deferred taxes and other non-cash taxes |  | (436) |  |  | (177) |  |  | (436) |  |  | (762) |  |  | (683) |  |
| Loss on debt extinguishment |  | — |  |  | 26 |  |  | 55 |  |  | 198 |  |  | 153 |  |
| (Gains) losses on investments |  | 4 |  |  | 25 |  |  | — |  |  | (90) |  |  | — |  |
| Non-cash restructuring, impairment and disposal charges |  | 8 |  |  | 12 |  |  | 15 |  |  | 35 |  |  | 32 |  |
| Non-cash interest expense |  | 24 |  |  | 21 |  |  | 22 |  |  | 67 |  |  | 83 |  |
| Other |  | — |  |  | (3) |  |  | (54) |  |  | (8) |  |  | (43) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 191 |  |  | 106 |  |  | 542 |  |  | 50 |  |  | 590 |  |
| Inventory |  | (156) |  |  | (52) |  |  | (128) |  |  | (157) |  |  | (98) |  |
| Accounts payable |  | 156 |  |  | (58) |  |  | (123) |  |  | 142 |  |  | 227 |  |
| Employee compensation and benefits |  | 254 |  |  | 135 |  |  | 231 |  |  | 14 |  |  | 75 |  |
| Other current assets and current liabilities |  | (227) |  |  | 182 |  |  | (2) |  |  | 363 |  |  | 462 |  |
| Other long-term assets and long-term liabilities |  | (77) |  |  | (70) |  |  | 184 |  |  | (206) |  |  | (425) |  |
| Net cash provided by operating activities |  | 3,541 |  |  | 3,569 |  |  | 3,178 |  |  | 10,223 |  |  | 8,713 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | (2) |  |  | (8) |  |  | (10,872) |  |
| Proceeds from sales of businesses |  | — |  |  | — |  |  | 50 |  |  | — |  |  | 218 |  |
| Purchases of property, plant and equipment |  | (115) |  |  | (126) |  |  | (105) |  |  | (355) |  |  | (361) |  |
| Proceeds from disposals of property, plant and equipment |  | 1 |  |  | 3 |  |  | 10 |  |  | 4 |  |  | 10 |  |
| Proceeds from sale of investment |  | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |
| Other |  | — |  |  | (3) |  |  | 1 |  |  | (3) |  |  | (4) |  |
| Net cash used in investing activities |  | (47) |  |  | (126) |  |  | (46) |  |  | (295) |  |  | (11,009) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | 7,953 |  |  | 9,904 |  |  | 27,802 |  |
| Payments on debt obligations |  | — |  |  | (1,533) |  |  | (6,825) |  |  | (10,733) |  |  | (15,814) |  |
| Other borrowings, net |  | — |  |  | — |  |  | (3,028) |  |  | — |  |  | (1,285) |  |
| Payments of dividends |  | (1,556) |  |  | (1,552) |  |  | (1,386) |  |  | (4,651) |  |  | (4,139) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (347) |  |  | (461) |  |  | (192) |  |  | (1,033) |  |  | (580) |  |
| Issuance of common stock |  | 7 |  |  | 71 |  |  | 46 |  |  | 113 |  |  | 174 |  |
| Other |  | (11) |  |  | (2) |  |  | (50) |  |  | (41) |  |  | (60) |  |
| Net cash provided by (used in) financing activities |  | (1,907) |  |  | (3,477) |  |  | (3,482) |  |  | (6,441) |  |  | 6,098 |  |
| Net change in cash and cash equivalents |  | 1,587 |  |  | (34) |  |  | (350) |  |  | 3,487 |  |  | 3,802 |  |
| Cash and cash equivalents at beginning of period |  | 9,518 |  |  | 9,552 |  |  | 9,207 |  |  | 7,618 |  |  | 5,055 |  |
| Cash and cash equivalents at end of period |  | $ | 11,105 |  |  | $ | 9,518 |  |  | $ | 8,857 |  |  | $ | 11,105 |  |  | $ | 8,857 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 253 |  |  | $ | 369 |  |  | $ | 269 |  |  | $ | 994 |  |  | $ | 1,025 |  |
| Cash paid for income taxes |  | $ | 167 |  |  | $ | 293 |  |  | $ | 44 |  |  | $ | 607 |  |  | $ | 299 |  |
