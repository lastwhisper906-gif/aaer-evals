# AVGO notes — 0001730168-21-000123


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-21-000123:notes:1]
[same as prior period, unchanged from 0001730168-21-000116:notes:1]

[0001730168-21-000123:notes:2]
[same as prior period, unchanged from 0001730168-21-000116:notes:2]

[0001730168-21-000123:notes:3]
[same as prior period, unchanged from 0001730168-21-000116:notes:3]

[0001730168-21-000123:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ended on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

[0001730168-21-000123:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 1, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.

[0001730168-21-000123:notes:6]
[same as prior period, unchanged from 0001730168-21-000116:notes:6]

[0001730168-21-000123:notes:7]
[same as prior period, unchanged from 0001730168-21-000116:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-21-000123:notes:8]
[same as prior period, unchanged from 0001730168-21-000116:notes:8]

[0001730168-21-000123:notes:9]
[same as prior period, unchanged from 0001730168-21-000116:notes:9]

[0001730168-21-000123:notes:10]
[same as prior period, unchanged from 0001730168-21-000116:notes:10]

[0001730168-21-000123:notes:11]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |

[0001730168-21-000123:notes:12]
|  |  | Fiscal Quarter Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |

[0001730168-21-000123:notes:13]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |

[0001730168-21-000123:notes:14]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |

[0001730168-21-000123:notes:15]
[same as prior period, unchanged from 0001730168-21-000116:notes:15]

[0001730168-21-000123:notes:16]
(a) Subscriptions and services predominantly include software licenses with termination for convenience clauses.

[0001730168-21-000123:notes:17]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.

[0001730168-21-000123:notes:18]
[same as prior period, unchanged from 0001730168-21-000116:notes:18]

[0001730168-21-000123:notes:19]
[same as prior period, unchanged from 0001730168-21-000116:notes:19]

[0001730168-21-000123:notes:20]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of August 1, 2021 |  | $ | 142 |  |  | $ | 3,628 |  |

[0001730168-21-000123:notes:21]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 1, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,330 million. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million.

[0001730168-21-000123:notes:22]
[same as prior period, unchanged from 0001730168-21-000116:notes:22]

[0001730168-21-000123:notes:23]
[same as prior period, unchanged from 0001730168-21-000116:notes:23]

[0001730168-21-000123:notes:24]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of August 1, 2021 were approximately $12.1 billion. We expect approximately 31% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001730168-21-000123:notes:25]
[same as prior period, unchanged from 0001730168-21-000116:notes:25]

[0001730168-21-000123:notes:26]
[same as prior period, unchanged from 0001730168-21-000116:notes:26]

[0001730168-21-000123:notes:27]
[same as prior period, unchanged from 0001730168-21-000116:notes:27]

[0001730168-21-000123:notes:28]
[same as prior period, unchanged from 0001730168-21-000116:notes:28]

[0001730168-21-000123:notes:29]
|  |  |  |  | Fiscal Quarter Ended |  |  |  | Three Fiscal Quarters Ended |
|  |  |  |  | August 2,2020 |  |  |  | August 2,2020 |
|  |  |  |  | (In millions) |
| Pro forma net revenue |  |  |  | $ | 5,687 |  |  |  |  | $ | 16,894 |  |
| Pro forma net income attributable to common stock |  |  |  | $ | 549 |  |  |  |  | $ | 1,181 |  |

[0001730168-21-000123:notes:30]
Other Acquisitions 
During the fiscal quarter ended February 2, 2020, we also completed three other acquisitions qualifying as business combinations for total consideration of $201 million, of which $109 million was allocated to goodwill and $46 million was allocated to intangible assets. These acquisitions are not material, individually or in the aggregate, to our condensed consolidated statements of operations.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-21-000123:notes:31]
[same as prior period, unchanged from 0001730168-21-000116:notes:31]

[0001730168-21-000123:notes:32]
Cash equivalents included $3,880 million and $2,471 million of time deposits and $1,555 million and $790 million of money-market funds as of August 1, 2021 and November 1, 2020, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-21-000123:notes:33]
[same as prior period, unchanged from 0001730168-21-000116:notes:33]

[0001730168-21-000123:notes:34]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,000 million and $2,827 million during the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and $927 million and $2,754 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. Factoring fees for the sales of receivables were recorded in other income, net and were not material for any of the periods presented.

[0001730168-21-000123:notes:35]
[same as prior period, unchanged from 0001730168-21-000116:notes:35]

[0001730168-21-000123:notes:36]
|  |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Finished goods |  | $ | 329 |  |  | $ | 323 |  |
| Work-in-process |  | 673 |  |  | 558 |  |
| Raw materials |  | 158 |  |  | 122 |  |
| Total inventory |  | $ | 1,160 |  |  | $ | 1,003 |  |

[0001730168-21-000123:notes:37]
[same as prior period, unchanged from 0001730168-21-000116:notes:37]

[0001730168-21-000123:notes:38]
|  |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Prepaid expenses |  | $ | 509 |  |  | $ | 387 |  |
| Other (miscellaneous) |  | 628 |  |  | 590 |  |
| Total other current assets |  | $ | 1,137 |  |  | $ | 977 |  |

[0001730168-21-000123:notes:39]
[same as prior period, unchanged from 0001730168-21-000116:notes:39]

[0001730168-21-000123:notes:40]
|  |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,008 |  |  | $ | 2,620 |  |
| Tax liabilities |  | 492 |  |  | 440 |  |
| Interest payable |  | 471 |  |  | 304 |  |
| Other (miscellaneous) |  | 390 |  |  | 467 |  |
| Total other current liabilities |  | $ | 4,361 |  |  | $ | 3,831 |  |

[0001730168-21-000123:notes:41]
[same as prior period, unchanged from 0001730168-21-000116:notes:41]

[0001730168-21-000123:notes:42]
|  |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions) |
| Unrecognized tax benefits |  | $ | 3,282 |  |  | $ | 3,185 |  |
| Contract liabilities |  | 620 |  |  | 823 |  |
| Other (miscellaneous) |  | 932 |  |  | 1,418 |  |
| Total other long-term liabilities |  | $ | 4,834 |  |  | $ | 5,426 |  |

[0001730168-21-000123:notes:43]
[same as prior period, unchanged from 0001730168-21-000116:notes:43]

[0001730168-21-000123:notes:44]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 253 |  |  | $ | 269 |  |  | $ | 994 |  |  | $ | 1,025 |  |
| Cash paid for income taxes |  | $ | 167 |  |  | $ | 44 |  |  | $ | 607 |  |  | $ | 299 |  |

[0001730168-21-000123:notes:45]
As of August 1, 2021 and August 2, 2020, $20 million and $37 million, respectively, of unpaid purchases of property, plant and equipment were included in accounts payable. Amounts reported as unpaid purchases are presented as cash outflows from investing activities for purchases of property, plant and equipment in the condensed consolidated statements of cash flows in the period in which they are paid.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001730168-21-000123:notes:46]
[same as prior period, unchanged from 0001730168-21-000116:notes:46]

[0001730168-21-000123:notes:47]
|  |  | Semiconductor Solutions |  | Infrastructure Software |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 25,959 |  |  | $ | 17,488 |  |  | $ | 43,447 |  |
| Acquisition |  | — |  |  | 10 |  |  | 10 |  |
| Balance as of August 1, 2021 |  | $ | 25,959 |  |  | $ | 17,498 |  |  | $ | 43,457 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-21-000123:notes:48]
[same as prior period, unchanged from 0001730168-21-000116:notes:48]

[0001730168-21-000123:notes:49]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of August 1, 2021: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,132 |  |  | $ | (16,498) |  |  | $ | 7,634 |  |
| Customer contracts and related relationships |  | 8,392 |  |  | (4,218) |  |  | 4,174 |  |
| Order backlog |  | 2,579 |  |  | (2,223) |  |  | 356 |  |
| Trade names |  | 797 |  |  | (378) |  |  | 419 |  |
| Other |  | 248 |  |  | (131) |  |  | 117 |  |
| Intangible assets subject to amortization |  | 36,148 |  |  | (23,448) |  |  | 12,700 |  |
| In-process research and development |  | 19 |  |  | — |  |  | 19 |  |
| Total |  | $ | 36,167 |  |  | $ | (23,448) |  |  | $ | 12,719 |  |
| As of November 1, 2020: |  |  |  |  |  |  |
| Purchased technology |  | $ | 24,119 |  |  | $ | (13,925) |  |  | $ | 10,194 |  |
| Customer contracts and related relationships |  | 8,389 |  |  | (3,179) |  |  | 5,210 |  |
| Order backlog |  | 2,579 |  |  | (1,836) |  |  | 743 |  |
| Trade names |  | 797 |  |  | (322) |  |  | 475 |  |
| Other |  | 252 |  |  | (117) |  |  | 135 |  |
| Intangible assets subject to amortization |  | 36,136 |  |  | (19,379) |  |  | 16,757 |  |
| In-process research and development |  | 25 |  |  | — |  |  | 25 |  |
| Total |  | $ | 36,161 |  |  | $ | (19,379) |  |  | $ | 16,782 |  |

[0001730168-21-000123:notes:50]
Based on the amount of intangible assets subject to amortization at August 1, 2021, the expected amortization expense for each of the next five years and thereafter was as follows:

[0001730168-21-000123:notes:51]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 1,347 |  |
| 2022 |  | 4,367 |  |
| 2023 |  | 3,239 |  |
| 2024 |  | 2,369 |  |
| 2025 |  | 659 |  |
| Thereafter |  | 719 |  |
| Total |  | $ | 12,700 |  |

[0001730168-21-000123:notes:52]
[same as prior period, unchanged from 0001730168-21-000116:notes:52]

[0001730168-21-000123:notes:53]
| Amortizable intangible assets: |  | August 1,2021 |
|  |  | (In years) |
| Purchased technology |  | 4 |
| Customer contracts and related relationships |  | 3 |
| Order backlog |  | 2 |
| Trade names |  | 9 |
| Other |  | 9 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-21-000123:notes:54]
[same as prior period, unchanged from 0001730168-21-000116:notes:54]

[0001730168-21-000123:notes:55]
[same as prior period, unchanged from 0001730168-21-000116:notes:55]

[0001730168-21-000123:notes:56]
[same as prior period, unchanged from 0001730168-21-000116:notes:56]

[0001730168-21-000123:notes:57]
For each of the fiscal quarter and three fiscal quarters ended August 1, 2021 and August 2, 2020, diluted net income per share excluded the potentially dilutive effect of 12 million shares of common stock issuable upon the conversion of Mandatory Convertible Preferred Stock as their effect was antidilutive.

[0001730168-21-000123:notes:58]
[same as prior period, unchanged from 0001730168-21-000116:notes:58]

[0001730168-21-000123:notes:59]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 1,876 |  |  | $ | 689 |  |  | $ | 4,747 |  |  | $ | 1,637 |  |
| Dividends on preferred stock |  | (74) |  |  | (74) |  |  | (224) |  |  | (223) |  |
| Income from continuing operations attributable to common stock |  | 1,802 |  |  | 615 |  |  | 4,523 |  |  | 1,414 |  |
| Loss from discontinued operations, net of income taxes, attributable to common stock |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Net income attributable to common stock |  | $ | 1,802 |  |  | $ | 614 |  |  | $ | 4,523 |  |  | $ | 1,413 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 411 |  |  | 403 |  |  | 409 |  |  | 401 |  |
| Dilutive effect of equity awards |  | 18 |  |  | 19 |  |  | 20 |  |  | 19 |  |
| Weighted-average shares outstanding - diluted |  | 429 |  |  | 422 |  |  | 429 |  |  | 420 |  |

[0001730168-21-000123:notes:60]
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.38 |  |  | $ | 1.53 |  |  | $ | 11.06 |  |  | $ | 3.53 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income per share |  | $ | 4.38 |  |  | $ | 1.52 |  |  | $ | 11.06 |  |  | $ | 3.52 |  |
| Diluted income per share attributable to common stock: |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.20 |  |  | $ | 1.46 |  |  | $ | 10.54 |  |  | $ | 3.37 |  |
| Loss per share from discontinued operations |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net income per share |  | $ | 4.20 |  |  | $ | 1.45 |  |  | $ | 10.54 |  |  | $ | 3.36 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-21-000123:notes:61]
Borrowings

[0001730168-21-000123:notes:62]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
|  |  |  |  | 5,500 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 10,000 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
|  |  |  |  | 3,917 |  |  | 3,917 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 6,273 |  |  | 8,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
|  |  |  |  | 3,497 |  |  | 4,500 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
|  |  |  |  | — |  |  | 5,888 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
|  |  |  |  | 4,805 |  |  | 7,762 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |

[0001730168-21-000123:notes:63]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 6,992 |  |  | 10,526 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
|  |  |  |  | 493 |  |  | 883 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,100) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,399 |  |  | $ | 40,994 |  |

[0001730168-21-000123:notes:64]
As of August 1, 2021 and November 1, 2020, short-term finance lease liabilities of $24 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $34 million and $48 million, respectively, were included in long-term debt.

[0001730168-21-000123:notes:65]
March 2021 Senior Notes

[0001730168-21-000123:notes:66]
In March 2021, we completed our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-21-000123:notes:67]
In connection with the Exchange Offer, Broadcom Corporation and Broadcom Technologies Inc. were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, June 2020 Senior Notes, May 2020 Senior Notes, April 2020 Senior Notes, and April 2019 Senior Notes.

[0001730168-21-000123:notes:68]
January 2021 Senior Notes

[0001730168-21-000123:notes:69]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

[0001730168-21-000123:notes:70]
During the fiscal quarter ended January 31, 2021, we used the net proceeds from the January 2021 Senior Notes to repay an aggregate of $5,888 million, or the outstanding balance, of our unsecured term A-3 facility and unsecured term A-5 facility under the credit agreement entered into on November 4, 2019 (the “November 2019 Credit Agreement”). Additionally, pursuant to a cash tender offer that we announced on January 4, 2021 (the “Tender Offer”), we early settled and repurchased $2,902 million of certain of our outstanding notes maturing between 2021 and 2023. As a result of these transactions, we incurred premiums of $128 million and wrote off $44 million of unamortized discount and issuance costs, both of which were included in interest expense. We also repaid $282 million of our 2.200% notes upon maturity in January 2021.

[0001730168-21-000123:notes:71]
During the fiscal quarter ended May 2, 2021, we completed the Tender Offer and repurchased an additional $9 million of certain outstanding notes maturing between 2021 and 2023. Using the remaining proceeds from the January 2021 Senior Notes, we repurchased $606 million, or the outstanding balances, of our 3.125% notes due April 2021, 3.125% notes due October 2022, and 3.600% notes due August 2022 and repurchased $314 million of our 3.000% notes due January 2022. As a result of these repurchases, we incurred premiums of $23 million.

[0001730168-21-000123:notes:72]
January 2021 Credit Agreement

[0001730168-21-000123:notes:73]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of August 1, 2021, we had no borrowings outstanding under the Revolving Facility.

[0001730168-21-000123:notes:74]
Commercial Paper

[0001730168-21-000123:notes:75]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of August 1, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

[0001730168-21-000123:notes:76]
Fair Value of Debt

[0001730168-21-000123:notes:77]
As of August 1, 2021, the estimated aggregate fair value of debt was $45,379 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-21-000123:notes:78]
Future Principal Payments of Debt

[0001730168-21-000123:notes:79]
The future scheduled principal payments of debt as of August 1, 2021 were as follows:

[0001730168-21-000123:notes:80]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | — |  |
| 2022 |  | 264 |  |
| 2023 |  | 403 |  |
| 2024 |  | 1,563 |  |
| 2025 |  | 1,832 |  |
| Thereafter |  | 37,437 |  |
| Total |  | $ | 41,499 |  |

[0001730168-21-000123:notes:81]
As of August 1, 2021 and November 1, 2020, we accrued interest payable of $471 million and $304 million, respectively, and were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-21-000123:notes:82]
[same as prior period, unchanged from 0001730168-21-000116:notes:82]

[0001730168-21-000123:notes:83]
[same as prior period, unchanged from 0001730168-21-000116:notes:83]

[0001730168-21-000123:notes:84]
On September 30, 2022, unless earlier converted, each outstanding share of Mandatory Convertible Preferred Stock will automatically convert into shares of our common stock at a rate between the then minimum and maximum conversion rates. At any time prior to September 30, 2022, holders may elect to convert each share of Mandatory Convertible Preferred Stock

[0001730168-21-000123:notes:85]
into shares of our common stock at the then minimum conversion rate. The conversion rates are subject to anti-dilution adjustments. As of August 1, 2021, the minimum conversion rate was 3.0763 and the maximum conversion rate was 3.5957.

[0001730168-21-000123:notes:86]
As of each August 1, 2021 and November 1, 2020, we recognized $27 million of accrued preferred stock dividends, which were presented as temporary equity on our condensed consolidated balance sheets.

[0001730168-21-000123:notes:87]
[same as prior period, unchanged from 0001730168-21-000116:notes:86]

[0001730168-21-000123:notes:88]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 3.60 |  |  | $ | 3.25 |  |  | $ | 10.80 |  |  | $ | 9.75 |  |
| Dividends to common stockholders |  | $ | 1,482 |  |  | $ | 1,312 |  |  | $ | 4,427 |  |  | $ | 3,915 |  |
| Dividends per share to preferred stockholders |  | $ | 20.00 |  |  | $ | 20.00 |  |  | $ | 60.00 |  |  | $ | 60.00 |  |
| Dividends to preferred stockholders |  | $ | 74 |  |  | $ | 74 |  |  | $ | 224 |  |  | $ | 224 |  |

[0001730168-21-000123:notes:89]
[same as prior period, unchanged from 0001730168-21-000116:notes:88]

[0001730168-21-000123:notes:90]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 18 |  |  | $ | 26 |  |  | $ | 59 |  |  | $ | 84 |  |
| Cost of subscriptions and services |  | 18 |  |  | 11 |  |  | 47 |  |  | 37 |  |
| Research and development |  | 285 |  |  | 337 |  |  | 920 |  |  | 1,101 |  |
| Selling, general and administrative |  | 100 |  |  | 91 |  |  | 264 |  |  | 305 |  |
| Total stock-based compensation expense |  | $ | 421 |  |  | $ | 465 |  |  | $ | 1,290 |  |  | $ | 1,527 |  |

[0001730168-21-000123:notes:91]
As of August 1, 2021, the total unrecognized compensation cost related to unvested stock-based awards was $3,334 million, which is expected to be recognized over the remaining weighted-average service period of 3.1 years.

[0001730168-21-000123:notes:92]
[same as prior period, unchanged from 0001730168-21-000116:notes:91]

[0001730168-21-000123:notes:93]
During the fiscal quarter ended May 2, 2021, our stockholders approved the amendment and restatement of our 2012 stock incentive plan, now called Broadcom Inc. 2012 Stock Incentive Plan (the “Amended 2012 Plan”). Under the Amended 2012 Plan, we may grant to all employees stock options and stock appreciation rights with an exercise price that is no less than the fair market value on the date of grant, and time- and market-based RSUs. The Amended 2012 Plan reduced the number of shares available for new equity award grants to 20 million shares and removed the annual share replenishment provision. We will make no further equity award grants under our LSI Corporation 2003 Equity Incentive Plan.

[0001730168-21-000123:notes:94]
[same as prior period, unchanged from 0001730168-21-000116:notes:93]

[0001730168-21-000123:notes:95]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant DateFair ValuePer Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 1, 2020 |  | 32 |  |  | $ | 188.35 |  |  |  |  |  |
| Granted |  | 1 |  |  | $ | 404.43 |  |  |  |  |  |
| Vested |  | (6) |  |  | $ | 211.74 |  |  |  |  |  |
| Forfeited |  | (2) |  |  | $ | 187.68 |  |  |  |  |  |
| Balance as of August 1, 2021 |  | 25 |  |  | $ | 200.55 |  |  |  |  |  |

[0001730168-21-000123:notes:96]
The aggregate fair value of time- and market-based RSUs that vested during the three fiscal quarters ended August 1, 2021 was $2,888 million, which represented the market value of our common stock on the date that the RSUs vested. The number of RSUs vested included shares of common stock that we withheld for settlement of employees’ tax obligations due upon the vesting of RSUs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-21-000123:notes:97]
[same as prior period, unchanged from 0001730168-21-000116:notes:96]

[0001730168-21-000123:notes:98]
The benefit from income taxes was $150 million and $151 million for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, compared to $96 million and $331 million for the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively.

[0001730168-21-000123:notes:99]
The benefit from income taxes for the fiscal quarter ended August 1, 2021 was primarily due to excess tax benefits from stock-based awards, the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, and the jurisdictional mix of income and expense.

[0001730168-21-000123:notes:100]
The benefit from income taxes for three fiscal quarters ended August 1, 2021 reflected excess tax benefits from stock-based awards and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements, offset in part by higher taxes on income from continuing operations.

[0001730168-21-000123:notes:101]
The benefit from income taxes for the fiscal quarter and three fiscal quarters ended August 2, 2020 was primarily due to the jurisdictional mix of income and expense, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefits from stock-based awards.

[0001730168-21-000123:notes:102]
[same as prior period, unchanged from 0001730168-21-000116:notes:100]

[0001730168-21-000123:notes:103]
The balance of gross unrecognized tax benefits was $4,893 million and $4,748 million as of August 1, 2021 and November 1, 2020, respectively.

[0001730168-21-000123:notes:104]
Accrued interest and penalties are included in other long-term liabilities on the condensed consolidated balance sheets. As of August 1, 2021 and November 1, 2020, the combined amount of cumulative accrued interest and penalties was approximately $354 million and $340 million, respectively.

[0001730168-21-000123:notes:105]
As of August 1, 2021 and November 1, 2020, approximately $5,247 million and $5,088 million, respectively, of the unrecognized tax benefits, including accrued interest and penalties, would affect our effective tax rate if favorably resolved.

[0001730168-21-000123:notes:106]
We are subject to U.S. income tax examination for fiscal years 2016 and later. Certain of our acquired companies are subject to tax examinations in major jurisdictions outside of the U.S. for fiscal years 2008 and later. It is possible that our existing unrecognized tax benefits may change up to $277 million as a result of lapses of the statute of limitations for certain audit periods and/or audit examinations expected to be completed within the next 12 months.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-21-000123:notes:107]
[same as prior period, unchanged from 0001730168-21-000116:notes:105]

[0001730168-21-000123:notes:108]
[same as prior period, unchanged from 0001730168-21-000116:notes:106]

[0001730168-21-000123:notes:109]
[same as prior period, unchanged from 0001730168-21-000116:notes:107]

[0001730168-21-000123:notes:110]
[same as prior period, unchanged from 0001730168-21-000116:notes:108]

[0001730168-21-000123:notes:111]
[same as prior period, unchanged from 0001730168-21-000116:notes:109]

[0001730168-21-000123:notes:112]
[same as prior period, unchanged from 0001730168-21-000116:notes:110]

[0001730168-21-000123:notes:113]
[same as prior period, unchanged from 0001730168-21-000116:notes:111]

[0001730168-21-000123:notes:114]
[same as prior period, unchanged from 0001730168-21-000116:notes:112]

[0001730168-21-000123:notes:115]
[same as prior period, unchanged from 0001730168-21-000116:notes:113]

[0001730168-21-000123:notes:116]
|  |  | Fiscal Quarter Ended |  | Three Fiscal Quarters Ended |
|  |  | August 1,2021 |  | August 2,2020 |  | August 1,2021 |  | August 2,2020 |
|  |  | (In millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 5,021 |  |  | $ | 4,219 |  |  | $ | 14,749 |  |  | $ | 12,437 |  |
| Infrastructure software |  | 1,757 |  |  | 1,602 |  |  | 5,294 |  |  | 4,984 |  |
| Total net revenue |  | $ | 6,778 |  |  | $ | 5,821 |  |  | $ | 20,043 |  |  | $ | 17,421 |  |
| Operating income: |  |  |  |  |  |  |  |  |
| Semiconductor solutions |  | $ | 2,720 |  |  | $ | 2,112 |  |  | $ | 7,828 |  |  | $ | 6,046 |  |
| Infrastructure software |  | 1,226 |  |  | 1,069 |  |  | 3,700 |  |  | 3,250 |  |
| Unallocated expenses |  | (1,820) |  |  | (2,173) |  |  | (5,590) |  |  | (6,808) |  |
| Total operating income |  | $ | 2,126 |  |  | $ | 1,008 |  |  | $ | 5,938 |  |  | $ | 2,488 |  |

[0001730168-21-000123:notes:117]
[same as prior period, unchanged from 0001730168-21-000116:notes:115]

[0001730168-21-000123:notes:118]
We sell our products through our direct sales force and a select network of distributors and channel partners globally. One customer accounted for 12% of our net accounts receivable balance as of August 1, 2021, while no customer accounted for more than 10% of our net accounts receivable balance as of November 1, 2020.

[0001730168-21-000123:notes:119]
One customer accounted for 16% and 17% of our net revenue for the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively, and 12% of our net revenue for the three fiscal quarters ended August 2, 2020, while no customer accounted for more than 10% of our net revenue for the fiscal quarter ended August 2, 2020. Net revenue from this customer was included in our semiconductor solutions segment.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-21-000123:notes:120]
Commitments and Contingencies
Commitments

[0001730168-21-000123:notes:121]
The following table summarizes contractual obligations and commitments as of August 1, 2021 that materially changed from the end of fiscal year 2020:

[0001730168-21-000123:notes:122]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 558 |  |  | $ | 1,305 |  |  | $ | 54 |  |
| 2022 |  | 1,819 |  |  | 78 |  |  | 239 |  |
| 2023 |  | 1,950 |  |  | 58 |  |  | 226 |  |
| 2024 |  | 3,084 |  |  | — |  |  | 162 |  |
| 2025 |  | 3,276 |  |  | — |  |  | 74 |  |
| Thereafter |  | 46,048 |  |  | — |  |  | 248 |  |
| Total |  | $ | 56,735 |  |  | $ | 1,441 |  |  | $ | 1,003 |  |

[0001730168-21-000123:notes:123]
Debt Principal, Interest and Fees. Represents principal, interest and fees on our borrowings.

[0001730168-21-000123:notes:124]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.

[0001730168-21-000123:notes:125]
Other Contractual Commitments. Represents amounts payable pursuant to agreements related to IT, human resources, and other service agreements.

[0001730168-21-000123:notes:126]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 1, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,282 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 1, 2021 have been excluded from the table above.

[0001730168-21-000123:notes:127]
Standby Letters of Credit

[0001730168-21-000123:notes:128]
As of August 1, 2021 and November 1, 2020, we had standby letters of credit of $52 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

[0001730168-21-000123:notes:129]
Contingencies

[0001730168-21-000123:notes:130]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcome of such proceedings is inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-21-000123:notes:131]
Lawsuits Relating to California Institute of Technology

[0001730168-21-000123:notes:132]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint

[0001730168-21-000123:notes:133]
sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. We are unable to predict the date on which the Federal Circuit Court will issue its decision.

[0001730168-21-000123:notes:134]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.

[0001730168-21-000123:notes:135]
Other Matters

[0001730168-21-000123:notes:136]
In addition to the matters discussed above, we are currently engaged in a number of legal actions in the ordinary course of our business.

[0001730168-21-000123:notes:137]
Contingency Assessment

[0001730168-21-000123:notes:138]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings or ongoing regulatory investigations, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation or regulatory investigations are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an intellectual property dispute.

[0001730168-21-000123:notes:139]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings or regulatory investigations, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-21-000123:notes:140]
Other Indemnifications

[0001730168-21-000123:notes:141]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001730168-21-000123:notes:142]
[same as prior period, unchanged from 0001730168-21-000116:notes:139]

[0001730168-21-000123:notes:143]
•During fiscal year 2021, we initiated cost reduction activities associated with plans to align our workforce with strategic business activities and to improve efficiencies in our operations. As a result, we recognized $25 million and $123 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and three fiscal quarters ended August 1, 2021, respectively.

[0001730168-21-000123:notes:144]
•We recognized $64 million and $173 million of restructuring expense primarily related to employee termination costs during the fiscal quarter and three fiscal quarters ended August 2, 2020, respectively. The restructuring expense during the fiscal quarter ended August 2, 2020 was primarily related to cost reduction activities associated with the Symantec Asset Purchase. The restructuring expense during the three fiscal quarters ended August 2, 2020 was related to cost reduction activities related to the Symantec Asset Purchase of $151 million and cost reduction activities related to our acquisition of CA, Inc. of $22 million.

[0001730168-21-000123:notes:145]
The following table summarizes the significant activities within, and components of, the restructuring liabilities during the three fiscal quarters ended August 1, 2021:

[0001730168-21-000123:notes:146]
|  |  | Employee Termination Costs |  | Other Exit Costs |  | Total |
|  |  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |
| Restructuring charges |  | 89 |  |  | 10 |  |  | 99 |  |
| Utilization |  | (117) |  |  | (10) |  |  | (127) |  |
| Balance as of August 1, 2021 (a) |  | $ | 6 |  |  | $ | — |  |  | $ | 6 |  |

[0001730168-21-000123:notes:147]
[same as prior period, unchanged from 0001730168-21-000116:notes:144]

[0001730168-21-000123:notes:148]
(a) We expect the majority of the employee termination costs balance to be paid within the next three months.

[0001730168-21-000123:notes:149]
Restructuring, impairment and disposal charges in our condensed consolidated statement of operations for the three fiscal quarters ended August 1, 2021 included $24 million for the write-down of certain lease-related right-of-use assets and other lease-related charges. As of August 1, 2021, short-term and long-term lease liabilities included $69 million of liabilities related to restructuring activities.


## us-gaap:SubsequentEventsTextBlock

[0001730168-21-000123:notes:150]
Subsequent Events
Preferred Stock Cash Dividends Declared

[0001730168-21-000123:notes:151]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2021 to stockholders of record on September 15, 2021.

[0001730168-21-000123:notes:152]
Common Stock Cash Dividends Declared

[0001730168-21-000123:notes:153]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on September 30, 2021 to stockholders of record on September 22, 2021.
