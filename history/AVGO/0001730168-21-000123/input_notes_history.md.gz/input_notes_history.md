# AVGO note change history — 0001730168-21-000116 → 0001730168-21-000123


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:1]
The following table summarizes contractual obligations and commitments as of August 1, 2021 that materially changed from the end of fiscal year 2020:
  (was, 2021-06-11, similarity 0.9751):
[0001730168-21-000116:note_history:1]
The following table summarizes contractual obligations and commitments as of May 2, 2021 that materially changed from the end of fiscal year 2020:

- changed (2021-09-09):
[0001730168-21-000123:note_history:2]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2021 (remainder) |  | $ | 558 |  |  | $ | 1,305 |  |  | $ | 54 |  |
| 2022 |  | 1,819 |  |  | 78 |  |  | 239 |  |
| 2023 |  | 1,950 |  |  | 58 |  |  | 226 |  |
| 2024 |  | 3,084 |  |  | — |  |  | 162 |  |
| 2025 |  | 3,276 |  |  | — |  |  | 74 |  |
| Thereafter |  | 46,048 |  |  | — |  |  | 248 |  |
| Total |  | $ | 56,735 |  |  | $ | 1,441 |  |  | $ | 1,003 |  |
  (was, 2021-06-11, similarity 0.7233):
[0001730168-21-000116:note_history:2]
| Fiscal Year: |  | Debt Principal, Interest and Fees |  | Purchase Commitments |  | Other Contractual Commitments |  |  |
|  |  | (In millions) |  |  |
| 2021 (remainder) |  | $ | 811 |  |  | $ | 1,106 |  |  | $ | 89 |  |  |  |
| 2022 |  | 1,819 |  |  | 76 |  |  | 231 |  |  |  |
| 2023 |  | 1,950 |  |  | 38 |  |  | 220 |  |  |  |
| 2024 |  | 3,084 |  |  | — |  |  | 166 |  |  |  |
| 2025 |  | 3,276 |  |  | — |  |  | 73 |  |  |  |
| Thereafter |  | 46,048 |  |  | — |  |  | 245 |  |  |  |
| Total |  | $ | 56,988 |  |  | $ | 1,220 |  |  | $ | 1,024 |  |  |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:3]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty.
  (was, 2021-06-11, similarity 0.7358):
[0001730168-21-000116:note_history:3]
Purchase Commitments. Represents unconditional purchase obligations that include agreements to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and that specify all significant terms, including fixed or minimum quantities to be purchased, fixed, minimum or variable price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty. Cancellation for outstanding purchase orders for capital expenditures in connection with construction of our new campuses is generally allowed but requires payment of all costs incurred through the date of cancellation and, therefore, cancelable purchase orders for these capital expenditures are included in the table above.

- changed (2021-09-09):
[0001730168-21-000123:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at August 1, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,282 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of August 1, 2021 have been excluded from the table above.
  (was, 2021-06-11, similarity 0.9806):
[0001730168-21-000116:note_history:4]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits at May 2, 2021, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,188 million of unrecognized tax benefits and accrued interest classified within other long-term liabilities on our condensed consolidated balance sheet as of May 2, 2021 have been excluded from the table above.

- added (2021-09-09):
[0001730168-21-000123:note_history:5]
As of August 1, 2021 and November 1, 2020, we had standby letters of credit of $52 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- added (2021-09-09):
[0001730168-21-000123:note_history:6]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint

- changed (2021-09-09):
[0001730168-21-000123:note_history:7]
sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit (the “Federal Circuit Court”) and oral arguments were heard on September 1, 2021. We are unable to predict the date on which the Federal Circuit Court will issue its decision.
  (was, 2021-06-11, similarity 0.6994):
[0001730168-21-000116:note_history:7]
California Institute of Technology ("Caltech") filed a complaint against Broadcom and Apple Inc. on May 26, 2016 in the United States District Court for the Central District of California (the “U.S. Central District Court”), and an amended complaint adding Cypress Semiconductor Corporation as a defendant on August 15, 2016. The amended complaint alleged that chips that support certain error correction codes as specified in IEEE Standards 802.11n and 802.11ac willfully infringed four patents related to error correction coding: U.S. Patent Nos. 7,116,710; 7,421,032; 7,916,781; and 8,284,833 (“’833 patent”). Prior to trial, Caltech dismissed its claims against Cypress and withdrew its infringement allegations as to ‘833 patent. The complaint sought a preliminary and permanent injunction, damages, pre- and post-judgment interest, as well as attorneys’ fees, costs, and expenses. The trial was held in January 2020, and on January 29, 2020, the jury issued its verdict finding infringement and awarding Caltech past damages of $270.2 million from Broadcom and $837.8 million from Apple, for which Apple is seeking indemnification from Broadcom. On August 3, 2020, the U.S. Central District Court issued its judgment, awarding Caltech past damages in the amounts awarded by the jury, as well as pre- and post-judgment interest. Additionally, the U.S. Central District Court awarded Caltech an unspecified amount of ongoing royalties to be determined after the anticipated appeals process is resolved. Neither the jury nor the U.S. Central District Court found willful infringement, which if it had, could have resulted in enhanced damages up to three times the amount awarded. Broadcom and Apple have appealed to the United States Court of Appeals for the Federal Circuit.

- changed (2021-09-09):
[0001730168-21-000123:note_history:8]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.
  (was, 2021-06-11, similarity 0.8969):
[0001730168-21-000116:note_history:8]
We believe that the evidence and the law do not support the U.S. Central District Court’s findings of infringement or the award of damages, including ongoing royalties, and do not believe a material loss is probable at this time. We believe that there are strong grounds for appeal, and we intend to vigorously challenge the U.S. Central District Court’s judgment and rulings. As a result, we have not recorded a reserve with respect to this litigation, in accordance with the applicable accounting standards. We believe the low end of the possible range of loss is zero, but we cannot reasonably estimate the

- removed (2021-09-09):
[0001730168-21-000116:note_history:9]
As of May 2, 2021 and November 1, 2020, we had standby letters of credit of $59 million and $65 million, respectively. Standby letters of credit are financial guarantees provided by third parties for leases, customs, taxes and certain self-insured risks. If the guarantees are called, we must reimburse the provider of the guarantees.

- removed (2021-09-09):
[0001730168-21-000116:note_history:10]
ultimate outcome, as a number of factors (including the appeal by Broadcom and Apple) could significantly change the assessment of damages.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:11]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ended on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.
  (was, 2021-06-11, similarity 0.9967):
[0001730168-21-000116:note_history:11]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal year ending October 31, 2021 (“fiscal year 2021”) is a 52-week fiscal year. The first quarter of our fiscal year 2021 ended on January 31, 2021, the second quarter ended on May 2, 2021 and the third quarter ends on August 1, 2021. Our fiscal year ended November 1, 2020 (“fiscal year 2020”) was also a 52-week fiscal year.

- changed (2021-09-09):
[0001730168-21-000123:note_history:12]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and three fiscal quarters ended August 1, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.
  (was, 2021-06-11, similarity 0.9927):
[0001730168-21-000116:note_history:12]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 1, 2020 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2020 as filed with the Securities and Exchange Commission. All intercompany transactions and balances have been eliminated in consolidation. The operating results for the fiscal quarter and two fiscal quarters ended May 2, 2021 are not necessarily indicative of the results that may be expected for fiscal year 2021, or for any other future period.


## avgo:ScheduleofFuturePrincipalPaymentsofDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:13]
The future scheduled principal payments of debt as of August 1, 2021 were as follows:
  (was, 2021-06-11, similarity 0.956):
[0001730168-21-000116:note_history:13]
The future scheduled principal payments of debt as of May 2, 2021 were as follows:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:14]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
|  |  |  |  | 5,500 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 10,000 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
|  |  |  |  | 3,917 |  |  | 3,917 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 6,273 |  |  | 8,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
|  |  |  |  | 3,497 |  |  | 4,500 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
|  |  |  |  | — |  |  | 5,888 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
|  |  |  |  | 4,805 |  |  | 7,762 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
  (was, 2021-06-11, similarity 0.6181):
[0001730168-21-000116:note_history:14]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |

- added (2021-09-09):
[0001730168-21-000123:note_history:15]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 6,992 |  |  | 10,526 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
|  |  |  |  | 493 |  |  | 883 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,100) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,399 |  |  | $ | 40,994 |  |

- added (2021-09-09):
[0001730168-21-000123:note_history:16]
As of August 1, 2021 and November 1, 2020, short-term finance lease liabilities of $24 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $34 million and $48 million, respectively, were included in long-term debt.

- changed (2021-09-09):
[0001730168-21-000123:note_history:17]
In March 2021, we completed our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.
  (was, 2021-06-11, similarity 0.9882):
[0001730168-21-000116:note_history:17]
In March 2021, we completed the settlement of our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034 (collectively, the “March 2021 Senior Notes”). As a result of the Exchange Offer, we paid premiums of $581 million, which were included in unamortized discount and issuance costs. At our option, we may redeem or purchase, in whole or in part, any of the March 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the March 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the March 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- changed (2021-09-09):
[0001730168-21-000123:note_history:18]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of August 1, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.
  (was, 2021-06-11, similarity 0.9943):
[0001730168-21-000116:note_history:18]
In January 2021, we issued $10 billion of senior unsecured notes (the “January 2021 Senior Notes”). At our option, we may redeem or purchase, in whole or in part, any of the January 2021 Senior Notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indenture governing the January 2021 Senior Notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. As of May 2, 2021, the January 2021 Senior Notes were recorded as long-term debt, net of discount and issuance costs, which are amortized to interest expense over the respective terms of these borrowings.

- changed (2021-09-09):
[0001730168-21-000123:note_history:19]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of August 1, 2021, we had no borrowings outstanding under the Revolving Facility.
  (was, 2021-06-11, similarity 0.9957):
[0001730168-21-000116:note_history:19]
In January 2021, we entered into a credit agreement (the “January 2021 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility (the “Revolving Facility”), of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit and certain other instruments would reduce the aggregate amount otherwise available under the Revolving Facility for revolving loans. Subject to the terms of the January 2021 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 19, 2026 and (b) the date of termination in whole of the revolving lenders’ commitments under the January 2021 Credit Agreement. In connection with the January 2021 Credit Agreement, we terminated the credit agreement entered into on May 7, 2019, which provided for a five-year $5 billion unsecured revolving credit facility, and the November 2019 Credit Agreement. As of May 2, 2021, we had no borrowings outstanding under the Revolving Facility.

- changed (2021-09-09):
[0001730168-21-000123:note_history:20]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of August 1, 2021 and November 1, 2020, we had no Commercial Paper outstanding.
  (was, 2021-06-11, similarity 0.9954):
[0001730168-21-000116:note_history:20]
In February 2019, we established a commercial paper program pursuant to which we may issue unsecured commercial paper notes (“Commercial Paper”) in principal amount of up to $2 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial Paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The discount associated with the Commercial Paper is amortized to interest expense over its term. Outstanding Commercial Paper reduces the amount that would otherwise be available to borrow for general corporate purposes under the Revolving Facility. As our commercial paper program is supported by the Revolving Facility, we have the ability and intent to continuously refinance Commercial Paper. As of May 2, 2021 and November 1, 2020, we had no Commercial Paper outstanding.

- changed (2021-09-09):
[0001730168-21-000123:note_history:21]
As of August 1, 2021, the estimated aggregate fair value of debt was $45,379 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2021-06-11, similarity 0.9811):
[0001730168-21-000116:note_history:21]
As of May 2, 2021, the estimated aggregate fair value of debt was $43,868 million. The fair value of our senior notes was determined using quoted prices from less active markets. All of our debt obligations are categorized as Level 2 instruments.

- changed (2021-09-09):
[0001730168-21-000123:note_history:22]
The future scheduled principal payments of debt as of August 1, 2021 were as follows:
  (was, 2021-06-11, similarity 0.956):
[0001730168-21-000116:note_history:22]
The future scheduled principal payments of debt as of May 2, 2021 were as follows:

- changed (2021-09-09):
[0001730168-21-000123:note_history:23]
As of August 1, 2021 and November 1, 2020, we accrued interest payable of $471 million and $304 million, respectively, and were in compliance with all debt covenants.
  (was, 2021-06-11, similarity 0.9769):
[0001730168-21-000116:note_history:23]
As of May 2, 2021 and November 1, 2020, we accrued interest payable of $335 million and $304 million, respectively, and were in compliance with all debt covenants.

- removed (2021-09-09):
[0001730168-21-000116:note_history:24]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,123) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,376 |  |  | $ | 40,994 |  |

- removed (2021-09-09):
[0001730168-21-000116:note_history:25]
As of May 2, 2021 and November 1, 2020, short-term finance lease liabilities of $23 million and $20 million, respectively, were included in the current portion of long-term debt and long-term finance lease liabilities of $39 million and $48 million, respectively, were included in long-term debt.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:26]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
|  |  |  |  | 5,500 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
|  |  |  |  | 10,000 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
|  |  |  |  | 3,917 |  |  | 3,917 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 6,273 |  |  | 8,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
|  |  |  |  | 3,497 |  |  | 4,500 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
|  |  |  |  | — |  |  | 5,888 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
|  |  |  |  | 4,805 |  |  | 7,762 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
  (was, 2021-06-11, similarity 0.6181):
[0001730168-21-000116:note_history:26]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | $ | 2,250 |  |  | $ | — |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | — |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | — |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | — |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | — |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | — |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | — |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 1,695 |  |  | 1,695 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 2,222 |  |  | 2,222 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.250% notes due November 2023 |  | 2.40 | % |  | 105 |  |  | 1,000 |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 1,418 |  |  | 2,250 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 2,750 |  |  | 2,750 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due April 2025 |  | 4.88 | % |  | 1,247 |  |  | 2,250 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 2,250 |  |  | 2,250 |  |
| November 2019 Term Loans - floating rate |  |  |  |  |  |  |
| LIBOR plus 1.125% term loan due November 2022 |  | 1.54 | % |  | — |  |  | 1,819 |  |
| LIBOR plus 1.250% term loan due November 2024 |  | 1.56 | % |  | — |  |  | 4,069 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due April 2021 |  | 3.61 | % |  | — |  |  | 525 |  |
| 3.125% notes due October 2022 |  | 3.53 | % |  | — |  |  | 693 |  |
| 3.625% notes due October 2024 |  | 3.98 | % |  | 622 |  |  | 1,044 |  |
| 4.250% notes due April 2026 |  | 4.54 | % |  | 1,183 |  |  | 2,500 |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 3,000 |  |  | 3,000 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 2.200% notes due January 2021 |  | 2.41 | % |  | — |  |  | 282 |  |
| 3.000% notes due January 2022 |  | 3.21 | % |  | 255 |  |  | 842 |  |
| 2.650% notes due January 2023 |  | 2.78 | % |  | 260 |  |  | 1,000 |  |
| 3.625% notes due January 2024 |  | 3.74 | % |  | 829 |  |  | 1,352 |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |

- added (2021-09-09):
[0001730168-21-000123:note_history:27]
|  |  | Effective Interest Rate |  | August 1,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| 3.125% notes due January 2025 |  | 3.23 | % |  | 585 |  |  | 1,000 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 3,813 |  |  | 4,800 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 1,250 |  |  | 1,250 |  |
|  |  |  |  | 6,992 |  |  | 10,526 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.600% notes due August 2022 |  | 4.07 | % |  | — |  |  | 283 |  |
| 4.500% notes due August 2023 |  | 4.10 | % |  | 143 |  |  | 250 |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 350 |  |  | 350 |  |
|  |  |  |  | 493 |  |  | 883 |  |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% senior notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,100) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,399 |  |  | $ | 40,994 |  |

- removed (2021-09-09):
[0001730168-21-000116:note_history:28]
|  |  | Effective Interest Rate |  | May 2,2021 |  | November 1,2020 |
|  |  | (In millions, except percentages) |
| Other borrowings |  |  |  |  |  |  |
| 2.500% - 4.500% notes due August 2022 - August 2034 |  | 2.59% - 4.55% |  | 22 |  |  | 22 |  |
| Total principal amount outstanding |  |  |  | 41,499 |  |  | 41,498 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,123) |  |  | (504) |  |
| Total debt |  |  |  | $ | 40,376 |  |  | $ | 40,994 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:29]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |
  (was, 2021-06-11, similarity 0.9863):
[0001730168-21-000116:note_history:29]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:30]
|  |  | Fiscal Quarter Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |
  (was, 2021-06-11, similarity 0.9863):
[0001730168-21-000116:note_history:30]
|  |  | Fiscal Quarter Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:31]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |
  (was, 2021-06-11, similarity 0.9776):
[0001730168-21-000116:note_history:31]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:32]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |
  (was, 2021-06-11, similarity 0.9776):
[0001730168-21-000116:note_history:32]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:33]
(a) Subscriptions and services predominantly include software licenses with termination for convenience clauses.
  (was, 2021-06-11, similarity 0.9956):
[0001730168-21-000116:note_history:33]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:34]
|  |  | Fiscal Quarter Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 438 |  |  | $ | 4,129 |  |  | $ | 497 |  |  | $ | 5,064 |  |
| Subscriptions and services (a) |  | 1,150 |  |  | 192 |  |  | 372 |  |  | 1,714 |  |
| Total |  | $ | 1,588 |  |  | $ | 4,321 |  |  | $ | 869 |  |  | $ | 6,778 |  |
  (was, 2021-06-11, similarity 0.9863):
[0001730168-21-000116:note_history:34]
|  |  | Fiscal Quarter Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 471 |  |  | $ | 4,035 |  |  | $ | 477 |  |  | $ | 4,983 |  |
| Subscriptions and services (a) |  | 1,050 |  |  | 193 |  |  | 384 |  |  | 1,627 |  |
| Total |  | $ | 1,521 |  |  | $ | 4,228 |  |  | $ | 861 |  |  | $ | 6,610 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:35]
|  |  | Fiscal Quarter Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 410 |  |  | $ | 3,393 |  |  | $ | 322 |  |  | $ | 4,125 |  |
| Subscriptions and services (a) |  | 1,000 |  |  | 349 |  |  | 347 |  |  | 1,696 |  |
| Total |  | $ | 1,410 |  |  | $ | 3,742 |  |  | $ | 669 |  |  | $ | 5,821 |  |
  (was, 2021-06-11, similarity 0.9863):
[0001730168-21-000116:note_history:35]
|  |  | Fiscal Quarter Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 490 |  |  | $ | 3,438 |  |  | $ | 325 |  |  | $ | 4,253 |  |
| Subscriptions and services (a) |  | 976 |  |  | 162 |  |  | 351 |  |  | 1,489 |  |
| Total |  | $ | 1,466 |  |  | $ | 3,600 |  |  | $ | 676 |  |  | $ | 5,742 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:36]
|  |  | Three Fiscal Quarters Ended August 1, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,299 |  |  | $ | 12,484 |  |  | $ | 1,345 |  |  | $ | 15,128 |  |
| Subscriptions and services (a) |  | 3,204 |  |  | 576 |  |  | 1,135 |  |  | 4,915 |  |
| Total |  | $ | 4,503 |  |  | $ | 13,060 |  |  | $ | 2,480 |  |  | $ | 20,043 |  |
  (was, 2021-06-11, similarity 0.9776):
[0001730168-21-000116:note_history:36]
|  |  | Two Fiscal Quarters Ended May 2, 2021 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 861 |  |  | $ | 8,355 |  |  | $ | 848 |  |  | $ | 10,064 |  |
| Subscriptions and services (a) |  | 2,054 |  |  | 384 |  |  | 763 |  |  | 3,201 |  |
| Total |  | $ | 2,915 |  |  | $ | 8,739 |  |  | $ | 1,611 |  |  | $ | 13,265 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:37]
|  |  | Three Fiscal Quarters Ended August 2, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,340 |  |  | $ | 10,282 |  |  | $ | 960 |  |  | $ | 12,582 |  |
| Subscriptions and services (a) |  | 3,075 |  |  | 680 |  |  | 1,084 |  |  | 4,839 |  |
| Total |  | $ | 4,415 |  |  | $ | 10,962 |  |  | $ | 2,044 |  |  | $ | 17,421 |  |
  (was, 2021-06-11, similarity 0.9776):
[0001730168-21-000116:note_history:37]
|  |  | Two Fiscal Quarters Ended May 3, 2020 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 930 |  |  | $ | 6,889 |  |  | $ | 638 |  |  | $ | 8,457 |  |
| Subscriptions and services (a) |  | 2,075 |  |  | 331 |  |  | 737 |  |  | 3,143 |  |
| Total |  | $ | 3,005 |  |  | $ | 7,220 |  |  | $ | 1,375 |  |  | $ | 11,600 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:38]
(a) Subscriptions and services predominantly include software licenses with termination for convenience clauses.
  (was, 2021-06-11, similarity 0.9956):
[0001730168-21-000116:note_history:38]
(a) Subscriptions and services predominantly includes software licenses with termination for convenience clauses.

- changed (2021-09-09):
[0001730168-21-000123:note_history:39]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based primarily on the geographic shipment location or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.
  (was, 2021-06-11, similarity 0.899):
[0001730168-21-000116:note_history:39]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by region based on the geographic shipment or delivery location specified by our distributors, original equipment manufacturer customers, contract manufacturers, channel partners, or software customers.

- changed (2021-09-09):
[0001730168-21-000123:note_history:40]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of August 1, 2021 |  | $ | 142 |  |  | $ | 3,628 |  |
  (was, 2021-06-11, similarity 0.9799):
[0001730168-21-000116:note_history:40]
|  |  | Contract Assets |  | Contract Liabilities |
|  | (In millions) |
| Balance as of November 1, 2020 |  | $ | 158 |  |  | $ | 3,443 |  |
| Balance as of May 2, 2021 |  | $ | 128 |  |  | $ | 4,097 |  |

- changed (2021-09-09):
[0001730168-21-000123:note_history:41]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 1, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $2,330 million. The amount of revenue recognized during the three fiscal quarters ended August 2, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,315 million.
  (was, 2021-06-11, similarity 0.9883):
[0001730168-21-000116:note_history:41]
Changes in our contract assets and contract liabilities primarily result from the timing difference between our performance and the customer’s payment. We fulfill our obligations under a contract with a customer by transferring products and services in exchange for consideration from the customer. We recognize a contract asset when we transfer products or services to a customer and the right to consideration is conditional on something other than the passage of time. Accounts receivable are recorded when the customer has been billed or the right to consideration is unconditional. We recognize contract liabilities when we have received consideration or an amount of consideration is due from the customer and we have a future obligation to transfer products or services. Contract liabilities include amounts billed or collected and advanced payments on contracts or arrangements, which may include termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 2, 2021 that was included in the contract liabilities balance as of November 1, 2020 was $1,853 million. The amount of revenue recognized during the two fiscal quarters ended May 3, 2020 that was included in the contract liabilities balance as of November 3, 2019 was $1,059 million.

- changed (2021-09-09):
[0001730168-21-000123:note_history:42]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of August 1, 2021 were approximately $12.1 billion. We expect approximately 31% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2021-06-11, similarity 0.9937):
[0001730168-21-000116:note_history:42]
Certain multi-year customer contracts in our semiconductor solutions segment contain firmly committed amounts and the remaining performance obligations under these contracts as of May 2, 2021 were approximately $6.1 billion. We expect approximately 26% of this amount to be recognized as revenue over the next 12 months. Although the majority of our software contracts are not deemed to be committed, our customers generally do not exercise their termination for convenience rights. In addition, the majority of our contracts for products, subscriptions and services have a duration of one year or less. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-09-09):
[0001730168-21-000123:note_history:43]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on September 30, 2021 to stockholders of record on September 15, 2021.
  (was, 2021-06-11, similarity 0.916):
[0001730168-21-000116:note_history:43]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $20.00 per share on our Mandatory Convertible Preferred Stock, payable on June 30, 2021 to stockholders of record on June 15, 2021.

- changed (2021-09-09):
[0001730168-21-000123:note_history:44]
On September 1, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on September 30, 2021 to stockholders of record on September 22, 2021.
  (was, 2021-06-11, similarity 0.9038):
[0001730168-21-000116:note_history:44]
On June 2, 2021, our Board of Directors declared a quarterly cash dividend of $3.60 per share on our common stock, payable on June 30, 2021 to stockholders of record on June 22, 2021.
