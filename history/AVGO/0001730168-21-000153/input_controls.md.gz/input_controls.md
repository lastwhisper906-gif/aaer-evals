# AVGO 10-K controls and the auditor's report


## auditors_report

[0001730168-21-000153:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001730168-21-000153:auditors_report:2]
To the Board of Directors and Stockholders of Broadcom Inc.

[0001730168-21-000153:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001730168-21-000153:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Broadcom Inc. and its subsidiaries (the “Company”) as of October 31, 2021 and November 1, 2020, and the related consolidated statements of operations, of comprehensive income, of stockholders’ equity and of cash flows for each of the three years in the period ended October 31, 2021, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of October 31, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001730168-21-000153:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of October 31, 2021 and November 1, 2020, and the results of its operations and its cash flows for each of the three years in the period ended October 31, 2021 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of October 31, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001730168-21-000153:auditors_report:6]
Change in Accounting Principle

[0001730168-21-000153:auditors_report:7]
As discussed in Note 6 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in fiscal 2020.

[0001730168-21-000153:auditors_report:8]
Basis for Opinions

[0001730168-21-000153:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001730168-21-000153:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001730168-21-000153:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001730168-21-000153:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001730168-21-000153:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and

[0001730168-21-000153:auditors_report:14]
expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001730168-21-000153:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001730168-21-000153:auditors_report:16]
Critical Audit Matters

[0001730168-21-000153:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001730168-21-000153:auditors_report:18]
Uncertain Tax Positions (UTPs)

[0001730168-21-000153:auditors_report:19]
As described in Notes 2 and 12 to the consolidated financial statements, the gross unrecognized tax benefits balance was $5,030 million as of October 31, 2021. As management has disclosed, management evaluates the exposure associated with various tax filing positions and accrues an income tax liability when such positions do not meet the more-likely-than-not threshold for recognition. A tax benefit from an UTP may be recognized when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits.

[0001730168-21-000153:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the UTPs is a critical audit matter are (i) the significant judgment by management when evaluating the technical merits of these tax positions, (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating the technical merits of the tax positions, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001730168-21-000153:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the identification and recognition of the income tax liability for UTPs, including controls addressing the completeness of the UTPs and the measurement of the income tax liability. These procedures also included, among others, (i) testing management’s process for identifying potential new UTPs, (ii) for a selection of UTPs, evaluating possible outcomes, and (iii) for a selection of UTPs, testing the calculation of the income tax liability by jurisdiction, including management’s assessment of the technical merits of tax positions and estimates of the amount of tax benefit expected to be sustained. Professionals with specialized skill and knowledge were used to assist in (i) the evaluation of the completeness of management’s identification of the UTPs and (ii) for a selection of UTPs, the evaluation of the reasonableness of management’s assessment of whether the tax positions are more-likely-than-not of being sustained, the amount of potential benefit to be realized, and the application of relevant tax laws.

[0001730168-21-000153:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0001730168-21-000153:auditors_report:23]
San Jose, California

[0001730168-21-000153:auditors_report:24]
December 17, 2021

[0001730168-21-000153:auditors_report:25]
We have served as the Company’s auditor since 2006.

[0001730168-21-000153:auditors_report:26]
50

[0001730168-21-000153:auditors_report:27]
BROADCOM INC.


## item_9a

[0001730168-21-000153:item_9a:1]
ITEM 9A.CONTROLS AND PROCEDURES

[0001730168-21-000153:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001730168-21-000153:item_9a:3]
Our management, with the participation of our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), evaluated the effectiveness of our disclosure controls and procedures as of October 31, 2021. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to our management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the evaluation of our disclosure controls and procedures as of October 31, 2021, our CEO and CFO concluded that, as of such date, our disclosure controls and procedures were effective at the reasonable assurance level.

[0001730168-21-000153:item_9a:4]
95

[0001730168-21-000153:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001730168-21-000153:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting. Internal control over financial reporting is defined in Rules 13a-15(f) and 15d-15(f) promulgated under the Exchange Act as a process designed by, or under the supervision of, our principal executive and principal financial officers and effected by the Board, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with GAAP and includes those policies and procedures that:

[0001730168-21-000153:item_9a:7]
•pertain to the maintenance of records that in reasonable detail accurately and fairly reflect the transactions and dispositions of the assets;

[0001730168-21-000153:item_9a:8]
•provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with GAAP, and that receipts and expenditures of us are being made only in accordance with authorizations of management and directors; and

[0001730168-21-000153:item_9a:9]
•provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets that could have a material effect on the financial statements.

[0001730168-21-000153:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001730168-21-000153:item_9a:11]
Our management assessed the effectiveness of our internal control over financial reporting as of October 31, 2021. In making this assessment, our management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control-Integrated Framework (2013). Based on this assessment, our management concluded that, as of October 31, 2021, our internal control over financial reporting is effective based on those criteria.

[0001730168-21-000153:item_9a:12]
The effectiveness of our internal control over financial reporting, as of October 31, 2021 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which is included in Part II, Item 8. of this Annual Report on Form 10-K.

[0001730168-21-000153:item_9a:13]
Changes in Internal Control over Financial Reporting

[0001730168-21-000153:item_9a:14]
No change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) occurred during the fourth quarter ended October 31, 2021 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting. Although we have modified our workplace practices globally due to the COVID-19 pandemic, resulting in some of our employees working remotely, this has not meaningfully affected our internal controls over financial reporting. We are continually monitoring and assessing the COVID-19 situation on our internal controls to minimize the impact on their design and operating effectiveness.
