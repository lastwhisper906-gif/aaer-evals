# AVGO MD&A — 0001730168-21-000153


## mdna

[0001730168-21-000153:mdna:1]
ITEM 7.     MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001730168-21-000153:mdna:2]
The following section generally discusses our financial condition and results of operations for our fiscal year ended October 31, 2021 (“fiscal year 2021”) compared to our fiscal year ended November 1, 2020 (“fiscal year 2020”). A discussion regarding our financial condition and results of operations for fiscal year 2020 compared to our fiscal year ended November 3, 2019 (“fiscal year 2019”) can be found in Part II, Item 7 of our Annual Report on Form 10-K for fiscal year 2020, filed with the Securities and Exchange Commission (the “SEC”) on December 18, 2020.

[0001730168-21-000153:mdna:3]
Overview

[0001730168-21-000153:mdna:4]
We are a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. We develop semiconductor devices with a focus on complex digital and mixed signal complementary metal oxide semiconductor based devices and analog III-V based products. We have a history of innovation in the semiconductor industry and offer thousands of products that are used in end products such as enterprise and data center networking, home connectivity, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, data center servers and storage systems, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions enable customers to plan, develop, automate, manage and secure applications across mainframe, distributed, mobile and cloud platforms. Our portfolio of industry-leading infrastructure and security software is designed to modernize, optimize, and secure the most complex hybrid environments, enabling scalability, agility, automation, insights, resiliency and security. We also offer mission critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products.

[0001730168-21-000153:mdna:5]
We have two reportable segments: semiconductor solutions and infrastructure software, as a result of a change in our organizational structure during fiscal year 2020. Our semiconductor solutions segment includes all of our product lines and intellectual property (“IP”) licensing. Our infrastructure software segment includes our mainframe, distributed and cyber security solutions, and our FC SAN business. During fiscal year 2020, we refined our allocation methodology for certain selling, general and administrative expenses to more closely align these costs with the segment benefiting from the shared expenses.

[0001730168-21-000153:mdna:6]
Our strategy is to combine best-of-breed technology leadership in semiconductor and infrastructure software solutions, with unmatched scale, on a common sales and administrative platform to deliver a comprehensive suite of infrastructure technology products to the world’s leading business and government customers. We seek to achieve this through responsibly financed acquisitions of category-leading businesses and technologies, as well as investing extensively in research and development, to ensure our products retain their technology leadership. This strategy results in a robust business model designed to drive diversified and sustainable operating and financial results.

[0001730168-21-000153:mdna:7]
The demand for our products has been affected in the past, and is likely to continue to be affected in the future, by various factors, including the following:

[0001730168-21-000153:mdna:8]
•gain or loss of significant customers;

[0001730168-21-000153:mdna:9]
•general economic and market conditions in the industries and markets in which we compete;

[0001730168-21-000153:mdna:10]
•our distributors’ product inventory and end customer demand;

[0001730168-21-000153:mdna:11]
•the rate at which our present and future customers and end-users adopt our products and technologies in our target markets, and the rate at which our customers' products that include our technology are accepted in their markets;

[0001730168-21-000153:mdna:12]
•the shift to cloud-based information technology solutions and services, such as hyperscale computing, which may adversely affect the timing and volume of sales of our products for use in traditional enterprise data centers; and

[0001730168-21-000153:mdna:13]
•the timing, rescheduling or cancellation of expected customer orders.

[0001730168-21-000153:mdna:14]
COVID-19 Update

[0001730168-21-000153:mdna:15]
In response to the ongoing COVID-19 pandemic and the various resulting government directives, we have taken extensive measures to protect the health and safety of our employees and contractors at our facilities. We modified our workplace practices globally, which resulted in some of our employees working remotely for an extended period of time and some of whom are still working remotely. While we have implemented personal safety measures at all of our facilities where

[0001730168-21-000153:mdna:16]
35

[0001730168-21-000153:mdna:17]
our employees are working on site, we may need to modify our business practices and policies. We continue to monitor the implications of the COVID-19 pandemic on our business, as well as our customers’ and suppliers’ businesses.

[0001730168-21-000153:mdna:18]
The demand environment for our semiconductor products was consistent with our expectations for the fourth quarter of fiscal year 2021, with continued demand for products and infrastructure as customers invest in technologies to support remote or hybrid tele-work and learning arising from COVID-19, as well as the transition to office re-openings. While we continue to see robust demand in this area and record profitability driven by the supply imbalance, the macroeconomic environment remains uncertain and it may not be sustainable over the longer term. We continue to experience various constraints in our supply chain due to the pandemic, including with respect to wafers and substrates. While supply lead times have stabilized, we continue to have difficulties in obtaining some necessary components and inputs in a timely manner to meet increased demand. To date, the impact of COVID-19 on the demand environment for our software products has been limited.

[0001730168-21-000153:mdna:19]
We have also taken various actions to de-risk our business in light of the ongoing uncertainty and strengthen our balance sheet, including closely managing working capital and our debt instruments.

[0001730168-21-000153:mdna:20]
Overall, in light of the changing nature and continuing uncertainty around the COVID-19 pandemic, our ability to predict the impact of COVID-19 on our business in future periods remains limited. The effects of the pandemic on our business are unlikely to be fully realized, or reflected in our financial results, until future periods.

[0001730168-21-000153:mdna:21]
Fiscal Year Highlights

[0001730168-21-000153:mdna:22]
Highlights during fiscal year 2021 include the following:

[0001730168-21-000153:mdna:23]
•We generated $13,764 million of cash from operations.

[0001730168-21-000153:mdna:24]
•We paid $6,212 million in cash dividends.

[0001730168-21-000153:mdna:25]
Acquisitions and Divestitures

[0001730168-21-000153:mdna:26]
The discussion and analysis in this section and the accompanying consolidated financial statements include the results of operations of acquired companies commencing on their respective acquisition dates.

[0001730168-21-000153:mdna:27]
Acquisition of Symantec Corporation Enterprise Security Business

[0001730168-21-000153:mdna:28]
On November 4, 2019, we purchased and assumed certain assets and certain liabilities, respectively, of the Symantec Corporation Enterprise Security business (the “Symantec Business”) for $10.7 billion in cash. We financed this acquisition with the net proceeds from the borrowings under the November 2019 Term Loans, as defined in Note 10. “Borrowings” included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-21-000153:mdna:29]
Acquisition of CA, Inc.

[0001730168-21-000153:mdna:30]
On November 5, 2018, we acquired CA, Inc. (“CA”) for $18.8 billion in aggregate cash purchase consideration and assumed $2.25 billion of outstanding unsecured bonds. We financed the acquisition of CA with $18 billion of term loans, as well as cash on hand of the combined companies. We also assumed all eligible unvested CA equity awards in the transaction. On December 31, 2018, we sold Veracode, Inc., a subsidiary of CA and provider of application security testing solutions, to Thoma Bravo, LLC for cash consideration of $950 million, before working capital adjustments.

[0001730168-21-000153:mdna:31]
Net Revenue

[0001730168-21-000153:mdna:32]
A majority of our net revenue is derived from sales of a broad range of semiconductor devices that are incorporated into electronic products, as well as from modules, switches and subsystems. Net revenue is also generated from the sale of software solutions that enable our customers to plan, develop, automate, manage, and secure applications across mainframe, distributed, mobile, and cloud platforms.

[0001730168-21-000153:mdna:33]
Our overall net revenue, as well as the percentage of total net revenue generated by sales in our semiconductor solutions and infrastructure software segments, have varied from quarter to quarter, due largely to fluctuations in end-market demand, including the effects of seasonality, which are discussed in detail in Part I, Item 1. Business under “Seasonality” of this Annual Report on Form 10-K.

[0001730168-21-000153:mdna:34]
Original equipment manufacturers (“OEMs”), or their contract manufacturers, and distributors, typically account for the substantial majority of our semiconductor sales. To serve customers around the world, we have strategically developed relationships with large global electronic component distributors, complemented by a number of regional distributors with customer relationships based on their respective product ranges. We have established strong relationships with leading OEM customers across multiple target markets. Our direct sales force focuses on supporting our large OEM customers and has specialized product and service knowledge that enables us to sell specific offerings at key levels throughout a customer’s organization. Certain customers require us to contract with them directly and with specified intermediaries, such as contract

[0001730168-21-000153:mdna:35]
manufacturers. Many of our major customer relationships have been in place for many years and are often the result of years of collaborative product development. This has enabled us to build our extensive IP portfolio and develop critical expertise regarding our customers’ requirements, including substantial system-level knowledge. This collaboration has provided us with key insights into our customers' businesses and has enabled us to be more efficient and productive and to better serve our target markets and customers. We recognize revenue upon the delivery of our products to the distributors, which can cause our quarterly net revenue to fluctuate significantly. Such revenue is reduced for estimated returns and distributor allowances.

[0001730168-21-000153:mdna:36]
Our software customers generally consist of large enterprises that have computing environments from multiple vendors and are highly complex. We believe our enterprise-wide license model will continue to offer our customers reduced complexity, more flexibility and an easier renewal process that will help drive revenue growth.

[0001730168-21-000153:mdna:37]
Costs and Expenses

[0001730168-21-000153:mdna:38]
Cost of products sold.  Cost of products sold consists primarily of the costs for semiconductor wafers and other materials, as well as the costs of assembling and testing those products and materials. Such costs include personnel and overhead related to our manufacturing operations, which include stock-based compensation expense; related occupancy; computer services; equipment costs; manufacturing quality; order fulfillment; warranty adjustments; inventory adjustments, including write-downs for inventory obsolescence; and acquisition costs, which include direct transaction costs and acquisition-related costs.

[0001730168-21-000153:mdna:39]
Although we outsource a significant portion of our manufacturing activities, we do have some proprietary semiconductor fabrication facilities. If we are unable to utilize our owned fabrication facilities at a desired level, the fixed costs associated with these facilities will not be fully absorbed, resulting in higher average unit costs and lower gross margins.

[0001730168-21-000153:mdna:40]
Cost of subscriptions and services.  Cost of subscriptions and services consists of personnel, project costs associated with professional services or support of our subscriptions and services revenue, and allocated facilities costs and other corporate expenses. Personnel costs include stock-based compensation expense.

[0001730168-21-000153:mdna:41]
Total cost of revenue also includes amortization of acquisition-related intangible assets and restructuring charges.

[0001730168-21-000153:mdna:42]
Research and development.  Research and development expense consists primarily of personnel costs for our engineers engaged in the design and development of our products and technologies, including stock-based compensation expense. These expenses also include project material costs, third-party fees paid to consultants, prototype development expense, allocated facilities costs and other corporate expenses and computer services costs related to supporting computer tools used in the engineering and design process.

[0001730168-21-000153:mdna:43]
Selling, general and administrative.  Selling expense consists primarily of compensation and associated costs for sales and marketing personnel, including stock-based compensation expense, sales commissions paid to our independent sales representatives, advertising costs, trade shows, corporate marketing, promotion, travel related to our sales and marketing operations, related occupancy and equipment costs, and other marketing costs. General and administrative expense consists primarily of compensation and associated costs for executive management, finance, human resources and other administrative personnel, including stock-based compensation expense, outside professional fees, allocated facilities costs, acquisition-related costs and other corporate expenses.

[0001730168-21-000153:mdna:44]
Amortization of acquisition-related intangible assets.  In connection with our acquisitions, we recognize intangible assets that are being amortized over their estimated useful lives. We also recognize goodwill, which is not amortized, and in-process research and development (“IPR&D”), which is initially capitalized as an indefinite-lived intangible asset, in connection with the acquisitions. Upon completion of each underlying project, IPR&D assets are reclassified as amortizable purchased intangible assets and amortized over their estimated useful lives.

[0001730168-21-000153:mdna:45]
Restructuring, impairment and disposal charges. Restructuring, impairment and disposal charges consist primarily of compensation costs associated with employee exit programs, alignment of our global manufacturing operations, rationalizing product development program costs, facility and lease abandonments, fixed asset impairment, IPR&D impairment, and other exit costs, including curtailment of service or supply agreements.

[0001730168-21-000153:mdna:46]
Interest expense.  Interest expense includes coupon interest, commitment fees, accretion of original issue discount, amortization of debt premiums and debt issuance costs, and expenses related to debt modifications or extinguishments.

[0001730168-21-000153:mdna:47]
Other income, net.  Other income, net includes interest income, gains or losses on investments, foreign currency remeasurement, and other miscellaneous items.

[0001730168-21-000153:mdna:48]
Provision for (benefit from) income taxes.  We have structured our operations to maximize the benefit from tax incentives extended to us in various jurisdictions to encourage investment or employment. Our tax incentives from the Singapore Economic Development Board provide that any qualifying income earned in Singapore is subject to tax incentives or reduced rates of Singapore income tax. Subject to our compliance with the conditions specified in these incentives and

[0001730168-21-000153:mdna:49]
legislative developments, these Singapore tax incentives are presently expected to expire in November 2025. The corporate income tax rate in Singapore that would otherwise apply to us would be 17%. We also have a tax holiday on our qualifying income in Malaysia, which is scheduled to expire in fiscal year 2028.

[0001730168-21-000153:mdna:50]
Each tax incentive and tax holiday is also subject to our compliance with various operating and other conditions. If we cannot, or elect not to, comply with any such operating conditions specified, we could, in some instances, be required to refund previously realized material tax benefits, or if such tax incentive or tax holiday is terminated prior to its expiration absent a new incentive applying, we will lose the related tax benefits earlier than scheduled. We may elect to modify our operational structure and tax strategy, which may not be as beneficial to us as the benefits provided under the present tax concession arrangements. Before taking into consideration the effects of the U.S. Tax Cuts and Jobs Act and other indirect tax impacts, the effect of these tax incentives and tax holiday was to decrease the provision for income taxes by approximately $1,156 million for fiscal year 2021 and increase the benefit from income taxes by approximately $833 million for fiscal year 2020.

[0001730168-21-000153:mdna:51]
Our interpretations and conclusions regarding the tax incentives are not binding on any taxing authority, and if our assumptions about tax and other laws are incorrect or if these tax incentives are substantially modified or rescinded, we could suffer material adverse tax and other financial consequences, which would increase our expenses, reduce our profitability and adversely affect our cash flows. In addition, taxable income in any jurisdiction is dependent upon acceptance of our operational practices and intercompany transfer pricing by local tax authorities as being on an arm’s length basis. Due to inconsistencies in application of the arm’s length standard among taxing authorities, as well as lack of adequate treaty-based protection, transfer pricing challenges by tax authorities could, if successful, substantially increase our income tax expense.

[0001730168-21-000153:mdna:52]
Critical Accounting Estimates

[0001730168-21-000153:mdna:53]
The preparation of financial statements in accordance with generally accepted accounting principles in the United States (“GAAP”) requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the reporting period. We base our estimates and assumptions on current facts, historical experience and various other factors that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities and the accrual of costs and expenses that are not readily apparent from other sources. Our actual financial results may differ materially and adversely from our estimates. Our critical accounting policies are those that affect our historical financial statements materially and involve difficult, subjective or complex judgments by management. Those policies include revenue recognition, business combinations, valuation of goodwill and long-lived assets, inventory valuation, income taxes, retirement and post-retirement benefit plan assumptions, stock-based compensation and employee bonus programs. See Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K for further information on our critical accounting policies and estimates.

[0001730168-21-000153:mdna:54]
Revenue recognition.  We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable we will collect substantially all of the consideration we are entitled to. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer. Our products and services can be broadly categorized as sales of products and subscriptions and services.

[0001730168-21-000153:mdna:55]
We recognize products revenue from sales to direct customers and distributors when control transfers to the customer. An allowance for distributor credits covering price adjustments is made based on our estimate of historical experience rates as well as considering economic conditions and contractual terms. To date, actual distributor claims activity has been materially consistent with the provisions we have made based on our historical estimates. However, because of the inherent nature of estimates, there is always a risk that there could be significant differences between actual amounts and our estimates. Different judgments or estimates could result in variances that might be significant to reported operating results. We also record reductions of revenue for rebates in the same period that the related revenue is recorded. We accrue 100% of potential rebates at the time of sale. We reverse the accrual of unclaimed rebate amounts as specific rebate programs contractually end and when we believe unclaimed rebates are no longer subject to payment and will not be paid. Thus, the reversal of unclaimed rebates may have a positive impact on our net revenue and net income in subsequent periods.

[0001730168-21-000153:mdna:56]
Our contracts may contain more than one of our products and services, each of which is separately accounted for as a distinct performance obligation. When available, we use directly observable transactions to determine the standalone selling prices for performance obligations. Our estimates of standalone selling price for each performance obligation require judgment that considers multiple factors, including, but not limited to, historical discounting trends for products and services and pricing practices through different sales channels, gross margin objectives, internal costs, competitor pricing strategies, technology lifecycles and market conditions.

[0001730168-21-000153:mdna:57]
We also estimate the standalone selling price of our material rights. Our estimate of the value of the customer’s option to purchase or receive additional products or services at a discounted price includes estimating the incremental discount the customer would obtain when exercising the option and the likelihood that the option would be exercised.

[0001730168-21-000153:mdna:58]
Certain contracts contain a right of return that allows the customer to cancel all or a portion of the product or service and receive a credit. We estimate returns based on historical returns data which is constrained to an amount for which a material revenue reversal is not probable. We do not recognize revenue for products or services that are expected to be returned.

[0001730168-21-000153:mdna:59]
Business combinations.  Accounting for business combinations requires management to make significant estimates and assumptions, especially at the acquisition date, for intangible assets, contractual obligations assumed, restructuring liabilities, pre-acquisition contingencies, and contingent consideration, where applicable. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based, in part, on historical experience and information obtained from management of the acquired companies and are inherently uncertain. Critical estimates in valuing certain of the intangible assets we have acquired include, but are not limited to, future expected cash flows from product sales, customer contracts and acquired technologies, revenue growth rate, customer ramp-up period, technology obsolescence rates, expected costs to develop IPR&D into commercially viable products, estimated cash flows from the projects when completed, and discount rates. The discount rates used to discount expected future cash flows to present value are typically derived from a weighted-average cost of capital analysis and adjusted to reflect inherent risks. Unanticipated events and circumstances may occur that could affect either the accuracy or validity of such assumptions, estimates or actual results.

[0001730168-21-000153:mdna:60]
Valuation of goodwill and long-lived assets.  We perform an annual impairment review of our goodwill during the fourth fiscal quarter of each year, and more frequently if we believe indicators of impairment exist. The process of evaluating the potential impairment of goodwill is highly subjective and requires significant judgment. To review for impairment, we first assess qualitative factors to determine whether events or circumstances lead to a determination that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount. Our qualitative assessment of the recoverability of goodwill, whether performed annually or based on specific events or circumstances, considers various macroeconomic, industry-specific and company-specific factors. These factors include: (i) severe adverse industry or economic trends; (ii) significant company-specific actions, including exiting an activity in conjunction with restructuring of operations; (iii) current, historical or projected deterioration of our financial performance; or (iv) a sustained decrease in our market capitalization below our net book value. After assessing the totality of events and circumstances, if we determine that it is not more likely than not that the fair value of any of our reporting units is less than its carrying amount, no further assessment is performed. If we determine that it is more likely than not that the fair value of any of our reporting units is less than its carrying amount, we calculate the fair value of that reporting unit and compare the fair value to the reporting unit’s net book value.

[0001730168-21-000153:mdna:61]
Determining the fair value of a reporting unit involves the use of significant estimates and assumptions. Our goodwill impairment test uses both the income approach and the market approach to estimate a reporting unit's fair value. The income approach is based on the discounted cash flow method that uses the reporting unit estimates for forecasted future financial performance including revenues, operating expenses, and taxes, as well as working capital and capital asset requirements. These estimates are developed as part of our long-term planning process based on assumed market segment growth rates and our assumed market segment share, estimated costs based on historical data and various internal estimates. Projected cash flows are then discounted to a present value employing a discount rate that properly accounts for the estimated market weighted-average cost of capital, as well as any risk unique to the subject cash flows. The market approach is based on weighting financial multiples of comparable companies and applies a control premium. A reporting unit's carrying value represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash and debt.

[0001730168-21-000153:mdna:62]
We assess the impairment of long-lived assets including purchased IPR&D, property, plant and equipment, and intangible assets, whenever events or changes in circumstances indicate that the carrying value of such assets may not be recoverable. Factors we consider important which could trigger an impairment review include (i) significant under-performance relative to historical or projected future operating results, (ii) significant changes in the manner of our use of the acquired assets or the strategy for our overall business, or (iii) significant negative industry or economic trends. The process of evaluating the potential impairment of long-lived assets under the accounting guidance on property, plant and equipment and other intangible assets is also highly subjective and requires significant judgment. In order to estimate the fair value of long-lived assets, we typically make various assumptions about the future prospects of our business or the part of our business that the long-lived asset relates to. We also consider market factors specific to the business and estimate future cash flows to be generated by the business, which requires significant judgment as it is based on assumptions about market demand for our products over a number of future years. Based on these assumptions and estimates, we determine whether we need to take an impairment charge to reduce the value of the long-lived asset stated on our consolidated balance sheets

[0001730168-21-000153:mdna:63]
39

[0001730168-21-000153:mdna:64]
to reflect its estimated fair value. Assumptions and estimates about future values and remaining useful lives are complex and often subjective. They can be affected by a variety of factors, including external factors, such as the real estate market, industry and economic trends, and internal factors, such as changes in our business strategy and our internal forecasts. Although we believe the assumptions and estimates we have made in the past have been reasonable and appropriate, changes in assumptions and estimates could materially impact our reported financial results.

[0001730168-21-000153:mdna:65]
Inventory valuation.  We regularly review inventory quantities on hand and record a provision for excess and obsolete inventory based primarily on our forecast of product demand and production requirements. Demand for our products can fluctuate significantly from period to period. A significant decrease in demand could result in an increase in the amount of excess inventory quantities on hand. In addition, our industry is characterized by rapid technological change, frequent new product development and rapid product obsolescence that could result in an increase in the amount of obsolete inventory quantities on hand. Additionally, our estimates of future product demand may prove to be inaccurate, which may cause us to understate or overstate both the provision required for excess and obsolete inventory and cost of products sold. Therefore, although we make every effort to ensure the accuracy of our forecasts of future product demand, any significant unanticipated changes in demand or technological developments could have a significant impact on the value of our inventory and our results of operations.

[0001730168-21-000153:mdna:66]
Income taxes.  Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. We have considered projected future taxable income and ongoing prudent and feasible tax planning strategies in assessing the need for valuation allowances. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made. In evaluating the exposure associated with various tax filing positions, we accrue an income tax liability when such positions do not meet the more likely than not threshold for recognition.

[0001730168-21-000153:mdna:67]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax law and regulations in a multitude of jurisdictions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes, interest, and penalties will be due. If our estimate of income tax liabilities proves to be less than the actual amount ultimately assessed, a further charge to tax expense would be required. If the payment of these amounts ultimately proves to be unnecessary, the reversal of the accrued liabilities would result in tax benefits being recognized in the period when we determine the liabilities no longer exist.

[0001730168-21-000153:mdna:68]
Retirement and post-retirement benefit plan assumptions.  Retirement and post-retirement benefit plan obligations represent liabilities that will ultimately be settled sometime in the future and therefore, are subject to estimation. Pension accounting is intended to reflect the recognition of future retirement and post-retirement benefit plan costs over the employees' average expected future service to us, based on the terms of the plans and investment and funding decisions. To estimate the impact of these future payments and our decisions concerning funding of these obligations, we are required to make assumptions using actuarial concepts within the framework of GAAP. One assumption is the discount rate used to calculate the estimated plan obligations. Other assumptions include the expected long-term return on plan assets, expected future salary increases, the health care cost trend rate, expected future increases to benefit payments, expected retirement dates, employee turnover, retiree mortality rates, and portfolio composition. We evaluate these assumptions at least annually.

[0001730168-21-000153:mdna:69]
For our U.S. and non-U.S. plans, we use October 31, the month end closest to our fiscal year end, as the annual discount rate measurement date to determine the present value of future benefit payments. The U.S. discount rates are based on the results of matching expected plan benefit payments with cash flows from a hypothetical yield curve constructed with high-quality corporate bond yields. The discount rate for non-U.S. plans was based either on published rates for government bonds or use of a hypothetical yield curve constructed with high-quality corporate bond yields, depending on the availability of sufficient quantities of quality corporate bonds. Lower discount rates increase present values of the pension liabilities and subsequent year pension expense; higher discount rates decrease present values of the pension liabilities and subsequent year pension expense.

[0001730168-21-000153:mdna:70]
The U.S. expected rate of return on plan assets is set equal to the discount rate due to the implementation of our fully-matched, liability-driven investment strategy.

[0001730168-21-000153:mdna:71]
Actuarial assumptions are based on our best estimates and judgment. Material changes may occur in retirement benefit costs in the future if these assumptions differ from actual events or experiences. We performed a sensitivity analysis on the discount rate, which is the key assumption in calculating the U.S. pension and post-retirement benefit obligations. Each change of 25 basis points in the discount rate assumption would have had an estimated $36 million impact on the benefit obligations as of the fiscal year 2021 measurement date. Each change of 25 basis points in the discount rate assumption or expected rate of return assumption would not have a material impact on annual net retirement benefit costs for the fiscal year ending October 30, 2022 (“fiscal year 2022”).

[0001730168-21-000153:mdna:72]
40

[0001730168-21-000153:mdna:73]
Stock-based compensation expense.  Stock-based compensation expense consists of expense for restricted stock units (“RSUs”) and stock options granted to employees and non-employees or assumed from acquisitions as well as expense associated with Broadcom employee stock purchase plan (“ESPP”). We recognize compensation expense for time-based stock options and ESPP rights based on the estimated grant-date fair value method required under the authoritative guidance using the Black-Scholes valuation model.

[0001730168-21-000153:mdna:74]
Certain equity awards include both time-based and market-based conditions and are accounted for as market-based awards. The fair value of these market-based awards is estimated on the date of grant using a Monte Carlo simulation model.

[0001730168-21-000153:mdna:75]
Employee Bonus Programs.  Our employee bonus programs, which are overseen by our Compensation Committee, or our Board, in the case of our Chief Executive Officer, provide for variable compensation based on the attainment of overall corporate annual targets and functional performance metrics. At the end of each fiscal quarter, we monitor and accrue for an estimated, variable, proportional compensation expense based on our actual progress toward the achievement of the annual targets and metrics. The actual achievement of target and metrics at the end of the fiscal year, which is subject to approval by our Compensation Committee, may result in the actual variable compensation amounts being significantly higher or lower than the relevant estimated amounts accrued in earlier quarters, which would result in a corresponding adjustment in the fourth fiscal quarter.

[0001730168-21-000153:mdna:76]
Fiscal Year Presentation

[0001730168-21-000153:mdna:77]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31 in a 52-week year and the first Sunday in November in a 53-week year. Our fiscal years 2021, 2020 and 2019 consisted of 52 weeks.

[0001730168-21-000153:mdna:78]
The financial statements included in Part II, Item 8. of this Annual Report on Form 10-K are presented in accordance with GAAP and expressed in U.S. dollars.

[0001730168-21-000153:mdna:79]
Results of Operations

[0001730168-21-000153:mdna:80]
Fiscal Year 2021 Compared to Fiscal Year 2020

[0001730168-21-000153:mdna:81]
The following table sets forth our results of operations for the periods presented:

[0001730168-21-000153:mdna:82]
|  |  | Fiscal Year Ended |
|  |  | October 31,2021 |  | November 1,2020 |  | October 31,2021 |  | November 1,2020 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 20,886 |  |  | $ | 17,435 |  |  | 76 | % |  | 73 | % |
| Subscriptions and services |  | 6,564 |  |  | 6,453 |  |  | 24 |  |  | 27 |  |
| Total net revenue |  | 27,450 |  |  | 23,888 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 6,555 |  |  | 5,892 |  |  | 24 |  |  | 25 |  |
| Cost of subscriptions and services |  | 607 |  |  | 626 |  |  | 2 |  |  | 2 |  |
| Amortization of acquisition-related intangible assets |  | 3,427 |  |  | 3,819 |  |  | 13 |  |  | 16 |  |
| Restructuring charges |  | 17 |  |  | 35 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 10,606 |  |  | 10,372 |  |  | 39 |  |  | 43 |  |
| Gross margin |  | 16,844 |  |  | 13,516 |  |  | 61 |  |  | 57 |  |
| Research and development |  | 4,854 |  |  | 4,968 |  |  | 18 |  |  | 21 |  |
| Selling, general and administrative |  | 1,347 |  |  | 1,935 |  |  | 5 |  |  | 8 |  |
| Amortization of acquisition-related intangible assets |  | 1,976 |  |  | 2,401 |  |  | 7 |  |  | 10 |  |
| Restructuring, impairment and disposal charges |  | 148 |  |  | 198 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 8,325 |  |  | 9,502 |  |  | 30 |  |  | 40 |  |
| Operating income |  | $ | 8,519 |  |  | $ | 4,014 |  |  | 31 | % |  | 17 | % |

[0001730168-21-000153:mdna:83]
Net Revenue

[0001730168-21-000153:mdna:84]
A relatively small number of customers account for a significant portion of our net revenue. Sales of products to distributors accounted for 53% and 42% of our net revenue for fiscal years 2021 and 2020, respectively. Direct sales to WT Microelectronics Co., Ltd., a distributor, accounted for 18% and 13% of our net revenue for fiscal years 2021 and 2020, respectively. We believe aggregate sales to our top five end customers, through all channels, accounted for more than 35% and 30% of our net revenue for fiscal years 2021 and 2020, respectively. We believe aggregate sales to Apple Inc., through all channels, accounted for approximately 20% and 15% of our net revenue for fiscal years 2021 and 2020, respectively. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-21-000153:mdna:85]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our wireless products as fluctuations may be magnified by the timing of launches, and seasonal variations in sales, of mobile handsets. The ongoing COVID-19 pandemic and related uncertainties and supply imbalance have caused and may continue to cause our net revenue to fluctuate significantly and impact our results of operations, as discussed above. Additionally, export restrictions on one of our larger customers have had, and may continue to have, an adverse impact on our revenue.

[0001730168-21-000153:mdna:86]
Although we recognize revenue for the majority of our products when title and control transfer in Penang, Malaysia, we disclose net revenue by country based primarily on the geographic shipment or delivery location specified by our distributors, OEMs, contract manufacturers, channel partners, or software customers. In each of fiscal years 2021 and 2020, approximately 35% of our net revenue came from shipments or deliveries to China (including Hong Kong). However, the end customers for either our products or for the end products into which our products are incorporated, are frequently located in countries other than China (including Hong Kong). As a result, we believe that a substantially smaller percentage of our net revenue is ultimately dependent on sales of either our product or our customers’ product incorporating our product, to end customers located in China (including Hong Kong).

[0001730168-21-000153:mdna:87]
The following tables set forth net revenue by segment for the periods presented:

[0001730168-21-000153:mdna:88]
|  |  | Fiscal Year Ended |  |  |  |  |
| Net Revenue by Segment |  | October 31,2021 |  | November 1,2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 20,383 |  |  | $ | 17,267 |  |  | $ | 3,116 |  |  | 18 | % |
| Infrastructure software |  | 7,067 |  |  | 6,621 |  |  | 446 |  |  | 7 | % |
| Total net revenue |  | $ | 27,450 |  |  | $ | 23,888 |  |  | $ | 3,562 |  |  | 15 | % |

[0001730168-21-000153:mdna:89]
|  |  | Fiscal Year Ended |
| Net Revenue by Segment |  | October 31, 2021 |  | November 1, 2020 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 74 | % |  | 72 | % |
| Infrastructure software |  | 26 |  |  | 28 |  |
| Total net revenue |  | 100 | % |  | 100 | % |

[0001730168-21-000153:mdna:90]
Net revenue from our semiconductor solutions segment increased primarily due to higher demand for our wireless products, as well as the delayed production ramp of a new mobile handset by a major customer in the prior fiscal year, which resulted in lower shipments in fiscal year 2020. Net revenue from our semiconductor solutions segment also increased due to higher demand for our networking and wireless connectivity products. Net revenue from our infrastructure software segment increased primarily due to higher demand for our FC SAN products, mainframe and cyber security solutions.

[0001730168-21-000153:mdna:91]
Gross Margin

[0001730168-21-000153:mdna:92]
Gross margin was $16,844 million, or 61% of net revenue, for fiscal year 2021, compared to $13,516 million, or 57% of net revenue, for fiscal year 2020. The increase was primarily due to lower amortization of acquisition-related intangible assets and favorable margin within our semiconductor solutions segment due to increased demand.

[0001730168-21-000153:mdna:93]
Research and Development Expense

[0001730168-21-000153:mdna:94]
Research and development expense decreased $114 million, or 2%, in fiscal year 2021, compared to the prior fiscal year. The decrease was primarily due to lower stock-based compensation expense reflecting the full vesting of certain equity awards and the effects of forfeitures, partially offset by higher variable employee compensation expense.

[0001730168-21-000153:mdna:95]
Selling, General and Administrative Expense

[0001730168-21-000153:mdna:96]
Selling, general and administrative expense decreased $588 million, or 30%, in fiscal year 2021, compared to the prior fiscal year. The decrease was primarily due to higher acquisition-related costs incurred in the prior fiscal year as a result of our acquisition of the Symantec Business. The decrease was also due to lower compensation expense reflecting the full benefit of the completed Symantec Business integration as well as our strategic workforce alignment. In addition, fiscal year 2020 included non-recurring litigation settlements.

[0001730168-21-000153:mdna:97]
Amortization of Acquisition-Related Intangible Assets

[0001730168-21-000153:mdna:98]
Amortization of acquisition-related intangible assets recognized in operating expenses decreased $425 million, or 18%, in fiscal year 2021, compared to the prior fiscal year. The decrease was primarily due to lower amortization of certain intangible assets from our acquisition of CA.

[0001730168-21-000153:mdna:99]
Restructuring, Impairment and Disposal Charges

[0001730168-21-000153:mdna:100]
Restructuring, impairment and disposal charges recognized in operating expenses decreased $50 million, or 25%, in fiscal year 2021, compared to the prior fiscal year. The decrease was primarily due to higher employee termination costs in the prior fiscal year from cost reduction activities related to our acquisition of the Symantec Business.

[0001730168-21-000153:mdna:101]
Stock-Based Compensation Expense

[0001730168-21-000153:mdna:102]
Total stock-based compensation expense was $1,704 million and $1,976 million for fiscal years 2021 and 2020, respectively. The decrease primarily reflects the full vesting of certain equity awards and the effect of forfeitures.

[0001730168-21-000153:mdna:103]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of October 31, 2021, which we expect to recognize over the remaining weighted-average service period of 2.9 years.

[0001730168-21-000153:mdna:104]
43

[0001730168-21-000153:mdna:105]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2022 |  | $ | 1,289 |  |
| 2023 |  | 907 |  |
| 2024 |  | 535 |  |
| 2025 |  | 210 |  |
| 2026 |  | 26 |  |
| Total |  | $ | 2,967 |  |

[0001730168-21-000153:mdna:106]
During the first quarter of fiscal year 2019, our Compensation Committee approved a broad-based program of multi-year equity grants of time- and market-based RSUs (the “Multi-Year Equity Awards”) in lieu of our annual employee equity awards historically granted on March 15 of each year. Each Multi-Year Equity Award vests on the same basis as four annual grants made March 15 of each year, beginning in fiscal year 2019, with successive four-year vesting periods. We recognize stock-based compensation expense related to the Multi-Year Equity Awards from the grant date through their respective vesting date, ranging from 4 years to 7 years.

[0001730168-21-000153:mdna:107]
Segment Operating Results

[0001730168-21-000153:mdna:108]
|  |  | Fiscal Year Ended |  |  |  |  |
| Operating Income by Segment |  | October 31, 2021 |  | November 1, 2020 |  | $ Change |  | % Change |
|  |  | (In millions, except for percentages) |
| Semiconductor solutions |  | $ | 10,976 |  |  | $ | 8,576 |  |  | $ | 2,400 |  |  | 28 | % |
| Infrastructure software |  | 4,936 |  |  | 4,363 |  |  | 573 |  |  | 13 | % |
| Unallocated expenses |  | (7,393) |  |  | (8,925) |  |  | 1,532 |  |  | (17) | % |
| Total operating income |  | $ | 8,519 |  |  | $ | 4,014 |  |  | $ | 4,505 |  |  | 112 | % |

[0001730168-21-000153:mdna:109]
Operating income from our semiconductor solutions segment increased primarily due to higher demand for our wireless products, as well as the delayed production ramp of a new mobile handset by a major customer in the prior fiscal year, which resulted in lower shipments in fiscal year 2020. Operating income from our semiconductor solutions segment also increased due to higher demand for our networking and wireless connectivity products, as well as higher gross margin. Operating income from our infrastructure software segment increased primarily due to higher demand for our FC SAN products and mainframe solutions.

[0001730168-21-000153:mdna:110]
Unallocated expenses include amortization of acquisition-related intangible assets; stock-based compensation expense; restructuring, impairment and disposal charges; acquisition-related costs; and other costs that are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses decreased 17% in fiscal year 2021, compared to the prior fiscal year, primarily due to lower amortization of acquisition-related intangible assets, acquisition-related costs and stock-based compensation expense.

[0001730168-21-000153:mdna:111]
Non-Operating Income and Expenses

[0001730168-21-000153:mdna:112]
Interest expense.  Interest expense was $1,885 million and $1,777 million for fiscal years 2021 and 2020, respectively. The increase was primarily due to higher losses on extinguishment of debt as a result of our fiscal year 2021 debt transactions.

[0001730168-21-000153:mdna:113]
Other income, net.  Other income, net, which includes interest income, gains or losses on investments, foreign currency remeasurement and other miscellaneous items, was $131 million and $206 million for fiscal years 2021 and 2020, respectively. The decrease was primarily due to a $116 million non-recurring gain from the lapse of a tax indemnification arrangement included in the prior fiscal year, offset in part by an increase in gains on investments in fiscal year 2021.

[0001730168-21-000153:mdna:114]
Provision for (benefit from) income taxes.  The provision for income taxes of $29 million in fiscal year 2021 was primarily due to income from continuing operations, offset in part by excess tax benefits from stock-based awards, a benefit from foreign derived intangible income, and the recognition of gross unrecognized tax benefits as a result of lapses of statutes of limitations and audit settlements.

[0001730168-21-000153:mdna:115]
The benefit from income taxes of $518 million in fiscal year 2020 was primarily due to the jurisdictional mix of income and expense, the recognition of gross uncertain tax benefits as a result of lapses of statutes of limitations, the remeasurement of certain foreign deferred tax assets and liabilities, and excess tax benefit from stock-based awards.

[0001730168-21-000153:mdna:116]
Liquidity and Capital Resources

[0001730168-21-000153:mdna:117]
The following section discusses our principal liquidity and capital resources as well as our primary liquidity requirements and uses of cash. Our cash and cash equivalents are maintained in highly liquid investments with remaining maturities of 90 days or less at the time of purchase. We believe our cash equivalents are liquid and accessible.

[0001730168-21-000153:mdna:118]
Our primary sources of liquidity as of October 31, 2021 consisted of: (i) $12,163 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility (the “Revolving Facility”). In addition, we may also generate cash from the sale of assets and debt or equity financing from time to time.

[0001730168-21-000153:mdna:119]
Our short-term and long-term liquidity requirements primarily arise from: (i) business acquisitions and investments we may make from time to time, (ii) working capital requirements, (iii) research and development and capital expenditure needs, (iv) cash dividend payments (if and when declared by our Board of Directors), (v) interest and principal payments related to our outstanding indebtedness, (vi) share repurchases, and (vii) payment of income taxes. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-21-000153:mdna:120]
We believe that our cash and cash equivalents on hand, cash flows from operations, and the Revolving Facility will provide sufficient liquidity to operate our business and fund our current and assumed obligations for at least the next 12 months. We expect a slight increase in capital expenditures in fiscal year 2022 as compared to fiscal year 2021. For additional information regarding our cash requirement from contractual obligations, indebtedness and lease obligations, see Note 14. “Commitments and Contingencies”, Note 10. “Borrowings” and Note 6. “Leases” in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-21-000153:mdna:121]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, or unanticipated capital expenditures, our business and financial condition could suffer. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our senior unsecured notes and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to sell additional debt or equity securities for reasons other than those specified above.

[0001730168-21-000153:mdna:122]
In addition, we may, at any time and from time to time, seek to retire or purchase our outstanding debt through cash tenders and/or exchanges for equity or debt, in open-market purchases, privately negotiated transactions or otherwise. Such tenders, exchanges or purchases, if any, will be upon such terms and at such prices as we may determine, and will depend on prevailing market conditions, our liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0001730168-21-000153:mdna:123]
Working Capital

[0001730168-21-000153:mdna:124]
Working capital increased to $10,305 million at October 31, 2021 from $5,524 million at November 1, 2020. The increase was attributable to the following:

[0001730168-21-000153:mdna:125]
•Cash and cash equivalents increased to $12,163 million at October 31, 2021 from $7,618 million at November 1, 2020, primarily due to $13,764 million in net cash provided by operating activities and $9,904 million in proceeds from long-term borrowings, partially offset by $11,495 million of payments on debt obligations, $6,212 million of dividend payments and $1,299 million in payments of employee withholding taxes related to net share settled equity awards. See the “Cash Flows” section below for further details.

[0001730168-21-000153:mdna:126]
•Current portion of long-term debt decreased to $290 million at October 31, 2021 from $827 million at November 1, 2020, primarily as a result of our fiscal year 2021 debt transactions.

[0001730168-21-000153:mdna:127]
•Inventory increased to $1,297 million at October 31, 2021 from $1,003 million at November 1, 2020, primarily due to the timing of customer product ramps.

[0001730168-21-000153:mdna:128]
These increases in working capital were offset in part by the following:

[0001730168-21-000153:mdna:129]
•Accounts payable increased to $1,086 million at October 31, 2021 from $836 million at November 1, 2020, primarily due to the timing of vendor payments.

[0001730168-21-000153:mdna:130]
•Accounts receivable decreased to $2,071 million at October 31, 2021 from $2,297 million at November 1, 2020, primarily due to revenue linearity and additional receivables sold through factoring arrangements.

[0001730168-21-000153:mdna:131]
•Employee compensation and benefits increased to $1,066 million at October 31, 2021 from $877 million at November 1, 2020, primarily due to higher variable compensation based on current fiscal year performance.

[0001730168-21-000153:mdna:132]
Capital Returns

[0001730168-21-000153:mdna:133]
|  |  | Fiscal Year Ended |
| Cash Dividends Declared and Paid |  | October 31, 2021 |  | November 1, 2020 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 14.40 |  |  | $ | 13.00 |  |
| Dividends to common stockholders |  | $ | 5,913 |  |  | $ | 5,235 |  |
| Dividends per share to preferred stockholders |  | $ | 80.00 |  |  | $ | 80.00 |  |
| Dividends to preferred stockholders |  | $ | 299 |  |  | $ | 299 |  |

[0001730168-21-000153:mdna:134]
During fiscal years 2021 and 2020, we paid approximately $1,299 million and $765 million, respectively, in employee withholding taxes due upon the vesting of net settled equity awards. We withheld approximately 3 million shares of common stock from employees in connection with such net share settlements during each of fiscal years 2021 and 2020.

[0001730168-21-000153:mdna:135]
In December 2021, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time on or prior to December 31, 2022. Repurchases under our stock repurchase program may be effected through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities, and other factors. We are not obligated to repurchase any specific amount of shares of common stock, and the stock repurchase program may be suspended or terminated at any time.

[0001730168-21-000153:mdna:136]
Cash Flows

[0001730168-21-000153:mdna:137]
|  |  | Fiscal Year Ended |
|  |  | October 31, 2021 |  | November 1, 2020 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 13,764 |  |  | $ | 12,061 |  |
| Net cash used in investing activities |  | (245) |  |  | (11,109) |  |
| Net cash provided by (used in) financing activities |  | (8,974) |  |  | 1,611 |  |
| Net change in cash and cash equivalents |  | $ | 4,545 |  |  | $ | 2,563 |  |

[0001730168-21-000153:mdna:138]
Operating Activities

[0001730168-21-000153:mdna:139]
Cash provided by operating activities consisted of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $1,703 million increase in cash provided by operations during fiscal year 2021 compared to fiscal year 2020 was due to $3,776 million higher net income, offset by a $1,220 million decrease resulting from changes in operating assets and liabilities, as well as a $853 million decrease in amortization of intangible assets, stock-based compensation, and other adjustments.

[0001730168-21-000153:mdna:140]
Investing Activities

[0001730168-21-000153:mdna:141]
Cash flows from investing activities primarily consisted of cash used for acquisitions, capital expenditures and investments, and proceeds from sales of businesses and assets. The $10,864 million decrease in cash used in investing activities for fiscal year 2021 compared to fiscal year 2020 was primarily related to a $10,864 million decrease in cash paid for acquisitions, partially offset by $173 million less in proceeds received from sales of businesses.

[0001730168-21-000153:mdna:142]
Financing Activities

[0001730168-21-000153:mdna:143]
Cash flows from financing activities primarily consisted of net proceeds and payments related to our long-term borrowings, dividend and distribution payments, stock repurchases and the issuances of stock. The $10,585 million decrease in cash related to financing activities for fiscal year 2021 compared to fiscal year 2020 was primarily due to a $9,294 million decrease in net proceeds from borrowings as a result of debt repayments, and a $678 million increase in dividend payments.

[0001730168-21-000153:mdna:144]
Summarized Obligor Group Financial Information

[0001730168-21-000153:mdna:145]
Pursuant to indentures dated January 19, 2017 and October 17, 2017 (collectively, the “2017 Indentures”), Broadcom Cayman Finance Limited (subsequently merged into Broadcom Technologies Inc. (“BTI”) during fiscal year 2019 with BTI remaining as the surviving entity) and Broadcom Corporation (“BRCM”) (BRCM and BTI collectively, the “2017 Senior Notes Co-Issuers”) issued $13,550 million and $4,000 million aggregate principal amount of notes, respectively (collectively, the “2017 Senior Notes”). Substantially all of the 2017 Senior Notes have been registered with the SEC.

[0001730168-21-000153:mdna:146]
We may redeem all or a portion of our 2017 Senior Notes at any time prior to their maturity, subject to a specified make-whole premium as set forth in the 2017 Indentures. In the event of a change of control triggering event, holders of our 2017 Senior Notes will have the right to require us to purchase for cash, all or a portion of their 2017 Senior Notes at a redemption price of 101% of the aggregate principal amount plus accrued and unpaid interest. The 2017 Indentures also contain covenants that restrict, among other things, the ability of Broadcom and its subsidiaries to incur certain secured debt and to consummate certain sale and leaseback transactions and restrict the ability of Broadcom, BRCM and BTI (collectively,

[0001730168-21-000153:mdna:147]
the “Obligor Group”) to merge, consolidate or sell all or substantially all of their assets.

[0001730168-21-000153:mdna:148]
Broadcom and BTI fully and unconditionally guarantee, jointly and severally, on an unsecured, unsubordinated basis, the 2017 Senior Notes. Because the guarantees are not secured, they are effectively subordinated to any existing and future secured indebtedness of the guarantors to the extent of the value of the collateral securing that indebtedness. The guarantee by Broadcom and BTI will be automatically and unconditionally released upon the sale, exchange, disposition or other transfer of all or substantially all of the assets of such guarantor if any of these events occurs, subject to the terms of the 2017 Indentures. The guarantee by Broadcom (1) will also be automatically and unconditionally released at such time as: (A) the 2017 Senior Notes Co-Issuers, in their sole discretion, determine that such guarantee is no longer required by Rule 3-10(a), as applicable, of Regulation S-X to except the 2017 Senior Notes Co-Issuers’ financial statements from being required to be filed pursuant to Rule 3-10(a) of Regulation S-X or otherwise facilitate a reduction in its financial reporting obligations or (B) either of the 2017 Senior Notes Co-Issuers becomes subject to Section 13 or 15(d) of the Securities Exchange Act of 1934 (“Exchange Act”) and (2) may, at the election of the 2017 Senior Notes Co-Issuers, be unconditionally released at such time as Broadcom is eligible to suspend its reporting obligation under the Exchange Act.

[0001730168-21-000153:mdna:149]
In March 2021, we completed the settlement of our private offers to exchange $5.5 billion of certain of our outstanding notes maturing between 2024 and 2027 (the “Exchange Offer”) for $2,250 million of 3.419% new senior unsecured notes due April 2033 and $3,250 million of 3.469% new senior unsecured notes due April 2034. In connection with the Exchange Offer, BRCM and BTI were automatically and unconditionally released from their guarantees in accordance with the respective indentures governing the January 2021 Senior Notes, the June 2020 Senior Notes, the May 2020 Senior Notes, the April 2020 Senior Notes, and the April 2019 Senior Notes, as defined in Note 10. “Borrowings” included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001730168-21-000153:mdna:150]
The following tables set forth the summarized financial information of the Obligor Group on a combined basis. This summarized financial information excludes any subsidiaries that are not issuers or guarantors (the “Non-Obligor Group”). Intercompany balances and transactions between members of the Obligor Group have been eliminated.

[0001730168-21-000153:mdna:151]
| Summarized Balance Sheet Information |  | October 31,2021 |  |  |
|  |  | (In millions) |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Amount due from Non-Obligor Group |  | $ | 792 |  |  |  |
| Other current assets |  | 7,418 |  |  |  |
| Total current assets |  | $ | 8,210 |  |  |  |
| Long-term assets: |  |  |  |  |
| Amount due from Non-Obligor Group, long-term |  | $ | 4,620 |  |  |  |
| Goodwill |  | 1,380 |  |  |  |
| Other long-term assets |  | 1,376 |  |  |  |
| Total long-term assets |  | $ | 7,376 |  |  |  |
| LIABILITIES |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group |  | $ | 7,412 |  |  |  |
| Current portion of long-term debt |  | 264 |  |  |  |
| Other current liabilities |  | 666 |  |  |  |
| Total current liabilities |  | $ | 8,342 |  |  |  |
| Long-term liabilities: |  |  |  |  |
| Amount due to Non-Obligor Group, long-term |  | $ | 7 |  |  |  |
| Long-term debt |  | 38,998 |  |  |  |
| Other long-term liabilities |  | 2,787 |  |  |  |
| Total long-term liabilities |  | $ | 41,792 |  |  |  |

[0001730168-21-000153:mdna:152]
|  |  | Fiscal Year Ended |
| Summarized Statement of Operations Information |  | October 31,2021 |
|  |  | (In millions) |
| Intercompany revenue with Non-Obligor Group |  | $ | 1,760 |  |
| Intercompany gross margin |  | $ | 1,596 |  |
| Net loss (a) |  | $ | (1,262) |  |

[0001730168-21-000153:mdna:153]
_________________________________

[0001730168-21-000153:mdna:154]
(a) In addition to intercompany gross margin, there were $962 million of intercompany transactions included in net loss.

[0001730168-21-000153:mdna:155]
Accounting Changes and Recent Accounting Standards

[0001730168-21-000153:mdna:156]
For a description of accounting changes and recent accounting standards, including the expected dates of adoption and estimated effects, if any, in our consolidated financial statements, see Note 2. “Summary of Significant Accounting Policies” included in Part II, Item 8. of this Annual Report on Form 10-K.
