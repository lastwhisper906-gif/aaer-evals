# AVGO 8-K — 0001730168-21-000148 filed 2021-12-09

## item codes, every 8-K on or before 2021-12-17

- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2021-12-17

- none on or before 2021-12-17

## item 2.02 — earnings release, exhibit 99.1

[0001730168-21-000148:8k_2_02:1]
EX-99.1
2
avgo-10312021x8kxex99.htm
EX-99.1

[0001730168-21-000148:8k_2_02:2]
Document

[0001730168-21-000148:8k_2_02:3]
Exhibit 99.1

[0001730168-21-000148:8k_2_02:4]
Broadcom Inc. Announces Fourth Quarter and Fiscal Year 2021 Financial Results and Quarterly Dividends

[0001730168-21-000148:8k_2_02:5]
•Revenue of $7,407 million for the fourth quarter, up 15 percent from the prior year period

[0001730168-21-000148:8k_2_02:6]
•GAAP net income of $1,989 million for the fourth quarter; Adjusted EBITDA of $4,547 million for the fourth quarter

[0001730168-21-000148:8k_2_02:7]
•GAAP diluted EPS of $4.45 for the fourth quarter; Non-GAAP diluted EPS of $7.81 for the fourth quarter

[0001730168-21-000148:8k_2_02:8]
•$3,453 million of free cash flow from operations for the fourth quarter, defined as cash from operations of $3,541 million less capital expenditures of $88 million

[0001730168-21-000148:8k_2_02:9]
•First quarter revenue guidance of approximately $7.6 billion, an expected increase of 14 percent from the prior year period

[0001730168-21-000148:8k_2_02:10]
•First quarter Adjusted EBITDA guidance of approximately 61.5 percent of projected revenue (1)

[0001730168-21-000148:8k_2_02:11]
•Quarterly common stock dividend increased by 14 percent to $4.10 per share from the prior quarter

[0001730168-21-000148:8k_2_02:12]
•New share repurchase program authorized for repurchase of up to $10 billion of common stock

[0001730168-21-000148:8k_2_02:13]
SAN JOSE, Calif. – December 9, 2021 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its fourth quarter and fiscal year 2021, ended October 31, 2021, provided guidance for the first quarter of its fiscal year 2022 and announced its quarterly dividends.

[0001730168-21-000148:8k_2_02:14]
“Broadcom concluded the year with record fourth quarter results driven by a rebound in enterprise, and continued strength from cloud and service provider demand. Our infrastructure software growth continues to be steady with our focus on strategic customers,” said Hock Tan, President and CEO of Broadcom Inc. “With the strength and breadth of our IP portfolio, we continue to be able to uniquely deliver leading edge, best-in-class semiconductor solutions, and extend our leadership in our franchise markets.”

[0001730168-21-000148:8k_2_02:15]
“In fiscal 2021, we achieved record adjusted EBITDA margin of 60%, generating $13.3 billion of free cash flow, or 49% of revenue,” said Kirsten Spears, CFO of Broadcom Inc. “Consistent with our commitment to return excess cash to shareholders, we are increasing our target quarterly common stock dividend by 14 percent to $4.10 per share per quarter for fiscal year 2022, and announcing a new $10 billion share repurchase program.”

[0001730168-21-000148:8k_2_02:16]
Fourth Quarter Fiscal Year 2021 Financial Highlights

[0001730168-21-000148:8k_2_02:17]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q4 21 |  | Q4 20 |  | Change |  | Q4 21 |  | Q4 20 |  | Change |
| Net revenue |  | $ | 7,407 |  |  | $ | 6,467 |  |  | +15 | % |  | $ | 7,407 |  |  | $ | 6,467 |  |  | +15 | % |
| Net income |  | $ | 1,989 |  |  | $ | 1,324 |  |  | +$665 |  |  | $ | 3,501 |  |  | $ | 2,865 |  |  | +$636 |  |
| Earnings per common share - diluted |  | $ | 4.45 |  |  | $ | 2.93 |  |  | +$1.52 |  |  | $ | 7.81 |  |  | $ | 6.35 |  |  | +$1.46 |  |

[0001730168-21-000148:8k_2_02:18]
________________________________

[0001730168-21-000148:8k_2_02:19]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-21-000148:8k_2_02:20]
1

[0001730168-21-000148:8k_2_02:21]
| (Dollars in millions) |  | Q4 21 |  | Q4 20 |  | Change |  |
| Cash flow from operations |  | $ | 3,541 |  |  | $ | 3,348 |  |  | +$193 |  |
| Adjusted EBITDA |  | $ | 4,547 |  |  | $ | 3,827 |  |  | +$720 |  |
| Free cash flow |  | $ | 3,453 |  |  | $ | 3,246 |  |  | +$207 |  |

[0001730168-21-000148:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q4 21 |  |  |  | Q4 20 |  | Change |  |
| Semiconductor solutions |  | $ | 5,634 |  |  | 76 | % |  |  |  |  |  |  | $ | 4,830 |  |  | 75 | % |  | +17 | % |  |
| Infrastructure software |  | 1,773 |  |  | 24 |  |  |  |  |  |  |  | 1,637 |  |  | 25 |  |  | +8 | % |  |
| Total net revenue |  | $ | 7,407 |  |  | 100 | % |  |  |  |  |  |  | $ | 6,467 |  |  | 100 | % |  |  |  |  |

[0001730168-21-000148:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $12,163 million, compared to $11,105 million at the end of the prior quarter.

[0001730168-21-000148:8k_2_02:24]
During the fourth fiscal quarter, the Company generated $3,541 million in cash from operations and spent $88 million on capital expenditures.

[0001730168-21-000148:8k_2_02:25]
On September 30, 2021, the Company paid a cash dividend of $3.60 per share of common stock, totaling $1,486 million and a cash dividend of $20.00 per share of mandatory convertible preferred stock, totaling $75 million.

[0001730168-21-000148:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below, and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-21-000148:8k_2_02:27]
Fiscal Year 2021 Financial Highlights

[0001730168-21-000148:8k_2_02:28]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | FY 21 |  | FY 20 |  | Change |  | FY 21 |  | FY 20 |  | Change |
| Net revenue |  | $ | 27,450 |  |  | $ | 23,888 |  |  | +15 | % |  | $ | 27,450 |  |  | $ | 23,888 |  |  | +15 | % |
| Net income |  | $ | 6,736 |  |  | $ | 2,960 |  |  | +$3,776 |  |  | $ | 12,578 |  |  | $ | 9,993 |  |  | +$2,585 |  |
| Earnings per common share - diluted |  | $ | 15.00 |  |  | $ | 6.33 |  |  | +$8.67 |  |  | $ | 28.01 |  |  | $ | 22.16 |  |  | +$5.85 |  |

[0001730168-21-000148:8k_2_02:29]
| (Dollars in millions) |  | FY 21 |  | FY 20 |  | Change |  |
| Cash flow from operations |  | $ | 13,764 |  |  | $ | 12,061 |  |  | +$1,703 |  |
| Adjusted EBITDA |  | $ | 16,571 |  |  | $ | 13,643 |  |  | +$2,928 |  |
| Free cash flow |  | $ | 13,321 |  |  | $ | 11,598 |  |  | +$1,723 |  |

[0001730168-21-000148:8k_2_02:30]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | FY 21 |  | FY 20 |  | Change |  |
| Semiconductor solutions |  | $ | 20,383 |  |  | 74 | % |  | $ | 17,267 |  |  | 72 | % |  | +18 | % |  |
| Infrastructure software |  | 7,067 |  |  | 26 |  |  | 6,621 |  |  | 28 |  |  | +7 | % |  |
| Total net revenue |  | $ | 27,450 |  |  | 100 | % |  | $ | 23,888 |  |  | 100 | % |  |  |  |  |

[0001730168-21-000148:8k_2_02:31]
2

[0001730168-21-000148:8k_2_02:32]
First Quarter Fiscal Year 2022 Business Outlook

[0001730168-21-000148:8k_2_02:33]
Based on current business trends and conditions, the outlook for the first quarter of fiscal year 2022, ending January 30, 2022, is expected to be as follows:

[0001730168-21-000148:8k_2_02:34]
•First quarter revenue guidance of approximately $7.6 billion; and

[0001730168-21-000148:8k_2_02:35]
•First quarter Adjusted EBITDA guidance of approximately 61.5 percent of projected revenue.

[0001730168-21-000148:8k_2_02:36]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000148:8k_2_02:37]
Quarterly Dividends

[0001730168-21-000148:8k_2_02:38]
The Company’s Board of Directors has approved a quarterly cash dividend on its common stock of $4.10 per share. The common stock dividend is payable on December 31, 2021 to common stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 22, 2021.

[0001730168-21-000148:8k_2_02:39]
The Company’s Board of Directors has also approved a quarterly cash dividend on its 8.00% Mandatory Convertible Preferred Stock, Series A, of $20.00 per share. This dividend is payable on December 31, 2021 to preferred stockholders of record at the close of business (5:00 p.m. Eastern Time) on December 15, 2021.

[0001730168-21-000148:8k_2_02:40]
Share Repurchase Authorization

[0001730168-21-000148:8k_2_02:41]
The Company’s Board of Directors has authorized the repurchase of up to $10 billion of its common stock under a new share repurchase program. The authorization is effective until December 31, 2022. Repurchases under the new share repurchase program may be made through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. Broadcom is not obligated to repurchase any specific amount of shares of common stock, and the share repurchase program may be suspended or terminated at any time.

[0001730168-21-000148:8k_2_02:42]
Financial Results Conference Call

[0001730168-21-000148:8k_2_02:43]
Broadcom Inc. will host a conference call to review its financial results for the fourth quarter and fiscal year 2021 and to discuss the business outlook, today at 2:00 p.m. Pacific Time.

[0001730168-21-000148:8k_2_02:44]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-21-000148:8k_2_02:45]
3

[0001730168-21-000148:8k_2_02:46]
To Listen via Telephone: Preregistration is required by the conference call operator. Please preregister at: http://www.directeventreg.com/registration/event/3991413. Upon registering, you will be emailed a dial-in number, direct passcode and unique PIN.

[0001730168-21-000148:8k_2_02:47]
Replay: A telephone playback of the conference call can be accessed for one week following the call by dialing: (855) 859-2056; International + 1 (404) 537-3406; Passcode: 3991413; or through the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-21-000148:8k_2_02:48]
Non-GAAP Financial Measures

[0001730168-21-000148:8k_2_02:49]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-21-000148:8k_2_02:50]
In addition to GAAP reporting, Broadcom provides investors with net revenue, net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring, impairment and disposal charges, acquisition-related costs, including integration costs, purchase accounting effect on inventory, litigation settlements, loss on debt extinguishment, gains (losses) on investments, income (loss) from discontinued operations, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-21-000148:8k_2_02:51]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-21-000148:8k_2_02:52]
About Broadcom Inc.

[0001730168-21-000148:8k_2_02:53]
Broadcom Inc. (NASDAQ: AVGO) is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Broadcom's category-leading product portfolio serves critical markets including data center, networking, enterprise software, broadband, wireless, storage and industrial. Our solutions include data center networking and storage,

[0001730168-21-000148:8k_2_02:54]
4

[0001730168-21-000148:8k_2_02:55]
enterprise, mainframe and cyber security software focused on automation, monitoring and security, smartphone components, telecoms and factory automation. For more information, go to https://www.broadcom.com.

[0001730168-21-000148:8k_2_02:56]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-21-000148:8k_2_02:57]
Particular uncertainties that could materially affect future results include risks associated with: the COVID-19 pandemic, which has disrupted, and will likely continue to disrupt, normal business activity, and which may have an adverse effect on our results of operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; government regulations and administrative proceedings, trade restrictions and trade tensions; global economic conditions and concerns; cyclicality in the semiconductor industry or in our target markets; global political and economic conditions; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase program; dependence on and risks associated with distributors and resellers of our products; dependence on senior management and our ability to attract and retain qualified personnel; any acquisitions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; quarterly and annual fluctuations in operating results; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our competitive performance and ability to continue achieving design wins with our customers, as well as the timing of any design wins; prolonged disruptions of our or our contract manufacturers’ manufacturing facilities, warehouses or other significant operations; our ability to improve our manufacturing efficiency and quality; our dependence on outsourced service providers for certain key business services and their ability to execute to our requirements; our ability to maintain or improve gross margin; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; availability of third party software used in our products; use of open source code sources in our products; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims; market acceptance of the end products into which our products are designed; our

[0001730168-21-000148:8k_2_02:58]
5

[0001730168-21-000148:8k_2_02:59]
ability to sell to new types of customers and to keep pace with technological advances; our compliance with privacy and data security laws; our ability to protect against a breach of security systems; fluctuations in foreign exchange rates; our provision for income taxes and overall cash tax costs, legislation that may impact our overall cash tax costs and our ability to maintain tax concessions in certain jurisdictions; and other events and trends on a national, regional and global scale, including those of a political, economic, business, competitive and regulatory nature. Many of the foregoing risks and uncertainties are, and will be, exacerbated by the COVID-19 pandemic and any worsening of the global business and economic environment as a result.

[0001730168-21-000148:8k_2_02:60]
Our filings with the SEC, which you may obtain for free at the SEC’s website at http://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-21-000148:8k_2_02:61]
Contact:

[0001730168-21-000148:8k_2_02:62]
Ji Yoo

[0001730168-21-000148:8k_2_02:63]
Broadcom Inc.

[0001730168-21-000148:8k_2_02:64]
Investor Relations

[0001730168-21-000148:8k_2_02:65]
408-433-8000

[0001730168-21-000148:8k_2_02:66]
investor.relations@broadcom.com

[0001730168-21-000148:8k_2_02:67]
(AVGO-Q)

[0001730168-21-000148:8k_2_02:68]
6

[0001730168-21-000148:8k_2_02:69]
BROADCOM INC.

[0001730168-21-000148:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-21-000148:8k_2_02:71]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-21-000148:8k_2_02:72]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 31,2021 |  | August 1,2021 |  | November 1,2020 |  | October 31,2021 |  | November 1,2020 |
| Net revenue |  | $ | 7,407 |  |  | $ | 6,778 |  |  | $ | 6,467 |  |  | $ | 27,450 |  |  | $ | 23,888 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 1,920 |  |  | 1,729 |  |  | 1,753 |  |  | 7,162 |  |  | 6,518 |  |
| Amortization of acquisition-related intangible assets |  | 849 |  |  | 851 |  |  | 962 |  |  | 3,427 |  |  | 3,819 |  |
| Restructuring charges |  | — |  |  | 1 |  |  | 5 |  |  | 17 |  |  | 35 |  |
| Total cost of revenue |  | 2,769 |  |  | 2,581 |  |  | 2,720 |  |  | 10,606 |  |  | 10,372 |  |
| Gross margin |  | 4,638 |  |  | 4,197 |  |  | 3,747 |  |  | 16,844 |  |  | 13,516 |  |
| Research and development |  | 1,200 |  |  | 1,205 |  |  | 1,182 |  |  | 4,854 |  |  | 4,968 |  |
| Selling, general and administrative |  | 337 |  |  | 346 |  |  | 405 |  |  | 1,347 |  |  | 1,935 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 599 |  |  | 1,976 |  |  | 2,401 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 26 |  |  | 35 |  |  | 148 |  |  | 198 |  |
| Total operating expenses |  | 2,057 |  |  | 2,071 |  |  | 2,221 |  |  | 8,325 |  |  | 9,502 |  |
| Operating income |  | 2,581 |  |  | 2,126 |  |  | 1,526 |  |  | 8,519 |  |  | 4,014 |  |
| Interest expense |  | (434) |  |  | (415) |  |  | (420) |  |  | (1,885) |  |  | (1,777) |  |
| Other income, net |  | 22 |  |  | 15 |  |  | 31 |  |  | 131 |  |  | 206 |  |
| Income from continuing operations before income taxes |  | 2,169 |  |  | 1,726 |  |  | 1,137 |  |  | 6,765 |  |  | 2,443 |  |
| Provision for (benefit from) income taxes |  | 180 |  |  | (150) |  |  | (187) |  |  | 29 |  |  | (518) |  |
| Income from continuing operations |  | 1,989 |  |  | 1,876 |  |  | 1,324 |  |  | 6,736 |  |  | 2,961 |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |
| Net income |  | 1,989 |  |  | 1,876 |  |  | 1,324 |  |  | 6,736 |  |  | 2,960 |  |
| Dividends on preferred stock |  | (75) |  |  | (74) |  |  | (74) |  |  | (299) |  |  | (297) |  |
| Net income attributable to common stock |  | $ | 1,914 |  |  | $ | 1,802 |  |  | $ | 1,250 |  |  | $ | 6,437 |  |  | $ | 2,663 |  |
| Basic income per share attributable to common stock: |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.65 |  |  | $ | 4.38 |  |  | $ | 3.09 |  |  | $ | 15.70 |  |  | $ | 6.62 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income per share |  | $ | 4.65 |  |  | $ | 4.38 |  |  | $ | 3.09 |  |  | $ | 15.70 |  |  | $ | 6.62 |  |
| Diluted income per share attributable to common stock (1): |  |  |  |  |  |  |  |  |  |  |
| Income per share from continuing operations |  | $ | 4.45 |  |  | $ | 4.20 |  |  | $ | 2.93 |  |  | $ | 15.00 |  |  | $ | 6.33 |  |
| Loss per share from discontinued operations |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income per share |  | $ | 4.45 |  |  | $ | 4.20 |  |  | $ | 2.93 |  |  | $ | 15.00 |  |  | $ | 6.33 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 412 |  |  | 411 |  |  | 405 |  |  | 410 |  |  | 402 |  |
| Diluted |  | 430 |  |  | 429 |  |  | 426 |  |  | 429 |  |  | 421 |  |
| Stock-based compensation expense included in continuing operations: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 37 |  |  | $ | 36 |  |  | $ | 38 |  |  | $ | 143 |  |  | $ | 159 |  |
| Research and development |  | 279 |  |  | 285 |  |  | 318 |  |  | 1,199 |  |  | 1,419 |  |
| Selling, general and administrative |  | 98 |  |  | 100 |  |  | 93 |  |  | 362 |  |  | 398 |  |
| Total stock-based compensation expense |  | $ | 414 |  |  | $ | 421 |  |  | $ | 449 |  |  | $ | 1,704 |  |  | $ | 1,976 |  |
| (1) Excludes the potentially dilutive effect of Mandatory Convertible Preferred Stock as the impact was antidilutive. |

[0001730168-21-000148:8k_2_02:73]
BROADCOM INC.

[0001730168-21-000148:8k_2_02:74]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-21-000148:8k_2_02:75]
(IN MILLIONS)

[0001730168-21-000148:8k_2_02:76]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 31,2021 |  | August 1,2021 |  | November 1,2020 |  | October 31,2021 |  | November 1,2020 |
| Gross margin on GAAP basis |  | $ | 4,638 |  |  | $ | 4,197 |  |  | $ | 3,747 |  |  | $ | 16,844 |  |  | $ | 13,516 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 849 |  |  | 851 |  |  | 962 |  |  | 3,427 |  |  | 3,819 |  |
| Stock-based compensation expense |  | 37 |  |  | 36 |  |  | 38 |  |  | 143 |  |  | 159 |  |
| Restructuring charges |  | — |  |  | 1 |  |  | 5 |  |  | 17 |  |  | 35 |  |
| Acquisition-related costs |  | 3 |  |  | 3 |  |  | 6 |  |  | 12 |  |  | 12 |  |
| Gross margin on non-GAAP basis |  | $ | 5,527 |  |  | $ | 5,088 |  |  | $ | 4,758 |  |  | $ | 20,443 |  |  | $ | 17,552 |  |
| Research and development on GAAP basis |  | $ | 1,200 |  |  | $ | 1,205 |  |  | $ | 1,182 |  |  | $ | 4,854 |  |  | $ | 4,968 |  |
| Stock-based compensation expense |  | 279 |  |  | 285 |  |  | 318 |  |  | 1,199 |  |  | 1,419 |  |
| Acquisition-related costs |  | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 14 |  |
| Research and development on non-GAAP basis |  | $ | 921 |  |  | $ | 919 |  |  | $ | 863 |  |  | $ | 3,652 |  |  | $ | 3,535 |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 337 |  |  | $ | 346 |  |  | $ | 405 |  |  | $ | 1,347 |  |  | $ | 1,935 |  |
| Stock-based compensation expense |  | 98 |  |  | 100 |  |  | 93 |  |  | 362 |  |  | 398 |  |
| Acquisition-related costs |  | 17 |  |  | 22 |  |  | 60 |  |  | 105 |  |  | 396 |  |
| Litigation settlements |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 63 |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 222 |  |  | $ | 223 |  |  | $ | 252 |  |  | $ | 879 |  |  | $ | 1,078 |  |
| Total operating expenses on GAAP basis |  | $ | 2,057 |  |  | $ | 2,071 |  |  | $ | 2,221 |  |  | $ | 8,325 |  |  | $ | 9,502 |  |
| Amortization of acquisition-related intangible assets |  | 494 |  |  | 494 |  |  | 599 |  |  | 1,976 |  |  | 2,401 |  |
| Stock-based compensation expense |  | 377 |  |  | 385 |  |  | 411 |  |  | 1,561 |  |  | 1,817 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 26 |  |  | 35 |  |  | 148 |  |  | 198 |  |
| Litigation settlements |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 17 |  |  | 23 |  |  | 61 |  |  | 108 |  |  | 410 |  |
| Total operating expenses on non-GAAP basis |  | $ | 1,143 |  |  | $ | 1,142 |  |  | $ | 1,115 |  |  | $ | 4,531 |  |  | $ | 4,613 |  |
| Operating income on GAAP basis |  | $ | 2,581 |  |  | $ | 2,126 |  |  | $ | 1,526 |  |  | $ | 8,519 |  |  | $ | 4,014 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,343 |  |  | 1,345 |  |  | 1,561 |  |  | 5,403 |  |  | 6,220 |  |
| Stock-based compensation expense |  | 414 |  |  | 421 |  |  | 449 |  |  | 1,704 |  |  | 1,976 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 27 |  |  | 40 |  |  | 165 |  |  | 233 |  |
| Litigation settlements |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 20 |  |  | 26 |  |  | 67 |  |  | 120 |  |  | 422 |  |
| Operating income on non-GAAP basis |  | $ | 4,384 |  |  | $ | 3,946 |  |  | $ | 3,643 |  |  | $ | 15,912 |  |  | $ | 12,939 |  |
| Interest expense on GAAP basis |  | $ | (434) |  |  | $ | (415) |  |  | $ | (420) |  |  | $ | (1,885) |  |  | $ | (1,777) |  |
| Loss on debt extinguishment |  | 23 |  |  | — |  |  | 16 |  |  | 245 |  |  | 169 |  |
| Interest expense on non-GAAP basis |  | $ | (411) |  |  | $ | (415) |  |  | $ | (404) |  |  | $ | (1,640) |  |  | $ | (1,608) |  |
| Other income, net on GAAP basis |  | $ | 22 |  |  | $ | 15 |  |  | $ | 31 |  |  | $ | 131 |  |  | $ | 206 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | (9) |  |  | 4 |  |  | (10) |  |  | (99) |  |  | (31) |  |
| Gain from sale of business |  | (8) |  |  | — |  |  | — |  |  | (8) |  |  | (23) |  |
| Acquisition-related gain |  | — |  |  | — |  |  | (4) |  |  | (3) |  |  | (11) |  |
| Other income, net on non-GAAP basis |  | $ | 5 |  |  | $ | 19 |  |  | $ | 17 |  |  | $ | 21 |  |  | $ | 25 |  |

[0001730168-21-000148:8k_2_02:77]
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 31,2021 |  | August 1,2021 |  | November 1,2020 |  | October 31,2021 |  | November 1,2020 |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 180 |  |  | $ | (150) |  |  | $ | (187) |  |  | $ | 29 |  |  | $ | (518) |  |
| Non-GAAP tax reconciling adjustments |  | 297 |  |  | 576 |  |  | 578 |  |  | 1,686 |  |  | 1,881 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 477 |  |  | $ | 426 |  |  | $ | 391 |  |  | $ | 1,715 |  |  | $ | 1,363 |  |
| Net income on GAAP basis |  | $ | 1,989 |  |  | $ | 1,876 |  |  | $ | 1,324 |  |  | $ | 6,736 |  |  | $ | 2,960 |  |
| Purchase accounting effect on inventory |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Amortization of acquisition-related intangible assets |  | 1,343 |  |  | 1,345 |  |  | 1,561 |  |  | 5,403 |  |  | 6,220 |  |
| Stock-based compensation expense |  | 414 |  |  | 421 |  |  | 449 |  |  | 1,704 |  |  | 1,976 |  |
| Restructuring, impairment and disposal charges |  | 26 |  |  | 27 |  |  | 40 |  |  | 165 |  |  | 233 |  |
| Litigation settlements |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | 63 |  |
| Acquisition-related costs |  | 20 |  |  | 26 |  |  | 63 |  |  | 117 |  |  | 411 |  |
| Loss on debt extinguishment |  | 23 |  |  | — |  |  | 16 |  |  | 245 |  |  | 169 |  |
| Gain from lapse of indemnification |  | — |  |  | — |  |  | — |  |  | — |  |  | (116) |  |
| (Gains) losses on investments |  | (9) |  |  | 4 |  |  | (10) |  |  | (99) |  |  | (31) |  |
| Gain from sale of business |  | (8) |  |  | — |  |  | — |  |  | (8) |  |  | (23) |  |
| Non-GAAP tax reconciling adjustments |  | (297) |  |  | (576) |  |  | (578) |  |  | (1,686) |  |  | (1,881) |  |
| Loss from discontinued operations, net of income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Net income on non-GAAP basis |  | $ | 3,501 |  |  | $ | 3,124 |  |  | $ | 2,865 |  |  | $ | 12,578 |  |  | $ | 9,993 |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 430 |  |  | 429 |  |  | 426 |  |  | 429 |  |  | 421 |  |
| Non-GAAP adjustment (1) |  | 18 |  |  | 20 |  |  | 25 |  |  | 20 |  |  | 30 |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 448 |  |  | 449 |  |  | 451 |  |  | 449 |  |  | 451 |  |
| Net income on non-GAAP basis |  | $ | 3,501 |  |  | $ | 3,124 |  |  | $ | 2,865 |  |  | $ | 12,578 |  |  | $ | 9,993 |  |
| Interest expense on non-GAAP basis |  | 411 |  |  | 415 |  |  | 404 |  |  | 1,640 |  |  | 1,608 |  |
| Provision for income taxes on non-GAAP basis |  | 477 |  |  | 426 |  |  | 391 |  |  | 1,715 |  |  | 1,363 |  |
| Depreciation |  | 134 |  |  | 134 |  |  | 139 |  |  | 539 |  |  | 570 |  |
| Amortization of purchased intangibles and right-of-use assets |  | 24 |  |  | 24 |  |  | 28 |  |  | 99 |  |  | 109 |  |
| Adjusted EBITDA |  | $ | 4,547 |  |  | $ | 4,123 |  |  | $ | 3,827 |  |  | $ | 16,571 |  |  | $ | 13,643 |  |
| Net cash provided by operating activities |  | $ | 3,541 |  |  | $ | 3,541 |  |  | $ | 3,348 |  |  | $ | 13,764 |  |  | $ | 12,061 |  |
| Purchases of property, plant and equipment |  | (88) |  |  | (115) |  |  | (102) |  |  | (443) |  |  | (463) |  |
| Free cash flow |  | $ | 3,453 |  |  | $ | 3,426 |  |  | $ | 3,246 |  |  | $ | 13,321 |  |  | $ | 11,598 |  |

[0001730168-21-000148:8k_2_02:78]
|  |  | Fiscal Quarter Ending |
|  |  | January 30, |
| Expected average diluted share count (2): |  | 2022 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 430 |  |
| Non-GAAP adjustment (1) |  | 18 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 448 |  |

[0001730168-21-000148:8k_2_02:79]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. In addition, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is antidilutive on a GAAP basis. For the fiscal quarter ending January 30, 2022, the non-GAAP adjustment includes the impact of Mandatory Convertible Preferred Stock that is expected to be antidilutive on a GAAP basis. |
| (2) Excludes the effects of potential share repurchases. |

[0001730168-21-000148:8k_2_02:80]
BROADCOM INC.

[0001730168-21-000148:8k_2_02:81]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-21-000148:8k_2_02:82]
(IN MILLIONS)

[0001730168-21-000148:8k_2_02:83]
|  |  | October 31,2021 |  | November 1,2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 12,163 |  |  | $ | 7,618 |  |
| Trade accounts receivable, net |  | 2,071 |  |  | 2,297 |  |
| Inventory |  | 1,297 |  |  | 1,003 |  |
| Other current assets |  | 1,055 |  |  | 977 |  |
| Total current assets |  | 16,586 |  |  | 11,895 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,348 |  |  | 2,509 |  |
| Goodwill |  | 43,450 |  |  | 43,447 |  |
| Intangible assets, net |  | 11,374 |  |  | 16,782 |  |
| Other long-term assets |  | 1,812 |  |  | 1,300 |  |
| Total assets |  | $ | 75,570 |  |  | $ | 75,933 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 1,086 |  |  | $ | 836 |  |
| Employee compensation and benefits |  | 1,066 |  |  | 877 |  |
| Current portion of long-term debt |  | 290 |  |  | 827 |  |
| Other current liabilities |  | 3,839 |  |  | 3,831 |  |
| Total current liabilities |  | 6,281 |  |  | 6,371 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 39,440 |  |  | 40,235 |  |
| Other long-term liabilities |  | 4,860 |  |  | 5,426 |  |
| Total liabilities |  | 50,581 |  |  | 52,032 |  |
| Preferred stock dividend obligation |  | 27 |  |  | 27 |  |
| Stockholders' equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common stock |  | — |  |  | — |  |
| Additional paid-in capital |  | 24,330 |  |  | 23,982 |  |
| Retained earnings |  | 748 |  |  | — |  |
| Accumulated other comprehensive loss |  | (116) |  |  | (108) |  |
| Total stockholders' equity |  | 24,962 |  |  | 23,874 |  |
| Total liabilities and equity |  | $ | 75,570 |  |  | $ | 75,933 |  |

[0001730168-21-000148:8k_2_02:84]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Fiscal Year Ended |
|  |  | October 31,2021 |  | August 1,2021 |  | November 1,2020 |  | October 31,2021 |  | November 1,2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,989 |  |  | $ | 1,876 |  |  | $ | 1,324 |  |  | $ | 6,736 |  |  | $ | 2,960 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 1,367 |  |  | 1,369 |  |  | 1,589 |  |  | 5,502 |  |  | 6,335 |  |
| Depreciation |  | 134 |  |  | 134 |  |  | 139 |  |  | 539 |  |  | 570 |  |
| Stock-based compensation |  | 414 |  |  | 421 |  |  | 449 |  |  | 1,704 |  |  | 1,976 |  |
| Deferred taxes and other non-cash taxes |  | (47) |  |  | (436) |  |  | (459) |  |  | (809) |  |  | (1,142) |  |
| Loss on debt extinguishment |  | — |  |  | — |  |  | 16 |  |  | 198 |  |  | 169 |  |
| (Gains) losses on investments |  | (9) |  |  | 4 |  |  | — |  |  | (99) |  |  | — |  |
| Non-cash restructuring, impairment and disposal charges |  | 3 |  |  | 8 |  |  | 12 |  |  | 38 |  |  | 44 |  |
| Non-cash interest expense |  | 29 |  |  | 24 |  |  | 25 |  |  | 96 |  |  | 108 |  |
| Other |  | (6) |  |  | — |  |  | (9) |  |  | (14) |  |  | (52) |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | 160 |  |  | 191 |  |  | 391 |  |  | 210 |  |  | 981 |  |
| Inventory |  | (137) |  |  | (156) |  |  | 67 |  |  | (294) |  |  | (31) |  |
| Accounts payable |  | 101 |  |  | 156 |  |  | (230) |  |  | 243 |  |  | (3) |  |
| Employee compensation and benefits |  | 172 |  |  | 254 |  |  | 142 |  |  | 186 |  |  | 217 |  |
| Other current assets and current liabilities |  | (540) |  |  | (227) |  |  | (131) |  |  | (177) |  |  | 331 |  |
| Other long-term assets and long-term liabilities |  | (89) |  |  | (77) |  |  | 23 |  |  | (295) |  |  | (402) |  |
| Net cash provided by operating activities |  | 3,541 |  |  | 3,541 |  |  | 3,348 |  |  | 13,764 |  |  | 12,061 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (8) |  |  | (10,872) |  |
| Proceeds from sales of businesses |  | 45 |  |  | — |  |  | — |  |  | 45 |  |  | 218 |  |
| Purchases of property, plant and equipment |  | (88) |  |  | (115) |  |  | (102) |  |  | (443) |  |  | (463) |  |
| Proceeds from disposals of property, plant and equipment |  | — |  |  | 1 |  |  | 2 |  |  | 4 |  |  | 12 |  |
| Proceeds from sales of investments |  | 102 |  |  | 67 |  |  | — |  |  | 169 |  |  | — |  |
| Other |  | (9) |  |  | — |  |  | — |  |  | (12) |  |  | (4) |  |
| Net cash provided by (used in) investing activities |  | 50 |  |  | (47) |  |  | (100) |  |  | (245) |  |  | (11,109) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | — |  |  | — |  |  | 9,904 |  |  | 27,802 |  |
| Payments on debt obligations |  | (762) |  |  | — |  |  | (3,000) |  |  | (11,495) |  |  | (18,814) |  |
| Other borrowings, net |  | — |  |  | — |  |  | — |  |  | — |  |  | (1,285) |  |
| Payments of dividends |  | (1,561) |  |  | (1,556) |  |  | (1,395) |  |  | (6,212) |  |  | (5,534) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | (266) |  |  | (347) |  |  | (185) |  |  | (1,299) |  |  | (765) |  |
| Issuance of common stock |  | 57 |  |  | 7 |  |  | 102 |  |  | 170 |  |  | 276 |  |
| Other |  | (1) |  |  | (11) |  |  | (9) |  |  | (42) |  |  | (69) |  |
| Net cash provided by (used in) financing activities |  | (2,533) |  |  | (1,907) |  |  | (4,487) |  |  | (8,974) |  |  | 1,611 |  |
| Net change in cash and cash equivalents |  | 1,058 |  |  | 1,587 |  |  | (1,239) |  |  | 4,545 |  |  | 2,563 |  |
| Cash and cash equivalents at beginning of period |  | 11,105 |  |  | 9,518 |  |  | 8,857 |  |  | 7,618 |  |  | 5,055 |  |
| Cash and cash equivalents at end of period |  | $ | 12,163 |  |  | $ | 11,105 |  |  | $ | 7,618 |  |  | $ | 12,163 |  |  | $ | 7,618 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 571 |  |  | $ | 253 |  |  | $ | 383 |  |  | $ | 1,565 |  |  | $ | 1,408 |  |
| Cash paid for income taxes |  | $ | 168 |  |  | $ | 167 |  |  | $ | 202 |  |  | $ | 775 |  |  | $ | 501 |  |
