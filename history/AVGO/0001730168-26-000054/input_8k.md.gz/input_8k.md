# AVGO 8-K — 0001730168-26-000051 filed 2026-06-03

## item codes, every 8-K on or before 2026-06-09

- 2026-06-03 0001730168-26-000051 — 2.02, 8.01, 9.01
- 2026-04-21 0001730168-26-000039 — 5.07
- 2026-04-06 0001193125-26-144028 — 8.01
- 2026-04-02 0001193125-26-140574 — 5.02
- 2026-03-04 0001730168-26-000011 — 2.02, 8.01, 9.01
- 2026-03-02 0001193125-26-085656 — 5.02
- 2026-01-13 0001193125-26-011731 — 8.01, 9.01
- 2025-12-11 0001730168-25-000116 — 2.02, 8.01, 9.01
- 2025-09-29 0001193125-25-223202 — 8.01, 9.01
- 2025-09-10 0001193125-25-200108 — 8.01, 9.01
- 2025-09-09 0001193125-25-199281 — 5.02, 9.01
- 2025-09-04 0001730168-25-000094 — 2.02, 8.01, 9.01
- 2025-07-11 0001193125-25-158202 — 1.02, 8.01, 9.01
- 2025-06-05 0001730168-25-000061 — 2.02, 8.01, 9.01
- 2025-04-22 0001730168-25-000037 — 5.07
- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2026-06-09

- none on or before 2026-06-09

## item 2.02 — earnings release, exhibit 99.1

[0001730168-26-000051:8k_2_02:1]
EX-99.1
2
avgo-05032026x8kxex99.htm
EX-99.1

[0001730168-26-000051:8k_2_02:2]
Document

[0001730168-26-000051:8k_2_02:3]
Exhibit 99.1

[0001730168-26-000051:8k_2_02:4]
Broadcom Inc. Announces Second Quarter Fiscal Year 2026 Financial Results and Quarterly Dividend

[0001730168-26-000051:8k_2_02:5]
•Revenue of $22,187 million for the second quarter, up 48 percent from the prior year period

[0001730168-26-000051:8k_2_02:6]
•GAAP net income of $9,310 million for the second quarter; Non-GAAP net income of $12,074 million for the second quarter

[0001730168-26-000051:8k_2_02:7]
•Adjusted EBITDA of $15,244 million for the second quarter, or 69 percent of revenue

[0001730168-26-000051:8k_2_02:8]
•GAAP diluted EPS of $1.91 for the second quarter; Non-GAAP diluted EPS of $2.44 for the second quarter

[0001730168-26-000051:8k_2_02:9]
•Cash from operations of $10,493 million for the second quarter, less capital expenditures of $231 million, resulted in $10,262 million of free cash flow, or 46 percent of revenue

[0001730168-26-000051:8k_2_02:10]
•Quarterly common stock dividend of $0.65 per share

[0001730168-26-000051:8k_2_02:11]
•Third quarter fiscal year 2026 revenue guidance of approximately $29.4 billion, an increase of 84 percent from the prior year period

[0001730168-26-000051:8k_2_02:12]
•Third quarter fiscal year 2026 Non-GAAP operating income guidance of approximately 67 percent of projected revenue (1)

[0001730168-26-000051:8k_2_02:13]
•Third quarter fiscal year 2026 Adjusted EBITDA guidance of approximately 68 percent of projected revenue (1)

[0001730168-26-000051:8k_2_02:14]
PALO ALTO, Calif. – June 3, 2026 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its second quarter of fiscal year 2026, ended May 3, 2026, provided guidance for its third quarter of fiscal year 2026 and announced its quarterly dividend.

[0001730168-26-000051:8k_2_02:15]
“Broadcom achieved record revenue, operating profit and free cash flow in Q2 driven by accelerating growth in AI semiconductor revenue and strong operating leverage. Q2 semiconductor revenue from AI of $10.8 billion grew 143% year-over-year, above our forecast, driven by increasing demand for custom AI accelerators and AI networking,” said Hock Tan, President and CEO of Broadcom Inc. “The momentum continues and in Q3 we expect semiconductor revenue from AI to grow over 200 percent year-over-year to $16.0 billion.”

[0001730168-26-000051:8k_2_02:16]
“Q2 consolidated revenue grew 48% year-over-year to a record $22.2 billion. Adjusted EBITDA increased 52% year-over-year to a record $15.2 billion, representing 69% of revenue,” said Kirsten Spears, CFO of Broadcom Inc. “In Q3 we expect consolidated revenue growth to increase 84% year-over-year to $29.4 billion, with non-GAAP operating margin stable at 67% reflecting our strong operating leverage.”

[0001730168-26-000051:8k_2_02:17]
________________________________

[0001730168-26-000051:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of projected non-GAAP financial measures presented to the relevant projected GAAP measures without unreasonable effort.

[0001730168-26-000051:8k_2_02:19]
Second Quarter Fiscal Year 2026 Financial Highlights

[0001730168-26-000051:8k_2_02:20]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q2 26 |  | Q2 25 |  | Change |  | Q2 26 |  | Q2 25 |  | Change |
| Net revenue |  | $ | 22,187 |  |  | $ | 15,004 |  |  | +48 | % |  | $ | 22,187 |  |  | $ | 15,004 |  |  | +48 | % |
| Net income |  | $ | 9,310 |  |  | $ | 4,965 |  |  | +88 | % |  | $ | 12,074 |  |  | $ | 7,787 |  |  | +55 | % |
| Earnings per common share - diluted |  | $ | 1.91 |  |  | $ | 1.03 |  |  | +85 | % |  | $ | 2.44 |  |  | $ | 1.58 |  |  | +54 | % |

[0001730168-26-000051:8k_2_02:21]
| (Dollars in millions) |  | Q2 26 |  | Q2 25 |  | Change |  |
| Cash flow from operations |  | $ | 10,493 |  |  | $ | 6,555 |  |  | +60 | % |  |
| Adjusted EBITDA |  | $ | 15,244 |  |  | $ | 10,001 |  |  | +52 | % |  |
| Free cash flow |  | $ | 10,262 |  |  | $ | 6,411 |  |  | +60 | % |  |

[0001730168-26-000051:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q2 26 |  |  |  | Q2 25 |  | Change |  |
| Semiconductor solutions |  | $ | 15,009 |  |  | 68 | % |  |  |  |  |  |  | $ | 8,408 |  |  | 56 | % |  | +79 | % |  |
| Infrastructure software |  | 7,178 |  |  | 32 |  |  |  |  |  |  |  | 6,596 |  |  | 44 |  |  | +9 | % |  |
| Total net revenue |  | $ | 22,187 |  |  | 100 | % |  |  |  |  |  |  | $ | 15,004 |  |  | 100 | % |  |  |  |  |

[0001730168-26-000051:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $19,628 million, compared to $14,174 million at the end of the prior fiscal quarter.

[0001730168-26-000051:8k_2_02:24]
During the second fiscal quarter, the Company generated $10,493 million in cash from operations and spent $231 million on capital expenditures, resulting in $10,262 million of free cash flow.

[0001730168-26-000051:8k_2_02:25]
On March 31, 2026, the Company paid a cash dividend of $0.65 per share, totaling $3,092 million.

[0001730168-26-000051:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-26-000051:8k_2_02:27]
Third Quarter Fiscal Year 2026 Business Outlook

[0001730168-26-000051:8k_2_02:28]
Based on current business trends and conditions, the outlook for the third quarter of fiscal year 2026, ending August 2, 2026, is expected to be as follows:

[0001730168-26-000051:8k_2_02:29]
•Third quarter revenue guidance of approximately $29.4 billion;

[0001730168-26-000051:8k_2_02:30]
•Third quarter non-GAAP operating income guidance of approximately 67 percent of projected revenue;

[0001730168-26-000051:8k_2_02:31]
•Third quarter Adjusted EBITDA guidance of approximately 68 percent of projected revenue.

[0001730168-26-000051:8k_2_02:32]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected non-GAAP financial measures to the relevant projected GAAP measures without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-26-000051:8k_2_02:33]
2

[0001730168-26-000051:8k_2_02:34]
Quarterly Dividends

[0001730168-26-000051:8k_2_02:35]
The Board of Directors of Broadcom has approved a quarterly cash dividend of $0.65 per share. The dividend is payable on June 30, 2026 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on June 22, 2026.

[0001730168-26-000051:8k_2_02:36]
Financial Results Conference Call

[0001730168-26-000051:8k_2_02:37]
Broadcom Inc. will host a conference call to review its financial results for the second quarter of fiscal year 2026 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-26-000051:8k_2_02:38]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-26-000051:8k_2_02:39]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-26-000051:8k_2_02:40]
Non-GAAP Financial Measures

[0001730168-26-000051:8k_2_02:41]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. When possible, a reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release. The Company is not readily able to provide a reconciliation of projected non-GAAP measures to the comparable GAAP measures without unreasonable effort. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-26-000051:8k_2_02:42]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-26-000051:8k_2_02:43]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right

[0001730168-26-000051:8k_2_02:44]
3

[0001730168-26-000051:8k_2_02:45]
to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-26-000051:8k_2_02:46]
About Broadcom

[0001730168-26-000051:8k_2_02:47]
Broadcom Inc. (NASDAQ: AVGO) is a technology leader that designs, develops, and supplies semiconductors and infrastructure software for global organizations’ complex, mission-critical needs. Broadcom combines long-term R&D investment with superb execution to deliver the best technology, at scale. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, visit www.broadcom.com.

[0001730168-26-000051:8k_2_02:48]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-26-000051:8k_2_02:49]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; cyclicality in the semiconductor industry undergoing profound change due to AI; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; the slow or unsuccessful return on our research and development investments, expansion of our business strategy or adoption of new business models; our dependence on contract manufacturing and outsourced supply chain; our dependency on a limited number of suppliers; our ability to continue winning business in the semiconductor solutions industry; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; dependence on senior management and our ability to attract and retain qualified personnel; our ability to maintain or improve gross margin; our ability to protect against cybersecurity threats and a breach of security systems; prolonged disruptions of our, our customers’ or our suppliers’ facilities or other significant operations; our ability to maintain appropriate manufacturing capacity and quality; dependence on and risks associated with distributors and other channel partners of our products; ability of our software portfolio to manage and secure IT infrastructures and environments; demand for our data center virtualization products and customer acceptance of our software, services and business strategy; competitiveness of our software solutions and compatibility of our software with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our software and services; sales to government customers; our ability to manage our software solutions and services lifecycles; our competitive performance; quarterly and annual fluctuations in operating results; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with

[0001730168-26-000051:8k_2_02:50]
4

[0001730168-26-000051:8k_2_02:51]
integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; corporate responsibility matters; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase program; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature.

[0001730168-26-000051:8k_2_02:52]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-26-000051:8k_2_02:53]
Contact:

[0001730168-26-000051:8k_2_02:54]
Ji Yoo

[0001730168-26-000051:8k_2_02:55]
Broadcom Inc.

[0001730168-26-000051:8k_2_02:56]
Investor Relations

[0001730168-26-000051:8k_2_02:57]
650-427-6000

[0001730168-26-000051:8k_2_02:58]
investor.relations@broadcom.com

[0001730168-26-000051:8k_2_02:59]
(AVGO-Q)

[0001730168-26-000051:8k_2_02:60]
5

[0001730168-26-000051:8k_2_02:61]
BROADCOM INC.

[0001730168-26-000051:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-26-000051:8k_2_02:63]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-26-000051:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | February 1,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
| Net revenue |  | $ | 22,187 |  |  | $ | 19,311 |  |  | $ | 15,004 |  |  | $ | 41,498 |  |  | $ | 29,920 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 5,301 |  |  | 4,679 |  |  | 3,296 |  |  | 9,980 |  |  | 6,569 |  |
| Amortization of acquisition-related intangible assets |  | 1,461 |  |  | 1,462 |  |  | 1,483 |  |  | 2,923 |  |  | 2,967 |  |
| Restructuring charges |  | 10 |  |  | 13 |  |  | 28 |  |  | 23 |  |  | 42 |  |
| Total cost of revenue |  | 6,772 |  |  | 6,154 |  |  | 4,807 |  |  | 12,926 |  |  | 9,578 |  |
| Gross margin |  | 15,415 |  |  | 13,157 |  |  | 10,197 |  |  | 28,572 |  |  | 20,342 |  |
| Research and development |  | 2,995 |  |  | 2,965 |  |  | 2,693 |  |  | 5,960 |  |  | 4,946 |  |
| Selling, general and administrative |  | 1,055 |  |  | 1,019 |  |  | 1,083 |  |  | 2,074 |  |  | 2,032 |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 507 |  |  | 506 |  |  | 1,013 |  |  | 1,017 |  |
| Restructuring and other charges |  | 71 |  |  | 103 |  |  | 86 |  |  | 174 |  |  | 258 |  |
| Total operating expenses |  | 4,627 |  |  | 4,594 |  |  | 4,368 |  |  | 9,221 |  |  | 8,253 |  |
| Operating income |  | 10,788 |  |  | 8,563 |  |  | 5,829 |  |  | 19,351 |  |  | 12,089 |  |
| Interest expense |  | (776) |  |  | (801) |  |  | (769) |  |  | (1,577) |  |  | (1,642) |  |
| Other income, net |  | 118 |  |  | 433 |  |  | 25 |  |  | 551 |  |  | 128 |  |
| Income before income taxes |  | 10,130 |  |  | 8,195 |  |  | 5,085 |  |  | 18,325 |  |  | 10,575 |  |
| Provision for income taxes |  | 820 |  |  | 846 |  |  | 120 |  |  | 1,666 |  |  | 107 |  |
| Net income |  | $ | 9,310 |  |  | $ | 7,349 |  |  | $ | 4,965 |  |  | $ | 16,659 |  |  | $ | 10,468 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.96 |  |  | $ | 1.55 |  |  | $ | 1.05 |  |  | $ | 3.51 |  |  | $ | 2.23 |  |
| Diluted |  | $ | 1.91 |  |  | $ | 1.50 |  |  | $ | 1.03 |  |  | $ | 3.41 |  |  | $ | 2.17 |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,747 |  |  | 4,741 |  |  | 4,707 |  |  | 4,744 |  |  | 4,701 |  |
| Diluted |  | 4,876 |  |  | 4,888 |  |  | 4,826 |  |  | 4,882 |  |  | 4,831 |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 223 |  |  | $ | 236 |  |  | $ | 203 |  |  | $ | 459 |  |  | $ | 356 |  |
| Research and development |  | 1,395 |  |  | 1,447 |  |  | 1,169 |  |  | 2,842 |  |  | 1,991 |  |
| Selling, general and administrative |  | 474 |  |  | 493 |  |  | 399 |  |  | 967 |  |  | 704 |  |
| Total stock-based compensation expense |  | $ | 2,092 |  |  | $ | 2,176 |  |  | $ | 1,771 |  |  | $ | 4,268 |  |  | $ | 3,051 |  |

[0001730168-26-000051:8k_2_02:65]
BROADCOM INC.

[0001730168-26-000051:8k_2_02:66]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-26-000051:8k_2_02:67]
(IN MILLIONS)

[0001730168-26-000051:8k_2_02:68]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |  |
|  |  | May 3,2026 |  | February 1,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |  |
| Gross margin on GAAP basis |  | $ | 15,415 |  |  | $ | 13,157 |  |  | $ | 10,197 |  |  | $ | 28,572 |  |  | $ | 20,342 |  |  |
| Amortization of acquisition-related intangible assets |  | 1,461 |  |  | 1,462 |  |  | 1,483 |  |  | 2,923 |  |  | 2,967 |  |  |
| Stock-based compensation expense |  | 223 |  |  | 236 |  |  | 203 |  |  | 459 |  |  | 356 |  |  |
| Restructuring charges |  | 10 |  |  | 13 |  |  | 28 |  |  | 23 |  |  | 42 |  |  |
| Gross margin on non-GAAP basis |  | $ | 17,109 |  |  | $ | 14,868 |  |  | $ | 11,911 |  |  | $ | 31,977 |  |  | $ | 23,707 |  |  |
| Research and development on GAAP basis |  | $ | 2,995 |  |  | $ | 2,965 |  |  | $ | 2,693 |  |  | $ | 5,960 |  |  | $ | 4,946 |  |  |
| Stock-based compensation expense |  | 1,395 |  |  | 1,447 |  |  | 1,169 |  |  | 2,842 |  |  | 1,991 |  |  |
| Research and development on non-GAAP basis |  | $ | 1,600 |  |  | $ | 1,518 |  |  | $ | 1,524 |  |  | $ | 3,118 |  |  | $ | 2,955 |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,055 |  |  | $ | 1,019 |  |  | $ | 1,083 |  |  | $ | 2,074 |  |  | $ | 2,032 |  |  |
| Stock-based compensation expense |  | 474 |  |  | 493 |  |  | 399 |  |  | 967 |  |  | 704 |  |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | 90 |  |  | 2 |  |  | 197 |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 581 |  |  | $ | 524 |  |  | $ | 594 |  |  | $ | 1,105 |  |  | $ | 1,131 |  |  |
| Total operating expenses on GAAP basis |  | $ | 4,627 |  |  | $ | 4,594 |  |  | $ | 4,368 |  |  | $ | 9,221 |  |  | $ | 8,253 |  |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 507 |  |  | 506 |  |  | 1,013 |  |  | 1,017 |  |  |
| Stock-based compensation expense |  | 1,869 |  |  | 1,940 |  |  | 1,568 |  |  | 3,809 |  |  | 2,695 |  |  |
| Restructuring and other charges |  | 71 |  |  | 103 |  |  | 86 |  |  | 174 |  |  | 258 |  |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | 90 |  |  | 2 |  |  | 197 |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,181 |  |  | $ | 2,042 |  |  | $ | 2,118 |  |  | $ | 4,223 |  |  | $ | 4,086 |  |  |
| Operating income on GAAP basis |  | $ | 10,788 |  |  | $ | 8,563 |  |  | $ | 5,829 |  |  | $ | 19,351 |  |  | $ | 12,089 |  |  |
| Amortization of acquisition-related intangible assets |  | 1,967 |  |  | 1,969 |  |  | 1,989 |  |  | 3,936 |  |  | 3,984 |  |  |
| Stock-based compensation expense |  | 2,092 |  |  | 2,176 |  |  | 1,771 |  |  | 4,268 |  |  | 3,051 |  |  |
| Restructuring and other charges |  | 81 |  |  | 116 |  |  | 114 |  |  | 197 |  |  | 300 |  |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | 90 |  |  | 2 |  |  | 197 |  |  |
| Operating income on non-GAAP basis |  | $ | 14,928 |  |  | $ | 12,826 |  |  | $ | 9,793 |  |  | $ | 27,754 |  |  | $ | 19,621 |  |  |
| Interest expense on GAAP basis |  | $ | (776) |  |  | $ | (801) |  |  | $ | (769) |  |  | $ | (1,577) |  |  | $ | (1,642) |  |  |
| Loss on debt extinguishment |  | 31 |  |  | 55 |  |  | — |  |  | 86 |  |  | 65 |  |  |
| Interest expense on non-GAAP basis |  | $ | (745) |  |  | $ | (746) |  |  | $ | (769) |  |  | $ | (1,491) |  |  | $ | (1,577) |  |  |
| Other income, net on GAAP basis |  | $ | 118 |  |  | $ | 433 |  |  | $ | 25 |  |  | $ | 551 |  |  | $ | 128 |  |  |
| Excise tax benefit |  | — |  |  | (315) |  |  | — |  |  | (315) |  |  | — |  |  |
| Other |  | — |  |  | — |  |  | 6 |  |  | — |  |  | (21) |  |  |
| Other income, net on non-GAAP basis |  | $ | 118 |  |  | $ | 118 |  |  | $ | 31 |  |  | $ | 236 |  |  | $ | 107 |  |  |

[0001730168-26-000051:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |  |
|  |  | May 3,2026 |  | February 1,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |  |
| Provision for income taxes on GAAP basis |  | $ | 820 |  |  | $ | 846 |  |  | $ | 120 |  |  | $ | 1,666 |  |  | $ | 107 |  |  |
| Non-GAAP tax reconciling adjustments |  | 1,407 |  |  | 1,167 |  |  | 1,148 |  |  | 2,574 |  |  | 2,434 |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 2,227 |  |  | $ | 2,013 |  |  | $ | 1,268 |  |  | $ | 4,240 |  |  | $ | 2,541 |  |  |
| Net income on GAAP basis |  | $ | 9,310 |  |  | $ | 7,349 |  |  | $ | 4,965 |  |  | $ | 16,659 |  |  | $ | 10,468 |  |  |
| Amortization of acquisition-related intangible assets |  | 1,967 |  |  | 1,969 |  |  | 1,989 |  |  | 3,936 |  |  | 3,984 |  |  |
| Stock-based compensation expense |  | 2,092 |  |  | 2,176 |  |  | 1,771 |  |  | 4,268 |  |  | 3,051 |  |  |
| Restructuring and other charges |  | 81 |  |  | 116 |  |  | 114 |  |  | 197 |  |  | 300 |  |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | 90 |  |  | 2 |  |  | 197 |  |  |
| Loss on debt extinguishment |  | 31 |  |  | 55 |  |  | — |  |  | 86 |  |  | 65 |  |  |
| Excise tax benefit |  | — |  |  | (315) |  |  | — |  |  | (315) |  |  | — |  |  |
| Other |  | — |  |  | — |  |  | 6 |  |  | — |  |  | (21) |  |  |
| Non-GAAP tax reconciling adjustments |  | (1,407) |  |  | (1,167) |  |  | (1,148) |  |  | (2,574) |  |  | (2,434) |  |  |
| Net income on non-GAAP basis |  | $ | 12,074 |  |  | $ | 10,185 |  |  | $ | 7,787 |  |  | $ | 22,259 |  |  | $ | 15,610 |  |  |
| Net income on GAAP basis |  | $ | 9,310 |  |  | $ | 7,349 |  |  | $ | 4,965 |  |  | $ | 16,659 |  |  | $ | 10,468 |  |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,967 |  |  | 1,969 |  |  | 1,989 |  |  | 3,936 |  |  | 3,984 |  |  |
| Stock-based compensation expense |  | 2,092 |  |  | 2,176 |  |  | 1,771 |  |  | 4,268 |  |  | 3,051 |  |  |
| Restructuring and other charges |  | 81 |  |  | 116 |  |  | 114 |  |  | 197 |  |  | 300 |  |  |
| Acquisition-related costs |  | — |  |  | 2 |  |  | 90 |  |  | 2 |  |  | 197 |  |  |
| Loss on debt extinguishment |  | 31 |  |  | 55 |  |  | — |  |  | 86 |  |  | 65 |  |  |
| Excise tax benefit |  | — |  |  | (315) |  |  | — |  |  | (315) |  |  | — |  |  |
| Other |  | — |  |  | — |  |  | 6 |  |  | — |  |  | (21) |  |  |
| Non-GAAP tax reconciling adjustments |  | (1,407) |  |  | (1,167) |  |  | (1,148) |  |  | (2,574) |  |  | (2,434) |  |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 745 |  |  | 746 |  |  | 769 |  |  | 1,491 |  |  | 1,577 |  |  |
| Provision for income taxes on non-GAAP basis |  | 2,227 |  |  | 2,013 |  |  | 1,268 |  |  | 4,240 |  |  | 2,541 |  |  |
| Depreciation |  | 163 |  |  | 150 |  |  | 142 |  |  | 313 |  |  | 284 |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 35 |  |  | 34 |  |  | 35 |  |  | 69 |  |  | 72 |  |  |
| Adjusted EBITDA |  | $ | 15,244 |  |  | $ | 13,128 |  |  | $ | 10,001 |  |  | $ | 28,372 |  |  | $ | 20,084 |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,876 |  |  | 4,888 |  |  | 4,826 |  |  | 4,882 |  |  | 4,831 |  |  |
| Non-GAAP adjustment (1) |  | 64 |  |  | 69 |  |  | 111 |  |  | 66 |  |  | 85 |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,940 |  |  | 4,957 |  |  | 4,937 |  |  | 4,948 |  |  | 4,916 |  |  |
| Net cash provided by operating activities |  | $ | 10,493 |  |  | $ | 8,260 |  |  | $ | 6,555 |  |  | $ | 18,753 |  |  | $ | 12,668 |  |  |
| Purchases of property, plant and equipment |  | (231) |  |  | (250) |  |  | (144) |  |  | (481) |  |  | (244) |  |  |
| Free cash flow |  | $ | 10,262 |  |  | $ | 8,010 |  |  | $ | 6,411 |  |  | $ | 18,272 |  |  | $ | 12,424 |  |  |

[0001730168-26-000051:8k_2_02:70]
| (1) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |

[0001730168-26-000051:8k_2_02:71]
BROADCOM INC.

[0001730168-26-000051:8k_2_02:72]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-26-000051:8k_2_02:73]
(IN MILLIONS)

[0001730168-26-000051:8k_2_02:74]
|  |  | May 3,2026 |  | November 2,2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 19,628 |  |  | $ | 16,178 |  |
| Trade accounts receivable, net |  | 10,830 |  |  | 7,145 |  |
| Inventory |  | 4,328 |  |  | 2,270 |  |
| Other current assets |  | 7,427 |  |  | 5,980 |  |
| Total current assets |  | 42,213 |  |  | 31,573 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,788 |  |  | 2,530 |  |
| Goodwill |  | 97,801 |  |  | 97,801 |  |
| Intangible assets, net |  | 28,333 |  |  | 32,273 |  |
| Other long-term assets |  | 8,023 |  |  | 6,915 |  |
| Total assets |  | $ | 179,158 |  |  | $ | 171,092 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 2,337 |  |  | $ | 1,560 |  |
| Employee compensation and benefits |  | 1,134 |  |  | 2,129 |  |
| Short-term debt |  | 2,252 |  |  | 3,152 |  |
| Other current liabilities |  | 13,139 |  |  | 11,673 |  |
| Total current liabilities |  | 18,862 |  |  | 18,514 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 62,655 |  |  | 61,984 |  |
| Other long-term liabilities |  | 9,950 |  |  | 9,302 |  |
| Total liabilities |  | 91,467 |  |  | 89,800 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 75,312 |  |  | 71,308 |  |
| Retained earnings |  | 12,166 |  |  | 9,761 |  |
| Accumulated other comprehensive income |  | 208 |  |  | 218 |  |
| Total stockholders' equity |  | 87,691 |  |  | 81,292 |  |
| Total liabilities and equity |  | $ | 179,158 |  |  | $ | 171,092 |  |

[0001730168-26-000051:8k_2_02:75]
| BROADCOM INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |
| (IN MILLIONS) |
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | February 1,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,310 |  |  | $ | 7,349 |  |  | $ | 4,965 |  |  | $ | 16,659 |  |  | $ | 10,468 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,002 |  |  | 2,003 |  |  | 2,024 |  |  | 4,005 |  |  | 4,056 |  |
| Depreciation |  | 163 |  |  | 150 |  |  | 142 |  |  | 313 |  |  | 284 |  |
| Stock-based compensation |  | 2,092 |  |  | 2,176 |  |  | 1,771 |  |  | 4,268 |  |  | 3,051 |  |
| Deferred taxes and other non-cash taxes |  | (603) |  |  | (455) |  |  | (571) |  |  | (1,058) |  |  | (1,267) |  |
| Loss on debt extinguishment |  | 31 |  |  | 55 |  |  | — |  |  | 86 |  |  | 65 |  |
| Non-cash interest expense |  | 67 |  |  | 72 |  |  | 94 |  |  | 139 |  |  | 191 |  |
| Other |  | 3 |  |  | 15 |  |  | 40 |  |  | 18 |  |  | 81 |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (2,370) |  |  | (1,315) |  |  | (590) |  |  | (3,685) |  |  | (1,129) |  |
| Inventory |  | (1,366) |  |  | (692) |  |  | (109) |  |  | (2,058) |  |  | (257) |  |
| Accounts payable |  | 149 |  |  | 534 |  |  | (613) |  |  | 683 |  |  | (372) |  |
| Employee compensation and benefits |  | 270 |  |  | (1,261) |  |  | 287 |  |  | (991) |  |  | (621) |  |
| Other current assets and current liabilities |  | 474 |  |  | (692) |  |  | (55) |  |  | (218) |  |  | (29) |  |
| Other long-term assets and long-term liabilities |  | 271 |  |  | 321 |  |  | (830) |  |  | 592 |  |  | (1,853) |  |
| Net cash provided by operating activities |  | 10,493 |  |  | 8,260 |  |  | 6,555 |  |  | 18,753 |  |  | 12,668 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (231) |  |  | (250) |  |  | (144) |  |  | (481) |  |  | (244) |  |
| Purchases of investments |  | (23) |  |  | (114) |  |  | (57) |  |  | (137) |  |  | (162) |  |
| Sales of investments |  | 39 |  |  | 244 |  |  | 78 |  |  | 283 |  |  | 96 |  |
| Other |  | 7 |  |  | 5 |  |  | (10) |  |  | 12 |  |  | 3 |  |
| Net cash used in investing activities |  | (208) |  |  | (115) |  |  | (133) |  |  | (323) |  |  | (307) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | — |  |  | 4,474 |  |  | 749 |  |  | 4,474 |  |  | 3,735 |  |
| Payments on debt obligations |  | (1,250) |  |  | (3,650) |  |  | — |  |  | (4,900) |  |  | (8,090) |  |
| Proceeds from (repayments of) commercial paper, net |  | — |  |  | — |  |  | (119) |  |  | — |  |  | 3,861 |  |
| Payments of dividends |  | (3,092) |  |  | (3,086) |  |  | (2,785) |  |  | (6,178) |  |  | (5,559) |  |
| Repurchases of common stock - repurchase program |  | (600) |  |  | (7,850) |  |  | (2,450) |  |  | (8,450) |  |  | (2,450) |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | — |  |  | (1,766) |  |  | — |  |  | (3,802) |  |
| Issuance of common stock |  | 113 |  |  | — |  |  | 118 |  |  | 113 |  |  | 118 |  |
| Other |  | (2) |  |  | (37) |  |  | (4) |  |  | (39) |  |  | (50) |  |
| Net cash used in financing activities |  | (4,831) |  |  | (10,149) |  |  | (6,257) |  |  | (14,980) |  |  | (12,237) |  |
| Net change in cash and cash equivalents |  | 5,454 |  |  | (2,004) |  |  | 165 |  |  | 3,450 |  |  | 124 |  |
| Cash and cash equivalents at beginning of period |  | 14,174 |  |  | 16,178 |  |  | 9,307 |  |  | 16,178 |  |  | 9,348 |  |
| Cash and cash equivalents at end of period |  | $ | 19,628 |  |  | $ | 14,174 |  |  | $ | 9,472 |  |  | $ | 19,628 |  |  | $ | 9,472 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 695 |  |  | $ | 619 |  |  | $ | 700 |  |  | $ | 1,314 |  |  | $ | 1,371 |  |
| Cash paid for income taxes |  | $ | 1,099 |  |  | $ | 782 |  |  | $ | 608 |  |  | $ | 1,881 |  |  | $ | 1,012 |  |
