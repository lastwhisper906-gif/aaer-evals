# AVGO MD&A — 0001730168-26-000054


## mdna

[0001730168-26-000054:mdna:1]
[same as prior period, unchanged from 0001730168-26-000016:mdna:1]

[0001730168-26-000054:mdna:2]
[same as prior period, unchanged from 0001730168-26-000016:mdna:2]

[0001730168-26-000054:mdna:3]
[same as prior period, unchanged from 0001730168-26-000016:mdna:3]

[0001730168-26-000054:mdna:4]
[same as prior period, unchanged from 0001730168-26-000016:mdna:4]

[0001730168-26-000054:mdna:5]
[same as prior period, unchanged from 0001730168-26-000016:mdna:5]

[0001730168-26-000054:mdna:6]
[same as prior period, unchanged from 0001730168-26-000016:mdna:6]

[0001730168-26-000054:mdna:7]
Highlights during the fiscal quarter ended May 3, 2026 include the following:

[0001730168-26-000054:mdna:8]
•We generated $10,493 million of cash from operations.

[0001730168-26-000054:mdna:9]
•We paid $3,092 million in cash dividends.

[0001730168-26-000054:mdna:10]
•We repurchased $600 million of common stock.

[0001730168-26-000054:mdna:11]
[same as prior period, unchanged from 0001730168-26-000016:mdna:16]

[0001730168-26-000054:mdna:12]
[same as prior period, unchanged from 0001730168-26-000016:mdna:11]

[0001730168-26-000054:mdna:13]
[same as prior period, unchanged from 0001730168-26-000016:mdna:12]

[0001730168-26-000054:mdna:14]
There were no significant changes in our critical accounting estimates during the two fiscal quarters ended May 3, 2026 compared to those previously disclosed in “Critical Accounting Estimates” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in the 2025 Annual Report on Form 10-K.

[0001730168-26-000054:mdna:15]
[same as prior period, unchanged from 0001730168-26-000016:mdna:14]

[0001730168-26-000054:mdna:16]
We are subject to risks and exposures from evolving macroeconomic conditions, including uncertainty and volatility in financial markets, geopolitical events, supply constraints, efforts of governments to stimulate or stabilize the economy and other unfavorable changes in economic conditions, as well as an increase in trade tensions and related tariffs with U.S. trading partners. While difficult to isolate and quantify, these risks and exposures may cause our net revenue to fluctuate significantly and disrupt supply chain operations, and we continuously monitor the broader impacts of these circumstances on our business, our supply chain and our results of operations.

[0001730168-26-000054:mdna:17]
[same as prior period, unchanged from 0001730168-26-000016:mdna:26]

[0001730168-26-000054:mdna:18]
[same as prior period, unchanged from 0001730168-26-000016:mdna:17]

[0001730168-26-000054:mdna:19]
Fiscal Quarter and Two Fiscal Quarters Ended May 3, 2026 Compared to Fiscal Quarter and Two Fiscal Quarters Ended May 4, 2025

[0001730168-26-000054:mdna:20]
The following tables set forth our results of operations for the periods presented:

[0001730168-26-000054:mdna:21]
|  |  | Fiscal Quarter Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 16,892 |  |  | $ | 10,309 |  |  | 76 | % |  | 69 | % |
| Subscriptions and services |  | 5,295 |  |  | 4,695 |  |  | 24 |  |  | 31 |  |
| Total net revenue |  | 22,187 |  |  | 15,004 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 4,665 |  |  | 2,722 |  |  | 21 |  |  | 18 |  |
| Cost of subscriptions and services |  | 636 |  |  | 574 |  |  | 3 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 1,461 |  |  | 1,483 |  |  | 7 |  |  | 10 |  |
| Restructuring charges |  | 10 |  |  | 28 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 6,772 |  |  | 4,807 |  |  | 31 |  |  | 32 |  |
| Gross margin |  | 15,415 |  |  | 10,197 |  |  | 69 |  |  | 68 |  |
| Research and development |  | 2,995 |  |  | 2,693 |  |  | 13 |  |  | 18 |  |
| Selling, general and administrative |  | 1,055 |  |  | 1,083 |  |  | 5 |  |  | 7 |  |
| Amortization of acquisition-related intangible assets |  | 506 |  |  | 506 |  |  | 2 |  |  | 3 |  |
| Restructuring and other charges |  | 71 |  |  | 86 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 4,627 |  |  | 4,368 |  |  | 20 |  |  | 29 |  |
| Operating income |  | $ | 10,788 |  |  | $ | 5,829 |  |  | 49 | % |  | 39 | % |

[0001730168-26-000054:mdna:22]
25

[0001730168-26-000054:mdna:23]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |  | (As a percentage of net revenue) |
| Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 31,022 |  |  | $ | 20,452 |  |  | 75 | % |  | 68 | % |
| Subscriptions and services |  | 10,476 |  |  | 9,468 |  |  | 25 |  |  | 32 |  |
| Total net revenue |  | 41,498 |  |  | 29,920 |  |  | 100 |  |  | 100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of products sold |  | 8,706 |  |  | 5,417 |  |  | 21 |  |  | 18 |  |
| Cost of subscriptions and services |  | 1,274 |  |  | 1,152 |  |  | 3 |  |  | 4 |  |
| Amortization of acquisition-related intangible assets |  | 2,923 |  |  | 2,967 |  |  | 7 |  |  | 10 |  |
| Restructuring charges |  | 23 |  |  | 42 |  |  | — |  |  | — |  |
| Total cost of revenue |  | 12,926 |  |  | 9,578 |  |  | 31 |  |  | 32 |  |
| Gross margin |  | 28,572 |  |  | 20,342 |  |  | 69 |  |  | 68 |  |
| Research and development |  | 5,960 |  |  | 4,946 |  |  | 14 |  |  | 17 |  |
| Selling, general and administrative |  | 2,074 |  |  | 2,032 |  |  | 5 |  |  | 7 |  |
| Amortization of acquisition-related intangible assets |  | 1,013 |  |  | 1,017 |  |  | 3 |  |  | 3 |  |
| Restructuring and other charges |  | 174 |  |  | 258 |  |  | — |  |  | 1 |  |
| Total operating expenses |  | 9,221 |  |  | 8,253 |  |  | 22 |  |  | 28 |  |
| Operating income |  | $ | 19,351 |  |  | $ | 12,089 |  |  | 47 | % |  | 40 | % |

[0001730168-26-000054:mdna:24]
We included upfront license revenue of $1,964 million and $3,719 million within products revenue for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively. We included the related costs, which were immaterial, in cost of products sold. To conform to the current period presentation, we reclassified $1,803 million and $3,775 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. We also reclassified the related costs for the upfront license revenue, which were immaterial for the periods presented. See Note 2. “Revenue from Contracts with Customers” in Part I, Item 1. of this Form 10-Q for additional information.

[0001730168-26-000054:mdna:25]
[same as prior period, unchanged from 0001730168-26-000016:mdna:22]

[0001730168-26-000054:mdna:26]
A relatively small number of customers account for a significant portion of our net revenue. Direct sales to one semiconductor solutions customer, which is a distributor, accounted for 42% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2026, and 29% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 4, 2025.

[0001730168-26-000054:mdna:27]
We believe aggregate sales to our top five end customers, through all channels, accounted for approximately 45% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 3, 2026 and 40% of our net revenue for each of the fiscal quarter and two fiscal quarters ended May 4, 2025. We expect to continue to experience significant customer concentration in future periods. The loss of, or significant decrease in demand from, any of our top five end customers could have a material adverse effect on our business, results of operations and financial condition.

[0001730168-26-000054:mdna:28]
From time to time, some of our key semiconductor customers place large orders or delay orders, causing our quarterly net revenue to fluctuate significantly. This is particularly true of our products used in AI and wireless applications as fluctuations may be magnified by the timing of customer deployments, as well as product launches. For infrastructure software, the relative volume of customer contracts signed with the right to terminate causes variations in revenue recognized in each period.

[0001730168-26-000054:mdna:29]
[same as prior period, unchanged from 0001730168-26-000016:mdna:53]

[0001730168-26-000054:mdna:30]
[same as prior period, unchanged from 0001730168-26-000016:mdna:27]

[0001730168-26-000054:mdna:31]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Net Revenue by Segment |  | May 3, 2026 |  | May 4, 2025 |  | $ Change |  | % Change |  | May 3, 2026 |  | May 4, 2025 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 15,009 |  |  | $ | 8,408 |  |  | $ | 6,601 |  |  | 79 | % |  | $ | 27,524 |  |  | $ | 16,620 |  |  | $ | 10,904 |  |  | 66 | % |
| Infrastructure software |  | 7,178 |  |  | 6,596 |  |  | 582 |  |  | 9 | % |  | 13,974 |  |  | 13,300 |  |  | 674 |  |  | 5 | % |
| Total net revenue |  | $ | 22,187 |  |  | $ | 15,004 |  |  | $ | 7,183 |  |  | 48 | % |  | $ | 41,498 |  |  | $ | 29,920 |  |  | $ | 11,578 |  |  | 39 | % |

[0001730168-26-000054:mdna:32]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
| Net Revenue by Segment |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (As a percentage of net revenue) |
| Semiconductor solutions |  | 68 | % |  | 56 | % |  | 66 | % |  | 56 | % |
| Infrastructure software |  | 32 |  |  | 44 |  |  | 34 |  |  | 44 |  |
| Total net revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0001730168-26-000054:mdna:33]
Net revenue from our semiconductor solutions segment increased in the fiscal quarter and two fiscal quarters ended May 3, 2026 compared to the prior year fiscal periods due to strong demand for our networking solutions, primarily custom AI accelerators and AI networking products.

[0001730168-26-000054:mdna:34]
Net revenue from our infrastructure software segment increased in the fiscal quarter and two fiscal quarters ended May 3, 2026 compared to the prior year fiscal periods primarily due to strong demand for our VMware Cloud Foundation (“VCF”) product.

[0001730168-26-000054:mdna:35]
[same as prior period, unchanged from 0001730168-26-000016:mdna:31]

[0001730168-26-000054:mdna:36]
Gross margin was $15,415 million for the fiscal quarter ended May 3, 2026 compared to $10,197 million for the fiscal quarter ended May 4, 2025 and $28,572 million for the two fiscal quarters ended May 3, 2026 compared to $20,342 million for the two fiscal quarters ended May 4, 2025. The increases were primarily due to strong product demand for our AI-related semiconductor solutions.

[0001730168-26-000054:mdna:37]
As a percentage of net revenue, gross margin was 69% for each of the fiscal quarter and two fiscal quarters ended May 3, 2026, and 68% for each of the fiscal quarter and two fiscal quarters ended May 4, 2025. The increases were primarily due to the gross margin benefit from our net revenue growth, partially offset by a higher mix of semiconductor solutions net revenue, which has a lower gross margin than infrastructure software.

[0001730168-26-000054:mdna:38]
[same as prior period, unchanged from 0001730168-26-000016:mdna:34]

[0001730168-26-000054:mdna:39]
Research and development expense increased $302 million, or 11%, and $1,014 million or 21%, for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, compared to the prior year fiscal periods. The increases were primarily due to higher stock-based compensation.

[0001730168-26-000054:mdna:40]
[same as prior period, unchanged from 0001730168-26-000016:mdna:36]

[0001730168-26-000054:mdna:41]
Selling, general and administrative expense decreased $28 million, or 3%, and increased $42 million or 2% for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, compared to the prior year fiscal periods. These modest changes principally result from two factors. In the current fiscal year periods, higher stock-based compensation was substantially offset by lower acquisition-related costs compared to the prior year fiscal periods.

[0001730168-26-000054:mdna:42]
[same as prior period, unchanged from 0001730168-26-000016:mdna:38]

[0001730168-26-000054:mdna:43]
[same as prior period, unchanged from 0001730168-26-000016:mdna:39]

[0001730168-26-000054:mdna:44]
Total stock-based compensation expense was $2,092 million and $1,771 million for the fiscal quarters ended May 3, 2026 and May 4, 2025, respectively, and $4,268 million and $3,051 million for the two fiscal quarters ended May 3, 2026 and

[0001730168-26-000054:mdna:45]
May 4, 2025, respectively. The increases were due to the full impact in the current year fiscal periods of the Two-Year Equity Awards granted during the second quarter of fiscal year 2025.

[0001730168-26-000054:mdna:46]
The following table sets forth the total unrecognized compensation cost related to unvested stock-based awards outstanding and expected to vest as of May 3, 2026. The remaining weighted-average service period was 3.0 years.

[0001730168-26-000054:mdna:47]
| Fiscal Year: |  | Unrecognized Compensation Cost, Net of Expected Forfeitures |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 4,078 |  |
| 2027 |  | 7,235 |  |
| 2028 |  | 5,137 |  |
| 2029 |  | 2,873 |  |
| 2030 |  | 783 |  |
| Total |  | $ | 20,106 |  |

[0001730168-26-000054:mdna:48]
[same as prior period, unchanged from 0001730168-26-000016:mdna:43]

[0001730168-26-000054:mdna:49]
|  |  | Fiscal Quarter Ended |  |  |  |  |  | Two Fiscal Quarters Ended |  |  |  |  |
| Operating Income by Segment |  | May 3,2026 |  | May 4,2025 |  | $ Change |  | % Change |  | May 3,2026 |  | May 4,2025 |  | $ Change |  | % Change |
|  |  | (Dollars in millions) |
| Semiconductor solutions |  | $ | 9,281 |  |  | $ | 4,806 |  |  | $ | 4,475 |  |  | 93 | % |  | $ | 16,784 |  |  | $ | 9,512 |  |  | $ | 7,272 |  |  | 76 | % |
| Infrastructure software |  | 5,647 |  |  | 4,987 |  |  | 660 |  |  | 13 | % |  | 10,970 |  |  | 10,109 |  |  | 861 |  |  | 9 | % |
| Unallocated expenses |  | (4,140) |  |  | (3,964) |  |  | (176) |  |  | 4 | % |  | (8,403) |  |  | (7,532) |  |  | (871) |  |  | 12 | % |
| Total operating income |  | $ | 10,788 |  |  | $ | 5,829 |  |  | $ | 4,959 |  |  | 85 | % |  | $ | 19,351 |  |  | $ | 12,089 |  |  | $ | 7,262 |  |  | 60 | % |

[0001730168-26-000054:mdna:50]
Operating income from our semiconductor solutions segment increased for the fiscal quarter and two fiscal quarters ended May 3, 2026 compared to the prior year fiscal periods due to strong demand for our networking solutions, primarily custom AI accelerators and AI networking products.

[0001730168-26-000054:mdna:51]
Higher operating income from our infrastructure software segment in the fiscal quarter and two fiscal quarters ended May 3, 2026 compared to the prior year fiscal periods was primarily due to strong demand for our VCF product.

[0001730168-26-000054:mdna:52]
Unallocated expenses include stock-based compensation expense, amortization of acquisition-related intangible assets, restructuring and other charges, acquisition-related costs, and other costs, which are not used in evaluating the results of, or in allocating resources to, our segments. Unallocated expenses increased 4% and 12% for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, compared to the prior year fiscal periods due to higher stock-based compensation expense.

[0001730168-26-000054:mdna:53]
[same as prior period, unchanged from 0001730168-26-000016:mdna:47]

[0001730168-26-000054:mdna:54]
Interest expense. Interest expense was $776 million and $769 million for the fiscal quarters ended May 3, 2026 and May 4, 2025, respectively. The increase was due to a loss on debt extinguishment. Interest expense was $1,577 million and $1,642 million for the two fiscal quarters ended May 3, 2026 and May 4, 2025, respectively. The decrease was primarily due to an overall reduction in outstanding debt balances and debt refinancing activities.

[0001730168-26-000054:mdna:55]
Other income, net. Other income, net includes interest income, gains and losses on investments, foreign currency remeasurement and other miscellaneous items. Other income, net, was $118 million and $551 million for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, and $25 million and $128 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. Interest income increased compared to the prior year fiscal periods as a result of higher invested balances. In addition, for the two fiscal quarters ended May 3, 2026, other income, net included a $315 million gain from the reversal of excise tax charges on our acquisition of VMware, Inc. (“VMware”), as the final Inflation Reduction Act of 2022 regulations exempted purchases of common stock on acquisitions from excise tax.

[0001730168-26-000054:mdna:56]
28

[0001730168-26-000054:mdna:57]
Provision for income taxes. The provision for income taxes was $820 million and $1,666 million for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, compared to $120 million and $107 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. The increase in the provision for income taxes in both the fiscal quarter and two fiscal quarters ended May 3, 2026, as compared to the prior year fiscal periods, was primarily due to higher income before income taxes.

[0001730168-26-000054:mdna:58]
[same as prior period, unchanged from 0001730168-26-000016:mdna:51]

[0001730168-26-000054:mdna:59]
[same as prior period, unchanged from 0001730168-26-000016:mdna:52]

[0001730168-26-000054:mdna:60]
Our primary sources of liquidity as of May 3, 2026 consisted of: (i) $19,628 million in cash and cash equivalents, (ii) cash we expect to generate from operations and (iii) available capacity under our $7.5 billion unsecured revolving credit facility. In addition, we may also generate cash from the sale of assets, and debt or equity financings from time to time.

[0001730168-26-000054:mdna:61]
Our short-term and long-term liquidity requirements primarily arise from: (i) working capital requirements, (ii) research and development and capital expenditure needs, (iii) cash dividend payments (if and when declared by our Board of Directors), (iv) interest and principal payments related to our $66,720 million of outstanding indebtedness with $2,252 million principal amounts payable within 12 months, (v) payment of income taxes, (vi) discretionary stock repurchases, and (vii) business acquisitions and investments we may make from time to time. Our ability to fund these requirements will depend, in part, on our future cash flows, which are determined by our future operating performance and, therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001730168-26-000054:mdna:62]
We believe that our cash and cash equivalents on hand, cash flows from operations and our revolving credit facility will provide sufficient liquidity to operate our business and fund our current obligations for at least the next 12 months. For additional information regarding our cash requirement from indebtedness, contractual commitments and backstops, see Note 6. “Borrowings,” Note 10. “Commitments and Contingencies” and Note 11. “Subsequent Events” in Part I, Item 1 of this Form 10-Q, as well as our disclosure in Part II, Item 5 of this Form 10-Q.

[0001730168-26-000054:mdna:63]
From time to time, we engage in discussions with third parties regarding potential acquisitions of, or investments in, businesses, technologies and product lines. Any such transaction, or evaluation of potential transactions, could require significant use of our cash and cash equivalents, or require us to increase our borrowings to fund such transactions. If we do not have sufficient cash to fund our operations or finance growth opportunities, including acquisitions, expansions of new business strategies and models, or unanticipated capital expenditures, our business and financial condition could suffer. In addition, we may agree to financial obligations, including backstops, or increase our exposure to credit or customer default risks to support our strategic initiatives or other corporate purposes. In such circumstances, we may seek to obtain new debt or equity financing. However, we cannot assure you that such additional financing will be available on terms acceptable to us or at all. Our ability to service our outstanding indebtedness and any other indebtedness we may incur will depend on our ability to generate cash in the future. We may also elect to issue additional debt or equity securities for reasons other than those specified above. From time to time, we manage our indebtedness through financings, redemptions, repayments, exchanges, tender offers and other transactions. Such transactions will depend on prevailing market conditions, our liquidity requirements, the terms of indentures, contractual restrictions and other factors.

[0001730168-26-000054:mdna:64]
[same as prior period, unchanged from 0001730168-26-000016:mdna:58]

[0001730168-26-000054:mdna:65]
Working capital increased to $23,351 million at May 3, 2026 from $13,059 million at November 2, 2025. The increase was primarily attributable to the following:

[0001730168-26-000054:mdna:66]
•Trade accounts receivable, net increased to $10,830 million at May 3, 2026 from $7,145 million at November 2, 2025 primarily due to higher semiconductor revenue, the timing of billings and lower receivables sold through factoring arrangements.

[0001730168-26-000054:mdna:67]
•Cash and cash equivalents increased to $19,628 million at May 3, 2026 from $16,178 million at November 2, 2025, primarily due to $18,753 million in net cash provided by operating activities, offset in part by $8,450 million of stock repurchases and $6,178 million of dividend payments.

[0001730168-26-000054:mdna:68]
•Inventory increased to $4,328 million at May 3, 2026 from $2,270 million at November 2, 2025 primarily to support higher expected shipments for custom AI accelerators.

[0001730168-26-000054:mdna:69]
•Other current assets increased to $7,427 million at May 3, 2026 from $5,980 million at November 2, 2025 primarily from higher software contract assets and prepaid taxes.

[0001730168-26-000054:mdna:70]
[same as prior period, unchanged from 0001730168-26-000016:mdna:62]

[0001730168-26-000054:mdna:71]
29

[0001730168-26-000054:mdna:72]
•Other current liabilities increased to $13,139 million at May 3, 2026 from $11,673 million at November 2, 2025 primarily from higher contract liabilities.

[0001730168-26-000054:mdna:73]
[same as prior period, unchanged from 0001730168-26-000016:mdna:65]

[0001730168-26-000054:mdna:74]
|  |  | Two Fiscal Quarters Ended |
| Cash Dividends Declared and Paid |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 1.30 |  |  | $ | 1.18 |  |
| Dividends to common stockholders |  | $ | 6,178 |  |  | $ | 5,559 |  |

[0001730168-26-000054:mdna:75]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock through December 31, 2025, which was subsequently extended through December 31, 2026 and increased to $11 billion. In March 2026, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2026. During the two fiscal quarters ended May 3, 2026 and May 4, 2025, we repurchased and retired 25 million and 16 million shares for $8,450 million and $2,450 million, respectively. As of May 3, 2026, $10.1 billion of the authorized amount remained available for repurchase.

[0001730168-26-000054:mdna:76]
During the two fiscal quarters ended May 4, 2025, we paid $3,802 million in employee withholding taxes due upon the vesting of net settled equity awards and withheld 17 million shares from employees in connection with such net share settlements. In the current year fiscal period, we settled withholding taxes upon the vesting of employee equity awards using proceeds from the sale of a portion of the vested shares.

[0001730168-26-000054:mdna:77]
[same as prior period, unchanged from 0001730168-26-000016:mdna:70]

[0001730168-26-000054:mdna:78]
|  |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |
| Net cash provided by operating activities |  | $ | 18,753 |  |  | $ | 12,668 |  |
| Net cash used in investing activities |  | (323) |  |  | (307) |  |
| Net cash used in financing activities |  | (14,980) |  |  | (12,237) |  |
| Net change in cash and cash equivalents |  | $ | 3,450 |  |  | $ | 124 |  |

[0001730168-26-000054:mdna:79]
[same as prior period, unchanged from 0001730168-26-000016:mdna:72]

[0001730168-26-000054:mdna:80]
Cash flows from operating activities consist of net income adjusted for certain non-cash and other items and changes in assets and liabilities. The $6,085 million increase in cash provided by operations during the two fiscal quarters ended May 3, 2026 compared to the prior year fiscal period was primarily due to $6,191 million higher net income and $1,310 million higher non-cash adjustments primarily from higher stock-based compensation, offset in part by $1,416 million from changes in operating assets and liabilities.

[0001730168-26-000054:mdna:81]
[same as prior period, unchanged from 0001730168-26-000016:mdna:74]

[0001730168-26-000054:mdna:82]
Cash flows from investing activities primarily consist of capital expenditures and proceeds and payments related to investments. The cash flows from investing activities during the two fiscal quarters ended May 3, 2026 were relatively flat compared to the prior year fiscal period as higher capital expenditures in the current year fiscal period was substantially offset by an increase in net proceeds from investments compared to the prior year fiscal period.

[0001730168-26-000054:mdna:83]
[same as prior period, unchanged from 0001730168-26-000016:mdna:76]

[0001730168-26-000054:mdna:84]
Cash flows from financing activities primarily consist of proceeds and payments related to our borrowings, dividend payments, authorized stock repurchases, and employee withholding tax payments related to net settled equity awards. The $2,743 million increase in cash used in financing activities during the two fiscal quarters ended May 3, 2026 compared to the prior year fiscal period was primarily due to a $6,000 million increase in stock repurchases, offset in part by $3,802 million of employee withholding tax payments related to net settled equity awards in the prior year fiscal period.
