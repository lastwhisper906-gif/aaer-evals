# AVGO note change history — 0001730168-26-000016 → 0001730168-26-000054


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001730168-26-000054:note_history:1]
The following table summarizes contractual commitments as of May 3, 2026:
  (was, 2026-03-11, similarity 0.8553):
[0001730168-26-000016:note_history:1]
The following table summarizes contractual obligations and commitments as of February 1, 2026:

- changed (2026-06-09):
[0001730168-26-000054:note_history:2]
Purchase Commitments. Represent unconditional purchase commitments to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase commitments exclude agreements that are cancelable without penalty and unconditional purchase commitments with a remaining term of one year or less.
  (was, 2026-03-11, similarity 0.9372):
[0001730168-26-000016:note_history:2]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

- changed (2026-06-09):
[0001730168-26-000054:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 3, 2026, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,662 million of unrecognized tax benefits and accrued interest and penalties as of May 3, 2026 have been excluded from the table above.
  (was, 2026-03-11, similarity 0.9771):
[0001730168-26-000016:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 1, 2026, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,668 million of unrecognized tax benefits and accrued interest and penalties as of February 1, 2026 have been excluded from the table above.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001730168-26-000054:note_history:4]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, and subsystems. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.
  (was, 2026-03-11, similarity 0.9865):
[0001730168-26-000016:note_history:4]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, subsystems and, in some cases, racks. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.

- changed (2026-06-09):
[0001730168-26-000054:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 2, 2025 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2025 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 3, 2026 are not necessarily indicative of the results that may be expected for fiscal year 2026, or for any other future period.
  (was, 2026-03-11, similarity 0.9955):
[0001730168-26-000016:note_history:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 2, 2025 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2025 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 1, 2026 are not necessarily indicative of the results that may be expected for fiscal year 2026, or for any other future period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001730168-26-000054:note_history:6]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
  (was, 2026-03-11, similarity 0.9976):
[0001730168-26-000016:note_history:6]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:7]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,214 |  |  | 7,232 |  |
| 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | — |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,500 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 64,970 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
  (was, 2026-03-11, similarity 0.8776):
[0001730168-26-000016:note_history:7]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
|  |  |  |  | 752 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 3,856 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 66,220 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:8]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total debt principal outstanding |  |  |  | 66,720 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,813) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 62,655 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |
  (was, 2026-03-11, similarity 0.9253):
[0001730168-26-000016:note_history:8]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
| Total debt principal outstanding |  |  |  | 67,970 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,913) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 63,805 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:9]
During the fiscal quarter ended February 1, 2026, we issued senior unsecured notes for an aggregate principal amount of $4,500 million and repaid and redeemed a total of $3,650 million of our senior notes. During the fiscal quarter ended May 3, 2026, we redeemed $1,250 million of our senior notes.

- changed (2026-06-09):
[0001730168-26-000054:note_history:10]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. We had no borrowings outstanding under our revolving credit facility at either May 3, 2026 or November 2, 2025.
  (was, 2026-03-11, similarity 0.9681):
[0001730168-26-000016:note_history:10]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. We had no borrowings outstanding under our revolving credit facility at either February 1, 2026 or November 2, 2025.

- changed (2026-06-09):
[0001730168-26-000054:note_history:11]
Under our commercial paper program, we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either May 3, 2026 or November 2, 2025.
  (was, 2026-03-11, similarity 0.9928):
[0001730168-26-000016:note_history:11]
Under our commercial paper program, we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either February 1, 2026 or November 2, 2025.

- changed (2026-06-09):
[0001730168-26-000054:note_history:12]
As of May 3, 2026, the estimated aggregate fair value of our debt was $62,505 million, which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments in the fair value hierarchy.
  (was, 2026-03-11, similarity 0.9273):
[0001730168-26-000016:note_history:12]
As of February 1, 2026, the estimated aggregate fair value of our debt was $65,738 million, which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments.

- changed (2026-06-09):
[0001730168-26-000054:note_history:13]
The future scheduled principal payments of our debt as of May 3, 2026 were as follows:
  (was, 2026-03-11, similarity 0.9586):
[0001730168-26-000016:note_history:13]
The future scheduled principal payments of our debt as of February 1, 2026 were as follows:

- changed (2026-06-09):
[0001730168-26-000054:note_history:14]
As of May 3, 2026 and November 2, 2025, we were in compliance with all debt covenants.
  (was, 2026-03-11, similarity 0.956):
[0001730168-26-000016:note_history:14]
As of February 1, 2026 and November 2, 2025, we were in compliance with all debt covenants.

- removed (2026-06-09):
[0001730168-26-000016:note_history:15]
In January 2026, we issued senior unsecured notes for an aggregate principal amount of $4,500 million. During the fiscal quarter ended February 1, 2026, we repaid and redeemed a total of $3,650 million of our senior notes.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001730168-26-000054:note_history:16]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
  (was, 2026-03-11, similarity 0.9976):
[0001730168-26-000016:note_history:16]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:17]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,214 |  |  | 7,232 |  |
| 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | — |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,500 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 64,970 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
  (was, 2026-03-11, similarity 0.8776):
[0001730168-26-000016:note_history:17]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
|  |  |  |  | 752 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 3,856 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 66,220 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:18]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total debt principal outstanding |  |  |  | 66,720 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,813) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 62,655 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |
  (was, 2026-03-11, similarity 0.9253):
[0001730168-26-000016:note_history:18]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
| Total debt principal outstanding |  |  |  | 67,970 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,913) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 63,805 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-06-09):
[0001730168-26-000054:note_history:19]
The future scheduled principal payments of our debt as of May 3, 2026 were as follows:
  (was, 2026-03-11, similarity 0.9586):
[0001730168-26-000016:note_history:19]
The future scheduled principal payments of our debt as of February 1, 2026 were as follows:


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001730168-26-000054:note_history:20]
|  |  | Fiscal Quarter Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,187 |  |  | $ | 13,956 |  |  | $ | 749 |  |  | $ | 16,892 |  |
| Subscriptions and services |  | 3,015 |  |  | 579 |  |  | 1,701 |  |  | 5,295 |  |
| Total |  | $ | 5,202 |  |  | $ | 14,535 |  |  | $ | 2,450 |  |  | $ | 22,187 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:21]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,891 |  |  | $ | 7,632 |  |  | $ | 786 |  |  | $ | 10,309 |  |
| Subscriptions and services |  | 2,815 |  |  | 468 |  |  | 1,412 |  |  | 4,695 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:22]
|  |  | Two Fiscal Quarters Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 4,351 |  |  | $ | 24,906 |  |  | $ | 1,765 |  |  | $ | 31,022 |  |
| Subscriptions and services |  | 5,932 |  |  | 1,244 |  |  | 3,300 |  |  | 10,476 |  |
| Total |  | $ | 10,283 |  |  | $ | 26,150 |  |  | $ | 5,065 |  |  | $ | 41,498 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:23]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 3,826 |  |  | $ | 14,965 |  |  | $ | 1,661 |  |  | $ | 20,452 |  |
| Subscriptions and services |  | 5,512 |  |  | 1,167 |  |  | 2,789 |  |  | 9,468 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

- removed (2026-06-09):
[0001730168-26-000016:note_history:24]
|  |  | Fiscal Quarter Ended February 1, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,164 |  |  | $ | 10,950 |  |  | $ | 1,016 |  |  | $ | 14,130 |  |
| Subscriptions and services |  | 2,917 |  |  | 665 |  |  | 1,599 |  |  | 5,181 |  |
| Total |  | $ | 5,081 |  |  | $ | 11,615 |  |  | $ | 2,615 |  |  | $ | 19,311 |  |

- removed (2026-06-09):
[0001730168-26-000016:note_history:25]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,935 |  |  | $ | 7,333 |  |  | $ | 875 |  |  | $ | 10,143 |  |
| Subscriptions and services |  | 2,697 |  |  | 699 |  |  | 1,377 |  |  | 4,773 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001730168-26-000054:note_history:26]
For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue. In the fiscal quarter and two fiscal quarters ended May 3, 2026, we included upfront license revenue of $1,964 million and $3,719 million, respectively, within products revenue, and the related costs, which were immaterial, in cost of products sold, in our condensed consolidated statements of operations. To conform to the current period presentation, we reclassified $1,803 million and $3,775 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. We also reclassified the related costs for the upfront license revenue, which were immaterial for the periods presented.

- changed (2026-06-09):
[0001730168-26-000054:note_history:27]
In the revenue disaggregation tables by type and by region presented below, we included $1,456 million, $137 million and $371 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended May 3, 2026. We included $2,517 million, $261 million and $941 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the two fiscal quarters ended May 3, 2026.
  (was, 2026-03-11, similarity 0.878):
[0001730168-26-000016:note_history:27]
In the revenue disaggregation tables by type and by region presented below, we included $1,061 million, $124 million and $570 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 1, 2026. To conform to the current period presentation, we reclassified $1,445 million, $64 million and $463 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 2, 2025.

- added (2026-06-09):
[0001730168-26-000054:note_history:28]
To conform to the current period presentation, we reclassified $1,256 million, $178 million and $369 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended May 4, 2025. We reclassified $2,701 million, $242 million and $832 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the two fiscal quarters ended May 4, 2025.

- added (2026-06-09):
[0001730168-26-000054:note_history:29]
|  |  | Fiscal Quarter Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,187 |  |  | $ | 13,956 |  |  | $ | 749 |  |  | $ | 16,892 |  |
| Subscriptions and services |  | 3,015 |  |  | 579 |  |  | 1,701 |  |  | 5,295 |  |
| Total |  | $ | 5,202 |  |  | $ | 14,535 |  |  | $ | 2,450 |  |  | $ | 22,187 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:30]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,891 |  |  | $ | 7,632 |  |  | $ | 786 |  |  | $ | 10,309 |  |
| Subscriptions and services |  | 2,815 |  |  | 468 |  |  | 1,412 |  |  | 4,695 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:31]
|  |  | Two Fiscal Quarters Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 4,351 |  |  | $ | 24,906 |  |  | $ | 1,765 |  |  | $ | 31,022 |  |
| Subscriptions and services |  | 5,932 |  |  | 1,244 |  |  | 3,300 |  |  | 10,476 |  |
| Total |  | $ | 10,283 |  |  | $ | 26,150 |  |  | $ | 5,065 |  |  | $ | 41,498 |  |

- added (2026-06-09):
[0001730168-26-000054:note_history:32]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 3,826 |  |  | $ | 14,965 |  |  | $ | 1,661 |  |  | $ | 20,452 |  |
| Subscriptions and services |  | 5,512 |  |  | 1,167 |  |  | 2,789 |  |  | 9,468 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:33]
|  |  | May 3,2026 |  | November 2,2025 |
|  | (In millions) |
| Contract Assets |  | $ | 10,399 |  |  | $ | 8,922 |  |
| Contract Liabilities |  | $ | 14,242 |  |  | $ | 13,016 |  |
  (was, 2026-03-11, similarity 0.9756):
[0001730168-26-000016:note_history:33]
|  |  | February 1,2026 |  | November 2,2025 |
|  | (In millions) |
| Contract Assets |  | $ | 9,347 |  |  | $ | 8,922 |  |
| Contract Liabilities |  | $ | 12,855 |  |  | $ | 13,016 |  |

- changed (2026-06-09):
[0001730168-26-000054:note_history:34]
As of May 3, 2026, approximately 64% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 3, 2026 that was included in the contract liabilities balance as of November 2, 2025 was $6,445 million. The amount of revenue recognized during the two fiscal quarters ended May 4, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $6,103 million.
  (was, 2026-03-11, similarity 0.6032):
[0001730168-26-000016:note_history:34]
As of February 1, 2026, approximately 67% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 1, 2026 that was included in the contract liabilities balance as of November 2, 2025 was $3,915 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $3,583 million.

- added (2026-06-09):
[0001730168-26-000054:note_history:35]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods. Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of May 3, 2026 were approximately $164.6 billion. These commitments include obligations under a long-term contract for custom AI accelerators entered in the fiscal quarter ended May 3, 2026. We expect approximately 30% of this amount to be recognized as revenue over the next 12 months.

- added (2026-06-09):
[0001730168-26-000054:note_history:36]
Remaining performance obligations do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract permits termination for convenience. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”). Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2026-06-09):
[0001730168-26-000016:note_history:37]
For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue. In the fiscal quarter ended February 1, 2026, we included upfront license revenue of $1,755 million within products revenue, and the related costs, which were immaterial, in cost of products sold, in our condensed consolidated statements of operations. To conform to the current period presentation, we reclassified $1,972 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter ended February 2, 2025. We also reclassified the related costs for the upfront license revenue, which were immaterial.

- removed (2026-06-09):
[0001730168-26-000016:note_history:38]
|  |  | Fiscal Quarter Ended February 1, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,164 |  |  | $ | 10,950 |  |  | $ | 1,016 |  |  | $ | 14,130 |  |
| Subscriptions and services |  | 2,917 |  |  | 665 |  |  | 1,599 |  |  | 5,181 |  |
| Total |  | $ | 5,081 |  |  | $ | 11,615 |  |  | $ | 2,615 |  |  | $ | 19,311 |  |

- removed (2026-06-09):
[0001730168-26-000016:note_history:39]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,935 |  |  | $ | 7,333 |  |  | $ | 875 |  |  | $ | 10,143 |  |
| Subscriptions and services |  | 2,697 |  |  | 699 |  |  | 1,377 |  |  | 4,773 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

- removed (2026-06-09):
[0001730168-26-000016:note_history:40]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods, but do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract permits termination for convenience. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”).

- removed (2026-06-09):
[0001730168-26-000016:note_history:41]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of February 1, 2026 were approximately $45.0 billion. We expect approximately 33% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2026-06-09):
[0001730168-26-000054:note_history:42]
Subsequent Events
On June 8, 2026, we arranged for an investor partner to take on certain agreements to purchase AI racks based on custom AI accelerators designed by us and the related lease agreements with a customer that enable access to compute capacity. In connection with the arrangement, we entered into a backstop agreement with the investor partner for the customer’s lease obligations over 5-year terms. The backstop will increase over time as the AI racks are deployed and decrease as the customer makes payments on its lease obligations, with a maximum exposure of $29 billion. In the event of default by the customer, we have various remedies, including the assumption of the lease or effecting a sale of the AI racks, which would reduce our maximum exposure.

- changed (2026-06-09):
[0001730168-26-000054:note_history:43]
Cash Dividends Declared
  (was, 2026-03-11, similarity 0.7188):
[0001730168-26-000016:note_history:43]
Subsequent Events
Cash Dividends Declared

- changed (2026-06-09):
[0001730168-26-000054:note_history:44]
On June 2, 2026, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on June 30, 2026 to stockholders of record on June 22, 2026.
  (was, 2026-03-11, similarity 0.9184):
[0001730168-26-000016:note_history:44]
On March 3, 2026, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on March 31, 2026 to stockholders of record on March 23, 2026.
