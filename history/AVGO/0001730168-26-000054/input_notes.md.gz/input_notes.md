# AVGO notes — 0001730168-26-000054


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-26-000054:notes:1]
[same as prior period, unchanged from 0001730168-26-000016:notes:1]

[0001730168-26-000054:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, and subsystems. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.

[0001730168-26-000054:notes:3]
[same as prior period, unchanged from 0001730168-26-000016:notes:3]

[0001730168-26-000054:notes:4]
[same as prior period, unchanged from 0001730168-26-000016:notes:4]

[0001730168-26-000054:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 2, 2025 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2025 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended May 3, 2026 are not necessarily indicative of the results that may be expected for fiscal year 2026, or for any other future period.

[0001730168-26-000054:notes:6]
[same as prior period, unchanged from 0001730168-26-000016:notes:6]

[0001730168-26-000054:notes:7]
[same as prior period, unchanged from 0001730168-26-000016:notes:7]

[0001730168-26-000054:notes:8]
[same as prior period, unchanged from 0001730168-26-000016:notes:8]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-26-000054:notes:9]
[same as prior period, unchanged from 0001730168-26-000016:notes:9]

[0001730168-26-000054:notes:10]
[same as prior period, unchanged from 0001730168-26-000016:notes:10]

[0001730168-26-000054:notes:11]
For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue. In the fiscal quarter and two fiscal quarters ended May 3, 2026, we included upfront license revenue of $1,964 million and $3,719 million, respectively, within products revenue, and the related costs, which were immaterial, in cost of products sold, in our condensed consolidated statements of operations. To conform to the current period presentation, we reclassified $1,803 million and $3,775 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. We also reclassified the related costs for the upfront license revenue, which were immaterial for the periods presented.

[0001730168-26-000054:notes:12]
In the revenue disaggregation tables by type and by region presented below, we included $1,456 million, $137 million and $371 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended May 3, 2026. We included $2,517 million, $261 million and $941 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the two fiscal quarters ended May 3, 2026.

[0001730168-26-000054:notes:13]
To conform to the current period presentation, we reclassified $1,256 million, $178 million and $369 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended May 4, 2025. We reclassified $2,701 million, $242 million and $832 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the two fiscal quarters ended May 4, 2025.

[0001730168-26-000054:notes:14]
[same as prior period, unchanged from 0001730168-26-000016:notes:13]

[0001730168-26-000054:notes:15]
[same as prior period, unchanged from 0001730168-26-000016:notes:14]

[0001730168-26-000054:notes:16]
[same as prior period, unchanged from 0001730168-26-000016:notes:15]

[0001730168-26-000054:notes:17]
|  |  | Fiscal Quarter Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,187 |  |  | $ | 13,956 |  |  | $ | 749 |  |  | $ | 16,892 |  |
| Subscriptions and services |  | 3,015 |  |  | 579 |  |  | 1,701 |  |  | 5,295 |  |
| Total |  | $ | 5,202 |  |  | $ | 14,535 |  |  | $ | 2,450 |  |  | $ | 22,187 |  |

[0001730168-26-000054:notes:18]
|  |  | Fiscal Quarter Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,891 |  |  | $ | 7,632 |  |  | $ | 786 |  |  | $ | 10,309 |  |
| Subscriptions and services |  | 2,815 |  |  | 468 |  |  | 1,412 |  |  | 4,695 |  |
| Total |  | $ | 4,706 |  |  | $ | 8,100 |  |  | $ | 2,198 |  |  | $ | 15,004 |  |

[0001730168-26-000054:notes:19]
|  |  | Two Fiscal Quarters Ended May 3, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 4,351 |  |  | $ | 24,906 |  |  | $ | 1,765 |  |  | $ | 31,022 |  |
| Subscriptions and services |  | 5,932 |  |  | 1,244 |  |  | 3,300 |  |  | 10,476 |  |
| Total |  | $ | 10,283 |  |  | $ | 26,150 |  |  | $ | 5,065 |  |  | $ | 41,498 |  |

[0001730168-26-000054:notes:20]
|  |  | Two Fiscal Quarters Ended May 4, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 3,826 |  |  | $ | 14,965 |  |  | $ | 1,661 |  |  | $ | 20,452 |  |
| Subscriptions and services |  | 5,512 |  |  | 1,167 |  |  | 2,789 |  |  | 9,468 |  |
| Total |  | $ | 9,338 |  |  | $ | 16,132 |  |  | $ | 4,450 |  |  | $ | 29,920 |  |

[0001730168-26-000054:notes:21]
[same as prior period, unchanged from 0001730168-26-000016:notes:18]

[0001730168-26-000054:notes:22]
[same as prior period, unchanged from 0001730168-26-000016:notes:19]

[0001730168-26-000054:notes:23]
[same as prior period, unchanged from 0001730168-26-000016:notes:20]

[0001730168-26-000054:notes:24]
|  |  | May 3,2026 |  | November 2,2025 |
|  | (In millions) |
| Contract Assets |  | $ | 10,399 |  |  | $ | 8,922 |  |
| Contract Liabilities |  | $ | 14,242 |  |  | $ | 13,016 |  |

[0001730168-26-000054:notes:25]
[same as prior period, unchanged from 0001730168-26-000016:notes:22]

[0001730168-26-000054:notes:26]
[same as prior period, unchanged from 0001730168-26-000016:notes:23]

[0001730168-26-000054:notes:27]
As of May 3, 2026, approximately 64% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the two fiscal quarters ended May 3, 2026 that was included in the contract liabilities balance as of November 2, 2025 was $6,445 million. The amount of revenue recognized during the two fiscal quarters ended May 4, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $6,103 million.

[0001730168-26-000054:notes:28]
[same as prior period, unchanged from 0001730168-26-000016:notes:25]

[0001730168-26-000054:notes:29]
Revenue allocated to remaining performance obligations represents the transaction price allocated to unsatisfied or partially unsatisfied performance obligations. Remaining performance obligations include unearned revenue and amounts that will be invoiced and recognized as revenue in future periods. Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of May 3, 2026 were approximately $164.6 billion. These commitments include obligations under a long-term contract for custom AI accelerators entered in the fiscal quarter ended May 3, 2026. We expect approximately 30% of this amount to be recognized as revenue over the next 12 months.

[0001730168-26-000054:notes:30]
Remaining performance obligations do not include contracts for software, subscriptions or services where the customer is not committed. The customer is not considered committed when the customer contract permits termination for convenience. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Additionally, as a practical expedient, we have not included contracts that have an original duration of one year or less, nor have we included contracts with sales-based or usage-based royalties promised in exchange for a license of intellectual property (“IP”). Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-26-000054:notes:31]
[same as prior period, unchanged from 0001730168-26-000016:notes:28]

[0001730168-26-000054:notes:32]
Cash equivalents included $4,003 million and $3,163 million of time deposits and $2,801 million and $2,239 million of money-market funds as of May 3, 2026 and November 2, 2025, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-26-000054:notes:33]
As of May 3, 2026, cash equivalents also included $2,985 million of U.S. Treasury Bills which were carried at fair value. Due to the short-term nature of the instruments, their amortized cost approximates fair value. As of May 3, 2026, $995 million and $1,990 million of the U.S. Treasury Bills were classified as Level 1 assets and Level 2 assets in the fair value hierarchy, respectively, depending on whether the instruments were traded in active or less active markets.

[0001730168-26-000054:notes:34]
[same as prior period, unchanged from 0001730168-26-000016:notes:30]

[0001730168-26-000054:notes:35]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $600 million and $2,350 million during the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, and $1,750 million and $3,951 million during the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively.

[0001730168-26-000054:notes:36]
[same as prior period, unchanged from 0001730168-26-000016:notes:32]

[0001730168-26-000054:notes:37]
|  |  | May 3,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Finished goods |  | $ | 1,858 |  |  | $ | 682 |  |
| Work-in-process |  | 1,801 |  |  | 1,280 |  |
| Raw materials |  | 669 |  |  | 308 |  |
| Total inventory |  | $ | 4,328 |  |  | $ | 2,270 |  |

[0001730168-26-000054:notes:38]
[same as prior period, unchanged from 0001730168-26-000016:notes:34]

[0001730168-26-000054:notes:39]
|  |  | May 3,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 5,918 |  |  | $ | 5,005 |  |
| Prepaid expenses |  | 1,140 |  |  | 518 |  |
| Other |  | 369 |  |  | 457 |  |
| Total other current assets |  | $ | 7,427 |  |  | $ | 5,980 |  |

[0001730168-26-000054:notes:40]
[same as prior period, unchanged from 0001730168-26-000016:notes:36]

[0001730168-26-000054:notes:41]
|  |  | May 3,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 10,038 |  |  | $ | 9,469 |  |
| Tax liabilities |  | 1,217 |  |  | 921 |  |
| Interest payable |  | 656 |  |  | 620 |  |
| Other |  | 1,228 |  |  | 663 |  |
| Total other current liabilities |  | $ | 13,139 |  |  | $ | 11,673 |  |

[0001730168-26-000054:notes:42]
[same as prior period, unchanged from 0001730168-26-000016:notes:38]

[0001730168-26-000054:notes:43]
|  |  | May 3,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 4,204 |  |  | $ | 3,547 |  |
| Unrecognized tax benefits |  | 1,662 |  |  | 1,628 |  |
| Deferred tax liabilities |  | 1,615 |  |  | 2,704 |  |
| Other |  | 2,469 |  |  | 1,423 |  |
| Total other long-term liabilities |  | $ | 9,950 |  |  | $ | 9,302 |  |

[0001730168-26-000054:notes:44]
[same as prior period, unchanged from 0001730168-26-000016:notes:40]

[0001730168-26-000054:notes:45]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |
| Cash paid for interest |  | $ | 695 |  |  | $ | 700 |  |  | $ | 1,314 |  |  | $ | 1,371 |  |
| Cash paid for income taxes |  | $ | 1,099 |  |  | $ | 608 |  |  | $ | 1,881 |  |  | $ | 1,012 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-26-000054:notes:46]
[same as prior period, unchanged from 0001730168-26-000016:notes:42]

[0001730168-26-000054:notes:47]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of May 3, 2026: |  |  |  |  |  |  |
| Purchased technology |  | $ | 32,851 |  |  | $ | (17,322) |  |  | $ | 15,529 |  |
| Customer contracts and related relationships |  | 15,791 |  |  | (4,961) |  |  | 10,830 |  |
| Trade names |  | 1,612 |  |  | (455) |  |  | 1,157 |  |
| Other |  | 188 |  |  | (121) |  |  | 67 |  |
| Intangible assets subject to amortization |  | 50,442 |  |  | (22,859) |  |  | 27,583 |  |
| In-process research and development |  | 750 |  |  | — |  |  | 750 |  |
| Total |  | $ | 51,192 |  |  | $ | (22,859) |  |  | $ | 28,333 |  |
| As of November 2, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 32,781 |  |  | $ | (14,401) |  |  | $ | 18,380 |  |
| Customer contracts and related relationships |  | 15,791 |  |  | (4,003) |  |  | 11,788 |  |
| Trade names |  | 1,612 |  |  | (399) |  |  | 1,213 |  |
| Other |  | 186 |  |  | (114) |  |  | 72 |  |
| Intangible assets subject to amortization |  | 50,370 |  |  | (18,917) |  |  | 31,453 |  |
| In-process research and development |  | 820 |  |  | — |  |  | 820 |  |
| Total |  | $ | 51,190 |  |  | $ | (18,917) |  |  | $ | 32,273 |  |

[0001730168-26-000054:notes:48]
Based on the amount of intangible assets subject to amortization as of May 3, 2026, the expected amortization expense was as follows:

[0001730168-26-000054:notes:49]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 3,940 |  |
| 2027 |  | 6,818 |  |
| 2028 |  | 5,689 |  |
| 2029 |  | 4,562 |  |
| 2030 |  | 3,378 |  |
| Thereafter |  | 3,196 |  |
| Total |  | $ | 27,583 |  |

[0001730168-26-000054:notes:50]
[same as prior period, unchanged from 0001730168-26-000016:notes:46]

[0001730168-26-000054:notes:51]
| Amortizable intangible assets: |  | May 3,2026 |
|  |  | (In years) |
| Purchased technology |  | 5 |
| Customer contracts and related relationships |  | 6 |
| Trade names |  | 11 |
| Other |  | 10 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-26-000054:notes:52]
[same as prior period, unchanged from 0001730168-26-000016:notes:48]

[0001730168-26-000054:notes:53]
[same as prior period, unchanged from 0001730168-26-000016:notes:49]

[0001730168-26-000054:notes:54]
[same as prior period, unchanged from 0001730168-26-000016:notes:50]

[0001730168-26-000054:notes:55]
[same as prior period, unchanged from 0001730168-26-000016:notes:51]

[0001730168-26-000054:notes:56]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,310 |  |  | $ | 4,965 |  |  | $ | 16,659 |  |  | $ | 10,468 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,747 |  |  | 4,707 |  |  | 4,744 |  |  | 4,701 |  |
| Dilutive effect of equity awards |  | 129 |  |  | 119 |  |  | 138 |  |  | 130 |  |
| Weighted-average shares outstanding - diluted |  | 4,876 |  |  | 4,826 |  |  | 4,882 |  |  | 4,831 |  |

[0001730168-26-000054:notes:57]
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.96 |  |  | $ | 1.05 |  |  | $ | 3.51 |  |  | $ | 2.23 |  |
| Diluted |  | $ | 1.91 |  |  | $ | 1.03 |  |  | $ | 3.41 |  |  | $ | 2.17 |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-26-000054:notes:58]
Borrowings

[0001730168-26-000054:notes:59]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

[0001730168-26-000054:notes:60]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 5,214 |  |  | 7,232 |  |
| 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | — |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,500 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 64,970 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |

[0001730168-26-000054:notes:61]
|  |  | Effective Interest Rate |  | May 3,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total debt principal outstanding |  |  |  | 66,720 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,813) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 62,655 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 64,907 |  |  | $ | 65,136 |  |

[0001730168-26-000054:notes:62]
__________________________

[0001730168-26-000054:notes:63]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate includes the impact of previously deferred gains on derivatives.

[0001730168-26-000054:notes:64]
Senior Notes

[0001730168-26-000054:notes:65]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. With the exception of the senior notes issued in September 2025 and January 2026, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Interest is paid semi-annually.

[0001730168-26-000054:notes:66]
During the fiscal quarter ended February 1, 2026, we issued senior unsecured notes for an aggregate principal amount of $4,500 million and repaid and redeemed a total of $3,650 million of our senior notes. During the fiscal quarter ended May 3, 2026, we redeemed $1,250 million of our senior notes.

[0001730168-26-000054:notes:67]
Fixed-Rate Term Loans

[0001730168-26-000054:notes:68]
Interest on the term loans is due quarterly. We are permitted to prepay the term loans at any time, subject to a specified make-whole premium determined in accordance with the credit agreements governing the respective term loans, plus accrued and unpaid interest.

[0001730168-26-000054:notes:69]
2025 Credit Agreement

[0001730168-26-000054:notes:70]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. We had no borrowings outstanding under our revolving credit facility at either May 3, 2026 or November 2, 2025.

[0001730168-26-000054:notes:71]
Commercial Paper

[0001730168-26-000054:notes:72]
Under our commercial paper program, we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either May 3, 2026 or November 2, 2025.

[0001730168-26-000054:notes:73]
Fair Value of Debt

[0001730168-26-000054:notes:74]
As of May 3, 2026, the estimated aggregate fair value of our debt was $62,505 million, which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments in the fair value hierarchy.

[0001730168-26-000054:notes:75]
Future Principal Payments of Debt

[0001730168-26-000054:notes:76]
The future scheduled principal payments of our debt as of May 3, 2026 were as follows:

[0001730168-26-000054:notes:77]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 2,252 |  |
| 2027 |  | 493 |  |
| 2028 |  | 5,127 |  |
| 2029 |  | 4,655 |  |
| 2030 |  | 6,406 |  |
| Thereafter |  | 47,787 |  |
| Total |  | $ | 66,720 |  |

[0001730168-26-000054:notes:78]
As of May 3, 2026 and November 2, 2025, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-26-000054:notes:79]
[same as prior period, unchanged from 0001730168-26-000016:notes:75]

[0001730168-26-000054:notes:80]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.65 |  |  | $ | 0.59 |  |  | $ | 1.30 |  |  | $ | 1.18 |  |
| Dividends to common stockholders |  | $ | 3,092 |  |  | $ | 2,785 |  |  | $ | 6,178 |  |  | $ | 5,559 |  |

[0001730168-26-000054:notes:81]
[same as prior period, unchanged from 0001730168-26-000016:notes:77]

[0001730168-26-000054:notes:82]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock through December 31, 2025, which was subsequently extended through December 31, 2026 and increased to $11 billion. In March 2026, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2026. We repurchased and retired 2 million and 25 million shares for $600 million and $8,450 million during the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively. We also repurchased 16 million shares for $2,450 million during the fiscal quarter ended May 4, 2025. As of May 3, 2026, $10.1 billion of the authorized amount remained available for repurchase.

[0001730168-26-000054:notes:83]
[same as prior period, unchanged from 0001730168-26-000016:notes:80]

[0001730168-26-000054:notes:84]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |
| Cost of products sold |  | $ | 64 |  |  | $ | 50 |  |  | $ | 130 |  |  | $ | 83 |  |
| Cost of subscriptions and services |  | 159 |  |  | 153 |  |  | 329 |  |  | 273 |  |
| Research and development |  | 1,395 |  |  | 1,169 |  |  | 2,842 |  |  | 1,991 |  |
| Selling, general and administrative |  | 474 |  |  | 399 |  |  | 967 |  |  | 704 |  |
| Total stock-based compensation expense |  | $ | 2,092 |  |  | $ | 1,771 |  |  | $ | 4,268 |  |  | $ | 3,051 |  |

[0001730168-26-000054:notes:85]
[same as prior period, unchanged from 0001730168-26-000016:notes:82]

[0001730168-26-000054:notes:86]
As of May 3, 2026, the total unrecognized compensation cost related to unvested stock-based awards was $20,106 million, which is expected to be recognized over the remaining weighted-average service period of 3.0 years.

[0001730168-26-000054:notes:87]
[same as prior period, unchanged from 0001730168-26-000016:notes:84]

[0001730168-26-000054:notes:88]
[same as prior period, unchanged from 0001730168-26-000016:notes:85]

[0001730168-26-000054:notes:89]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 2, 2025 |  | 229 |  |  | $ | 127.63 |  |  |  |  |  |
| Granted |  | 4 |  |  | $ | 323.86 |  |  |  |  |  |
| Vested |  | (41) |  |  | $ | 85.50 |  |  |  |  |  |
| Forfeited |  | (9) |  |  | $ | 137.42 |  |  |  |  |  |
| Balance as of May 3, 2026 |  | 183 |  |  | $ | 140.26 |  |  |  |  |  |

[0001730168-26-000054:notes:90]
The aggregate fair value of RSUs that vested during the two fiscal quarters ended May 3, 2026 was $13,527 million, which represented the market value of our common stock on the date that the RSUs vested.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-26-000054:notes:91]
Income Taxes
The provision for income taxes was $820 million and $1,666 million for the fiscal quarter and two fiscal quarters ended May 3, 2026, respectively, compared to $120 million and $107 million for the fiscal quarter and two fiscal quarters ended May 4, 2025, respectively. The increase in the provision for income taxes in both the fiscal quarter and two fiscal quarters ended May 3, 2026, as compared to the prior year fiscal periods, was primarily due to higher income before income taxes. We expect to remain subject to the Corporate Alternative Minimum Tax (“CAMT”) for fiscal year 2026 and subsequent years. Accordingly, we continue to maintain a full valuation allowance against our CAMT credit carryforwards and CAMT credits generated in the current fiscal year.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-26-000054:notes:92]
[same as prior period, unchanged from 0001730168-26-000016:notes:90]

[0001730168-26-000054:notes:93]
[same as prior period, unchanged from 0001730168-26-000016:notes:91]

[0001730168-26-000054:notes:94]
[same as prior period, unchanged from 0001730168-26-000016:notes:92]

[0001730168-26-000054:notes:95]
[same as prior period, unchanged from 0001730168-26-000016:notes:93]

[0001730168-26-000054:notes:96]
[same as prior period, unchanged from 0001730168-26-000016:notes:94]

[0001730168-26-000054:notes:97]
|  |  | Fiscal Quarter Ended |  | Two Fiscal Quarters Ended |
|  |  | May 3,2026 |  | May 4,2025 |  | May 3,2026 |  | May 4,2025 |
|  |  | (In millions) |
| Semiconductor solutions: |  |  |  |  |  |  |  |  |
| Net revenue |  | $ | 15,009 |  |  | $ | 8,408 |  |  | $ | 27,524 |  |  | $ | 16,620 |  |
| Cost of revenue |  | 4,573 |  |  | 2,631 |  |  | 8,522 |  |  | 5,247 |  |
| Research and development |  | 999 |  |  | 847 |  |  | 1,940 |  |  | 1,638 |  |
| Selling, general and administrative |  | 156 |  |  | 124 |  |  | 278 |  |  | 223 |  |
| Operating income |  | $ | 9,281 |  |  | $ | 4,806 |  |  | $ | 16,784 |  |  | $ | 9,512 |  |
| Infrastructure software: |  |  |  |  |  |  |  |  |
| Net revenue |  | $ | 7,178 |  |  | $ | 6,596 |  |  | $ | 13,974 |  |  | $ | 13,300 |  |
| Cost of revenue |  | 505 |  |  | 462 |  |  | 999 |  |  | 966 |  |
| Research and development |  | 601 |  |  | 677 |  |  | 1,178 |  |  | 1,317 |  |
| Selling, general and administrative |  | 425 |  |  | 470 |  |  | 827 |  |  | 908 |  |
| Operating income |  | $ | 5,647 |  |  | $ | 4,987 |  |  | $ | 10,970 |  |  | $ | 10,109 |  |
| Total: |  |  |  |  |  |  |  |  |
| Net revenue |  | $ | 22,187 |  |  | $ | 15,004 |  |  | $ | 41,498 |  |  | $ | 29,920 |  |
| Cost of revenue |  | 5,078 |  |  | 3,093 |  |  | 9,521 |  |  | 6,213 |  |
| Research and development |  | 1,600 |  |  | 1,524 |  |  | 3,118 |  |  | 2,955 |  |
| Selling, general and administrative |  | 581 |  |  | 594 |  |  | 1,105 |  |  | 1,131 |  |
| Unallocated expenses: |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | 2,092 |  |  | 1,771 |  |  | 4,268 |  |  | 3,051 |  |
| Amortization of acquisition-related intangible assets |  | 1,967 |  |  | 1,989 |  |  | 3,936 |  |  | 3,984 |  |
| Restructuring and other charges |  | 81 |  |  | 114 |  |  | 197 |  |  | 300 |  |
| Acquisition-related costs |  | — |  |  | 90 |  |  | 2 |  |  | 197 |  |
| Operating income |  | $ | 10,788 |  |  | $ | 5,829 |  |  | $ | 19,351 |  |  | $ | 12,089 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-26-000054:notes:98]
Commitments and Contingencies
Commitments

[0001730168-26-000054:notes:99]
The following table summarizes contractual commitments as of May 3, 2026:

[0001730168-26-000054:notes:100]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 22 |  |  | $ | 516 |  |
| 2027 |  | 55,214 |  |  | 744 |  |
| 2028 |  | 72,870 |  |  | 763 |  |
| 2029 |  | 4 |  |  | 894 |  |
| 2030 |  | — |  |  | 303 |  |
| Thereafter |  | — |  |  | 885 |  |
| Total |  | $ | 128,110 |  |  | $ | 4,105 |  |

[0001730168-26-000054:notes:101]
Purchase Commitments. Represent unconditional purchase commitments to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase commitments exclude agreements that are cancelable without penalty and unconditional purchase commitments with a remaining term of one year or less.

[0001730168-26-000054:notes:102]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-26-000054:notes:103]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of May 3, 2026, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,662 million of unrecognized tax benefits and accrued interest and penalties as of May 3, 2026 have been excluded from the table above.

[0001730168-26-000054:notes:104]
Contingencies

[0001730168-26-000054:notes:105]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including but not limited to commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-26-000054:notes:106]
Contingency Assessment

[0001730168-26-000054:notes:107]
We are currently engaged in a number of legal actions in the ordinary course of our business; however, we do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-26-000054:notes:108]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-26-000054:notes:109]
Other Indemnifications

[0001730168-26-000054:notes:110]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:SubsequentEventsTextBlock

[0001730168-26-000054:notes:111]
Subsequent Events
On June 8, 2026, we arranged for an investor partner to take on certain agreements to purchase AI racks based on custom AI accelerators designed by us and the related lease agreements with a customer that enable access to compute capacity. In connection with the arrangement, we entered into a backstop agreement with the investor partner for the customer’s lease obligations over 5-year terms. The backstop will increase over time as the AI racks are deployed and decrease as the customer makes payments on its lease obligations, with a maximum exposure of $29 billion. In the event of default by the customer, we have various remedies, including the assumption of the lease or effecting a sale of the AI racks, which would reduce our maximum exposure.

[0001730168-26-000054:notes:112]
Cash Dividends Declared

[0001730168-26-000054:notes:113]
On June 2, 2026, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on June 30, 2026 to stockholders of record on June 22, 2026.
