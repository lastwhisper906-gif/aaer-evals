# AVGO notes — 0001730168-26-000016


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001730168-26-000016:notes:1]
[same as prior period, unchanged from 0001730168-25-000098:notes:1]

[0001730168-26-000016:notes:2]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, subsystems and, in some cases, racks. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.

[0001730168-26-000016:notes:3]
[same as prior period, unchanged from 0001730168-25-000098:notes:3]

[0001730168-26-000016:notes:4]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal years ending November 1, 2026 (“fiscal year 2026”) and November 2, 2025 (“fiscal year 2025”) are both 52-week fiscal years.

[0001730168-26-000016:notes:5]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 2, 2025 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2025 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 1, 2026 are not necessarily indicative of the results that may be expected for fiscal year 2026, or for any other future period.

[0001730168-26-000016:notes:6]
Certain prior period amounts reported in our condensed consolidated statements of operations have been reclassified to conform to the current period presentation. See Note 2. “Revenue from Contracts with Customers” for additional information.

[0001730168-26-000016:notes:7]
[same as prior period, unchanged from 0001730168-25-000098:notes:6]

[0001730168-26-000016:notes:8]
[same as prior period, unchanged from 0001730168-25-000098:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001730168-26-000016:notes:9]
[same as prior period, unchanged from 0001730168-25-000098:notes:8]

[0001730168-26-000016:notes:10]
Reclassifications to Condensed Consolidated Statements of Operations

[0001730168-26-000016:notes:11]
For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue. In the fiscal quarter ended February 1, 2026, we included upfront license revenue of $1,755 million within products revenue, and the related costs, which were immaterial, in cost of products sold, in our condensed consolidated statements of operations. To conform to the current period presentation, we reclassified $1,972 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter ended February 2, 2025. We also reclassified the related costs for the upfront license revenue, which were immaterial.

[0001730168-26-000016:notes:12]
In the revenue disaggregation tables by type and by region presented below, we included $1,061 million, $124 million and $570 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 1, 2026. To conform to the current period presentation, we reclassified $1,445 million, $64 million and $463 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 2, 2025.

[0001730168-26-000016:notes:13]
[same as prior period, unchanged from 0001730168-25-000098:notes:9]

[0001730168-26-000016:notes:14]
We have considered (1) information that is regularly reviewed by our Chief Executive Officer, who has been identified as the chief operating decision maker (the “CODM”) as defined by the authoritative guidance on segment reporting, in evaluating financial performance and (2) disclosures presented outside of our financial statements in our earnings releases and used in investor presentations to disaggregate revenues. The principal category we use to disaggregate revenues is the nature of our products and subscriptions and services, as presented in our condensed consolidated statements of operations. In addition, revenues by reportable segment are presented in Note 9. “Segment Information.”

[0001730168-26-000016:notes:15]
The following tables present revenue disaggregated by type and by region for the periods presented:

[0001730168-26-000016:notes:16]
|  |  | Fiscal Quarter Ended February 1, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,164 |  |  | $ | 10,950 |  |  | $ | 1,016 |  |  | $ | 14,130 |  |
| Subscriptions and services |  | 2,917 |  |  | 665 |  |  | 1,599 |  |  | 5,181 |  |
| Total |  | $ | 5,081 |  |  | $ | 11,615 |  |  | $ | 2,615 |  |  | $ | 19,311 |  |

[0001730168-26-000016:notes:17]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,935 |  |  | $ | 7,333 |  |  | $ | 875 |  |  | $ | 10,143 |  |
| Subscriptions and services |  | 2,697 |  |  | 699 |  |  | 1,377 |  |  | 4,773 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

[0001730168-26-000016:notes:18]
[same as prior period, unchanged from 0001730168-25-000098:notes:16]

[0001730168-26-000016:notes:19]
[same as prior period, unchanged from 0001730168-25-000098:notes:17]

[0001730168-26-000016:notes:20]
[same as prior period, unchanged from 0001730168-25-000098:notes:18]

[0001730168-26-000016:notes:21]
|  |  | February 1,2026 |  | November 2,2025 |
|  | (In millions) |
| Contract Assets |  | $ | 9,347 |  |  | $ | 8,922 |  |
| Contract Liabilities |  | $ | 12,855 |  |  | $ | 13,016 |  |

[0001730168-26-000016:notes:22]
[same as prior period, unchanged from 0001730168-25-000098:notes:20]

[0001730168-26-000016:notes:23]
[same as prior period, unchanged from 0001730168-25-000098:notes:21]

[0001730168-26-000016:notes:24]
As of February 1, 2026, approximately 67% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 1, 2026 that was included in the contract liabilities balance as of November 2, 2025 was $3,915 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $3,583 million.

[0001730168-26-000016:notes:25]
[same as prior period, unchanged from 0001730168-25-000098:notes:23]

[0001730168-26-000016:notes:26]
[same as prior period, unchanged from 0001730168-25-000098:notes:24]

[0001730168-26-000016:notes:27]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of February 1, 2026 were approximately $45.0 billion. We expect approximately 33% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001730168-26-000016:notes:28]
[same as prior period, unchanged from 0001730168-25-000098:notes:31]

[0001730168-26-000016:notes:29]
Cash equivalents included $2,901 million and $3,163 million of time deposits and $2,290 million and $2,239 million of money-market funds as of February 1, 2026 and November 2, 2025, respectively. For time deposits, carrying value approximates fair value due to the short-term nature of the instruments. The fair value of money-market funds, which was consistent with their carrying value, was determined using unadjusted prices in active, accessible markets for identical assets, and as such, they were classified as Level 1 assets in the fair value hierarchy.

[0001730168-26-000016:notes:30]
[same as prior period, unchanged from 0001730168-25-000098:notes:33]

[0001730168-26-000016:notes:31]
We sell certain of our trade accounts receivable on a non-recourse basis to third-party financial institutions pursuant to factoring arrangements. We account for these transactions as sales of receivables and present cash proceeds as cash provided by operating activities in the condensed consolidated statements of cash flows. Total trade accounts receivable sold under the factoring arrangements were $1,750 million and $2,201 million during the fiscal quarters ended February 1, 2026 and February 2, 2025, respectively.

[0001730168-26-000016:notes:32]
[same as prior period, unchanged from 0001730168-25-000098:notes:35]

[0001730168-26-000016:notes:33]
|  |  | February 1,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Finished goods |  | $ | 842 |  |  | $ | 682 |  |
| Work-in-process |  | 1,544 |  |  | 1,280 |  |
| Raw materials |  | 576 |  |  | 308 |  |
| Total inventory |  | $ | 2,962 |  |  | $ | 2,270 |  |

[0001730168-26-000016:notes:34]
[same as prior period, unchanged from 0001730168-25-000098:notes:37]

[0001730168-26-000016:notes:35]
|  |  | February 1,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Current portion of contract assets |  | $ | 5,536 |  |  | $ | 5,005 |  |
| Prepaid expenses |  | 641 |  |  | 518 |  |
| Other |  | 289 |  |  | 457 |  |
| Total other current assets |  | $ | 6,466 |  |  | $ | 5,980 |  |

[0001730168-26-000016:notes:36]
[same as prior period, unchanged from 0001730168-25-000098:notes:39]

[0001730168-26-000016:notes:37]
|  |  | February 1,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 9,188 |  |  | $ | 9,469 |  |
| Tax liabilities |  | 1,088 |  |  | 921 |  |
| Interest payable |  | 673 |  |  | 620 |  |
| Other |  | 682 |  |  | 663 |  |
| Total other current liabilities |  | $ | 11,631 |  |  | $ | 11,673 |  |

[0001730168-26-000016:notes:38]
[same as prior period, unchanged from 0001730168-25-000098:notes:41]

[0001730168-26-000016:notes:39]
|  |  | February 1,2026 |  | November 2,2025 |
|  |  | (In millions) |
| Contract liabilities |  | $ | 3,667 |  |  | $ | 3,547 |  |
| Deferred tax liabilities |  | 2,222 |  |  | 2,704 |  |
| Unrecognized tax benefits |  | 1,668 |  |  | 1,628 |  |
| Other |  | 1,810 |  |  | 1,423 |  |
| Total other long-term liabilities |  | $ | 9,367 |  |  | $ | 9,302 |  |

[0001730168-26-000016:notes:40]
[same as prior period, unchanged from 0001730168-25-000098:notes:46]

[0001730168-26-000016:notes:41]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | February 2,2025 |  |  |  |  |
|  |  | (In millions) |  |  |
| Cash paid for interest |  | $ | 619 |  |  | $ | 671 |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 782 |  |  | $ | 404 |  |  |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001730168-26-000016:notes:42]
[same as prior period, unchanged from 0001730168-25-000098:notes:48]

[0001730168-26-000016:notes:43]
|  |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net Book Value |
|  |  | (In millions) |
| As of February 1, 2026: |  |  |  |  |  |  |
| Purchased technology |  | $ | 32,851 |  |  | $ | (15,862) |  |  | $ | 16,989 |  |
| Customer contracts and related relationships |  | 15,791 |  |  | (4,482) |  |  | 11,309 |  |
| Trade names |  | 1,612 |  |  | (427) |  |  | 1,185 |  |
| Other |  | 186 |  |  | (117) |  |  | 69 |  |
| Intangible assets subject to amortization |  | 50,440 |  |  | (20,888) |  |  | 29,552 |  |
| In-process research and development |  | 750 |  |  | — |  |  | 750 |  |
| Total |  | $ | 51,190 |  |  | $ | (20,888) |  |  | $ | 30,302 |  |
| As of November 2, 2025: |  |  |  |  |  |  |
| Purchased technology |  | $ | 32,781 |  |  | $ | (14,401) |  |  | $ | 18,380 |  |
| Customer contracts and related relationships |  | 15,791 |  |  | (4,003) |  |  | 11,788 |  |
| Trade names |  | 1,612 |  |  | (399) |  |  | 1,213 |  |
| Other |  | 186 |  |  | (114) |  |  | 72 |  |
| Intangible assets subject to amortization |  | 50,370 |  |  | (18,917) |  |  | 31,453 |  |
| In-process research and development |  | 820 |  |  | — |  |  | 820 |  |
| Total |  | $ | 51,190 |  |  | $ | (18,917) |  |  | $ | 32,273 |  |

[0001730168-26-000016:notes:44]
Based on the amount of intangible assets subject to amortization as of February 1, 2026, the expected amortization expense was as follows:

[0001730168-26-000016:notes:45]
| Fiscal Year: |  | Expected Amortization Expense |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 5,911 |  |
| 2027 |  | 6,818 |  |
| 2028 |  | 5,688 |  |
| 2029 |  | 4,562 |  |
| 2030 |  | 3,377 |  |
| Thereafter |  | 3,196 |  |
| Total |  | $ | 29,552 |  |

[0001730168-26-000016:notes:46]
[same as prior period, unchanged from 0001730168-25-000098:notes:52]

[0001730168-26-000016:notes:47]
| Amortizable intangible assets: |  | February 1,2026 |
|  |  | (In years) |
| Purchased technology |  | 6 |
| Customer contracts and related relationships |  | 6 |
| Trade names |  | 11 |
| Other |  | 11 |


## us-gaap:EarningsPerShareTextBlock

[0001730168-26-000016:notes:48]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period.

[0001730168-26-000016:notes:49]
Potentially dilutive shares outstanding include the dilutive effect of unvested restricted stock units (“RSUs”) and employee stock purchase plan (“ESPP”) rights (collectively referred to as “equity awards”). Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001730168-26-000016:notes:50]
[same as prior period, unchanged from 0001730168-25-000098:notes:56]

[0001730168-26-000016:notes:51]
The following is a reconciliation of the numerators and denominators of the basic and diluted net income per share computations for the periods presented:

[0001730168-26-000016:notes:52]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | February 2,2025 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,349 |  |  | $ | 5,503 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic |  | 4,741 |  |  | 4,695 |  |  |  |  |  |
| Dilutive effect of equity awards |  | 147 |  |  | 141 |  |  |  |  |  |
| Weighted-average shares outstanding - diluted |  | 4,888 |  |  | 4,836 |  |  |  |  |  |

[0001730168-26-000016:notes:53]
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.55 |  |  | $ | 1.17 |  |  |  |  |  |
| Diluted |  | $ | 1.50 |  |  | $ | 1.14 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001730168-26-000016:notes:54]
Borrowings

[0001730168-26-000016:notes:55]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

[0001730168-26-000016:notes:56]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
|  |  |  |  | 752 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 3,856 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 66,220 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |

[0001730168-26-000016:notes:57]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
| Total debt principal outstanding |  |  |  | 67,970 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,913) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 63,805 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |

[0001730168-26-000016:notes:58]
__________________________

[0001730168-26-000016:notes:59]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate includes the impact of previously deferred gains on derivatives.

[0001730168-26-000016:notes:60]
Senior Notes

[0001730168-26-000016:notes:61]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. With the exception of the senior notes issued in September 2025 and January 2026, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Interest is paid semi-annually.

[0001730168-26-000016:notes:62]
In January 2026, we issued senior unsecured notes for an aggregate principal amount of $4,500 million. During the fiscal quarter ended February 1, 2026, we repaid and redeemed a total of $3,650 million of our senior notes.

[0001730168-26-000016:notes:63]
Fixed-Rate Term Loans

[0001730168-26-000016:notes:64]
Interest on the term loans is due quarterly. We are permitted to prepay the term loans at any time, subject to a specified make-whole premium determined in accordance with the credit agreements governing the respective term loans, plus accrued and unpaid interest.

[0001730168-26-000016:notes:65]
2025 Credit Agreement

[0001730168-26-000016:notes:66]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. We had no borrowings outstanding under our revolving credit facility at either February 1, 2026 or November 2, 2025.

[0001730168-26-000016:notes:67]
Commercial Paper

[0001730168-26-000016:notes:68]
Under our commercial paper program, we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either February 1, 2026 or November 2, 2025.

[0001730168-26-000016:notes:69]
Fair Value of Debt

[0001730168-26-000016:notes:70]
As of February 1, 2026, the estimated aggregate fair value of our debt was $65,738 million, which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments.

[0001730168-26-000016:notes:71]
Future Principal Payments of Debt

[0001730168-26-000016:notes:72]
The future scheduled principal payments of our debt as of February 1, 2026 were as follows:

[0001730168-26-000016:notes:73]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 2,252 |  |
| 2027 |  | 1,743 |  |
| 2028 |  | 5,127 |  |
| 2029 |  | 4,655 |  |
| 2030 |  | 6,406 |  |
| Thereafter |  | 47,787 |  |
| Total |  | $ | 67,970 |  |

[0001730168-26-000016:notes:74]
As of February 1, 2026 and November 2, 2025, we were in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001730168-26-000016:notes:75]
[same as prior period, unchanged from 0001730168-25-000098:notes:88]

[0001730168-26-000016:notes:76]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | February 2,2025 |  |  |  |  |
|  |  | (In millions, except per share data) |
| Dividends per share to common stockholders |  | $ | 0.65 |  |  | $ | 0.59 |  |  |  |  |  |
| Dividends to common stockholders |  | $ | 3,086 |  |  | $ | 2,774 |  |  |  |  |  |

[0001730168-26-000016:notes:77]
[same as prior period, unchanged from 0001730168-25-000098:notes:90]

[0001730168-26-000016:notes:78]
In April 2025, our Board of Directors authorized a stock repurchase program to repurchase up to $10 billion of our common stock through December 31, 2025, which was subsequently extended through December 31, 2026 and increased to $11 billion. During the fiscal quarter ended February 1, 2026, we repurchased and retired 23 million shares for $7,850 million. As of February 1, 2026, $700 million of the authorized amount remained available for repurchase under this program.

[0001730168-26-000016:notes:79]
Subsequent to the fiscal quarter ended February 1, 2026, our Board of Directors in March 2026 authorized a stock repurchase program to repurchase up to $10 billion of our common stock from time to time through December 31, 2026.

[0001730168-26-000016:notes:80]
[same as prior period, unchanged from 0001730168-25-000098:notes:93]

[0001730168-26-000016:notes:81]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | February 2,2025 |  |  |  |  |
|  |  | (In millions) |
| Cost of products sold |  | $ | 66 |  |  | $ | 33 |  |  |  |  |  |
| Cost of subscriptions and services |  | 170 |  |  | 120 |  |  |  |  |  |
| Research and development |  | 1,447 |  |  | 822 |  |  |  |  |  |
| Selling, general and administrative |  | 493 |  |  | 305 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 2,176 |  |  | $ | 1,280 |  |  |  |  |  |

[0001730168-26-000016:notes:82]
During the second quarter of fiscal year 2025, we granted two-year time- and market-based RSU awards (the “Two-Year Equity Awards”), in lieu of our annual employee equity awards historically granted in the second quarter of each fiscal year. Each of the Two-Year Equity Awards vests on the same basis as two annual grants with staggered vesting start dates of March 15, 2025 and March 15, 2026 and successive four-year vesting periods. We recognize stock-based compensation expense related to these awards from the grant date through their respective vesting date, ranging from four to five years.

[0001730168-26-000016:notes:83]
As of February 1, 2026, the total unrecognized compensation cost related to unvested stock-based awards was $21,971 million, which is expected to be recognized over the remaining weighted-average service period of 3.2 years.

[0001730168-26-000016:notes:84]
Restricted Stock Unit Awards

[0001730168-26-000016:notes:85]
A summary of RSU activity is as follows:

[0001730168-26-000016:notes:86]
|  |  | Number of RSUs Outstanding |  | Weighted-AverageGrant Date Fair Value Per Share |  |  |  |  |
|  |  | (In millions, except per share data) |  |  |  |  |
| Balance as of November 2, 2025 |  | 229 |  |  | $ | 127.63 |  |  |  |  |  |
| Granted |  | 2 |  |  | $ | 330.46 |  |  |  |  |  |
| Vested |  | (18) |  |  | $ | 92.14 |  |  |  |  |  |
| Forfeited |  | (5) |  |  | $ | 134.41 |  |  |  |  |  |
| Balance as of February 1, 2026 |  | 208 |  |  | $ | 132.52 |  |  |  |  |  |

[0001730168-26-000016:notes:87]
The aggregate fair value of RSUs that vested during the fiscal quarter ended February 1, 2026 was $6,255 million, which represented the market value of our common stock on the date that the RSUs vested.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001730168-26-000016:notes:88]
Income Taxes
The provision for income taxes was $846 million for the fiscal quarter ended February 1, 2026 and was primarily due to income before income taxes, partially offset by excess tax benefits from stock-based awards.

[0001730168-26-000016:notes:89]
The benefit from income taxes was $13 million for the fiscal quarter ended February 2, 2025 and was primarily due to excess tax benefits from stock-based awards, partially offset by income before income taxes and a shift in the jurisdictional location mix of revenue and expenses.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001730168-26-000016:notes:90]
[same as prior period, unchanged from 0001730168-25-000098:notes:107]

[0001730168-26-000016:notes:91]
We have two reportable segments: semiconductor solutions and infrastructure software. Each segment has separate financial information. The CODM considers actual and expected results of regularly provided net revenue, cost of revenue, operating expenses and operating income by segment during the budgeting and forecasting processes to support strategic decision-making and to evaluate the performance of and allocate resources to each of the segments. Operating income by segment includes items that are directly attributable to each segment and shared expenses such as marketing, general and administrative activities, facilities and IT expenses. Shared expenses are primarily allocated based on revenue and headcount.

[0001730168-26-000016:notes:92]
Semiconductor solutions. Our semiconductor solutions are used in a wide array of environments, end products and applications such as enterprise and AI data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our semiconductor solutions segment also includes our IP licensing.

[0001730168-26-000016:notes:93]
Infrastructure software. Our infrastructure software solutions include revenues from software arrangements, related support, and professional services that help enterprises simplify their IT environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical FC SAN products and related software.

[0001730168-26-000016:notes:94]
Stock-based compensation expense, amortization of acquisition-related intangible assets, restructuring and other charges, and acquisition-related costs are not used in evaluating the results of, or in allocating resources to, our segments and therefore are not allocated to each segment. The CODM does not evaluate each segment using discrete asset information. Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by segment and, therefore, it is not separately presented. There was no inter-segment revenue for any of the periods presented. The accounting policies of the segments are the same as those described in the “Summary of Significant Accounting Policies” included in the Annual Report on Form 10-K for fiscal year 2025.

[0001730168-26-000016:notes:95]
|  |  | Fiscal Quarter Ended |
|  |  | February 1,2026 |  | February 2,2025 |
|  |  | (In millions) |
| Semiconductor solutions: |  |  |  |  |
| Net revenue |  | $ | 12,515 |  |  | $ | 8,212 |  |
| Cost of revenue |  | 3,949 |  |  | 2,616 |  |
| Research and development |  | 941 |  |  | 791 |  |
| Selling, general and administrative |  | 122 |  |  | 99 |  |
| Operating income |  | $ | 7,503 |  |  | $ | 4,706 |  |
| Infrastructure software: |  |  |  |  |
| Net revenue |  | $ | 6,796 |  |  | $ | 6,704 |  |
| Cost of revenue |  | 494 |  |  | 504 |  |
| Research and development |  | 577 |  |  | 640 |  |
| Selling, general and administrative |  | 402 |  |  | 438 |  |
| Operating income |  | $ | 5,323 |  |  | $ | 5,122 |  |
| Total: |  |  |  |  |
| Net revenue |  | $ | 19,311 |  |  | $ | 14,916 |  |
| Cost of revenue |  | 4,443 |  |  | 3,120 |  |
| Research and development |  | 1,518 |  |  | 1,431 |  |
| Selling, general and administrative |  | 524 |  |  | 537 |  |
| Unallocated expenses: |  |  |  |  |
| Stock-based compensation |  | 2,176 |  |  | 1,280 |  |
| Amortization of acquisition-related intangible assets |  | 1,969 |  |  | 1,995 |  |
| Restructuring and other charges |  | 116 |  |  | 186 |  |
| Acquisition-related costs |  | 2 |  |  | 107 |  |
| Operating income |  | $ | 8,563 |  |  | $ | 6,260 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001730168-26-000016:notes:96]
Commitments and Contingencies
Commitments

[0001730168-26-000016:notes:97]
The following table summarizes contractual obligations and commitments as of February 1, 2026:

[0001730168-26-000016:notes:98]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 28 |  |  | $ | 763 |  |
| 2027 |  | 12 |  |  | 718 |  |
| 2028 |  | 10 |  |  | 736 |  |
| 2029 |  | 4 |  |  | 890 |  |
| 2030 |  | — |  |  | 300 |  |
| Thereafter |  | — |  |  | 873 |  |
| Total |  | $ | 54 |  |  | $ | 4,280 |  |

[0001730168-26-000016:notes:99]
Purchase Commitments. Represent unconditional purchase obligations to purchase goods or services, primarily inventory, that are enforceable and legally binding on us and specify all significant terms, including fixed or minimum quantities to be purchased, price provisions, and the approximate timing of the transaction. Purchase obligations exclude agreements that are cancelable without penalty and unconditional purchase obligations with a remaining term of one year or less.

[0001730168-26-000016:notes:100]
Other Contractual Commitments. Represent amounts payable pursuant to agreements related to IT and other service agreements.

[0001730168-26-000016:notes:101]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 1, 2026, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,668 million of unrecognized tax benefits and accrued interest and penalties as of February 1, 2026 have been excluded from the table above.

[0001730168-26-000016:notes:102]
Contingencies

[0001730168-26-000016:notes:103]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including but not limited to commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

[0001730168-26-000016:notes:104]
Contingency Assessment

[0001730168-26-000016:notes:105]
We are currently engaged in a number of legal actions in the ordinary course of our business; however, we do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

[0001730168-26-000016:notes:106]
During the periods presented, no material amounts have been accrued or disclosed in the accompanying condensed consolidated financial statements with respect to loss contingencies associated with any other legal proceedings, regulatory investigations or tax disputes, as potential losses for such matters are not considered probable and ranges of losses are not reasonably estimable. These matters are subject to many uncertainties and the ultimate outcomes are not predictable. There can be no assurances that the actual amounts required to satisfy any liabilities arising from the matters described above will not have a material adverse effect on our condensed consolidated financial statements.

[0001730168-26-000016:notes:107]
Other Indemnifications

[0001730168-26-000016:notes:108]
As is customary in our industry and as provided for in local law in the U.S. and other jurisdictions, many of our standard contracts provide remedies to our customers and others with whom we enter into contracts, such as defense, settlement, or payment of judgment for IP claims related to the use of our products. From time to time, we indemnify customers, as well as our suppliers, contractors, lessors, lessees, companies that purchase our businesses or assets and others with whom we enter into contracts, against combinations of loss, expense, or liability arising from various triggering events related to the sale and the use of our products, the use of their goods and services, the use of facilities and state of our owned facilities, the state of the assets and businesses that we sell and other matters covered by such contracts, usually up to a specified maximum amount. In addition, from time to time we also provide protection to these parties against claims related to undiscovered liabilities, additional product liabilities or environmental obligations. In our experience, claims made under such indemnifications are rare and the associated estimated fair value of the liability is not material.


## us-gaap:SubsequentEventsTextBlock

[0001730168-26-000016:notes:109]
Subsequent Events
Cash Dividends Declared

[0001730168-26-000016:notes:110]
On March 3, 2026, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on March 31, 2026 to stockholders of record on March 23, 2026.
