# AVGO 8-K — 0001730168-26-000011 filed 2026-03-04

## item codes, every 8-K on or before 2026-03-11

- 2026-03-04 0001730168-26-000011 — 2.02, 8.01, 9.01
- 2026-03-02 0001193125-26-085656 — 5.02
- 2026-01-13 0001193125-26-011731 — 8.01, 9.01
- 2025-12-11 0001730168-25-000116 — 2.02, 8.01, 9.01
- 2025-09-29 0001193125-25-223202 — 8.01, 9.01
- 2025-09-10 0001193125-25-200108 — 8.01, 9.01
- 2025-09-09 0001193125-25-199281 — 5.02, 9.01
- 2025-09-04 0001730168-25-000094 — 2.02, 8.01, 9.01
- 2025-07-11 0001193125-25-158202 — 1.02, 8.01, 9.01
- 2025-06-05 0001730168-25-000061 — 2.02, 8.01, 9.01
- 2025-04-22 0001730168-25-000037 — 5.07
- 2025-03-06 0001730168-25-000009 — 2.02, 8.01, 9.01
- 2025-01-13 0001193125-25-005318 — 1.02, 8.01
- 2025-01-10 0001193125-25-004476 — 8.01, 9.01
- 2024-12-12 0001730168-24-000125 — 2.02, 8.01, 9.01
- 2024-10-02 0001193125-24-231159 — 8.01, 9.01
- 2024-09-05 0001730168-24-000095 — 2.02, 8.01, 9.01
- 2024-07-12 0001140361-24-033072 — 5.03, 8.01, 9.01
- 2024-07-08 0001140361-24-032566 — 8.01, 9.01
- 2024-06-12 0001730168-24-000077 — 2.02, 8.01, 9.01
- 2024-04-24 0001730168-24-000055 — 5.07
- 2024-03-07 0001730168-24-000012 — 2.02, 8.01, 9.01
- 2024-02-09 0001140361-24-006724 — 5.02
- 2024-02-08 0001140361-24-006447 — 9.01 — amendment of 0001140361-23-054354
- 2023-12-07 0001730168-23-000093 — 2.02, 2.05, 8.01, 9.01
- 2023-11-22 0001140361-23-054354 — 2.01, 2.03, 8.01, 9.01
- 2023-10-30 0001140361-23-050217 — 8.01, 9.01
- 2023-10-18 0001140361-23-048712 — 8.01, 9.01
- 2023-08-31 0001730168-23-000074 — 2.02, 8.01, 9.01
- 2023-08-16 0001140361-23-040084 — 1.01, 2.03, 8.01, 9.01
- 2023-06-01 0001730168-23-000062 — 2.02, 8.01, 9.01
- 2023-05-23 0001730168-23-000054 — 7.01
- 2023-04-06 0001730168-23-000052 — 5.02, 5.07
- 2023-03-02 0001730168-23-000004 — 2.02, 8.01, 9.01
- 2022-12-08 0001730168-22-000110 — 2.02, 8.01, 9.01
- 2022-11-02 0001730168-22-000101 — 5.02
- 2022-09-01 0001730168-22-000091 — 2.02, 8.01, 9.01
- 2022-07-11 0001140361-22-025654 — 5.02
- 2022-05-26 0001193125-22-161016 — 1.01, 8.01, 9.01
- 2022-05-26 0001193125-22-160371 — 7.01, 9.01
- 2022-05-26 0001193125-22-160304 — 2.02, 8.01, 9.01
- 2022-04-18 0001193125-22-108067 — 1.01, 2.03, 9.01
- 2022-04-15 0001193125-22-105918 — 1.01, 8.01, 9.01
- 2022-04-05 0001730168-22-000059 — 5.07
- 2022-04-01 0001193125-22-092425 — 8.01, 9.01
- 2022-03-31 0001193125-22-090874 — 8.01, 9.01
- 2022-03-03 0001730168-22-000015 — 2.02, 8.01, 9.01
- 2021-12-09 0001730168-21-000148 — 2.02, 8.01, 9.01
- 2021-09-30 0001193125-21-287948 — 1.01, 2.03, 9.01
- 2021-09-28 0001193125-21-284581 — 8.01, 9.01
- 2021-09-13 0001193125-21-271676 — 8.01, 9.01
- 2021-09-02 0001730168-21-000121 — 2.02, 8.01, 9.01
- 2021-06-03 0001730168-21-000110 — 2.02, 5.02, 8.01, 9.01
- 2021-04-05 0001730168-21-000071 — 5.07, 9.01
- 2021-03-31 0001193125-21-102518 — 1.01, 8.01, 9.01
- 2021-03-30 0001193125-21-098755 — 8.01, 9.01
- 2021-03-16 0001193125-21-081796 — 8.01, 9.01
- 2021-03-04 0001730168-21-000026 — 2.02, 8.01, 9.01
- 2021-02-02 0001193125-21-025889 — 8.01, 9.01
- 2021-01-19 0001193125-21-011422 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2021-01-07 0001193125-21-003380 — 8.01, 9.01
- 2021-01-05 0001193125-21-001276 — 8.01, 9.01
- 2021-01-04 0001193125-21-000394 — 8.01, 9.01
- 2020-12-10 0001730168-20-000201 — 2.02, 7.01, 8.01, 9.01
- 2020-12-10 0001193125-20-315010 — 5.02, 9.01
- 2020-09-03 0001730168-20-000154 — 2.02, 7.01, 8.01, 9.01
- 2020-06-26 0001730168-20-000126 — 8.01, 9.01
- 2020-06-04 0001730168-20-000099 — 2.02, 8.01, 9.01
- 2020-06-03 0001193125-20-159573 — 8.01, 9.01
- 2020-05-21 0001193125-20-148648 — 1.01, 2.03, 9.01
- 2020-05-19 0001193125-20-146131 — 8.01, 9.01
- 2020-05-08 0001193125-20-137528 — 1.01, 2.03, 9.01
- 2020-05-06 0001193125-20-134440 — 8.01, 9.01
- 2020-05-05 0001193125-20-133159 — 8.01, 9.01
- 2020-04-22 0001193125-20-114389 — 8.01, 9.01
- 2020-04-15 0001193125-20-107418 — 8.01, 9.01
- 2020-04-09 0001193125-20-102580 — 1.01, 2.03, 9.01
- 2020-04-06 0001193125-20-099626 — 8.01, 9.01
- 2020-04-06 0001193125-20-099090 — 8.01, 9.01
- 2020-03-31 0001193125-20-092827 — 5.07
- 2020-03-12 0001193125-20-071608 — 2.02, 8.01, 9.01
- 2020-01-31 0001193125-20-021302 — 5.02
- 2020-01-23 0001193125-20-013100 — 7.01
- 2020-01-13 0001193125-20-005998 — 5.02
- 2020-01-09 0001193125-20-004721 — 8.01
- 2019-12-12 0001193125-19-312797 — 2.02, 5.02, 8.01, 9.01
- 2019-11-04 0001193125-19-282605 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2019-09-30 0001193125-19-258822 — 3.03, 5.03, 8.01, 9.01
- 2019-09-13 0001193125-19-244923 — 5.02, 9.01
- 2019-09-12 0001193125-19-243919 — 2.02, 8.01, 9.01
- 2019-08-09 0001193125-19-217369 — 1.01, 7.01, 8.01, 9.01
- 2019-06-26 0001193125-19-181599 — 7.01
- 2019-06-13 0001193125-19-172516 — 2.02, 5.02, 8.01, 9.01
- 2019-06-10 0001193125-19-169285 — 7.01
- 2019-05-07 0001193125-19-139727 — 1.01, 1.02, 2.03, 9.01
- 2019-04-05 0001193125-19-099260 — 1.01, 2.03, 9.01
- 2019-04-01 0001193125-19-094751 — 5.07, 8.01, 9.01
- 2019-03-14 0001193125-19-074832 — 2.02, 5.05, 8.01, 9.01
- 2019-01-25 0001193125-19-017097 — 1.01, 8.01, 9.01
- 2019-01-14 0001193125-19-009086 — 9.01 — amendment of 0001193125-18-317917
- 2019-01-14 0001193125-19-008372 — 5.02
- 2019-01-09 0001193125-19-004970 — 5.02
- 2018-12-06 0001193125-18-343743 — 2.02, 5.02, 8.01, 9.01
- 2018-11-05 0001193125-18-317917 — 1.01, 2.01, 2.03, 7.01, 8.01, 9.01
- 2018-10-12 0001193125-18-298363 — 8.01
- 2018-09-07 0001193125-18-269288 — 7.01, 9.01
- 2018-09-06 0001730168-18-000036 — 2.02, 7.01, 8.01, 9.01
- 2018-08-24 0001193125-18-257622 — 8.01, 9.01
- 2018-07-12 0001193125-18-216419 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2018-06-07 0001193125-18-186769 — 2.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143404 — 7.01, 9.01
- 2018-04-12 0001193125-18-115599 — 8.01, 9.01
- 2018-04-09 0001193125-18-111706 — 1.01, 9.01
- 2018-03-26 0001193125-18-095153 — 8.01
- 2018-03-23 0001193125-18-094342 — 5.03, 9.01

## late-filing notifications on or before 2026-03-11

- none on or before 2026-03-11

## item 2.02 — earnings release, exhibit 99.1

[0001730168-26-000011:8k_2_02:1]
EX-99.1
2
avgo-02012026x8kxex99.htm
EX-99.1

[0001730168-26-000011:8k_2_02:2]
Document

[0001730168-26-000011:8k_2_02:3]
Exhibit 99.1

[0001730168-26-000011:8k_2_02:4]
Broadcom Inc. Announces First Quarter Fiscal Year 2026 Financial Results and Quarterly Dividend

[0001730168-26-000011:8k_2_02:5]
•Revenue of $19,311 million for the first quarter, up 29 percent from the prior year period

[0001730168-26-000011:8k_2_02:6]
•GAAP net income of $7,349 million for the first quarter; Non-GAAP net income of $10,185 million for the first quarter

[0001730168-26-000011:8k_2_02:7]
•Adjusted EBITDA of $13,128 million for the first quarter, or 68 percent of revenue

[0001730168-26-000011:8k_2_02:8]
•GAAP diluted EPS of $1.50 for the first quarter; Non-GAAP diluted EPS of $2.05 for the first quarter

[0001730168-26-000011:8k_2_02:9]
•Cash from operations of $8,260 million for the first quarter, less capital expenditures of $250 million, resulted in $8,010 million of free cash flow, or 41 percent of revenue

[0001730168-26-000011:8k_2_02:10]
•Quarterly common stock dividend of $0.65 per share

[0001730168-26-000011:8k_2_02:11]
•Second quarter fiscal year 2026 revenue guidance of approximately $22.0 billion, an increase of 47 percent from the prior year period

[0001730168-26-000011:8k_2_02:12]
•Second quarter fiscal year 2026 Adjusted EBITDA guidance of approximately 68 percent of projected revenue (1)

[0001730168-26-000011:8k_2_02:13]
•New $10 billion share repurchase program

[0001730168-26-000011:8k_2_02:14]
PALO ALTO, Calif. – March 4, 2026 – Broadcom Inc. (Nasdaq: AVGO), a global technology leader that designs, develops and supplies semiconductor and infrastructure software solutions, today reported financial results for its first quarter of fiscal year 2026, ended February 1, 2026, provided guidance for its second quarter of fiscal year 2026 and announced its quarterly dividend.

[0001730168-26-000011:8k_2_02:15]
“Broadcom achieved record first quarter revenue on continued strength in AI semiconductor solutions. Q1 AI revenue of $8.4 billion grew 106% year-over-year, above our forecast, driven by robust demand for custom AI accelerators and AI networking,” said Hock Tan, President and CEO of Broadcom Inc. “Our AI revenue growth is accelerating, and we expect AI semiconductor revenue to be $10.7 billion in Q2.”

[0001730168-26-000011:8k_2_02:16]
“Consolidated revenue grew 29% year-over-year to a record $19.3 billion. Adjusted EBITDA increased 30% year-over-year to a record $13.1 billion, representing 68% of revenue. In Q2 we expect revenue growth to increase 47% year-over-year to $22.0 billion, with adjusted EBITDA of 68%,” said Kirsten Spears, CFO of Broadcom Inc. “Consistent with our commitment to return excess cash to shareholders, we returned $10.9 billion in the first quarter through $3.1 billion of cash dividends and $7.8 billion of stock repurchases.”

[0001730168-26-000011:8k_2_02:17]
________________________________

[0001730168-26-000011:8k_2_02:18]
(1) The Company is not readily able to provide a reconciliation of the projected non-GAAP financial information presented to the relevant projected GAAP measure without unreasonable effort.

[0001730168-26-000011:8k_2_02:19]
First Quarter Fiscal Year 2026 Financial Highlights

[0001730168-26-000011:8k_2_02:20]
|  |  | GAAP |  | Non-GAAP |
| (Dollars in millions, except per share data) |  | Q1 26 |  | Q1 25 |  | Change |  | Q1 26 |  | Q1 25 |  | Change |
| Net revenue |  | $ | 19,311 |  |  | $ | 14,916 |  |  | +29 | % |  | $ | 19,311 |  |  | $ | 14,916 |  |  | +29 | % |
| Net income |  | $ | 7,349 |  |  | $ | 5,503 |  |  | +34 | % |  | $ | 10,185 |  |  | $ | 7,823 |  |  | +30 | % |
| Earnings per common share - diluted |  | $ | 1.50 |  |  | $ | 1.14 |  |  | +32 | % |  | $ | 2.05 |  |  | $ | 1.60 |  |  | +28 | % |

[0001730168-26-000011:8k_2_02:21]
| (Dollars in millions) |  | Q1 26 |  | Q1 25 |  | Change |  |
| Cash flow from operations |  | $ | 8,260 |  |  | $ | 6,113 |  |  | +35 | % |  |
| Adjusted EBITDA |  | $ | 13,128 |  |  | $ | 10,083 |  |  | +30 | % |  |
| Free cash flow |  | $ | 8,010 |  |  | $ | 6,013 |  |  | +33 | % |  |

[0001730168-26-000011:8k_2_02:22]
| Net revenue by segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Dollars in millions) |  | Q1 26 |  |  |  | Q1 25 |  | Change |  |
| Semiconductor solutions |  | $ | 12,515 |  |  | 65 | % |  |  |  |  |  |  | $ | 8,212 |  |  | 55 | % |  | +52 | % |  |
| Infrastructure software |  | 6,796 |  |  | 35 |  |  |  |  |  |  |  | 6,704 |  |  | 45 |  |  | +1 | % |  |
| Total net revenue |  | $ | 19,311 |  |  | 100 | % |  |  |  |  |  |  | $ | 14,916 |  |  | 100 | % |  |  |  |  |

[0001730168-26-000011:8k_2_02:23]
The Company’s cash and cash equivalents at the end of the fiscal quarter were $14,174 million, compared to $16,178 million at the end of the prior fiscal quarter.

[0001730168-26-000011:8k_2_02:24]
During the first fiscal quarter, the Company generated $8,260 million in cash from operations and spent $250 million on capital expenditures, resulting in $8,010 million of free cash flow.

[0001730168-26-000011:8k_2_02:25]
On December 31, 2025, the Company paid a cash dividend of $0.65 per share, totaling $3,086 million.

[0001730168-26-000011:8k_2_02:26]
The differences between the Company’s GAAP and non-GAAP results are described generally under “Non-GAAP Financial Measures” below and presented in detail in the financial reconciliation tables attached to this release.

[0001730168-26-000011:8k_2_02:27]
Second Quarter Fiscal Year 2026 Business Outlook

[0001730168-26-000011:8k_2_02:28]
Based on current business trends and conditions, the outlook for the second quarter of fiscal year 2026, ending May 3, 2026, is expected to be as follows:

[0001730168-26-000011:8k_2_02:29]
•Second quarter revenue guidance of approximately $22.0 billion; and

[0001730168-26-000011:8k_2_02:30]
•Second quarter Adjusted EBITDA guidance of approximately 68 percent of projected revenue.

[0001730168-26-000011:8k_2_02:31]
The guidance provided above is only an estimate of what the Company believes is realizable as of the date of this release. The Company is not readily able to provide a reconciliation of projected Adjusted EBITDA to projected net income without unreasonable effort. Actual results will vary from the guidance and the variations may be material. The Company undertakes no intent or obligation to publicly update or revise any of these projections, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-26-000011:8k_2_02:32]
2

[0001730168-26-000011:8k_2_02:33]
Quarterly Dividends

[0001730168-26-000011:8k_2_02:34]
The Board of Directors of Broadcom has approved a quarterly cash dividend of $0.65 per share. The dividend is payable on March 31, 2026 to stockholders of record at the close of business (5:00 p.m. Eastern Time) on March 23, 2026.

[0001730168-26-000011:8k_2_02:35]
New Share Repurchase Program

[0001730168-26-000011:8k_2_02:36]
The Board of Directors of Broadcom has authorized a new share repurchase program to repurchase up to $10 billion of its common stock through December 31, 2026. Repurchases under the new share repurchase authorization may be made through a variety of methods, including open market or privately negotiated purchases. The timing and amount of shares repurchased will depend on the stock price, business and market conditions, corporate and regulatory requirements, alternative investment opportunities, acquisition opportunities and other factors. Broadcom is not obligated to repurchase any specific amount of shares of common stock, and the share repurchase program may be suspended or terminated at any time.

[0001730168-26-000011:8k_2_02:37]
Financial Results Conference Call

[0001730168-26-000011:8k_2_02:38]
Broadcom Inc. will host a conference call to review its financial results for the first quarter of fiscal year 2026 and to discuss the business outlook today at 2:00 p.m. Pacific Time.

[0001730168-26-000011:8k_2_02:39]
To Listen via Internet: The conference call can be accessed live online in the Investors section of the Broadcom website at https://investors.broadcom.com/.

[0001730168-26-000011:8k_2_02:40]
Replay: An audio replay of the conference call can be accessed for one year through the Investors section of Broadcom’s website at https://investors.broadcom.com/.

[0001730168-26-000011:8k_2_02:41]
Non-GAAP Financial Measures

[0001730168-26-000011:8k_2_02:42]
The non-GAAP measures should not be considered as a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. A reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial data attached to this press release to the extent available without unreasonable effort. Broadcom believes non-GAAP financial information provides additional insight into the Company’s on-going performance. Therefore, Broadcom provides this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons.

[0001730168-26-000011:8k_2_02:43]
In addition to GAAP reporting, Broadcom provides investors with net income, operating income, gross margin, operating expenses, cash flow and other data on a non-GAAP basis. This non-GAAP information excludes amortization of acquisition-related intangible assets, stock-based compensation expense, restructuring and other charges, acquisition-related costs, including integration costs, non-GAAP tax reconciling adjustments, and other adjustments. Management does not believe that these items are reflective of the Company’s underlying performance. Internally, these non-GAAP measures are significant measures used by management for purposes of evaluating the core operating performance of the Company, establishing internal budgets, calculating return on investment for development programs and growth initiatives, comparing performance with internal forecasts and targeted business

[0001730168-26-000011:8k_2_02:44]
models, strategic planning, evaluating and valuing potential acquisition candidates and how their operations compare to the Company’s operations, and benchmarking performance externally against the Company’s competitors. The exclusion of these and other similar items from Broadcom’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001730168-26-000011:8k_2_02:45]
Free cash flow measures have limitations as they omit certain components of the overall cash flow statement and do not represent the residual cash flow available for discretionary expenditures. Investors should not consider presentation of free cash flow measures as implying that stockholders have any right to such cash. Broadcom’s free cash flow may not be calculated in a manner comparable to similarly named measures used by other companies.

[0001730168-26-000011:8k_2_02:46]
About Broadcom

[0001730168-26-000011:8k_2_02:47]
Broadcom Inc. (NASDAQ: AVGO) is a technology leader that designs, develops, and supplies semiconductors and infrastructure software for global organizations’ complex, mission-critical needs. Broadcom combines long-term R&D investment with superb execution to deliver the best technology, at scale. Broadcom is a Delaware corporation headquartered in Palo Alto, CA. For more information, visit www.broadcom.com.

[0001730168-26-000011:8k_2_02:48]
Cautionary Note Regarding Forward-Looking Statements

[0001730168-26-000011:8k_2_02:49]
Particular uncertainties that could materially affect future results include risks associated with: global economic conditions and uncertainty; government regulations, trade restrictions and trade tensions; global political and economic conditions relating to our international operations; any loss of our significant customers and fluctuations in the timing and volume of significant customer demand; our dependence on contract manufacturing and outsourced supply chain; the slow or unsuccessful return on our investments, expansion of our business strategy or adoption of new business models; cyclicality in the semiconductor industry or in our target markets; dependence on senior management and our ability to attract and retain qualified personnel; our ability to protect against cybersecurity threats and a breach of security systems; our ability to accurately estimate customers’ demand and adjust our manufacturing and supply chain accordingly; our dependency on a limited number of suppliers; prolonged disruptions of our, our customers’ or our suppliers’ facilities or other significant operations; our ability to maintain appropriate manufacturing capacity and quality; our ability to continue winning business in the semiconductor solutions industry; dependence on and risks associated with distributors and other channel partners of our products; ability of our software products to manage and secure IT

[0001730168-26-000011:8k_2_02:50]
4

[0001730168-26-000011:8k_2_02:51]
infrastructures and environments; demand for our data center virtualization products and customer acceptance of our products, services and business strategy; compatibility of our software products with operating environments, platforms or third-party products; our ability to enter into satisfactory software license agreements; use of open source software in our products; sales to government customers; our ability to manage products and services lifecycles; our competitive performance; quarterly and annual fluctuations in operating results; our ability to maintain or improve gross margin; any acquisitions or dispositions we may make, such as delays, challenges and expenses associated with receiving governmental and regulatory approvals and satisfying other closing conditions, and with integrating acquired businesses with our existing businesses and our ability to achieve the benefits, growth prospects and synergies expected by such acquisitions; involvement in legal proceedings; our ability to protect our intellectual property and the unpredictability of any associated litigation expenses; any expenses or reputational damage associated with resolving customer product warranty and indemnification claims, or other undetected defects or bugs; our compliance with privacy and data security laws; corporate responsibility matters; our provision for income taxes and overall cash tax costs; our ability to maintain tax concessions in certain jurisdictions; potential tax liabilities as a result of acquiring VMware; our significant indebtedness and the need to generate sufficient cash flows to service and repay such debt; the amount and frequency of our share repurchase program; and other events and trends on a national, regional, industry-specific and global scale, including those of a political, economic, business, competitive and regulatory nature. We are not obligated to repurchase any specific amount of shares of common stock, and the share repurchase program may be suspended or terminated at any time.

[0001730168-26-000011:8k_2_02:52]
Our filings with the SEC, which are available without charge at the SEC’s website at https://www.sec.gov, discuss some of the important risk factors that may affect our business, results of operations and financial condition. Actual results may vary from the estimates provided. We undertake no intent or obligation to publicly update or revise any of the estimates and other forward-looking statements made in this announcement, whether as a result of new information, future events or otherwise, except as required by law.

[0001730168-26-000011:8k_2_02:53]
Contact:

[0001730168-26-000011:8k_2_02:54]
Ji Yoo

[0001730168-26-000011:8k_2_02:55]
Broadcom Inc.

[0001730168-26-000011:8k_2_02:56]
Investor Relations

[0001730168-26-000011:8k_2_02:57]
650-427-6000

[0001730168-26-000011:8k_2_02:58]
investor.relations@broadcom.com

[0001730168-26-000011:8k_2_02:59]
(AVGO-Q)

[0001730168-26-000011:8k_2_02:60]
5

[0001730168-26-000011:8k_2_02:61]
BROADCOM INC.

[0001730168-26-000011:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS — UNAUDITED

[0001730168-26-000011:8k_2_02:63]
(IN MILLIONS, EXCEPT PER SHARE DATA)

[0001730168-26-000011:8k_2_02:64]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | November 2,2025 |  | February 2,2025 |  |  |  |  |
| Net revenue |  | $ | 19,311 |  |  | $ | 18,015 |  |  | $ | 14,916 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | 4,679 |  |  | 4,213 |  |  | 3,273 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,462 |  |  | 1,545 |  |  | 1,484 |  |  |  |  |  |
| Restructuring charges |  | 13 |  |  | 8 |  |  | 14 |  |  |  |  |  |
| Total cost of revenue |  | 6,154 |  |  | 5,766 |  |  | 4,771 |  |  |  |  |  |
| Gross margin |  | 13,157 |  |  | 12,249 |  |  | 10,145 |  |  |  |  |  |
| Research and development |  | 2,965 |  |  | 2,981 |  |  | 2,253 |  |  |  |  |  |
| Selling, general and administrative |  | 1,019 |  |  | 1,107 |  |  | 949 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 507 |  |  | 511 |  |  |  |  |  |
| Restructuring and other charges |  | 103 |  |  | 146 |  |  | 172 |  |  |  |  |  |
| Total operating expenses |  | 4,594 |  |  | 4,741 |  |  | 3,885 |  |  |  |  |  |
| Operating income |  | 8,563 |  |  | 7,508 |  |  | 6,260 |  |  |  |  |  |
| Interest expense |  | (801) |  |  | (761) |  |  | (873) |  |  |  |  |  |
| Other income, net |  | 433 |  |  | 122 |  |  | 103 |  |  |  |  |  |
| Income before income taxes |  | 8,195 |  |  | 6,869 |  |  | 5,490 |  |  |  |  |  |
| Provision for (benefit from) income taxes |  | 846 |  |  | (1,649) |  |  | (13) |  |  |  |  |  |
| Net income |  | $ | 7,349 |  |  | $ | 8,518 |  |  | $ | 5,503 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.55 |  |  | $ | 1.80 |  |  | $ | 1.17 |  |  |  |  |  |
| Diluted |  | $ | 1.50 |  |  | $ | 1.74 |  |  | $ | 1.14 |  |  |  |  |  |
| Weighted-average shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 4,741 |  |  | 4,732 |  |  | 4,695 |  |  |  |  |  |
| Diluted |  | 4,888 |  |  | 4,889 |  |  | 4,836 |  |  |  |  |  |
| Stock-based compensation expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 236 |  |  | $ | 237 |  |  | $ | 153 |  |  |  |  |  |
| Research and development |  | 1,447 |  |  | 1,456 |  |  | 822 |  |  |  |  |  |
| Selling, general and administrative |  | 493 |  |  | 502 |  |  | 305 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 2,176 |  |  | $ | 2,195 |  |  | $ | 1,280 |  |  |  |  |  |

[0001730168-26-000011:8k_2_02:65]
BROADCOM INC.

[0001730168-26-000011:8k_2_02:66]
FINANCIAL RECONCILIATION: GAAP TO NON-GAAP — UNAUDITED

[0001730168-26-000011:8k_2_02:67]
(IN MILLIONS)

[0001730168-26-000011:8k_2_02:68]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | November 2,2025 |  | February 2,2025 |  |  |  |  |
| Gross margin on GAAP basis |  | $ | 13,157 |  |  | $ | 12,249 |  |  | $ | 10,145 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,462 |  |  | 1,545 |  |  | 1,484 |  |  |  |  |  |
| Stock-based compensation expense |  | 236 |  |  | 237 |  |  | 153 |  |  |  |  |  |
| Restructuring charges |  | 13 |  |  | 8 |  |  | 14 |  |  |  |  |  |
| Gross margin on non-GAAP basis |  | $ | 14,868 |  |  | $ | 14,039 |  |  | $ | 11,796 |  |  |  |  |  |
| Research and development on GAAP basis |  | $ | 2,965 |  |  | $ | 2,981 |  |  | $ | 2,253 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,447 |  |  | 1,456 |  |  | 822 |  |  |  |  |  |
| Research and development on non-GAAP basis |  | $ | 1,518 |  |  | $ | 1,525 |  |  | $ | 1,431 |  |  |  |  |  |
| Selling, general and administrative expense on GAAP basis |  | $ | 1,019 |  |  | $ | 1,107 |  |  | $ | 949 |  |  |  |  |  |
| Stock-based compensation expense |  | 493 |  |  | 502 |  |  | 305 |  |  |  |  |  |
| Acquisition-related costs |  | 2 |  |  | 12 |  |  | 107 |  |  |  |  |  |
| Selling, general and administrative expense on non-GAAP basis |  | $ | 524 |  |  | $ | 593 |  |  | $ | 537 |  |  |  |  |  |
| Total operating expenses on GAAP basis |  | $ | 4,594 |  |  | $ | 4,741 |  |  | $ | 3,885 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 507 |  |  | 507 |  |  | 511 |  |  |  |  |  |
| Stock-based compensation expense |  | 1,940 |  |  | 1,958 |  |  | 1,127 |  |  |  |  |  |
| Restructuring and other charges |  | 103 |  |  | 146 |  |  | 172 |  |  |  |  |  |
| Acquisition-related costs |  | 2 |  |  | 12 |  |  | 107 |  |  |  |  |  |
| Total operating expenses on non-GAAP basis |  | $ | 2,042 |  |  | $ | 2,118 |  |  | $ | 1,968 |  |  |  |  |  |
| Operating income on GAAP basis |  | $ | 8,563 |  |  | $ | 7,508 |  |  | $ | 6,260 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,969 |  |  | 2,052 |  |  | 1,995 |  |  |  |  |  |
| Stock-based compensation expense |  | 2,176 |  |  | 2,195 |  |  | 1,280 |  |  |  |  |  |
| Restructuring and other charges |  | 116 |  |  | 154 |  |  | 186 |  |  |  |  |  |
| Acquisition-related costs |  | 2 |  |  | 12 |  |  | 107 |  |  |  |  |  |
| Operating income on non-GAAP basis |  | $ | 12,826 |  |  | $ | 11,921 |  |  | $ | 9,828 |  |  |  |  |  |
| Interest expense on GAAP basis |  | $ | (801) |  |  | $ | (761) |  |  | $ | (873) |  |  |  |  |  |
| Loss on debt extinguishment |  | 55 |  |  | 20 |  |  | 65 |  |  |  |  |  |
| Interest expense on non-GAAP basis |  | $ | (746) |  |  | $ | (741) |  |  | $ | (808) |  |  |  |  |  |
| Other income, net on GAAP basis |  | $ | 433 |  |  | $ | 122 |  |  | $ | 103 |  |  |  |  |  |
| Excise tax benefit |  | (315) |  |  | — |  |  | — |  |  |  |  |  |
| (Gains) losses on investments |  | — |  |  | (6) |  |  | 4 |  |  |  |  |  |
| Other |  | — |  |  | — |  |  | (31) |  |  |  |  |  |
| Other income, net on non-GAAP basis |  | $ | 118 |  |  | $ | 116 |  |  | $ | 76 |  |  |  |  |  |

[0001730168-26-000011:8k_2_02:69]
|  |  | Fiscal Quarter Ended |  |  |
|  |  | February 1,2026 |  | November 2,2025 |  | February 2,2025 |  |  |  |  |
| Provision for (benefit from) income taxes on GAAP basis |  | $ | 846 |  |  | $ | (1,649) |  |  | $ | (13) |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments (1) |  | 1,167 |  |  | 3,231 |  |  | 1,286 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | $ | 2,013 |  |  | $ | 1,582 |  |  | $ | 1,273 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 7,349 |  |  | $ | 8,518 |  |  | $ | 5,503 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,969 |  |  | 2,052 |  |  | 1,995 |  |  |  |  |  |
| Stock-based compensation expense |  | 2,176 |  |  | 2,195 |  |  | 1,280 |  |  |  |  |  |
| Restructuring and other charges |  | 116 |  |  | 154 |  |  | 186 |  |  |  |  |  |
| Acquisition-related costs |  | 2 |  |  | 12 |  |  | 107 |  |  |  |  |  |
| Loss on debt extinguishment |  | 55 |  |  | 20 |  |  | 65 |  |  |  |  |  |
| Excise tax benefit |  | (315) |  |  | — |  |  | — |  |  |  |  |  |
| (Gains) losses on investments |  | — |  |  | (6) |  |  | 4 |  |  |  |  |  |
| Other |  | — |  |  | — |  |  | (31) |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments (1) |  | (1,167) |  |  | (3,231) |  |  | (1,286) |  |  |  |  |  |
| Net income on non-GAAP basis |  | $ | 10,185 |  |  | $ | 9,714 |  |  | $ | 7,823 |  |  |  |  |  |
| Net income on GAAP basis |  | $ | 7,349 |  |  | $ | 8,518 |  |  | $ | 5,503 |  |  |  |  |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  | 1,969 |  |  | 2,052 |  |  | 1,995 |  |  |  |  |  |
| Stock-based compensation expense |  | 2,176 |  |  | 2,195 |  |  | 1,280 |  |  |  |  |  |
| Restructuring and other charges |  | 116 |  |  | 154 |  |  | 186 |  |  |  |  |  |
| Acquisition-related costs |  | 2 |  |  | 12 |  |  | 107 |  |  |  |  |  |
| Loss on debt extinguishment |  | 55 |  |  | 20 |  |  | 65 |  |  |  |  |  |
| Excise tax benefit |  | (315) |  |  | — |  |  | — |  |  |  |  |  |
| (Gains) losses on investments |  | — |  |  | (6) |  |  | 4 |  |  |  |  |  |
| Other |  | — |  |  | — |  |  | (31) |  |  |  |  |  |
| Non-GAAP tax reconciling adjustments (1) |  | (1,167) |  |  | (3,231) |  |  | (1,286) |  |  |  |  |  |
| Other Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 746 |  |  | 741 |  |  | 808 |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis |  | 2,013 |  |  | 1,582 |  |  | 1,273 |  |  |  |  |  |
| Depreciation |  | 150 |  |  | 148 |  |  | 142 |  |  |  |  |  |
| Amortization of purchased intangibles and right-of-use assets |  | 34 |  |  | 33 |  |  | 37 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 13,128 |  |  | $ | 12,218 |  |  | $ | 10,083 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on GAAP basis |  | 4,888 |  |  | 4,889 |  |  | 4,836 |  |  |  |  |  |
| Non-GAAP adjustment (2) |  | 69 |  |  | 80 |  |  | 59 |  |  |  |  |  |
| Weighted-average shares used in per share calculations - diluted on non-GAAP basis |  | 4,957 |  |  | 4,969 |  |  | 4,895 |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 8,260 |  |  | $ | 7,703 |  |  | $ | 6,113 |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (250) |  |  | (237) |  |  | (100) |  |  |  |  |  |
| Free cash flow |  | $ | 8,010 |  |  | $ | 7,466 |  |  | $ | 6,013 |  |  |  |  |  |

[0001730168-26-000011:8k_2_02:70]
|  |  | Fiscal Quarter Ending |
|  |  | May 3, |
| Expected average diluted share count (3): |  | 2026 |
| Weighted-average shares used in per share calculation - diluted on GAAP basis |  | 4,875 |  |
| Non-GAAP adjustment (2) |  | 69 |  |
| Weighted-average shares used in per share calculation - diluted on non-GAAP basis |  | 4,944 |  |

[0001730168-26-000011:8k_2_02:71]
| (1) For the fiscal quarter ended November 2, 2025, non-GAAP tax reconciling adjustments included a one-time discrete non-cash tax benefit of $2.1 billion from the impact of lapses of statutes of limitations. |
| (2) Non-GAAP adjustment for the number of shares used in the diluted per share calculations excludes the impact of stock-based compensation expense expected to be incurred in future periods and not yet recognized in the financial statements, which would otherwise be assumed to be used to repurchase shares under the GAAP treasury stock method. |
| (3) Excludes the effects of potential share repurchases. |

[0001730168-26-000011:8k_2_02:72]
BROADCOM INC.

[0001730168-26-000011:8k_2_02:73]
CONDENSED CONSOLIDATED BALANCE SHEETS — UNAUDITED

[0001730168-26-000011:8k_2_02:74]
(IN MILLIONS)

[0001730168-26-000011:8k_2_02:75]
|  |  | February 1,2026 |  | November 2,2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 14,174 |  |  | $ | 16,178 |  |
| Trade accounts receivable, net |  | 8,460 |  |  | 7,145 |  |
| Inventory |  | 2,962 |  |  | 2,270 |  |
| Other current assets |  | 6,466 |  |  | 5,980 |  |
| Total current assets |  | 32,062 |  |  | 31,573 |  |
| Long-term assets: |  |  |  |  |
| Property, plant and equipment, net |  | 2,599 |  |  | 2,530 |  |
| Goodwill |  | 97,801 |  |  | 97,801 |  |
| Intangible assets, net |  | 30,302 |  |  | 32,273 |  |
| Other long-term assets |  | 7,139 |  |  | 6,915 |  |
| Total assets |  | $ | 169,903 |  |  | $ | 171,092 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 2,112 |  |  | $ | 1,560 |  |
| Employee compensation and benefits |  | 864 |  |  | 2,129 |  |
| Short-term debt |  | 2,252 |  |  | 3,152 |  |
| Other current liabilities |  | 11,631 |  |  | 11,673 |  |
| Total current liabilities |  | 16,859 |  |  | 18,514 |  |
| Long-term liabilities: |  |  |  |  |
| Long-term debt |  | 63,805 |  |  | 61,984 |  |
| Other long-term liabilities |  | 9,367 |  |  | 9,302 |  |
| Total liabilities |  | 90,031 |  |  | 89,800 |  |
| Stockholders’ equity: |  |  |  |  |
| Preferred stock |  | — |  |  | — |  |
| Common Stock |  | 5 |  |  | 5 |  |
| Additional paid-in capital |  | 73,135 |  |  | 71,308 |  |
| Retained earnings |  | 6,520 |  |  | 9,761 |  |
| Accumulated other comprehensive income |  | 212 |  |  | 218 |  |
| Total stockholders' equity |  | 79,872 |  |  | 81,292 |  |
| Total liabilities and equity |  | $ | 169,903 |  |  | $ | 171,092 |  |

[0001730168-26-000011:8k_2_02:76]
| BROADCOM INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS — UNAUDITED |  |
| (IN MILLIONS) |  |
|  |  | Fiscal Quarter Ended |  |  |  |
|  |  | February 1,2026 |  | November 2,2025 |  | February 2,2025 |  |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,349 |  |  | $ | 8,518 |  |  | $ | 5,503 |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible and right-of-use assets |  | 2,003 |  |  | 2,085 |  |  | 2,032 |  |  |  |  |  |  |
| Depreciation |  | 150 |  |  | 148 |  |  | 142 |  |  |  |  |  |  |
| Stock-based compensation |  | 2,176 |  |  | 2,195 |  |  | 1,280 |  |  |  |  |  |  |
| Deferred taxes and other non-cash taxes |  | (455) |  |  | (3,025) |  |  | (696) |  |  |  |  |  |  |
| Loss on debt extinguishment |  | 55 |  |  | 20 |  |  | 65 |  |  |  |  |  |  |
| Non-cash interest expense |  | 72 |  |  | 71 |  |  | 97 |  |  |  |  |  |  |
| Other |  | 15 |  |  | 36 |  |  | 41 |  |  |  |  |  |  |
| Changes in assets and liabilities, net of acquisitions and disposals: |  |  |  |  |  |  |  |  |  |  |  |
| Trade accounts receivable, net |  | (1,315) |  |  | (651) |  |  | (539) |  |  |  |  |  |  |
| Inventory |  | (692) |  |  | (90) |  |  | (148) |  |  |  |  |  |  |
| Accounts payable |  | 534 |  |  | 118 |  |  | 241 |  |  |  |  |  |  |
| Employee compensation and benefits |  | (1,261) |  |  | 410 |  |  | (908) |  |  |  |  |  |  |
| Other current assets and current liabilities |  | (692) |  |  | (809) |  |  | 26 |  |  |  |  |  |  |
| Other long-term assets and long-term liabilities |  | 321 |  |  | (1,323) |  |  | (1,023) |  |  |  |  |  |  |
| Net cash provided by operating activities |  | 8,260 |  |  | 7,703 |  |  | 6,113 |  |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (250) |  |  | (237) |  |  | (100) |  |  |  |  |  |  |
| Purchases of investments |  | (114) |  |  | (336) |  |  | (105) |  |  |  |  |  |  |
| Sales of investments |  | 244 |  |  | 101 |  |  | 18 |  |  |  |  |  |  |
| Other |  | 5 |  |  | 105 |  |  | 13 |  |  |  |  |  |  |
| Net cash used in investing activities |  | (115) |  |  | (367) |  |  | (174) |  |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from long-term borrowings |  | 4,474 |  |  | 4,971 |  |  | 2,986 |  |  |  |  |  |  |
| Payments on debt obligations |  | (3,650) |  |  | (3,638) |  |  | (8,090) |  |  |  |  |  |  |
| Proceeds from (repayments of) commercial paper, net |  | — |  |  | (488) |  |  | 3,980 |  |  |  |  |  |  |
| Payments of dividends |  | (3,086) |  |  | (2,797) |  |  | (2,774) |  |  |  |  |  |  |
| Repurchases of common stock - repurchase program |  | (7,850) |  |  | — |  |  | — |  |  |  |  |  |  |
| Shares repurchased for tax withholdings on vesting of equity awards |  | — |  |  | — |  |  | (2,036) |  |  |  |  |  |  |
| Issuance of common stock |  | — |  |  | 103 |  |  | — |  |  |  |  |  |  |
| Other |  | (37) |  |  | (27) |  |  | (46) |  |  |  |  |  |  |
| Net cash used in financing activities |  | (10,149) |  |  | (1,876) |  |  | (5,980) |  |  |  |  |  |  |
| Net change in cash and cash equivalents |  | (2,004) |  |  | 5,460 |  |  | (41) |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | 16,178 |  |  | 10,718 |  |  | 9,348 |  |  |  |  |  |  |
| Cash and cash equivalents at end of period |  | $ | 14,174 |  |  | $ | 16,178 |  |  | $ | 9,307 |  |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 619 |  |  | $ | 699 |  |  | $ | 671 |  |  |  |  |  |  |
| Cash paid for income taxes |  | $ | 782 |  |  | $ | 755 |  |  | $ | 404 |  |  |  |  |  |  |
