# AVGO note change history — 0001730168-25-000098 → 0001730168-26-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-03-11):
[0001730168-26-000016:note_history:1]
The following table summarizes contractual obligations and commitments as of February 1, 2026:
  (was, 2025-09-10, similarity 0.9326):
[0001730168-25-000098:note_history:1]
The following table summarizes contractual obligations and commitments as of August 3, 2025:

- changed (2026-03-11):
[0001730168-26-000016:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 28 |  |  | $ | 763 |  |
| 2027 |  | 12 |  |  | 718 |  |
| 2028 |  | 10 |  |  | 736 |  |
| 2029 |  | 4 |  |  | 890 |  |
| 2030 |  | — |  |  | 300 |  |
| Thereafter |  | — |  |  | 873 |  |
| Total |  | $ | 54 |  |  | $ | 4,280 |  |
  (was, 2025-09-10, similarity 0.7911):
[0001730168-25-000098:note_history:2]
| Fiscal Year: |  | Purchase Commitments |  | Other Contractual Commitments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | 106 |  |  | $ | 264 |  |
| 2026 |  | 103 |  |  | 634 |  |
| 2027 |  | 12 |  |  | 604 |  |
| 2028 |  | 10 |  |  | 530 |  |
| 2029 |  | 4 |  |  | 718 |  |
| Thereafter |  | — |  |  | 1,027 |  |
| Total |  | $ | 235 |  |  | $ | 3,777 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of February 1, 2026, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $1,668 million of unrecognized tax benefits and accrued interest and penalties as of February 1, 2026 have been excluded from the table above.
  (was, 2025-09-10, similarity 0.8914):
[0001730168-25-000098:note_history:3]
Due to the inherent uncertainty with respect to the timing of future cash outflows associated with our unrecognized tax benefits as of August 3, 2025, we are unable to reliably estimate the timing of cash settlement with the respective taxing authorities. Therefore, $3,817 million of unrecognized tax benefits and accrued interest and penalties as of August 3, 2025 have been excluded from the table above.

- added (2026-03-11):
[0001730168-26-000016:note_history:4]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including but not limited to commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- added (2026-03-11):
[0001730168-26-000016:note_history:5]
We are currently engaged in a number of legal actions in the ordinary course of our business; however, we do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.

- removed (2026-03-11):
[0001730168-25-000098:note_history:6]
From time to time, we are involved in litigation that we believe is of the type common to companies engaged in our lines of business, including commercial disputes, employment issues, tax disputes and disputes involving claims by third parties that our activities infringe their patent, copyright, trademark or other IP rights, as well as regulatory investigations or inquiries. Legal proceedings and regulatory investigations or inquiries are often complex, may require the expenditure of significant funds and other resources, and the outcomes of such proceedings are inherently uncertain, with material adverse outcomes possible. IP property claims generally involve the demand by a third-party that we cease the manufacture, use or sale of the allegedly infringing products, processes or technologies and/or pay substantial damages or royalties for past, present and future use of the allegedly infringing IP. Claims that our products or processes infringe or misappropriate any third-party IP rights (including claims arising through our contractual indemnification of our customers) often involve highly complex, technical issues, the outcome of which is inherently uncertain. Moreover, from time to time, we pursue litigation to assert our IP rights. Regardless of the merit or resolution of any such litigation, complex IP litigation is generally costly and diverts the efforts and attention of our management and technical personnel.

- removed (2026-03-11):
[0001730168-25-000098:note_history:7]
Lawsuits Relating to VMware Backlog

- removed (2026-03-11):
[0001730168-25-000098:note_history:8]
On March 31, 2020, a securities class action lawsuit was filed against VMware and certain former officers of VMware in the United States District Court for the Northern District of California (the “California Court”). On September 18, 2020, the plaintiffs filed a consolidated amended complaint alleging that VMware’s statements about backlog and the related internal controls during the period from August 2018 through February 2020 were materially misleading. The defendants filed a motion to dismiss, which was granted with leave to amend on September 10, 2021. On October 8, 2021, the plaintiffs filed their Second Amended Consolidated Complaint based on the same alleged disclosure deficiencies. The defendants’ motion to dismiss the Second Amended Consolidated Complaint was filed on November 5, 2021. On April 2, 2023, the California Court denied the defendants’ motion to dismiss finding that the plaintiffs had adequately stated claims under Sections 10 and 20A of the Securities Exchange Act of 1934. The parties have agreed to settlement terms and in March 2025 the California Court approved the settlement.

- removed (2026-03-11):
[0001730168-25-000098:note_history:9]
Other Matters

- removed (2026-03-11):
[0001730168-25-000098:note_history:10]
We are currently engaged in a number of legal actions in the ordinary course of our business.

- removed (2026-03-11):
[0001730168-25-000098:note_history:11]
We do not believe, based on currently available facts and circumstances, that the final outcome of any pending legal proceedings, ongoing regulatory investigations or tax disputes, taken individually or as a whole, will have a material adverse effect on our condensed consolidated financial statements. However, lawsuits may involve complex questions of fact and law and may require the expenditure of significant funds and other resources to defend. The results of litigation, regulatory investigations or tax disputes are inherently uncertain, and material adverse outcomes are possible. From time to time, we may enter into confidential discussions regarding the potential settlement of such lawsuits. Any settlement of pending litigation could require us to incur substantial costs and other ongoing expenses, such as future royalty payments in the case of an IP dispute.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-03-11):
[0001730168-26-000016:note_history:12]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and semiconductor-based solutions and infrastructure software solutions. Our semiconductor and semiconductor-based solutions include a broad portfolio of complex digital and mixed signal devices based on silicon wafers with complementary metal oxide semiconductor transistors, III-V based devices, network interface cards and other modules, switches, subsystems and, in some cases, racks. Our solutions are used in a wide array of environments, end products and applications, such as enterprise and artificial intelligence (“AI”) data centers, servers and networking and connectivity equipment, as well as storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, wireless devices and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments. Our customers rely on our infrastructure and security software solutions to modernize, optimize, and secure the most complex private cloud, hybrid cloud and edge environments. This enables scalability, agility, automation, insights, resiliency and security, making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries.
  (was, 2025-09-10, similarity 0.6784):
[0001730168-25-000098:note_history:12]
Broadcom Inc. (“Broadcom”), a Delaware corporation, is a global technology leader that designs, develops and supplies a broad range of semiconductor and infrastructure software solutions. Our semiconductor solutions include a broad portfolio of complex digital and mixed signal complementary metal oxide semiconductor based devices, analog III-V based products, network interface cards and other modules, switches, subsystems and, in some cases, racks that are used in a wide array of environments, end products and applications such as artificial intelligence (“AI”) and enterprise data centers, servers, networking and connectivity equipment, storage systems, home connectivity devices, set-top boxes, broadband access, telecommunication equipment, smartphones and base stations, factory automation, power generation and alternative energy systems, and electronic displays. Our infrastructure software solutions help enterprises simplify their information technology (“IT”) environments so they can increase business velocity and flexibility, and enable customers to plan, develop, deliver, automate, manage and secure applications across mainframe, distributed, edge, mobile, and private and hybrid cloud platforms. Our portfolio of infrastructure and security software is designed to modernize, optimize, and secure the most complex private and hybrid cloud environments, enabling scalability, agility, automation, insights, resiliency and security making it easy for customers to run their mission-critical workloads. We also offer mission-critical fibre channel storage area networking (“FC SAN”) products and related software in the form of modules, switches and subsystems incorporating multiple semiconductor products. Unless stated otherwise or the context otherwise requires, references to “Broadcom,” “we,” “our,” and “us” mean Broadcom and its consolidated subsidiaries. We have two reportable segments: semiconductor solutions and infrastructure software.

- changed (2026-03-11):
[0001730168-26-000016:note_history:13]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal years ending November 1, 2026 (“fiscal year 2026”) and November 2, 2025 (“fiscal year 2025”) are both 52-week fiscal years.
  (was, 2025-09-10, similarity 0.7114):
[0001730168-25-000098:note_history:13]
We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31. Our fiscal year ending November 2, 2025 (“fiscal year 2025”) is a 52-week fiscal year. Our fiscal year ended November 3, 2024 (“fiscal year 2024”) was a 53-week fiscal year, with our first fiscal quarter containing 14 weeks.

- changed (2026-03-11):
[0001730168-26-000016:note_history:14]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 2, 2025 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2025 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended February 1, 2026 are not necessarily indicative of the results that may be expected for fiscal year 2026, or for any other future period.
  (was, 2025-09-10, similarity 0.8995):
[0001730168-25-000098:note_history:14]
The accompanying condensed consolidated financial statements include the accounts of Broadcom and its subsidiaries, and have been prepared in accordance with generally accepted accounting principles in the United States (“GAAP”) for interim financial information. The financial information included herein is unaudited, and reflects all adjustments which are, in the opinion of our management, of a normal recurring nature and necessary for a fair statement of the results for the periods presented. The November 3, 2024 condensed consolidated balance sheet data were derived from Broadcom’s audited consolidated financial statements included in its Annual Report on Form 10-K for fiscal year 2024 as filed with the Securities and Exchange Commission. All intercompany balances and transactions have been eliminated in consolidation. The operating results for the fiscal quarter ended August 3, 2025 are not necessarily indicative of the results that may be expected for fiscal year 2025, or for any other future period.

- added (2026-03-11):
[0001730168-26-000016:note_history:15]
Certain prior period amounts reported in our condensed consolidated statements of operations have been reclassified to conform to the current period presentation. See Note 2. “Revenue from Contracts with Customers” for additional information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-03-11):
[0001730168-26-000016:note_history:16]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:17]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
|  |  |  |  | 752 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 3,856 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 66,220 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |
  (was, 2025-09-10, similarity 0.7979):
[0001730168-25-000098:note_history:17]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 6,250 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |

- added (2026-03-11):
[0001730168-26-000016:note_history:18]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
| Total debt principal outstanding |  |  |  | 67,970 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,913) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 63,805 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:19]
__________________________
  (was, 2025-09-10, similarity 0.9286):
[0001730168-25-000098:note_history:19]
______________________________

- changed (2026-03-11):
[0001730168-26-000016:note_history:20]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate includes the impact of previously deferred gains on derivatives.
  (was, 2025-09-10, similarity 0.8036):
[0001730168-25-000098:note_history:20]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

- changed (2026-03-11):
[0001730168-26-000016:note_history:21]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. With the exception of the senior notes issued in September 2025 and January 2026, in the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Interest is paid semi-annually.
  (was, 2025-09-10, similarity 0.8768):
[0001730168-25-000098:note_history:21]
We may redeem or purchase, in whole or in part, any of our senior notes prior to their respective maturities, subject to a specified make-whole premium determined in accordance with the indentures governing the respective notes, plus accrued and unpaid interest. In the event of a change in control, note holders will have the right to require us to repurchase their notes at a price equal to 101% of the principal amount of such notes, plus accrued and unpaid interest. Each series of the senior notes pays interest semi-annually.

- added (2026-03-11):
[0001730168-26-000016:note_history:22]
In January 2026, we issued senior unsecured notes for an aggregate principal amount of $4,500 million. During the fiscal quarter ended February 1, 2026, we repaid and redeemed a total of $3,650 million of our senior notes.

- changed (2026-03-11):
[0001730168-26-000016:note_history:23]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. We had no borrowings outstanding under our revolving credit facility at either February 1, 2026 or November 2, 2025.
  (was, 2025-09-10, similarity 0.7787):
[0001730168-25-000098:note_history:23]
In January 2025, we entered into a credit agreement (the “2025 Credit Agreement”), which provides for a five-year $7.5 billion unsecured revolving credit facility, of which $500 million is available for the issuance of multi-currency letters of credit. The issuance of letters of credit under the revolving credit facility would reduce the aggregate amount otherwise available under such facility for revolving loans. Subject to the terms of the 2025 Credit Agreement, we are permitted to borrow, repay and reborrow revolving loans at any time prior to the earlier of (a) January 13, 2030 or (b) the date that the commitments are terminated either at our request or, if an event of default occurs, by the lenders. In connection with the 2025 Credit Agreement, we terminated the credit agreement entered into in January 2021, which provided for a five-year $7.5 billion unsecured revolving credit facility. We had no borrowings outstanding under our revolving credit facility at either August 3, 2025 or November 3, 2024.

- changed (2026-03-11):
[0001730168-26-000016:note_history:24]
Under our commercial paper program, we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. We had no commercial paper outstanding at either February 1, 2026 or November 2, 2025.
  (was, 2025-09-10, similarity 0.8287):
[0001730168-25-000098:note_history:24]
In January 2025, we increased the maximum amount of our commercial paper program, pursuant to which we may issue unsecured commercial paper notes in an aggregate principal amount of up to $4.0 billion outstanding at any time with maturities of up to 397 days from the date of issue. Commercial paper is sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of issuance. The discount associated with the commercial paper is amortized to interest expense over its term. As of August 3, 2025, we had $500 million of commercial paper outstanding with maturities ranging from 40 days to 187 days.

- changed (2026-03-11):
[0001730168-26-000016:note_history:25]
As of February 1, 2026, the estimated aggregate fair value of our debt was $65,738 million, which was determined using quoted prices from less active markets or other observable inputs. All of our debt obligations are categorized as Level 2 instruments.
  (was, 2025-09-10, similarity 0.7488):
[0001730168-25-000098:note_history:25]
As of August 3, 2025, the estimated aggregate fair value of our fixed-rate borrowings was $62,489 million, which was determined using quoted prices from less active markets or other observable inputs. The carrying value of commercial paper approximates its fair value due to the short-term nature of the instruments. All of our debt obligations are categorized as Level 2 instruments.

- changed (2026-03-11):
[0001730168-26-000016:note_history:26]
The future scheduled principal payments of our debt as of February 1, 2026 were as follows:
  (was, 2025-09-10, similarity 0.8063):
[0001730168-25-000098:note_history:26]
The future scheduled principal payments of senior notes and term loans as of August 3, 2025 were as follows:

- changed (2026-03-11):
[0001730168-26-000016:note_history:27]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 2,252 |  |
| 2027 |  | 1,743 |  |
| 2028 |  | 5,127 |  |
| 2029 |  | 4,655 |  |
| 2030 |  | 6,406 |  |
| Thereafter |  | 47,787 |  |
| Total |  | $ | 67,970 |  |
  (was, 2025-09-10, similarity 0.9952):
[0001730168-25-000098:note_history:27]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| Thereafter |  | 44,693 |  |
| Total |  | $ | 65,757 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:28]
As of February 1, 2026 and November 2, 2025, we were in compliance with all debt covenants.
  (was, 2025-09-10, similarity 0.9259):
[0001730168-25-000098:note_history:28]
As of August 3, 2025 and November 3, 2024, we were in compliance with all debt covenants.

- removed (2026-03-11):
[0001730168-25-000098:note_history:29]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| July 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | $ | 1,750 |  |  | $ | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:30]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.71 | % | (b) | 500 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 66,257 |  |  | $ | 69,847 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:31]
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes outstanding |  | $ | 900 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 496 |  |  | — |  |
| Short-term finance lease liabilities |  | 3 |  |  | 26 |  |
| Total short-term debt |  | $ | 1,399 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 64,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,034) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 62,830 |  |  | $ | 66,295 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:32]
(b) Represents the weighted average interest rate on commercial paper outstanding as of August 3, 2025.

- removed (2026-03-11):
[0001730168-25-000098:note_history:33]
We entered into a $750 million three-year term loan at a 4.489% fixed rate and a $1.0 billion three-year term loan at a 4.540% fixed rate on May 2, 2025 and May 9, 2025, respectively. Using the proceeds and cash on hand, we repaid the $750 million of senior notes that matured on May 15, 2025 and $3.4 billion of commercial paper during the fiscal quarter ended August 3, 2025.

- removed (2026-03-11):
[0001730168-25-000098:note_history:34]
In July 2025, we issued senior unsecured notes for an aggregate principal amount of $6,000 million. Using the net proceeds from these senior notes, we repaid the remaining $6,000 million of our unsecured term facility due November 2028. Upon repayment, we terminated the credit agreement entered into on August 15, 2023.

- removed (2026-03-11):
[0001730168-25-000098:note_history:35]
In January 2025, we issued senior unsecured notes for an aggregate principal amount of $3,000 million. Using the net proceeds from these senior notes and commercial paper issued in January 2025 and cash on hand, we repaid the remaining $5,595 million of our unsecured term facility due November 2026 and $2,000 million of our unsecured term facility due November 2028.

- removed (2026-03-11):
[0001730168-25-000098:note_history:36]
As a result of these repayments, we wrote off unamortized discount and issuance costs of $53 million during the fiscal quarter ended August 3, 2025, and $65 million during the fiscal quarter ended February 2, 2025, which were included in

- removed (2026-03-11):
[0001730168-25-000098:note_history:37]
interest expense in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-03-11):
[0001730168-26-000016:note_history:38]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| January 2026 Senior Notes |  |  |  |  |  |  |
| 4.300% notes due January 2031 |  | 4.41 | % |  | $ | 750 |  |  | $ | — |  |
| 4.600% notes due January 2033 |  | 4.72 | % |  | 1,250 |  |  | — |  |
| 4.950% notes due January 2036 |  | 5.03 | % |  | 1,250 |  |  | — |  |
| 5.700% notes due January 2056 |  | 5.79 | % |  | 1,250 |  |  | — |  |
|  |  |  |  | 4,500 |  |  | — |  |
| September 2025 Senior Notes |  |  |  |  |  |  |
| 4.200% notes due October 2030 |  | 4.34 | % |  | 1,000 |  |  | 1,000 |  |
| 4.800% notes due February 2036 |  | 4.90 | % |  | 2,250 |  |  | 2,250 |  |
| 4.900% notes due February 2038 |  | 4.99 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2025 Senior Notes |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | 1,750 |  |  | 1,750 |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | 1,750 |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |
| January 2025 Senior Notes |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | 1,100 |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | 800 |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | 1,100 |  |
|  |  |  |  | 3,000 |  |  | 3,000 |  |
| October 2024 Senior Notes |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | — |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 4,125 |  |  | 5,000 |  |
| July 2024 Senior Notes |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 493 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 4,243 |  |  | 5,000 |  |
| April 2022 Senior Notes |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:39]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | — |  |  | 1,118 |  |
|  |  |  |  | 752 |  |  | 1,870 |  |
| May 2020 Senior Notes |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | — |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 3,856 |  |  | 4,756 |  |
| April 2020 Senior Notes |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes |  |  |  |  |  |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
| Assumed VMware Senior Notes |  |  |  |  |  |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,750 |  |  | 5,750 |  |
| Other senior notes |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes outstanding |  |  |  | 66,220 |  |  | 65,370 |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | 1,000 |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | 750 |  |
  (was, 2025-09-10, similarity 0.7979):
[0001730168-25-000098:note_history:39]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| March 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.419% notes due April 2033 |  | 4.66 | % |  | 2,250 |  |  | 2,250 |  |
| 3.469% notes due April 2034 |  | 4.63 | % |  | 3,250 |  |  | 3,250 |  |
|  |  |  |  | 5,500 |  |  | 5,500 |  |
| January 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 1.950% notes due February 2028 |  | 2.10 | % |  | 750 |  |  | 750 |  |
| 2.450% notes due February 2031 |  | 2.56 | % |  | 2,750 |  |  | 2,750 |  |
| 2.600% notes due February 2033 |  | 2.70 | % |  | 1,750 |  |  | 1,750 |  |
| 3.500% notes due February 2041 |  | 3.60 | % |  | 3,000 |  |  | 3,000 |  |
| 3.750% notes due February 2051 |  | 3.84 | % |  | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 10,000 |  |  | 10,000 |  |
| June 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.459% notes due September 2026 |  | 4.19 | % |  | 752 |  |  | 752 |  |
| 4.110% notes due September 2028 |  | 5.02 | % |  | 1,118 |  |  | 1,118 |  |
|  |  |  |  | 1,870 |  |  | 1,870 |  |
| May 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.150% notes due November 2025 |  | 3.29 | % |  | 900 |  |  | 900 |  |
| 4.150% notes due November 2030 |  | 4.27 | % |  | 1,856 |  |  | 1,856 |  |
| 4.300% notes due November 2032 |  | 4.39 | % |  | 2,000 |  |  | 2,000 |  |
|  |  |  |  | 4,756 |  |  | 4,756 |  |
| April 2020 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.000% notes due April 2030 |  | 5.18 | % |  | 606 |  |  | 606 |  |
| April 2019 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.750% notes due April 2029 |  | 4.95 | % |  | 1,655 |  |  | 1,655 |  |
| 2017 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.125% notes due January 2025 |  | 3.23 | % |  | — |  |  | 495 |  |
| 3.875% notes due January 2027 |  | 4.02 | % |  | 2,922 |  |  | 2,922 |  |
| 3.500% notes due January 2028 |  | 3.60 | % |  | 777 |  |  | 777 |  |
|  |  |  |  | 3,699 |  |  | 4,194 |  |
| Assumed VMware Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due May 2025 |  | 5.81 | % |  | — |  |  | 750 |  |
| 1.400% notes due August 2026 |  | 5.60 | % |  | 1,500 |  |  | 1,500 |  |
| 4.650% notes due May 2027 |  | 5.60 | % |  | 500 |  |  | 500 |  |
| 3.900% notes due August 2027 |  | 5.50 | % |  | 1,250 |  |  | 1,250 |  |
| 1.800% notes due August 2028 |  | 5.44 | % |  | 750 |  |  | 750 |  |
| 4.700% notes due May 2030 |  | 5.75 | % |  | 750 |  |  | 750 |  |
| 2.200% notes due August 2031 |  | 5.74 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 6,250 |  |  | 7,000 |  |
| Assumed CA Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.700% notes due March 2027 |  | 5.15 | % |  | 215 |  |  | 215 |  |

- added (2026-03-11):
[0001730168-26-000016:note_history:40]
|  |  | Effective Interest Rate |  | February 1,2026 |  | November 2,2025 |
|  |  |  |  | (In millions) |
| Total term loans outstanding |  |  |  | 1,750 |  |  | 1,750 |  |
| Total debt principal outstanding |  |  |  | 67,970 |  |  | 67,120 |  |
| Less: Unamortized discount and issuance costs |  |  |  | (1,913) |  |  | (1,984) |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |
| Short-term debt |  |  |  | $ | 2,252 |  |  | $ | 3,152 |  |
| Long-term debt |  |  |  | 63,805 |  |  | 61,984 |  |
| Total debt |  |  |  | $ | 66,057 |  |  | $ | 65,136 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:41]
__________________________
  (was, 2025-09-10, similarity 0.9286):
[0001730168-25-000098:note_history:41]
______________________________

- changed (2026-03-11):
[0001730168-26-000016:note_history:42]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate includes the impact of previously deferred gains on derivatives.
  (was, 2025-09-10, similarity 0.8036):
[0001730168-25-000098:note_history:42]
(a) In addition to contractual interest, discount and issuance costs, the effective interest rate also includes reclassification of the cumulative gain from derivatives.

- removed (2026-03-11):
[0001730168-25-000098:note_history:43]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| July 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.600% notes due July 2030 |  | 4.49 | % | (a) | $ | 1,750 |  |  | $ | — |  |
| 4.900% notes due July 2032 |  | 5.04 | % |  | 1,750 |  |  | — |  |
| 5.200% notes due July 2035 |  | 4.77 | % | (a) | 2,500 |  |  | — |  |
|  |  |  |  | 6,000 |  |  | — |  |
| 4.540% term loan due May 2028 |  | 4.59 | % |  | 1,000 |  |  | — |  |
| 4.489% term loan due May 2028 |  | 4.55 | % |  | 750 |  |  | — |  |
| January 2025 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.800% notes due April 2028 |  | 5.03 | % |  | 1,100 |  |  | — |  |
| 5.050% notes due April 2030 |  | 5.20 | % |  | 800 |  |  | — |  |
| 5.200% notes due April 2032 |  | 5.34 | % |  | 1,100 |  |  | — |  |
|  |  |  |  | 3,000 |  |  | — |  |
| October 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.150% notes due February 2028 |  | 4.36 | % |  | 875 |  |  | 875 |  |
| 4.350% notes due February 2030 |  | 4.51 | % |  | 1,500 |  |  | 1,500 |  |
| 4.550% notes due February 2032 |  | 4.70 | % |  | 875 |  |  | 875 |  |
| 4.800% notes due October 2034 |  | 4.38 | % | (a) | 1,750 |  |  | 1,750 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| July 2024 Senior Notes - fixed rate |  |  |  |  |  |  |
| 5.050% notes due July 2027 |  | 5.27 | % |  | 1,250 |  |  | 1,250 |  |
| 5.050% notes due July 2029 |  | 5.23 | % |  | 2,250 |  |  | 2,250 |  |
| 5.150% notes due November 2031 |  | 5.30 | % |  | 1,500 |  |  | 1,500 |  |
|  |  |  |  | 5,000 |  |  | 5,000 |  |
| 2023 Term Loans - floating rate |  |  |  |  |  |  |
| SOFR plus 1.125% term loan due November 2026 |  | 6.23 | % |  | — |  |  | 5,595 |  |
| SOFR plus 1.125% term loan due November 2028 |  | 5.63 | % |  | — |  |  | 8,000 |  |
|  |  |  |  | — |  |  | 13,595 |  |
| April 2022 Senior Notes - fixed rate |  |  |  |  |  |  |
| 4.000% notes due April 2029 |  | 4.17 | % |  | 750 |  |  | 750 |  |
| 4.150% notes due April 2032 |  | 4.30 | % |  | 1,200 |  |  | 1,200 |  |
| 4.926% notes due May 2037 |  | 5.33 | % |  | 2,500 |  |  | 2,500 |  |
|  |  |  |  | 4,450 |  |  | 4,450 |  |
| September 2021 Senior Notes - fixed rate |  |  |  |  |  |  |
| 3.137% notes due November 2035 |  | 4.23 | % |  | 3,250 |  |  | 3,250 |  |
| 3.187% notes due November 2036 |  | 4.79 | % |  | 2,750 |  |  | 2,750 |  |
|  |  |  |  | 6,000 |  |  | 6,000 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:44]
|  |  | Effective Interest Rate |  | August 3,2025 |  | November 3,2024 |
|  |  |  |  | (In millions) |
| Other senior notes - fixed rate |  |  |  |  |  |  |
| 4.500% notes due August 2034 |  | 4.55 | % |  | 6 |  |  | 6 |  |
| Total senior notes and term loans outstanding |  |  |  | 65,757 |  |  | 69,847 |  |
| Commercial paper |  | 4.71 | % | (b) | 500 |  |  | — |  |
| Total debt principal outstanding |  |  |  | $ | 66,257 |  |  | $ | 69,847 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:45]
| Short-Term Debt: |  |  |  |  |
| Current portion of senior notes outstanding |  | $ | 900 |  |  | $ | 1,245 |  |
| Commercial paper, net |  | 496 |  |  | — |  |
| Short-term finance lease liabilities |  | 3 |  |  | 26 |  |
| Total short-term debt |  | $ | 1,399 |  |  | $ | 1,271 |  |
| Long-Term Debt: |  |  |  |  |
| Non-current portion of senior notes and term loans outstanding |  | $ | 64,857 |  |  | $ | 68,602 |  |
| Long-term finance lease liabilities |  | 7 |  |  | 13 |  |
| Unamortized discount and issuance costs |  | (2,034) |  |  | (2,320) |  |
| Total long-term debt |  | $ | 62,830 |  |  | $ | 66,295 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:46]
(b) Represents the weighted average interest rate on commercial paper outstanding as of August 3, 2025.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-03-11):
[0001730168-26-000016:note_history:47]
The future scheduled principal payments of our debt as of February 1, 2026 were as follows:
  (was, 2025-09-10, similarity 0.8063):
[0001730168-25-000098:note_history:47]
The future scheduled principal payments of senior notes and term loans as of August 3, 2025 were as follows:

- changed (2026-03-11):
[0001730168-26-000016:note_history:48]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2026 (remainder) |  | $ | 2,252 |  |
| 2027 |  | 1,743 |  |
| 2028 |  | 5,127 |  |
| 2029 |  | 4,655 |  |
| 2030 |  | 6,406 |  |
| Thereafter |  | 47,787 |  |
| Total |  | $ | 67,970 |  |
  (was, 2025-09-10, similarity 0.9952):
[0001730168-25-000098:note_history:48]
| Fiscal Year: |  | Future Scheduled Principal Payments |
|  |  | (In millions) |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  | 3,152 |  |
| 2027 |  | 6,137 |  |
| 2028 |  | 7,120 |  |
| 2029 |  | 4,655 |  |
| Thereafter |  | 44,693 |  |
| Total |  | $ | 65,757 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-03-11):
[0001730168-26-000016:note_history:49]
The following tables present revenue disaggregated by type and by region for the periods presented:
  (was, 2025-09-10, similarity 0.9474):
[0001730168-25-000098:note_history:49]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

- added (2026-03-11):
[0001730168-26-000016:note_history:50]
|  |  | Fiscal Quarter Ended February 1, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,164 |  |  | $ | 10,950 |  |  | $ | 1,016 |  |  | $ | 14,130 |  |
| Subscriptions and services |  | 2,917 |  |  | 665 |  |  | 1,599 |  |  | 5,181 |  |
| Total |  | $ | 5,081 |  |  | $ | 11,615 |  |  | $ | 2,615 |  |  | $ | 19,311 |  |

- added (2026-03-11):
[0001730168-26-000016:note_history:51]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,935 |  |  | $ | 7,333 |  |  | $ | 875 |  |  | $ | 10,143 |  |
| Subscriptions and services |  | 2,697 |  |  | 699 |  |  | 1,377 |  |  | 4,773 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:52]
|  |  | Fiscal Quarter Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 662 |  |  | $ | 8,181 |  |  | $ | 414 |  |  | $ | 9,257 |  |
| Subscriptions and services |  | 4,062 |  |  | 779 |  |  | 1,854 |  |  | 6,695 |  |
| Total |  | $ | 4,724 |  |  | $ | 8,960 |  |  | $ | 2,268 |  |  | $ | 15,952 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:53]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:54]
|  |  | Three Fiscal Quarters Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,787 |  |  | $ | 22,904 |  |  | $ | 1,243 |  |  | $ | 25,934 |  |
| Subscriptions and services |  | 12,275 |  |  | 2,188 |  |  | 5,475 |  |  | 19,938 |  |
| Total |  | $ | 14,062 |  |  | $ | 25,092 |  |  | $ | 6,718 |  |  | $ | 45,872 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:55]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2026-03-11):
[0001730168-25-000098:note_history:56]
We account for a contract with a customer when both parties have approved the contract and are committed to perform their respective obligations, each party’s rights can be identified, payment terms can be identified, the contract has commercial substance, and it is probable that we will collect substantially all of the consideration to which we are entitled. Revenue is recognized when, or as, performance obligations are satisfied by transferring control of a promised product or service to a customer.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-03-11):
[0001730168-26-000016:note_history:57]
Reclassifications to Condensed Consolidated Statements of Operations

- added (2026-03-11):
[0001730168-26-000016:note_history:58]
For software arrangements without termination for convenience provisions, we recognize revenue for the license portion of the agreements upfront upon transfer of control to the customer, referred to as upfront license revenue. In the fiscal quarter ended February 1, 2026, we included upfront license revenue of $1,755 million within products revenue, and the related costs, which were immaterial, in cost of products sold, in our condensed consolidated statements of operations. To conform to the current period presentation, we reclassified $1,972 million of upfront license revenue from subscriptions and services revenue to products revenue for the fiscal quarter ended February 2, 2025. We also reclassified the related costs for the upfront license revenue, which were immaterial.

- added (2026-03-11):
[0001730168-26-000016:note_history:59]
In the revenue disaggregation tables by type and by region presented below, we included $1,061 million, $124 million and $570 million of upfront license revenue in products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 1, 2026. To conform to the current period presentation, we reclassified $1,445 million, $64 million and $463 million of upfront license revenue from subscriptions and services revenue to products revenue within the Americas; Asia Pacific; and Europe, the Middle East and Africa regions, respectively, for the fiscal quarter ended February 2, 2025.

- changed (2026-03-11):
[0001730168-26-000016:note_history:60]
The following tables present revenue disaggregated by type and by region for the periods presented:
  (was, 2025-09-10, similarity 0.9474):
[0001730168-25-000098:note_history:60]
The following tables present revenue disaggregated by type of revenue and by region for the periods presented:

- added (2026-03-11):
[0001730168-26-000016:note_history:61]
|  |  | Fiscal Quarter Ended February 1, 2026 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 2,164 |  |  | $ | 10,950 |  |  | $ | 1,016 |  |  | $ | 14,130 |  |
| Subscriptions and services |  | 2,917 |  |  | 665 |  |  | 1,599 |  |  | 5,181 |  |
| Total |  | $ | 5,081 |  |  | $ | 11,615 |  |  | $ | 2,615 |  |  | $ | 19,311 |  |

- added (2026-03-11):
[0001730168-26-000016:note_history:62]
|  |  | Fiscal Quarter Ended February 2, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,935 |  |  | $ | 7,333 |  |  | $ | 875 |  |  | $ | 10,143 |  |
| Subscriptions and services |  | 2,697 |  |  | 699 |  |  | 1,377 |  |  | 4,773 |  |
| Total |  | $ | 4,632 |  |  | $ | 8,032 |  |  | $ | 2,252 |  |  | $ | 14,916 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:63]
|  |  | February 1,2026 |  | November 2,2025 |
|  | (In millions) |
| Contract Assets |  | $ | 9,347 |  |  | $ | 8,922 |  |
| Contract Liabilities |  | $ | 12,855 |  |  | $ | 13,016 |  |
  (was, 2025-09-10, similarity 0.9586):
[0001730168-25-000098:note_history:63]
|  |  | August 3,2025 |  | November 3,2024 |
|  | (In millions) |
| Contract Assets |  | $ | 7,575 |  |  | $ | 4,402 |  |
| Contract Liabilities |  | $ | 14,336 |  |  | $ | 14,495 |  |

- changed (2026-03-11):
[0001730168-26-000016:note_history:64]
As of February 1, 2026, approximately 67% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the fiscal quarter ended February 1, 2026 that was included in the contract liabilities balance as of November 2, 2025 was $3,915 million. The amount of revenue recognized during the fiscal quarter ended February 2, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $3,583 million.
  (was, 2025-09-10, similarity 0.9007):
[0001730168-25-000098:note_history:64]
As of August 3, 2025, approximately 66% of contract liabilities related to contracts subject to termination for convenience provisions. The amount of revenue recognized during the three fiscal quarters ended August 3, 2025 that was included in the contract liabilities balance as of November 3, 2024 was $8,021 million. The amount of revenue recognized during the three fiscal quarters ended August 4, 2024 that was included in the contract liabilities balance as of October 29, 2023 was $2,280 million.

- changed (2026-03-11):
[0001730168-26-000016:note_history:65]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of February 1, 2026 were approximately $45.0 billion. We expect approximately 33% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.
  (was, 2025-09-10, similarity 0.9892):
[0001730168-25-000098:note_history:65]
Certain multi-year customer contracts in our semiconductor solutions segment and infrastructure software segment, including contracts where customers do not have termination rights, contain firmly committed amounts and the remaining performance obligations under these contracts as of August 3, 2025 were approximately $27.5 billion. We expect approximately 34% of this amount to be recognized as revenue over the next 12 months. For contracts with termination for convenience rights, our customers generally do not exercise those rights. Accordingly, our remaining performance obligations disclosed above are not indicative of revenue for future periods.

- removed (2026-03-11):
[0001730168-25-000098:note_history:66]
|  |  | Fiscal Quarter Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 662 |  |  | $ | 8,181 |  |  | $ | 414 |  |  | $ | 9,257 |  |
| Subscriptions and services |  | 4,062 |  |  | 779 |  |  | 1,854 |  |  | 6,695 |  |
| Total |  | $ | 4,724 |  |  | $ | 8,960 |  |  | $ | 2,268 |  |  | $ | 15,952 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:67]
|  |  | Fiscal Quarter Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 582 |  |  | $ | 6,411 |  |  | $ | 446 |  |  | $ | 7,439 |  |
| Subscriptions and services |  | 3,409 |  |  | 630 |  |  | 1,594 |  |  | 5,633 |  |
| Total |  | $ | 3,991 |  |  | $ | 7,041 |  |  | $ | 2,040 |  |  | $ | 13,072 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:68]
|  |  | Three Fiscal Quarters Ended August 3, 2025 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,787 |  |  | $ | 22,904 |  |  | $ | 1,243 |  |  | $ | 25,934 |  |
| Subscriptions and services |  | 12,275 |  |  | 2,188 |  |  | 5,475 |  |  | 19,938 |  |
| Total |  | $ | 14,062 |  |  | $ | 25,092 |  |  | $ | 6,718 |  |  | $ | 45,872 |  |

- removed (2026-03-11):
[0001730168-25-000098:note_history:69]
|  |  | Three Fiscal Quarters Ended August 4, 2024 |
|  |  | Americas |  | Asia Pacific |  | Europe, the Middle East and Africa |  | Total |
|  |  | (In millions) |
| Products |  | $ | 1,763 |  |  | $ | 18,869 |  |  | $ | 1,411 |  |  | $ | 22,043 |  |
| Subscriptions and services |  | 9,187 |  |  | 1,623 |  |  | 4,667 |  |  | 15,477 |  |
| Total |  | $ | 10,950 |  |  | $ | 20,492 |  |  | $ | 6,078 |  |  | $ | 37,520 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-03-11):
[0001730168-26-000016:note_history:70]
On March 3, 2026, our Board of Directors declared a quarterly cash dividend of $0.65 per share on our common stock, payable on March 31, 2026 to stockholders of record on March 23, 2026.
  (was, 2025-09-10, similarity 0.9133):
[0001730168-25-000098:note_history:70]
On September 3, 2025, our Board of Directors declared a quarterly cash dividend of $0.59 per share on our common stock, payable on September 30, 2025 to stockholders of record on September 22, 2025.
