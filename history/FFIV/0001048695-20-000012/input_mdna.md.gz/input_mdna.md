# FFIV MD&A — 0001048695-20-000012


## mdna

[0001048695-20-000012:mdna:1]
[same as prior period, unchanged from 0001048695-19-000030:mdna:1]

[0001048695-20-000012:mdna:2]
[same as prior period, unchanged from 0001048695-19-000030:mdna:2]

[0001048695-20-000012:mdna:3]
F5 is a leading provider of multi-cloud application services which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and healthcare industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-20-000012:mdna:4]
[same as prior period, unchanged from 0001048695-19-000030:mdna:5]

[0001048695-20-000012:mdna:5]
[same as prior period, unchanged from 0001048695-19-000030:mdna:6]

[0001048695-20-000012:mdna:6]
[same as prior period, unchanged from 0001048695-19-000030:mdna:7]

[0001048695-20-000012:mdna:7]
[same as prior period, unchanged from 0001048695-19-000030:mdna:8]

[0001048695-20-000012:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first three months of fiscal year 2020 was primarily due to cash provided by operating activities of $144.0 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $22.3 million for the first three months of fiscal year 2020 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-20-000012:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2020 primarily due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding at the end of the first quarter of fiscal year 2020 was 56. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter. |

[0001048695-20-000012:mdna:10]
[same as prior period, unchanged from 0001048695-19-000030:mdna:12]

[0001048695-20-000012:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition and accounting for business combinations.

[0001048695-20-000012:mdna:12]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K for the fiscal year ended September 30, 2019. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-20-000012:mdna:13]
[same as prior period, unchanged from 0001048695-19-000030:mdna:15]

[0001048695-20-000012:mdna:14]
[same as prior period, unchanged from 0001048695-19-000030:mdna:16]

[0001048695-20-000012:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 234,536 |  |  | $ | 233,877 |  |
| Services |  | 334,769 |  |  | 309,893 |  |
| Total |  | $ | 569,305 |  |  | $ | 543,770 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 41.2 | % |  | 43.0 | % |
| Services |  | 58.8 |  |  | 57.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-20-000012:mdna:16]
23

[0001048695-20-000012:mdna:17]
Net revenues. Total net revenues increased 4.7% for the three months ended December 31, 2019, from the comparable period in the prior year. Overall revenue growth for the three months ended December 31, 2019, was primarily due to increased software revenue including our subscription-based products and increased service revenues as a result of our increased installed base of products. International revenues represented 51.6% of total net revenues for the three months ended December 31, 2019, compared to 51.3% for the same period in the prior year.

[0001048695-20-000012:mdna:18]
Net product revenues remained relatively flat for the three months ended December 31, 2019, from the comparable period in the prior year.

[0001048695-20-000012:mdna:19]
Net service revenues increased 8.0% for the three months ended December 31, 2019, from the comparable period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-20-000012:mdna:20]
[same as prior period, unchanged from 0001048695-19-000030:mdna:21]

[0001048695-20-000012:mdna:21]
|  | Three months endedDecember 31, |
|  | 2019 |  | 2018 |
| Ingram Micro, Inc. | 16.5 | % |  | 16.8 | % |
| Westcon Group, Inc. | 11.0 | % |  | 11.3 | % |
| Arrow ECS | 10.1 | % |  | 10.9 | % |

[0001048695-20-000012:mdna:22]
[same as prior period, unchanged from 0001048695-19-000030:mdna:24]

[0001048695-20-000012:mdna:23]
|  | December 31, 2019 |  | September 30, 2019 |
| Ingram Micro, Inc. | 12.1 | % |  | 12.4 | % |
| Arrow ECS | 11.9 | % |  | — |  |
| Carahsoft Technology | 11.5 | % |  | 11.5 | % |
| Westcon Group, Inc. | 10.8 | % |  | — |  |
| Synnex Corporation | 10.7 | % |  | 12.9 | % |

[0001048695-20-000012:mdna:24]
[same as prior period, unchanged from 0001048695-19-000030:mdna:26]

[0001048695-20-000012:mdna:25]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 42,118 |  |  | $ | 42,410 |  |
| Services |  | 46,524 |  |  | 44,304 |  |
| Total |  | 88,642 |  |  | 86,714 |  |
| Gross profit |  | $ | 480,663 |  |  | $ | 457,056 |  |
| Percentage of net revenues and gross profit (as a percentage of related net revenue) |
| Products |  | 18.0 | % |  | 18.1 | % |
| Services |  | 13.9 |  |  | 14.3 |  |
| Total |  | 15.6 |  |  | 15.9 |  |
| Gross profit |  | 84.4 | % |  | 84.1 | % |

[0001048695-20-000012:mdna:26]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues remained relatively flat for the three months ended December 31, 2019, from the comparable period in the prior year, consistent with the trend in product revenues.

[0001048695-20-000012:mdna:27]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2019, cost of net service revenues as a percentage of net service revenues was 13.9%, compared to 14.3% for the comparable period in the prior year. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of December 2019 increased to 921 from 896 at the end of December 2018.

[0001048695-20-000012:mdna:28]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 195,519 |  |  | $ | 164,259 |  |
| Research and development |  | 96,005 |  |  | 92,038 |  |
| General and administrative |  | 59,004 |  |  | 42,543 |  |
| Restructuring charges |  | 7,800 |  |  | — |  |
| Total |  | $ | 358,328 |  |  | $ | 298,840 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 34.3 | % |  | 30.2 | % |
| Research and development |  | 16.9 |  |  | 16.9 |  |
| General and administrative |  | 10.4 |  |  | 7.8 |  |
| Restructuring charges |  | 1.4 |  |  | — |  |
| Total |  | 63.0 | % |  | 54.9 | % |

[0001048695-20-000012:mdna:29]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $31.3 million, or 19.0% for the three months ended December 31, 2019, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $13.6 million in personnel costs for the three months ended December 31, 2019 from the comparable period in the prior year. In addition, facilities costs for our Sales and Marketing organization increased $3.0 million for the three months ended December 31, 2019 from the comparable period in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. Sales and marketing headcount at the end of December 2019 increased to 2,123 from 1,774 at the end of December 2018. Sales and marketing expenses included stock-based compensation expense of $21.8 million for the three months ended December 31, 2019, compared to $15.5 million for the same period in the prior year.

[0001048695-20-000012:mdna:30]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $4.0 million, or 4.3% for the three months ended December 31, 2019 from the comparable period in the prior year. The increase in research and development expense was primarily due to an increase of $2.2 million in personnel costs for the three months ended December 31, 2019 from the comparable period in the prior year, as well as a $2.4 million increase in facilities costs primarily due to the move of our corporate headquarters which began in April 2019. Research and development headcount at the end of December 2019 increased to 1,534 from 1,320 at the end of December 2018. Research and development expenses included stock-based compensation expense of $11.2 million for the three months ended December 31, 2019 compared to $10.3 million for the same period in the prior year.

[0001048695-20-000012:mdna:31]
25

[0001048695-20-000012:mdna:32]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $16.5 million, or 38.7% for the three months ended December 31, 2019 from the comparable period in the prior year. The increase in general and administrative expenses was primarily due to an increase of $6.4 million in fees paid to outside consultants for legal, accounting and tax services for the three months ended December 31, 2019 from the comparable period in the prior year. In addition, personnel costs increased $4.2 million for the three months ended December 31, 2019 from the comparable period in the prior year due to growth in general and administrative headcount, including employees from the acquisition of NGINX. General and administrative expenses for the three months ended December 31, 2019 also included an increase in facilities cost of $1.9 million from the comparable period in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. General and administrative headcount at the end of December 2019 increased to 616 from 494 at the end of December 2018. General and administrative expenses included stock-based compensation expense of $9.2 million for the three months ended December 31, 2019 compared to $7.8 million for the same period in the prior year.

[0001048695-20-000012:mdna:33]
Restructuring charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million related to a reduction in workforce.

[0001048695-20-000012:mdna:34]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 122,335 |  |  | $ | 158,216 |  |
| Other income, net |  | 5,220 |  |  | 7,095 |  |
| Income before income taxes |  | 127,555 |  |  | 165,311 |  |
| Provision for income taxes |  | 29,028 |  |  | 34,406 |  |
| Net income |  | $ | 98,527 |  |  | $ | 130,905 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 21.5 | % |  | 29.1 | % |
| Other income, net |  | 0.9 |  |  | 1.3 |  |
| Income before income taxes |  | 22.4 |  |  | 30.4 |  |
| Provision for income taxes |  | 5.1 |  |  | 6.3 |  |
| Net income |  | 17.3 | % |  | 24.1 | % |

[0001048695-20-000012:mdna:35]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The decrease in other income, net for the three months ended December 31, 2019 was primarily due to a decrease in interest income of $1.4 million from our investments compared to the same period in the prior year.

[0001048695-20-000012:mdna:36]
Provision for income taxes. The effective tax rate was 22.8% and 20.8% for the three months ended December 31, 2019 and 2018, respectively. The increase in the effective tax rate for the three months ended December 31, 2019 as compared to the three months ended December 31, 2018 is primarily due to the tax impact from stock-based compensation.

[0001048695-20-000012:mdna:37]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2019 and September 30, 2019 were $29.1 million and $27.4 million, respectively. The net deferred tax assets include valuation allowances of $23.4 million and $23.5 million as of December 31, 2019 and September 30, 2019, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-20-000012:mdna:38]
[same as prior period, unchanged from 0001048695-19-000030:mdna:39]

[0001048695-20-000012:mdna:39]
[same as prior period, unchanged from 0001048695-19-000030:mdna:40]

[0001048695-20-000012:mdna:40]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,474.3 million as of December 31, 2019, compared to $1,330.7 million as of September 30, 2019, representing an increase of $143.6 million. The increase was primarily due to cash provided by operating activities of $144.0 million for the three months ended December 31, 2019. Cash provided by operating activities for the first three months of fiscal year 2020 resulted from net income of $98.5 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-20-000012:mdna:41]
Cash used in investing activities was $29.4 million for the three months ended December 31, 2019, compared to cash used in investing activities of $60.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the three months ended December 31, 2019 was primarily the result of capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-20-000012:mdna:42]
Cash provided by financing activities was $21.0 million for the three months ended December 31, 2019, compared to cash used in financing activities of $82.1 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2019 consisted of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $21.0 million.

[0001048695-20-000012:mdna:43]
[same as prior period, unchanged from 0001048695-19-000030:mdna:44]

[0001048695-20-000012:mdna:44]
As of December 31, 2019, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

[0001048695-20-000012:mdna:45]
[same as prior period, unchanged from 0001048695-19-000030:mdna:46]

[0001048695-20-000012:mdna:46]
[same as prior period, unchanged from 0001048695-19-000030:mdna:47]

[0001048695-20-000012:mdna:47]
[same as prior period, unchanged from 0001048695-19-000030:mdna:48]
