# FFIV note change history — 0001048695-19-000030 → 0001048695-20-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001048695-20-000012:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2019 and September 30, 2019 were not material.
  (was, 2019-08-02, similarity 0.9227):
[0001048695-19-000030:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2019 and September 30, 2018 were not considered material.

- changed (2020-02-05):
[0001048695-20-000012:note_history:2]
As of December 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.
  (was, 2019-08-02, similarity 0.9837):
[0001048695-19-000030:note_history:2]
As of June 30, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- added (2020-02-05):
[0001048695-20-000012:note_history:3]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.

- removed (2020-02-05):
[0001048695-19-000030:note_history:4]
Legal Proceedings

- removed (2020-02-05):
[0001048695-19-000030:note_history:5]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint sought a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents. The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims. F5's claims against Radware were later dismissed pursuant to a settlement agreement, the terms of which are confidential. The settlement did not have a material impact to the Company's consolidated financial statements.

- removed (2020-02-05):
[0001048695-19-000030:note_history:6]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0001048695-20-000012:note_history:7]
F5 Networks, Inc. (the “Company”) is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

- added (2020-02-05):
[0001048695-20-000012:note_history:8]
Certain prior year amounts have been reclassified to conform to the current year presentation in the Consolidated Statements of Cash Flows. The reclassified amounts are considered immaterial and there was no change to total cash from operating, investing or financing activities as a result.

- added (2020-02-05):
[0001048695-20-000012:note_history:9]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2019, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 7 - Leases.

- added (2020-02-05):
[0001048695-20-000012:note_history:10]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 7 - Leases for further discussion.

- added (2020-02-05):
[0001048695-20-000012:note_history:11]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.

- added (2020-02-05):
[0001048695-20-000012:note_history:12]
The Company includes in minimum lease payments, fixed and variable payments based on a rate or index, but excludes variable payments based on satisfying future benchmarks or actual future costs incurred; such amounts are expensed as incurred. To calculate the net present value, the Company applied an incremental borrowing rate. This incremental borrowing rate is determined using a portfolio approach based on the rate of interest the Company would pay to borrow an amount equal to the lease payments on a collateralized basis over a similar term. Renewal options to extend lease terms are excluded from the minimum lease term at lease commencement.

- changed (2020-02-05):
[0001048695-20-000012:note_history:13]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.
  (was, 2019-08-02, similarity 0.9138):
[0001048695-19-000030:note_history:13]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted.

- removed (2020-02-05):
[0001048695-19-000030:note_history:14]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance. On May 8, 2019, the Company completed the acquisition of Nginx, Inc. ("Nginx"), the open source leader in application delivery for modern applications. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand.

- removed (2020-02-05):
[0001048695-19-000030:note_history:15]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended June 30, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.

- removed (2020-02-05):
[0001048695-19-000030:note_history:16]
Revenue Recognition

- removed (2020-02-05):
[0001048695-19-000030:note_history:17]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

- removed (2020-02-05):
[0001048695-19-000030:note_history:18]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

- removed (2020-02-05):
[0001048695-19-000030:note_history:19]
| • | Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:20]
| • | Identify the performance obligations in the contract. Performance obligations are explicitly identified in the Company's contracts and include hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:21]
| • | Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:22]
| • | Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:23]
| • | Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:24]
The following is a description of the principal activities from which the Company generates revenue:

- removed (2020-02-05):
[0001048695-19-000030:note_history:25]
Product

- removed (2020-02-05):
[0001048695-19-000030:note_history:26]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been delivered and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

- removed (2020-02-05):
[0001048695-19-000030:note_history:27]
Subscription

- removed (2020-02-05):
[0001048695-19-000030:note_history:28]
The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based Silverline platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service Silverline offerings, revenue is recognized ratably as the services are provided.

- removed (2020-02-05):
[0001048695-19-000030:note_history:29]
Support and professional services

- removed (2020-02-05):
[0001048695-19-000030:note_history:30]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

- removed (2020-02-05):
[0001048695-19-000030:note_history:31]
Contract acquisition costs

- removed (2020-02-05):
[0001048695-19-000030:note_history:32]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

- removed (2020-02-05):
[0001048695-19-000030:note_history:33]
Significant Judgments

- removed (2020-02-05):
[0001048695-19-000030:note_history:34]
The Company’s contracts with customers often include promises to transfer multiple products and services. Determining whether products and services are considered distinct performance obligations that should be accounted for separately versus together may require significant judgment.

- removed (2020-02-05):
[0001048695-19-000030:note_history:35]
Judgment is also required to determine the standalone selling price (SSP) for each distinct performance obligation. The Company sells post-contract customer support (PCS), subscriptions and professional services on a standalone basis and can therefore use a population of historical standalone sales to determine fair value. For distinct performance obligations that the Company does not generally sell on a standalone basis (hardware and perpetual software), a combination of the adjusted market assessment approach and the expected cost plus a margin approach are used to estimate the SSP.

- removed (2020-02-05):
[0001048695-19-000030:note_history:36]
Cash, Cash Equivalents and Restricted Cash

- removed (2020-02-05):
[0001048695-19-000030:note_history:37]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, may exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents.

- removed (2020-02-05):
[0001048695-19-000030:note_history:38]
Amounts included in restricted cash represent those required to be set aside by a contractual agreement. The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements

- removed (2020-02-05):
[0001048695-19-000030:note_history:39]
of cash flows for the periods presented (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:40]
|  |  | June 30, |  | June 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 688,350 |  |  | $ | 599,268 |  |
| Restricted cash included in other assets, net |  | 3,013 |  |  | 1,182 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 691,363 |  |  | $ | 600,450 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:41]
Inventories

- removed (2020-02-05):
[0001048695-19-000030:note_history:42]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

- removed (2020-02-05):
[0001048695-19-000030:note_history:43]
Goodwill and Acquired Intangible Assets

- removed (2020-02-05):
[0001048695-19-000030:note_history:44]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill has been recorded in connection with various acquisitions, including the acquisition on Nginx in the third quarter of fiscal 2019. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- removed (2020-02-05):
[0001048695-19-000030:note_history:45]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

- removed (2020-02-05):
[0001048695-19-000030:note_history:46]
For its annual impairment test performed in the second quarter of fiscal 2019, the Company completed a quantitative assessment and determined that there was no impairment of goodwill.

- removed (2020-02-05):
[0001048695-19-000030:note_history:47]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2019 and noted no indicators of impairment.

- removed (2020-02-05):
[0001048695-19-000030:note_history:48]
Software Development Costs

- removed (2020-02-05):
[0001048695-19-000030:note_history:49]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result all software development costs have been expensed as research and development activities as incurred.

- removed (2020-02-05):
[0001048695-19-000030:note_history:50]
Internal Use Software

- removed (2020-02-05):
[0001048695-19-000030:note_history:51]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

- removed (2020-02-05):
[0001048695-19-000030:note_history:52]
Stock-Based Compensation

- removed (2020-02-05):
[0001048695-19-000030:note_history:53]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.0 million and $38.7 million of stock-based compensation expense for the three months ended June 30, 2019 and 2018, respectively and $119.2 million and $121.0 million of stock-based compensation expense for the nine months ended June 30, 2019 and 2018, respectively. As of June 30, 2019, there was $176.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- removed (2020-02-05):
[0001048695-19-000030:note_history:54]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 31, 2018, the Company’s Board of Directors and Compensation Committee approved 774,313 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

- removed (2020-02-05):
[0001048695-19-000030:note_history:55]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model. Compensation expense related to the shares issued pursuant to the ESPP is recognized on a straight-line basis over the offering period.

- removed (2020-02-05):
[0001048695-19-000030:note_history:56]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program.  Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified performance goals.

- removed (2020-02-05):
[0001048695-19-000030:note_history:57]
For performance stock awards granted prior to fiscal 2018, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals.  At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%.  Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold.  Each goal is also capped at achievement of 200% above target.

- removed (2020-02-05):
[0001048695-19-000030:note_history:58]
For the fiscal 2018 and 2019 performance stock awards, the Company's Compensation Committee adopted a new set of metrics that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least a 18% increase in annual software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

- removed (2020-02-05):
[0001048695-19-000030:note_history:59]
As of June 30, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:

- removed (2020-02-05):
[0001048695-19-000030:note_history:60]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2018 | 144,066 | Quarterly, Annually1 | 3 years | November 1, 2021 |
| November 1, 2017 | 140,135 | Quarterly, Annually1 | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |

- removed (2020-02-05):
[0001048695-19-000030:note_history:61]
| (1) | 50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:62]
The Company recognizes compensation costs for awards with performance conditions when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

- removed (2020-02-05):
[0001048695-19-000030:note_history:63]
Common Stock Repurchase

- removed (2020-02-05):
[0001048695-19-000030:note_history:64]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the nine months ended June 30, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at June 30, 2019.

- removed (2020-02-05):
[0001048695-19-000030:note_history:65]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of Nginx, it was suspending the automatic component of its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to repurchase shares and when and whether to re-implement an automatic component of its repurchase program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

- removed (2020-02-05):
[0001048695-19-000030:note_history:66]
Earnings Per Share

- removed (2020-02-05):
[0001048695-19-000030:note_history:67]
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock awards and restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

- removed (2020-02-05):
[0001048695-19-000030:note_history:68]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

- removed (2020-02-05):
[0001048695-19-000030:note_history:69]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,905 |  |  | $ | 122,743 |  |  | $ | 332,897 |  |  | $ | 320,808 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,981 |  |  | 60,970 |  |  | 59,963 |  |  | 61,531 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 215 |  |  | 663 |  |  | 409 |  |  | 683 |  |
| Weighted average shares outstanding — diluted |  | 60,196 |  |  | 61,633 |  |  | 60,372 |  |  | 62,214 |  |
| Basic net income per share |  | $ | 1.43 |  |  | $ | 2.01 |  |  | $ | 5.55 |  |  | $ | 5.21 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.99 |  |  | $ | 5.51 |  |  | $ | 5.16 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:70]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and nine months ended June 30, 2019 and 2018.

- removed (2020-02-05):
[0001048695-19-000030:note_history:71]
Comprehensive Income

- removed (2020-02-05):
[0001048695-19-000030:note_history:72]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments are included in accumulated other comprehensive income or loss.

- removed (2020-02-05):
[0001048695-19-000030:note_history:73]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The Company adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. See Note 2 - Revenue from Contracts with Customers for further details.

- removed (2020-02-05):
[0001048695-19-000030:note_history:74]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

- removed (2020-02-05):
[0001048695-19-000030:note_history:75]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which requires a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The Company adopted this new accounting standard on October 1, 2018, which resulted in an immaterial reclassification of beginning and ending cash, cash equivalents and restricted cash for the periods presented within the statement of cash flows. Upon adoption of this new standard, restricted cash activity is no longer separately presented within the investing activities in the statement of cash flows. The overall adoption of the standard did not have a material impact to the consolidated financial statements.

- removed (2020-02-05):
[0001048695-19-000030:note_history:76]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

- removed (2020-02-05):
[0001048695-19-000030:note_history:77]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

- removed (2020-02-05):
[0001048695-19-000030:note_history:78]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on its consolidated balance sheets upon adoption.

- removed (2020-02-05):
[0001048695-19-000030:note_history:79]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which the Company is planning to adopt in the first quarter of fiscal year 2020. The Company plans to adopt the transitional provisions allowed under ASU 2018-11.

- removed (2020-02-05):
[0001048695-19-000030:note_history:80]
The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-02-05):
[0001048695-20-000012:note_history:81]
Short-term investments consist of the following (in thousands):

- added (2020-02-05):
[0001048695-20-000012:note_history:82]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 991 |  |  | $ | — |  |  | $ | — |  |  | $ | 991 |  |
| Corporate bonds and notes |  | 264,006 |  |  | 463 |  |  | (44 | ) |  | 264,425 |  |
| Municipal bonds and notes |  | 9,188 |  |  | 5 |  |  | (3 | ) |  | 9,190 |  |
| U.S. government securities |  | 131,784 |  |  | 42 |  |  | (18 | ) |  | 131,808 |  |
| U.S. government agency securities |  | 20,335 |  |  | 12 |  |  | — |  |  | 20,347 |  |
|  |  | $ | 426,304 |  |  | $ | 522 |  |  | $ | (65 | ) |  | $ | 426,761 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:83]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:84]
Long-term investments consist of the following (in thousands):

- added (2020-02-05):
[0001048695-20-000012:note_history:85]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 274,383 |  |  | $ | 267 |  |  | $ | (173 | ) |  | $ | 274,477 |  |
| U.S. government securities |  | 7,558 |  |  | 5 |  |  | (4 | ) |  | 7,559 |  |
| U.S. government agency securities |  | 30,035 |  |  | — |  |  | (27 | ) |  | 30,008 |  |
|  |  | $ | 311,976 |  |  | $ | 272 |  |  | $ | (204 | ) |  | $ | 312,044 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:86]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001048695-20-000012:note_history:87]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 991 |  |  | $ | — |  |  | $ | — |  |  | $ | 991 |  |
| Corporate bonds and notes |  | 264,006 |  |  | 463 |  |  | (44 | ) |  | 264,425 |  |
| Municipal bonds and notes |  | 9,188 |  |  | 5 |  |  | (3 | ) |  | 9,190 |  |
| U.S. government securities |  | 131,784 |  |  | 42 |  |  | (18 | ) |  | 131,808 |  |
| U.S. government agency securities |  | 20,335 |  |  | 12 |  |  | — |  |  | 20,347 |  |
|  |  | $ | 426,304 |  |  | $ | 522 |  |  | $ | (65 | ) |  | $ | 426,761 |  |
  (was, 2019-08-02, similarity 0.876):
[0001048695-19-000030:note_history:87]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,970 |  |
| Corporate bonds and notes |  | 394,684 |  |  | 9 |  |  | (943 | ) |  | 393,750 |  |
| Municipal bonds and notes |  | 22,588 |  |  | 1 |  |  | (65 | ) |  | 22,524 |  |
| U.S. government securities |  | 120,283 |  |  | — |  |  | (205 | ) |  | 120,078 |  |
| U.S. government agency securities |  | 75,587 |  |  | — |  |  | (204 | ) |  | 75,383 |  |
|  |  | $ | 616,112 |  |  | $ | 10 |  |  | $ | (1,417 | ) |  | $ | 614,705 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:88]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

- changed (2020-02-05):
[0001048695-20-000012:note_history:89]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 274,383 |  |  | $ | 267 |  |  | $ | (173 | ) |  | $ | 274,477 |  |
| U.S. government securities |  | 7,558 |  |  | 5 |  |  | (4 | ) |  | 7,559 |  |
| U.S. government agency securities |  | 30,035 |  |  | — |  |  | (27 | ) |  | 30,008 |  |
|  |  | $ | 311,976 |  |  | $ | 272 |  |  | $ | (204 | ) |  | $ | 312,044 |  |
  (was, 2019-08-02, similarity 0.9111):
[0001048695-19-000030:note_history:89]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 370,377 |  |  | $ | 25 |  |  | $ | (2,692 | ) |  | $ | 367,710 |  |
| Municipal bonds and notes |  | 24,468 |  |  | — |  |  | (182 | ) |  | 24,286 |  |
| U.S. government securities |  | 12,956 |  |  | — |  |  | (185 | ) |  | 12,771 |  |
| U.S. government agency securities |  | 6,500 |  |  | — |  |  | (83 | ) |  | 6,417 |  |
|  |  | $ | 414,301 |  |  | $ | 25 |  |  | $ | (3,142 | ) |  | $ | 411,184 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:90]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:91]
Interest income from investments was $5.6 million and $7.0 million for the three months ended December 31, 2019 and 2018, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2020-02-05):
[0001048695-20-000012:note_history:92]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2019 (in thousands):
  (was, 2019-08-02, similarity 0.9753):
[0001048695-19-000030:note_history:92]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2019 (in thousands):

- changed (2020-02-05):
[0001048695-20-000012:note_history:93]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 171,910 |  |  | $ | (180 | ) |  | $ | 62,543 |  |  | $ | (37 | ) |  | $ | 234,453 |  |  | $ | (217 | ) |
| Municipal bonds and notes |  | 1,421 |  |  | — |  |  | 2,530 |  |  | (3 | ) |  | 3,951 |  |  | (3 | ) |
| U.S. government securities |  | 79,687 |  |  | (22 | ) |  | — |  |  | — |  |  | 79,687 |  |  | (22 | ) |
| U.S. government agency securities |  | 31,119 |  |  | (27 | ) |  | — |  |  | — |  |  | 31,119 |  |  | (27 | ) |
| Total |  | $ | 284,137 |  |  | $ | (229 | ) |  | $ | 65,073 |  |  | $ | (40 | ) |  | $ | 349,210 |  |  | $ | (269 | ) |
  (was, 2019-08-02, similarity 0.7829):
[0001048695-19-000030:note_history:93]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 543,729 |  |  | $ | (1,800 | ) |  | $ | 152,097 |  |  | $ | (1,835 | ) |  | $ | 695,826 |  |  | $ | (3,635 | ) |
| Municipal bonds and notes |  | 26,846 |  |  | (123 | ) |  | 14,363 |  |  | (124 | ) |  | 41,209 |  |  | (247 | ) |
| U.S. government securities |  | 103,470 |  |  | (281 | ) |  | 29,379 |  |  | (109 | ) |  | 132,849 |  |  | (390 | ) |
| U.S. government agency securities |  | 44,812 |  |  | (110 | ) |  | 36,987 |  |  | (177 | ) |  | 81,799 |  |  | (287 | ) |
| Total |  | $ | 718,857 |  |  | $ | (2,314 | ) |  | $ | 232,826 |  |  | $ | (2,245 | ) |  | $ | 951,683 |  |  | $ | (4,559 | ) |

- added (2020-02-05):
[0001048695-20-000012:note_history:94]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434 | ) |  | $ | 109,613 |  |  | $ | (104 | ) |  | $ | 347,360 |  |  | $ | (538 | ) |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11 | ) |  | 8,664 |  |  | (11 | ) |
| U.S. government securities |  | 27,095 |  |  | (12 | ) |  | 9,991 |  |  | (5 | ) |  | 37,086 |  |  | (17 | ) |
| U.S. government agency securities |  | 30,946 |  |  | (22 | ) |  | — |  |  | — |  |  | 30,946 |  |  | (22 | ) |
| Total |  | $ | 296,652 |  |  | $ | (468 | ) |  | $ | 127,404 |  |  | $ | (120 | ) |  | $ | 424,056 |  |  | $ | (588 | ) |

- changed (2020-02-05):
[0001048695-20-000012:note_history:95]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2019-08-02, similarity 0.971):
[0001048695-19-000030:note_history:95]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2020-02-05):
[0001048695-19-000030:note_history:96]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 734 |  |  | $ | — |  |  | $ | — |  |  | $ | 734 |  |
| Corporate bonds and notes |  | 256,471 |  |  | 238 |  |  | (287 | ) |  | 256,422 |  |
| Municipal bonds and notes |  | 13,066 |  |  | 3 |  |  | (15 | ) |  | 13,054 |  |
| U.S. government securities |  | 25,942 |  |  | 10 |  |  | (23 | ) |  | 25,929 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (2 | ) |  | 1,998 |  |
|  |  | $ | 298,213 |  |  | $ | 251 |  |  | $ | (327 | ) |  | $ | 298,137 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:97]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 154,893 |  |  | $ | 590 |  |  | $ | (135 | ) |  | $ | 155,348 |  |
| Municipal bonds and notes |  | 3,776 |  |  | 8 |  |  | (8 | ) |  | 3,776 |  |
| U.S. government agency securities |  | 2,500 |  |  | — |  |  | (5 | ) |  | 2,495 |  |
|  |  | $ | 161,169 |  |  | $ | 598 |  |  | $ | (148 | ) |  | $ | 161,619 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:98]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 66,064 |  |  | $ | (70 | ) |  | $ | 165,970 |  |  | $ | (352 | ) |  | $ | 232,034 |  |  | $ | (422 | ) |
| Municipal bonds and notes |  | 1,105 |  |  | — |  |  | 10,786 |  |  | (23 | ) |  | 11,891 |  |  | (23 | ) |
| U.S. government securities |  | — |  |  | — |  |  | 12,964 |  |  | (23 | ) |  | 12,964 |  |  | (23 | ) |
| U.S. government agency securities |  | — |  |  | — |  |  | 4,492 |  |  | (7 | ) |  | 4,492 |  |  | (7 | ) |
| Total |  | $ | 67,169 |  |  | $ | (70 | ) |  | $ | 194,212 |  |  | $ | (405 | ) |  | $ | 261,381 |  |  | $ | (475 | ) |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2020-02-05):
[0001048695-19-000030:note_history:99]
Revenue Recognition

- removed (2020-02-05):
[0001048695-19-000030:note_history:100]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

- removed (2020-02-05):
[0001048695-19-000030:note_history:101]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

- removed (2020-02-05):
[0001048695-19-000030:note_history:102]
| • | Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:103]
| • | Identify the performance obligations in the contract. Performance obligations are explicitly identified in the Company's contracts and include hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:104]
| • | Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:105]
| • | Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:106]
| • | Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:107]
The following is a description of the principal activities from which the Company generates revenue:

- removed (2020-02-05):
[0001048695-19-000030:note_history:108]
Product

- removed (2020-02-05):
[0001048695-19-000030:note_history:109]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been delivered and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

- removed (2020-02-05):
[0001048695-19-000030:note_history:110]
Subscription

- removed (2020-02-05):
[0001048695-19-000030:note_history:111]
The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based Silverline platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service Silverline offerings, revenue is recognized ratably as the services are provided.

- removed (2020-02-05):
[0001048695-19-000030:note_history:112]
Support and professional services

- removed (2020-02-05):
[0001048695-19-000030:note_history:113]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

- removed (2020-02-05):
[0001048695-19-000030:note_history:114]
Contract acquisition costs

- removed (2020-02-05):
[0001048695-19-000030:note_history:115]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

- removed (2020-02-05):
[0001048695-19-000030:note_history:116]
Significant Judgments

- removed (2020-02-05):
[0001048695-19-000030:note_history:117]
The Company’s contracts with customers often include promises to transfer multiple products and services. Determining whether products and services are considered distinct performance obligations that should be accounted for separately versus together may require significant judgment.

- removed (2020-02-05):
[0001048695-19-000030:note_history:118]
Judgment is also required to determine the standalone selling price (SSP) for each distinct performance obligation. The Company sells post-contract customer support (PCS), subscriptions and professional services on a standalone basis and can therefore use a population of historical standalone sales to determine fair value. For distinct performance obligations that the Company does not generally sell on a standalone basis (hardware and perpetual software), a combination of the adjusted market assessment approach and the expected cost plus a margin approach are used to estimate the SSP.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001048695-20-000012:note_history:119]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs
  (was, 2019-08-02, similarity 0.6667):
[0001048695-19-000030:note_history:119]
Capitalized Contract Acquisition Costs

- changed (2020-02-05):
[0001048695-20-000012:note_history:120]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2019 (in thousands):
  (was, 2019-08-02, similarity 0.948):
[0001048695-19-000030:note_history:120]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

- changed (2020-02-05):
[0001048695-20-000012:note_history:121]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,705 | ) |
| Balance, December 31, 2019 |  | $ | 58,153 |  |
  (was, 2019-08-02, similarity 0.8042):
[0001048695-19-000030:note_history:121]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 22,460 |  |
| Amortization of capitalized contract acquisition costs | $ | (21,380 | ) |
| Balance, June 30, 2019 | $ | 55,688 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:122]
Amortization of capitalized contract acquisition costs was $8.7 million and $7.3 million for the three months ended December 31, 2019 and 2018, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- added (2020-02-05):
[0001048695-20-000012:note_history:123]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to our contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- changed (2020-02-05):
[0001048695-20-000012:note_history:124]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2019 (in thousands):
  (was, 2019-08-02, similarity 0.9395):
[0001048695-19-000030:note_history:124]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

- changed (2020-02-05):
[0001048695-20-000012:note_history:125]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 3,407 |  |
| Contract asset net additions |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (13,584 | ) |
| Balance, December 31, 2019 |  | $ | 135,245 |  |
  (was, 2019-08-02, similarity 0.6753):
[0001048695-19-000030:note_history:125]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 15,240 |  |
| Contract asset net additions | $ | 50,159 |  |
| Contract assets reclassified to accounts receivable | $ | (29,386 | ) |
| Balance, June 30, 2019 | $ | 93,512 |  |

- changed (2020-02-05):
[0001048695-20-000012:note_history:126]
As of December 31, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2019 and 2018.
  (was, 2019-08-02, similarity 0.8886):
[0001048695-19-000030:note_history:126]
As of June 30, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2019.

- added (2020-02-05):
[0001048695-20-000012:note_history:127]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

- changed (2020-02-05):
[0001048695-20-000012:note_history:128]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (306,275 | ) |
| Balance, December 31, 2019 |  | $ | 1,237,973 |  |
  (was, 2019-08-02, similarity 0.8067):
[0001048695-19-000030:note_history:128]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 731,306 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (648,193 | ) |
| Balance, June 30, 2019 | $ | 1,166,512 |  |

- added (2020-02-05):
[0001048695-20-000012:note_history:129]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2019, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.2 billion and the Company expects to recognize revenues on approximately 68.5% of these remaining performance obligations over the next 12 months, 18.7% in year two, and the remaining balance thereafter.

- changed (2020-02-05):
[0001048695-20-000012:note_history:130]
See Note 11, Segment Information, for disaggregated revenue by significant customer and geographic region.
  (was, 2019-08-02, similarity 0.8052):
[0001048695-19-000030:note_history:130]
See Note 9, Geographic Sales and Significant Customers, for disaggregated revenue by significant customer and geographic region.

- removed (2020-02-05):
[0001048695-19-000030:note_history:131]
Revenue from Contracts with Customers
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of the date of adoption, October 1, 2018. This table does not represent the full consolidated balance sheet as it only reflects the accounts impacted by the adoption of ASC 606.

- removed (2020-02-05):
[0001048695-19-000030:note_history:132]
|  | Ending Balance as of September 30, 2018 (ASC 605) |  | ASC 606 Adjustments |  | Beginning Balance as of October 1, 2018(ASC 606) |
| Assets |  |  |  |  |  |
| Other current assets1 | $ | 52,326 |  |  | $ | 50,558 |  |  | $ | 102,884 |  |
| Other assets, net1 | $ | 42,186 |  |  | $ | 59,676 |  |  | $ | 101,862 |  |
| Deferred tax assets | $ | 33,441 |  |  | $ | (7,902 | ) |  | $ | 25,539 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |
| Deferred revenue | $ | 715,697 |  |  | $ | 35,464 |  |  | $ | 751,161 |  |
| Deferred revenue, long-term | $ | 299,624 |  |  | $ | 32,614 |  |  | $ | 332,238 |  |
| Retained earnings2 | $ | 1,287,243 |  |  | $ | 36,048 |  |  | $ | 1,323,291 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:133]
| (1) | Upon the adoption of ASC 606, capitalized contract acquisition costs and unbilled accounts receivable are reported as part of other current assets and other assets, net. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:134]
| (2) | The net increase to retained earnings of $36.0 million was primarily related to the capitalization of contract acquisition costs of $54.6 million, partially offset by a decrease of $8.8 million due to changes in deferred revenue and a decrease of $7.9 million from the impact on deferred income taxes. |

- removed (2020-02-05):
[0001048695-19-000030:note_history:135]
As a result of an increase in sales of the Company's software solutions sold as Enterprise License Agreements and annual subscriptions, the adoption of ASC 606 had a material impact to the Company's consolidated balance sheet as of June 30, 2019 and consolidated income statements for the three and nine months ended June 30, 2019.

- removed (2020-02-05):
[0001048695-19-000030:note_history:136]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of June 30, 2019 (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:137]
|  | June 30, 2019 |
|  | As Reported(ASC 606) |  | Impacts Subsequent to the Date of Adoption |  | Impacts on the Date of Adoption (October 1, 2018) |  | Without Adoption (ASC 605) |
| Assets |  |  |  |  |  |  |  |
| Other current assets | $ | 161,940 |  |  | $ | 23,480 |  |  | $ | 50,558 |  |  | $ | 87,902 |  |
| Other assets, net | $ | 194,295 |  |  | $ | 11,714 |  |  | $ | 59,676 |  |  | $ | 122,905 |  |
| Deferred tax assets | $ | 25,079 |  |  | $ | (1,961 | ) |  | $ | (7,902 | ) |  | $ | 34,942 |  |
| Total assets | $ | 3,177,275 |  |  | $ | 33,233 |  |  | $ | 102,332 |  |  | $ | 3,041,710 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |
| Accrued liabilities | $ | 213,195 |  |  | $ | 4,916 |  |  | $ | — |  |  | $ | 208,279 |  |
| Deferred revenue | $ | 803,241 |  |  | $ | 11,589 |  |  | $ | 35,464 |  |  | $ | 756,188 |  |
| Deferred revenue, long-term | $ | 363,271 |  |  | $ | (10,472 | ) |  | $ | 32,614 |  |  | $ | 341,129 |  |
| Total liabilities | $ | 1,553,493 |  |  | $ | 6,033 |  |  | $ | 68,078 |  |  | $ | 1,479,382 |  |
| Retained earnings | $ | 1,543,253 |  |  | $ | 25,406 |  |  | $ | 36,048 |  |  | $ | 1,481,799 |  |
| Total liabilities and shareholders' equity | $ | 3,177,275 |  |  | $ | 31,439 |  |  | $ | 104,126 |  |  | $ | 3,041,710 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:138]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the three months ended June 30, 2019 (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:139]
|  | Three Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 563,394 |  |  | $ | 29,338 |  |  | $ | 534,056 |  |
| Total cost of net revenues | $ | 90,767 |  |  | $ | 626 |  |  | $ | 90,141 |  |
| Gross profit | $ | 472,627 |  |  | $ | 28,712 |  |  | $ | 443,915 |  |
| Total operating expenses | $ | 369,887 |  |  | $ | (1,352 | ) |  | $ | 371,239 |  |
| Income before income taxes | $ | 107,462 |  |  | $ | 30,064 |  |  | $ | 77,398 |  |
| Provision for income taxes | $ | 21,557 |  |  | $ | 6,031 |  |  | $ | 15,526 |  |
| Net income | $ | 85,905 |  |  | $ | 24,033 |  |  | $ | 61,872 |  |
| Net income per share — basic | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |
| Net income per share — diluted | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:140]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the nine months ended June 30, 2019 (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:141]
|  | Nine Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 1,652,059 |  |  | $ | 36,528 |  |  | $ | 1,615,531 |  |
| Total cost of net revenues | $ | 265,659 |  |  | $ | 2,440 |  |  | $ | 263,219 |  |
| Gross profit | $ | 1,386,400 |  |  | $ | 34,088 |  |  | $ | 1,352,312 |  |
| Total operating expenses | $ | 982,651 |  |  | $ | 1,805 |  |  | $ | 980,846 |  |
| Income before income taxes | $ | 423,000 |  |  | $ | 32,283 |  |  | $ | 390,717 |  |
| Provision for income taxes | $ | 90,103 |  |  | $ | 6,877 |  |  | $ | 83,226 |  |
| Net income | $ | 332,897 |  |  | $ | 25,406 |  |  | $ | 307,491 |  |
| Net income per share — basic | $ | 5.55 |  |  | $ | 0.42 |  |  | $ | 5.13 |  |
| Net income per share — diluted | $ | 5.51 |  |  | $ | 0.42 |  |  | $ | 5.09 |  |

- removed (2020-02-05):
[0001048695-19-000030:note_history:142]
The adoption of ASC 606 did not have a material impact to cash from or used in operating, financing, or investing activities on the Company’s consolidated statement of cash flows for the nine months ended June 30, 2019.

- removed (2020-02-05):
[0001048695-19-000030:note_history:143]
Amortization of capitalized contract acquisition costs is recorded in Sales and Marketing expense in the accompanying consolidated income statements for the three and nine months ended June 30, 2019. There was no impairment of any capitalized contract acquisition costs.

- removed (2020-02-05):
[0001048695-19-000030:note_history:144]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to our contracts with customers. We record assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- removed (2020-02-05):
[0001048695-19-000030:note_history:145]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:146]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The Company expects to recognize this amount as revenue over the following time periods (in thousands):

- removed (2020-02-05):
[0001048695-19-000030:note_history:147]
|  | 2,019 |  | 2,020 |  | Thereafter |  | Total |
| Revenue expected to be recognized on remaining performance obligations | $ | 278,529 |  |  | $ | 574,901 |  |  | $ | 313,082 |  |  | $ | 1,166,512 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-02-05):
[0001048695-20-000012:note_history:148]
Subsequent Events
Acquisition of Shape Security, Inc.

- added (2020-02-05):
[0001048695-20-000012:note_history:149]
On December 19, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5.

- added (2020-02-05):
[0001048695-20-000012:note_history:150]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement.

- added (2020-02-05):
[0001048695-20-000012:note_history:151]
During the first quarter of 2020, the Company incurred approximately $4.0 million of acquisition and integration related expenses associated with the Shape acquisition, which is included within General and Administrative operating expenses in our Consolidated Income Statements.

- added (2020-02-05):
[0001048695-20-000012:note_history:152]
As a result of limited access to Shape information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill. Also, the Company is unable to provide pro forma revenues and earnings of the combined entity. This information will be included in the Company's Quarterly Report on Form 10-Q for the quarter ended March 31, 2020.

- added (2020-02-05):
[0001048695-20-000012:note_history:153]
Term Credit Agreement

- added (2020-02-05):
[0001048695-20-000012:note_history:154]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement (“Term Credit Agreement”) with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the “Term Loan Facility”). The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023.  Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed. Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company’s leverage ratio. Interest on the outstanding principal of borrowings is currently due monthly in arrears. As of January 24, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%. Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA.

- added (2020-02-05):
[0001048695-20-000012:note_history:155]
The proceeds from the Term Loan Facility were used to (i) finance, in part, the acquisition of Shape and (ii) to pay fees and expenses incurred in connection with the acquisition of Shape and the related transactions. As of February 5, 2020, there was $400.0 million outstanding under the Term Loan Facility.

- added (2020-02-05):
[0001048695-20-000012:note_history:156]
Revolving Credit Agreement
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the “Revolving Credit Agreement”) that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the “Revolving Credit Facility”). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. The Revolving Credit Facility matures on January 31, 2025. The remaining outstanding principal of borrowings under the Revolving Credit Facility is due upon maturity on January 31, 2025. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on our leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on our leverage ratio on the undrawn portion of the Revolving Credit Facility. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of February 5, 2020, there were no outstanding borrowings under the Revolving Credit Facility.
