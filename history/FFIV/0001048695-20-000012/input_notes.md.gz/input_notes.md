# FFIV notes — 0001048695-20-000012


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-20-000012:notes:1]
[same as prior period, unchanged from 0001048695-19-000030:notes:1]

[0001048695-20-000012:notes:2]
F5 Networks, Inc. (the “Company”) is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

[0001048695-20-000012:notes:3]
[same as prior period, unchanged from 0001048695-19-000030:notes:3]

[0001048695-20-000012:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

[0001048695-20-000012:notes:5]
Certain prior year amounts have been reclassified to conform to the current year presentation in the Consolidated Statements of Cash Flows. The reclassified amounts are considered immaterial and there was no change to total cash from operating, investing or financing activities as a result.

[0001048695-20-000012:notes:6]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2019, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 7 - Leases.

[0001048695-20-000012:notes:7]
Recently Adopted Accounting Standards

[0001048695-20-000012:notes:8]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 7 - Leases for further discussion.

[0001048695-20-000012:notes:9]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.

[0001048695-20-000012:notes:10]
The Company includes in minimum lease payments, fixed and variable payments based on a rate or index, but excludes variable payments based on satisfying future benchmarks or actual future costs incurred; such amounts are expensed as incurred. To calculate the net present value, the Company applied an incremental borrowing rate. This incremental borrowing rate is determined using a portfolio approach based on the rate of interest the Company would pay to borrow an amount equal to the lease payments on a collateralized basis over a similar term. Renewal options to extend lease terms are excluded from the minimum lease term at lease commencement.

[0001048695-20-000012:notes:11]
Recently Issued Accounting Pronouncements

[0001048695-20-000012:notes:12]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-20-000012:notes:13]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-20-000012:notes:14]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs

[0001048695-20-000012:notes:15]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

[0001048695-20-000012:notes:16]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,705 | ) |
| Balance, December 31, 2019 |  | $ | 58,153 |  |

[0001048695-20-000012:notes:17]
Amortization of capitalized contract acquisition costs was $8.7 million and $7.3 million for the three months ended December 31, 2019 and 2018, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-20-000012:notes:18]
[same as prior period, unchanged from 0001048695-19-000030:notes:91]

[0001048695-20-000012:notes:19]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to our contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-20-000012:notes:20]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

[0001048695-20-000012:notes:21]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 3,407 |  |
| Contract asset net additions |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (13,584 | ) |
| Balance, December 31, 2019 |  | $ | 135,245 |  |

[0001048695-20-000012:notes:22]
As of December 31, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2019 and 2018.

[0001048695-20-000012:notes:23]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

[0001048695-20-000012:notes:24]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (306,275 | ) |
| Balance, December 31, 2019 |  | $ | 1,237,973 |  |

[0001048695-20-000012:notes:25]
[same as prior period, unchanged from 0001048695-19-000030:notes:98]

[0001048695-20-000012:notes:26]
[same as prior period, unchanged from 0001048695-19-000030:notes:99]

[0001048695-20-000012:notes:27]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2019, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.2 billion and the Company expects to recognize revenues on approximately 68.5% of these remaining performance obligations over the next 12 months, 18.7% in year two, and the remaining balance thereafter.

[0001048695-20-000012:notes:28]
See Note 11, Segment Information, for disaggregated revenue by significant customer and geographic region.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-20-000012:notes:29]
Business Combinations
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-20-000012:notes:30]
On March 9, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Nginx, Inc. ("NGINX"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with NGINX becoming a wholly-owned subsidiary of F5.

[0001048695-20-000012:notes:31]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred an additional $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-20-000012:notes:32]
NGINX is an open source leader in application delivery. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of NGINX. The goodwill related to the NGINX acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of NGINX have been included in the Company’s consolidated financial statements from the date of acquisition.

[0001048695-20-000012:notes:33]
[same as prior period, unchanged from 0001048695-19-000030:notes:109]

[0001048695-20-000012:notes:34]
[same as prior period, unchanged from 0001048695-19-000030:notes:110]

[0001048695-20-000012:notes:35]
[same as prior period, unchanged from 0001048695-19-000030:notes:111]

[0001048695-20-000012:notes:36]
[same as prior period, unchanged from 0001048695-19-000030:notes:112]

[0001048695-20-000012:notes:37]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX merger was 8.1 years. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $450.7 million.

[0001048695-20-000012:notes:38]
Since the NGINX acquisition was completed on May 8, 2019, the F5 and NGINX teams have been rapidly executing a plan to integrate ongoing operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-20-000012:notes:39]
[same as prior period, unchanged from 0001048695-19-000030:notes:117]

[0001048695-20-000012:notes:40]
[same as prior period, unchanged from 0001048695-19-000030:notes:118]

[0001048695-20-000012:notes:41]
[same as prior period, unchanged from 0001048695-19-000030:notes:119]

[0001048695-20-000012:notes:42]
[same as prior period, unchanged from 0001048695-19-000030:notes:120]

[0001048695-20-000012:notes:43]
[same as prior period, unchanged from 0001048695-19-000030:notes:121]

[0001048695-20-000012:notes:44]
[same as prior period, unchanged from 0001048695-19-000030:notes:122]

[0001048695-20-000012:notes:45]
[same as prior period, unchanged from 0001048695-19-000030:notes:123]

[0001048695-20-000012:notes:46]
[same as prior period, unchanged from 0001048695-19-000030:notes:124]

[0001048695-20-000012:notes:47]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2019, were as follows (in thousands):

[0001048695-20-000012:notes:48]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2019 |
| Cash equivalents |  | $ | 249,178 |  |  | $ | 42,387 |  |  | $ | — |  |  | $ | 291,565 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 991 |  |  | — |  |  | 991 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 264,425 |  |  | — |  |  | 264,425 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 9,190 |  |  | — |  |  | 9,190 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 131,808 |  |  | — |  |  | 131,808 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 20,347 |  |  | — |  |  | 20,347 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 274,477 |  |  | — |  |  | 274,477 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,559 |  |  | — |  |  | 7,559 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 30,008 |  |  | — |  |  | 30,008 |  |
| Total |  | $ | 249,178 |  |  | $ | 781,192 |  |  | $ | — |  |  | $ | 1,030,370 |  |

[0001048695-20-000012:notes:49]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2019, were as follows (in thousands):

[0001048695-20-000012:notes:50]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2019 |
| Cash equivalents |  | $ | 140,238 |  |  | $ | 153,404 |  |  | $ | — |  |  | $ | 293,642 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 249 |  |  | — |  |  | 249 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 259,547 |  |  | — |  |  | 259,547 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 12,129 |  |  | — |  |  | 12,129 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 78,992 |  |  | — |  |  | 78,992 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 22,146 |  |  | — |  |  | 22,146 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 298,916 |  |  | — |  |  | 298,916 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,524 |  |  | — |  |  | 2,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,515 |  |  | — |  |  | 5,515 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 51,447 |  |  | — |  |  | 51,447 |  |
| Total |  | $ | 140,238 |  |  | $ | 884,869 |  |  | $ | — |  |  | $ | 1,025,107 |  |

[0001048695-20-000012:notes:51]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-20-000012:notes:52]
The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended December 31, 2019 and 2018, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-20-000012:notes:53]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-20-000012:notes:54]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 991 |  |  | $ | — |  |  | $ | — |  |  | $ | 991 |  |
| Corporate bonds and notes |  | 264,006 |  |  | 463 |  |  | (44 | ) |  | 264,425 |  |
| Municipal bonds and notes |  | 9,188 |  |  | 5 |  |  | (3 | ) |  | 9,190 |  |
| U.S. government securities |  | 131,784 |  |  | 42 |  |  | (18 | ) |  | 131,808 |  |
| U.S. government agency securities |  | 20,335 |  |  | 12 |  |  | — |  |  | 20,347 |  |
|  |  | $ | 426,304 |  |  | $ | 522 |  |  | $ | (65 | ) |  | $ | 426,761 |  |

[0001048695-20-000012:notes:55]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

[0001048695-20-000012:notes:56]
Long-term investments consist of the following (in thousands):

[0001048695-20-000012:notes:57]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 274,383 |  |  | $ | 267 |  |  | $ | (173 | ) |  | $ | 274,477 |  |
| U.S. government securities |  | 7,558 |  |  | 5 |  |  | (4 | ) |  | 7,559 |  |
| U.S. government agency securities |  | 30,035 |  |  | — |  |  | (27 | ) |  | 30,008 |  |
|  |  | $ | 311,976 |  |  | $ | 272 |  |  | $ | (204 | ) |  | $ | 312,044 |  |

[0001048695-20-000012:notes:58]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

[0001048695-20-000012:notes:59]
Interest income from investments was $5.6 million and $7.0 million for the three months ended December 31, 2019 and 2018, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-20-000012:notes:60]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2019 (in thousands):

[0001048695-20-000012:notes:61]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 171,910 |  |  | $ | (180 | ) |  | $ | 62,543 |  |  | $ | (37 | ) |  | $ | 234,453 |  |  | $ | (217 | ) |
| Municipal bonds and notes |  | 1,421 |  |  | — |  |  | 2,530 |  |  | (3 | ) |  | 3,951 |  |  | (3 | ) |
| U.S. government securities |  | 79,687 |  |  | (22 | ) |  | — |  |  | — |  |  | 79,687 |  |  | (22 | ) |
| U.S. government agency securities |  | 31,119 |  |  | (27 | ) |  | — |  |  | — |  |  | 31,119 |  |  | (27 | ) |
| Total |  | $ | 284,137 |  |  | $ | (229 | ) |  | $ | 65,073 |  |  | $ | (40 | ) |  | $ | 349,210 |  |  | $ | (269 | ) |

[0001048695-20-000012:notes:62]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2019 (in thousands):

[0001048695-20-000012:notes:63]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434 | ) |  | $ | 109,613 |  |  | $ | (104 | ) |  | $ | 347,360 |  |  | $ | (538 | ) |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11 | ) |  | 8,664 |  |  | (11 | ) |
| U.S. government securities |  | 27,095 |  |  | (12 | ) |  | 9,991 |  |  | (5 | ) |  | 37,086 |  |  | (17 | ) |
| U.S. government agency securities |  | 30,946 |  |  | (22 | ) |  | — |  |  | — |  |  | 30,946 |  |  | (22 | ) |
| Total |  | $ | 296,652 |  |  | $ | (468 | ) |  | $ | 127,404 |  |  | $ | (120 | ) |  | $ | 424,056 |  |  | $ | (588 | ) |

[0001048695-20-000012:notes:64]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-20-000012:notes:65]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-20-000012:notes:66]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-20-000012:notes:67]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Cash and cash equivalents |  | $ | 735,457 |  |  | $ | 599,219 |  |
| Restricted cash included in other assets, net |  | 3,188 |  |  | 3,035 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 738,645 |  |  | $ | 602,254 |  |

[0001048695-20-000012:notes:68]
Inventories

[0001048695-20-000012:notes:69]
Inventories consist of the following (in thousands):

[0001048695-20-000012:notes:70]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Finished goods |  | $ | 21,463 |  |  | $ | 22,441 |  |
| Raw materials |  | 10,918 |  |  | 11,960 |  |
|  |  | $ | 32,381 |  |  | $ | 34,401 |  |

[0001048695-20-000012:notes:71]
Other Current Assets

[0001048695-20-000012:notes:72]
[same as prior period, unchanged from 0001048695-19-000030:notes:144]

[0001048695-20-000012:notes:73]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Contract assets |  | $ | 85,118 |  |  | $ | 79,407 |  |
| Prepaid expenses |  | 55,170 |  |  | 49,051 |  |
| Capitalized contract acquisition costs |  | 27,752 |  |  | 28,228 |  |
| Other |  | 20,164 |  |  | 26,188 |  |
|  |  | $ | 188,204 |  |  | $ | 182,874 |  |

[0001048695-20-000012:notes:74]
Other Assets

[0001048695-20-000012:notes:75]
[same as prior period, unchanged from 0001048695-19-000030:notes:146]

[0001048695-20-000012:notes:76]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Intangible assets |  | $ | 104,315 |  |  | $ | 108,903 |  |
| Contract assets |  | 50,128 |  |  | 53,085 |  |
| Capitalized contract acquisition costs |  | 30,401 |  |  | 31,218 |  |
| Other |  | 13,007 |  |  | 10,575 |  |
|  |  | $ | 197,851 |  |  | $ | 203,781 |  |

[0001048695-20-000012:notes:77]
Accrued Liabilities

[0001048695-20-000012:notes:78]
Accrued liabilities consist of the following (in thousands):

[0001048695-20-000012:notes:79]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Payroll and benefits |  | $ | 110,446 |  |  | $ | 138,453 |  |
| Operating lease liabilities, current |  | 42,519 |  |  | — |  |
| Income and other tax accruals |  | 39,503 |  |  | 31,801 |  |
| Other |  | 57,882 |  |  | 65,615 |  |
|  |  | $ | 250,350 |  |  | $ | 235,869 |  |

[0001048695-20-000012:notes:80]
Other Long-term Liabilities

[0001048695-20-000012:notes:81]
Other long-term liabilities consist of the following (in thousands):

[0001048695-20-000012:notes:82]
|  |  | December 31, 2019 |  | September 30, 2019 |
| Income taxes payable |  | $ | 44,520 |  |  | $ | 42,324 |  |
| Deferred rent |  | — |  |  | 66,103 |  |
| Other |  | 18,091 |  |  | 23,426 |  |
|  |  | $ | 62,611 |  |  | $ | 131,853 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-20-000012:notes:83]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the “Leasing Standard”) using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively.

[0001048695-20-000012:notes:84]
The majority of the Company’s operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company has not yet determined whether the renewal option is likely to be exercised. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-20-000012:notes:85]
The components of the Company's operating lease expenses for the three months ended December 31, 2019 were as follows (in thousands):

[0001048695-20-000012:notes:86]
|  |  | Three months endedDecember 31, 2019 |
| Operating lease expense |  | $ | 11,318 |  |
| Short-term lease expense |  | 814 |  |
| Variable lease expense |  | 5,839 |  |
| Total lease expense |  | $ | 17,971 |  |

[0001048695-20-000012:notes:87]
Variable lease expense primarily consists of common area maintenance and parking expenses. The Company executed two sublease contracts that commenced during the first quarter of fiscal year 2020. Lease income payments are not due until the second fiscal quarter.

[0001048695-20-000012:notes:88]
Supplemental balance sheet information related to the Company's operating leases was as follows (in thousands, except lease term and discount rate):

[0001048695-20-000012:notes:89]
|  |  | December 31, 2019 |
| Operating lease right-of-use assets, net |  | $ | 303,435 |  |
| Operating lease liabilities, current1 |  | 42,519 |  |
| Operating lease liabilities, long-term |  | 342,303 |  |
| Total operating lease liabilities |  | $ | 384,822 |  |
| Weighted average remaining lease term (in years) |  | 11.1 |  |
| Weighted average discount rate |  | 2.65 | % |

[0001048695-20-000012:notes:90]
| (1) | Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheet. |

[0001048695-20-000012:notes:91]
Maturities of lease liabilities as of December 31, 2019 were as follows (in thousands):

[0001048695-20-000012:notes:92]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2020 (remainder) |  | $ | 39,193 |  |
| 2021 |  | 51,202 |  |
| 2022 |  | 48,737 |  |
| 2023 |  | 36,259 |  |
| 2024 |  | 32,938 |  |
| 2025 |  | 28,436 |  |
| Thereafter |  | 215,966 |  |
| Total lease payments |  | 452,731 |  |
| Less: imputed interest |  | (67,909 | ) |
| Total lease liabilities |  | $ | 384,822 |  |

[0001048695-20-000012:notes:93]
Operating lease liabilities above do not include sublease income. As of December 31, 2019, the Company expects to receive sublease income of approximately $5.6 million, which consists of $1.2 million to be received for the remainder of fiscal 2020 and $4.4 million to be received over the three fiscal years thereafter.

[0001048695-20-000012:notes:94]
As of December 31, 2019, the Company had no significant operating leases that were executed but not yet commenced.

[0001048695-20-000012:notes:95]
ASC 840 - Leases

[0001048695-20-000012:notes:96]
As a result of adopting the Leasing Standard, reporting periods beginning in the first quarter of fiscal 2020 are presented under the new standard while prior period amounts are not adjusted and continue to be reported in accordance with ASC 840 - Leases.

[0001048695-20-000012:notes:97]
Prior to the adoption of the Leasing Standard, future minimum operating lease payments, net of sublease income, were as follows as of September 30, 2019 (in thousands):

[0001048695-20-000012:notes:98]
| Fiscal Year |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2020 |  | $ | 54,046 |  |  | $ | 683 |  |  | $ | 53,363 |  |
| 2021 |  | 50,712 |  |  | 1,051 |  |  | 49,661 |  |
| 2022 |  | 47,550 |  |  | 1,082 |  |  | 46,468 |  |
| 2023 |  | 36,514 |  |  | 368 |  |  | 36,146 |  |
| 2024 |  | 33,971 |  |  | — |  |  | 33,971 |  |
| Thereafter |  | 242,826 |  |  | — |  |  | 242,826 |  |
|  |  | $ | 465,619 |  |  | $ | 3,184 |  |  | $ | 462,435 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-20-000012:notes:99]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-20-000012:notes:100]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-20-000012:notes:101]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2019 and September 30, 2019 were not material.

[0001048695-20-000012:notes:102]
Commitments

[0001048695-20-000012:notes:103]
As of December 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000012:notes:104]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000012:notes:105]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-20-000012:notes:106]
Income Taxes
Our tax provision for interim periods is determined using an estimated annual effective tax rate, adjusted for discrete items in the related period.

[0001048695-20-000012:notes:107]
The effective tax rate was 22.8% and 20.8% for the three months ended December 31, 2019 and 2018, respectively. The increase in the effective tax rate for the three months ended December 31, 2019 as compared to the three months ended December 31, 2018 is primarily due to the tax impact from stock-based compensation.

[0001048695-20-000012:notes:108]
At December 31, 2019, the Company had $44.1 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-20-000012:notes:109]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2018 for the United Kingdom, 2014 for Japan, 2015 for Singapore, 2015 for Australia, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2014 through 2017 and by Israel for fiscal years 2013 to 2017. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2016 federal income tax return, fiscal years 2015 and 2016 state income tax returns, and fiscal years 2013 to 2018 foreign income tax returns.


## us-gaap:EarningsPerShareTextBlock

[0001048695-20-000012:notes:110]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-20-000012:notes:111]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-20-000012:notes:112]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |
| Net income |  | $ | 98,527 |  |  | $ | 130,905 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,649 |  |  | 60,216 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 166 |  |  | 429 |  |
| Weighted average shares outstanding — diluted |  | 60,815 |  |  | 60,645 |  |
| Basic net income per share |  | $ | 1.62 |  |  | $ | 2.17 |  |
| Diluted net income per share |  | $ | 1.62 |  |  | $ | 2.16 |  |

[0001048695-20-000012:notes:113]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three months ended December 31, 2019 and 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-20-000012:notes:114]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-20-000012:notes:115]
Revenues by Geographic Location and Other Information

[0001048695-20-000012:notes:116]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company’s chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location

[0001048695-20-000012:notes:117]
based on the location of the customer.

[0001048695-20-000012:notes:118]
[same as prior period, unchanged from 0001048695-19-000030:notes:164]

[0001048695-20-000012:notes:119]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |
| United States |  | $ | 275,499 |  |  | $ | 264,751 |  |
| Other |  | 26,063 |  |  | 26,893 |  |
| Total Americas |  | 301,562 |  |  | 291,644 |  |
| EMEA |  | 155,952 |  |  | 148,984 |  |
| Asia Pacific |  | 111,791 |  |  | 103,142 |  |
|  |  | $ | 569,305 |  |  | $ | 543,770 |  |

[0001048695-20-000012:notes:120]
[same as prior period, unchanged from 0001048695-19-000030:notes:167]

[0001048695-20-000012:notes:121]
|  |  | Three months endedDecember 31, |
|  |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 16.5 | % |  | 16.8 | % |
| Westcon Group, Inc. |  | 11.0 | % |  | 11.3 | % |
| Arrow ECS |  | 10.1 | % |  | 10.9 | % |

[0001048695-20-000012:notes:122]
[same as prior period, unchanged from 0001048695-19-000030:notes:170]

[0001048695-20-000012:notes:123]
|  |  | December 31, 2019 |  | September 30, 2019 |
| United States |  | $ | 198,595 |  |  | $ | 194,176 |  |
| EMEA |  | 14,678 |  |  | 13,451 |  |
| Other countries |  | 16,527 |  |  | 15,799 |  |
|  |  | $ | 229,800 |  |  | $ | 223,426 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-20-000012:notes:124]
Restructuring Charges
In December 2019, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 75 employees. The Company recorded a restructuring charge of $7.8 million in the first quarter of fiscal 2020. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-20-000012:notes:125]
During the quarter ended December 31, 2019, the following activity was recorded (in thousands):

[0001048695-20-000012:notes:126]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (5,282 | ) |
| Non-cash items |  | — |  |
| Accrued expenses, December 31, 2019 |  | $ | 2,518 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-20-000012:notes:127]
Subsequent Events
Acquisition of Shape Security, Inc.

[0001048695-20-000012:notes:128]
On December 19, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5.

[0001048695-20-000012:notes:129]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement.

[0001048695-20-000012:notes:130]
During the first quarter of 2020, the Company incurred approximately $4.0 million of acquisition and integration related expenses associated with the Shape acquisition, which is included within General and Administrative operating expenses in our Consolidated Income Statements.

[0001048695-20-000012:notes:131]
As a result of limited access to Shape information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill. Also, the Company is unable to provide pro forma revenues and earnings of the combined entity. This information will be included in the Company's Quarterly Report on Form 10-Q for the quarter ended March 31, 2020.

[0001048695-20-000012:notes:132]
Term Credit Agreement

[0001048695-20-000012:notes:133]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement (“Term Credit Agreement”) with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the “Term Loan Facility”). The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023.  Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed. Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company’s leverage ratio. Interest on the outstanding principal of borrowings is currently due monthly in arrears. As of January 24, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%. Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA.

[0001048695-20-000012:notes:134]
The proceeds from the Term Loan Facility were used to (i) finance, in part, the acquisition of Shape and (ii) to pay fees and expenses incurred in connection with the acquisition of Shape and the related transactions. As of February 5, 2020, there was $400.0 million outstanding under the Term Loan Facility.

[0001048695-20-000012:notes:135]
Revolving Credit Agreement
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the “Revolving Credit Agreement”) that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the “Revolving Credit Facility”). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. The Revolving Credit Facility matures on January 31, 2025. The remaining outstanding principal of borrowings under the Revolving Credit Facility is due upon maturity on January 31, 2025. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on our leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on our leverage ratio on the undrawn portion of the Revolving Credit Facility. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of February 5, 2020, there were no outstanding borrowings under the Revolving Credit Facility.
