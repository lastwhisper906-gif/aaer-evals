# FFIV 8-K — 0001048695-26-000063 filed 2026-07-27

## item codes, every 8-K on or before 2026-08-06

- 2026-07-27 0001048695-26-000063 — 2.02, 9.01
- 2026-06-23 0001048695-26-000059 — 5.02, 7.01, 9.01
- 2026-04-28 0001048695-26-000044 — 5.02, 8.01, 9.01
- 2026-04-28 0001048695-26-000042 — 2.02, 9.01
- 2026-03-13 0001048695-26-000036 — 5.02, 5.07, 9.01
- 2026-01-27 0001048695-26-000018 — 2.02, 9.01
- 2025-10-27 0001048695-25-000153 — 2.02, 5.02, 9.01
- 2025-10-15 0001048695-25-000149 — 1.05, 5.02, 7.01
- 2025-09-11 0001048695-25-000143 — 7.01, 9.01
- 2025-07-30 0001048695-25-000113 — 2.02, 5.02, 9.01
- 2025-04-28 0001048695-25-000075 — 2.02, 5.02, 9.01
- 2025-03-17 0001048695-25-000068 — 5.07
- 2025-01-28 0001048695-25-000002 — 2.02, 9.01
- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2026-08-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-26-000063:8k_2_02:1]
EX-99.1
2
ex991-q326earningsreleasef.htm
EX-99.1

[0001048695-26-000063:8k_2_02:2]
Document

[0001048695-26-000063:8k_2_02:3]
| Q3 FY26 Earnings Release |  | Page 1 of 5 |

[0001048695-26-000063:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-26-000063:8k_2_02:5]
F5 Reports Third Quarter Results with 19% Product Revenue Growth

[0001048695-26-000063:8k_2_02:6]
Driving 11% Total Revenue Growth Year Over Year

[0001048695-26-000063:8k_2_02:7]
SEATTLE, July 27, 2026 – F5, Inc. (NASDAQ: FFIV), the global leader in delivering and securing every app and API, today announced financial results for its third quarter fiscal year 2026 ended June 30, 2026.

[0001048695-26-000063:8k_2_02:8]
“Q3 was another outstanding quarter with 19% product revenue growth driving 11% total revenue growth year over year,” said François Locoh-Donou, F5’s Chairman, President, and CEO. “Eight consecutive quarters of double-digit product growth reflect the mission-critical role F5 plays at the application delivery and security layer of today’s hybrid multicloud and AI-driven enterprise infrastructure.”

[0001048695-26-000063:8k_2_02:9]
“The world runs on applications and the threats targeting them have never been more sophisticated. AI has empowered attackers and compressed the time between vulnerability discovery and exploitation. F5’s response is a continuous defense model built for this new reality. We are using AI to empower our customers to stay ahead of threats across every environment they operate in by identifying risk earlier, protecting applications at runtime, and delivering hardened software faster,” continued Locoh-Donou.

[0001048695-26-000063:8k_2_02:10]
Third Quarter Performance Summary

[0001048695-26-000063:8k_2_02:11]
Third quarter fiscal year 2026 revenue totaled $865 million, representing 11% growth compared with $780 million in the third quarter of fiscal year 2025. Systems revenue of $240 million grew 32% from the year-ago period while software revenue of $223 million grew 7%. Services revenue of $402 million grew 3% from the year-ago period.

[0001048695-26-000063:8k_2_02:12]
GAAP gross profit for the third quarter of fiscal year 2026 was $712 million, representing GAAP gross margin of 82.2%. This compares with GAAP gross profit of $632 million in the year-ago period, which represented GAAP gross margin of 81.0%. Non-GAAP gross profit for the third quarter of fiscal year 2026 was $728 million, representing non-GAAP gross margin of 84.2%. This compares with non-GAAP gross profit of $649 million in the year-ago period, which represented non-GAAP gross margin of 83.1%.

[0001048695-26-000063:8k_2_02:13]
GAAP income from operations for the third quarter of fiscal year 2026 was $213 million, representing GAAP operating margin of 24.7%. This compares with GAAP income from operations of $196 million in the year-ago period, which represented GAAP operating margin of 25.2%. Non-

[0001048695-26-000063:8k_2_02:14]
| Q3 FY26 Earnings Release |  | Page 2 of 5 |

[0001048695-26-000063:8k_2_02:15]
GAAP income from operations for the period was $303 million, representing non-GAAP operating margin of 35.0%. This compares to non-GAAP income from operations of $267 million in the year-ago period, which represented non-GAAP operating margin of 34.3%.

[0001048695-26-000063:8k_2_02:16]
GAAP net income for the third quarter of fiscal year 2026 was $208 million, or $3.62 per diluted share compared to $190 million, or $3.25 per diluted share, in the third quarter of fiscal year 2025. Non-GAAP net income for the third quarter of fiscal year 2026 was $272 million, or $4.73 per diluted share, compared to $243 million, or $4.16 per diluted share, in the third quarter of fiscal year 2025.

[0001048695-26-000063:8k_2_02:17]
Performance Summary Tables

[0001048695-26-000063:8k_2_02:18]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q3 FY2026 | Q3 FY2025 |  | ($ in millions except EPS) | Q3 FY2026 | Q3 FY2025 |
| Revenue | $865 | $780 |  | Revenue | $865 | $780 |
| Gross profit | $712 | $632 |  | Gross profit | $728 | $649 |
| Gross margin | 82.2% | 81.0% |  | Gross margin | 84.2% | 83.1% |
| Income from operations | $213 | $196 |  | Income from operations | $303 | $267 |
| Operating margin | 24.7% | 25.2% |  | Operating margin | 35.0% | 34.3% |
| Net income | $208 | $190 |  | Net income | $272 | $243 |
| EPS | $3.62 | $3.25 |  | EPS | $4.73 | $4.16 |

[0001048695-26-000063:8k_2_02:19]
A reconciliation of GAAP to non-GAAP measures is included with the attached financial statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-26-000063:8k_2_02:20]
Business Outlook

[0001048695-26-000063:8k_2_02:21]
F5 raised its outlook for its fiscal year 2026, guiding for revenue growth of approximately 9% to 10%, up from 7% to 8% previously. F5 expects non-GAAP earnings per share in a range of $17.21 to $17.33, up from $16.25 to $16.55 previously.

[0001048695-26-000063:8k_2_02:22]
For the fourth quarter of fiscal year 2026, F5 is guiding to revenue in the range of $870 million to $890 million, with non-GAAP earnings in the range of $4.14 to $4.26 per diluted share.

[0001048695-26-000063:8k_2_02:23]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, cyber incident costs, insurance recoveries from cyber incident, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-26-000063:8k_2_02:24]
| Q3 FY26 Earnings Release |  | Page 3 of 5 |

[0001048695-26-000063:8k_2_02:25]
Live Webcast and Conference Call

[0001048695-26-000063:8k_2_02:26]
F5 will host a live webcast to review its financial results and outlook today, July 27, 2026, at 4:30 pm ET. Open to the public, the live webcast, supplemental financial information, and earnings slides are accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S., dial +1 (888) 596-4144; from outside the U.S. dial +1 (646) 968-2525, and reference conference ID 6076834. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-26-000063:8k_2_02:27]
Forward Looking Statements

[0001048695-26-000063:8k_2_02:28]
| Q3 FY26 Earnings Release |  | Page 4 of 5 |

[0001048695-26-000063:8k_2_02:29]
qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-26-000063:8k_2_02:30]
GAAP to non-GAAP Reconciliation

[0001048695-26-000063:8k_2_02:31]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, cyber incident costs, insurance recoveries from cyber incident, restructuring charges, net of tax effects, as well as certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-26-000063:8k_2_02:32]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-26-000063:8k_2_02:33]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-26-000063:8k_2_02:34]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-26-000063:8k_2_02:35]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-26-000063:8k_2_02:36]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle, and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-26-000063:8k_2_02:37]
Cyber incident costs. F5 has incurred certain non-recurring expenses in connection with the investigation and remediation of the Cyber Incident. Management believes it is useful to exclude these expenses as they are not representative of our ongoing operations and to facilitate comparison of the Company’s historical results and to those of peer companies.

[0001048695-26-000063:8k_2_02:38]
Insurance recoveries from cyber incident. F5 has received insurance recoveries in connection with the cyber incident costs described above. Management believes it is useful to exclude these recoveries as they offset

[0001048695-26-000063:8k_2_02:39]
| Q3 FY26 Earnings Release |  | Page 5 of 5 |

[0001048695-26-000063:8k_2_02:40]
the cyber incident costs non-GAAP adjustment, are not representative of our ongoing operations and to facilitate comparison of the Company's historical results and to those of peer companies.

[0001048695-26-000063:8k_2_02:41]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-26-000063:8k_2_02:42]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-26-000063:8k_2_02:43]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-26-000063:8k_2_02:44]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-26-000063:8k_2_02:45]
About F5

[0001048695-26-000063:8k_2_02:46]
F5, Inc. (NASDAQ: FFIV) is the global leader that delivers and secures every app. Backed by three decades of expertise, F5 has built the industry’s premier platform—F5 Application Delivery and Security Platform (ADSP)—to deliver and secure every app, every API, anywhere: on-premises, in the cloud, at the edge, and across hybrid, multicloud environments. F5 is committed to innovating and partnering with the world’s largest and most advanced organizations to deliver fast, available, and secure digital experiences. Together, we help each other thrive and bring a better digital world to life.

[0001048695-26-000063:8k_2_02:47]
For more information visit f5.com

[0001048695-26-000063:8k_2_02:48]
Explore F5 Labs threat research at f5.com/labs

[0001048695-26-000063:8k_2_02:49]
Follow to learn more about F5, our partners, and technologies: Blog | LinkedIn | X | YouTube | Instagram | Facebook

[0001048695-26-000063:8k_2_02:50]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries.

[0001048695-26-000063:8k_2_02:51]
SOURCE: F5, Inc.

[0001048695-26-000063:8k_2_02:52]
F5, Inc.

[0001048695-26-000063:8k_2_02:53]
Consolidated Balance Sheets

[0001048695-26-000063:8k_2_02:54]
(unaudited, in thousands)

[0001048695-26-000063:8k_2_02:55]
|  |  | June 30, |  | September 30, |
|  |  | 2026 |  | 2025 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,605,782 |  |  | $ | 1,344,273 |  |
| Accounts receivable, net of allowances of $2,788 and $2,877 |  | 428,678 |  |  | 414,433 |  |
| Inventories |  | 126,890 |  |  | 77,229 |  |
| Other current assets |  | 785,623 |  |  | 682,766 |  |
| Total current assets |  | 2,946,973 |  |  | 2,518,701 |  |
| Property and equipment, net |  | 197,284 |  |  | 156,947 |  |
| Operating lease right-of-use assets |  | 178,239 |  |  | 185,601 |  |
| Long-term investments |  | 21,991 |  |  | 15,693 |  |
| Deferred tax assets |  | 487,177 |  |  | 446,388 |  |
| Goodwill |  | 2,482,495 |  |  | 2,443,882 |  |
| Other assets, net |  | 514,915 |  |  | 552,280 |  |
| Total assets |  | $ | 6,829,074 |  |  | $ | 6,319,492 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 136,157 |  |  | $ | 83,972 |  |
| Accrued liabilities |  | 344,442 |  |  | 315,383 |  |
| Deferred revenue |  | 1,289,567 |  |  | 1,213,226 |  |
| Total current liabilities |  | 1,770,166 |  |  | 1,612,581 |  |
| Deferred tax liabilities |  | 1,949 |  |  | 1,921 |  |
| Deferred revenue, long-term |  | 903,131 |  |  | 786,011 |  |
| Operating lease liabilities, long-term |  | 218,700 |  |  | 230,749 |  |
| Other long-term liabilities |  | 79,399 |  |  | 96,231 |  |
| Total long-term liabilities |  | 1,203,179 |  |  | 1,114,912 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares issued and outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 56,826 and 57,684 shares issued and outstanding |  | 50,542 |  |  | 42,023 |  |
| Accumulated other comprehensive loss |  | (19,046) |  |  | (18,324) |  |
| Retained earnings |  | 3,824,233 |  |  | 3,568,300 |  |
| Total shareholders’ equity |  | 3,855,729 |  |  | 3,591,999 |  |
| Total liabilities and shareholders’ equity |  | $ | 6,829,074 |  |  | $ | 6,319,492 |  |

[0001048695-26-000063:8k_2_02:56]
F5, Inc.

[0001048695-26-000063:8k_2_02:57]
Consolidated Income Statements

[0001048695-26-000063:8k_2_02:58]
(unaudited, in thousands, except per share amounts)

[0001048695-26-000063:8k_2_02:59]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 462,829 |  |  | $ | 388,838 |  |  | $ | 1,283,627 |  |  | $ | 1,094,531 |  |
| Services |  | 402,248 |  |  | 391,532 |  |  | 1,215,615 |  |  | 1,183,451 |  |
| Total |  | 865,077 |  |  | 780,370 |  |  | 2,499,242 |  |  | 2,277,982 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 93,498 |  |  | 88,782 |  |  | 276,659 |  |  | 252,905 |  |
| Services |  | 60,066 |  |  | 59,846 |  |  | 179,590 |  |  | 177,192 |  |
| Total |  | 153,564 |  |  | 148,628 |  |  | 456,249 |  |  | 430,097 |  |
| Gross profit |  | 711,513 |  |  | 631,742 |  |  | 2,042,993 |  |  | 1,847,885 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 238,026 |  |  | 220,428 |  |  | 702,214 |  |  | 644,524 |  |
| Research and development |  | 164,661 |  |  | 136,345 |  |  | 456,861 |  |  | 403,424 |  |
| General and administrative |  | 95,589 |  |  | 78,652 |  |  | 277,834 |  |  | 228,320 |  |
| Restructuring charges |  | (30) |  |  | — |  |  | (388) |  |  | 11,321 |  |
| Total |  | 498,246 |  |  | 435,425 |  |  | 1,436,521 |  |  | 1,287,589 |  |
| Income from operations |  | 213,267 |  |  | 196,317 |  |  | 606,472 |  |  | 560,296 |  |
| Other income, net |  | 12,932 |  |  | 16,706 |  |  | 31,866 |  |  | 32,971 |  |
| Income before income taxes |  | 226,199 |  |  | 213,023 |  |  | 638,338 |  |  | 593,267 |  |
| Provision for income taxes |  | 17,991 |  |  | 23,111 |  |  | 102,321 |  |  | 91,380 |  |
| Net income |  | $ | 208,208 |  |  | $ | 189,912 |  |  | $ | 536,017 |  |  | $ | 501,887 |  |
| Net income per share — basic |  | $ | 3.67 |  |  | $ | 3.29 |  |  | $ | 9.40 |  |  | $ | 8.65 |  |
| Weighted average shares — basic |  | 56,726 |  |  | 57,772 |  |  | 57,031 |  |  | 57,989 |  |
| Net income per share — diluted |  | $ | 3.62 |  |  | $ | 3.25 |  |  | $ | 9.29 |  |  | $ | 8.54 |  |
| Weighted average shares — diluted |  | 57,550 |  |  | 58,492 |  |  | 57,674 |  |  | 58,773 |  |

[0001048695-26-000063:8k_2_02:60]
F5, Inc.

[0001048695-26-000063:8k_2_02:61]
Consolidated Statements of Cash Flows

[0001048695-26-000063:8k_2_02:62]
(unaudited, in thousands)

[0001048695-26-000063:8k_2_02:63]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2026 |  | 2025 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 536,017 |  |  | $ | 501,887 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 193,535 |  |  | 174,243 |  |
| Depreciation and amortization |  | 72,613 |  |  | 67,608 |  |
| Non-cash operating lease costs |  | 22,377 |  |  | 23,727 |  |
| Deferred income taxes |  | (38,644) |  |  | (56,308) |  |
| Other |  | (3,300) |  |  | 3,918 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (14,262) |  |  | 26,834 |  |
| Inventories |  | (49,661) |  |  | 9,458 |  |
| Other current assets |  | (101,005) |  |  | (54,523) |  |
| Other assets |  | 5,618 |  |  | (68,332) |  |
| Accounts payable and accrued liabilities |  | 50,995 |  |  | (19,031) |  |
| Deferred revenue |  | 192,266 |  |  | 159,003 |  |
| Lease liabilities |  | (25,176) |  |  | (26,886) |  |
| Net cash provided by operating activities |  | 841,373 |  |  | 741,598 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (4,850) |  |  | (4,400) |  |
| Maturities of investments |  | 402 |  |  | — |  |
| Sales of investments |  | 1,575 |  |  | — |  |
| Acquisition of businesses, net of cash acquired |  | (47,619) |  |  | (24,170) |  |
| Purchases of property and equipment |  | (63,705) |  |  | (27,119) |  |
| Net cash used in investing activities |  | (114,197) |  |  | (55,689) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 59,596 |  |  | 59,018 |  |
| Payments for repurchase of common stock, including excise taxes |  | (501,109) |  |  | (377,077) |  |
| Taxes paid related to net share settlement of equity awards |  | (22,664) |  |  | (19,601) |  |
| Net cash used in financing activities |  | (464,177) |  |  | (337,660) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 262,999 |  |  | 348,249 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (1,375) |  |  | 2,442 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,346,368 |  |  | 1,078,340 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,607,992 |  |  | $ | 1,429,031 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 31,490 |  |  | $ | 34,121 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 15,744 |  |  | $ | 37,198 |  |

[0001048695-26-000063:8k_2_02:64]
F5, Inc.

[0001048695-26-000063:8k_2_02:65]
GAAP to Non-GAAP Reconciliation

[0001048695-26-000063:8k_2_02:66]
(unaudited, in thousands, except percentages and per share amounts)

[0001048695-26-000063:8k_2_02:67]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net revenues |  | $ | 865,077 |  |  |  | $ | 780,370 |  |  |  | $ | 2,499,242 |  |  |  | $ | 2,277,982 |  |  |
| Gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit and gross margin |  | $ | 711,513 |  | 82.2 | % |  | $ | 631,742 |  | 81.0 | % |  | $ | 2,042,993 |  | 81.7 | % |  | $ | 1,847,885 |  | 81.1 | % |
| Adjustments to gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 6,905 |  | 0.8 | % |  | $ | 7,408 |  | 0.9 | % |  | $ | 21,204 |  | 0.8 | % |  | $ | 22,201 |  | 1.0 | % |
| Amortization and impairment of purchased intangible assets |  | 9,152 |  | 1.1 | % |  | 9,438 |  | 1.2 | % |  | 30,432 |  | 1.2 | % |  | 28,005 |  | 1.2 | % |
| Facility-exit costs |  | 121 |  | 0.0 | % |  | 118 |  | 0.0 | % |  | 303 |  | 0.0 | % |  | 679 |  | 0.0 | % |
| Acquisition-related charges |  | — |  | 0.0 | % |  | — |  | — |  |  | — |  | 0.0 | % |  | — |  | — |  |
| Cyber incident costs |  | 770 |  | 0.1 | % |  | — |  | — |  |  | 2,416 |  | 0.1 | % |  | — |  | — |  |
| Non-GAAP gross profit and gross margin |  | $ | 728,461 |  | 84.2 | % |  | $ | 648,706 |  | 83.1 | % |  | $ | 2,097,348 |  | 83.9 | % |  | $ | 1,898,770 |  | 83.4 | % |
| Income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income from operations and operating margin |  | $ | 213,267 |  | 24.7 | % |  | $ | 196,317 |  | 25.2 | % |  | $ | 606,472 |  | 24.3 | % |  | $ | 560,296 |  | 24.6 | % |
| Adjustments to income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 65,534 |  | 7.6 | % |  | $ | 57,451 |  | 7.4 | % |  | $ | 193,535 |  | 7.7 | % |  | $ | 174,243 |  | 7.6 | % |
| Amortization and impairment of purchased intangible assets |  | 9,619 |  | 1.1 | % |  | 10,250 |  | 1.3 | % |  | 32,523 |  | 1.3 | % |  | 30,488 |  | 1.3 | % |
| Facility-exit costs |  | 1,224 |  | 0.1 | % |  | 1,243 |  | 0.2 | % |  | 3,077 |  | 0.1 | % |  | 6,727 |  | 0.3 | % |
| Acquisition-related charges |  | 10,064 |  | 1.2 | % |  | 2,032 |  | 0.3 | % |  | 28,902 |  | 1.2 | % |  | 3,937 |  | 0.2 | % |
| Cyber incident costs |  | 2,978 |  | 0.3 | % |  | — |  | — |  |  | 26,503 |  | 1.1 | % |  | — |  | — |  |
| Restructuring charges |  | (30) |  | 0.0 | % |  | — |  | — |  |  | (388) |  | 0.0 | % |  | 11,321 |  | 0.5 | % |
| Non-GAAP income from operations and operating margin |  | $ | 302,656 |  | 35.0 | % |  | $ | 267,293 |  | 34.3 | % |  | $ | 890,624 |  | 35.6 | % |  | $ | 787,012 |  | 34.5 | % |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 208,208 |  |  |  | $ | 189,912 |  |  |  | $ | 536,017 |  |  |  | $ | 501,887 |  |  |
| Adjustments to net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 65,534 |  |  |  | $ | 57,451 |  |  |  | $ | 193,535 |  |  |  | $ | 174,243 |  |  |
| Amortization and impairment of purchased intangible assets |  | 9,619 |  |  |  | 10,250 |  |  |  | 32,523 |  |  |  | 30,488 |  |  |
| Facility-exit costs |  | 1,224 |  |  |  | 1,243 |  |  |  | 3,077 |  |  |  | 6,727 |  |  |
| Acquisition-related charges |  | 10,064 |  |  |  | 2,032 |  |  |  | 28,902 |  |  |  | 3,937 |  |  |
| Cyber incident costs |  | 2,978 |  |  |  | — |  |  |  | 26,503 |  |  |  | — |  |  |
| Insurance recoveries from cyber incident |  | (5,309) |  |  |  | — |  |  |  | (5,309) |  |  |  | — |  |  |
| Restructuring charges |  | (30) |  |  |  | — |  |  |  | (388) |  |  |  | 11,321 |  |  |
| Tax effects related to above items |  | (20,344) |  |  |  | (17,647) |  |  |  | (60,957) |  |  |  | (57,296) |  |  |
| Non-GAAP net income |  | $ | 271,944 |  |  |  | $ | 243,241 |  |  |  | $ | 753,903 |  |  |  | $ | 671,307 |  |  |
| Net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share — diluted |  | $ | 3.62 |  |  |  | $ | 3.25 |  |  |  | $ | 9.29 |  |  |  | $ | 8.54 |  |  |
| Adjustments to GAAP net income per share — diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 1.14 |  |  |  | $ | 0.98 |  |  |  | $ | 3.36 |  |  |  | $ | 2.96 |  |  |
| Amortization and impairment of purchased intangible assets |  | 0.17 |  |  |  | 0.18 |  |  |  | 0.56 |  |  |  | 0.52 |  |  |
| Facility-exit costs |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.05 |  |  |  | 0.11 |  |  |
| Acquisition-related charges |  | 0.17 |  |  |  | 0.03 |  |  |  | 0.50 |  |  |  | 0.07 |  |  |
| Cyber incident costs |  | 0.05 |  |  |  | — |  |  |  | 0.46 |  |  |  | — |  |  |
| Insurance recoveries from cyber incident |  | (0.09) |  |  |  | — |  |  |  | (0.09) |  |  |  | — |  |  |
| Restructuring charges |  | (0.00) |  |  |  | — |  |  |  | (0.01) |  |  |  | 0.19 |  |  |
| Tax effects related to above items |  | (0.35) |  |  |  | (0.30) |  |  |  | (1.06) |  |  |  | (0.97) |  |  |
| Non-GAAP net income per share — diluted |  | $ | 4.73 |  |  |  | $ | 4.16 |  |  |  | $ | 13.07 |  |  |  | $ | 11.42 |  |  |
| Weighted average shares — diluted |  | 57,550 |  |  |  | 58,492 |  |  |  | 57,674 |  |  |  | 58,773 |  |  |

[0001048695-26-000063:8k_2_02:68]
Note: Numbers and percentages are rounded for presentation purposes and may not foot.
