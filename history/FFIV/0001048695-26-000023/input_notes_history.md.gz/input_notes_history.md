# FFIV note change history — 0001048695-25-000129 → 0001048695-26-000023


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-05):
[0001048695-26-000023:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2025 and September 30, 2025 were not material.
  (was, 2025-08-06, similarity 0.9547):
[0001048695-25-000129:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2025 and September 30, 2024 were not material.

- changed (2026-02-05):
[0001048695-26-000023:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2025, the Company had no remaining purchase commitments under the fourth year of the agreement. The Company did not have any non-cancelable long-term purchase commitments outstanding as of December 31, 2025.
  (was, 2025-08-06, similarity 0.9216):
[0001048695-25-000129:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of June 30, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2025 was $10.0 million.

- added (2026-02-05):
[0001048695-26-000023:note_history:3]
Smith v. F5, Inc., et al.

- added (2026-02-05):
[0001048695-26-000023:note_history:4]
On December 19, 2025, Matthew Smith filed a putative class action complaint against F5, Inc., and certain of its executives in the United States District Court for the Western District of Washington, purportedly on behalf of individuals who purchased or otherwise acquired the Company's common stock between October 28, 2024 and October 27, 2025.  The complaint alleges that the Company and certain of its officers made false or misleading statements in violation of Sections 10(b) and 20(a) of the Exchange Act of 1934 regarding the Company’s cybersecurity capabilities. The complaint requests monetary damages, including interest, reasonable attorney fees, expert fees and other costs. The action is in its early stages. The Company intends to vigorously defend this claim.

- changed (2026-02-05):
[0001048695-26-000023:note_history:5]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these claims and lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any
  (was, 2025-08-06, similarity 0.8035):
[0001048695-25-000129:note_history:5]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2026-02-05):
[0001048695-26-000023:note_history:6]
litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2026-02-05):
[0001048695-26-000023:note_history:7]
Cyber Incident

- added (2026-02-05):
[0001048695-26-000023:note_history:8]
On October 15, 2025, the Company disclosed a security incident in which a threat actor maintained long-term, persistent access to F5 systems, and certain files were exfiltrated, referred to as the "Cyber Incident." In connection with the Cyber Incident, some customers and third parties may assert claims against the Company and/or officers and directors of the Company. The Company has also received a small number of inquiries from governmental authorities. The Company is cooperating and providing information in connection with these inquiries.

- added (2026-02-05):
[0001048695-26-000023:note_history:9]
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. The Company incurred $17.5 million of costs in response to the Cyber Incident for the three months ended December 31, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-05):
[0001048695-26-000023:note_history:10]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.
  (was, 2025-08-06, similarity 0.9869):
[0001048695-25-000129:note_history:10]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and software-as-a-service solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- added (2026-02-05):
[0001048695-26-000023:note_history:11]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2025.

- added (2026-02-05):
[0001048695-26-000023:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- added (2026-02-05):
[0001048695-26-000023:note_history:13]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- added (2026-02-05):
[0001048695-26-000023:note_history:14]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.

- removed (2026-02-05):
[0001048695-25-000129:note_history:15]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

- removed (2026-02-05):
[0001048695-25-000129:note_history:16]
Investments

- removed (2026-02-05):
[0001048695-25-000129:note_history:17]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of money market funds, corporate and municipal bonds and notes, and the United States government and agency securities, are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

- removed (2026-02-05):
[0001048695-25-000129:note_history:18]
Equity investments without readily determinable fair values are measured at cost with adjustments for observable changes in price or impairments, or measured using net asset value as a practical expedient to fair value and are classified as long-term investments on the Company's consolidated balance sheets. The Company performs a qualitative assessment on a periodic basis and recognizes an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense) in the Company's consolidated income statements.

- removed (2026-02-05):
[0001048695-25-000129:note_history:19]
Fair Value of Financial Instruments

- removed (2026-02-05):
[0001048695-25-000129:note_history:20]
Short-term and long-term debt investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gains or losses being recorded to other comprehensive income (loss). The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

- removed (2026-02-05):
[0001048695-25-000129:note_history:21]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- removed (2026-02-05):
[0001048695-25-000129:note_history:22]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-05):
[0001048695-26-000023:note_history:23]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 were not material.
  (was, 2025-08-06, similarity 0.9845):
[0001048695-25-000129:note_history:23]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2025 were not material.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-05):
[0001048695-26-000023:note_history:24]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):
  (was, 2025-08-06, similarity 0.9499):
[0001048695-25-000129:note_history:24]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):

- changed (2026-02-05):
[0001048695-26-000023:note_history:25]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 76,552 |  |  | $ | 66,258 |  |
| Additional capitalized contract acquisition costs |  | 12,384 |  |  | 13,223 |  |
| Amortization of capitalized contract acquisition costs |  | (10,311) |  |  | (9,134) |  |
| Balance, end of period |  | $ | 78,625 |  |  | $ | 70,347 |  |
  (was, 2025-08-06, similarity 0.9299):
[0001048695-25-000129:note_history:25]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 34,295 |  |  | 21,553 |  |
| Amortization of capitalized contract acquisition costs |  | (28,261) |  |  | (26,705) |  |
| Balance, end of period |  | $ | 72,292 |  |  | $ | 61,316 |  |

- changed (2026-02-05):
[0001048695-26-000023:note_history:26]
Amortization of capitalized contract acquisition costs was $10.3 million and $9.1 million for the three months ended December 31, 2025 and 2024, respectively, and is recorded in sales and marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2025-08-06, similarity 0.8732):
[0001048695-25-000129:note_history:26]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.7 million for the three months ended June 30, 2025 and 2024, respectively, and $28.3 million and $26.7 million for the nine months ended June 30, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2026-02-05):
[0001048695-26-000023:note_history:27]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):
  (was, 2025-08-06, similarity 0.947):
[0001048695-25-000129:note_history:27]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):

- added (2026-02-05):
[0001048695-26-000023:note_history:28]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,999,237 |  |  | $ | 1,797,959 |  |
| Amounts added but not recognized as revenues |  | 493,789 |  |  | 556,919 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (431,365) |  |  | (408,618) |  |
| Balance, end of period |  | $ | 2,061,661 |  |  | $ | 1,946,260 |  |

- changed (2026-02-05):
[0001048695-26-000023:note_history:29]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.1 billion and the Company expects to recognize revenues on 60.8% of these remaining performance obligations over the next 12 months, 23.9% in year two, and the remaining balance thereafter.
  (was, 2025-08-06, similarity 0.9927):
[0001048695-25-000129:note_history:29]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.0 billion and the Company expects to recognize revenues on 61.4% of these remaining performance obligations over the next 12 months, 23.7% in year two, and the remaining balance thereafter.

- removed (2026-02-05):
[0001048695-25-000129:note_history:30]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 1,123,086 |  |  | 966,031 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (964,083) |  |  | (968,568) |  |
| Balance, end of period |  | $ | 1,956,962 |  |  | $ | 1,772,584 |  |
