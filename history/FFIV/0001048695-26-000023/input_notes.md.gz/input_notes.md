# FFIV notes — 0001048695-26-000023


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-26-000023:notes:1]
[same as prior period, unchanged from 0001048695-25-000129:notes:1]

[0001048695-26-000023:notes:2]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-26-000023:notes:3]
[same as prior period, unchanged from 0001048695-25-000129:notes:3]

[0001048695-26-000023:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001048695-26-000023:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2025.

[0001048695-26-000023:notes:6]
[same as prior period, unchanged from 0001048695-25-000129:notes:11]

[0001048695-26-000023:notes:7]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-26-000023:notes:8]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-26-000023:notes:9]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-26-000023:notes:10]
[same as prior period, unchanged from 0001048695-25-000129:notes:14]

[0001048695-26-000023:notes:11]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):

[0001048695-26-000023:notes:12]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 76,552 |  |  | $ | 66,258 |  |
| Additional capitalized contract acquisition costs |  | 12,384 |  |  | 13,223 |  |
| Amortization of capitalized contract acquisition costs |  | (10,311) |  |  | (9,134) |  |
| Balance, end of period |  | $ | 78,625 |  |  | $ | 70,347 |  |

[0001048695-26-000023:notes:13]
Amortization of capitalized contract acquisition costs was $10.3 million and $9.1 million for the three months ended December 31, 2025 and 2024, respectively, and is recorded in sales and marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-26-000023:notes:14]
[same as prior period, unchanged from 0001048695-25-000129:notes:18]

[0001048695-26-000023:notes:15]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-26-000023:notes:16]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):

[0001048695-26-000023:notes:17]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,999,237 |  |  | $ | 1,797,959 |  |
| Amounts added but not recognized as revenues |  | 493,789 |  |  | 556,919 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (431,365) |  |  | (408,618) |  |
| Balance, end of period |  | $ | 2,061,661 |  |  | $ | 1,946,260 |  |

[0001048695-26-000023:notes:18]
[same as prior period, unchanged from 0001048695-25-000129:notes:22]

[0001048695-26-000023:notes:19]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.1 billion and the Company expects to recognize revenues on 60.8% of these remaining performance obligations over the next 12 months, 23.9% in year two, and the remaining balance thereafter.

[0001048695-26-000023:notes:20]
[same as prior period, unchanged from 0001048695-25-000129:notes:24]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-26-000023:notes:21]
Fair Value Measurements
Assets and Liabilities Measured and Recorded at Fair Value on a Recurring Basis

[0001048695-26-000023:notes:22]
The Company's financial assets measured at fair value on a recurring basis at December 31, 2025 and September 30, 2025, were as follows (in thousands):

[0001048695-26-000023:notes:23]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| December 31, 2025 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Level 1 |  | $ | 308,951 |  |  | $ | — |  |  | $ | — |  |  | $ | 308,951 |  |  | $ | 308,951 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  |  |  | $ | 308,951 |  |  | $ | — |  |  | $ | — |  |  | $ | 308,951 |  |  | $ | 308,951 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 17,965 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,965 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 17,965 |  |  | — |  |  | — |  |  | 17,965 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 326,916 |  |  | $ | 308,951 |  |  | $ | — |  |  | $ | 17,965 |  |

[0001048695-26-000023:notes:24]
[same as prior period, unchanged from 0001048695-25-000129:notes:37]

[0001048695-26-000023:notes:25]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| September 30, 2025 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Level 1 |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,997 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,997 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 15,693 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,693 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 15,693 |  |  | — |  |  | — |  |  | 15,693 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 658,690 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | 15,693 |  |

[0001048695-26-000023:notes:26]
* Equity investments presented in the table above include investments without readily determinable fair values that are measured at fair value using NAV as a practical expedient, or are measured at cost with adjustments for observable changes in price or impairments. The equity investments are not classified within the fair value hierarchy.

[0001048695-26-000023:notes:27]
[same as prior period, unchanged from 0001048695-25-000129:notes:40]

[0001048695-26-000023:notes:28]
Interest income from cash, cash equivalents, and investments was $8.9 million and $10.3 million for the three months ended December 31, 2025 and 2024, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. There were no unrealized losses on investments held for a period greater than 12 months at December 31, 2025 and September 30, 2025.

[0001048695-26-000023:notes:29]
The Company determined that as of December 31, 2025, there were no credit losses on any investments within its portfolio.

[0001048695-26-000023:notes:30]
[same as prior period, unchanged from 0001048695-25-000129:notes:43]

[0001048695-26-000023:notes:31]
[same as prior period, unchanged from 0001048695-25-000129:notes:44]

[0001048695-26-000023:notes:32]
The Company did not recognize any impairment charges related to non-financial long-lived assets for the three months ended December 31, 2025 and 2024.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-26-000023:notes:33]
Business Combinations
Fiscal Year 2025 Acquisition of CalypsoAI Corp

[0001048695-26-000023:notes:34]
On September 26, 2025, the Company closed on a transaction for the acquisition of CalypsoAI Corp. ("CalypsoAI"), a provider in enterprise AI security for $145.2 million in cash, with CalypsoAI immediately becoming a wholly-owned subsidiary of F5 upon the closing of the transaction. The addition of CalypsoAI's platform brings real-time threat defense, red teaming at scale, and data security to enterprises racing to deploy generative and agentic AI. These capabilities will be integrated into the F5 ADSP to create an enhanced solution for securing AI inference.

[0001048695-26-000023:notes:35]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of CalypsoAI. The goodwill related to the CalypsoAI acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the CalypsoAI acquisition was not deductible for tax purposes. Transaction costs associated with the acquisition were not material.

[0001048695-26-000023:notes:36]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-26-000023:notes:37]
| Other net tangible assets acquired, at fair value |  | $ | 14,151 |  |
| Identifiable intangible assets, developed technology |  | 16,900 |  |
| Goodwill |  | 114,156 |  |
| Total net assets acquired |  | $ | 145,207 |  |

[0001048695-26-000023:notes:38]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-26-000023:notes:39]
The developed technology intangible assets are amortized on a straight-line basis over the weighted average estimated useful life of 4.21 years and included in cost of net product revenues. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-26-000023:notes:40]
The pro forma financial information, as well as the revenue and earnings generated by CalypsoAI, were not material to the Company's operations for the periods presented.

[0001048695-26-000023:notes:41]
Other Fiscal Year 2025 Acquisitions

[0001048695-26-000023:notes:42]
During the second, third and fourth quarters of fiscal 2025, the Company completed three additional acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $17.4 million of goodwill as a result of the acquisitions. The acquisitions did not have a material impact to the Company's operating results.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-26-000023:notes:43]
[same as prior period, unchanged from 0001048695-25-000129:notes:50]

[0001048695-26-000023:notes:44]
[same as prior period, unchanged from 0001048695-25-000129:notes:51]

[0001048695-26-000023:notes:45]
|  |  | December 31,2025 |  | September 30,2025 |
| Cash and cash equivalents |  | $ | 1,199,734 |  |  | $ | 1,344,273 |  |
| Restricted cash included in other assets, net |  | 2,136 |  |  | 2,095 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,201,870 |  |  | $ | 1,346,368 |  |

[0001048695-26-000023:notes:46]
[same as prior period, unchanged from 0001048695-25-000129:notes:53]

[0001048695-26-000023:notes:47]
[same as prior period, unchanged from 0001048695-25-000129:notes:54]

[0001048695-26-000023:notes:48]
|  |  | December 31,2025 |  | September 30,2025 |
| Finished goods |  | $ | 35,302 |  |  | $ | 26,933 |  |
| Raw materials |  | 44,593 |  |  | 50,296 |  |
|  |  | $ | 79,895 |  |  | $ | 77,229 |  |

[0001048695-26-000023:notes:49]
[same as prior period, unchanged from 0001048695-25-000129:notes:56]

[0001048695-26-000023:notes:50]
[same as prior period, unchanged from 0001048695-25-000129:notes:57]

[0001048695-26-000023:notes:51]
|  |  | December 31,2025 |  | September 30,2025 |
| Unbilled receivables |  | $ | 512,595 |  |  | $ | 498,288 |  |
| Prepaid expenses |  | 145,388 |  |  | 86,346 |  |
| Capitalized contract acquisition costs |  | 38,087 |  |  | 37,023 |  |
| Other |  | 46,093 |  |  | 61,109 |  |
|  |  | $ | 742,163 |  |  | $ | 682,766 |  |

[0001048695-26-000023:notes:52]
Other Assets

[0001048695-26-000023:notes:53]
[same as prior period, unchanged from 0001048695-25-000129:notes:60]

[0001048695-26-000023:notes:54]
|  |  | December 31,2025 |  | September 30,2025 |
| Intangible assets |  | $ | 84,206 |  |  | $ | 96,266 |  |
| Unbilled receivables |  | 303,892 |  |  | 340,153 |  |
| Capitalized contract acquisition costs |  | 40,538 |  |  | 39,529 |  |
| Other |  | 81,146 |  |  | 76,332 |  |
|  |  | $ | 509,782 |  |  | $ | 552,280 |  |

[0001048695-26-000023:notes:55]
[same as prior period, unchanged from 0001048695-25-000129:notes:62]

[0001048695-26-000023:notes:56]
[same as prior period, unchanged from 0001048695-25-000129:notes:63]

[0001048695-26-000023:notes:57]
|  |  | December 31,2025 |  | September 30,2025 |
| Payroll and benefits |  | $ | 167,096 |  |  | $ | 189,337 |  |
| Operating lease liabilities, current |  | 32,856 |  |  | 31,042 |  |
| Income and other tax accruals |  | 60,979 |  |  | 44,051 |  |
| Other |  | 44,257 |  |  | 50,953 |  |
|  |  | $ | 305,188 |  |  | $ | 315,383 |  |

[0001048695-26-000023:notes:58]
[same as prior period, unchanged from 0001048695-25-000129:notes:65]

[0001048695-26-000023:notes:59]
[same as prior period, unchanged from 0001048695-25-000129:notes:66]

[0001048695-26-000023:notes:60]
|  |  | December 31,2025 |  | September 30,2025 |
| Income taxes payable |  | $ | 77,925 |  |  | $ | 85,278 |  |
| Other |  | 11,212 |  |  | 10,953 |  |
|  |  | $ | 89,137 |  |  | $ | 96,231 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-26-000023:notes:61]
Debt Facilities
Revolving Credit Agreement

[0001048695-26-000023:notes:62]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 were not material.

[0001048695-26-000023:notes:63]
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-26-000023:notes:64]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-26-000023:notes:65]
The components of the Company's operating lease expenses for the three months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001048695-26-000023:notes:66]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Operating lease expense |  | $ | 9,701 |  |  | $ | 10,007 |  |
| Short-term lease expense |  | 839 |  |  | 819 |  |
| Variable lease expense |  | 5,945 |  |  | 5,592 |  |
| Total lease expense |  | $ | 16,485 |  |  | $ | 16,418 |  |

[0001048695-26-000023:notes:67]
[same as prior period, unchanged from 0001048695-25-000129:notes:74]

[0001048695-26-000023:notes:68]
[same as prior period, unchanged from 0001048695-25-000129:notes:75]

[0001048695-26-000023:notes:69]
|  |  | December 31, 2025 |  | September 30, 2025 |
| Operating lease right-of-use assets, net |  | $ | 191,350 |  |  | $ | 185,601 |  |
| Operating lease liabilities, current1 |  | 32,856 |  |  | 31,042 |  |
| Operating lease liabilities, long-term |  | 234,862 |  |  | 230,749 |  |
| Total operating lease liabilities |  | $ | 267,718 |  |  | $ | 261,791 |  |
| Weighted average remaining lease term (in years) |  | 7.8 |  | 7.7 |
| Weighted average discount rate |  | 3.33 | % |  | 3.24 | % |

[0001048695-26-000023:notes:70]
[same as prior period, unchanged from 0001048695-25-000129:notes:77]

[0001048695-26-000023:notes:71]
As of December 31, 2025, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-26-000023:notes:72]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2026 (remainder) |  | $ | 29,848 |  |
| 2027 |  | 43,025 |  |
| 2028 |  | 38,826 |  |
| 2029 |  | 35,321 |  |
| 2030 |  | 34,777 |  |
| 2031 |  | 34,142 |  |
| Thereafter |  | 92,259 |  |
| Total lease payments |  | 308,198 |  |
| Less: imputed interest |  | (40,480) |  |
| Total lease liabilities |  | $ | 267,718 |  |

[0001048695-26-000023:notes:73]
Operating lease liabilities above do not include sublease income. As of December 31, 2025, the Company expects to receive sublease income of approximately $6.7 million, which consists of $1.5 million to be received for the remainder of fiscal 2026 and $5.2 million to be received over the seven fiscal years thereafter.
As of December 31, 2025, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-26-000023:notes:74]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-26-000023:notes:75]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-26-000023:notes:76]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2025 and September 30, 2025 were not material.

[0001048695-26-000023:notes:77]
Commitments

[0001048695-26-000023:notes:78]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2025, the Company had no remaining purchase commitments under the fourth year of the agreement. The Company did not have any non-cancelable long-term purchase commitments outstanding as of December 31, 2025.

[0001048695-26-000023:notes:79]
The Company leases its facilities under operating leases that expire at various dates through 2041. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-26-000023:notes:80]
Legal Proceedings

[0001048695-26-000023:notes:81]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-26-000023:notes:82]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-26-000023:notes:83]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-26-000023:notes:84]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-26-000023:notes:85]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. The parties are engaged in a first phase of discovery ordered by the Court in a March 7th case management conference that is focused on whether any NGINX Plus code was written by individuals employed by Rambler before the end of 2011.  On May 19, 2025, the Company and the other defendants answered Lynwood’s second amended complaint filed April 7, 2025, which was limited to the remaining portion of the copyright claim focused on NGINX Plus per the Court’s March 7th order. The Company intends to continue vigorously defending the litigation.

[0001048695-26-000023:notes:86]
Smith v. F5, Inc., et al.

[0001048695-26-000023:notes:87]
On December 19, 2025, Matthew Smith filed a putative class action complaint against F5, Inc., and certain of its executives in the United States District Court for the Western District of Washington, purportedly on behalf of individuals who purchased or otherwise acquired the Company's common stock between October 28, 2024 and October 27, 2025.  The complaint alleges that the Company and certain of its officers made false or misleading statements in violation of Sections 10(b) and 20(a) of the Exchange Act of 1934 regarding the Company’s cybersecurity capabilities. The complaint requests monetary damages, including interest, reasonable attorney fees, expert fees and other costs. The action is in its early stages. The Company intends to vigorously defend this claim.

[0001048695-26-000023:notes:88]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these claims and lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any

[0001048695-26-000023:notes:89]
litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-26-000023:notes:90]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

[0001048695-26-000023:notes:91]
Cyber Incident

[0001048695-26-000023:notes:92]
On October 15, 2025, the Company disclosed a security incident in which a threat actor maintained long-term, persistent access to F5 systems, and certain files were exfiltrated, referred to as the "Cyber Incident." In connection with the Cyber Incident, some customers and third parties may assert claims against the Company and/or officers and directors of the Company. The Company has also received a small number of inquiries from governmental authorities. The Company is cooperating and providing information in connection with these inquiries.

[0001048695-26-000023:notes:93]
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. The Company incurred $17.5 million of costs in response to the Cyber Incident for the three months ended December 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-26-000023:notes:94]
[same as prior period, unchanged from 0001048695-25-000129:notes:96]

[0001048695-26-000023:notes:95]
The effective tax rate was 19.2% and 20.4% for the three months ended December 31, 2025 and 2024, respectively. The decrease in the effective tax rate for the three months ended December 31, 2025 as compared to the three months ended December 31, 2024 is primarily due to change in unrecognized tax benefits.

[0001048695-26-000023:notes:96]
At December 31, 2025, the Company had $80.9 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-26-000023:notes:97]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018, as well as fiscal years 2020 and 2021. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2024 for the United Kingdom, 2024 for Singapore, 2020 for Israel, and 2019 for India. The Company is currently under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2022, and by various foreign jurisdictions including India for fiscal years 2019 to 2024, Israel for fiscal years 2020 to 2023, and Saudi Arabia for fiscal years 2015 to 2021.

[0001048695-26-000023:notes:98]
On July 4, 2025, the One Big Beautiful Bill Act was enacted into law. Applicable changes resulting from this legislation are not material for the current period and have been reflected in the Company’s consolidated financial statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-26-000023:notes:99]
[same as prior period, unchanged from 0001048695-25-000129:notes:100]

[0001048695-26-000023:notes:100]
On October 25, 2024, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization was incremental to the existing $6.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-26-000023:notes:101]
[same as prior period, unchanged from 0001048695-25-000129:notes:102]

[0001048695-26-000023:notes:102]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Shares repurchased |  | 1,203 |  | 490 |
| Average price per share |  | $ | 249.33 |  |  | $ | 255.31 |  |
| Amount repurchased |  | $ | 300,024 |  |  | $ | 125,010 |  |

[0001048695-26-000023:notes:103]
As of December 31, 2025, the Company had $622.4 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-26-000023:notes:104]
[same as prior period, unchanged from 0001048695-25-000129:notes:105]

[0001048695-26-000023:notes:105]
[same as prior period, unchanged from 0001048695-25-000129:notes:106]

[0001048695-26-000023:notes:106]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Numerator |  |  |  |  |
| Net income |  | $ | 180,054 |  |  | $ | 166,445 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 57,650 |  |  | 58,305 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 514 |  |  | 753 |  |
| Weighted average shares outstanding — diluted |  | 58,164 |  |  | 59,058 |  |
| Basic net income per share |  | $ | 3.12 |  |  | $ | 2.85 |  |
| Diluted net income per share |  | $ | 3.10 |  |  | $ | 2.82 |  |

[0001048695-26-000023:notes:107]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three months ended December 31, 2025 and 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-26-000023:notes:108]
[same as prior period, unchanged from 0001048695-25-000129:notes:109]

[0001048695-26-000023:notes:109]
The Company's Chief Executive Officer, who is the chief operating decision maker ("CODM"), regularly assesses performance and decides how to allocate resources primarily based on consolidated net income reported in the Consolidated Income Statements. The CODM uses consolidated net income to assess performance and make operating decisions by monitoring consolidated net income actual results compared to forecasted results, as well as reviewing historical performance trends. The CODM also manages the Company’s operations by reviewing consolidated net revenues by products and services and consolidated expense information consistent with the financial statement line items reported in the Consolidated Income Statements. Significant expenses include cost of net revenues by products and services, sales and marketing expenses, research and development expenses, general and administrative expenses, restructuring charges, and provision for income taxes, all of which are presented in the Consolidated Income Statements. Other segment items primarily include interest income, interest expense, and foreign currency transactions gains and losses, which are presented in other income, net in the Consolidated Income Statements. The measure of segment assets is reported on the Consolidated Balance Sheets as total assets.

[0001048695-26-000023:notes:110]
[same as prior period, unchanged from 0001048695-25-000129:notes:110]

[0001048695-26-000023:notes:111]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). The Company's CODM reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company’s foreign offices conduct sales, marketing, research and development, and support activities. Revenues are attributed by geographic location based on the location of the end-user customer.

[0001048695-26-000023:notes:112]
[same as prior period, unchanged from 0001048695-25-000129:notes:112]

[0001048695-26-000023:notes:113]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Americas: |  |  |  |  |
| United States |  | $ | 413,196 |  |  | $ | 407,388 |  |
| Other |  | 26,592 |  |  | 24,585 |  |
| Total Americas |  | 439,788 |  |  | 431,973 |  |
| EMEA |  | 253,709 |  |  | 204,387 |  |
| APAC |  | 128,968 |  |  | 130,129 |  |
|  |  | $ | 822,465 |  |  | $ | 766,489 |  |

[0001048695-26-000023:notes:114]
[same as prior period, unchanged from 0001048695-25-000129:notes:114]

[0001048695-26-000023:notes:115]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 218,356 |  |  | $ | 159,708 |  |
| Software revenue |  | 191,927 |  |  | 208,789 |  |
| Total net product revenue |  | $ | 410,283 |  |  | $ | 368,497 |  |

[0001048695-26-000023:notes:116]
The following distributor customers accounted for more than 10% of total net revenue:

[0001048695-26-000023:notes:117]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Customer A |  | 19.2 | % |  | 16.2 | % |
| Customer B |  | 15.5 | % |  | 16.8 | % |

[0001048695-26-000023:notes:118]
No end-user customers accounted for more than 10% of total net revenue. No other distributor customers accounted for more than 10% of total net revenue, other than those noted above.

[0001048695-26-000023:notes:119]
[same as prior period, unchanged from 0001048695-25-000129:notes:118]

[0001048695-26-000023:notes:120]
|  |  | December 31,2025 |  | September 30,2025 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 119,613 |  |  | $ | 118,414 |  |  |  |  |  |
| Other |  | 1,799 |  |  | 1,696 |  |  |  |  |  |
| Total Americas |  | 121,412 |  |  | 120,110 |  |  |  |  |  |
| EMEA |  | 20,685 |  |  | 20,985 |  |  |  |  |  |
| APAC |  | 15,003 |  |  | 15,852 |  |  |  |  |  |
|  |  | $ | 157,100 |  |  | $ | 156,947 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-26-000023:notes:121]
Restructuring Charges
In the first and fourth quarters of fiscal 2025, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including reduction in force programs. In the first quarter of fiscal 2025, the Company recorded a restructuring charge of $11.3 million. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2025 restructuring plan. In the fourth quarter of fiscal 2025, the Company recorded a restructuring charge of $14.3 million. The Company did not record any significant subsequent charges related to the fourth quarter of fiscal 2025 restructuring plan.

[0001048695-26-000023:notes:122]
During the three months ended December 31, 2025 and 2024, the following activity was recorded (in thousands):

[0001048695-26-000023:notes:123]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | 8,846 |  |  | $ | — |  |
| Restructuring charges1 |  | (43) |  |  | 11,321 |  |
| Cash payments |  | (8,175) |  |  | (9,208) |  |
| Accrued expenses, end of period |  | $ | 628 |  |  | $ | 2,113 |  |

[0001048695-26-000023:notes:124]
(1)    Includes restructuring charges and adjustments for in period relief of unused benefits and foreign currency fluctuations.
Charges related to employee severance, benefits, and related costs are reflected in the restructuring charges line item on the Company's consolidated income statements.
